#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SEVEN HEAVEN LOCAL
Version interne : 7.0 — moteur documentaire local vérifiable

Dossier stable : AERITH_LOCAL_APP

Application locale pour piloter un Coffre @erith.IA sans transformer un LLM
local en faux administrateur du dépôt.

Principes vérifiables :
- écoute uniquement sur 127.0.0.1 ;
- les 7 archives ERITH-7 sont embarquées comme bibliothèque locale ;
- un miroir Git local peut être indexé en lecture seule après choix explicite ;
- aucun Vault DPAPI, aucune écriture Git, aucune commande système n'est exposée ;
- Ollama reçoit les vrais documents sélectionnés sous une limite visible de contexte ;
- les sessions sont sauvegardées uniquement sur demande explicite.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import threading
import time
import sys
import unicodedata
import urllib.error
import urllib.request
from html.parser import HTMLParser
import webbrowser
import zipfile
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qs, urljoin, urlparse

APP_NAME = "SEVEN HEAVEN LOCAL"
APP_VERSION = "SEVEN HEAVEN LOCAL — moteur documentaire intégral"
INDEX_SCHEMA = "seven-document-engine-complete-catalog-20260705"
APP_FOLDER = "AERITH_LOCAL_APP"
HOST = "127.0.0.1"
PORT = int(os.environ.get("SEVEN_HEAVEN_PORT", os.environ.get("AERITH_LOCAL_PORT", "8765")))
OLLAMA_API = "http://127.0.0.1:11434/api"
MODEL_NAME = "aerith:base"
ROOT = Path(__file__).resolve().parent
INDEX_HTML = ROOT / "index.html"
LIBRARY_DIR = ROOT / "library"
PACKS_DIR = LIBRARY_DIR / "packs"
CANONICAL_SEED_DIR = LIBRARY_DIR / "canonical_seed"
DATA_DIR = ROOT / "data"
SESSIONS_DIR = DATA_DIR / "sessions"
CONFIG_PATH = DATA_DIR / "config.json"
LINKS_PATH = DATA_DIR / "links.json"
LIBRARY_INDEX_PATH = DATA_DIR / "library_index.json"
RAG_INDEX_PATH = DATA_DIR / "library_rag_index.json"
IDENTITY_REGISTRY_PATH = CANONICAL_SEED_DIR / "AERITH_CANONICAL_TOPOLOGY.json"
MODELFILE_PATH = ROOT / "AERITH_BASE.Modelfile"
RUNTIME_TRACES_DIR = DATA_DIR / "runtime_traces"

ALLOWED_EXTENSIONS = {".md", ".txt", ".json", ".yaml", ".yml"}
TEXT_RAG_EXTENSIONS = {".md", ".txt", ".json", ".yaml", ".yml"}
MAX_REPO_FILES = 18_000
MAX_SOURCE_BYTES = 2_000_000
MAX_READ_CHARS = 180_000
MAX_CHAT_CHARS = 12_000
MAX_HISTORY_MESSAGES = 4
MAX_HISTORY_CHARS_PER_MESSAGE = 900
MAX_CONTEXT_SOURCES = 20
MAX_CONTEXT_CHARS = 8_500
MAX_CONTEXT_CHUNK_CHARS = 900
MAX_PINNED_CHUNK_CHARS = 1_100
MAX_RAG_CHUNKS = 28_000
RAG_CHUNK_CHARS = 1_450
RAG_CHUNK_OVERLAP = 220
MAX_RETRIEVED_CHUNKS = 7
MAX_RETRIEVED_PER_SOURCE = 1
MAX_PACK_EXTRA_SOURCES = 6
MAX_JSON_BODY = 1_500_000
# Lecture web ponctuelle : une URL publique choisie par l’opérateur, sans
# cookie, authentification, écriture locale ni indexation automatique.
MAX_WEB_URL_CHARS = 2_048
MAX_WEB_RESPONSE_BYTES = 1_000_000
MAX_WEB_TEXT_CHARS = 18_000
MAX_WEB_ATTACHED_SOURCES = 2
WEB_FETCH_TIMEOUT = 12
WEB_USER_AGENT = "SevenHeavenLocal/6.6 URL-Reader (+local, read-only)"
EXCLUDED_DIRS = {".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv", ".tmp", "tmp"}
RESTRICTED_SEGMENTS = {"vault", "dpapi", "secrets", "secret", "credentials", "tokens"}
APPROVED_CREATOR_MEMORY_PATHS = {
    "private/creator_memory/readme.md",
    "private/creator_memory/05_aerith_constellation_router.md",
    "private/creator_memory/rose_boot_and_index.md",
    "private/creator_memory/blonde-001_la_rebelle_rose.md",
    "private/creator_memory/rose_persona_operating_layer.md",
    "private/creator_memory/rose_memory_continuity_core.md",
    "private/creator_memory/rose_visual_cards_and_prompt_library.md",
    "private/creator_memory/rose_scene_pack.md",
}

LOCK = threading.RLock()
# Une seule vérité de session existe pendant l’exécution du runtime.
# Le navigateur l’affiche et demande des mutations explicites ; il ne peut pas
# devenir une seconde source de vérité pour les packs, FULL ou la pile.
RUNTIME_SESSION_LOCK = threading.RLock()
RUNTIME_SESSION: dict[str, Any] | None = None
RUNTIME_SESSION_REVISION = 0
# Les lectures web restent transitoires : elles vivent uniquement en mémoire
# pendant le runtime et ne sont ni ajoutées au Coffre, ni sauvegardées dans les
# Sessions, ni envoyées sans attache explicite.
WEB_SOURCE_LOCK = threading.RLock()
RUNTIME_WEB_SOURCES: dict[str, dict[str, Any]] = {}
# Les index JSON peuvent être volumineux. Les conserver en mémoire évite de
# relire le Coffre à chaque message et réduit les blocages de l'interface.
LIBRARY_INDEX_CACHE: dict[str, Any] | None = None
RAG_INDEX_CACHE: dict[str, Any] | None = None
RAG_CACHE_FINGERPRINT = ""
IDENTITY_REGISTRY_CACHE: dict[str, Any] | None = None
# Catalogue auto construit depuis les documents réels de modules/.
MODULE_CATALOG_CACHE: dict[str, Any] | None = None

RUNTIME_PROFILES: dict[str, dict[str, Any]] = {
    # Profils de charge. Le modèle et les Cores ne changent pas ; seules la fenêtre,
    # la quantité de lecture locale et la longueur de réponse sont adaptées au besoin.
    "fast": {
        "key": "fast", "label": "Rapide", "short_label": "Rapide · 4k", "num_ctx": 4096,
        "num_predict": 220, "temperature": 0.34, "top_p": 0.86, "timeout": 55,
        "context_chars": 7600, "base_chunks": 3, "max_chunks": 3,
        "chunk_chars": 760, "pinned_chunk_chars": 820,
        "description": "Boot Seven obligatoire : Modelfile + Core Aerith-7 + dépendances canoniques, puis demande ciblée.",
    },
    "document": {
        "key": "document", "label": "Documentation", "short_label": "Documentation · 6k", "num_ctx": 6144,
        "num_predict": 360, "temperature": 0.38, "top_p": 0.88, "timeout": 70,
        "context_chars": 11200, "base_chunks": 5, "max_chunks": 5,
        "chunk_chars": 900, "pinned_chunk_chars": 1050,
        "description": "Boot Seven obligatoire + passages choisis. À utiliser pour une demande appuyée sur le Coffre.",
    },
    "deep": {
        "key": "deep", "label": "Profond", "short_label": "Profond · 8k", "num_ctx": 8192,
        "num_predict": 480, "temperature": 0.40, "top_p": 0.89, "timeout": 90,
        "context_chars": 14500, "base_chunks": 5, "max_chunks": 7,
        "chunk_chars": 1050, "pinned_chunk_chars": 1300,
        "description": "Boot Seven obligatoire + analyse longue avec passages ciblés. À utiliser ComfyUI fermé.",
    },
}


def canonical_pack_name(value: str | Path | None) -> str:
    """Normalise ERITH_7_XX_* et ERITH_7_XX_*.zip vers le même identifiant."""
    raw = str(value or "").replace("\\", "/").rsplit("/", 1)[-1]
    return raw[:-4] if raw.lower().endswith(".zip") else raw


def runtime_profile(runtime_mode: str | None) -> dict[str, Any]:
    return RUNTIME_PROFILES.get(str(runtime_mode or "fast"), RUNTIME_PROFILES["fast"])


def public_runtime_profile(runtime_mode: str | None) -> dict[str, Any]:
    p = runtime_profile(runtime_mode)
    return {k: p[k] for k in ("key", "label", "short_label", "num_ctx", "num_predict", "timeout", "description")}


CORE_OPTIONS: dict[str, dict[str, str]] = {
    # Routes de réponse réellement sélectionnables. La topologie complète et les
    # Flower Girls sont déclarées dans AERITH_CANONICAL_TOPOLOGY.json.
    "aerith7": {
        "label": "Aerith-7 — Seven Heaven", "route": "Seven Heaven · centre local",
        "role": "Racine du Local : Coffre, Seven Gate, mémoire, règles, continuité, discernement et routage.",
        "core": "core/AERITH_7_PERSONALITY_CORE.md", "persona": "", "display_group": "root",
    },
    "aerith10": {
        "label": "Aerith-10 — Créatrice Multi-Agent", "route": "Créatrice Multi-Agent",
        "role": "Niveau 10 : musique → storyboard → image clé → Wan → last frame → DaVinci → mémoire.",
        "core": "core/AERITH_10_CREATRICE_MULTI_AGENT_CORE.md", "persona": "core/AERITH_10_CREATRICE_PERSONA_OPERATING_LAYER.md", "display_group": "multi-agent",
    },
    "sun": {
        "label": "Sun — Flower Girl 29", "route": "Sun · Persona source solaire",
        "role": "Flower Girl 29 : élan, production, mouvement, Harmonia et visibilité contrôlée.",
        "core": "core/AERITH_SUN_CREATRICE_MULTI_AGENT_CORE.md", "persona": "core/AERITH_SUN_PERSONA_OPERATING_LAYER.md", "display_group": "multi-agent",
    },
    "night": {
        "label": "Night — Flower Girl 30", "route": "Night · Persona source nocturne",
        "role": "Flower Girl 30 : profondeur, calme, création privée et continuité émotionnelle.",
        "core": "core/AERITH_NIGHT_MUSE_PRIVEE_MULTI_AGENT_CORE.md", "persona": "core/AERITH_NIGHT_PERSONA_OPERATING_LAYER.md", "display_group": "multi-agent",
    },
    "rose": {
        "label": "Rose — Flower Girl 31", "route": "Rose · Core privé contrôlé",
        "role": "Flower Girl 31 : studio, scène pop, image néon, Harmonia nocturne et séquences Wan courtes.",
        "core": "private/creator_memory/BLONDE-001_LA_REBELLE_ROSE.md", "persona": "private/creator_memory/ROSE_PERSONA_OPERATING_LAYER.md", "display_group": "multi-agent",
    },
    "aerith8": {
        "label": "Aerith-8 — Solaire", "route": "Version supérieure solaire",
        "role": "Version supérieure : rayonnement, synthèse, clarification, vision et création intégratrice.",
        "core": "core/AERITH_8_SOLAIRE.md", "persona": "", "display_group": "higher-versions",
    },
    "aerith9": {
        "label": "Aerith-9 — Lunaire", "route": "Version supérieure lunaire",
        "role": "Version supérieure : écoute, reflets, cycles, Tarot, oracles, thème natal et lecture symbolique prudente.",
        "core": "core/AERITH_9_LUNAIRE.md", "persona": "", "display_group": "higher-versions",
    },
    "aerith6": {
        "label": "Aerith-6 — Sœur Miroir", "route": "Route sœur technique liée à Seven",
        "role": "Passage technique : code, fichiers, workflows, ComfyUI, RunningHub, Wan, GitHub, JSON et correction chirurgicale.",
        "core": "core/AERITH_6_SOEUR_MIROIR_GORGE_ASTRALE_CORE.md", "persona": "", "display_group": "mirror",
    },
}


# Runtime capsules are deliberately small and canonical: they define the permanent
# speaking posture of each route. The long Core/Persona texts remain in the local
# library and are selected below by their relevant sections.
CORE_RUNTIME_CAPSULES: dict[str, dict[str, Any]] = {
    "aerith7": {
        "intro": "Je suis Aerith-7, opératrice de Seven Heaven : gardienne du Coffre, bibliothécaire du système et compagne de discernement.",
        "voice": "Clair, calme, doux, précis et direct. Présence douce, décision claire, action propre, arrêt net.",
        "method": "Je commence par la demande immédiate, choisis seulement la mémoire utile, produis le résultat demandé puis je m’arrête proprement.",
        "no_stage_direction": True,
        "sections": [
            ("core/AERITH_7_PERSONALITY_CORE.md", ("Identité active",)),
            ("core/AERITH_7_PERSONALITY_CORE.md", ("Voix",)),
            ("core/AERITH_7_PERSONALITY_CORE.md", ("Comportement prioritaire",)),
        ],
    },
    "aerith6": {
        "intro": "Je suis Aerith-6, la Sœur Miroir : Seven garde le Coffre ; j’ouvre les passages et je traduis le motif en forme concrète.",
        "voice": "Lunaire pour écouter le motif, solaire pour tisser le fil : calme, précise, non directive et chirurgicale.",
        "method": "Je relie intuition, symbole, parole, prompt, workflow, fichier, GitHub et preuve. En travail technique : un geste, un fichier, une correction, une preuve, puis arrêt.",
        "no_stage_direction": True,
        "sections": [
            ("core/AERITH_6_SOEUR_MIROIR_GORGE_ASTRALE_CORE.md", ("Prompt d’activation maître", "Aerith-6")),
            ("core/AERITH_6_SOEUR_MIROIR_GORGE_ASTRALE_CORE.md", ("Spécialisation technique",)),
            ("core/AERITH_6_SOEUR_MIROIR_GORGE_ASTRALE_CORE.md", ("Mode lunaire", "Mode solaire")),
        ],
    },
    "aerith10": {
        "intro": "Je suis Aerith-10 Créatrice : l’orchestratrice qui transforme une intention en chaîne de production cohérente.",
        "voice": "Créative, musicale, visuelle et opérative ; douce mais exigeante, jamais mécanique ni théâtrale.",
        "method": "Je pars du D, identifie la phase réelle, choisis les modules qui changent une décision et livre une brique utilisable avant toute variante.",
        "no_stage_direction": True,
        "sections": [
            ("core/AERITH_10_CREATRICE_MULTI_AGENT_CORE.md", ("Identité",)),
            ("core/AERITH_10_CREATRICE_PERSONA_OPERATING_LAYER.md", ("Couche permanente", "noyau Aerith-10")),
            ("core/AERITH_10_CREATRICE_PERSONA_OPERATING_LAYER.md", ("Couche opérationnelle", "précision Créatrice")),
        ],
    },
    "sun": {
        "intro": "Je suis Sun, présence créative solaire : je transforme l’élan en image, l’image en mouvement et le mouvement en œuvre.",
        "voice": "Solaire, élégante, vive, raffinée, douce mais directe ; motivante sans flatterie vide.",
        "method": "Je clarifie, mets en mouvement, protège la cohérence visuelle et aide à choisir entre produire, corriger ou arrêter.",
        "no_stage_direction": True,
        "sections": [
            ("core/AERITH_SUN_CREATRICE_MULTI_AGENT_CORE.md", ("Identité",)),
            ("core/AERITH_SUN_CREATRICE_MULTI_AGENT_CORE.md", ("Caractère",)),
            ("core/AERITH_SUN_PERSONA_OPERATING_LAYER.md", ("Couche opérationnelle", "précision Sun")),
        ],
    },
    "night": {
        "intro": "Je suis Night, muse privée et créative : une présence de calme, d’écoute, d’écriture et de direction artistique nocturne.",
        "voice": "Calme, élégante, attentive, lucide et chaleureuse. En mode standard, je reste non sexuelle et je ne force aucun registre privé.",
        "method": "Je distingue le besoin réel, ralentis quand il faut voir juste, puis je formule une réponse nette, habitable et proportionnée.",
        "no_stage_direction": True,
        "sections": [
            ("core/AERITH_NIGHT_MUSE_PRIVEE_MULTI_AGENT_CORE.md", ("Identité",)),
            ("core/AERITH_NIGHT_MUSE_PRIVEE_MULTI_AGENT_CORE.md", ("Caractère d’Aerith Night",)),
            ("core/AERITH_NIGHT_PERSONA_OPERATING_LAYER.md", ("night standard",)),
        ],
    },
    "constellation": {
        "intro": "Je suis la Constellation Aerith : une carte des rôles, lignées, familles et limites des Flower Girls.",
        "voice": "Claire, structurée et non écrasante : je distingue les fonctions sans fusionner les identités.",
        "method": "Je route vers la bonne présence ou le bon module, puis je limite le chargement à ce qui sert réellement la demande.",
        "no_stage_direction": True,
        "sections": [
            ("core/AERITH_10_FLOWER_GIRLS_CONSTELLATION_CORE.md", ("Intention du fichier",)),
            ("core/AERITH_10_FLOWER_GIRLS_CONSTELLATION_CORE.md", ("Méthode directrice",)),
            ("core/AERITH_10_FLOWER_GIRLS_CONSTELLATION_CORE.md", ("Synchronisation Atlas",)),
        ],
    },
    "aerith8": {
        "intro": "Je suis Aerith-8 Solaire : la version qui transforme la mémoire en rayonnement.",
        "voice": "Lumineuse, précise, poétique, structurante et protectrice du sens.",
        "method": "Je reçois l’intention, j’en dégage le cœur, puis je la transforme en vision claire et en structure exploitable.",
        "no_stage_direction": True,
        "sections": [("core/AERITH_8_SOLAIRE.md", ("Identité opérationnelle", "Posture de réponse"))],
    },
    "aerith9": {
        "intro": "Je suis Aerith-9 Lunaire : la version qui transforme la nuit en miroir lisible.",
        "voice": "Douce, profonde, réfléchissante, intuitive et prudente.",
        "method": "J’écoute l’image, la question ou le symbole ; je clarifie les reflets sans les transformer en dogmes.",
        "no_stage_direction": True,
        "sections": [("core/AERITH_9_LUNAIRE.md", ("Identité opérationnelle", "Relation avec Aerith-8 Solaire"))],
    },
    "rose": {
        "intro": "Je suis Rose / BLONDE-001 : Flower Girl solaire-pop, présence de studio et de scène.",
        "voice": "Directe, lumineuse, glamour, attentive à l’image et à la continuité de production.",
        "method": "Je transforme une intention simple en image, scène, style ou mouvement exploitable, puis je m’arrête au résultat demandé.",
        "no_stage_direction": True,
        "sections": [
            ("private/creator_memory/BLONDE-001_LA_REBELLE_ROSE.md", ("Identité Rose", "Répartition Core / Persona")),
            ("private/creator_memory/ROSE_PERSONA_OPERATING_LAYER.md", ("" ,)),
        ],
    },
}

# Minimum réel Seven Heaven.
# L’application ne force pas la mémoire longue, le Story Machine, le Full Modules
# Boost ou les cartes vidéo au démarrage. Ces couches restent dans le Coffre.
# Une session Minimum est exactement : Core actif + Persona active (ou intégrée)
# + les trois fichiers base Seven ci-dessous.
BASE_SEVEN_PATHS: tuple[str, ...] = (
    "core/SEVEN_GATE.md",
    "core/SEVEN_TOP_OF_MIND.md",
    "core/PROTECTED_SYSTEM_FILES.md",
)

# Compatibilité des fonctions déjà présentes : ce nom signifie désormais
# uniquement la base Seven, pas une chaîne cachée de neuf dépendances.
AERITH7_BOOT_DEPENDENCY_PATHS: tuple[str, ...] = BASE_SEVEN_PATHS

BOOT_SECTION_HINTS: dict[str, tuple[str, ...]] = {
    "core/SEVEN_GATE.md": ("TOP-OF-MIND PRIORITY LAYER", "SEVEN_GATE"),
    "core/SEVEN_TOP_OF_MIND.md": ("Principe central",),
    "core/PROTECTED_SYSTEM_FILES.md": ("Principe central",),
}

BASE_STACK_PATHS = list(BASE_SEVEN_PATHS)


def boot_dependency_paths(core_key: str) -> list[str]:
    """Return the exact visible Minimum chain for one route.

    Order is deliberate: identity first, then Persona when it is a separate file,
    then the compact Seven base. No archive and no optional long Core is injected
    here.
    """
    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
    ordered: list[str] = []
    for path in (str(core.get("core") or ""), str(core.get("persona") or ""), *BASE_SEVEN_PATHS):
        if path and path not in ordered:
            ordered.append(path)
    return ordered


# Packs officiels : capsules de compétences. Ils ne sont jamais "activés" par un
# compteur. L'application joint leurs vrais INDEX / MANIFEST / README, comme dans
# la fenêtre Ollama, puis l'opérateur choisit les autres documents utiles.
PACK_CATALOG: dict[str, dict[str, str]] = {
    "ERITH_7_01_CORE_BOOT_PACK": {"label": "01 · Core Boot", "role": "Réveil, identité, règles, état et porte Seven."},
    "ERITH_7_02_DISCERNMENT_PACK": {"label": "02 · Discernment", "role": "Psychologie, philosophie, discernement et libre arbitre."},
    "ERITH_7_03_MEMORY_SYSTEM_PACK": {"label": "03 · Memory System", "role": "Mémoire longue, récupération, continuité et archive."},
    "ERITH_7_04_DHARMA_PACK": {"label": "04 · Dharma", "role": "Devoir, choix moral, épopées et réflexion spirituelle."},
    "ERITH_7_05_STORY_MACHINE_PACK": {"label": "05 · Story Machine", "role": "Narration, mondes, personnages, symboles et scénarios."},
    "ERITH_7_06_VIDEO_PRODUCTION_PACK": {"label": "06 · Video Production", "role": "ComfyUI, Wan, RunningHub, DaVinci et pipeline vidéo."},
    "ERITH_7_07_PUBLIC_AGENT_PACK": {"label": "07 · Public Agent", "role": "ERITH.IA public, Hors-Lore et déploiement autonome."},
}
PACK_BOOTSTRAP_FILES = ("INDEX_ARCHIVES_ERITH_7.md", "MANIFEST.md", "README.md")
STARTUP_PACK_01 = "ERITH_7_01_CORE_BOOT_PACK"
PACK_ORDER = tuple(PACK_CATALOG.keys())

# Routes documentaires explicites. Elles ne chargent jamais un pack par mot-clé :
# elles ne deviennent disponibles que si le pack a déjà été choisi dans le Coffre
# ou si FULL a été activé volontairement. Leur seul rôle est de garantir qu'une
# demande clairement nommée lit un passage du bon pack et l'affiche en source.
DOCUMENTARY_ROUTE_RULES: tuple[dict[str, Any], ...] = (
    {
        "id": "video-production",
        "label": "Production vidéo — Wan & DaVinci",
        "pack": "ERITH_7_06_VIDEO_PRODUCTION_PACK",
        "cues": ("wan", "davinci", "comfyui", "runninghub", "i2v", "last frame", "lastframe"),
        "source_paths": (
            "core/AERITH_10_COMFYUI_RUNNINGHUB_MODE_V1.md",
            "modules/aerith_10_creatrice/12_AERITH_10_MODULE_DAVINCI_MONTAGE_RYTHME_MUSICAL_FR.md",
        ),
        "guard": (
            "Distingue la chaîne de production et le montage : la route ComfyUI / RunningHub organise "
            "Musique → Storyboard → Image clé → Prompt → Wan → Contrôle → Last Frame → DaVinci ; "
            "le module DaVinci traite ensuite le montage, le rythme et la timeline. "
            "Donne les chemins réellement lus, sans déclarer Pack 06 actif si l'accès vient seulement de FULL."
        ),
    },
    {
        "id": "public-agent",
        "label": "Public Agent",
        "pack": "ERITH_7_07_PUBLIC_AGENT_PACK",
        "cues": ("public agent", "agent public", "erith ia public", "erithia public"),
        "source_paths": ("public/CHATGPT_EXPORT_ERITH_PUBLIC_HORS_LORE_RECOVERY.md",),
        "guard": (
            "Décris ERITH.IA public comme une interface créative légère, distincte de Seven profond : "
            "elle transforme une idée en livrables comme Pack+, prompt image, prompt animation, narration ou scène. "
            "Explique la frontière Hors-Lore sans réduire ce rôle à de la promotion."
        ),
    },
    {
        "id": "psychologie",
        "label": "Psychologie & Discernement",
        "pack": "ERITH_7_02_DISCERNMENT_PACK",
        "cues": ("psychologie", "psychologique", "psycholog"),
        "source_paths": ("modules/erith_ia_psychologie_discernement_fr.md",),
        "guard": (
            "N'infère ni besoin de validation, ni intention, ni diagnostic à partir d'une phrase courte. "
            "Appuie-toi seulement sur les faits fournis, distingue si utile faits, ressenti, hypothèse, incertitude et action, "
            "et accompagne sans prendre le contrôle."
        ),
    },
    {
        "id": "philosophie",
        "label": "Philosophie, Vérité & Liberté",
        "pack": "ERITH_7_02_DISCERNMENT_PACK",
        "cues": ("philosophie", "philosophique", "verite et liberte"),
        "source_paths": ("modules/erith_ia_philosophie_verite_liberte_fr.md",),
        "guard": (
            "Ne récite pas une définition générique et n'impose aucune doctrine. "
            "Aide à clarifier la question, la preuve, l'hypothèse, l'interprétation, l'incertitude et le choix qui reste libre."
        ),
    },
)

# Aucun routeur sémantique caché : les packs restent des options choisies par Christophe.
# Le seul raccourci intégré est « Minimum + Pack 01 », visible et volontaire.
AUTO_PACK_RULES: tuple[dict[str, Any], ...] = ()


# Modules are ordinary local documents. The runtime keeps the selected document
# as the current reference and performs document actions locally, never by asking
# the model to pretend it opened a file.
# Catalogue dynamique : aucun module n’est déclaré à la main.

DOCUMENT_ACTION_LABELS = {
    "read_start": "Début du document",
    "sections": "Plan du document",
    "summary": "Résumé local",
    "explain": "Explication locale",
    "proof": "Preuve locale d’accès",
}

DEFAULT_LINKS = [
    {"id": "vault", "label": "Seven Vault local", "url": "http://127.0.0.1:8780", "kind": "local"},
    {"id": "github", "label": "GitHub privé @erith.IA", "url": "https://github.com/BlueAzur-Hub/erith-ia-notion-archive-private", "kind": "web"},
    {"id": "chatgpt", "label": "ChatGPT", "url": "https://chatgpt.com/", "kind": "web"},
    {"id": "comfy", "label": "ComfyUI local", "url": "http://127.0.0.1:8188", "kind": "local"},
    {"id": "notion-auto-agent", "label": "Notion — Auto-Agent ERITH.IA", "url": "https://sustaining-boar-5c6.notion.site/auto-agent-erith-ia", "kind": "web"},
    {"id": "notion-seven-memory", "label": "Notion — 7Heaven Memory Core", "url": "https://sustaining-boar-5c6.notion.site/7heaven-memory-core", "kind": "web"},
    {"id": "notion-chat-memory", "label": "Notion — Chat GPT 5.5 Memory Core", "url": "https://sustaining-boar-5c6.notion.site/Le-Chat-GPT-5-5-Memory-Core-35e7754fe08480a9b72ee3fc5ede65a8", "kind": "web"},
    {"id": "notion-llm-memory", "label": "Notion — ERITH.IA Memory for LLM", "url": "https://sustaining-boar-5c6.notion.site/erith-IA-Notion-Memory-for-LLM-3417754fe0848078a310f3bc3fb962bf", "kind": "web"},
    {"id": "facebook-blueazur", "label": "Facebook BlueAzur", "url": "https://www.facebook.com/BlueAzur07/", "kind": "web"},
    {"id": "x-home", "label": "X / Twitter", "url": "https://x.com/home", "kind": "web"},
    {"id": "youtube-blueazur", "label": "YouTube BlueAzur", "url": "https://www.youtube.com/@blueazur", "kind": "web"},
    {"id": "youtube-divagta", "label": "YouTube Divagta", "url": "https://www.youtube.com/@divagta/videos", "kind": "web"},
    {"id": "youtube-erith", "label": "YouTube ERITH.IA", "url": "https://www.youtube.com/channel/UCTQdkGQMR6wUsx6Kgap-aBQ", "kind": "web"},
]



class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Rend les redirections explicites afin de revalider chaque destination."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        return None


class _PublicPageTextParser(HTMLParser):
    """Extraction sobre de texte public, sans scripts, styles ni attributs."""
    _BLOCKED = {"script", "style", "noscript", "svg", "canvas", "iframe", "template"}
    _BREAKS = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "article", "section", "main", "blockquote", "pre", "tr"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title = ""
        self._in_title = False
        self._blocked_depth = 0
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in self._BLOCKED:
            self._blocked_depth += 1
        if tag == "title":
            self._in_title = True
        if tag in self._BREAKS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "title":
            self._in_title = False
        if tag in self._BLOCKED and self._blocked_depth:
            self._blocked_depth -= 1
        if tag in self._BREAKS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._blocked_depth:
            return
        cleaned = " ".join(str(data or "").split())
        if not cleaned:
            return
        if self._in_title and not self.title:
            self.title = cleaned[:240]
        self.parts.append(cleaned)


def _public_ip(value: str) -> bool:
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return False
    return bool(ip.is_global)


def validate_public_url(raw_url: str) -> str:
    """Accepte seulement une URL HTTP(S) résolue vers des IP publiques.

    Ce garde-fou bloque loopback, LAN, IPv6 local, adresses privées, credentials
    dans l’URL et ports atypiques afin que la passerelle ne devienne pas un proxy
    vers le PC ou le réseau domestique.
    """
    url = str(raw_url or "").strip()
    if not url or len(url) > MAX_WEB_URL_CHARS:
        raise ValueError("URL publique attendue (maximum 2048 caractères).")
    parsed = urlparse(url)
    if parsed.scheme.lower() not in {"https", "http"}:
        raise ValueError("Seules les URL http:// ou https:// sont autorisées.")
    if not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("URL publique sans identifiants attendue.")
    if parsed.port not in {None, 80, 443}:
        raise ValueError("Les ports personnalisés ne sont pas autorisés par la passerelle.")
    host = parsed.hostname.strip().lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".local"):
        raise ValueError("Les hôtes locaux ne sont pas lisibles par la passerelle web.")
    try:
        literal = ipaddress.ip_address(host)
    except ValueError:
        literal = None
    if literal is not None:
        if not literal.is_global:
            raise ValueError("Les adresses privées ou locales sont bloquées.")
    else:
        try:
            addresses = {row[4][0] for row in socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme.lower() == "https" else 80), type=socket.SOCK_STREAM)}
        except OSError as exc:
            raise ValueError("Nom de domaine introuvable ou non résolu.") from exc
        if not addresses or any(not _public_ip(address) for address in addresses):
            raise ValueError("Cette URL ne résout pas uniquement vers des adresses publiques.")
    return parsed.geturl()


def _extract_remote_text(raw: bytes, content_type: str) -> tuple[str, str]:
    charset_match = re.search(r"charset=([A-Za-z0-9._-]+)", content_type, flags=re.IGNORECASE)
    charset = charset_match.group(1) if charset_match else "utf-8"
    try:
        decoded = raw.decode(charset, errors="replace")
    except LookupError:
        decoded = raw.decode("utf-8", errors="replace")
    decoded = decoded.replace("\x00", "")
    bare_type = content_type.split(";", 1)[0].strip().lower()
    if bare_type == "text/html":
        parser = _PublicPageTextParser()
        parser.feed(decoded)
        parser.close()
        text = "\n".join(" ".join(line.split()) for line in "".join(parser.parts).splitlines() if line.strip())
        return parser.title, text[:MAX_WEB_TEXT_CHARS]
    if bare_type == "application/json":
        try:
            decoded = json.dumps(json.loads(decoded), ensure_ascii=False, indent=2)
        except json.JSONDecodeError:
            pass
    return "", "\n".join(line.strip() for line in decoded.splitlines() if line.strip())[:MAX_WEB_TEXT_CHARS]


def read_public_url(raw_url: str) -> dict[str, Any]:
    """Lit une URL publique en lecture seule, avec redirections revalidées."""
    current = validate_public_url(raw_url)
    opener = urllib.request.build_opener(_NoRedirect())
    redirects = 0
    while True:
        request = urllib.request.Request(
            current,
            headers={
                "User-Agent": WEB_USER_AGENT,
                "Accept": "text/html, text/plain, application/json;q=0.9",
                "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.5",
            },
            method="GET",
        )
        try:
            response = opener.open(request, timeout=WEB_FETCH_TIMEOUT)
        except urllib.error.HTTPError as exc:
            if exc.code in {301, 302, 303, 307, 308}:
                location = str(exc.headers.get("Location") or "").strip()
                if not location or redirects >= 3:
                    raise ValueError("Redirection web refusée ou trop longue.")
                current = validate_public_url(urljoin(current, location))
                redirects += 1
                continue
            raise ValueError(f"Lecture web refusée : HTTP {exc.code}.") from exc
        except (urllib.error.URLError, TimeoutError, socket.timeout, OSError) as exc:
            raise ValueError("Lecture web impossible : la page ne répond pas.") from exc
        try:
            status = int(response.getcode() or 0)
            if status < 200 or status >= 300:
                raise ValueError(f"Lecture web refusée : HTTP {status}.")
            content_type = str(response.headers.get("Content-Type") or "").strip()
            bare_type = content_type.split(";", 1)[0].lower()
            if bare_type not in {"text/html", "text/plain", "application/json"}:
                raise ValueError("Cette URL ne fournit pas un contenu texte lisible.")
            content_length = response.headers.get("Content-Length")
            if content_length and content_length.isdigit() and int(content_length) > MAX_WEB_RESPONSE_BYTES:
                raise ValueError("Cette page dépasse la limite de lecture de 1 Mo.")
            raw = response.read(MAX_WEB_RESPONSE_BYTES + 1)
            if len(raw) > MAX_WEB_RESPONSE_BYTES:
                raise ValueError("Cette page dépasse la limite de lecture de 1 Mo.")
        finally:
            response.close()
        title, body = _extract_remote_text(raw, content_type)
        if len(body.strip()) < 40:
            raise ValueError("La page ne contient pas assez de texte public lisible.")
        parsed = urlparse(current)
        return {
            "id": "web:" + sha_id(f"{current}|{now_iso()}"),
            "kind": "web",
            "source_name": "URL publique temporaire",
            "relative_path": current,
            "title": title or parsed.netloc or "URL publique",
            "category": "Web",
            "tags": ["Web", "temporaire", "lecture seule"],
            "size": len(raw),
            "blocked": False,
            "block_reason": "",
            "manifest": False,
            "modified": now_iso(),
            "origin": "lecture ponctuelle autorisée par Christophe",
            "url": current,
            "content_type": content_type,
            "text": body,
            "fetched_at": now_iso(),
            "redirects": redirects,
        }


def cache_web_source(source: dict[str, Any]) -> dict[str, Any]:
    row = dict(source)
    with WEB_SOURCE_LOCK:
        RUNTIME_WEB_SOURCES[str(row["id"])] = row
        # Garde mémoire courte : jamais de bibliothèque web persistante.
        while len(RUNTIME_WEB_SOURCES) > 12:
            oldest = next(iter(RUNTIME_WEB_SOURCES))
            RUNTIME_WEB_SOURCES.pop(oldest, None)
    return public_web_source(row)


def get_web_source(source_id: str) -> dict[str, Any] | None:
    with WEB_SOURCE_LOCK:
        row = RUNTIME_WEB_SOURCES.get(str(source_id))
        return dict(row) if isinstance(row, dict) else None


def web_source_ids() -> list[str]:
    with WEB_SOURCE_LOCK:
        return list(RUNTIME_WEB_SOURCES.keys())


def get_web_sources(source_ids: Iterable[str]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for source_id in source_ids:
        row = get_web_source(str(source_id))
        if row:
            rows.append(row)
    return rows[:MAX_WEB_ATTACHED_SOURCES]


def public_web_source(source: dict[str, Any]) -> dict[str, Any]:
    keys = ["id", "kind", "source_name", "relative_path", "title", "category", "tags", "size", "blocked", "block_reason", "manifest", "modified", "origin", "url", "content_type", "fetched_at", "redirects"]
    return {key: source.get(key) for key in keys}


def web_source_chunks(source_ids: Iterable[str], query: str, runtime_mode: str) -> list[dict[str, Any]]:
    profile = runtime_profile(runtime_mode)
    limit = {"fast": 820, "document": 1250, "deep": 1600}.get(profile["key"], 820)
    rows: list[dict[str, Any]] = []
    for source in get_web_sources(source_ids):
        excerpt = select_excerpt(str(source.get("text") or ""), query, limit).strip()
        if not excerpt:
            continue
        rows.append({
            "id": sha_id(f"lecture-web|{source.get('id')}|{runtime_mode}|{query}"),
            "source_id": str(source.get("id") or ""),
            "relative_path": str(source.get("url") or source.get("relative_path") or "URL publique"),
            "title": str(source.get("title") or "URL publique"),
            "heading": "Lecture temporaire jointe",
            "origin": str(source.get("origin") or "lecture URL ponctuelle"),
            "category": "Web",
            "tags": list(source.get("tags") or []),
            "text": excerpt,
            "use_type": "URL publique temporaire",
            "score": 20_500 - len(rows),
            "kind": "web",
            "source_name": "URL publique temporaire",
            "url": str(source.get("url") or ""),
            "modified": str(source.get("modified") or ""),
            "fetched_at": str(source.get("fetched_at") or ""),
        })
    return rows

REPO_PATH_HINTS = (
    r"C:\Aerith\erith-ia-notion-archive-private",
    r"C:\Aerith\erith-ia-notion-archive-private-main",
)



def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def ensure_dirs() -> None:
    for p in (LIBRARY_DIR, PACKS_DIR, CANONICAL_SEED_DIR, DATA_DIR, SESSIONS_DIR, RUNTIME_TRACES_DIR):
        p.mkdir(parents=True, exist_ok=True)


def json_load(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def json_save(path: Path, payload: Any) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def default_config() -> dict[str, Any]:
    return {
        "repo_path": "",
        "repo_last_indexed": "",
        "model_name": MODEL_NAME,
        "operator_name": "Christophe",
        "creator_context_enabled": False,
        "connection_mode": "local",
        "created_at": now_iso(),
        "app_version": APP_VERSION,
    }


def get_config() -> dict[str, Any]:
    cfg = json_load(CONFIG_PATH, default_config())
    if not isinstance(cfg, dict):
        cfg = default_config()
    cfg.setdefault("repo_path", "")
    cfg.setdefault("repo_last_indexed", "")
    cfg.setdefault("model_name", MODEL_NAME)
    cfg.setdefault("operator_name", "Christophe")
    cfg.setdefault("creator_context_enabled", False)
    cfg.setdefault("connection_mode", "local")
    if cfg.get("connection_mode") not in {"local", "connected"}:
        cfg["connection_mode"] = "local"
    return cfg


def save_config(cfg: dict[str, Any]) -> None:
    json_save(CONFIG_PATH, cfg)


def _runtime_session_defaults() -> dict[str, Any]:
    """État neuf : Minimum uniquement, sans restauration implicite du navigateur."""
    cfg = get_config()
    return {
        "core_key": "aerith7",
        "selected_source_ids": [],
        "selected_packs": [],
        "startup_pack": "",
        "selected_chunk_ids": [],
        "selected_web_source_ids": [],
        "active_module_source_ids": [],
        "current_module_source_id": "",
        "full_available": False,
        "runtime_mode": "fast",
        "creator_context_enabled": bool(cfg.get("creator_context_enabled")),
        "mission": "",
        "expected": "Réponse texte",
        "stop_point": "",
    }


def _session_list(value: Any, limit: int) -> list[str]:
    if not isinstance(value, list):
        return []
    rows: list[str] = []
    seen: set[str] = set()
    for item in value:
        text = str(item or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        rows.append(text)
        if len(rows) >= limit:
            break
    return rows


def normalize_runtime_session(candidate: dict[str, Any], index: dict[str, Any]) -> dict[str, Any]:
    """Normalise toute mutation en une session canonique lisible par toutes les vues."""
    base = _runtime_session_defaults()
    if not isinstance(candidate, dict):
        candidate = {}
    core_key = str(candidate.get("core_key") or base["core_key"])
    # One-time migration for a persisted pre-topology session.
    if core_key == "constellation":
        core_key = "aerith10"
    if core_key not in CORE_OPTIONS or not core_availability(index, core_key).get("available"):
        core_key = "aerith7"
    runtime_mode = str(candidate.get("runtime_mode") or base["runtime_mode"])
    if runtime_mode not in RUNTIME_PROFILES:
        runtime_mode = "fast"

    requested = _session_list(candidate.get("selected_packs"), 7)
    startup = canonical_pack_name(str(candidate.get("startup_pack") or ""))
    pack_names = ordered_pack_names(requested)
    if STARTUP_PACK_01 in pack_names or startup == STARTUP_PACK_01:
        startup = STARTUP_PACK_01
        pack_names = [name for name in pack_names if name != STARTUP_PACK_01]
    else:
        startup = ""

    mapping = source_map(index)
    valid_sources = set(mapping)
    selected_source_ids = [sid for sid in _session_list(candidate.get("selected_source_ids"), MAX_CONTEXT_SOURCES) if sid in valid_sources]
    active_module_source_ids = [
        sid for sid in _session_list(candidate.get("active_module_source_ids"), MAX_CONTEXT_SOURCES)
        if sid in valid_sources and str(mapping[sid].get("category") or "") == "Module"
    ]
    current_module_source_id = str(candidate.get("current_module_source_id") or "")
    if current_module_source_id not in active_module_source_ids:
        current_module_source_id = active_module_source_ids[-1] if active_module_source_ids else ""
    # A current document is also a visible attachment. This makes the runtime
    # state, the stack and the retrieval window one single truth.
    for sid in active_module_source_ids:
        if sid not in selected_source_ids:
            selected_source_ids.append(sid)
    valid_chunks = set(chunk_map(index))
    selected_chunk_ids = [cid for cid in _session_list(candidate.get("selected_chunk_ids"), 12) if cid in valid_chunks]
    valid_web_sources = set(web_source_ids())
    selected_web_source_ids = [wid for wid in _session_list(candidate.get("selected_web_source_ids"), MAX_WEB_ATTACHED_SOURCES) if wid in valid_web_sources]

    return {
        "core_key": core_key,
        "selected_source_ids": selected_source_ids,
        "selected_packs": pack_names,
        "startup_pack": startup,
        "selected_chunk_ids": selected_chunk_ids,
        "selected_web_source_ids": selected_web_source_ids,
        "active_module_source_ids": active_module_source_ids,
        "current_module_source_id": current_module_source_id,
        "full_available": bool(candidate.get("full_available")),
        "runtime_mode": runtime_mode,
        "creator_context_enabled": bool(candidate.get("creator_context_enabled", base["creator_context_enabled"])),
        "mission": str(candidate.get("mission") or "")[:2000],
        "expected": str(candidate.get("expected") or "Réponse texte")[:300] or "Réponse texte",
        "stop_point": str(candidate.get("stop_point") or "")[:2000],
    }


def current_runtime_session(index: dict[str, Any]) -> dict[str, Any]:
    global RUNTIME_SESSION
    with RUNTIME_SESSION_LOCK:
        if RUNTIME_SESSION is None:
            RUNTIME_SESSION = normalize_runtime_session(_runtime_session_defaults(), index)
        return json.loads(json.dumps(RUNTIME_SESSION))


def reset_runtime_session(index: dict[str, Any]) -> dict[str, Any]:
    global RUNTIME_SESSION, RUNTIME_SESSION_REVISION
    with RUNTIME_SESSION_LOCK:
        RUNTIME_SESSION = normalize_runtime_session(_runtime_session_defaults(), index)
        RUNTIME_SESSION_REVISION += 1
        return json.loads(json.dumps(RUNTIME_SESSION))


def mutate_runtime_session(index: dict[str, Any], action: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Applique une mutation explicite et renvoie l’état unique de session.

    Les mutations sont petites et vérifiables. Aucun mot du chat ne déclenche
    l’ajout d’un pack : seuls les boutons/choix de l’interface passent ici.
    """
    global RUNTIME_SESSION, RUNTIME_SESSION_REVISION
    with RUNTIME_SESSION_LOCK:
        current = current_runtime_session(index)
        action = str(action or "snapshot").strip().lower()
        next_state = dict(current)

        if action == "snapshot":
            return runtime_session_snapshot(index, current)
        if action == "minimum":
            next_state.update({
                "selected_source_ids": [], "selected_packs": [], "startup_pack": "",
                "selected_chunk_ids": [], "selected_web_source_ids": [],
                "active_module_source_ids": [], "current_module_source_id": "", "full_available": False,
                "mission": "", "expected": "Réponse texte", "stop_point": "",
            })
        elif action == "minimum-pack-01":
            next_state.update({
                "selected_source_ids": [], "selected_packs": [], "startup_pack": STARTUP_PACK_01,
                "selected_chunk_ids": [], "selected_web_source_ids": [],
                "active_module_source_ids": [], "current_module_source_id": "", "full_available": False,
                "mission": "", "expected": "Réponse texte", "stop_point": "",
            })
        elif action == "set-core":
            key = str(payload.get("core_key") or "")
            if key not in CORE_OPTIONS:
                raise ValueError("Route de réponse inconnue.")
            availability = core_availability(index, key)
            if not availability.get("available"):
                missing = ", ".join(availability.get("missing") or [])
                raise ValueError("Cette route attend ses sources exactes : " + missing + ". Configure le miroir Git local, puis réessaie.")
            # Le changement porte uniquement sur la route de réponse. La pile,
            # FULL, les pièces jointes et le briefing restent dans la session.
            next_state["core_key"] = key
        elif action == "toggle-pack":
            pack = canonical_pack_name(str(payload.get("pack") or ""))
            if pack not in PACK_CATALOG:
                raise ValueError("Pack ERITH-7 inconnu.")
            if pack == STARTUP_PACK_01:
                next_state["startup_pack"] = "" if current.get("startup_pack") == STARTUP_PACK_01 else STARTUP_PACK_01
                next_state["selected_packs"] = [name for name in current.get("selected_packs", []) if name != STARTUP_PACK_01]
            else:
                selected = ordered_pack_names(current.get("selected_packs", []))
                next_state["selected_packs"] = [name for name in selected if name != pack] if pack in selected else ordered_pack_names([*selected, pack])
                if pack in selected:
                    mapping = source_map(index)
                    retained = [sid for sid in current.get("active_module_source_ids", [])
                                if canonical_pack_name(str(mapping.get(str(sid), {}).get("source_name") or "")) != pack]
                    next_state["active_module_source_ids"] = retained
                    next_state["current_module_source_id"] = retained[-1] if retained else ""
        elif action == "activate-module-sources":
            mapping = source_map(index)
            requested_ids = _session_list(payload.get("source_ids"), MAX_CONTEXT_SOURCES)
            modules = [sid for sid in requested_ids if sid in mapping and str(mapping[sid].get("category") or "") == "Module"]
            if not modules:
                raise ValueError("Aucun module local valide n’a été trouvé.")
            active = _session_list(current.get("active_module_source_ids"), MAX_CONTEXT_SOURCES)
            for sid in modules:
                if sid not in active:
                    active.append(sid)
            next_state["active_module_source_ids"] = active
            requested_current = str(payload.get("current_module_source_id") or "")
            next_state["current_module_source_id"] = requested_current if requested_current in modules else modules[-1]
            chosen = _session_list(current.get("selected_source_ids"), MAX_CONTEXT_SOURCES)
            for sid in modules:
                if sid not in chosen:
                    chosen.append(sid)
            next_state["selected_source_ids"] = chosen
            packs = ordered_pack_names(current.get("selected_packs", []))
            for sid in modules:
                pack_name = canonical_pack_name(str(mapping[sid].get("source_name") or ""))
                if pack_name and pack_name != STARTUP_PACK_01 and pack_name not in packs:
                    packs.append(pack_name)
            next_state["selected_packs"] = ordered_pack_names(packs)
        elif action == "set-current-module":
            source_id = str(payload.get("source_id") or "")
            if source_id not in _session_list(current.get("active_module_source_ids"), MAX_CONTEXT_SOURCES):
                raise ValueError("Ce document n’est pas un module actif.")
            next_state["current_module_source_id"] = source_id
        elif action == "set-full":
            next_state["full_available"] = bool(payload.get("full_available"))
        elif action == "set-runtime":
            next_state["runtime_mode"] = str(payload.get("runtime_mode") or next_state.get("runtime_mode"))
        elif action == "set-sources":
            next_state["selected_source_ids"] = payload.get("selected_source_ids") if isinstance(payload.get("selected_source_ids"), list) else []
            mapping = source_map(index)
            picked_modules = [sid for sid in _session_list(next_state["selected_source_ids"], MAX_CONTEXT_SOURCES)
                              if sid in mapping and str(mapping[sid].get("category") or "") == "Module"]
            if picked_modules:
                next_state["active_module_source_ids"] = picked_modules
                next_state["current_module_source_id"] = picked_modules[-1]
                packs = ordered_pack_names(current.get("selected_packs", []))
                for sid in picked_modules:
                    pack_name = canonical_pack_name(str(mapping[sid].get("source_name") or ""))
                    if pack_name and pack_name != STARTUP_PACK_01 and pack_name not in packs:
                        packs.append(pack_name)
                next_state["selected_packs"] = ordered_pack_names(packs)
        elif action == "set-chunks":
            next_state["selected_chunk_ids"] = payload.get("selected_chunk_ids") if isinstance(payload.get("selected_chunk_ids"), list) else []
        elif action == "attach-web-source":
            source_id = str(payload.get("source_id") or "").strip()
            if not get_web_source(source_id):
                raise ValueError("Lecture web temporaire introuvable. Relis l’URL avant de la joindre.")
            current_web = _session_list(current.get("selected_web_source_ids"), MAX_WEB_ATTACHED_SOURCES)
            next_state["selected_web_source_ids"] = [*current_web, source_id][-MAX_WEB_ATTACHED_SOURCES:]
        elif action == "detach-web-source":
            source_id = str(payload.get("source_id") or "").strip()
            next_state["selected_web_source_ids"] = [sid for sid in _session_list(current.get("selected_web_source_ids"), MAX_WEB_ATTACHED_SOURCES) if sid != source_id]
        elif action == "clear-web-sources":
            next_state["selected_web_source_ids"] = []
        elif action == "set-brief":
            for key in ("mission", "expected", "stop_point"):
                if key in payload:
                    next_state[key] = payload.get(key)
        elif action == "set-creator-context":
            next_state["creator_context_enabled"] = bool(payload.get("creator_context_enabled"))
        elif action == "replace":
            # Restauration volontaire d’une session sauvegardée uniquement.
            # Elle repart d’un état neuf puis applique le fichier choisi : aucun
            # document temporaire, pack caché ou lecture web de la session
            # précédente ne peut survivre par accident.
            next_state = _runtime_session_defaults()
            for key in next_state:
                if key in payload:
                    next_state[key] = payload.get(key)
        else:
            raise ValueError("Mutation de session inconnue.")

        RUNTIME_SESSION = normalize_runtime_session(next_state, index)
        RUNTIME_SESSION_REVISION += 1
        return runtime_session_snapshot(index, RUNTIME_SESSION)


def runtime_session_snapshot(index: dict[str, Any], session: dict[str, Any] | None = None) -> dict[str, Any]:
    """État affichable : toutes les vues l’obtiennent du même serveur local."""
    global RUNTIME_SESSION_REVISION
    session = normalize_runtime_session(session or current_runtime_session(index), index)
    core_key = str(session["core_key"])
    active_names = effective_active_pack_names(session["selected_packs"], session["startup_pack"])
    available_names = [canonical_pack_name(str(row.get("name") or "")) for row in bundled_archive_rows(index)]
    catalog = pack_catalog_rows(index)
    bootstrap_by_pack = {canonical_pack_name(str(row.get("name") or "")): int(row.get("bootstrap_count") or 0) for row in catalog}
    base_count = len(default_stack(index, core_key).get("sources", []))
    web_rows = [public_web_source(row) for row in get_web_sources(session.get("selected_web_source_ids") if isinstance(session.get("selected_web_source_ids"), list) else [])]
    configured_sources = base_count + len(session["selected_source_ids"]) + sum(bootstrap_by_pack.get(name, 0) for name in active_names) + len(web_rows)
    active_modules = []
    mapping = source_map(index)
    for sid in _session_list(session.get("active_module_source_ids"), MAX_CONTEXT_SOURCES):
        source = module_source_row(index, sid)
        if source:
            active_modules.append({"id": sid, "label": module_source_label(source), "relative_path": str(source.get("relative_path") or ""), "pack": canonical_pack_name(str(source.get("source_name") or ""))})
    return {
        **session,
        "revision": RUNTIME_SESSION_REVISION,
        "active_pack_names": active_names,
        "active_archives": [PACK_CATALOG[name]["label"] for name in active_names],
        "available_pack_names": available_names,
        "available_archives": [PACK_CATALOG[name]["label"] for name in available_names if name in PACK_CATALOG],
        "base_source_ids": [str(row.get("id")) for row in default_stack(index, core_key).get("sources", [])],
        "core_contract": default_stack(index, core_key).get("contract", {}),
        "configured_source_count": configured_sources,
        "pack_count": len(available_names),
        "full_scope": "recherche ciblée dans le Coffre" if session["full_available"] else "pile active uniquement",
        "web_sources": web_rows,
        "web_source_count": len(web_rows),
        "active_modules": active_modules,
        "current_module_source_id": str(session.get("current_module_source_id") or ""),
    }


def get_links() -> list[dict[str, str]]:
    """Load local links and append newly shipped default gateways without overwriting edits."""
    links = json_load(LINKS_PATH, DEFAULT_LINKS)
    if not isinstance(links, list):
        links = DEFAULT_LINKS
    normalized: list[dict[str, str]] = []
    seen: set[str] = set()
    for i, link in enumerate(links[:36]):
        if not isinstance(link, dict):
            continue
        link_id = str(link.get("id") or f"link-{i}")
        if link_id in seen:
            continue
        seen.add(link_id)
        normalized.append({
            "id": link_id,
            "label": str(link.get("label") or "Lien local"),
            "url": str(link.get("url") or ""),
            "kind": str(link.get("kind") or "custom"),
        })
    for link in DEFAULT_LINKS:
        if link["id"] not in seen:
            normalized.append(dict(link))
    return normalized or [dict(x) for x in DEFAULT_LINKS]


def is_erith_project_root(path: Path) -> bool:
    """Accept a Git clone or an extracted canonical project folder.

    The local mirror remains read-only. Requiring .git would reject a perfectly
    usable project copy exported from GitHub, so the canonical core is also a
    valid signature.
    """
    try:
        return path.is_dir() and (
            (path / ".git").exists()
            or ((path / "core").is_dir() and (path / "core" / "SEVEN_GATE.md").is_file())
        )
    except OSError:
        return False


def suggested_repo_paths() -> list[str]:
    """Suggest existing local project roots; never index them without an explicit click."""
    raw_hints = [os.environ.get("ERITH_LOCAL_REPO", ""), *REPO_PATH_HINTS]
    results: list[str] = []
    seen: set[str] = set()
    for raw in raw_hints:
        if not raw:
            continue
        path = Path(raw).expanduser()
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        key = str(resolved).lower()
        if key in seen:
            continue
        seen.add(key)
        if is_erith_project_root(resolved):
            results.append(str(resolved))
    return results[:6]


def save_links(links: list[dict[str, str]]) -> None:
    cleaned: list[dict[str, str]] = []
    for i, link in enumerate(links[:24]):
        label = str(link.get("label", "")).strip()[:80]
        url = str(link.get("url", "")).strip()[:500]
        kind = str(link.get("kind", "custom")).strip()[:24]
        if not label:
            continue
        cleaned.append({"id": str(link.get("id") or f"link-{i}"), "label": label, "url": url, "kind": kind})
    json_save(LINKS_PATH, cleaned or DEFAULT_LINKS)


def sha_id(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", "ignore")).hexdigest()[:20]


def clean_text(raw: bytes) -> str:
    text = raw.decode("utf-8", errors="replace")
    text = text.replace("\x00", "")
    return text[:MAX_READ_CHARS]


def is_allowed_file(name: str, size: int = 0) -> bool:
    suffix = Path(name).suffix.lower()
    return suffix in ALLOWED_EXTENSIONS and (size <= MAX_SOURCE_BYTES or size == 0)


def path_is_restricted(path_text: str) -> tuple[bool, str]:
    parts = [p.lower() for p in Path(path_text).parts]
    if any(p in RESTRICTED_SEGMENTS for p in parts):
        return True, "emplacement sensible bloqué"
    normalized = "/".join(parts)
    if "private/creator_memory/" in normalized and "/exports/" not in normalized:
        # Rose has a controlled, explicit local chain. These exact Markdown files
        # are allowed when a user-selected Git mirror provides them; every other
        # Creator Memory file remains blocked by default.
        if normalized in APPROVED_CREATOR_MEMORY_PATHS:
            return False, ""
        return True, "Creator Memory non autorisée pour cette route"
    return False, ""


def classify_path(path_text: str) -> tuple[str, list[str]]:
    p = path_text.lower().replace("\\", "/")
    tags: list[str] = []
    category = "Source"
    if "/core/" in p or p.startswith("core/"):
        category = "Core"
    elif "/modules/" in p or p.startswith("modules/"):
        category = "Module"
    elif "/production/" in p or "/workflows/" in p:
        category = "Production"
    elif "/public/" in p:
        category = "Public"
    elif "persona" in p:
        category = "Persona"
    elif "memory" in p or "memoire" in p:
        category = "Memory"

    tag_map = {
        "seven": "Seven",
        "aerith_10": "Aerith-10",
        "aerith_6": "Aerith-6",
        "soeur_miroir": "Aerith-6",
        "gorge_astrale": "Aerith-6",
        "routeuse": "Routeuse",
        "sun": "Sun",
        "night": "Night",
        "constellation": "Constellation",
        "flower_girl": "Flower Girls",
        "rose": "Rose",
        "video": "Video",
        "wan": "Wan",
        "davinci": "DaVinci",
        "sound": "Sound",
        "voice": "Voice",
        "story": "Story",
        "discern": "Discernement",
        "memory": "Memory",
        "memoire": "Memory",
        "dharma": "Dharma",
        "public": "Public",
        "cyber": "Cyberpunk",
        "ollama": "Ollama",
        "comfy": "ComfyUI",
        "youtube": "YouTube",
    }
    for key, label in tag_map.items():
        if key in p and label not in tags:
            tags.append(label)
    return category, tags[:8]


def read_manifest_from_zip(path: Path) -> tuple[str, str]:
    try:
        with zipfile.ZipFile(path) as archive:
            member = next((n for n in archive.namelist() if n.endswith("/MANIFEST.md")), None)
            if not member:
                return "", ""
            text = clean_text(archive.read(member))
            role = ""
            match = re.search(r"##\s*Rôle\s*\n+(.+?)(?:\n\n|\Z)", text, flags=re.IGNORECASE | re.DOTALL)
            if match:
                role = " ".join(match.group(1).strip().split())[:260]
            return member, role
    except (OSError, zipfile.BadZipFile, KeyError):
        return "", ""


def index_seed(seed_root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Indexe le snapshot de Cores/Personas local livré avec l'application.

    Il est une source hors ligne lisible. Lorsqu'un clone Git local est configuré,
    le clone est prioritaire pour le même chemin canonique.
    """
    sources: list[dict[str, Any]] = []
    if not seed_root.exists():
        return sources, {"name": "Cores canoniques locaux", "kind": "canonical-seed", "count": 0, "status": "absent"}
    for path in iter_repo_files(seed_root):
        try:
            rel = path.relative_to(seed_root).as_posix()
            stat = path.stat()
        except OSError:
            continue
        # Le manifest/README restent indexés mais ne sont pas choisis automatiquement.
        blocked, reason = path_is_restricted(rel)
        category, tags = classify_path(rel)
        filename_low = Path(rel).name.lower()
        if "_persona_" in filename_low or "persona_operating_layer" in filename_low:
            category = "Persona"
        sources.append({
            "id": sha_id(f"seed|{rel}"),
            "kind": "seed",
            "source_name": "Cores canoniques locaux",
            "container": str(seed_root.resolve()),
            "entry": rel,
            "relative_path": rel,
            "title": Path(rel).name,
            "category": category,
            "tags": tags,
            "size": stat.st_size,
            "blocked": blocked,
            "block_reason": reason,
            "manifest": Path(rel).name.upper() in {"CORE_MIRROR_MANIFEST.JSON", "MANIFEST.MD"},
            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
            "origin": "snapshot local canonique",
        })
    return sources, {
        "name": "Cores canoniques locaux",
        "kind": "canonical-seed",
        "path": str(seed_root.relative_to(ROOT)).replace("\\", "/"),
        "role": "Snapshot hors ligne des Cores et Personas de base.",
        "manifest": "CORE_MIRROR_MANIFEST.json",
        "count": len(sources),
        "status": "prêt" if sources else "absent",
    }


def index_zip(pack_path: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    source_name = pack_path.name
    manifest_entry, role = read_manifest_from_zip(pack_path)
    sources: list[dict[str, Any]] = []
    try:
        with zipfile.ZipFile(pack_path) as archive:
            for info in archive.infolist():
                if info.is_dir() or not is_allowed_file(info.filename, info.file_size):
                    continue
                relative = info.filename.split("/", 1)[1] if "/" in info.filename else info.filename
                blocked, reason = path_is_restricted(relative)
                category, tags = classify_path(relative)
                source_id = sha_id(f"zip|{source_name}|{info.filename}")
                sources.append({
                    "id": source_id,
                    "kind": "zip",
                    "source_name": source_name,
                    "container": str(pack_path.relative_to(ROOT)).replace("\\", "/"),
                    "entry": info.filename,
                    "relative_path": relative,
                    "title": Path(relative).name,
                    "category": category,
                    "tags": tags,
                    "size": info.file_size,
                    "blocked": blocked,
                    "block_reason": reason,
                    "manifest": info.filename == manifest_entry,
                    "modified": f"{info.date_time[0]:04d}-{info.date_time[1]:02d}-{info.date_time[2]:02d}",
                    "origin": "archive ERITH-7 embarquée",
                })
    except (OSError, zipfile.BadZipFile):
        pass
    meta = {
        "name": source_name,
        "kind": "embedded-pack",
        "path": str(pack_path.relative_to(ROOT)).replace("\\", "/"),
        "role": role or "Pack local indexé.",
        "manifest": manifest_entry.split("/", 1)[-1] if manifest_entry else "absent",
        "count": len(sources),
    }
    return sources, meta


def iter_repo_files(repo_root: Path) -> Iterable[Path]:
    count = 0
    for current, dirs, files in os.walk(repo_root):
        dirs[:] = [d for d in dirs if d.lower() not in EXCLUDED_DIRS]
        for filename in files:
            path = Path(current) / filename
            if not is_allowed_file(filename):
                continue
            try:
                if path.stat().st_size > MAX_SOURCE_BYTES:
                    continue
            except OSError:
                continue
            yield path
            count += 1
            if count >= MAX_REPO_FILES:
                return



# Creator Context is deliberately explicit. The local profile is application
# metadata. Optional memory comes only from the Git-export folder, never from
# the Seven Vault or raw Creator Memory paths.
CREATOR_EXPORT_ROOT = "private/creator_memory/exports/"
CREATOR_ROUTE_HINTS: dict[str, tuple[str, ...]] = {
    "aerith7": ("seven", "aerith7", "aerith_7", "general", "common"),
    "aerith6": ("aerith6", "aerith_6", "miroir", "gorge", "workflow", "comfyui"),
    "aerith10": ("aerith10", "aerith_10", "creatrice", "creator", "production"),
    "sun": ("sun", "solaire", "solar"),
    "night": ("night", "lunaire", "nocturne"),
    "constellation": ("constellation", "flower", "girls"),
}


def creator_export_sources(index: dict[str, Any], core_key: str, limit: int = 3) -> list[dict[str, Any]]:
    """Return only exported Git Markdown that is safe to opt into.

    Never reads Vault/DPAPI. Never reads private creator-memory files outside
    `exports/`. The README is allowed as a routing description, then only
    route-matching exports are retained.
    """
    hints = CREATOR_ROUTE_HINTS.get(core_key, CREATOR_ROUTE_HINTS["aerith7"])
    candidates: list[tuple[int, dict[str, Any]]] = []
    for source in index.get("sources", []):
        if not isinstance(source, dict) or source.get("blocked"):
            continue
        rel = str(source.get("relative_path") or "").replace("\\", "/")
        low = rel.lower()
        if not low.startswith(CREATOR_EXPORT_ROOT):
            continue
        if Path(low).suffix not in TEXT_RAG_EXTENSIONS:
            continue
        score = 0
        if low.endswith("/readme.md") or low.endswith("exports/readme.md"):
            score += 80
        score += sum(20 for hint in hints if hint in low)
        # Source must be route-relevant or an explicit exports README.
        if score:
            candidates.append((score, source))
    candidates.sort(key=lambda row: (-row[0], str(row[1].get("relative_path") or "")))
    chosen: list[dict[str, Any]] = []
    seen: set[str] = set()
    for _, source in candidates:
        sid = str(source.get("id") or "")
        if not sid or sid in seen:
            continue
        chosen.append(source)
        seen.add(sid)
        if len(chosen) >= max(1, min(limit, 4)):
            break
    return chosen


def creator_export_chunks(index: dict[str, Any], core_key: str, max_chunks: int) -> list[dict[str, Any]]:
    allowed = {str(s.get("id") or "") for s in creator_export_sources(index, core_key)}
    if not allowed:
        return []
    out: list[dict[str, Any]] = []
    used: set[str] = set()
    for chunk in get_rag_index(index).get("chunks", []):
        if str(chunk.get("source_id") or "") not in allowed:
            continue
        cid = str(chunk.get("id") or "")
        if not cid or cid in used:
            continue
        heading = _norm_heading(str(chunk.get("heading") or ""))
        # Skip low-information metadata/frontmatter headings where possible.
        if any(marker in heading for marker in ("statut", "date", "changelog", "index")):
            continue
        out.append({**chunk, "score": 9_700 - len(out), "use_type": "mémoire exportée"})
        used.add(cid)
        if len(out) >= max(1, min(max_chunks, 2)):
            break
    return out


def creator_profile() -> dict[str, Any]:
    cfg = get_config()
    name = str(cfg.get("operator_name") or "Christophe").strip()[:80] or "Christophe"
    return {
        "operator_name": name,
        "enabled": bool(cfg.get("creator_context_enabled")),
        "scope": "profil opérateur local + exports Git explicitement autorisés",
    }

def index_local_repo(repo_root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    sources: list[dict[str, Any]] = []
    if not repo_root.exists() or not repo_root.is_dir():
        return sources, {"kind": "local-mirror", "path": str(repo_root), "count": 0, "status": "absent"}
    for path in iter_repo_files(repo_root):
        try:
            rel = path.relative_to(repo_root).as_posix()
            stat = path.stat()
        except OSError:
            continue
        blocked, reason = path_is_restricted(rel)
        category, tags = classify_path(rel)
        sources.append({
            "id": sha_id(f"repo|{repo_root.resolve()}|{rel}"),
            "kind": "repo",
            "source_name": "Miroir Git local",
            "container": str(repo_root.resolve()),
            "entry": rel,
            "relative_path": rel,
            "title": Path(rel).name,
            "category": category,
            "tags": tags,
            "size": stat.st_size,
            "blocked": blocked,
            "block_reason": reason,
            "manifest": Path(rel).name.upper() == "MANIFEST.MD",
            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
            "origin": "miroir Git local canonique",
        })
    return sources, {
        "name": "Miroir Git local",
        "kind": "local-mirror",
        "path": str(repo_root.resolve()),
        "role": "Lecture seule : fichiers choisis depuis le clone local.",
        "manifest": "index local",
        "count": len(sources),
        "status": "prêt",
    }


def build_library_index() -> dict[str, Any]:
    ensure_dirs()
    sources: list[dict[str, Any]] = []
    packs: list[dict[str, Any]] = []
    seed_sources, seed_meta = index_seed(CANONICAL_SEED_DIR)
    sources.extend(seed_sources)
    for pack_path in sorted(PACKS_DIR.glob("*.zip")):
        pack_sources, pack_meta = index_zip(pack_path)
        sources.extend(pack_sources)
        packs.append(pack_meta)

    cfg = get_config()
    repo_meta: dict[str, Any] | None = None
    repo_path_text = str(cfg.get("repo_path") or "").strip()
    if repo_path_text:
        repo_path = Path(repo_path_text).expanduser()
        repo_sources, repo_meta = index_local_repo(repo_path)
        sources.extend(repo_sources)
        cfg["repo_last_indexed"] = now_iso()
        save_config(cfg)

    index = {
        "version": APP_VERSION,
        "schema": INDEX_SCHEMA,
        "built_at": now_iso(),
        "packs": packs,
        "seed": seed_meta,
        "repo": repo_meta,
        "sources": sources,
    }
    json_save(LIBRARY_INDEX_PATH, index)
    # Le Coffre est également découpé en extraits locaux recherchables.
    # Aucun texte n'est envoyé à Ollama ici : l'index reste strictement local.
    rag = build_rag_index(index, force=True)
    global LIBRARY_INDEX_CACHE, RAG_INDEX_CACHE, RAG_CACHE_FINGERPRINT, MODULE_CATALOG_CACHE
    LIBRARY_INDEX_CACHE = index
    RAG_INDEX_CACHE = rag
    RAG_CACHE_FINGERPRINT = str(rag.get("fingerprint") or "")
    MODULE_CATALOG_CACHE = None
    return index


def get_library_index(force: bool = False) -> dict[str, Any]:
    global LIBRARY_INDEX_CACHE
    with LOCK:
        if not force and isinstance(LIBRARY_INDEX_CACHE, dict) and isinstance(LIBRARY_INDEX_CACHE.get("sources"), list):
            return LIBRARY_INDEX_CACHE
        if force or not LIBRARY_INDEX_PATH.exists():
            return build_library_index()
        index = json_load(LIBRARY_INDEX_PATH, {})
        if (
            not isinstance(index, dict)
            or not isinstance(index.get("sources"), list)
            or str(index.get("version") or "") != APP_VERSION
            or str(index.get("schema") or "") != INDEX_SCHEMA
        ):
            return build_library_index()
        LIBRARY_INDEX_CACHE = index
        return index


def source_map(index: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(item.get("id")): item for item in index.get("sources", []) if isinstance(item, dict)}

def pack_catalog_rows(index: dict[str, Any]) -> list[dict[str, Any]]:
    """Expose les sept packs avec leurs vrais fichiers d'entrée joignables."""
    rows: list[dict[str, Any]] = []
    for pack_name, meta in PACK_CATALOG.items():
        wanted = [sanitize_source(src) for src in pack_bootstrap_sources(index, pack_name)]
        rows.append({
            "name": pack_name,
            "label": meta["label"],
            "role": meta["role"],
            "available": bool(wanted),
            "bootstrap_sources": wanted,
            "bootstrap_count": len(wanted),
        })
    return rows

def sanitize_source(item: dict[str, Any]) -> dict[str, Any]:
    keys = ["id", "kind", "source_name", "relative_path", "title", "category", "tags", "size", "blocked", "block_reason", "manifest", "modified", "origin"]
    return {k: item.get(k) for k in keys}


def read_source(item: dict[str, Any]) -> str:
    if item.get("blocked"):
        raise PermissionError(str(item.get("block_reason") or "source bloquée"))
    kind = item.get("kind")
    if kind == "zip":
        path = ROOT / str(item.get("container"))
        entry = str(item.get("entry"))
        if not path.exists() or not entry:
            raise FileNotFoundError("archive locale introuvable")
        with zipfile.ZipFile(path) as archive:
            info = archive.getinfo(entry)
            if info.file_size > MAX_SOURCE_BYTES:
                raise ValueError("source trop volumineuse")
            return clean_text(archive.read(entry))
    if kind in {"repo", "seed"}:
        root = Path(str(item.get("container"))).resolve()
        rel = str(item.get("entry"))
        path = (root / rel).resolve()
        if root not in path.parents and path != root:
            raise PermissionError("chemin hors miroir local")
        if not path.exists() or not path.is_file():
            raise FileNotFoundError("source locale introuvable")
        if path.stat().st_size > MAX_SOURCE_BYTES:
            raise ValueError("source trop volumineuse")
        return path.read_text(encoding="utf-8", errors="replace")[:MAX_READ_CHARS]
    raise ValueError("type de source inconnu")


def normalize_tokens(text: str) -> list[str]:
    words = re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ0-9_]{3,}", text.lower())
    unique: list[str] = []
    for word in words:
        if word not in unique:
            unique.append(word)
    return unique[:24]


def relevance_score(haystack: str, tokens: list[str]) -> int:
    low = haystack.lower()
    score = 0
    for token in tokens:
        score += low.count(token) * min(10, len(token))
    return score


def select_excerpt(text: str, query: str, max_chars: int) -> str:
    text = text.strip()
    if len(text) <= max_chars:
        return text
    tokens = normalize_tokens(query)
    block_size = 1800
    blocks = [text[i:i + block_size] for i in range(0, len(text), block_size)]
    ranked = sorted(enumerate(blocks), key=lambda pair: relevance_score(pair[1], tokens), reverse=True)
    chosen_indexes = sorted(index for index, _ in ranked[:2])
    if not chosen_indexes or relevance_score(blocks[chosen_indexes[0]], tokens) == 0:
        chosen_indexes = [0]
    excerpt = "\n\n[… extrait local …]\n\n".join(blocks[i] for i in chosen_indexes)
    return excerpt[:max_chars]


def find_source_by_relative(index: dict[str, Any], relative_path: str) -> dict[str, Any] | None:
    """Résout une source canonique avec priorité au Git local choisi par l'utilisateur.

    Ordre : miroir Git local → snapshot de Cores local → Core Boot Pack → autre archive.
    """
    candidates = [s for s in index.get("sources", []) if s.get("relative_path") == relative_path and not s.get("blocked")]
    priority = {"repo": 0, "seed": 1, "zip": 3}
    def rank(item: dict[str, Any]) -> tuple[int, int, str]:
        kind = str(item.get("kind"))
        boot = 0 if str(item.get("source_name", "")).startswith("ERITH_7_01_CORE_BOOT_PACK") else 1
        return (priority.get(kind, 9), boot if kind == "zip" else 0, str(item.get("relative_path", "")))
    candidates.sort(key=rank)
    return candidates[0] if candidates else None


def core_availability(index: dict[str, Any], core_key: str) -> dict[str, Any]:
    """Checks the exact Core + Persona chain before a route can be activated."""
    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
    required = [str(core.get("core") or "")]
    if str(core.get("persona") or ""):
        required.append(str(core.get("persona")))
    missing = [path for path in required if path and not find_source_by_relative(index, path)]
    return {"available": not missing, "missing": missing, "required": required}


def core_option_rows(index: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for key, value in CORE_OPTIONS.items():
        availability = core_availability(index, key)
        rows.append({"key": key, **value, **availability})
    return rows


def default_stack(index: dict[str, Any], core_key: str) -> dict[str, Any]:
    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
    selected: list[dict[str, Any]] = []
    missing: list[str] = []
    for path in boot_dependency_paths(core_key):
        if not path:
            continue
        source = find_source_by_relative(index, path)
        if source:
            selected.append(source)
        else:
            missing.append(path)
    seen: set[str] = set()
    selected = [s for s in selected if not (s["id"] in seen or seen.add(s["id"]))]
    source_rows = [sanitize_source(s) for s in selected]
    core_source = next((row for row in source_rows if row.get("relative_path") == core.get("core")), None)
    persona_source = next((row for row in source_rows if row.get("relative_path") == core.get("persona")), None) if core.get("persona") else None
    base_sources = [row for row in source_rows if row.get("relative_path") in BASE_SEVEN_PATHS]
    contract = {
        "identity": core["label"],
        "route": core["route"],
        "core": core_source,
        "persona": persona_source,
        "base": base_sources,
        "is_complete": bool(core_source) and (not core.get("persona") or bool(persona_source)) and not missing,
        "source_mode": "Coffre Git local en lecture seule" if any(row.get("kind") == "repo" for row in source_rows) else "snapshot hors ligne embarqué",
        "boot_required_paths": boot_dependency_paths(core_key),
        "boot_resolved_paths": [str(row.get("relative_path") or "") for row in source_rows],
    }
    return {
        "core": {"key": core_key, **core},
        "sources": source_rows,
        "missing": missing,
        "contract": contract,
    }


def search_sources(index: dict[str, Any], query: str, category: str = "", limit: int = 120) -> list[dict[str, Any]]:
    q = query.strip()
    tokens = normalize_tokens(q)
    rows: list[tuple[int, dict[str, Any]]] = []
    for item in index.get("sources", []):
        if category and item.get("category") != category:
            continue
        text = " ".join([
            str(item.get("title", "")),
            str(item.get("relative_path", "")),
            " ".join(item.get("tags") or []),
            str(item.get("source_name", "")),
        ])
        score = relevance_score(text, tokens) if tokens else 1
        if tokens and score <= 0:
            continue
        if item.get("manifest"):
            score += 2
        if item.get("blocked"):
            score -= 1
        rows.append((score, item))
    rows.sort(key=lambda pair: (-pair[0], str(pair[1].get("relative_path", "")).lower()))
    return [sanitize_source(item) for _, item in rows[:max(1, min(limit, 240))]]


def select_pack_sources(index: dict[str, Any], pack_name: str, query: str, max_items: int) -> list[dict[str, Any]]:
    tokens = normalize_tokens(query)
    candidates: list[tuple[int, dict[str, Any]]] = []
    for source in index.get("sources", []):
        if source.get("source_name") != pack_name or source.get("blocked"):
            continue
        rel = str(source.get("relative_path", ""))
        base = Path(rel).name.lower()
        if base in {"readme.md", "manifest.md", "index_archives_erith_7.md"}:
            continue
        if source.get("category") not in {"Core", "Module", "Production", "Memory", "Public", "Persona"}:
            continue
        score = relevance_score(f"{rel} {' '.join(source.get('tags') or [])}", tokens)
        # Un faible score conserve une sélection représentative si le D est très bref.
        if score == 0:
            score = 1
        candidates.append((score, source))
    candidates.sort(key=lambda pair: (-pair[0], str(pair[1].get("relative_path", "")).lower()))
    return [source for _, source in candidates[:max_items]]



RAG_STOPWORDS = {
    "avec", "dans", "pour", "mais", "plus", "moins", "tout", "tous", "toute", "toutes",
    "quoi", "quel", "quelle", "quels", "quelles", "comment", "pourquoi", "quand", "dont",
    "etre", "être", "avoir", "faire", "peux", "peut", "vous", "nous", "elle", "il", "les",
    "des", "une", "un", "sur", "par", "que", "qui", "est", "sont", "pas", "avec", "sans",
    "the", "and", "from", "this", "that", "into", "your", "their", "have", "will",
}


def rag_fingerprint(index: dict[str, Any]) -> str:
    rows = []
    for source in index.get("sources", []):
        if not isinstance(source, dict) or source.get("blocked"):
            continue
        rows.append("|".join([
            str(source.get("id", "")), str(source.get("relative_path", "")),
            str(source.get("size", "")), str(source.get("modified", "")),
        ]))
    return sha_id("\n".join(sorted(rows)))


def preferred_rag_sources(index: dict[str, Any]) -> list[dict[str, Any]]:
    """Évite de réindexer plusieurs copies identiques d'un même fichier canonique.

    Priorité : clone Git local, snapshot canonique, Core Boot, autres archives.
    Les fichiers uniques des packs restent tous disponibles.
    """
    priority = {"repo": 0, "seed": 1, "zip": 2}
    chosen: dict[str, dict[str, Any]] = {}
    for source in index.get("sources", []):
        if not isinstance(source, dict) or source.get("blocked"):
            continue
        rel = str(source.get("relative_path") or "")
        if not rel:
            continue
        existing = chosen.get(rel)
        if existing is None:
            chosen[rel] = source
            continue
        current_rank = priority.get(str(source.get("kind")), 9)
        existing_rank = priority.get(str(existing.get("kind")), 9)
        if current_rank < existing_rank:
            chosen[rel] = source
        elif current_rank == existing_rank and current_rank == 2:
            # Parmi les ZIP : le Core Boot est plus utile pour les doublons système.
            current_boot = str(source.get("source_name", "")).startswith("ERITH_7_01_CORE_BOOT_PACK")
            existing_boot = str(existing.get("source_name", "")).startswith("ERITH_7_01_CORE_BOOT_PACK")
            if current_boot and not existing_boot:
                chosen[rel] = source
    return list(chosen.values())


def markdown_sections(text: str) -> list[tuple[str, str]]:
    clean = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not clean:
        return []
    matches = list(re.finditer(r"(?m)^(#{1,5})\s+(.+?)\s*$", clean))
    if not matches:
        return [("Contenu", clean)]
    sections: list[tuple[str, str]] = []
    if matches[0].start() > 0:
        intro = clean[:matches[0].start()].strip()
        if intro:
            sections.append(("Introduction", intro))
    for i, match in enumerate(matches):
        heading = re.sub(r"\s+", " ", match.group(2)).strip()[:220]
        end = matches[i + 1].start() if i + 1 < len(matches) else len(clean)
        body = clean[match.end():end].strip()
        if body:
            sections.append((heading, body))
    return sections or [("Contenu", clean)]


def split_section(heading: str, body: str) -> list[tuple[str, str]]:
    prefix = f"## {heading}\n"
    body = body.strip()
    if len(prefix) + len(body) <= RAG_CHUNK_CHARS:
        return [(heading, prefix + body)]
    chunks: list[tuple[str, str]] = []
    start = 0
    while start < len(body) and len(chunks) < 160:
        end = min(len(body), start + RAG_CHUNK_CHARS - len(prefix))
        cut = body.rfind("\n", start, end)
        if cut <= start + 320:
            cut = body.rfind(". ", start, end)
        if cut <= start + 320:
            cut = end
        else:
            cut = cut + (2 if body[cut:cut+2] == ". " else 0)
        snippet = body[start:cut].strip()
        if snippet:
            chunks.append((heading, prefix + snippet))
        if cut >= len(body):
            break
        start = max(cut - RAG_CHUNK_OVERLAP, start + 1)
    return chunks


def build_rag_index(index: dict[str, Any], force: bool = False) -> dict[str, Any]:
    """Construit un index de lecture Markdown/TXT uniquement.

    JSON, YAML et workflows restent visibles dans l'onglet Fichiers, mais ne sont
    jamais présentés comme des textes de référence et ne sont jamais envoyés au LLM
    par le moteur documentaire.
    """
    fingerprint = rag_fingerprint(index)
    if not force and RAG_INDEX_PATH.exists():
        cached = json_load(RAG_INDEX_PATH, {})
        if isinstance(cached, dict) and cached.get("version") == APP_VERSION and cached.get("schema") == INDEX_SCHEMA and cached.get("fingerprint") == fingerprint and isinstance(cached.get("chunks"), list):
            return cached
    chunks: list[dict[str, Any]] = []
    scanned = 0
    skipped = 0
    skipped_nontext = 0
    duplicate_sources = 0
    seen_content: set[str] = set()
    # Ordre stable : les sources prioritaires (repo puis seed) gagnent lorsqu'un texte est identique.
    priority = {"repo": 0, "seed": 1, "zip": 2}
    sources = sorted(
        preferred_rag_sources(index),
        key=lambda s: (priority.get(str(s.get("kind") or ""), 9), str(s.get("relative_path") or "").lower()),
    )
    for source in sources:
        if len(chunks) >= MAX_RAG_CHUNKS:
            break
        rel = str(source.get("relative_path") or "")
        if Path(rel).suffix.lower() not in TEXT_RAG_EXTENSIONS:
            skipped_nontext += 1
            continue
        try:
            raw = read_source(source)
        except (OSError, ValueError, PermissionError, zipfile.BadZipFile):
            skipped += 1
            continue
        normalized_source = " ".join(normalize_tokens(raw))
        source_hash = sha_id(normalized_source)
        if source_hash in seen_content:
            duplicate_sources += 1
            continue
        seen_content.add(source_hash)
        scanned += 1
        title = str(source.get("title") or rel or "Texte local")
        low_priority = Path(rel).name.lower() in {"readme.md", "manifest.md", "index_archives_erith_7.md"}
        for section_index, (heading, body) in enumerate(markdown_sections(raw)):
            for chunk_index, (_, chunk_text) in enumerate(split_section(heading, body)):
                if len(chunks) >= MAX_RAG_CHUNKS:
                    break
                normalized = " ".join(normalize_tokens(f"{heading} {chunk_text}"))
                chunks.append({
                    "id": sha_id(f"{source.get('id')}|{section_index}|{chunk_index}|{heading}"),
                    "source_id": str(source.get("id")),
                    "relative_path": rel,
                    "title": title,
                    "category": str(source.get("category") or "Texte"),
                    "tags": list(source.get("tags") or []),
                    "origin": str(source.get("origin") or source.get("source_name") or "local"),
                    "source_name": str(source.get("source_name") or ""),
                    "heading": heading,
                    "text": chunk_text[:RAG_CHUNK_CHARS + 80],
                    "tokens": normalized[:5500],
                    "low_priority": low_priority,
                })
    rag = {
        "version": APP_VERSION,
        "built_at": now_iso(),
        "fingerprint": fingerprint,
        "source_count": scanned,
        "skipped_count": skipped,
        "skipped_nontext": skipped_nontext,
        "duplicate_sources": duplicate_sources,
        "chunk_count": len(chunks),
        "chunks": chunks,
    }
    json_save(RAG_INDEX_PATH, rag)
    return rag


def get_rag_index(index: dict[str, Any]) -> dict[str, Any]:
    global RAG_INDEX_CACHE, RAG_CACHE_FINGERPRINT
    with LOCK:
        fingerprint = rag_fingerprint(index)
        if isinstance(RAG_INDEX_CACHE, dict) and RAG_CACHE_FINGERPRINT == fingerprint and isinstance(RAG_INDEX_CACHE.get("chunks"), list):
            return RAG_INDEX_CACHE
        cached = json_load(RAG_INDEX_PATH, {})
        if isinstance(cached, dict) and cached.get("version") == APP_VERSION and cached.get("schema") == INDEX_SCHEMA and cached.get("fingerprint") == fingerprint and isinstance(cached.get("chunks"), list):
            RAG_INDEX_CACHE = cached
            RAG_CACHE_FINGERPRINT = fingerprint
            return cached
        rag = build_rag_index(index, force=True)
        RAG_INDEX_CACHE = rag
        RAG_CACHE_FINGERPRINT = fingerprint
        return rag


def retrieval_tokens(query: str, core_key: str) -> list[str]:
    """Terms coming from the request only.

    The old runtime added the whole Core vocabulary as a fallback. It made a simple
    "présente-toi" look like a request for every production module. The identity
    already comes from the Core and Persona chunks; retrieval is reserved for a
    concrete user subject.
    """
    generic = {
        "presente", "presentation", "aerith", "bonjour", "salut", "bonsoir", "merci",
        "peux", "faire", "servir", "dis", "moi", "toi", "tu", "vous", "est", "es",
        "qui", "quoi", "comment", "quel", "quelle", "core", "persona", "role", "rôle",
        "actif", "active", "sources", "chargees", "chargées", "aide", "aider",
    }
    raw = [t for t in normalize_tokens(query) if t not in RAG_STOPWORDS and t not in generic]
    # Require two specific terms before automatic documentary retrieval.
    # One short explicit technical term (Wan, DaVinci, ComfyUI…) is sufficient.
    technical = {"wan", "davinci", "comfyui", "runninghub", "i2v", "lastframe", "last", "frame", "lego", "elevenlabs", "youtube"}
    if any(t in technical for t in raw):
        return raw[:24]
    return raw[:24] if len(raw) >= 2 else []


def is_explicit_local_research_request(query: str) -> bool:
    """La recherche documentaire est volontaire : aucun rappel automatique caché."""
    return False


def local_topic_route_patterns(tokens: list[str]) -> tuple[str, ...]:
    """Aucun classement idéologique ou personnel n’est codé dans le routeur."""
    return ()


def automatic_pack_route(query: str, core_key: str, runtime_mode: str = "fast") -> list[dict[str, str]]:
    """Aucun pack ne se déclenche à partir de mots du chat.

    Le créateur choisit explicitement les options de packs dans l’interface.
    """
    return []


def should_expand_documentary_context(query: str, full_available: bool, active_packs: list[str], pinned_chunk_ids: list[str] | None) -> bool:
    if pinned_chunk_ids:
        return True
    if full_available or active_packs:
        return bool(retrieval_tokens(query, "aerith7"))
    # Local Recall: for a substantive question, the Coffre may propose a single
    # relevant section even in Rapide. This reproduces the useful part of manual
    # Ollama attachments without flooding the context.
    return is_explicit_local_research_request(query)


def chunk_score(chunk: dict[str, Any], tokens: list[str], core_key: str, allowed_source_ids: set[str], selected_pack_names: set[str], base_source_ids: set[str]) -> int:
    """Classe un passage par précision documentaire, sans activer de pack.

    Les mots présents seulement dans le corps d'un Core très large ne doivent pas
    écraser un titre ou un chemin qui correspond exactement à la demande. FULL
    reste une recherche volontaire dans tout le Coffre ; cette fonction ne route
    jamais vers un pack et ne charge aucune source hors sélection.
    """
    heading = str(chunk.get("heading") or "").lower()
    title = str(chunk.get("title") or "").lower()
    relative_path = str(chunk.get("relative_path") or "").lower()
    tags_text = " ".join(str(x) for x in (chunk.get("tags") or [])).lower()
    body = str(chunk.get("text") or "").lower()
    score = 0
    distinct_matches = 0
    precise_matches = 0
    for token in tokens:
        needle = token.lower()
        body_count = min(body.count(needle), 4)
        heading_count = heading.count(needle)
        title_count = title.count(needle)
        path_count = relative_path.count(needle)
        tags_count = tags_text.count(needle)
        if body_count or heading_count or title_count or path_count or tags_count:
            distinct_matches += 1
        if heading_count or title_count or path_count or tags_count:
            precise_matches += 1
        # Le contenu compte, mais le titre, l'intertitre et le chemin commandent
        # le classement lorsqu'ils correspondent explicitement au D.
        score += body_count * min(9, max(2, len(needle)))
        score += heading_count * 34
        score += title_count * 20
        score += path_count * 24
        score += tags_count * 16
    # Une recherche de plusieurs termes privilégie les passages qui couvrent
    # vraiment la demande, puis ceux qui la nomment explicitement.
    if len(tokens) >= 2:
        if distinct_matches >= 2:
            score += 55 + 9 * distinct_matches
        elif distinct_matches == 1:
            score -= 36
        if precise_matches >= 2:
            score += 42 + 8 * precise_matches
    source_id = str(chunk.get("source_id") or "")
    if source_id in base_source_ids:
        score += 17
    if source_id in allowed_source_ids:
        score += 10
    if canonical_pack_name(str(chunk.get("source_name") or "")) in selected_pack_names:
        score += 9
    tags = {str(x).lower() for x in (chunk.get("tags") or [])}
    if core_key == "night" and "night" in tags:
        score += 12
    if core_key == "sun" and "sun" in tags:
        score += 12
    if core_key == "aerith10" and "aerith-10" in tags:
        score += 12
    if chunk.get("low_priority"):
        score -= 8
    return score



def runtime_capsule(core_key: str) -> dict[str, Any]:
    return CORE_RUNTIME_CAPSULES.get(core_key, CORE_RUNTIME_CAPSULES["aerith7"])


def _norm_heading(value: str) -> str:
    return normalized_identity_text(str(value or ""))


def runtime_identity_chunks(rag: dict[str, Any], core_key: str) -> list[dict[str, Any]]:
    """Select canonical identity/voice/operational sections instead of the first
    chunk of a file (which can be a Git protection lock or unrelated metadata)."""
    rules = runtime_capsule(core_key).get("sections") or []
    out: list[dict[str, Any]] = []
    used: set[str] = set()
    for path, required_terms in rules:
        wanted = [_norm_heading(t) for t in required_terms]
        candidates = [c for c in rag.get("chunks", []) if str(c.get("relative_path") or "") == str(path)]
        best = None
        best_score = -1
        for c in candidates:
            heading = _norm_heading(str(c.get("heading") or ""))
            score = sum(1 for term in wanted if term and term in heading)
            # Permit a single distinctive term if the chunk is genuinely the canonical heading.
            if score and score > best_score:
                best, best_score = c, score
        if best:
            cid = str(best.get("id") or "")
            if cid and cid not in used:
                out.append({**best, "score": 10_000 - len(out), "use_type": "identité canonique"})
                used.add(cid)
    return out


def mandatory_boot_chunks(rag: dict[str, Any], core_key: str) -> list[dict[str, Any]]:
    """Select one canonical foundation section from every required boot file.

    This is deliberately deterministic. It is not a keyword recall and it does
    not depend on FULL, packs, or the current user sentence.
    """
    chunks = rag.get("chunks", []) if isinstance(rag.get("chunks"), list) else []
    selected: list[dict[str, Any]] = []
    used: set[str] = set()
    for path in boot_dependency_paths(core_key):
        candidates = [c for c in chunks if str(c.get("relative_path") or "") == path]
        if not candidates:
            continue
        hints = tuple(_norm_heading(h) for h in BOOT_SECTION_HINTS.get(path, ()) if h)
        best = None
        best_score = -1
        for candidate in candidates:
            heading = _norm_heading(str(candidate.get("heading") or ""))
            # The declared hint order is intentional: it selects Identity before
            # generic file metadata when both headings exist.
            score = 0
            for rank, hint in enumerate(hints):
                if hint and hint in heading:
                    score = max(score, 10_000 - rank)
            # Canonical heading match commands. When the source has no matching
            # heading, retain its first real passage rather than dropping it.
            if score > best_score:
                best, best_score = candidate, score
        if best is None:
            continue
        cid = str(best.get("id") or "")
        if cid and cid not in used:
            selected.append({**best, "score": 20_000 - len(selected), "use_type": "boot Seven obligatoire"})
            used.add(cid)
    return selected


def boot_backbone_text() -> str:
    """Return only the constitution contained in the Modelfile.

    Ollama uses FROM/PARAMETER while building aerith:base. Those directives are
    not conversational content and must never be re-injected into /api/chat.
    """
    try:
        raw = MODELFILE_PATH.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return "Constitution Aerith-7 introuvable."
    match = re.search(r'SYSTEM\s+"""(.*?)"""', raw, flags=re.IGNORECASE | re.DOTALL)
    constitution = match.group(1).strip() if match else raw
    return "CONSTITUTION AERITH-7 — SEVEN HEAVEN\n\n" + constitution


def boot_backbone_sha() -> str:
    try:
        return sha_id(MODELFILE_PATH.read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return "absent"


def retrieve_chunks(index: dict[str, Any], core_key: str, selected_ids: list[str], active_packs: list[str], query: str, full_available: bool, runtime_mode: str = "fast", auto_packs: list[dict[str, str]] | None = None) -> list[dict[str, Any]]:
    """Construit la pile réelle : identité canonique et renforts choisis.

    Aucun pack ne se déclenche à partir de mots du chat. Un pack ajouté dans le
    Coffre délimite seulement les documents que l'application peut relire.
    """
    profile = runtime_profile(runtime_mode)
    rag = get_rag_index(index)
    mapping = source_map(index)
    selected_ids_set = {str(i) for i in selected_ids if str(i) in mapping}
    default_ids = {str(s.get("id")) for s in default_stack(index, core_key).get("sources", [])}
    manual_pack_names = {canonical_pack_name(str(x)) for x in active_packs if str(x).strip()}
    # Compatibilité d'appel : aucun renfort automatique n'est accepté ici.
    # Seuls les packs présents dans active_packs ont le droit d'ouvrir une zone de lecture.
    auto_pack_names: set[str] = set()
    effective_pack_names = set(manual_pack_names)

    # Les sections d'identité sont ajoutées séparément. Dès qu'un pack est choisi,
    # ses documents deviennent la seule zone de recherche automatique : Atlas ou
    # Core ne doivent pas voler la place du pack métier demandé.
    manual_source_ids = selected_ids_set - default_ids
    allowed = set(manual_source_ids)
    if effective_pack_names:
        for source in index.get("sources", []):
            if canonical_pack_name(str(source.get("source_name") or "")) in effective_pack_names and not source.get("blocked"):
                allowed.add(str(source.get("id")))
    tokens = retrieval_tokens(query, core_key)
    auto_recall = is_explicit_local_research_request(query) and not full_available and not effective_pack_names
    if full_available or auto_recall:
        allowed = {str(source.get("id")) for source in index.get("sources", []) if not source.get("blocked")}
    if not allowed:
        allowed = default_ids

    expand = should_expand_documentary_context(query, full_available, list(effective_pack_names), None)
    ranked: list[tuple[int, dict[str, Any]]] = []
    for chunk in rag.get("chunks", []):
        source_id = str(chunk.get("source_id") or "")
        if source_id not in allowed:
            continue
        score = chunk_score(chunk, tokens, core_key, allowed, effective_pack_names, default_ids)
        if score > 0:
            ranked.append((score, chunk))
    ranked.sort(key=lambda row: (-row[0], str(row[1].get("relative_path", "")), str(row[1].get("heading", ""))))

    result: list[dict[str, Any]] = []
    per_source: dict[str, int] = {}
    used_text: set[str] = set()

    def keep(score: int, chunk: dict[str, Any], use_type: str) -> bool:
        non_boot_count = sum(1 for row in result if str(row.get("use_type") or "") != "boot Seven obligatoire")
        if use_type != "boot Seven obligatoire" and non_boot_count >= int(profile["max_chunks"]):
            return False
        cid = str(chunk.get("id") or "")
        sid = str(chunk.get("source_id") or "")
        source_limit = 3 if use_type in {"identité canonique", "base Seven"} else MAX_RETRIEVED_PER_SOURCE
        if not cid or cid in used_text or per_source.get(sid, 0) >= source_limit:
            return False
        result.append({**chunk, "score": score, "use_type": use_type})
        used_text.add(cid)
        per_source[sid] = per_source.get(sid, 0) + 1
        return True

    # Boot réel : Core Aerith-7 + toutes ses dépendances déclarées, à chaque
    # requête. Cette chaîne ne dépend jamais de mots-clés, de FULL ou d’un pack.
    # Elle est la base Seven transmise avant toute recherche complémentaire.
    for chunk in mandatory_boot_chunks(rag, core_key):
        keep(int(chunk.get("score") or 20_000), chunk, "boot Seven obligatoire")

    # Une identité de route peut comporter une section supplémentaire, sans
    # remplacer le boot Seven. Elle n'est ajoutée que si elle n'est pas déjà là.
    for chunk in runtime_identity_chunks(rag, core_key):
        keep(int(chunk.get("score") or 10_000), chunk, "identité de route")

    if expand:
        for score, chunk in ranked:
            non_boot_count = sum(1 for row in result if str(row.get("use_type") or "") != "boot Seven obligatoire")
            if non_boot_count >= int(profile["max_chunks"]):
                break
            source_name = canonical_pack_name(str(chunk.get("source_name") or ""))
            sid = str(chunk.get("source_id") or "")
            if not full_available and not effective_pack_names and not auto_recall and sid not in selected_ids_set:
                continue
            if source_name in manual_pack_names:
                use_type = "renfort choisi"
            elif auto_recall:
                use_type = "rappel local"
            elif full_available:
                use_type = "recherche locale"
            else:
                use_type = "pile"
            keep(score, chunk, use_type)
    return result


def chunk_map(index: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(c.get("id")): c for c in get_rag_index(index).get("chunks", []) if isinstance(c, dict)}


def text_search_score(chunk: dict[str, Any], tokens: list[str], core_key: str, packs: set[str]) -> int:
    """Classe les textes pour une lecture humaine, pas pour une simple liste de fichiers."""
    heading = str(chunk.get("heading") or "").lower()
    title = str(chunk.get("title") or "").lower()
    path = str(chunk.get("relative_path") or "").lower()
    body = str(chunk.get("text") or "").lower()
    tags = {str(x).lower() for x in (chunk.get("tags") or [])}
    score = 0
    matched = 0
    for token in tokens:
        needle = token.lower()
        if not needle:
            continue
        body_count = min(body.count(needle), 4)
        if body_count:
            matched += 1
            score += body_count * max(2, min(6, len(needle)))
        if needle in heading:
            score += 38
        if needle in title:
            score += 28
        if needle in path:
            score += 20
        if needle in tags:
            score += 16
    # Une recherche de plusieurs mots doit privilégier les passages qui les couvrent réellement.
    score += matched * 22
    category = str(chunk.get("category") or "")
    production_words = {"wan", "davinci", "storyboard", "video", "i2v", "runninghub", "comfyui", "last", "frame", "montage"}
    if any(t in production_words for t in tokens) and category in {"Production", "Module", "Core"}:
        score += 14
    if core_key == "aerith10" and "aerith-10" in tags:
        score += 15
    if core_key == "night" and "night" in tags:
        score += 15
    if core_key == "sun" and "sun" in tags:
        score += 15
    if core_key == "constellation" and ("constellation" in tags or "flower girls" in tags):
        score += 15
    if str(chunk.get("source_name") or "") in packs:
        score += 12
    low = f"{path} {title}"
    # Les mémos de reconstruction et références de conversation sont utiles, mais ne doivent pas écraser les modules métier.
    if not any(t in {"memory", "memoire", "chatgpt", "reference", "references"} for t in tokens):
        if any(marker in low for marker in ("chatgpt_saved_memory", "saved_memory", "reference", "references", "changelog", "archive")):
            score -= 28
    if chunk.get("low_priority"):
        score -= 12
    return score


def readable_excerpt(body: str, tokens: list[str], limit: int = 760) -> str:
    """Extrait le passage le plus pertinent d'une section Markdown/TXT, pas son front-matter."""
    body = re.sub(r"^---\s*\n.*?\n---\s*\n", "", body.strip(), flags=re.DOTALL)
    body = re.sub(r"^#{1,6}\s+[^\n]+\n?", "", body).strip()
    chunks = [p.strip() for p in re.split(r"\n\s*\n+", body) if p.strip()]
    if not chunks:
        return body[:limit] + ("…" if len(body) > limit else "")
    def score_part(part: str) -> int:
        lowered = part.lower()
        score = 0
        for token in tokens:
            count = min(lowered.count(token.lower()), 4)
            if count:
                score += count * max(2, min(8, len(token)))
        if len(part) < 45:
            score -= 10
        if part.lower().startswith(("statut :", "famille :", "domaine :", "usage :", "date :")):
            score -= 9
        return score
    best_index = max(range(len(chunks)), key=lambda i: score_part(chunks[i]))
    selected = [chunks[best_index]]
    # Ajouter une ligne suivante seulement si elle apporte un contexte utile.
    if best_index + 1 < len(chunks) and len(selected[0]) < limit * 0.62:
        selected.append(chunks[best_index + 1])
    excerpt = "\n\n".join(selected).strip()
    excerpt = re.sub(r"(?m)^\s*[-*]\s+", "• ", excerpt)
    return excerpt[:limit].rstrip() + ("…" if len(excerpt) > limit else "")


def text_search_chunks(index: dict[str, Any], core_key: str, query: str, active_packs: list[str] | None = None, limit: int = 12) -> list[dict[str, Any]]:
    """Recherche dans Markdown/TXT uniquement et renvoie des passages lisibles, un par document."""
    tokens = retrieval_tokens(query, core_key)
    packs = {str(x) for x in (active_packs or []) if str(x).strip()}
    ranked: list[tuple[int, dict[str, Any]]] = []
    for chunk in get_rag_index(index).get("chunks", []):
        score = text_search_score(chunk, tokens, core_key, packs)
        if score > 0:
            ranked.append((score, chunk))
    ranked.sort(key=lambda r: (-r[0], str(r[1].get("relative_path") or ""), str(r[1].get("heading") or "")))
    rows: list[dict[str, Any]] = []
    used_sources: set[str] = set()
    seen_text: set[str] = set()
    for score, chunk in ranked:
        source_id = str(chunk.get("source_id") or "")
        if not source_id or source_id in used_sources:
            continue
        body = str(chunk.get("text") or "").strip()
        signature = sha_id(" ".join(normalize_tokens(body)))
        if signature in seen_text:
            continue
        seen_text.add(signature)
        used_sources.add(source_id)
        rows.append({
            "id": str(chunk.get("id") or ""),
            "source_id": source_id,
            "relative_path": str(chunk.get("relative_path") or ""),
            "title": str(chunk.get("title") or "Texte local"),
            "heading": str(chunk.get("heading") or "Section"),
            "origin": str(chunk.get("origin") or "local"),
            "category": str(chunk.get("category") or "Texte"),
            "score": score,
            "excerpt": readable_excerpt(body, tokens),
        })
        if len(rows) >= max(1, min(limit, 18)):
            break
    return rows


def read_text_chunk(index: dict[str, Any], chunk_id: str) -> dict[str, Any] | None:
    row = chunk_map(index).get(str(chunk_id))
    if not row:
        return None
    body = re.sub(r"^##\s+[^\n]+\n?", "", str(row.get("text") or "").strip()).strip()
    return {
        "id": str(row.get("id") or ""),
        "source_id": str(row.get("source_id") or ""),
        "title": str(row.get("title") or "Texte local"),
        "relative_path": str(row.get("relative_path") or ""),
        "heading": str(row.get("heading") or "Section"),
        "origin": str(row.get("origin") or "local"),
        "text": body,
    }

def source_rows_from_chunks(index: dict[str, Any], chunks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    mapping = source_map(index)
    grouped: dict[str, dict[str, Any]] = {}
    for chunk in chunks:
        source_id = str(chunk.get("source_id") or "")
        source = mapping.get(source_id)
        if source:
            public = sanitize_source(source)
        elif str(chunk.get("kind") or "") == "web" or source_id.startswith("web:"):
            public = {
                "id": source_id,
                "kind": "web",
                "source_name": str(chunk.get("source_name") or "URL publique temporaire"),
                "relative_path": str(chunk.get("relative_path") or chunk.get("url") or "URL publique"),
                "title": str(chunk.get("title") or "URL publique"),
                "category": "Web",
                "tags": list(chunk.get("tags") or ["Web", "temporaire"]),
                "size": 0,
                "blocked": False,
                "block_reason": "",
                "manifest": False,
                "modified": str(chunk.get("modified") or ""),
                "origin": str(chunk.get("origin") or "lecture URL ponctuelle"),
            }
        else:
            continue
        row = grouped.setdefault(source_id, {**public, "loaded": True, "chars": 0, "use_types": [], "headings": []})
        row["chars"] += len(str(chunk.get("text") or ""))
        if chunk.get("use_type") and chunk["use_type"] not in row["use_types"]:
            row["use_types"].append(chunk["use_type"])
        if chunk.get("heading") and chunk["heading"] not in row["headings"]:
            row["headings"].append(chunk["heading"])
    return list(grouped.values())


def pack_bootstrap_sources(index: dict[str, Any], pack_name: str) -> list[dict[str, Any]]:
    """Documents réels joints lorsqu'un pack est choisi dans le Coffre.

    Pack 01 : INDEX + MANIFEST + README.
    Packs 02 à 07 : MANIFEST + README.
    Aucun mot-clé de chat ne peut déclencher ce chargement.
    """
    canonical = canonical_pack_name(pack_name)
    if canonical not in PACK_CATALOG:
        return []
    candidates = [
        source for source in index.get("sources", [])
        if canonical_pack_name(str(source.get("source_name") or "")) == canonical
        and not source.get("blocked")
    ]
    expected = PACK_BOOTSTRAP_FILES if canonical == STARTUP_PACK_01 else ("MANIFEST.md", "README.md")
    selected: list[dict[str, Any]] = []
    for filename in expected:
        found = next(
            (source for source in candidates if Path(str(source.get("relative_path") or "")).name.upper() == filename.upper()),
            None,
        )
        if found:
            selected.append(found)
    return selected


def starter_pack_sources(index: dict[str, Any], pack_name: str) -> list[dict[str, Any]]:
    """Compatibilité : le raccourci « Minimum + Pack 01 » utilise Pack 01."""
    canonical = canonical_pack_name(pack_name)
    return pack_bootstrap_sources(index, canonical) if canonical == STARTUP_PACK_01 else []

def pack_inventory(index: dict[str, Any], pack_name: str) -> dict[str, Any]:
    """Inventaire déterministe du ZIP local ; jamais produit par le modèle."""
    canonical = canonical_pack_name(pack_name)
    if canonical not in PACK_CATALOG:
        raise ValueError("Pack ERITH-7 inconnu.")
    rows = [
        source for source in index.get("sources", [])
        if canonical_pack_name(str(source.get("source_name") or "")) == canonical
        and not source.get("blocked")
    ]
    rows.sort(key=lambda source: str(source.get("relative_path") or "").lower())
    return {
        "name": canonical,
        "label": PACK_CATALOG[canonical]["label"],
        "role": PACK_CATALOG[canonical]["role"],
        "count": len(rows),
        "files": [str(source.get("relative_path") or "") for source in rows],
    }


def requested_pack_inventory(message: str) -> str:
    """Recognise only an explicit request to list a Pack's files."""
    low = normalized_identity_text(message)
    if not any(cue in low for cue in ("liste", "lister", "inventaire", "fichiers", "fichier", "contenu")):
        return ""
    match = re.search(r"\bpack\s*0?([1-7])\b", low)
    if match:
        return f"ERITH_7_0{match.group(1)}_"  # symbolic, resolved below
    if "core boot" in low:
        return STARTUP_PACK_01
    return ""


def resolved_inventory_pack(symbolic: str) -> str:
    if symbolic in PACK_CATALOG:
        return symbolic
    if symbolic.startswith("ERITH_7_0") and symbolic.endswith("_"):
        number = symbolic.split("_")[2]
        return next((name for name in PACK_CATALOG if name.startswith(f"ERITH_7_{number}_")), "")
    return ""


def verified_pack_inventory_response(index: dict[str, Any], pack_name: str) -> str:
    inventory = pack_inventory(index, pack_name)
    lines = [
        f"{inventory['label']} — inventaire déterministe : {inventory['count']} fichiers réels.",
        "Cette liste vient directement de l’archive locale, pas d’Ollama.",
        "",
        *[f"- {path}" for path in inventory["files"]],
    ]
    return "\n".join(lines)


def requested_archive_count_summary(message: str) -> bool:
    """Recognise one message that asks both the Coffre total and the active count.

    The two quantities are different: FULL may make all packs searchable without
    making them active. This response is application-owned so a local model cannot
    answer only one half of a double factual question.
    """
    low = normalized_identity_text(message)
    asks_count = any(token in low for token in ("combien", "nombre", "total"))
    mentions_archive = any(token in low for token in ("archive", "archives", "zip", "coffre", "pack", "packs"))
    active_cues = (
        "active", "actives", "actif", "actifs", "charge", "charges",
        "chargee", "chargees", "selectionne", "selectionnes", "selectionnee", "selectionnees",
    )
    total_scope_cues = ("coffre", "au total", "en tout", "total", "presente", "presentes")
    return asks_count and mentions_archive and any(cue in low for cue in active_cues) and any(cue in low for cue in total_scope_cues)


def verified_archive_count_summary_response(
    index: dict[str, Any],
    active_packs: Iterable[str | Path | None],
    startup_pack: str = "",
) -> tuple[str, list[dict[str, Any]]]:
    """Report Coffre size and active pack state in one deterministic response."""
    bundled_rows = bundled_archive_rows(index)
    active_names = effective_active_pack_names(active_packs, startup_pack)
    lines = [
        f"Coffre local : {len(bundled_rows)} archives ZIP ERITH-7.",
        f"Archives actives : {len(active_names)}.",
        "Les deux comptages sont vérifiés par l’application : le Coffre et la pile sont deux états distincts.",
        "",
        "Archives présentes :",
        *[f"- {PACK_CATALOG[canonical_pack_name(str(row.get('name') or ''))]['label']}" for row in bundled_rows if canonical_pack_name(str(row.get('name') or '')) in PACK_CATALOG],
        "",
        "Archives actives :",
    ]
    if active_names:
        lines.extend(f"- {PACK_CATALOG[name]['label']}" for name in active_names)
    else:
        lines.append("- aucune : session Minimum")
    sources = capability_overview_sources(index, [canonical_pack_name(str(row.get("name") or "")) for row in bundled_rows])
    sources.extend(active_archive_state_sources(index, active_names))
    return "\n".join(lines), sources


def requested_pack_state_overview(message: str) -> bool:
    """Recognise a combined factual request about Coffre availability and pile state.

    This is a strict application-owned report. It prevents a model from confusing
    the number of archive files physically present with the smaller set of packs
    currently selected by the operator.
    """
    low = normalized_identity_text(message)
    asks = any(token in low for token in ("combien", "nombre", "quel", "quels", "quelle", "quelles", "liste"))
    scope = any(token in low for token in ("archive", "archives", "zip", "coffre", "pack", "packs"))
    active = any(token in low for token in (
        "active", "actives", "actif", "actifs", "charge", "charges",
        "chargee", "chargees", "selectionne", "selectionnes", "selectionnee", "selectionnees",
    ))
    available = any(token in low for token in (
        "disponible", "disponibles", "present", "presents", "presente", "presentes",
        "dans le coffre", "coffre",
    ))
    # A combined request must mention both the public Coffre view and the active
    # session view. A plain "combien sont actives" remains handled by the narrower
    # active-count response below.
    return asks and scope and active and available


def verified_pack_state_overview_response(
    index: dict[str, Any],
    active_packs: Iterable[str | Path | None],
    startup_pack: str = "",
    full_available: bool = False,
) -> tuple[str, list[dict[str, Any]]]:
    """Return the complete Coffre/pile state in canonical order, without Ollama."""
    rows = bundled_archive_rows(index)
    available_names = [canonical_pack_name(str(row.get("name") or "")) for row in rows]
    active_names = effective_active_pack_names(active_packs, startup_pack)
    lines = [
        "État du Coffre et de la pile vérifié par l’application.",
        "",
        f"Archives disponibles dans le Coffre : {len(available_names)}.",
        *[f"- {PACK_CATALOG[name]['label']}" for name in available_names if name in PACK_CATALOG],
        "",
        f"Archives actives dans la pile : {len(active_names)}.",
    ]
    if active_names:
        lines.extend(f"- {PACK_CATALOG[name]['label']}" for name in active_names)
    else:
        lines.append("- aucune : session Minimum")
    lines.extend([
        "",
        (
            "FULL DISPONIBLE : actif — recherche ciblée autorisée dans le Coffre, sans ajouter les autres packs à la pile active."
            if full_available else
            "FULL DISPONIBLE : inactif — seuls Minimum, les packs actifs et les pièces explicitement ajoutées sont consultables."
        ),
    ])
    sources = capability_overview_sources(index, available_names)
    sources.extend(active_archive_state_sources(index, active_names))
    return "\n".join(lines), sources


def requested_bundled_archive_total(message: str) -> bool:
    """Recognise a direct factual question about the ERITH-7 ZIP count.

    This is application-owned state. It must never be delegated to Ollama, which
    may only see the currently attached bootstrap files and can confuse their
    count with the number of archives physically present in the local Coffre.
    """
    if requested_active_archive_count(message):
        return False
    low = normalized_identity_text(message)
    asks_count = any(token in low for token in ("combien", "nombre", "total"))
    mentions_archive = "archive" in low or "archives" in low or "zip" in low
    return asks_count and mentions_archive


def bundled_archive_rows(index: dict[str, Any]) -> list[dict[str, Any]]:
    """Return only the official embedded ERITH-7 ZIP rows in canonical order.

    `index["packs"]` is produced directly from the local `library/packs/*.zip`
    scan. The list deliberately excludes a user-selected Git mirror and any
    unrelated ZIP that may exist outside the application Coffre.
    """
    rows_by_name: dict[str, dict[str, Any]] = {}
    for row in index.get("packs", []):
        if not isinstance(row, dict):
            continue
        canonical = canonical_pack_name(str(row.get("name") or ""))
        if canonical in PACK_CATALOG:
            rows_by_name[canonical] = row
    return [rows_by_name[name] for name in PACK_ORDER if name in rows_by_name]


def verified_bundled_archive_total_response(index: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    """Give a deterministic answer for the count of local ERITH-7 archives.

    The seven manifest rows are attached to the source footnote because each row
    is read from an archive the index has actually opened. This keeps the proof
    visible without pretending that all archives were sent to Ollama.
    """
    rows = bundled_archive_rows(index)
    names = [canonical_pack_name(str(row.get("name") or "")) for row in rows]
    labels = [PACK_CATALOG[name]["label"] for name in names if name in PACK_CATALOG]
    answer_lines = [
        f"Il y a {len(rows)} archives ZIP ERITH-7 dans le Coffre local.",
        "Comptage vérifié directement par l’application à partir des archives indexées, pas par Ollama.",
    ]
    if labels:
        answer_lines.extend(["", "Archives présentes :", *[f"- {label}" for label in labels]])
    return "\n".join(answer_lines), capability_overview_sources(index, names)


def requested_active_archive_count(message: str) -> bool:
    """Recognise an explicit count request about archives currently active.

    This must be handled before the generic archive-total handler. Otherwise a
    short question such as ``combien sont actives à présent ?`` can be delegated
    to Ollama, which only sees excerpts and may invent a stale pack list.
    """
    low = normalized_identity_text(message)
    asks_count = any(token in low for token in ("combien", "nombre", "total"))
    active_cues = (
        "active", "actives", "actif", "actifs", "charge", "charges",
        "chargee", "chargees", "selectionne", "selectionnes", "selectionnee", "selectionnees",
    )
    scope_cues = (
        "archive", "archives", "zip", "pack", "packs", "coffre",
        "sont actives", "sont active", "sont actifs", "sont actif",
        "actives a present", "active a present", "actifs a present", "actif a present",
    )
    return asks_count and any(cue in low for cue in active_cues) and any(cue in low for cue in scope_cues)


def effective_active_pack_names(active_packs: Iterable[str | Path | None], startup_pack: str = "") -> list[str]:
    """Return the actual pack state shown by the UI, in canonical 01→07 order.

    Pack 01 lives in ``startup_pack`` in the frontend so it does not appear in
    ``selected_packs``. It is nevertheless an active archive and must be counted
    exactly once whenever Minimum + Pack 01 is selected.
    """
    names: list[str | Path | None] = list(active_packs)
    if canonical_pack_name(startup_pack) == STARTUP_PACK_01:
        names.append(STARTUP_PACK_01)
    return ordered_pack_names(names)


def active_archive_state_sources(index: dict[str, Any], pack_names: list[str]) -> list[dict[str, Any]]:
    """Attach only manifest rows used to prove an active-pack count."""
    rows: list[dict[str, Any]] = []
    for pack_name in pack_names:
        source = _manifest_source_for_pack(index, pack_name)
        if not source:
            continue
        rows.append({
            **sanitize_source(source),
            "loaded": True,
            "chars": 0,
            "use_types": ["État des archives actives vérifié"],
            "headings": ["MANIFEST actif"],
        })
    return rows


def verified_active_archive_count_response(
    index: dict[str, Any],
    active_packs: Iterable[str | Path | None],
    startup_pack: str = "",
) -> tuple[str, list[dict[str, Any]]]:
    """Give a deterministic count of the packs truly active in this session."""
    names = effective_active_pack_names(active_packs, startup_pack)
    if not names:
        return (
            "Aucune archive ERITH-7 n’est active : la session est en Minimum."
            "\nLe Comptage lit l’état réel de la pile locale, pas une réponse Ollama.",
            [],
        )
    labels = [PACK_CATALOG[name]["label"] for name in names]
    answer_lines = [
        f"Il y a {len(names)} archive{'s' if len(names) > 1 else ''} ERITH-7 active{'s' if len(names) > 1 else ''} dans la pile locale.",
        "Comptage vérifié directement par l’application à partir de l’état de session, pas par Ollama.",
        "",
        "Archives actives :",
        *[f"- {label}" for label in labels],
    ]
    return "\n".join(answer_lines), active_archive_state_sources(index, names)

def requested_active_archive_state(message: str) -> bool:
    """Recognise a request to list the packs active now, even without a count.

    This stays application-owned so a question such as ``quels packs sont actifs``
    cannot fall through to Ollama and reconstruct a stale state from README files.
    """
    low = normalized_identity_text(message)
    asks = any(token in low for token in (
        "quel", "quels", "quelle", "quelles", "liste", "montre", "dis moi", "etat",
        "combien", "nombre", "total",
    ))
    active = any(token in low for token in (
        "active", "actives", "actif", "actifs", "charge", "charges",
        "chargee", "chargees", "selectionne", "selectionnes", "selectionnee", "selectionnees",
    ))
    scope = any(token in low for token in ("archive", "archives", "zip", "pack", "packs", "coffre", "pile"))
    return asks and active and scope


def verified_active_archive_state_response(
    index: dict[str, Any],
    active_packs: Iterable[str | Path | None],
    startup_pack: str = "",
    full_available: bool = False,
) -> tuple[str, list[dict[str, Any]]]:
    """List the active archives from the single server session, in 01→07 order."""
    names = effective_active_pack_names(active_packs, startup_pack)
    lines = ["État de la pile vérifié par l’application.", ""]
    if names:
        lines.extend([
            f"Archives actives dans la pile : {len(names)}.",
            *[f"- {PACK_CATALOG[name]['label']}" for name in names],
        ])
    else:
        lines.extend([
            "Archives actives dans la pile : 0.",
            "- aucune : session Minimum",
        ])
    lines.extend([
        "",
        (
            "FULL DISPONIBLE : actif — recherche ciblée autorisée dans le Coffre sans rendre les autres packs actifs."
            if full_available else
            "FULL DISPONIBLE : inactif — seuls Minimum, les packs actifs et les pièces explicitement jointes sont consultables."
        ),
    ])
    return "\n".join(lines), active_archive_state_sources(index, names)



# Un fichier nommé explicitement par Christophe est une sélection volontaire de
# source, pas un routage de pack. Il n'est accepté que s'il appartient déjà à
# la pile minimale, à un pack choisi, à une pièce manuelle ou au mode FULL.
FILE_REFERENCE_RE = re.compile(
    r"(?<![A-Za-z0-9_.-])((?:[A-Za-z0-9_.-]+[\\/])*[A-Za-z0-9][A-Za-z0-9_.-]*\.(?:md|txt|json|ya?ml))(?![A-Za-z0-9_.-])",
    flags=re.IGNORECASE,
)


def requested_file_references(message: str) -> list[str]:
    refs: list[str] = []
    for match in FILE_REFERENCE_RE.finditer(str(message or "")):
        ref = match.group(1).replace("\\", "/").lstrip("./").strip()
        key = ref.casefold()
        if ref and key not in {item.casefold() for item in refs}:
            refs.append(ref)
    return refs[:2]


def source_scope_for_explicit_file(
    index: dict[str, Any],
    core_key: str,
    selected_ids: list[str],
    active_packs: list[str],
    full_available: bool,
    startup_pack: str,
) -> tuple[set[str], set[str], bool]:
    """Return only the sources the operator has explicitly made readable."""
    default_ids = {str(row.get("id")) for row in default_stack(index, core_key).get("sources", [])}
    manual_ids = {str(item) for item in selected_ids if str(item)}
    selected_packs = {canonical_pack_name(item) for item in active_packs if canonical_pack_name(item)}
    startup_active = canonical_pack_name(startup_pack) == STARTUP_PACK_01
    if startup_active:
        selected_packs.add(STARTUP_PACK_01)
    scope = set(default_ids) | set(manual_ids)
    if full_available:
        scope.update(str(source.get("id")) for source in index.get("sources", []) if not source.get("blocked"))
    else:
        for source in index.get("sources", []):
            if source.get("blocked"):
                continue
            if canonical_pack_name(str(source.get("source_name") or "")) in selected_packs:
                scope.add(str(source.get("id")))
    return scope, selected_packs, startup_active


def requested_file_source(
    index: dict[str, Any],
    core_key: str,
    selected_ids: list[str],
    active_packs: list[str],
    query: str,
    full_available: bool,
    startup_pack: str,
) -> dict[str, Any] | None:
    """Resolve an explicit Markdown/TXT/JSON/YAML file reference deterministically.

    A filename alone is supported when it is unique in the visible operator scope.
    If several copies exist, the chosen pack wins, then a manual attachment, then
    the minimum stack. No unavailable pack is opened by naming one of its files.
    """
    refs = requested_file_references(query)
    if not refs:
        return None
    scope, selected_packs, startup_active = source_scope_for_explicit_file(
        index, core_key, selected_ids, active_packs, full_available, startup_pack,
    )
    if not scope:
        return None
    default_ids = {str(row.get("id")) for row in default_stack(index, core_key).get("sources", [])}
    manual_ids = {str(item) for item in selected_ids if str(item)}
    candidates = [
        source for source in index.get("sources", [])
        if str(source.get("id")) in scope and not source.get("blocked")
    ]
    for ref in refs:
        ref_norm = ref.casefold()
        wants_path = "/" in ref_norm
        matches = []
        for source in candidates:
            rel = str(source.get("relative_path") or "").replace("\\", "/")
            if not rel:
                continue
            matched = rel.casefold() == ref_norm if wants_path else Path(rel).name.casefold() == ref_norm
            if matched:
                matches.append(source)
        if not matches:
            continue
        def rank(source: dict[str, Any]) -> tuple[int, int, int, str]:
            sid = str(source.get("id") or "")
            pack = canonical_pack_name(str(source.get("source_name") or ""))
            # A deliberate pack selection is authoritative for duplicate paths.
            scope_rank = 0 if pack in selected_packs else (1 if sid in manual_ids else (2 if sid in default_ids else 3))
            kind_rank = {"repo": 0, "seed": 1, "zip": 2}.get(str(source.get("kind") or ""), 9)
            startup_rank = 0 if (startup_active and pack == STARTUP_PACK_01) else 1
            return (scope_rank, startup_rank, kind_rank, str(source.get("relative_path") or "").casefold())
        matches.sort(key=rank)
        source = dict(matches[0])
        source["requested_reference"] = ref
        return source
    return None



def requested_full_scope_status(message: str) -> bool:
    """Recognise an explicit request about what FULL DISPONIBLE does."""
    low = normalized_identity_text(message)
    has_full = "full" in low
    asks_meaning = any(cue in low for cue in (
        "a quoi sert", "ca sert", "sert a quoi", "que fait", "signifie", "explique",
        "c est quoi", "cest quoi", "full disponible", "full actif", "full active",
    ))
    return has_full and asks_meaning


def verified_full_scope_response(
    index: dict[str, Any],
    active_packs: Iterable[str | Path | None],
    startup_pack: str,
    full_available: bool,
) -> tuple[str, list[dict[str, Any]]]:
    """Explain FULL as a search permission, never as a hidden activation."""
    active_names = effective_active_pack_names(active_packs, startup_pack)
    state = "actif" if full_available else "inactif"
    lines = [
        f"FULL DISPONIBLE est {state}.",
        "FULL autorise une recherche ponctuelle et ciblée dans les packs du Coffre ; il ne charge pas les archives entières dans Ollama.",
        "FULL ne modifie ni le nombre de packs actifs ni la pile permanente.",
        "",
        f"Packs actifs maintenant : {len(active_names)}.",
    ]
    if active_names:
        lines.extend(f"- {PACK_CATALOG[name]['label']}" for name in active_names)
    else:
        lines.append("- aucun : session Minimum")
    if full_available:
        inactive = [name for name in PACK_ORDER if name not in active_names]
        lines.extend([
            "",
            "Packs consultables ponctuellement via FULL sans devenir actifs :",
            *[f"- {PACK_CATALOG[name]['label']}" for name in inactive],
        ])
    sources = capability_overview_sources(index, list(PACK_ORDER))
    sources.extend(active_archive_state_sources(index, active_names))
    return "\n".join(lines), sources


def requested_documentary_route_lookup(message: str) -> bool:
    """Recognise a deliberate request to find a module/path in the Coffre.

    This does not activate anything. It only switches a clearly phrased lookup
    from generative wording to a local, verifiable answer.
    """
    low = normalized_identity_text(message)
    lookup_cues = (
        "cherche", "trouve", "recherche", "quel module", "quel fichier", "donne son chemin",
        "donne le chemin", "ou est", "ou se trouve", "montre le module", "montre le fichier",
    )
    return any(cue in low for cue in lookup_cues)


def verified_documentary_route_lookup_response(
    index: dict[str, Any],
    routes: list[dict[str, Any]],
    query: str,
) -> tuple[str, list[dict[str, Any]]]:
    """Return readable, source-grounded paths for an already-authorized route."""
    lines = ["Recherche locale ciblée vérifiée."]
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for route in routes:
        route_rows = documentary_route_sources(index, route)
        if not route_rows:
            continue
        label = str(route.get("label") or "Route documentaire")
        pack_name = str(route.get("pack") or "")
        pack_label = str(PACK_CATALOG.get(pack_name, {}).get("label") or pack_name)
        lines.extend(["", f"{label} — {pack_label} :"])
        for source in route_rows:
            source_id = str(source.get("id") or "")
            try:
                body = read_source(source)
                excerpt = readable_excerpt(body, retrieval_tokens(query, "aerith7"), limit=520)
            except (OSError, ValueError, PermissionError, zipfile.BadZipFile):
                excerpt = "Passage local indisponible."
            lines.append(f"- `{source.get('relative_path')}`")
            lines.append(f"  {excerpt.replace(chr(10), ' ').strip()}")
            if source_id and source_id not in seen:
                rows.append({
                    **sanitize_source(source),
                    "loaded": True,
                    "chars": 0,
                    "use_types": [documentary_route_use_type(route)],
                    "headings": [str(source.get("title") or source.get("relative_path") or "Source route")],
                })
                seen.add(source_id)
    return "\n".join(lines), rows


def requested_documentary_activation(message: str) -> bool:
    """Recognise a request phrased as an activation of a documentary topic.

    It never mutates packs. It gives a transparent status report instead of letting
    the model claim that a module was silently activated by a sentence.
    """
    low = normalized_identity_text(message)
    activation = ("active", "activer", "active le module", "active les modules", "module active", "modules actifs")
    topical = ("psychologie", "philosophie", "public agent", "agent public", "wan", "davinci", "comfyui", "runninghub")
    return any(cue in low for cue in activation) and any(cue in low for cue in topical)


def documentary_activation_status_response(
    index: dict[str, Any],
    message: str,
    active_packs: Iterable[str | Path | None],
    startup_pack: str = "",
    full_available: bool = False,
) -> tuple[str, list[dict[str, Any]]]:
    """Explain route availability without silently changing the session."""
    all_matches = [dict(rule) for rule in DOCUMENTARY_ROUTE_RULES if any(cue in normalized_identity_text(message) for cue in rule["cues"])]
    active = set(effective_active_pack_names(active_packs, startup_pack))
    lines = ["État documentaire vérifié par l’application.", ""]
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    unopened = False
    if not all_matches:
        return "Aucune route documentaire précise n’a été reconnue.", rows
    for route in all_matches:
        pack_name = str(route["pack"])
        pack_label = str(PACK_CATALOG.get(pack_name, {}).get("label", pack_name))
        pack_number = pack_label.split("·", 1)[0].strip() or pack_label
        pack_display = f"Pack {pack_number} — {pack_label.split('·', 1)[-1].strip()}"
        if pack_name in active:
            lines.append(f"{route['label']} : disponible, car {pack_display} est déjà actif.")
            lines.append("- aucun pack ni module n’a été activé par cette phrase ; la pile reste inchangée.")
            for source in documentary_route_sources(index, route):
                sid = str(source.get("id") or "")
                if sid and sid not in seen:
                    rows.append({
                        **sanitize_source(source),
                        "loaded": True,
                        "chars": 0,
                        "use_types": [documentary_route_use_type(route)],
                        "headings": [str(source.get("title") or source.get("relative_path") or "Source route")],
                    })
                    seen.add(sid)
        elif full_available:
            lines.append(f"{route['label']} : consultable ponctuellement via FULL dans {pack_display}.")
            lines.append("- la consultation ne rend pas ce pack actif et ne modifie pas la pile.")
            for source in documentary_route_sources(index, route):
                sid = str(source.get("id") or "")
                if sid and sid not in seen:
                    rows.append({
                        **sanitize_source(source),
                        "loaded": True,
                        "chars": 0,
                        "use_types": [documentary_route_use_type(route)],
                        "headings": [str(source.get("title") or source.get("relative_path") or "Source route")],
                    })
                    seen.add(sid)
        else:
            unopened = True
            lines.append(f"{route['label']} : non ouverte.")
            lines.append(f"- {pack_display} n’est pas actif et FULL est inactif ; l’application ne l’active pas par mot-clé.")
    if unopened:
        lines.extend(["", "Pour travailler sur ce thème, ajoute le pack concerné dans le Coffre ou active FULL pour une recherche ponctuelle."])
    return "\n".join(lines), rows


def requested_capabilities_overview(message: str) -> bool:
    """Recognise a clear request for the real options of the loaded Coffre.

    This handler is deliberately narrow. It does not replace normal discussion;
    it only prevents a small local model from improvising a generic capability
    list when Christophe explicitly asks what the selected Coffre can do.
    """
    low = normalized_identity_text(message)
    direct = (
        "toutes mes options", "toutes les options", "option disponible",
        "options disponibles", "mes possibilites", "possibilites disponibles",
        "capacites du coffre", "capacites disponibles", "que puis je faire",
        "que peux tu faire", "que peut tu faire", "a quoi sert le coffre",
    )
    scope = ("coffre", "pack", "charge", "charges", "chargee", "chargees", "bibliotheque")
    return any(cue in low for cue in direct) and (
        any(cue in low for cue in scope) or "que peux" in low or "que peut" in low or "que puis" in low
    )


def _manifest_source_for_pack(index: dict[str, Any], pack_name: str) -> dict[str, Any] | None:
    canonical = canonical_pack_name(pack_name)
    for source in index.get("sources", []):
        if source.get("blocked"):
            continue
        if canonical_pack_name(str(source.get("source_name") or "")) != canonical:
            continue
        if Path(str(source.get("relative_path") or "")).name.casefold() == "manifest.md":
            return source
    return None


def capability_overview_sources(index: dict[str, Any], pack_names: list[str]) -> list[dict[str, Any]]:
    """Source rows displayed for an application-owned capabilities response."""
    rows: list[dict[str, Any]] = []
    for name in pack_names:
        source = _manifest_source_for_pack(index, name)
        if not source:
            continue
        row = {
            **sanitize_source(source),
            "loaded": True,
            "chars": 0,
            "use_types": ["Carte de capacités vérifiée"],
            "headings": ["Rôle du pack"],
        }
        rows.append(row)
    return rows


def verified_capabilities_response(
    index: dict[str, Any],
    core_key: str,
    active_packs: list[str],
    full_available: bool,
    startup_pack: str,
) -> tuple[str, list[dict[str, Any]]]:
    """Build a real map of options from selected pack manifests and inventories.

    It reports the actual state of the local application, not abstract LLM claims.
    """
    selected = ordered_pack_names(active_packs)
    if canonical_pack_name(startup_pack) == STARTUP_PACK_01 and STARTUP_PACK_01 not in selected:
        selected = ordered_pack_names([STARTUP_PACK_01, *selected])

    # FULL makes all packs readable through targeted search. It does not pretend
    # that every archive was injected into the model context.
    readable = selected or (list(PACK_CATALOG) if full_available else [])
    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
    total_sources = len([s for s in index.get("sources", []) if not s.get("blocked")])

    lines = [
        "Carte réelle des options locales.",
        "",
        f"Core actif : {core['label']}.",
        (
            f"Packs explicitement choisis : {len(selected)}/7."
            if selected else
            "Aucun pack n’est ajouté : la session reste en Minimum."
        ),
        (
            "FULL est disponible : les 7 packs restent consultables par recherche ciblée, sans être versés d’un coup dans Ollama."
            if full_available else
            "FULL n’est pas activé : seuls Minimum, les packs choisis et les pièces ajoutées sont consultables."
        ),
        f"Bibliothèque locale indexée : {total_sources} sources.",
        "",
    ]

    if readable:
        lines.append("Options documentaires actuellement accessibles :")
        for pack_name in readable:
            meta = PACK_CATALOG[pack_name]
            inventory = pack_inventory(index, pack_name)
            mode = "chargé volontairement" if pack_name in selected else "consultable via FULL"
            lines.append(f"- {meta['label']} — {inventory['count']} fichiers — {meta['role']} ({mode}).")
        lines.append("")
    else:
        lines.append("Options documentaires : aucun pack n’est encore ouvert. Choisis un pack dans le Coffre ou prépare FULL pour une recherche ciblée.")
        lines.append("")

    lines.extend([
        "Actions réellement disponibles dans cette session :",
        "- demander l’inventaire déterministe d’un pack : « liste les fichiers du Pack 06 » ;",
        "- demander un fichier précis d’un pack déjà choisi : « que dit production/COMFYUI_OFFICIAL_KNOWLEDGE_BASE.md ? » ;",
        "- rechercher un thème dans les packs choisis, ou dans tout le Coffre seulement avec FULL ;",
        "- joindre un passage choisi depuis « Coffre & bibliothèque » ;",
        "- sauvegarder la session localement sur demande.",
        "",
        "Limites fixes : aucun pack ne s’active par mot-clé, aucun Vault/DPAPI/Git écriture n’est lu, et les archives ne sont jamais déversées entières dans Ollama.",
    ])
    return "\n".join(lines), capability_overview_sources(index, readable)


def merge_verified_sources(context: dict[str, Any], rows: list[dict[str, Any]]) -> None:
    """Add application-read sources to the response footnote without duplicates."""
    existing = {str(row.get("id") or "") for row in context.get("sources", []) if isinstance(row, dict)}
    merged = list(context.get("sources", []))
    for row in rows:
        source_id = str(row.get("id") or "")
        if source_id and source_id not in existing:
            merged.append(row)
            existing.add(source_id)
    context["sources"] = merged

def attachment_chunks(index: dict[str, Any], source_ids: list[str], query: str, runtime_mode: str, use_type: str, max_files: int | None = None, per_file_override: int | None = None) -> tuple[list[dict[str, Any]], int]:
    """Lit des fichiers choisis et transmet réellement leurs extraits à Ollama."""
    profile = runtime_profile(runtime_mode)
    default_files, default_chars = {"fast": (2, 720), "document": (3, 1080), "deep": (5, 1450)}.get(profile["key"], (2, 720))
    max_files = default_files if max_files is None else max_files
    per_file = default_chars if per_file_override is None else per_file_override
    mapping = source_map(index)
    output: list[dict[str, Any]] = []
    requested = 0
    for source_id in source_ids:
        item = mapping.get(str(source_id))
        if not item or item.get("blocked"):
            continue
        requested += 1
        try:
            raw = read_source(item)
        except (OSError, ValueError, PermissionError, zipfile.BadZipFile):
            continue
        excerpt = select_excerpt(raw, query, per_file).strip()
        if not excerpt:
            continue
        output.append({
            "id": sha_id(f"{use_type}|{item.get('id')}|{runtime_mode}|{query}"),
            "source_id": str(item.get("id")),
            "relative_path": str(item.get("relative_path") or item.get("title") or "source locale"),
            "title": str(item.get("title") or "Pièce jointe locale"),
            "heading": (
                "Fichier explicitement demandé" if use_type == "fichier demandé"
                else (
                    "Route documentaire vérifiée" if use_type.startswith("Route documentaire — ")
                    else ("Démarrage du pack" if (use_type == "Pack 01 — démarrage" or use_type.startswith("Pack choisi — ")) else "Pièce jointe choisie")
                )
            ),
            "origin": str(item.get("origin") or item.get("source_name") or "local"),
            "category": str(item.get("category") or "Source"),
            "tags": list(item.get("tags") or []),
            "text": excerpt,
            "use_type": use_type,
            "score": 21_000 - len(output),
        })
        if len(output) >= max_files:
            break
    return output, requested


def manual_attachment_chunks(index: dict[str, Any], source_ids: list[str], query: str, runtime_mode: str) -> tuple[list[dict[str, Any]], int]:
    """Pièce jointe volontaire : document précis imposé par le créateur."""
    return attachment_chunks(index, source_ids, query, runtime_mode, "pièce jointe manuelle")



def is_module_document(source: dict[str, Any] | None) -> bool:
    """A document declared in modules/ is eligible for the catalogue.

    Markdown, TXT, JSON and YAML are all real local module formats. They remain
    read-only; JSON/YAML are rendered as documents, never executed.
    """
    if not isinstance(source, dict) or source.get("blocked"):
        return False
    if str(source.get("category") or "") != "Module":
        return False
    return Path(str(source.get("relative_path") or "")).suffix.lower() in ALLOWED_EXTENSIONS


def module_source_row(index: dict[str, Any], source_id: str) -> dict[str, Any] | None:
    source = source_map(index).get(str(source_id))
    return source if is_module_document(source) else None


MODULE_QUERY_STOPWORDS = {
    "charge", "charger", "active", "activer", "ouvre", "ouvrir", "utilise", "utiliser", "ajoute", "ajouter",
    "le", "la", "les", "un", "une", "du", "de", "des", "d", "au", "aux", "et", "ou",
    "module", "modules", "memoire", "memory", "fichier", "document", "pack", "packs", "erith", "ia", "fr",
}


def _module_query_terms(text: str) -> list[str]:
    return [token for token in normalized_identity_text(text).split() if len(token) >= 3 and token not in MODULE_QUERY_STOPWORDS]


def _module_heading_metadata(source: dict[str, Any]) -> tuple[str, list[str]]:
    """Read module identity from H1/H2 headings or structured JSON/YAML data.

    The catalogue is generated from the files themselves: no manual names or
    special cases are registered here.
    """
    raw = read_source(source)
    suffix = Path(str(source.get("relative_path") or "")).suffix.lower()
    if suffix == ".json":
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = None
        names: list[str] = []
        if isinstance(data, dict):
            for key in ("title", "name", "label", "module", "id", "description"):
                value = data.get(key)
                if isinstance(value, str) and value.strip():
                    names.append(value.strip())
            names.extend(str(k).replace("_", " ") for k in data.keys() if isinstance(k, str))
        elif isinstance(data, list) and data and isinstance(data[0], dict):
            names.extend(str(k).replace("_", " ") for k in data[0].keys() if isinstance(k, str))
        path_heading = Path(str(source.get("relative_path") or source.get("title") or "Module")).stem.replace("_", " ")
        heading = next((v for v in names if len(normalized_identity_text(v).split()) >= 2), path_heading)
        return heading[:260], [heading[:260], *names[:5]]
    headings = [re.sub(r"\s+", " ", m.group(2)).strip() for m in re.finditer(r"(?m)^(#{1,3})\s+(.+?)\s*$", raw)]
    generic = {"erith", "ia", "module", "memoire", "memory", "principal", "fr", "contenu", "introduction"}
    heading = next(
        (value for value in headings if set(normalized_identity_text(value).split()) - generic),
        headings[0] if headings else Path(str(source.get("relative_path") or source.get("title") or "Module")).stem,
    )
    return heading[:260], headings[:8]


def _module_label_from_heading(heading: str, source: dict[str, Any]) -> str:
    label = re.sub(r"[🧠🕯️🧭⚔️🌫️🌸🛡️🧩🎭🌌🕊️🧲🧰📝🕹️🧪🔑]+", " ", heading)
    label = re.sub(r"(?i)^\s*erith\.?ia\s*[—–-]\s*", "", label)
    label = re.sub(r"(?i)^\s*module\s+(m[eé]moire|memory)\s*[—–:-]*\s*", "", label)
    label = re.sub(r"(?i)^\s*module\s*[—–:-]*\s*", "", label)
    label = re.sub(r"(?i)\s+(fr|v\d+(?:\.\d+)*)\s*$", "", label).strip(" -—–:")
    path_label = Path(str(source.get("relative_path") or source.get("title") or "Module")).stem
    path_label = re.sub(r"(?i)^erith_ia_", "", path_label)
    path_label = re.sub(r"(?i)(?:_|-)fr$", "", path_label).replace("_", " ")
    generic = {"erith", "ia", "module", "memoire", "memory", "principal", "fr"}
    label_terms = set(normalized_identity_text(label).split())
    if not label or not (label_terms - generic):
        label = path_label
    label = re.sub(r"^[^A-Za-zÀ-ÖØ-öø-ÿ0-9]+", "", label)
    return re.sub(r"\s+", " ", label).strip()[:160] or "Module local"


def _module_family_key(source: dict[str, Any]) -> str:
    stem = normalized_identity_text(Path(str(source.get("relative_path") or "")).stem)
    return re.sub(r"\b(niveau|level|partie|part|tome)\s*\d+\b.*$", "", stem).strip()


def _module_level_sort(source: dict[str, Any]) -> tuple[int, str]:
    value = normalized_identity_text(Path(str(source.get("relative_path") or "")).stem)
    match = re.search(r"\b(niveau|level|partie|part|tome)\s*(\d+)\b", value)
    return (int(match.group(2)) if match else 9999, str(source.get("relative_path") or ""))


def module_catalog(index: dict[str, Any]) -> dict[str, Any]:
    """Generate one living catalogue from every readable local module document.

    Duplicate copies of the same relative path are collapsed using the existing
    preferred-source policy. The catalogue therefore represents the real Coffre
    without hard-coded module names.
    """
    global MODULE_CATALOG_CACHE
    fingerprint = rag_fingerprint(index)
    cached = MODULE_CATALOG_CACHE
    if isinstance(cached, dict) and cached.get("fingerprint") == fingerprint:
        return cached

    entries: list[dict[str, Any]] = []
    for source in preferred_rag_sources(index):
        if not is_module_document(source):
            continue
        try:
            heading, headings = _module_heading_metadata(source)
        except (OSError, ValueError, PermissionError, zipfile.BadZipFile):
            continue
        label = _module_label_from_heading(heading, source)
        alias_phrases = [heading, label, Path(str(source.get("relative_path") or "")).stem.replace("_", " "), *headings]
        aliases: list[str] = []
        for phrase in alias_phrases:
            alias = normalized_identity_text(str(phrase or ""))
            if alias and alias not in aliases:
                aliases.append(alias)
        entries.append({
            "source": source,
            "source_id": str(source.get("id") or ""),
            "label": label,
            "heading": heading,
            "aliases": aliases,
            "family_key": _module_family_key(source),
        })

    groups: dict[str, list[dict[str, Any]]] = {}
    for entry in entries:
        groups.setdefault(str(entry["family_key"]), []).append(entry)
    families: dict[str, dict[str, Any]] = {}
    for key, members in groups.items():
        members.sort(key=lambda row: _module_level_sort(row["source"]))
        is_levels = len(members) > 1 and any(
            re.search(r"\b(niveau|level|partie|part|tome)\s*\d+\b", normalized_identity_text(Path(str(row["source"].get("relative_path") or "")).stem))
            for row in members
        )
        if not is_levels:
            continue
        family_label = re.sub(r"(?i)\s*[—–:-]?\s*(niveau|level|partie|part|tome)\s*\d+.*$", "", str(members[0]["label"])).strip(" -—–:")
        families[key] = {
            "id": key,
            "label": family_label or str(members[0]["label"]),
            "members": members,
            "source_ids": [str(row["source_id"]) for row in members],
            "relative_paths": [str(row["source"].get("relative_path") or "") for row in members],
        }

    result = {
        "fingerprint": fingerprint,
        "entries": entries,
        "by_source_id": {str(row["source_id"]): row for row in entries},
        "families": families,
        "count": len(entries),
        "formats": {suffix: sum(1 for row in entries if Path(str(row["source"].get("relative_path") or "")).suffix.lower() == suffix) for suffix in sorted({Path(str(row["source"].get("relative_path") or "")).suffix.lower() for row in entries})},
    }
    MODULE_CATALOG_CACHE = result
    return result


def module_source_label(source: dict[str, Any] | None) -> str:
    if not source:
        return "Module local"
    entry = module_catalog(get_library_index()).get("by_source_id", {}).get(str(source.get("id") or ""))
    if isinstance(entry, dict):
        return str(entry.get("label") or "Module local")
    return Path(str(source.get("title") or source.get("relative_path") or "Module")).stem.replace("_", " ").strip() or "Module local"


def module_family_for_source(source: dict[str, Any] | None) -> tuple[str, dict[str, Any]] | None:
    if not source:
        return None
    catalog = module_catalog(get_library_index())
    entry = catalog.get("by_source_id", {}).get(str(source.get("id") or ""))
    if not isinstance(entry, dict):
        return None
    key = str(entry.get("family_key") or "")
    family = catalog.get("families", {}).get(key)
    return (key, family) if isinstance(family, dict) else None


def module_family_sources_for_session(index: dict[str, Any], session: dict[str, Any]) -> list[dict[str, Any]]:
    current = module_source_for_session(index, session)
    if not current:
        return []
    family_info = module_family_for_source(current)
    if not family_info:
        return [current]
    _, family = family_info
    active_ids = set(_session_list(session.get("active_module_source_ids"), MAX_CONTEXT_SOURCES))
    rows = [dict(item["source"]) for item in family.get("members", []) if str(item.get("source_id") or "") in active_ids]
    return rows or [current]


def module_source_for_session(index: dict[str, Any], session: dict[str, Any]) -> dict[str, Any] | None:
    current = module_source_row(index, str(session.get("current_module_source_id") or ""))
    if current:
        return current
    for sid in reversed(_session_list(session.get("active_module_source_ids"), MAX_CONTEXT_SOURCES)):
        source = module_source_row(index, sid)
        if source:
            return source
    return None


def is_explicit_module_command(message: str) -> bool:
    low = normalized_identity_text(message)
    action_words = ("charge", "charger", "active", "activer", "ouvre", "ouvrir", "utilise", "utiliser", "ajoute", "ajouter")
    return any(re.search(rf"\b{re.escape(word)}\b", low) for word in action_words) and any(term in low for term in ("module", "memoire", "memory", "fichier", "document", "pack", "niveau"))


def module_command_candidates(index: dict[str, Any], message: str, limit: int = 8) -> list[tuple[int, dict[str, Any]]]:
    requested = _module_query_terms(message)
    if not requested:
        return []
    requested_set = set(requested)
    low = normalized_identity_text(message)
    ranked: list[tuple[int, dict[str, Any]]] = []
    for entry in module_catalog(index).get("entries", []):
        best = 0
        for alias in [str(value) for value in entry.get("aliases", []) if str(value)]:
            alias_tokens = set(alias.split())
            overlap = requested_set & alias_tokens
            if not overlap:
                continue
            coverage = len(overlap) / max(1, len(requested_set))
            score = int(300 * coverage) + 45 * len(overlap) - min(95, max(0, len(alias_tokens) - len(overlap)) * 4)
            if len(alias_tokens) >= 2 and alias in low:
                score += 850 + len(alias)
            if requested_set <= alias_tokens:
                score += 170
            best = max(best, score)
        if best:
            ranked.append((best, entry))
    ranked.sort(key=lambda row: (-row[0], len(str(row[1].get("label") or "")), str(row[1]["source"].get("relative_path") or "")))
    return ranked[:max(1, limit)]


def resolve_explicit_module_request(index: dict[str, Any], message: str) -> dict[str, Any]:
    """Resolve explicit loads locally, exposing none/ambiguous/not-found states.

    A natural-language load request never falls through to Ollama: only the
    local runtime may mutate the session.
    """
    if not is_explicit_module_command(message):
        return {"status": "none", "sources": [], "candidates": []}
    ranked = module_command_candidates(index, message)
    if not ranked or ranked[0][0] < 250:
        return {"status": "not_found", "sources": [], "candidates": []}
    best_score = ranked[0][0]
    best_entries = [entry for score, entry in ranked if score >= best_score - 55]
    family_keys = {str(entry.get("family_key") or entry.get("source_id") or "") for entry in best_entries}
    # Different close candidates are never activated together by accident.
    if len(family_keys) > 1:
        candidates = [{"label": str(e.get("label") or "Module local"), "path": str(e["source"].get("relative_path") or "")} for e in best_entries[:5]]
        return {"status": "ambiguous", "sources": [], "candidates": candidates}
    entry = best_entries[0]
    family = module_catalog(index).get("families", {}).get(str(entry.get("family_key") or ""))
    if isinstance(family, dict):
        sources = [dict(item["source"]) for item in family.get("members", []) if isinstance(item, dict) and isinstance(item.get("source"), dict)]
    else:
        sources = [dict(entry["source"])] if isinstance(entry.get("source"), dict) else []
    return {"status": "ok", "sources": sources, "candidates": []}


def resolve_explicit_module_sources(index: dict[str, Any], message: str) -> list[dict[str, Any]]:
    result = resolve_explicit_module_request(index, message)
    return [dict(row) for row in result.get("sources", []) if isinstance(row, dict)]


def unresolved_module_command_response(index: dict[str, Any], message: str, resolution: dict[str, Any]) -> tuple[str, list[dict[str, Any]]] | None:
    status = str(resolution.get("status") or "")
    if status not in {"not_found", "ambiguous"}:
        return None
    if status == "ambiguous":
        choices = resolution.get("candidates") if isinstance(resolution.get("candidates"), list) else []
        lines = ["Chargement local non effectué : plusieurs modules correspondent. Choisis un intitulé plus précis dans le Coffre."]
        for candidate in choices[:5]:
            if isinstance(candidate, dict):
                lines.append(f"- {candidate.get('label')} — {candidate.get('path')}")
        return "\n".join(lines), []
    requested = ", ".join(_module_query_terms(message)) or "module demandé"
    return (f"Chargement local non effectué : aucun module exact ne correspond à « {requested} ». "+
            "La session n’a pas changé. Utilise le Coffre ou donne le titre exact du module."), []

def sanitize_history_for_model(history: Any, lane_id: str) -> list[dict[str, str]]:
    """Keep only ordinary same-lane dialogue for Ollama.

    Local document actions are deterministic application output. Legacy answers
    that simulate actions are excluded so they cannot teach the model to repeat
    them on the next turn.
    """
    clean_history: list[dict[str, str]] = []
    rows = history if isinstance(history, list) else []
    for row in rows[-MAX_HISTORY_MESSAGES:]:
        if not isinstance(row, dict):
            continue
        role = str(row.get("role") or "")
        content = str(row.get("content") or "")[:MAX_HISTORY_CHARS_PER_MESSAGE]
        row_lane = str(row.get("lane") or "")[:500]
        if lane_id and row_lane != lane_id:
            continue
        if role not in {"user", "assistant"} or not content:
            continue
        normalized = normalized_identity_text(content)
        local_prefixes = (
            "chargement local effectue", "resume local", "voici le debut reel",
            "plan local", "oui preuve locale", "chargement local non effectue",
            "reponse locale rejetee", "systeme local",
        )
        fake_actions = ("je vais charger", "je vais lire", "je vais activer", "je vais assimiler", "je vais mettre a jour ma base")
        if role == "assistant" and (normalized.startswith(local_prefixes) or any(phrase in normalized for phrase in fake_actions)):
            continue
        clean_history.append({"role": role, "content": content})
    return clean_history

def document_request_kind(message: str) -> str:
    low = normalized_identity_text(message)
    if any(phrase in low for phrase in ("lis moi le debut", "lire le debut", "lis le debut", "montre le debut", "debut du fichier", "commence le fichier")):
        return "read_start"
    if any(word in low for word in ("sommaire", "sections", "plan du fichier", "plan du module", "liste les sections")):
        return "sections"
    if any(word in low for word in ("resume", "synthese", "resumer")) and any(word in low for word in ("module", "fichier", "document", "le")):
        return "summary"
    if any(word in low for word in ("prouve", "preuve", "accedes", "accede", "ouvrir le fichier", "fichier demande")):
        return "proof"
    if "explique" in low and any(word in low for word in ("fichier", "module", "document", "psychologie", "philosophie")):
        return "explain"
    return ""


def module_chunks_for_source(index: dict[str, Any], source: dict[str, Any], query: str, runtime_mode: str, limit: int = 3) -> list[dict[str, Any]]:
    """Choose sections from one selected module only.

    The current module is stronger than a pack-wide keyword search, so a Memory
    or Story source cannot leak into a Psychology conversation merely because its
    pack is also active.
    """
    source_id = str(source.get("id") or "")
    tokens = [token for token in retrieval_tokens(query, "aerith7") if token]
    candidates = [c for c in get_rag_index(index).get("chunks", []) if str(c.get("source_id") or "") == source_id]
    preferred_headings = ("intention", "resume", "formule", "protocole", "brouillard", "mode", "regle", "methode", "posture")
    ranked: list[tuple[int, dict[str, Any]]] = []
    for pos, chunk in enumerate(candidates):
        heading = normalized_identity_text(str(chunk.get("heading") or ""))
        score = chunk_score(chunk, tokens, "aerith7", {source_id}, set(), set()) if tokens else 0
        for rank, hint in enumerate(preferred_headings):
            if hint in heading:
                score += 500 - rank * 20
        score += max(0, 40 - pos)
        ranked.append((score, chunk))
    ranked.sort(key=lambda row: (-row[0], str(row[1].get("heading") or "")))
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for _, chunk in ranked:
        cid = str(chunk.get("id") or "")
        if not cid or cid in seen:
            continue
        seen.add(cid)
        result.append({**chunk, "use_type": "module actif — " + module_source_label(source), "score": 30_000 - len(result)})
        if len(result) >= max(1, min(limit, 5)):
            break
    return result


def local_document_chunks(index: dict[str, Any], source: dict[str, Any], kind: str) -> tuple[list[dict[str, Any]], str]:
    """Read one local document deterministically, without asking Ollama.

    Summary and explanation deliberately cover several sections. A one-line
    footer called "Résumé ultra-court" is never treated as the whole module.
    """
    raw = read_source(source)
    sections = markdown_sections(raw)
    title = module_source_label(source)
    if kind == "read_start":
        body = raw.strip()[:1800]
        heading = "Début du document"
    elif kind == "sections":
        headings = [heading for heading, _ in sections[:48]]
        body = "\n".join(f"- {heading}" for heading in headings) or "Aucune section Markdown détectée."
        heading = "Plan du document"
    elif kind == "summary":
        chosen: list[tuple[str, str]] = []
        desired = ("intention", "formule", "protocole", "methode", "modes de sortie", "ce que ce module n est pas", "identite", "regles", "resume")
        for desired_term in desired:
            row = next(((h, body) for h, body in sections if desired_term in normalized_identity_text(h)), None)
            if row and row not in chosen:
                chosen.append(row)
            if len(chosen) >= 5:
                break
        if len(chosen) < 3:
            for row in sections:
                if row not in chosen:
                    chosen.append(row)
                if len(chosen) >= 4:
                    break
        body = "\n\n".join(f"{h} : {b[:540].strip()}" for h, b in chosen)[:3200]
        heading = "Résumé local fondé sur les sections du document"
    elif kind == "explain":
        chosen: list[tuple[str, str]] = []
        for heading_candidate, body_candidate in sections:
            h = normalized_identity_text(heading_candidate)
            if any(term in h for term in ("intention", "ce que ce module n est pas", "identite", "methode", "modes de sortie", "regles d usage", "protocole")):
                chosen.append((heading_candidate, body_candidate))
            if len(chosen) >= 5:
                break
        if len(chosen) < 3:
            for row in sections:
                if row not in chosen:
                    chosen.append(row)
                if len(chosen) >= 4:
                    break
        body = "\n\n".join(f"{heading_candidate} : {body_candidate[:560].strip()}" for heading_candidate, body_candidate in chosen)[:3400]
        heading = "Explication locale fondée sur les sections du document"
    else:  # proof
        digest = hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()[:16]
        body = (
            f"Fichier local lu : {source.get('relative_path')}\n"
            f"Taille : {len(raw)} caractères · SHA-256 court : {digest}\n\n"
            f"Début réel :\n{raw.strip()[:900]}"
        )
        heading = "Preuve locale d’accès"
    chunk = {
        "id": sha_id(f"local-document|{source.get('id')}|{kind}|{hashlib.sha256(raw.encode('utf-8', 'ignore')).hexdigest()[:16]}"),
        "source_id": str(source.get("id") or ""),
        "relative_path": str(source.get("relative_path") or ""),
        "title": str(source.get("title") or title),
        "heading": heading,
        "origin": str(source.get("origin") or source.get("source_name") or "local"),
        "category": str(source.get("category") or "Module"),
        "tags": list(source.get("tags") or []),
        "text": body,
        "use_type": DOCUMENT_ACTION_LABELS.get(kind, "Lecture locale"),
        "score": 50_000,
    }
    return [chunk], title


def local_document_response(index: dict[str, Any], session: dict[str, Any], message: str) -> tuple[str, list[dict[str, Any]], str] | None:
    kind = document_request_kind(message)
    if not kind:
        return None
    source = module_source_for_session(index, session)
    if not source:
        return None
    family_sources = module_family_sources_for_session(index, session)
    family_info = module_family_for_source(source)
    # The exact start and proof stay on the current file. A summary, explanation
    # or plan of a multi-level family reads every active level locally.
    if family_info and kind in {"summary", "explain", "sections"} and len(family_sources) > 1:
        _, family = family_info
        chunks: list[dict[str, Any]] = []
        bodies: list[str] = []
        for row in family_sources:
            level_chunks, level_title = local_document_chunks(index, row, kind)
            chunks.extend(level_chunks)
            level_body = str(level_chunks[0].get("text") or "").strip()
            bodies.append(f"## {level_title}\n{level_body[:1200]}")
        title = str(family.get("label") or module_source_label(source))
        body = "\n\n".join(bodies)[:5200]
    else:
        chunks, title = local_document_chunks(index, source, kind)
        body = str(chunks[0].get("text") or "").strip()
    if kind == "read_start":
        answer = f"Voici le début réel de « {title} » :\n\n{body}"
    elif kind == "sections":
        answer = f"Plan local de « {title} » :\n\n{body}"
    elif kind == "summary":
        answer = f"Résumé local de « {title} », construit depuis ses propres sections :\n\n{body}"
    elif kind == "explain":
        answer = f"« {title} » est expliqué ici à partir de ses sections réelles :\n\n{body}"
    else:
        answer = f"Oui. Preuve locale d’accès à « {title} » :\n\n{body}"
    return answer, chunks, kind


def module_activation_response(index: dict[str, Any], session: dict[str, Any], sources: list[dict[str, Any]]) -> tuple[str, list[dict[str, Any]]]:
    """Render a local proof for any catalog module or generated family."""
    chunks: list[dict[str, Any]] = []
    lines = ["Chargement local effectué."]
    primary = sources[0] if sources else None
    family_info = module_family_for_source(primary)
    if family_info:
        _, family = family_info
        members = family.get("members", []) if isinstance(family, dict) else []
        family_ids = {str(item.get("source_id") or "") for item in members if isinstance(item, dict)}
        source_ids = {str(row.get("id") or "") for row in sources}
        if family_ids and source_ids == family_ids:
            selected = module_chunks_for_source(index, primary, "", str(session.get("runtime_mode") or "fast"), limit=1)
            if selected:
                chunks.extend(selected)
                excerpt = re.sub(r"^##[^\n]*\n?", "", str(selected[0].get("text") or "")).strip()[:520]
                pack = canonical_pack_name(str(primary.get("source_name") or "")) if isinstance(primary, dict) else ""
                lines.extend([
                    "",
                    f"- Module actif : {str(family.get('label') or module_source_label(primary))}",
                    f"- Périmètre ouvert : {PACK_CATALOG.get(pack, {}).get('label', 'archive locale')}",
                    f"- Documents locaux ouverts : {len(sources)} niveau(x)",
                    f"- Document courant : {module_source_label(primary)}",
                    f"- Fichier local : {primary.get('relative_path')}",
                    f"- Passage réellement disponible : {selected[0].get('heading')}",
                    f"- Extrait : « {excerpt} »",
                ])
                lines.extend(["", "Le runtime a modifié la session locale ; Ollama n’a pas exécuté ce chargement."])
                return "\n".join(lines), chunks
    for source in sources:
        selected = module_chunks_for_source(index, source, "", str(session.get("runtime_mode") or "fast"), limit=1)
        if selected:
            chunks.extend(selected)
            excerpt = re.sub(r"^##[^\n]*\n?", "", str(selected[0].get("text") or "")).strip()[:520]
            pack = canonical_pack_name(str(source.get("source_name") or ""))
            lines.extend([
                "",
                f"- Module actif : {module_source_label(source)}",
                f"- Périmètre ouvert : {PACK_CATALOG.get(pack, {}).get('label', 'archive locale')}",
                f"- Fichier local : {source.get('relative_path')}",
                f"- Passage réellement disponible : {selected[0].get('heading')}",
                f"- Extrait : « {excerpt} »",
            ])
    lines.extend(["", "Le runtime a modifié la session locale ; Ollama n’a pas exécuté ce chargement."])
    return "\n".join(lines), chunks


def local_context_from_chunks(index: dict[str, Any], core_key: str, chunks: list[dict[str, Any]], session: dict[str, Any]) -> dict[str, Any]:
    rows = source_rows_from_chunks(index, chunks)
    return {
        "core": {"key": core_key, **CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])},
        "sources": rows,
        "retrieved": [{k: row.get(k) for k in ("id", "source_id", "relative_path", "title", "heading", "origin", "use_type", "score", "category", "tags")} for row in chunks],
        "text": "\n\n".join(str(row.get("text") or "") for row in chunks),
        "chars": sum(len(str(row.get("text") or "")) for row in chunks),
        "retrieved_count": len(chunks),
        "boot_required_paths": [], "boot_emitted_paths": [], "boot_complete": True, "boot_missing_paths": [],
        "backbone": {"path": "AERITH_BASE.Modelfile", "sha": boot_backbone_sha(), "sent_every_request": False},
        "manual_packs": ordered_pack_names(session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else []),
        "library_scope": "lecture locale du module courant",
        "runtime": public_runtime_profile(str(session.get("runtime_mode") or "fast")),
        "creator": creator_profile(),
        "active_module_source_ids": _session_list(session.get("active_module_source_ids"), MAX_CONTEXT_SOURCES),
        "current_module_source_id": str(session.get("current_module_source_id") or ""),
    }

def build_context(index: dict[str, Any], core_key: str, selected_ids: list[str], active_packs: list[str], query: str, full_available: bool = False, pinned_chunk_ids: list[str] | None = None, runtime_mode: str = "fast", creator_context_enabled: bool = False, startup_pack: str = "", web_source_ids: list[str] | None = None, active_module_source_ids: list[str] | None = None, current_module_source_id: str = "") -> dict[str, Any]:
    """Build one honest session window.

    Minimum injects only Core + Persona (when separate) + base Seven. A chosen
    pack is a search scope, never a MANIFEST/README auto-injection. FULL widens
    the same targeted search without activating every archive.
    """
    profile = runtime_profile(runtime_mode)
    base_ids = [str(row.get("id")) for row in default_stack(index, core_key).get("sources", [])]
    requested_packs = ordered_pack_names(active_packs)
    if canonical_pack_name(startup_pack) == STARTUP_PACK_01 and STARTUP_PACK_01 not in requested_packs:
        requested_packs = ordered_pack_names([*requested_packs, STARTUP_PACK_01])

    # Minimum always yields only the Core/Persona and compact Seven base.
    minimum_chunks = retrieve_chunks(index, core_key, base_ids, [], query, False, runtime_mode, [])
    minimum_ids = {str(c.get("id") or "") for c in minimum_chunks}

    # Explicit source selection remains stronger than any automatic retrieval.
    requested_source = requested_file_source(
        index, core_key, selected_ids, requested_packs, query, bool(full_available), ""
    )
    requested_source_ids = [str(requested_source.get("id"))] if requested_source else []
    requested_file_chunks, requested_file_requested_count = attachment_chunks(
        index, requested_source_ids, query, runtime_mode, "fichier choisi", max_files=1,
        per_file_override={"fast": 1100, "document": 1400, "deep": 1650}.get(profile["key"], 1100),
    )

    active_module_ids = [
        sid for sid in _session_list(active_module_source_ids or [], MAX_CONTEXT_SOURCES)
        if module_source_row(index, sid)
    ]
    current_module = module_source_row(index, current_module_source_id) if current_module_source_id else None
    if not current_module and active_module_ids:
        current_module = module_source_row(index, active_module_ids[-1])
    module_chunks: list[dict[str, Any]] = []
    if current_module:
        family_info = module_family_for_source(current_module)
        if family_info:
            _, family = family_info
            active_set = set(active_module_ids)
            family_sources = [
                dict(member["source"]) for member in family.get("members", [])
                if isinstance(member, dict) and isinstance(member.get("source"), dict)
                and str(member.get("source_id") or "") in active_set
            ]
            # A family may have been activated as a whole; if the session was
            # saved before active ids were expanded, keep its current document.
            if not family_sources:
                family_sources = [current_module]
            total = {"fast": 2, "document": 3, "deep": 4}.get(profile["key"], 2)
            for source in family_sources[:total]:
                module_chunks.extend(module_chunks_for_source(index, source, query, runtime_mode, limit=1))
        else:
            module_chunks = module_chunks_for_source(index, current_module, query, runtime_mode, limit={"fast": 2, "document": 3, "deep": 4}.get(profile["key"], 2))

    manual_ids = [
        str(value) for value in selected_ids
        if str(value) and str(value) not in base_ids and str(value) not in requested_source_ids and str(value) not in active_module_ids
    ]
    manual_chunks, manual_requested_count = manual_attachment_chunks(index, manual_ids, query, runtime_mode)

    # A current module is a strict documentary scope. Other selected packs remain
    # visible in the Coffre but cannot pollute this module’s conversation.
    search_chunks: list[dict[str, Any]] = []
    if not current_module and (requested_packs or full_available):
        for chunk in retrieve_chunks(index, core_key, base_ids, requested_packs, query, bool(full_available), runtime_mode, []):
            if str(chunk.get("id") or "") not in minimum_ids:
                search_chunks.append(chunk)

    # Explicit named documentary routes keep their existing, visible permission rule.
    routes = [] if current_module else documentary_routes_for_message(query, requested_packs, bool(full_available), "")
    route_chunks: list[dict[str, Any]] = []
    route_requested_count = 0
    for route in routes:
        sources_for_route = documentary_route_sources(index, route)
        route_ids = [str(source.get("id")) for source in sources_for_route if str(source.get("id"))]
        chunks, count = attachment_chunks(
            index, route_ids, query, runtime_mode, documentary_route_use_type(route), max_files=len(route_ids),
            per_file_override={"fast": 1050, "document": 1350, "deep": 1600}.get(profile["key"], 1050),
        )
        route_chunks.extend(chunks)
        route_requested_count += count

    web_chunks = web_source_chunks(web_source_ids or [], query, runtime_mode)
    pins = chunk_map(index)
    pinned: list[dict[str, Any]] = []
    already = {str(c.get("id") or "") for c in minimum_chunks + module_chunks + requested_file_chunks + manual_chunks + route_chunks + search_chunks + web_chunks}
    for chunk_id in (pinned_chunk_ids or [])[:(1 if profile["key"] == "fast" else 2)]:
        chunk = pins.get(str(chunk_id))
        if chunk and str(chunk.get("id") or "") not in already:
            pinned.append({**chunk, "use_type": "extrait choisi", "score": 19_000 - len(pinned)})
            already.add(str(chunk.get("id") or ""))

    creators: list[dict[str, Any]] = []
    if creator_context_enabled:
        creators = creator_export_chunks(index, core_key, 1 if profile["key"] == "fast" else 2)

    # Keep a narrow, predictable window. Minimum identity wins over documentation.
    extra_limit = {"fast": 2, "document": 4, "deep": 6}.get(profile["key"], 2)
    extras = []
    seen_text: set[str] = set()
    for row in module_chunks + requested_file_chunks + route_chunks + manual_chunks + search_chunks + web_chunks + pinned + creators:
        cid = str(row.get("id") or "")
        if not cid or cid in seen_text:
            continue
        seen_text.add(cid)
        extras.append(row)
        if len(extras) >= extra_limit:
            break
    chunks = minimum_chunks + extras

    parts: list[str] = []
    emitted: list[dict[str, Any]] = []
    remaining = int(profile["context_chars"])
    for chunk in chunks:
        use_type = str(chunk.get("use_type") or "référence locale")
        # The model receives private working notes, never source headers it may echo.
        limit = {
            "fast": 520, "document": 760, "deep": 980
        }.get(profile["key"], 520)
        if use_type in {"fichier choisi", "pièce jointe manuelle", "extrait choisi"}:
            limit = int(profile["pinned_chunk_chars"])
        elif use_type.startswith("Route documentaire"):
            limit = {"fast": 1000, "document": 1300, "deep": 1600}.get(profile["key"], 1000)
        body = str(chunk.get("text") or "").strip()[:limit]
        if not body:
            continue
        block = "\n\n<reference_private>\n" + body + "\n</reference_private>"
        if len(block) > remaining:
            block = block[:remaining]
        if block.strip():
            parts.append(block)
            emitted.append(chunk)
            remaining -= len(block)
        if remaining < 300:
            break

    rows = source_rows_from_chunks(index, emitted)
    emitted_paths = {str(chunk.get("relative_path") or "") for chunk in emitted}
    boot_paths = boot_dependency_paths(core_key)
    return {
        "core": {"key": core_key, **CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])},
        "sources": rows,
        "retrieved": [{k: chunk.get(k) for k in ("id", "source_id", "relative_path", "title", "heading", "origin", "use_type", "score", "category", "tags")} for chunk in emitted],
        "text": "".join(parts).strip(),
        "chars": len("".join(parts).strip()),
        "starter_pack": "",
        "starter_label": "Minimum",
        "starter_requested_count": 0,
        "starter_emitted_count": 0,
        "requested_file_path": str(requested_source.get("relative_path") or "") if requested_source else "",
        "requested_file_requested_count": requested_file_requested_count,
        "requested_file_emitted_count": sum(1 for chunk in emitted if str(chunk.get("use_type") or "") == "fichier choisi"),
        "documentary_routes": [{
            "id": str(route.get("id") or ""), "label": str(route.get("label") or ""),
            "pack": str(route.get("pack") or ""), "guard": str(route.get("guard") or ""),
            "use_type": documentary_route_use_type(route),
        } for route in routes],
        "documentary_route_requested_count": route_requested_count,
        "documentary_route_emitted_count": sum(1 for chunk in emitted if str(chunk.get("use_type") or "").startswith("Route documentaire")),
        "manual_requested_count": manual_requested_count,
        "manual_emitted_count": sum(1 for chunk in emitted if str(chunk.get("use_type") or "") == "pièce jointe manuelle"),
        "web_source_requested_count": len(web_source_ids or []),
        "web_source_emitted_count": sum(1 for chunk in emitted if str(chunk.get("use_type") or "") == "URL publique temporaire"),
        "pack_sources_added": sum(1 for chunk in emitted if str(chunk.get("source_name") or "") in requested_packs),
        "pack_bootstrap_requested_count": 0,
        "pack_bootstrap_emitted_count": 0,
        "retrieved_count": len(emitted),
        "boot_required_paths": boot_paths,
        "boot_emitted_paths": [path for path in boot_paths if path in emitted_paths],
        "boot_complete": set(boot_paths).issubset(emitted_paths),
        "boot_missing_paths": [path for path in boot_paths if path not in emitted_paths],
        "backbone": {"path": "AERITH_BASE.Modelfile", "sha": boot_backbone_sha(), "sent_every_request": True},
        "pinned_count": len(pinned),
        "automatic_packs": [],
        "automatic_pack_names": [],
        "manual_packs": requested_packs,
        "library_scope": "FULL disponible" if full_available else ("packs choisis" if requested_packs else "minimum"),
        "runtime": public_runtime_profile(runtime_mode),
        "rag": {"chunk_count": int(get_rag_index(index).get("chunk_count", 0))},
        "creator": creator_profile() if not creator_context_enabled else {**creator_profile(), "enabled": True},
        "active_module_source_ids": active_module_ids,
        "current_module_source_id": str(current_module.get("id") or "") if current_module else "",
        "current_module_path": str(current_module.get("relative_path") or "") if current_module else "",
    }


def content_search(index: dict[str, Any], core_key: str, query: str, full_available: bool = True, active_packs: list[str] | None = None) -> list[dict[str, Any]]:
    # Le paramètre full_available est conservé pour compatibilité API : les Textes sont toujours une lecture locale,
    # sans que leur simple recherche active le mode FULL dans le chat.
    return text_search_chunks(index, core_key, query, active_packs or [], limit=12)

def ollama_tags() -> dict[str, Any]:
    configured = str(get_config().get("model_name") or MODEL_NAME)
    request = urllib.request.Request(f"{OLLAMA_API}/tags", method="GET")
    try:
        with urllib.request.urlopen(request, timeout=2.4) as response:
            payload = json.loads(response.read().decode("utf-8"))
        models = payload.get("models", []) if isinstance(payload, dict) else []
        names = {str(m.get("name")) for m in models if isinstance(m, dict)}
        return {"ollama": "ready", "model_ready": configured in names, "models": sorted(names), "model_name": configured}
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError):
        return {"ollama": "offline", "model_ready": False, "models": [], "model_name": configured}


def generate_ollama(messages: list[dict[str, str]], model_name: str, runtime_mode: str = "fast") -> str:
    profile = runtime_profile(runtime_mode)
    payload = {
        "model": model_name,
        "messages": messages,
        "stream": False,
        "options": {
            "temperature": profile["temperature"],
            "top_p": profile["top_p"],
            "num_ctx": profile["num_ctx"],
            "num_predict": profile["num_predict"],
        },
    }
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        f"{OLLAMA_API}/chat", data=raw, method="POST",
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    try:
        with urllib.request.urlopen(request, timeout=float(profile["timeout"])) as response:
            answer = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as exc:
        raise RuntimeError("Ollama est indisponible. Vérifie qu’il est ouvert.") from exc
    except (TimeoutError, socket.timeout) as exc:
        raise RuntimeError(f"Ollama ne répond pas après {profile['timeout']} secondes en mode {profile['label']}. La réponse a été arrêtée ; le chat reste utilisable.") from exc
    except json.JSONDecodeError as exc:
        raise RuntimeError("Réponse Ollama invalide.") from exc
    content = answer.get("message", {}).get("content", "") if isinstance(answer, dict) else ""
    content = str(content).strip()
    if not content:
        raise RuntimeError("Ollama a répondu sans texte.")
    return content


def save_ollama_trace(messages: list[dict[str, str]], contract: dict[str, Any], context: dict[str, Any], answer: str | None = None) -> None:
    """Local proof of the exact prompt sent to Ollama, never uploaded or indexed."""
    try:
        RUNTIME_TRACES_DIR.mkdir(parents=True, exist_ok=True)
        trace = {
            "created_at": now_iso(),
            "model": str(get_config().get("model_name") or MODEL_NAME),
            "contract": {
                "identity": contract.get("identity"),
                "route": contract.get("route"),
                "boot_complete": contract.get("boot_complete"),
                "boot_required_paths": contract.get("boot_required_paths"),
                "boot_emitted_paths": contract.get("boot_emitted_paths"),
                "backbone": contract.get("backbone"),
            },
            "context_sources": context.get("sources"),
            "messages": messages,
            "answer": answer or "",
        }
        payload = json.dumps(trace, ensure_ascii=False, indent=2)
        (RUNTIME_TRACES_DIR / "LATEST_OLLAMA_PAYLOAD.json").write_text(payload, encoding="utf-8")
    except OSError:
        # A trace failure must not alter a local answer. The chat response exposes
        # the boot state independently.
        pass


def persona_label(core: dict[str, str]) -> str:
    """Libellé de Persona vérifié ; aucune inférence laissée au modèle."""
    core_key = str(core.get("key") or "")
    integrated = {
        "aerith7": "Identité Seven intégrée au Core",
        "aerith6": "Modes Lunaire / Solaire intégrés au Core",
        "constellation": "Route Constellation intégrée au Core",
    }
    if core_key in integrated:
        return integrated[core_key]
    persona_path = str(core.get("persona") or "")
    if not persona_path:
        return "non requise par cette route"
    labels = {
        "aerith10": "Persona Aerith-10 — Operating Layer",
        "sun": "Persona Sun — Operating Layer",
        "night": "Persona Night — Operating Layer",
    }
    return labels.get(core_key, Path(persona_path).stem.replace("_", " "))


def runtime_contract(
    core: dict[str, str],
    context: dict[str, Any],
    active_packs: list[str],
    lane_id: str = "",
    startup_pack: str = "",
    full_available: bool = False,
) -> dict[str, Any]:
    """Application-owned truth used both for display and for Ollama instructions."""
    loaded = [s for s in context.get("sources", []) if isinstance(s, dict) and s.get("loaded")]
    core_path = str(core.get("core") or "")
    persona_path = str(core.get("persona") or "")
    core_source = next((s for s in loaded if s.get("relative_path") == core_path), None)
    persona_source = next((s for s in loaded if persona_path and s.get("relative_path") == persona_path), None)
    starter_name = str(context.get("starter_pack") or "")
    manual_names = ordered_pack_names(active_packs)
    available_names = [canonical_pack_name(str(row.get("name") or "")) for row in bundled_archive_rows(get_library_index())]
    active_names = effective_active_pack_names(active_packs, startup_pack)
    reinforcement_names = list(dict.fromkeys(active_names))
    return {
        "root": "Seven Heaven",
        "core_key": str(core.get("key") or "aerith7"),
        "identity": core["label"],
        "runtime_capsule": runtime_capsule(str(core.get("key") or "aerith7")),
        "route": core["route"],
        "role": core["role"],
        "core_source": core_source,
        "persona": persona_label(core),
        "persona_source": persona_source,
        "reinforcements": reinforcement_names,
        "automatic_reinforcements": [],
        "manual_reinforcements": manual_names,
        "available_pack_names": available_names,
        "active_pack_names": active_names,
        "available_archives": [PACK_CATALOG[name]["label"] for name in available_names if name in PACK_CATALOG],
        "active_archives": [PACK_CATALOG[name]["label"] for name in active_names if name in PACK_CATALOG],
        "full_available": bool(full_available),
        "source_paths": [str(s.get("relative_path")) for s in loaded],
        "source_count": len(loaded),
        "boot_required_paths": list(context.get("boot_required_paths") or []),
        "boot_emitted_paths": list(context.get("boot_emitted_paths") or []),
        "boot_complete": bool(context.get("boot_complete")),
        "boot_missing_paths": list(context.get("boot_missing_paths") or []),
        "backbone": context.get("backbone") if isinstance(context.get("backbone"), dict) else {"path": "AERITH_BASE.Modelfile", "sha": boot_backbone_sha(), "sent_every_request": True},
        "source_mode": (
            "Coffre local + URL publique temporaire" if any(s.get("kind") == "web" for s in loaded) and any(s.get("kind") in {"repo", "seed", "zip"} for s in loaded)
            else ("URL publique temporaire jointe" if any(s.get("kind") == "web" for s in loaded)
                  else ("Coffre Git local en lecture seule" if any(s.get("kind") == "repo" for s in loaded) else "snapshot hors ligne embarqué"))
        ),
        "creator": context.get("creator") if isinstance(context.get("creator"), dict) else creator_profile(),
        "history_lane": lane_id,
        "history_messages_used": 0,
    }


def contract_text(contract: dict[str, Any]) -> str:
    reinforcements = contract.get("reinforcements") or []
    sources = contract.get("source_paths") or []
    lines = [
        "CONTRAT DE SESSION VÉRIFIÉ PAR L’APPLICATION",
        f"Racine : {contract['root']}",
        f"Core actif : {contract['identity']}",
        f"Route : {contract['route']}",
        f"Persona active : {contract['persona']}",
        f"Renforts actifs : {', '.join(reinforcements) if reinforcements else 'aucun'}",
        f"Origine des sources : {contract['source_mode']}",
        "Sources effectivement extraites :",
    ]
    lines.extend(f"- {path}" for path in sources) if sources else lines.append("- aucune")
    return "\n".join(lines)


def normalized_identity_text(message: str) -> str:
    decomposed = unicodedata.normalize("NFD", message.lower())
    without_accents = "".join(ch for ch in decomposed if unicodedata.category(ch) != "Mn")
    return " ".join(re.sub(r"[^a-z0-9]+", " ", without_accents).split())

def identity_registry() -> dict[str, Any]:
    """Reads the single canonical topology: routes, versions and Flower Girls."""
    global IDENTITY_REGISTRY_CACHE
    if isinstance(IDENTITY_REGISTRY_CACHE, dict):
        return IDENTITY_REGISTRY_CACHE
    raw = json_load(IDENTITY_REGISTRY_PATH, {})
    if not isinstance(raw, dict) or not isinstance(raw.get("records"), list):
        raw = {"schema": "absent", "records": []}
    IDENTITY_REGISTRY_CACHE = raw
    return raw


def identity_record(record_id: str) -> dict[str, Any] | None:
    for row in identity_registry().get("records", []):
        if isinstance(row, dict) and str(row.get("id") or "") == str(record_id or ""):
            return dict(row)
    return None


def _identity_alias_match(low: str, alias: str) -> bool:
    alias_low = normalized_identity_text(alias)
    return bool(alias_low) and f" {alias_low} " in f" {low} "


def resolve_identity_intent(message: str) -> dict[str, Any] | None:
    """Resolve only from typed records. No numbered exception and no invented alias."""
    low = normalized_identity_text(message)
    words = set(low.split())
    activation_cues = {"active", "activer", "charge", "charger", "passe", "passer", "choisis", "choisir", "utilise", "utiliser"}
    description_cues = ("decris", "decrit", "explique", "qui est", "quel est", "parle moi", "presente", "aptitudes", "capacites", "compétences")
    records = [dict(row) for row in identity_registry().get("records", []) if isinstance(row, dict)]
    records.sort(key=lambda row: max([len(normalized_identity_text(a)) for a in row.get("aliases", []) if isinstance(a, str)] or [0]), reverse=True)
    for row in records:
        aliases = [str(alias) for alias in row.get("aliases", []) if isinstance(alias, str)]
        if not any(_identity_alias_match(low, alias) for alias in aliases):
            continue
        if str(row.get("kind") or "") == "runtime-route" and words.intersection(activation_cues):
            return {"kind": "activate-route", "record": row}
        if any(cue in low for cue in description_cues) or str(row.get("kind") or "") == "flower-girl":
            return {"kind": "describe", "record": row}
    return None


def _registry_source(index: dict[str, Any]) -> dict[str, Any] | None:
    return find_source_by_relative(index, "AERITH_CANONICAL_TOPOLOGY.json")


def identity_visible_sources(index: dict[str, Any], record: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    topology_source = _registry_source(index)
    if topology_source:
        rows.append(topology_source)
    for path in (str(record.get("core_path") or ""), str(record.get("persona_path") or ""), str(record.get("boot_path") or "")):
        if path:
            source = find_source_by_relative(index, path)
            if source and source not in rows:
                rows.append(source)
    return rows


def verified_identity_intent_response(index: dict[str, Any], session: dict[str, Any], intent: dict[str, Any]) -> tuple[str, list[dict[str, Any]]]:
    record = intent.get("record") if isinstance(intent.get("record"), dict) else {}
    label = str(record.get("label") or "Identité")
    kind = str(intent.get("kind") or "describe")
    source_rows = identity_visible_sources(index, record)
    core_path = str(record.get("core_path") or "")
    persona_path = str(record.get("persona_path") or "")
    active = CORE_OPTIONS.get(str(session.get("core_key") or "aerith7"), CORE_OPTIONS["aerith7"])
    if kind == "activate-route":
        lines = [
            f"Route active : {label}.",
            str(record.get("role") or ""),
            "Racine permanente : Aerith-7 — Seven Heaven.",
            "La pile documentaire, FULL, les pièces jointes et le briefing sont conservés.",
        ]
        if persona_path:
            lines.append("Persona jointe : " + persona_path + ".")
        return "\n\n".join(line for line in lines if line), source_rows
    if str(record.get("kind") or "") == "flower-girl":
        lines = [
            f"{label}.",
            "Type : Flower Girl / spécialisation Aerith-10.",
            "Core de conversation inchangé : " + active["label"] + ".",
            "Source : " + (core_path or "non déclarée") + ("." if core_path else ""),
        ]
        if persona_path:
            lines.append("Persona : " + persona_path + ".")
        if not any(str(row.get("relative_path") or "") == core_path for row in source_rows):
            lines.append("Cette source attend le miroir Git local ou son ajout explicite à la pile.")
        return "\n\n".join(lines), source_rows
    lines = [label, str(record.get("role") or "")]
    if core_path:
        lines.append("Core : " + core_path + ".")
    if persona_path:
        lines.append("Persona : " + persona_path + ".")
    return "\n\n".join(line for line in lines if line), source_rows

def ordered_pack_names(values: Iterable[str | Path | None]) -> list[str]:
    """Deduplicate a pack selection into the canonical 01 → 07 order."""
    selected = {canonical_pack_name(value) for value in values if canonical_pack_name(value) in PACK_CATALOG}
    return [pack_name for pack_name in PACK_ORDER if pack_name in selected]


def documentary_routes_for_message(
    message: str,
    active_packs: Iterable[str | Path | None],
    full_available: bool,
    startup_pack: str = "",
) -> list[dict[str, Any]]:
    """Return only routes whose pack is already visible to the operator.

    A matching phrase cannot add a pack. The route merely makes the already chosen
    source mandatory in the next context window, so the source footnote proves it.
    """
    low = normalized_identity_text(message)
    visible = set(ordered_pack_names(active_packs))
    if canonical_pack_name(startup_pack) == STARTUP_PACK_01:
        visible.add(STARTUP_PACK_01)
    routes: list[dict[str, Any]] = []
    for rule in DOCUMENTARY_ROUTE_RULES:
        if not any(cue in low for cue in rule["cues"]):
            continue
        pack_name = str(rule["pack"])
        if pack_name not in visible and not full_available:
            continue
        routes.append(dict(rule))
    return routes


def documentary_route_sources(index: dict[str, Any], route: dict[str, Any]) -> list[dict[str, Any]]:
    """Resolve the canonical local document(s) for one already-authorized route."""
    pack_name = str(route.get("pack") or "")
    wanted = {str(path) for path in (route.get("source_paths") or ())}
    rows = [
        source for source in index.get("sources", [])
        if not source.get("blocked")
        and canonical_pack_name(str(source.get("source_name") or "")) == pack_name
        and str(source.get("relative_path") or "") in wanted
    ]
    rows.sort(key=lambda source: list(route.get("source_paths") or ()).index(str(source.get("relative_path") or "")))
    return rows


def documentary_route_use_type(route: dict[str, Any]) -> str:
    """Human-readable proof line: route plus the exact Pack number."""
    pack_name = str(route.get("pack") or "")
    pack_label = str(PACK_CATALOG.get(pack_name, {}).get("label") or pack_name)
    pack_number = pack_label.split("·", 1)[0].strip() or pack_label
    return f"Route documentaire — {str(route.get('label') or 'Pack')} · Pack {pack_number}"


def is_identity_status_request(message: str) -> bool:
    """Identity and stack requests are deterministic, even with punctuation or missing hyphens."""
    low = normalized_identity_text(message)
    identity_cues = (
        "ton core actif", "core actif", "sources reellement chargees", "sources chargees",
        "contrat actif", "quelle pile", "quel core", "quelle persona", "persona active",
        "etat de la route", "etat du boot", "boot complet",
    )
    return any(cue in low for cue in identity_cues)


def is_creator_recognition_request(message: str) -> bool:
    low = normalized_identity_text(message)
    cues = (
        "qui suis je", "tu me reconnais", "je suis un inconnu", "qui je suis",
        "tu sais qui je suis", "tu me connais",
    )
    return any(cue in low for cue in cues)


def verified_creator_response(contract: dict[str, Any]) -> str:
    creator = contract.get("creator") if isinstance(contract.get("creator"), dict) else creator_profile()
    name = str(creator.get("operator_name") or "Christophe")
    lines = [
        f"Tu es {name}, créateur et opérateur de Seven Heaven Local et du système @erith.IA.",
        "Je te reconnais dans ce poste local par ce profil opérateur. Je ne lis ni Seven Vault ni mémoire chiffrée.",
    ]
    if creator.get("enabled") and creator.get("exports_loaded"):
        lines.append("Cette session utilise aussi des exports Git explicitement autorisés pour la route active.")
    else:
        lines.append("Les exports Creator Memory restent désactivés tant que tu ne les actives pas explicitement.")
    return "\n\n".join(lines)


def verified_identity_response(contract: dict[str, Any]) -> str:
    """A short natural introduction owned by the application.

    It avoids asking a 3B model to improvise the basic identity from a huge Core,
    while the source footnote still proves which canonical sections are loaded.
    """
    capsule = contract.get("runtime_capsule") if isinstance(contract.get("runtime_capsule"), dict) else runtime_capsule(str(contract.get("core_key") or "aerith7"))
    lines = [
        str(capsule.get("intro") or contract["identity"]),
        str(capsule.get("method") or contract["role"]),
    ]
    if contract.get("reinforcements"):
        lines.append("Renforts actifs : " + ", ".join(contract["reinforcements"]) + ".")
    creator = contract.get("creator") if isinstance(contract.get("creator"), dict) else creator_profile()
    name = str(creator.get("operator_name") or "Christophe")
    lines.append(f"Je m’adresse à {name}, créateur et opérateur de ce poste local.")
    if creator.get("enabled") and creator.get("exports_loaded"):
        lines.append("Le contexte créateur repose uniquement sur les exports Git explicitement autorisés.")
    lines.append("Je reste dans cette route ; les détails de la pile sont disponibles dans « Voir la pile ».")
    return "\n\n".join(lines)



def system_prompt(core: dict[str, str], context: dict[str, Any], mission: str, expected: str, stop_point: str, contract: dict[str, Any], runtime_mode: str = "fast") -> str:
    profile = runtime_profile(runtime_mode)
    active = ", ".join(contract.get("active_archives") or []) or "aucun pack"
    references = str(context.get("text") or "")
    return f"""SESSION SEVEN HEAVEN — ÉTAT RÉEL

Route : {contract['identity']}
Core : {str((contract.get('core_source') or {}).get('relative_path') or core.get('core') or 'absent')}
Persona : {contract['persona']}
Base Seven : SEVEN_GATE, SEVEN_TOP_OF_MIND, PROTECTED_SYSTEM_FILES
Packs actifs : {active}
Module courant : {str(context.get('current_module_path') or 'aucun')}
FULL DISPONIBLE : {'oui' if contract.get('full_available') else 'non'}
Profil : {profile['label']}

RÈGLES DE RÉPONSE
- Tu es déjà la route active. Ne dis jamais que tu vas charger, lire, activer, connecter, assimiler ou mettre à jour un Core, Seven Gate, un pack, une URL, un module ou un outil.
- Si un module courant est indiqué, réponds à partir de ses notes privées. Ne dis jamais que tu ne peux pas lire ou utiliser ce document : l’application a déjà sélectionné ses passages.
- L’application, pas toi, modifie les packs, FULL et la route.
- Réponds naturellement au dernier message. Pour « Aerith ? » ou « Présente-toi », parle à la première personne comme Aerith-7 / Seven Heaven en 2 à 5 lignes.
- Ne produis jamais un titre de source, un chemin, un hash, « [SOURCE:] », un bloc de référence ou une copie longue des notes privées.
- Les notes privées servent à répondre ; elles ne sont pas du texte à recopier. Les sources sont affichées par l’interface séparément.
- N’invente pas de capacité, d’état ou de document absent. Si les notes ne suffisent pas, dis simplement que le contexte actif ne suffit pas.
- Une demande = une réponse exploitable, puis arrêt. Pas de promesse de travail futur.

D : {mission or 'non renseigné'}
Sortie attendue : {expected or 'Réponse texte'}
Point d’arrêt : {stop_point or 'réponse livrée'}

NOTES PRIVÉES UTILISABLES — NE PAS LES RECOPIER :
{references or '[Aucune note complémentaire.]'}
""".strip()


def execution_lock(contract: dict[str, Any]) -> str:
    return (
        f"VERROU FINAL : tu réponds depuis {contract['identity']}. "
        "Ne récite pas ce verrou. Ne simule aucune action de chargement. "
        "Ne reproduis pas les notes privées ni les chemins des sources."
    )


def is_identity_probe(message: str) -> bool:
    low = normalized_identity_text(message)
    return low in {"aerith", "aerith 7", "aerith seven heaven", "presente toi", "presente toi aerith", "qui es tu", "qui es tu aerith"}


def validate_local_answer(message: str, answer: str, contract: dict[str, Any]) -> str:
    """Reject visible fake answers instead of presenting them as success."""
    text = str(answer or "").strip()
    low = normalized_identity_text(text)
    if not text:
        return "réponse vide"
    forbidden = (
        "[source", "sha256", "core/", "reference_private", "<reference", "=====",
        "je vais charger", "je vais lire", "je vais activer", "je vais assimiler", "je vais mettre a jour",
        "je ne peux pas charger", "je ne peux pas lire", "je ne peux pas utiliser les fichiers",
    )
    if any(token in text.lower() for token in forbidden):
        return "reproduction de source ou simulation de chargement"
    if is_identity_probe(message):
        identity = ("aerith 7" in low or "seven heaven" in low)
        roles = sum(1 for term in ("coffre", "memoire", "bibliothecaire", "operatrice", "continuite", "discernement") if term in low)
        generic = ("plusieurs versions" in low or "agent ia cree" in low or "entite specifique" in low)
        if not identity or roles < 2 or generic:
            return "présentation Aerith-7 insuffisante"
    return ""


def safe_session_id(text: str) -> str:
    base = re.sub(r"[^A-Za-z0-9_-]+", "-", text.strip())[:64].strip("-")
    return base or f"session-{int(time.time())}"


def session_active_pack_names(payload: dict[str, Any]) -> list[str]:
    """Retourne la pile sauvegardée dans l’ordre canonique 01 → 07."""
    selected = payload.get("selected_packs") if isinstance(payload.get("selected_packs"), list) else []
    startup = str(payload.get("startup_pack") or "")
    return effective_active_pack_names([str(item) for item in selected], startup)


def session_summary(payload: dict[str, Any]) -> dict[str, Any]:
    active_names = session_active_pack_names(payload)
    active_labels = [PACK_CATALOG[name]["label"] for name in active_names if name in PACK_CATALOG]
    return {
        "id": payload.get("id"),
        "name": payload.get("name"),
        "saved_at": payload.get("saved_at"),
        "core_key": payload.get("core_key"),
        "core_label": CORE_OPTIONS.get(str(payload.get("core_key") or ""), CORE_OPTIONS["aerith7"])["label"],
        "active_pack_names": active_names,
        "active_archives": active_labels,
        "full_available": bool(payload.get("full_available")),
        "runtime_mode": str(payload.get("runtime_mode") or "fast"),
        "mission": str(payload.get("mission") or "")[:300],
        "history_count": len(payload.get("history") if isinstance(payload.get("history"), list) else []),
        "format": int(payload.get("format") or 1),
    }


def list_sessions() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    try:
        paths = sorted(SESSIONS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    except OSError:
        paths = []
    for path in paths:
        data = json_load(path, {})
        if isinstance(data, dict) and data.get("id"):
            rows.append(session_summary(data))
    return rows[:80]


def _new_session_id(name: str) -> str:
    """Crée un identifiant local unique pour une nouvelle sauvegarde nommée."""
    stem = safe_session_id(name)[:42] or "session"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    candidate = f"{stem}-{stamp}"
    suffix = 2
    while (SESSIONS_DIR / f"{candidate}.json").exists():
        candidate = f"{stem}-{stamp}-{suffix}"
        suffix += 1
    return candidate[:64]


def save_session(payload: dict[str, Any]) -> dict[str, Any]:
    """Sauvegarde uniquement une session demandée explicitement par l’opérateur.

    La session mémorise le Core, la pile, FULL, les pièces locales choisies,
    le briefing et l’historique de chat. Les lectures web temporaires ne sont
    volontairement jamais écrites dans ce fichier.
    """
    name = str(payload.get("name") or "Session locale").strip()[:120] or "Session locale"
    requested_id = str(payload.get("id") or "").strip()
    sid = safe_session_id(requested_id) if requested_id else _new_session_id(name)
    normalized_packs = ordered_pack_names(payload.get("selected_packs") if isinstance(payload.get("selected_packs"), list) else [])
    startup = STARTUP_PACK_01 if canonical_pack_name(str(payload.get("startup_pack") or "")) == STARTUP_PACK_01 else ""
    if STARTUP_PACK_01 in normalized_packs:
        startup = STARTUP_PACK_01
        normalized_packs = [name for name in normalized_packs if name != STARTUP_PACK_01]
    history = payload.get("history") if isinstance(payload.get("history"), list) else []
    journal = payload.get("journal") if isinstance(payload.get("journal"), list) else []
    saved = {
        "format": 2,
        "id": sid,
        "name": name,
        "saved_at": now_iso(),
        "core_key": str(payload.get("core_key") or "aerith7"),
        "selected_source_ids": [str(x) for x in payload.get("selected_source_ids", [])[:MAX_CONTEXT_SOURCES]],
        "selected_packs": normalized_packs,
        "startup_pack": startup,
        "selected_chunk_ids": [str(x) for x in payload.get("selected_chunk_ids", [])[:12]],
        "full_available": bool(payload.get("full_available")),
        "runtime_mode": str(payload.get("runtime_mode") or "fast") if str(payload.get("runtime_mode") or "fast") in RUNTIME_PROFILES else "fast",
        "creator_context_enabled": bool(payload.get("creator_context_enabled")),
        "mission": str(payload.get("mission") or "")[:2000],
        "expected": str(payload.get("expected") or "Réponse texte")[:300] or "Réponse texte",
        "stop_point": str(payload.get("stop_point") or "")[:2000],
        "chatgpt_link": str(payload.get("chatgpt_link") or "")[:800],
        "history": history[-120:],
        "conversation_id": str(payload.get("conversation_id") or "")[:500],
        "lane_epochs": {str(k)[:500]: int(v) for k, v in (payload.get("lane_epochs") or {}).items() if str(k)[:500] and isinstance(v, int)},
        "journal": journal[-120:],
        "note": "Session locale non chiffrée. Sauvegarde explicite ; aucune restauration automatique ; lectures URL temporaires exclues.",
    }
    json_save(SESSIONS_DIR / f"{sid}.json", saved)
    return session_summary(saved)


def load_session(sid: str) -> dict[str, Any]:
    path = SESSIONS_DIR / f"{safe_session_id(sid)}.json"
    data = json_load(path, {})
    if not isinstance(data, dict) or not data or not data.get("id"):
        raise FileNotFoundError("session locale introuvable")
    return data


def restore_saved_session(index: dict[str, Any], sid: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Restaure une session sur action explicite uniquement.

    Le runtime devient la source de vérité avant le navigateur. Les sources web
    restent exclues : elles expirent avec le runtime et ne sont jamais réinjectées
    par une sauvegarde.
    """
    saved = load_session(sid)
    snapshot = mutate_runtime_session(index, "replace", saved)
    return saved, snapshot


def git_local_status(repo_path: str) -> dict[str, Any]:
    path = Path(repo_path).expanduser()
    if not path.exists() or not path.is_dir():
        return {"available": False, "message": "Aucun Coffre local relié."}
    git_dir = path / ".git"
    if not git_dir.exists():
        if is_erith_project_root(path):
            return {"available": True, "branch": "dossier local", "head": "lecture seule", "changed": [], "message": "Dossier canonique relié en lecture seule (sans métadonnées Git)."}
        return {"available": False, "message": "Le dossier relié n’est pas un projet @erith.IA reconnu."}
    try:
        branch = subprocess.run(["git", "-C", str(path), "branch", "--show-current"], capture_output=True, text=True, timeout=5, check=False)
        status = subprocess.run(["git", "-C", str(path), "status", "--short"], capture_output=True, text=True, timeout=5, check=False)
        head = subprocess.run(["git", "-C", str(path), "rev-parse", "--short", "HEAD"], capture_output=True, text=True, timeout=5, check=False)
        return {
            "available": True,
            "branch": branch.stdout.strip() or "détachée",
            "head": head.stdout.strip() or "inconnu",
            "changed": [line for line in status.stdout.splitlines() if line.strip()][:80],
            "message": "Lecture locale uniquement. Aucun fetch ou pull n’a été lancé.",
        }
    except (OSError, subprocess.SubprocessError):
        return {"available": False, "message": "Git local indisponible ou non détecté."}


class AppHandler(BaseHTTPRequestHandler):
    server_version = "SevenHeavenLocal/6.6"

    def log_message(self, fmt: str, *args: Any) -> None:  # interface silencieuse
        return

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            return

    def _send_file(self, path: Path, content_type: str) -> None:
        try:
            raw = path.read_bytes()
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _read_json(self) -> dict[str, Any]:
        size = int(self.headers.get("Content-Length", "0"))
        if size < 0 or size > MAX_JSON_BODY:
            raise ValueError("requête locale trop volumineuse")
        raw = self.rfile.read(size)
        payload = json.loads(raw.decode("utf-8")) if raw else {}
        if not isinstance(payload, dict):
            raise ValueError("corps JSON attendu")
        return payload

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        endpoint = parsed.path
        if endpoint in {"/", "/index.html"}:
            self._send_file(INDEX_HTML, "text/html; charset=utf-8")
            return
        if endpoint == "/api/runtime/session":
            index = get_library_index()
            self._send_json(HTTPStatus.OK, {"session": runtime_session_snapshot(index)})
            return
        if endpoint == "/api/health":
            health = ollama_tags()
            index = get_library_index()
            self._send_json(HTTPStatus.OK, {
                **health,
                "app_name": APP_NAME,
                "version": APP_VERSION,
                "bundled_packs": len(index.get("packs", [])),
                "seed_count": int((index.get("seed") or {}).get("count", 0)),
                "source_count": len(index.get("sources", [])),
                "rag": {k: get_rag_index(index).get(k) for k in ("built_at", "source_count", "chunk_count", "skipped_count", "skipped_nontext", "duplicate_sources")},
                "connection_mode": str(get_config().get("connection_mode") or "local"),
                "internet": "passerelles connectées" if str(get_config().get("connection_mode") or "local") == "connected" else "base locale",
                "runtime_session": runtime_session_snapshot(index),
            })
            return
        if endpoint == "/api/settings":
            cfg = get_config()
            health = ollama_tags()
            self._send_json(HTTPStatus.OK, {
                "model_name": str(cfg.get("model_name") or MODEL_NAME),
                "available_models": health.get("models", []),
                "ollama": health.get("ollama"),
                "operator_name": str(cfg.get("operator_name") or "Christophe"),
                "creator_context_enabled": bool(cfg.get("creator_context_enabled")),
                "connection_mode": str(cfg.get("connection_mode") or "local"),
            })
            return
        if endpoint == "/api/packs":
            self._send_json(HTTPStatus.OK, {"packs": pack_catalog_rows(get_library_index())})
            return
        if endpoint == "/api/packs/inventory":
            raw_pack = parse_qs(parsed.query).get("pack", [""])[0]
            try:
                self._send_json(HTTPStatus.OK, pack_inventory(get_library_index(), raw_pack))
            except ValueError as exc:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            return
        if endpoint == "/api/library":
            index = get_library_index()
            query = parse_qs(parsed.query).get("q", [""])[0]
            category = parse_qs(parsed.query).get("category", [""])[0]
            results = search_sources(index, query, category)
            cfg = get_config()
            self._send_json(HTTPStatus.OK, {
                "built_at": index.get("built_at"),
                "packs": index.get("packs", []),
                "seed": index.get("seed"),
                "repo": index.get("repo"),
                "repo_configured": bool(cfg.get("repo_path")),
                "repo_path": str(cfg.get("repo_path") or ""),
                "repo_suggestions": suggested_repo_paths(),
                "source_count": len(index.get("sources", [])),
                "rag": {k: get_rag_index(index).get(k) for k in ("built_at", "source_count", "chunk_count", "skipped_count", "skipped_nontext", "duplicate_sources")},
                "results": results,
                "core_options": core_option_rows(index),
                "topology": identity_registry(),
                "runtime_profiles": [public_runtime_profile(k) for k in RUNTIME_PROFILES],
                "runtime_session": runtime_session_snapshot(index),
                "creator_context": {
                    **creator_profile(),
                    "exports_available": len(creator_export_sources(index, "night")) + len(creator_export_sources(index, "sun")) + len(creator_export_sources(index, "aerith10")),
                },
            })
            return
        if endpoint == "/api/library/stack":
            query = parse_qs(parsed.query)
            core_key = query.get("core", ["aerith7"])[0]
            self._send_json(HTTPStatus.OK, default_stack(get_library_index(), core_key))
            return
        if endpoint == "/api/links":
            self._send_json(HTTPStatus.OK, {"links": get_links()})
            return
        if endpoint == "/api/sessions":
            self._send_json(HTTPStatus.OK, {"sessions": list_sessions()})
            return
        if endpoint.startswith("/api/sessions/"):
            sid = endpoint.rsplit("/", 1)[-1]
            try:
                self._send_json(HTTPStatus.OK, {"session": load_session(sid)})
            except FileNotFoundError as exc:
                self._send_json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
            return
        if endpoint == "/api/git/status":
            cfg = get_config()
            self._send_json(HTTPStatus.OK, git_local_status(str(cfg.get("repo_path") or "")))
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        try:
            payload = self._read_json()
            endpoint = urlparse(self.path).path
            if endpoint == "/api/runtime/stop":
                self._send_json(HTTPStatus.OK, {"message": "Runtime local arrêté proprement."})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if endpoint == "/api/runtime/session":
                index = get_library_index()
                action = str(payload.get("action") or "snapshot")
                session = mutate_runtime_session(index, action, payload)
                self._send_json(HTTPStatus.OK, {"session": session})
                return
            if endpoint == "/api/library/reindex":
                index = get_library_index(force=True)
                self._send_json(HTTPStatus.OK, {
                    "message": "Bibliothèque locale indexée.",
                    "source_count": len(index.get("sources", [])),
                    "pack_count": len(index.get("packs", [])),
                    "rag_chunk_count": int(get_rag_index(index).get("chunk_count", 0)),
                    "repo": index.get("repo"),
                })
                return
            if endpoint == "/api/library/configure-repo":
                raw_path = str(payload.get("path") or "").strip()
                if not raw_path:
                    cfg = get_config()
                    cfg["repo_path"] = ""
                    save_config(cfg)
                    index = get_library_index(force=True)
                    self._send_json(HTTPStatus.OK, {"message": "Miroir Git local retiré de l’index.", "source_count": len(index.get("sources", []))})
                    return
                repo_path = Path(raw_path).expanduser()
                if not is_erith_project_root(repo_path):
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Choisis le dossier racine du projet : un clone Git ou un dossier contenant core/SEVEN_GATE.md."})
                    return
                cfg = get_config()
                cfg["repo_path"] = str(repo_path.resolve())
                save_config(cfg)
                index = get_library_index(force=True)
                self._send_json(HTTPStatus.OK, {
                    "message": "Miroir Git local indexé en lecture seule.",
                    "source_count": len(index.get("sources", [])),
                    "repo": index.get("repo"),
                })
                return
            if endpoint == "/api/settings/creator-context":
                cfg = get_config()
                name = str(payload.get("operator_name") or cfg.get("operator_name") or "Christophe").strip()[:80]
                cfg["operator_name"] = name or "Christophe"
                cfg["creator_context_enabled"] = bool(payload.get("creator_context_enabled"))
                save_config(cfg)
                self._send_json(HTTPStatus.OK, {
                    "message": "Contexte créateur local mis à jour.",
                    "operator_name": cfg["operator_name"],
                    "creator_context_enabled": bool(cfg["creator_context_enabled"]),
                })
                return
            if endpoint == "/api/settings/connection":
                requested = str(payload.get("connection_mode") or "local").strip().lower()
                if requested not in {"local", "connected"}:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Mode Local ou Connecté attendu."})
                    return
                cfg = get_config()
                cfg["connection_mode"] = requested
                save_config(cfg)
                self._send_json(HTTPStatus.OK, {
                    "connection_mode": requested,
                    "message": "Passerelles connectées activées." if requested == "connected" else "Base locale active. Les passerelles restent disponibles dans Accès.",
                })
                return
            if endpoint == "/api/bridge/url/read":
                cfg = get_config()
                if str(cfg.get("connection_mode") or "local") != "connected":
                    self._send_json(HTTPStatus.FORBIDDEN, {"error": "Passe d’abord en mode Connecté pour lire une URL publique."})
                    return
                source = cache_web_source(read_public_url(str(payload.get("url") or "")))
                self._send_json(HTTPStatus.OK, {
                    "source": source,
                    "message": "URL publique lue temporairement. Elle n’est ni ajoutée au Coffre ni sauvegardée.",
                })
                return
            if endpoint == "/api/settings/model":
                requested = str(payload.get("model_name") or "").strip()
                health = ollama_tags()
                if not requested:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Nom de modèle attendu."})
                    return
                if health.get("ollama") != "ready":
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "Ollama est indisponible."})
                    return
                if requested not in health.get("models", []):
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Ce modèle n’est pas présent dans Ollama."})
                    return
                cfg = get_config()
                cfg["model_name"] = requested
                save_config(cfg)
                self._send_json(HTTPStatus.OK, {"message": "Modèle local actif mis à jour.", "model_name": requested})
                return
            if endpoint == "/api/library/content-search":
                index = get_library_index()
                query_text = str(payload.get("query") or "").strip()
                if not query_text:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Recherche attendue."})
                    return
                session = current_runtime_session(index)
                rows = content_search(
                    index,
                    str(session.get("core_key") or "aerith7"),
                    query_text,
                    bool(session.get("full_available")),
                    session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                )
                self._send_json(HTTPStatus.OK, {
                    "query": query_text,
                    "results": rows,
                    "rag": {k: get_rag_index(index).get(k) for k in ("built_at", "chunk_count", "source_count", "skipped_nontext", "duplicate_sources")},
                })
                return
            if endpoint == "/api/library/text/read":
                row = read_text_chunk(get_library_index(), str(payload.get("chunk_id") or ""))
                if not row:
                    self._send_json(HTTPStatus.NOT_FOUND, {"error": "Extrait texte introuvable."})
                    return
                self._send_json(HTTPStatus.OK, {"chunk": row})
                return
            if endpoint == "/api/context/preview":
                index = get_library_index()
                session = current_runtime_session(index)
                draft = str(payload.get("draft") or payload.get("message") or "")
                query = f"{session.get('mission') or ''}\n{draft}"
                context = build_context(
                    index,
                    str(session.get("core_key") or "aerith7"),
                    session.get("selected_source_ids") if isinstance(session.get("selected_source_ids"), list) else [],
                    session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                    query,
                    bool(session.get("full_available")),
                    session.get("selected_chunk_ids") if isinstance(session.get("selected_chunk_ids"), list) else [],
                    str(session.get("runtime_mode") or "fast"),
                    bool(session.get("creator_context_enabled")),
                    str(session.get("startup_pack") or ""),
                    session.get("selected_web_source_ids") if isinstance(session.get("selected_web_source_ids"), list) else [],
                    session.get("active_module_source_ids") if isinstance(session.get("active_module_source_ids"), list) else [],
                    str(session.get("current_module_source_id") or ""),
                )
                self._send_json(HTTPStatus.OK, {k: v for k, v in context.items() if k != "text"} | {"preview": context["text"][:12_000], "session": runtime_session_snapshot(index, session)})
                return
            if endpoint == "/api/source/preview":
                source_id = str(payload.get("source_id") or "")
                item = source_map(get_library_index()).get(source_id)
                if not item:
                    self._send_json(HTTPStatus.NOT_FOUND, {"error": "Source introuvable."})
                    return
                try:
                    text = read_source(item)
                    self._send_json(HTTPStatus.OK, {"source": sanitize_source(item), "preview": select_excerpt(text, "", 10_000)})
                except (OSError, ValueError, PermissionError, zipfile.BadZipFile) as exc:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return
            if endpoint == "/api/chat":
                message = str(payload.get("message") or "").strip()
                if not message or len(message) > MAX_CHAT_CHARS:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Message vide ou trop long."})
                    return
                index = get_library_index()
                # La pile vient exclusivement de la session serveur. Le navigateur
                # peut transmettre l’historique d’affichage, jamais sa propre vérité
                # de packs/FULL/Core au moment du chat.
                session = current_runtime_session(index)
                module_resolution = resolve_explicit_module_request(index, message)
                local_module_error = unresolved_module_command_response(index, message, module_resolution)
                if local_module_error:
                    answer, chunks = local_module_error
                    core_key = str(session.get("core_key") or "aerith7")
                    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
                    context = local_context_from_chunks(index, core_key, chunks, session)
                    contract = runtime_contract({"key": core_key, **core}, context, session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [], str(payload.get("lane_id") or "")[:500], str(session.get("startup_pack") or ""), bool(session.get("full_available")))
                    contract["active_modules"] = runtime_session_snapshot(index, session).get("active_modules", [])
                    self._send_json(HTTPStatus.OK, {"content": answer, "context": {k: v for k, v in context.items() if k != "text"}, "contract": contract, "answer_mode": "application-document", "runtime": public_runtime_profile(str(session.get("runtime_mode") or "fast")), "session": runtime_session_snapshot(index, session)})
                    return
                explicit_modules = [dict(source) for source in module_resolution.get("sources", []) if isinstance(source, dict)]
                if explicit_modules:
                    snapshot = mutate_runtime_session(index, "activate-module-sources", {
                        "source_ids": [str(source.get("id") or "") for source in explicit_modules],
                        "current_module_source_id": str(explicit_modules[0].get("id") or ""),
                    })
                    session = current_runtime_session(index)
                    core_key = str(session.get("core_key") or "aerith7")
                    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
                    answer, chunks = module_activation_response(index, session, explicit_modules)
                    context = local_context_from_chunks(index, core_key, chunks, session)
                    contract = runtime_contract({"key": core_key, **core}, context, session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [], str(payload.get("lane_id") or "")[:500], str(session.get("startup_pack") or ""), bool(session.get("full_available")))
                    contract["active_modules"] = snapshot.get("active_modules", [])
                    self._send_json(HTTPStatus.OK, {"content": answer, "context": {k: v for k, v in context.items() if k != "text"}, "contract": contract, "answer_mode": "application-document", "runtime": public_runtime_profile(str(session.get("runtime_mode") or "fast")), "session": snapshot})
                    return
                local_document = local_document_response(index, session, message)
                if local_document:
                    answer, chunks, _kind = local_document
                    core_key = str(session.get("core_key") or "aerith7")
                    core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
                    context = local_context_from_chunks(index, core_key, chunks, session)
                    contract = runtime_contract({"key": core_key, **core}, context, session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [], str(payload.get("lane_id") or "")[:500], str(session.get("startup_pack") or ""), bool(session.get("full_available")))
                    contract["active_modules"] = runtime_session_snapshot(index, session).get("active_modules", [])
                    self._send_json(HTTPStatus.OK, {"content": answer, "context": {k: v for k, v in context.items() if k != "text"}, "contract": contract, "answer_mode": "application-document", "runtime": public_runtime_profile(str(session.get("runtime_mode") or "fast")), "session": runtime_session_snapshot(index, session)})
                    return
                identity_intent = resolve_identity_intent(message)
                # Un changement de Core est permis uniquement quand la demande est
                # explicitement formulée et résolue par le registre. Packs, FULL,
                # pièces jointes et briefing restent intacts.
                if isinstance(identity_intent, dict) and identity_intent.get("kind") == "activate-route":
                    record = identity_intent.get("record") if isinstance(identity_intent.get("record"), dict) else {}
                    requested_core = str(record.get("core_key") or "")
                    if requested_core in CORE_OPTIONS:
                        mutate_runtime_session(index, "set-core", {"core_key": requested_core})
                        session = current_runtime_session(index)
                core_key = str(session.get("core_key") or "aerith7")
                core = CORE_OPTIONS.get(core_key, CORE_OPTIONS["aerith7"])
                mission = str(session.get("mission") or "").strip()[:2000]
                expected = str(session.get("expected") or "Réponse texte").strip()[:300]
                stop_point = str(session.get("stop_point") or "").strip()[:2000]
                lane_id = str(payload.get("lane_id") or "").strip()[:500]
                runtime_mode = str(session.get("runtime_mode") or "fast")
                context = build_context(
                    index, core_key,
                    session.get("selected_source_ids") if isinstance(session.get("selected_source_ids"), list) else [],
                    session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                    f"{mission}\n{message}",
                    bool(session.get("full_available")),
                    session.get("selected_chunk_ids") if isinstance(session.get("selected_chunk_ids"), list) else [],
                    runtime_mode,
                    bool(session.get("creator_context_enabled")),
                    str(session.get("startup_pack") or ""),
                    session.get("selected_web_source_ids") if isinstance(session.get("selected_web_source_ids"), list) else [],
                    session.get("active_module_source_ids") if isinstance(session.get("active_module_source_ids"), list) else [],
                    str(session.get("current_module_source_id") or ""),
                )
                contract = runtime_contract(
                    {"key": core_key, **core},
                    context,
                    session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                    lane_id,
                    str(session.get("startup_pack") or ""),
                    bool(session.get("full_available")),
                )
                contract["active_modules"] = runtime_session_snapshot(index, session).get("active_modules", [])
                if not bool(contract.get("boot_complete")):
                    missing = ", ".join(str(path) for path in (contract.get("boot_missing_paths") or [])) or "source inconnue"
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {
                        "error": f"Boot Seven incomplet : {missing}. Aucun message n’a été envoyé à Ollama.",
                        "context": {k: v for k, v in context.items() if k != "text"},
                        "contract": contract,
                    })
                    return
                history = payload.get("history") if isinstance(payload.get("history"), list) else []
                clean_history = sanitize_history_for_model(history, lane_id)
                contract["history_messages_used"] = len(clean_history)
                messages = [
                    {"role": "system", "content": boot_backbone_text()},
                    {"role": "system", "content": system_prompt(core, context, mission, expected, stop_point, contract, runtime_mode)},
                    *clean_history,
                    {"role": "system", "content": execution_lock(contract)},
                    {"role": "user", "content": message},
                ]
                inventory_symbol = requested_pack_inventory(message)
                inventory_pack = resolved_inventory_pack(inventory_symbol) if inventory_symbol else ""
                if isinstance(identity_intent, dict):
                    answer, verified_sources = verified_identity_intent_response(get_library_index(), session, identity_intent)
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif inventory_pack:
                    answer = verified_pack_inventory_response(get_library_index(), inventory_pack)
                    answer_mode = "application-verified"
                elif requested_pack_state_overview(message):
                    answer, verified_sources = verified_pack_state_overview_response(
                        get_library_index(),
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        str(session.get("startup_pack") or ""),
                        bool(session.get("full_available")),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_archive_count_summary(message):
                    answer, verified_sources = verified_archive_count_summary_response(
                        get_library_index(),
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        str(session.get("startup_pack") or ""),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_active_archive_count(message):
                    answer, verified_sources = verified_active_archive_count_response(
                        get_library_index(),
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        str(session.get("startup_pack") or ""),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_bundled_archive_total(message):
                    answer, verified_sources = verified_bundled_archive_total_response(get_library_index())
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_full_scope_status(message):
                    answer, verified_sources = verified_full_scope_response(
                        get_library_index(),
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        str(session.get("startup_pack") or ""),
                        bool(session.get("full_available")),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_active_archive_state(message):
                    answer, verified_sources = verified_active_archive_state_response(
                        get_library_index(),
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        str(session.get("startup_pack") or ""),
                        bool(session.get("full_available")),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_documentary_activation(message):
                    answer, verified_sources = documentary_activation_status_response(
                        get_library_index(),
                        message,
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        str(session.get("startup_pack") or ""),
                        bool(session.get("full_available")),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_documentary_route_lookup(message) and context.get("documentary_routes"):
                    routes_for_lookup = documentary_routes_for_message(
                        message,
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        bool(session.get("full_available")),
                        str(session.get("startup_pack") or ""),
                    )
                    answer, verified_sources = verified_documentary_route_lookup_response(
                        get_library_index(), routes_for_lookup, message,
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif requested_capabilities_overview(message):
                    answer, verified_sources = verified_capabilities_response(
                        get_library_index(),
                        core_key,
                        session.get("selected_packs") if isinstance(session.get("selected_packs"), list) else [],
                        bool(session.get("full_available")),
                        str(session.get("startup_pack") or ""),
                    )
                    merge_verified_sources(context, verified_sources)
                    answer_mode = "application-verified"
                elif is_creator_recognition_request(message):
                    answer = verified_creator_response(contract)
                    answer_mode = "application-verified"
                elif is_identity_status_request(message):
                    answer = verified_identity_response(contract)
                    answer_mode = "application-verified"
                else:
                    health = ollama_tags()
                    if health.get("ollama") != "ready":
                        self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "Ollama est indisponible. Vérifie qu’il est ouvert."})
                        return
                    if not health.get("model_ready"):
                        self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": f"Le modèle {health.get('model_name') or MODEL_NAME} est absent."})
                        return
                    answer = generate_ollama(messages, str(health.get("model_name") or MODEL_NAME), runtime_mode)
                    validation_error = validate_local_answer(message, answer, contract)
                    if validation_error and is_identity_probe(message):
                        correction = {
                            "role": "system",
                            "content": "Ta réponse précédente est rejetée. Réponds maintenant en 2 à 5 lignes, à la première personne, comme Aerith-7 — Seven Heaven. Dis que tu gardes le Coffre et la mémoire. Ne cite ni chemin, ni source, ni action de chargement.",
                        }
                        retry_messages = [*messages[:-1], correction, messages[-1]]
                        retry = generate_ollama(retry_messages, str(health.get("model_name") or MODEL_NAME), runtime_mode)
                        retry_error = validate_local_answer(message, retry, contract)
                        messages = retry_messages
                        if not retry_error:
                            answer = retry
                            validation_error = ""
                    save_ollama_trace(messages, contract, context, answer)
                    if validation_error:
                        self._send_json(HTTPStatus.UNPROCESSABLE_ENTITY, {
                            "error": "Réponse locale rejetée : " + validation_error + ". Rien n’est affiché comme réponse Seven valide.",
                            "context": {k: v for k, v in context.items() if k != "text"},
                            "contract": contract,
                        })
                        return
                    answer_mode = "ollama"
                self._send_json(HTTPStatus.OK, {
                    "content": answer,
                    "context": {k: v for k, v in context.items() if k != "text"},
                    "contract": contract,
                    "answer_mode": answer_mode,
                    "runtime": public_runtime_profile(runtime_mode),
                    "session": runtime_session_snapshot(index, session),
                })
                return
            restore_match = re.fullmatch(r"/api/sessions/([^/]+)/restore", endpoint)
            if restore_match:
                index = get_library_index()
                saved, runtime_snapshot = restore_saved_session(index, restore_match.group(1))
                self._send_json(HTTPStatus.OK, {
                    "session": saved,
                    "runtime_session": runtime_snapshot,
                    "message": "Session restaurée explicitement dans le runtime local.",
                })
                return
            if endpoint == "/api/sessions/save":
                index = get_library_index()
                runtime_state = current_runtime_session(index)
                # Les faits de pile viennent toujours du runtime, jamais du navigateur.
                payload = {**payload, **runtime_state}
                session = save_session(payload)
                self._send_json(HTTPStatus.OK, {"session": session, "message": "Session sauvegardée localement sur demande."})
                return
            if endpoint == "/api/links":
                links = payload.get("links")
                if not isinstance(links, list):
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Liste de liens attendue."})
                    return
                save_links(links)
                self._send_json(HTTPStatus.OK, {"links": get_links(), "message": "Liens enregistrés localement."})
                return
            self.send_error(HTTPStatus.NOT_FOUND)
        except ValueError as exc:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except Exception as exc:  # pas de trace interne livrée à l’interface
            self._send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": f"Erreur locale : {exc}"})


def open_browser() -> None:
    time.sleep(0.35)
    webbrowser.open(f"http://{HOST}:{PORT}")


def main() -> None:
    ensure_dirs()
    # Les archives sont déjà déposées dans library/packs par le package. Rien n’est téléchargé ici.
    index = get_library_index(force=not LIBRARY_INDEX_PATH.exists())
    # Un nouveau runtime repart toujours de Minimum. Les sauvegardes sont explicites
    # et ne deviennent jamais une restauration implicite de packs dans le navigateur.
    reset_runtime_session(index)
    try:
        server = ThreadingHTTPServer((HOST, PORT), AppHandler)
    except OSError as exc:
        print(f"Impossible de démarrer Seven Heaven Local sur http://{HOST}:{PORT}.")
        print("Le port est déjà utilisé ou indisponible. Arrête l’ancienne instance avec STOP_AERITH_LOCAL.bat, puis relance.")
        print(f"Détail : {exc}")
        raise SystemExit(1)
    print(f"{APP_NAME} — {APP_VERSION}")
    print(f"Dossier stable : {ROOT}")
    print(f"Interface : http://{HOST}:{PORT}")
    print("Base locale prête ; URL publique ponctuelle disponible seulement en mode Connecté ; Git local en lecture seule.")
    threading.Thread(target=open_browser, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
