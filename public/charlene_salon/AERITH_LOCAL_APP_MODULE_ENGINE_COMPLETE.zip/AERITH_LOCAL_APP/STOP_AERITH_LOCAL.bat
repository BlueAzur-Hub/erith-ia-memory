@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8765/api/runtime/stop' -Method POST -ContentType 'application/json' -Body '{}'; Write-Host $r.Content } catch { Write-Host 'Aucun runtime Seven Heaven Local actif sur le port 8765.'; exit 1 }"
echo.
pause
endlocal
