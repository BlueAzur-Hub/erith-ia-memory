# PATCH — Sessions locales explicites

- Sauvegarde volontaire uniquement ; Nouveau chat ne crée plus d’archive automatique.
- Une nouvelle sauvegarde nommée reçoit un identifiant local unique ; une session restaurée peut être mise à jour volontairement.
- Aperçu sans mutation de runtime.
- Restauration confirmée via une route serveur dédiée.
- Le runtime reste l’unique source de vérité ; les URL temporaires sont exclues de toute sauvegarde et effacées lors d’une restauration.
