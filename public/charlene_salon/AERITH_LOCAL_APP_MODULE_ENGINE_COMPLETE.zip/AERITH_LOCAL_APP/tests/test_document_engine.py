#!/usr/bin/env python3
"""Offline contract tests for Seven Heaven's local document engine.

No Ollama process is required. These tests prove catalogue, activation,
current-document reads, family context, ambiguity, and history sanitation.
"""
from __future__ import annotations
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import AERITH_LOCAL_APP as app  # noqa: E402


def index():
    return app.get_library_index(force=True)


def activate(idx, query: str):
    result = app.resolve_explicit_module_request(idx, query)
    assert result["status"] == "ok", result
    sources = result["sources"]
    assert sources
    app.reset_runtime_session(idx)
    app.mutate_runtime_session(idx, "activate-module-sources", {
        "source_ids": [str(source["id"]) for source in sources],
        "current_module_source_id": str(sources[0]["id"]),
    })
    return app.current_runtime_session(idx), sources


def test_catalog_covers_every_unique_module_document():
    idx = index()
    expected = {
        str(source["relative_path"])
        for source in app.preferred_rag_sources(idx)
        if app.is_module_document(source)
    }
    catalog = app.module_catalog(idx)
    got = {str(entry["source"]["relative_path"]) for entry in catalog["entries"]}
    assert got == expected
    assert catalog["formats"].get(".md", 0) > 0
    assert catalog["formats"].get(".json", 0) > 0


def test_psychology_is_real_current_document_and_context():
    idx = index()
    session, sources = activate(idx, "charge le module de psychologie")
    assert sources[0]["relative_path"] == "modules/erith_ia_psychologie_discernement_fr.md"
    response = app.local_document_response(idx, session, "résume ce module")
    assert response is not None
    answer, chunks, _ = response
    assert "Intention" in answer and "Protocole" in answer
    assert {row["relative_path"] for row in chunks} == {sources[0]["relative_path"]}
    context = app.build_context(
        idx, "aerith7", session["selected_source_ids"], session["selected_packs"],
        "j ai mal dormi et suis dans le brouillard", False, [], "fast", False,
        session["startup_pack"], [], session["active_module_source_ids"], session["current_module_source_id"],
    )
    module_paths = {
        row["relative_path"] for row in context["retrieved"]
        if str(row.get("use_type", "")).startswith("module actif")
    }
    assert module_paths == {sources[0]["relative_path"]}
    assert any("Brouillard" in str(row.get("heading")) for row in context["retrieved"])


def test_sword_family_context_uses_all_levels():
    idx = index()
    session, sources = activate(idx, "charge le module épée de vérité")
    assert len(sources) == 4
    context = app.build_context(
        idx, "aerith7", session["selected_source_ids"], session["selected_packs"],
        "quelles idées principales", False, [], "deep", False,
        session["startup_pack"], [], session["active_module_source_ids"], session["current_module_source_id"],
    )
    module_paths = [
        row["relative_path"] for row in context["retrieved"]
        if str(row.get("use_type", "")).startswith("module actif")
    ]
    assert set(module_paths) == {str(source["relative_path"]) for source in sources}


def test_unknown_and_ambiguous_loads_stay_local():
    idx = index()
    unknown = app.resolve_explicit_module_request(idx, "charge le module de mémoire inconnu")
    assert unknown["status"] == "not_found"
    local = app.unresolved_module_command_response(idx, "charge le module de mémoire inconnu", unknown)
    assert local and "session n’a pas changé" in local[0]
    ambiguous = app.resolve_explicit_module_request(idx, "charge le module histoire mondiale master")
    assert ambiguous["status"] == "ambiguous"
    local = app.unresolved_module_command_response(idx, "charge le module histoire mondiale master", ambiguous)
    assert local and "plusieurs modules" in local[0]


def test_json_module_is_catalogued_and_read_locally():
    idx = index()
    session, sources = activate(idx, "charge le module faune sauvage cueillette discernement")
    assert sources[0]["relative_path"].endswith(".json")
    response = app.local_document_response(idx, session, "lis moi le début du fichier")
    assert response and "objectif" in response[0].lower()


def test_fake_and_local_history_is_not_sent_to_ollama():
    history = [
        {"role": "assistant", "lane": "chat", "content": "Je vais charger le module de psychologie."},
        {"role": "assistant", "lane": "chat", "content": "Chargement local effectué."},
        {"role": "assistant", "lane": "chat", "content": "Réponse ordinaire utile."},
        {"role": "user", "lane": "chat", "content": "Explique moi le module."},
    ]
    clean = app.sanitize_history_for_model(history, "chat")
    assert [row["content"] for row in clean] == ["Réponse ordinaire utile.", "Explique moi le module."]

# HTTP path test is kept below the simple runner definitions so it can be run
# as a standalone file without any external test framework.
def test_http_local_document_commands_never_need_ollama():
    import json
    import threading
    import urllib.request
    from http.server import ThreadingHTTPServer
    idx = index()
    app.reset_runtime_session(idx)
    server = ThreadingHTTPServer(("127.0.0.1", 0), app.AppHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    def post(path, payload):
        raw = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(base + path, data=raw, method="POST", headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read().decode("utf-8"))
    try:
        loaded = post("/api/chat", {"message": "charge le module de psychologie", "history": [], "lane_id": "test"})
        assert loaded["answer_mode"] == "application-document"
        assert "Psychologie & Discernement" in loaded["content"]
        read = post("/api/chat", {"message": "lis moi le début du fichier", "history": [], "lane_id": "test"})
        assert read["answer_mode"] == "application-document"
        assert "Module Mémoire Psychologie" in read["content"]
        unknown = post("/api/chat", {"message": "charge le module de mémoire inconnu", "history": [], "lane_id": "test"})
        assert unknown["answer_mode"] == "application-document"
        assert "session n’a pas changé" in unknown["content"]
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=3)


if __name__ == "__main__":
    tests = [name for name in sorted(globals()) if name.startswith("test_")]
    failures = []
    for name in tests:
        try:
            globals()[name]()
            print(f"OK {name}")
        except Exception as exc:  # noqa: BLE001
            failures.append((name, exc))
            print(f"FAIL {name}: {exc}")
    if failures:
        raise SystemExit(1)
    print(f"PASS {len(tests)} tests")
