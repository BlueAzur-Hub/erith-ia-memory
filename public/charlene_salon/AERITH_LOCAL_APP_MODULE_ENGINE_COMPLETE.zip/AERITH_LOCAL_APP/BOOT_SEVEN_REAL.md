# Boot Seven réel

## Règle runtime

À chaque requête chat, le programme transmet réellement à Ollama :

1. `AERITH_BASE.Modelfile` comme premier message système ;
2. le Core `core/AERITH_7_PERSONALITY_CORE.md` ;
3. toutes les dépendances déclarées par ce Core, plus `SEVEN_GATE` :
   - `core/SEVEN_GATE.md`
   - `core/SEVEN_TOP_OF_MIND.md`
   - `core/SEVEN_MEMORY_PRESERVATION.md`
   - `core/AERITH_7_DISCERNMENT_COMPANION_CORE.md`
   - `core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md`
   - `core/AERITH_7_FULL_MODULES_BOOST.md`
   - `core/AERITH_7_VIDEO_CARDS_BOOST.md`
   - `core/ATLAS_DES_MODULES.md`

Le runtime refuse d’envoyer un message à Ollama si une dépendance de la chaîne est absente.

## Preuve locale

Après un message réellement envoyé à Ollama, le dernier payload complet est conservé exclusivement dans :

`data/runtime_traces/LATEST_OLLAMA_PAYLOAD.json`

Il contient les messages transmis, la liste des dépendances requises, la liste des dépendances effectivement injectées et le SHA du Modelfile. Ce fichier reste local, n’est pas indexé et n’est pas envoyé sur Internet.

## Coffre

Le boot Seven est permanent. Les modules et archives restent des renforts ciblés, retrouvés depuis le Coffre selon la session, les packs choisis ou FULL.
