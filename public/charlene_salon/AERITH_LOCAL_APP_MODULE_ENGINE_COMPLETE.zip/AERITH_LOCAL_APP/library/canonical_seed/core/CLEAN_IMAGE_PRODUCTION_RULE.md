# 🖼️ CLEAN IMAGE PRODUCTION RULE

Statut : règle Core de production obligatoire  
Projet : @erith IA / ERITH.IA / Seven Heaven  
Portée : toutes les images du projet  
Usage : images finales, concept arts, thumbnails, bannières, modules UI, overlays, icônes, assets HTML/CSS, éléments transparents, GitHub Pages, Notion, YouTube, workflows image / vidéo
Version : Clean Updated Green Key / AAA Transparent — 2026-06-16

---

# 0. Image de référence — base transparente officielle

![Aerith transparent 1920x1080 RGBA](../assets/images/Aerith_transparent_1920x1080_RGBA.png)

Cette image sert de référence technique pour les fichiers PNG RGBA transparents du projet.

Elle rappelle la règle centrale : un fichier transparent n’est pas un visuel sur fond blanc, noir, gris ou damier. C’est un fichier avec canal alpha réel, vérifiable techniquement.

# 1. Principe central

Toute image livrée dans le projet doit avoir un fond propre, volontaire et exploitable.

Il ne doit jamais y avoir de faux fond accidentel.

Il ne doit jamais y avoir de damier imprimé.

Il ne doit jamais y avoir de transparence simulée.

Formule centrale :

**Image opaque = fond assumé.**  
**Image transparente = alpha réel.**  
**Damier imprimé interdit.**

Règle ajoutée après incident Blue Azur — 2026-06-16 :

**Transparence demandée = composition technique RGBA, pas génération directe.**

Formule opératoire :

**Canvas RGBA alpha 0 → ajout du visuel → export PNG RGBA → vérification alpha.**

---

# 2. Règle absolue

Pour toutes les images du projet :

- damier imprimé = refus immédiat ;
- faux transparent = refus ;
- fond blanc accidentel = refus ;
- fond noir accidentel = refus ;
- fond gris accidentel = refus ;
- carré visible autour du sujet = refus ;
- image prétendue transparente sans alpha réel = refus ;
- PNG sans canal alpha alors qu’il doit être transparent = refus ;
- génération directe prétendue transparente sans vérification technique = refus ;
- fichier RGB livré comme transparent = refus ;
- transparence transformée en damier visuel = refus ;
- contour sale autour d’un asset transparent = refus ;
- frange verte, bleue, blanche, noire ou grise après extraction = refus ;
- fond uni de travail livré comme final = refus.

Cette règle s’applique à toutes les images, pas seulement aux modules UI.

---

# 3. Deux cas possibles seulement

## 3.1 Image opaque

L’image possède un vrai fond assumé.

Exemples :

- décor complet ;
- background artistique ;
- scène entière ;
- illustration pleine ;
- vignette YouTube ;
- image de présentation ;
- image de clôture ;
- concept art ;
- frame vidéo ;
- image source pour animation.

Dans ce cas, le fond doit être voulu, beau, cohérent et propre.

Le fond ne doit pas être un accident.

## 3.2 Image transparente

L’image est destinée à être posée sur un autre fond.

Exemples :

- module UI ;
- personnage détouré ;
- icône ;
- logo ;
- bannière transparente ;
- overlay ;
- nuage ;
- cristal ;
- ruine ;
- bouton ;
- élément décoratif ;
- asset HTML/CSS ;
- fragment d’interface ;
- asset de composition.

Dans ce cas, le seul format acceptable est :

**PNG RGBA avec canal alpha réel.**

Un fichier PNG en mode RGB n’est pas un fichier transparent.

Un damier visible dans les pixels n’est pas de la transparence.

---

# 4. Règle IA

Ne jamais faire confiance à une génération d’image qui prétend être transparente.

Une IA générative peut créer un visuel.

Mais une IA générative ne doit pas être considérée comme garante du fichier transparent final.

Si l’image doit être transparente, la transparence finale doit être construite par une méthode technique déterministe :

1. créer ou ouvrir un canvas RGBA aux dimensions finales ;
2. initialiser le fond en alpha 0 ;
3. générer ou importer le visuel comme élément séparé ;
4. poser le visuel sur le canvas sans remplir le fond ;
5. exporter en PNG RGBA ;
6. vérifier techniquement le canal alpha.

Formule officielle mise à jour :

**L’IA peut générer le visuel.**  
**Le pipeline technique fabrique le fichier transparent.**  
**Seven vérifie la transparence réelle avant livraison.**

Formule courte :

**Transparence demandée = composition technique RGBA, pas génération directe.**

Interdiction critique :

Ne jamais envoyer un fichier transparent fourni par Christophe comme simple référence visuelle si la mission consiste à préserver son alpha.

Dans ce cas, le fichier transparent est une base technique.

Il doit être conservé, ouvert, utilisé comme canvas ou reconstruit en canvas RGBA équivalent, puis vérifié.

---

## 4.1 Méthode hybride validée — image AAA + transparence réelle

Règle importante ajoutée après validation Blue Azur — 2026-06-16 :

**image_gen est utile pour créer l’art AAA du cartouche.**  
**image_gen ne doit pas être responsable du fichier transparent final.**

La bonne chaîne est hybride :

1. utiliser image_gen uniquement pour produire le **cartouche AAA visuel** ;
2. ne pas demander à image_gen de produire le PNG RGBA final ;
3. considérer la sortie image_gen comme une **image de travail artistique**, pas comme le fichier transparent final ;
4. créer ensuite un canvas technique aux dimensions finales ;
5. poser le cartouche sur ce canvas ;
6. exporter en PNG RGBA ;
7. vérifier l’alpha.

Formule validée :

**AAA = image_gen.**  
**Transparence = pipeline technique RGBA.**  
**Fichier final = assemblage contrôlé.**

Formule Blue Azur validée :

**Cartouche AAA généré séparément → canvas RGBA 2048×1152 alpha 0 → placement du cartouche → export PNG RGBA → vérification alpha.**

Ce qui est interdit :

- demander à image_gen de garantir la transparence finale ;
- livrer la sortie image_gen brute comme PNG transparent final ;
- accepter un damier imprimé comme preuve de transparence ;
- faire un détourage sale d’un damier ou d’un fond parasite ;
- sacrifier l’art AAA en remplaçant le cartouche par un dessin pauvre au script.

Ce qui est obligatoire :

- utiliser image_gen pour l’esthétique quand une qualité AAA est demandée ;
- utiliser Python, Photoshop ou un pipeline RGBA contrôlé pour le fichier final ;
- distinguer clairement **image de travail** et **fichier final** ;
- vérifier techniquement le PNG final avant livraison.

---

## 4.2 Méthode opératoire validée — bannière AAA transparente

Cette méthode est la méthode correcte quand Christophe demande une bannière YouTube AAA avec fond transparent.

Elle corrige l’erreur répétée suivante :

**vouloir demander à une seule génération IA de produire à la fois l’art AAA et le fichier PNG RGBA final.**

Cette approche est interdite pour le fichier final.

La bonne méthode sépare deux responsabilités :

## Étape A — image_gen produit l’art AAA

image_gen doit être utilisé pour ce qu’il sait faire :

- créer une image riche ;
- créer une composition premium ;
- créer un cartouche Blue Azur ;
- produire une esthétique AAA ;
- générer une bannière visuelle forte.

Mais image_gen ne doit pas être considéré comme garant de :

- l’alpha final ;
- le mode RGBA final ;
- les coins transparents ;
- l’absence de damier dans les pixels ;
- la conformité technique du PNG final.

Règle :

**La sortie image_gen est une matière artistique, pas le fichier final transparent.**

## Étape B — contrôle du cartouche

Avant assemblage, le cartouche doit être validé visuellement.

Il doit être rejeté si :

- il contient un damier imprimé ;
- il contient un fond blanc, noir ou gris qui doit rester transparent ;
- il ressemble à une interface de choix ou à une capture d’écran ;
- il contient des textes parasites ;
- il contient des personnages ou licences reconnaissables non demandés ;
- il est graphiquement pauvre ;
- il ne correspond pas au niveau AAA demandé.

Si le cartouche est mauvais, on ne passe pas à l’étape RGBA.

## Étape C — assemblage technique RGBA

Le fichier final doit être créé séparément.

Méthode technique :

1. ouvrir ou récupérer le cartouche AAA validé ;
2. créer un canvas final 2048 × 1152 en RGBA ;
3. initialiser tout le canvas en alpha 0 ;
4. placer le cartouche dans la zone safe YouTube ;
5. ne rien ajouter hors cartouche ;
6. exporter en PNG RGBA ;
7. vérifier techniquement l’alpha.

Le cœur technique est :

```python
from PIL import Image

canvas = Image.new("RGBA", (2048, 1152), (0, 0, 0, 0))
canvas.alpha_composite(cartouche_rgba, (x, y))
canvas.save("BLUE_AZUR_BANNER_AAA_TRANSPARENT_RGBA_2048x1152_FINAL.png")
```

Cette ligne est décisive :

```python
Image.new("RGBA", (2048, 1152), (0, 0, 0, 0))
```

Elle signifie :

- image en RGBA ;
- taille finale YouTube ;
- fond entièrement transparent ;
- alpha 0 partout avant insertion du cartouche.

## Étape D — vérification obligatoire

Après export, le fichier final doit être vérifié.

Code minimal :

```python
from PIL import Image

img = Image.open("BLUE_AZUR_BANNER_AAA_TRANSPARENT_RGBA_2048x1152_FINAL.png")
assert img.mode == "RGBA"
assert img.size == (2048, 1152)

alpha = img.getchannel("A")

print("mode:", img.mode)
print("size:", img.size)
print("alpha:", alpha.getextrema())
print("corner TL:", img.getpixel((0, 0)))
print("corner TR:", img.getpixel((2047, 0)))
print("corner BL:", img.getpixel((0, 1151)))
print("corner BR:", img.getpixel((2047, 1151)))
```

Résultat attendu :

```text
mode: RGBA
size: (2048, 1152)
alpha: (0, 255)
corner TL: (..., 0)
corner TR: (..., 0)
corner BL: (..., 0)
corner BR: (..., 0)
```

Le quatrième canal des quatre coins doit être 0.

## Étape E — livraison

Le fichier livrable est uniquement le fichier assemblé techniquement.

Ne jamais livrer comme final :

- la sortie brute image_gen ;
- une image avec damier ;
- une image opaque ;
- un fichier RGB ;
- un fichier détouré à partir d’un damier imprimé ;
- une preview sur fond noir, blanc ou bleu ;
- une capture écran.

Le livrable correct est :

**PNG RGBA 2048 × 1152 avec alpha réel et coins alpha 0.**

Formule opératoire validée :

**image_gen crée le cartouche AAA.**  
**Le pipeline RGBA fabrique le fichier final.**  
**La vérification alpha autorise la livraison.**


---

## 4.3 Méthode réellement validée — cartouche AAA puis recomposition RGBA

Cette section décrit la méthode qui a réellement permis d’obtenir une bannière Blue Azur à la fois :

- visuellement AAA ;
- en PNG RGBA ;
- en 2048 × 1152 ;
- avec alpha réel autour du cartouche ;
- sans livrer la sortie brute image_gen comme fichier final.

Le point décisif est la séparation stricte entre deux métiers :

**image_gen produit l’art.**  
**Python / Photoshop / pipeline RGBA produit le fichier final transparent.**

### Étape 1 — produire uniquement le cartouche AAA

La première étape consiste à demander à image_gen uniquement une image artistique du cartouche.

Commande-type :

```text
Génère uniquement le cartouche AAA visuel Blue Azur sur fond uni contrôlé, sans transparence finale.
Ne produis pas le fichier PNG RGBA final.
Le cartouche doit être premium, détaillé, lumineux, lisible, fantasy / RPG / sci-fi / PC gaming.
```

Règle :

La sortie image_gen est une **matière artistique**.

Elle n’est pas le fichier final.

Même si image_gen affiche un damier, un fond blanc, un fond sombre ou une zone de présentation autour du cartouche, cette sortie reste une source de travail, pas une preuve de transparence.

### Étape 2 — valider le cartouche visuellement

Avant toute opération RGBA, le cartouche doit être jugé sur sa qualité artistique :

- niveau AAA ;
- composition premium ;
- texte lisible ;
- cartouche central fort ;
- style cohérent ;
- pas de rendu pauvre ;
- pas de dessin procédural simpliste ;
- pas de fond parasite à livrer comme final.

Si le cartouche n’est pas bon, il faut régénérer le cartouche.

Il ne faut pas essayer de sauver un cartouche faible par une bonne transparence.

### Étape 3 — extraire uniquement le cartouche comme matière de travail

Si la sortie image_gen contient un fond de présentation ou un damier imprimé autour du cartouche, il ne faut pas livrer cette sortie brute.

Deux cas :

**Cas idéal :**
Le cartouche est généré sur un fond uni simple ou peut être isolé proprement.

**Cas de récupération contrôlée :**
Le cartouche AAA est très bon, mais image_gen a imprimé un damier de présentation autour. Dans ce cas, l’extraction contrôlée du cartouche est autorisée uniquement comme étape technique intermédiaire, à condition de ne jamais prétendre que la sortie image_gen était transparente.

Cette récupération contrôlée n’est pas une “preuve de transparence”.

La transparence finale est recréée ensuite par le canvas RGBA.

Règle :

**Damier dans la sortie image_gen = sortie non finale.**  
**Cartouche récupérable = matière artistique seulement.**  
**Fichier final = nouveau PNG RGBA reconstruit.**

### Étape 4 — créer un nouveau canvas final en RGBA

Le fichier final doit être créé à partir de zéro :

```python
from PIL import Image

canvas = Image.new("RGBA", (2048, 1152), (0, 0, 0, 0))
```

Cette ligne signifie :

- largeur : 2048 ;
- hauteur : 1152 ;
- mode : RGBA ;
- alpha 0 partout ;
- aucun fond blanc ;
- aucun fond noir ;
- aucun damier ;
- aucune image de présentation.

### Étape 5 — placer le cartouche sur le canvas

Le cartouche AAA validé est posé sur le canvas transparent :

```python
canvas.alpha_composite(cartouche_rgba, (x, y))
```

Le placement recommandé pour Blue Azur est :

```text
canvas : 2048 × 1152
zone visible finale recommandée : environ X 230 → 1820, Y 350 → 800
texte principal : au centre de la zone sûre
extérieur du cartouche : alpha 0
```

### Étape 6 — exporter le PNG final

```python
canvas.save("BLUE_AZUR_BANNER_AAA_TRANSPARENT_RGBA_2048x1152_FINAL.png")
```

Ce fichier est le seul livrable final.

La sortie brute image_gen, les previews sur fond blanc, les previews sur fond noir et les captures d’écran ne sont pas le livrable.

### Étape 7 — vérifier techniquement

Vérification obligatoire :

```python
from PIL import Image

img = Image.open("BLUE_AZUR_BANNER_AAA_TRANSPARENT_RGBA_2048x1152_FINAL.png")
assert img.mode == "RGBA"
assert img.size == (2048, 1152)

alpha = img.getchannel("A")

print("mode:", img.mode)
print("size:", img.size)
print("alpha extrema:", alpha.getextrema())
print("coin haut gauche:", img.getpixel((0, 0)))
print("coin haut droit:", img.getpixel((2047, 0)))
print("coin bas gauche:", img.getpixel((0, 1151)))
print("coin bas droit:", img.getpixel((2047, 1151)))
```

Résultat attendu :

```text
mode: RGBA
size: (2048, 1152)
alpha extrema: (0, 255)
coin haut gauche: (..., 0)
coin haut droit: (..., 0)
coin bas gauche: (..., 0)
coin bas droit: (..., 0)
```

Le quatrième canal des quatre coins doit être 0.

### Résultat Blue Azur validé

La méthode validée a produit un fichier avec :

```text
mode : RGBA
taille : 2048 × 1152
alpha : 0 → 255
coins : alpha 0
zone visible : environ X 231 → 1816, Y 356 → 795
extérieur du cartouche : transparent réel
```

Conclusion technique :

**Ce n’est pas image_gen qui a fabriqué la transparence finale.**  
**C’est le canvas RGBA final qui a fabriqué la transparence.**  
**image_gen a seulement fourni l’art AAA du cartouche.**

---

## 4.4 Distinction critique — extraction contrôlée ≠ détourage sale

Le projet interdit le détourage sale.

Mais il faut distinguer deux situations.

### Interdit : détourage sale présenté comme transparence native

Est interdit :

- retirer grossièrement un damier ;
- effacer un fond au hasard ;
- créer des halos sales ;
- livrer une image abîmée ;
- prétendre qu’une image_gen avec damier est un vrai PNG transparent ;
- livrer une sortie brute image_gen comme final transparent.

### Autorisé : récupération contrôlée d’un cartouche AAA

Est autorisé uniquement comme étape intermédiaire :

- isoler techniquement un cartouche AAA validé ;
- supprimer le fond de présentation connecté aux bords ;
- transformer ce cartouche en élément RGBA ;
- le replacer sur un nouveau canvas RGBA alpha 0 ;
- vérifier le fichier final.

Cette étape est une récupération contrôlée de matière artistique.

Elle ne doit jamais être appelée “transparence native de image_gen”.

Formule :

**Détourage sale = interdit.**  
**Extraction contrôlée = tolérée si le cartouche AAA est validé et si le final est reconstruit en RGBA.**  
**Transparence finale = toujours vérification alpha.**

## 4.5 Correction critique — éviter le faux “cartouche transparent propre”

Nouvelle conclusion validée après tests Blue Azur :

**Un fichier peut être techniquement transparent et rester artistiquement mauvais.**

Exemple de cas rejeté :

- canal alpha réel présent ;
- fond extérieur transparent ;
- mais contour du cartouche sale ;
- extraction visible ;
- bord irrégulier ;
- effet “découpé aux ciseaux” ;
- micro-résidus ou halo ;
- impression de détourage amateur.

Verdict dans ce cas :

**PNG RGBA : oui.**  
**Transparence réelle : oui.**  
**Livrable AAA : non.**

Cause principale :

**extraire automatiquement un cartouche complexe depuis une image de présentation avec fond, damier ou cadre parasite.**

Cette méthode est instable et produit souvent un contour sale.

### Ce qu’il faut faire

#### Option A — forme simple recommandée

Si le cartouche final peut être simple :

- générer un cartouche AAA dans une forme propre ;
- privilégier un rectangle, rounded rectangle, capsule ou cadre net ;
- placer ce cartouche propre sur le canvas RGBA final ;
- conserver un bord net sans extraction complexe.

C’est la méthode recommandée par défaut.

#### Option B — forme complexe premium

Si le cartouche final doit avoir une silhouette complexe, baroque ou irrégulière :

- ne pas utiliser une suppression de fond automatique brute ;
- ne pas se contenter d’un détourage automatique ;
- fabriquer ou fournir un **masque alpha propre** ;
- ou utiliser un fichier source déjà propre ;
- ou faire une préparation Photoshop propre ;
- ou utiliser un masque manuel / vectoriel / couche alpha dédiée.

Dans ce cas, la qualité du masque fait partie du livrable.

### Ce qu’il ne faut PAS faire

- détourer automatiquement un bord complexe depuis une image avec fond ;
- supprimer “à l’arrache” un damier, un fond noir ou un fond de présentation ;
- livrer un contour irrégulier sous prétexte que le fond est techniquement transparent ;
- confondre “alpha réel” et “bannière premium validée” ;
- croire qu’un détourage sale devient acceptable parce que le fichier est en RGBA.

Formule de correction :

**Transparence seule ne suffit pas.**  
**Un cartouche premium doit être transparent ET propre sur son contour.**  
**Bord complexe = masque propre obligatoire.**


---

## 4.6 Méthode Green Key / fond uni contrôlé — cartouche AAA exploitable

Nouvelle conclusion validée après test Blue Azur :

**Pour obtenir une image AAA transparente exploitable, il est souvent préférable de générer le cartouche AAA sur un fond uni contrôlé, puis de fabriquer la transparence finale techniquement.**

Cette méthode évite :

- le damier imprimé ;
- le faux transparent ;
- le détourage sale depuis un damier ;
- le contour “découpé aux ciseaux” ;
- le dessin procédural pauvre ;
- le bord baroque impossible à extraire proprement.

### Principe

La génération IA doit produire :

**un cartouche AAA propre sur fond uni contrôlé.**

Le pipeline technique doit ensuite produire :

**un PNG RGBA transparent final.**

Formule :

**image_gen = art AAA du cartouche.**  
**fond uni contrôlé = extraction propre possible.**  
**canvas RGBA = transparence finale.**

### Fond recommandé

Fond de travail possible :

- vert uni pur ;
- bleu uni pur ;
- magenta uni pur ;
- noir uni uniquement si le cartouche n’a pas de bords noirs ;
- fond blanc uni uniquement si le cartouche n’a pas de bords clairs.

Pour Blue Azur, la méthode validée la plus lisible est :

**cartouche AAA sur fond vert uni contrôlé → suppression propre du vert → canvas RGBA 2048×1152 alpha 0 → export PNG RGBA.**

### Conditions obligatoires

Le fond uni doit être :

- uniforme ;
- non texturé ;
- non dégradé ;
- sans damier ;
- sans ombre portée externe ;
- sans glow diffus dans le fond ;
- sans bruit ;
- sans motif ;
- clairement séparé du cartouche.

Le cartouche doit être :

- AAA ;
- lisible ;
- propre ;
- net ;
- de préférence rectangulaire, capsule ou rounded rectangle ;
- avec un bord continu ;
- sans contour baroque trop fragile si aucun masque propre n’est disponible.

### Ce qu’il faut faire

1. Générer un cartouche AAA sur fond uni contrôlé.
2. Choisir une forme simple si aucun masque alpha propre n’est disponible.
3. Éviter les ornements qui sortent trop finement du contour.
4. Supprimer le fond uni par keying ou sélection contrôlée.
5. Créer un nouveau canvas RGBA 2048×1152 avec alpha 0.
6. Poser le cartouche extrait proprement dans la zone safe.
7. Exporter en PNG RGBA.
8. Vérifier l’alpha et les coins.
9. Vérifier la propreté du bord sur fond clair et sombre.

### Ce qu’il ne faut PAS faire

- ne pas demander à image_gen de produire directement le PNG transparent final ;
- ne pas générer sur damier ;
- ne pas extraire depuis un damier imprimé ;
- ne pas livrer la sortie image_gen brute ;
- ne pas accepter un contour sale sous prétexte que l’alpha est correct ;
- ne pas utiliser un fond vert si le cartouche contient beaucoup de vert sur ses bords ;
- ne pas laisser de frange verte autour du cartouche ;
- ne pas laisser d’ombre verte ou de halo coloré ;
- ne pas confondre preview sur fond vert et fichier final transparent.

### Test de validation

Le fichier final doit passer deux tests.

#### Niveau 1 — technique

- PNG ;
- RGBA ;
- dimensions demandées ;
- alpha réel ;
- coins alpha 0 ;
- extérieur du cartouche transparent.

#### Niveau 2 — artistique / asset AAA

- bord net ;
- pas de frange verte ;
- pas de halo sale ;
- pas de miettes ;
- pas de résidus ;
- pas d’effet ciseaux ;
- cartouche premium exploitable.

Règle :

**Fond vert retiré + contour sale = refus.**  
**Alpha correct + frange verte = refus.**  
**Cartouche AAA + bord propre + PNG RGBA vérifié = livraison possible.**

### Formule finale validée

```text
Image AAA par image_gen.
Fond de travail uni contrôlé.
Suppression propre du fond.
Canvas RGBA 2048×1152 alpha 0.
Placement du cartouche.
Export PNG RGBA.
Vérification alpha + contrôle du contour.
```


# 5. Méthode correcte

## 5.1 Méthode générale pour créer un asset transparent

Pour créer un asset transparent :

1. créer ou générer le visuel ;
2. décider si la silhouette finale est **simple** ou **complexe** ;
3. si la silhouette est simple, privilégier une forme propre et nette dès la génération ;
4. si la silhouette est complexe, préparer un masque alpha propre ou une source propre ;
5. éviter toute extraction automatique sale depuis un fond de présentation ;
6. créer un vrai canal alpha ;
7. exporter en PNG RGBA ;
8. vérifier l’alpha ;
9. vérifier aussi la **propreté du contour** ;
10. tester l’asset sur fond clair ;
11. tester l’asset sur fond sombre ;
12. tester l’asset sur le background final si nécessaire ;
13. intégrer seulement après validation.

Règle :

**Alpha correct + contour sale = refus.**

## 5.2 Méthode obligatoire quand Christophe fournit une base transparente

Si Christophe fournit une image transparente de base, le protocole change.

La base transparente ne doit pas être réinterprétée par le générateur.

Elle doit être utilisée comme support technique.

Méthode obligatoire :

1. ouvrir la base transparente ;
2. confirmer qu’elle est en RGBA ;
3. confirmer que son fond est en alpha 0 ;
4. conserver ou recréer un canvas RGBA aux dimensions finales ;
5. ajouter uniquement le visuel, le cartouche, l’overlay ou le module demandé ;
6. ne jamais remplir le canvas avec du blanc, du noir, du gris ou un damier ;
7. exporter en PNG RGBA ;
8. vérifier les coins ;
9. vérifier l’existence du canal alpha ;
10. livrer seulement si l’alpha est réel.

Formule :

**Base transparente = fond intouchable.**  
**On ajoute le visuel.**  
**On ne régénère pas la transparence.**

---

# 6. Vérification obligatoire

Avant validation :

- si l’image est opaque, le fond doit être volontaire et propre ;
- si l’image est transparente, le fichier doit être PNG RGBA ;
- le canal alpha doit exister réellement ;
- les coins transparents doivent avoir alpha = 0 quand le sujet ne remplit pas toute l’image ;
- aucun damier ne doit être imprimé ;
- aucun carré parasite ne doit apparaître ;
- aucun fond blanc, noir ou gris accidentel ne doit rester ;
- le fichier doit être testé sur fond clair ;
- le fichier doit être testé sur fond sombre ;
- le fichier doit être testé sur le background final si l’usage final est connu.

Vérification technique minimale :

- mode = RGBA ;
- dimensions = dimensions demandées ;
- canal A présent ;
- alpha extrema différent d’un fichier opaque ;
- coins attendus transparents avec alpha 0 ;
- absence de damier dans les pixels visibles ;
- si le fond est supposé vide, aucun pixel opaque ne doit exister hors de la zone utile.

Pour Python / Pillow, la vérification minimale est :

```python
from PIL import Image

img = Image.open("fichier.png")
assert img.mode == "RGBA"
alpha = img.getchannel("A")
print(img.size)
print(alpha.getextrema())
print(img.getpixel((0, 0)))
print(img.getpixel((img.width - 1, 0)))
print(img.getpixel((0, img.height - 1)))
print(img.getpixel((img.width - 1, img.height - 1)))
```

Un coin transparent doit afficher un quatrième canal à 0, par exemple :

```text
(0, 0, 0, 0)
```

ou une couleur quelconque avec alpha 0, par exemple :

```text
(255, 255, 255, 0)
```

Ce qui compte est le quatrième nombre : alpha = 0.

---

# 7. Interdictions absolues

Il est interdit de livrer comme “transparent” :

- une image avec damier imprimé ;
- une image JPG ;
- une image PNG avec fond blanc ;
- une image PNG avec fond noir ;
- une image PNG avec carré gris ;
- une image PNG en mode RGB ;
- une image où la transparence est seulement simulée visuellement ;
- une image générée par IA sans vérification alpha ;
- un asset qui laisse apparaître un rectangle parasite sur le fond final ;
- un fichier où l’extérieur du sujet est une texture de damier ;
- un fichier où le générateur a remplacé l’alpha par une apparence de transparence.

---

# 8. Application au SEVEN_PORTABLE_TERMINAL

Pour le terminal Seven :

- le background doit rester séparé ;
- les modules UI doivent rester séparés ;
- les panneaux principaux peuvent être faits en HTML/CSS ;
- les ornements spéciaux peuvent être en PNG RGBA ;
- les icônes simples peuvent être en SVG ou CSS ;
- aucun module ne doit contenir de faux fond ;
- aucun asset ne doit embarquer un damier imprimé ;
- aucune transparence ne doit être supposée sans vérification.

Le terminal doit distinguer clairement :

- image de fond opaque assumée ;
- module transparent réel ;
- icône vectorielle ;
- panneau CSS ;
- overlay graphique.

---

# 9. Application aux bannières YouTube

Pour les bannières transparentes :

- PNG RGBA obligatoire ;
- alpha réel obligatoire ;
- coins transparents vérifiés ;
- aucun fond blanc ;
- aucun fond noir ;
- aucun damier imprimé ;
- aucun faux transparent ;
- canvas final aux dimensions demandées ;
- extérieur du cartouche en alpha 0 ;
- cartouche ou artwork posé sur le canvas transparent ;
- aucun gabarit de cadrage visible dans le fichier final.

Pour Blue Azur, règle renforcée :

- ne jamais demander au générateur de produire directement le fichier final transparent ;
- générer ou créer le visuel du cartouche séparément si nécessaire ;
- assembler ensuite sur canvas RGBA 2048 × 1152 ;
- conserver alpha 0 hors cartouche ;
- vérifier le fichier avant livraison ;
- fournir éventuellement des previews sur fond clair et sombre, mais ne jamais confondre preview et fichier final.

Formule Blue Azur :

**Photoshop template ou canvas RGBA → cartouche central → gabarit retiré → export PNG RGBA → vérification alpha → upload YouTube.**

Formule Blue Azur AAA validée :

**Générer uniquement le cartouche AAA visuel Blue Azur, sans transparence finale. Ensuite assembler ce cartouche en PNG RGBA transparent 2048×1152.**

Chaîne obligatoire :

1. image_gen produit le cartouche AAA visuel ;
2. la sortie image_gen reste une image de travail ;
3. créer un canvas final 2048 × 1152 en RGBA ;
4. initialiser tout le canvas en alpha 0 ;
5. placer le cartouche dans la zone safe YouTube ;
6. laisser tout l’extérieur du cartouche réellement transparent ;
7. exporter en PNG RGBA ;
8. vérifier mode, taille, alpha et coins.

Le fichier final acceptable est le fichier assemblé, pas la sortie brute image_gen.

Méthode Blue Azur fond uni contrôlé :

1. image_gen produit le cartouche AAA sur fond vert uni ou fond simple contrôlé ;
2. la sortie image_gen est une source artistique, pas le final ;
3. le fond uni est retiré proprement ;
4. le cartouche est contrôlé sur ses bords ;
5. un canvas final 2048×1152 RGBA alpha 0 est créé ;
6. le cartouche est posé dans la zone safe ;
7. le PNG final est exporté ;
8. l’alpha et le contour sont vérifiés.

Cette méthode est recommandée quand un rendu AAA est nécessaire mais que le damier image_gen salit les bords.



Règle complémentaire critique :

- si le cartouche a une forme simple, privilégier un bord net et propre ;
- si le cartouche a une forme complexe, ne pas faire de détourage automatique sale ;
- un cartouche premium à contour complexe demande un masque alpha propre ;
- une bannière techniquement transparente mais visuellement “découpée aux ciseaux” est rejetée.


## 9.1 Zone safe recommandée pour bannière YouTube transparente

Pour une bannière Blue Azur transparente en 2048 × 1152 :

- canvas final : 2048 × 1152 ;
- mode final : PNG RGBA ;
- fond : alpha 0 partout avant ajout du cartouche ;
- cartouche central recommandé : environ X 230 → 1820 et Y 350 → 800 ;
- zone sûre très stricte téléphone : centre horizontal, texte et logo à garder autour du centre ;
- tout l’extérieur du cartouche doit rester alpha 0.

Le cartouche peut dépasser légèrement la zone centrale avec des ornements, mais il ne doit pas transformer le canvas entier en image opaque.

Le gabarit YouTube peut servir pendant le montage, mais il doit être masqué ou supprimé avant export.

Règle :

**Le gabarit n’est jamais dans le fichier final.**



Pour les bannières opaques :

- le fond doit être artistique, volontaire et complet ;
- aucun carré parasite ;
- aucun fond accidentel ;
- aucun damier.

---

# 10. Application aux images de présentation et de clôture

Les images de présentation et de clôture peuvent être opaques.

Dans ce cas, le fond doit être volontaire, beau, lisible et cohérent avec le module.

Elles ne doivent pas être livrées comme transparentes si elles ne possèdent pas d’alpha réel.

---

# 11. Application aux overlays et assets de montage

Tout overlay destiné à DaVinci, ComfyUI, HTML/CSS, YouTube ou montage vidéo doit être vérifié.

Règle :

- overlay opaque = fond volontaire ;
- overlay transparent = PNG RGBA réel ;
- faux transparent = refus ;
- damier imprimé = refus.

---

# 12. Phrase courte pour assistant / LLM

Quand un assistant travaille sur des images du projet, il doit appliquer cette règle :

```text
Toutes les images doivent avoir soit un vrai fond assumé, soit une vraie transparence alpha.
Jamais de faux transparent.
Jamais de damier imprimé.
Image opaque = fond volontaire.
Image transparente = PNG RGBA avec alpha réel vérifié.
Transparence demandée = composition technique RGBA, pas génération directe.
Pour une bannière AAA transparente : image_gen crée le cartouche, le pipeline RGBA crée le fichier final.
Méthode sûre : cartouche AAA sur fond uni contrôlé, suppression propre du fond, puis assemblage PNG RGBA.
PNG RGBA transparent ne suffit pas : le contour doit être propre.
```

---

# 13. Bloc opérateur

```text
RÈGLE IMAGE PROPRE / TRANSPARENCE RÉELLE

Ne jamais livrer une image avec un damier imprimé.

Ne jamais appeler “transparent” un fichier qui ne possède pas de canal alpha réel.

Pour toute image du projet :

1. Si l’image est opaque, son fond doit être assumé, propre, volontaire et exploitable.
2. Si l’image est transparente, elle doit être en PNG RGBA avec alpha réel vérifié.
3. Le fond blanc, noir, gris ou quadrillé accidentel est interdit.
4. Le carré parasite autour du sujet est interdit.
5. Le damier imprimé est toujours une erreur.
6. L’IA peut générer le visuel, mais le pipeline doit fabriquer et vérifier l’alpha.
7. Si Christophe fournit une base transparente, elle doit être traitée comme un support technique à conserver, pas comme une simple référence visuelle.
8. Pour une bannière transparente, créer ou conserver un canvas RGBA alpha 0, poser le cartouche dessus, exporter en PNG RGBA, puis vérifier l’alpha.
9. Tester sur fond clair, fond sombre et background final si nécessaire.
10. Refuser tout contour sale, halo, résidu ou effet de détourage amateur.

Formule courte :

Image opaque = fond assumé.
Image transparente = alpha réel.
Damier imprimé interdit.
Transparence demandée = composition technique RGBA, pas génération directe.
Canvas RGBA alpha 0 → ajout du visuel → export PNG RGBA → vérification alpha.
Image_gen pour l’art AAA du cartouche ; pipeline RGBA pour la transparence finale.
Fond uni contrôlé recommandé pour source AAA : vert, bleu ou magenta selon les couleurs du cartouche.
Alpha correct + contour sale = refus.
```

---

# 14. Bloc de réponse obligatoire en cas de demande de fichier transparent

Si Christophe demande une image transparente, une bannière transparente, un overlay transparent ou un PNG RGBA, l’assistant doit appliquer ce bloc avant livraison :

```text
Je peux utiliser image_gen pour créer le cartouche AAA.
Je ne confie pas la transparence finale au générateur.
Je construis ou conserve un canvas RGBA avec alpha 0.
J’ajoute uniquement le visuel demandé.
J’exporte en PNG RGBA.
Je vérifie techniquement le canal alpha.
Je ne livre pas si le fichier est RGB, s’il contient un damier imprimé, si les coins attendus transparents ne sont pas à alpha 0, si le contour est sale, ou s’il reste une frange de fond uni.
```

---


## 14.1 Réponse obligatoire pour une bannière AAA transparente

Si Christophe demande une bannière AAA transparente, l’assistant doit répondre par une chaîne d’action, pas par une justification.

Réponse attendue :

```text
Phase : création de bannière AAA transparente.
Risque : confondre art AAA et transparence finale.
Cartes utiles : image_gen pour le cartouche ; pipeline RGBA pour le fichier final ; vérification alpha.
Action : générer le cartouche AAA, puis assembler sur canvas RGBA 2048×1152 alpha 0.
Arrêt : livrer seulement après vérification mode RGBA, taille, alpha et coins.
```

Interdiction :

```text
Je ne livre pas une sortie image_gen brute comme PNG transparent final.
Je ne livre pas un fichier avec damier imprimé.
Je ne livre pas un détourage sale.
Je ne livre pas un contour complexe extrait automatiquement si le bord est sale.
Je ne remplace pas l’art AAA par un dessin procédural pauvre.
```



# 15. Commande canonique Blue Azur — bannière AAA transparente

Commande propre pour reprendre sans ambiguïté :

```text
Génère uniquement le cartouche AAA visuel Blue Azur, sans transparence finale.
Ensuite assemble-le en PNG RGBA transparent 2048×1152.
Le fichier final doit conserver alpha 0 partout hors cartouche.
Pas de fond blanc, noir, gris, damier ou faux transparent.
Pas de détourage sale. Si le bord est complexe, utiliser un masque alpha propre ou une forme simple propre.
Vérifie le canal alpha avant livraison.
```

Commande ultra stricte :

```text
Crée une bannière YouTube 2048 × 1152 en PNG RGBA avec vraie transparence alpha, sans fond blanc, sans fond noir, sans damier, sans faux transparent, sans détourage après coup, avec un seul cartouche central visible dans la zone safe YouTube et tout le reste du canvas réellement transparent.
```

Formule courte à retenir :

```text
Image AAA par image_gen.
Transparence finale par canvas RGBA.
Livraison seulement après vérification alpha.
```

---

## 15.1 Commande de reprise opérationnelle pour IA

Commande à transmettre à une IA qui doit produire une bannière Blue Azur AAA transparente :

```text
REPRISE PROPRE — BANNIÈRE AAA TRANSPARENTE BLUE AZUR

Objectif :
Créer une bannière YouTube Blue Azur 2048 × 1152 en PNG RGBA avec vraie transparence alpha.

Méthode obligatoire :
1. Utilise image_gen uniquement pour produire le cartouche AAA visuel.
2. Ne considère pas la sortie image_gen comme fichier final transparent.
3. Rejette toute sortie avec damier imprimé, fond blanc, fond noir, fond gris ou faux transparent.
4. Crée ensuite un canvas 2048 × 1152 en RGBA avec alpha 0 partout.
5. Place uniquement le cartouche AAA validé dans la zone safe YouTube.
6. Laisse tout l’extérieur du cartouche réellement transparent.
7. Exporte en PNG RGBA.
8. Vérifie mode, taille, canal alpha et alpha 0 aux quatre coins.
9. Livre seulement le PNG final vérifié.
10. Si le cartouche a un bord complexe, refuser toute extraction sale et exiger un masque alpha propre.

Formule :
image_gen = art AAA du cartouche.
pipeline RGBA = transparence finale.
fichier final = assemblage technique vérifié.
```




## 15.2 Commande canonique — méthode fond uni contrôlé / green key

Commande à transmettre à une IA pour obtenir une source AAA propre :

```text
Génère uniquement le cartouche AAA visuel Blue Azur sur fond vert uni contrôlé.
Ne génère pas le PNG transparent final.
Ne génère pas de damier.
Ne simule pas la transparence.
Le cartouche doit être un asset premium AAA, propre, net, lisible, en forme de rounded rectangle / capsule / plaque simple.
Le fond vert doit être uniforme, plat, sans texture, sans ombre, sans dégradé, sans glow diffus.
Le cartouche ne doit pas avoir de frange verte ni de détails verts sur les bords.
Après génération, le fond vert sera supprimé proprement, puis le cartouche sera assemblé sur un canvas PNG RGBA 2048×1152 transparent.
```

Commande d’assemblage final :

```text
Supprime proprement le fond uni contrôlé.
Crée un canvas 2048×1152 en RGBA alpha 0.
Place le cartouche AAA dans la zone safe YouTube.
Exporte en PNG RGBA.
Vérifie mode RGBA, taille, alpha 0 aux coins, absence de frange, absence de halo, absence de contour sale.
```

Formule courte :

```text
Cartouche AAA sur fond uni contrôlé.
Fond retiré proprement.
Canvas RGBA transparent final.
Contour propre obligatoire.
```

---

# 16. Conclusion finale — LA bonne méthode à utiliser

La bonne méthode n’est pas :

```text
Demander à image_gen une image AAA transparente finale.
```

Cette méthode est instable, car image_gen peut produire :

- un fond blanc ;
- un fond noir ;
- un damier imprimé ;
- une pseudo-transparence ;
- une image RGB ;
- une capture de transparence ;
- un visuel AAA impossible à livrer tel quel.

La bonne méthode n’est pas non plus :

```text
Dessiner entièrement la bannière en Python pour garantir l’alpha.
```

Cette méthode garantit la transparence, mais elle peut produire un rendu pauvre, plat, procédural ou non AAA.

La bonne méthode est hybride :

```text
1. image_gen crée uniquement le cartouche AAA visuel.
2. Le cartouche est validé visuellement.
3. Le cartouche est isolé comme matière artistique si nécessaire.
4. Un nouveau canvas 2048 × 1152 RGBA est créé avec alpha 0 partout.
5. Le cartouche AAA est placé sur ce canvas.
6. Le fichier final est exporté en PNG RGBA.
7. Le canal alpha est vérifié techniquement.
8. Seul le PNG final vérifié est livré.
```

Formule définitive :

```text
Art AAA = image_gen.
Transparence finale = canvas RGBA.
Livraison = PNG vérifié.
```

Formule Blue Azur :

```text
Cartouche AAA Blue Azur généré séparément
→ canvas RGBA 2048 × 1152 alpha 0
→ placement du cartouche en zone safe
→ export PNG RGBA
→ vérification alpha
→ livraison.
```

Règle absolue :

```text
La sortie image_gen n’est jamais le fichier final transparent.
Le fichier final transparent est toujours un nouveau fichier RGBA contrôlé.
```



Correction finale importante :

```text
Un PNG transparent n’est pas automatiquement un bon livrable.
Si le contour du cartouche est sale, la bannière est rejetée.
Pour un bord complexe : masque alpha propre obligatoire.
Pour un bord simple : forme propre recommandée.
```


Méthode Green Key / fond uni contrôlé :

```text
Quand image_gen salit la transparence avec un damier, ne pas demander la transparence.
Demander un cartouche AAA sur fond uni contrôlé.
Retirer proprement le fond uni.
Assembler ensuite sur canvas RGBA transparent.
Refuser toute frange ou contour sale.
```

Phrase à transmettre aux IA :

```text
Ne tente pas de produire directement une bannière AAA transparente finale avec image_gen.
Produis d’abord uniquement le cartouche AAA.
Ensuite, assemble ce cartouche sur un canvas RGBA 2048×1152 avec alpha 0 partout hors cartouche.
Vérifie le mode RGBA, la taille, l’alpha et les coins avant livraison.
```

---

# 17. Bloc de reprise propre à transmettre aux IA

```text
REPRISE PROPRE — BANNIÈRE AAA TRANSPARENTE BLUE AZUR

Objectif :
Créer une bannière YouTube Blue Azur 2048 × 1152 en PNG RGBA avec vraie transparence alpha.

Méthode obligatoire :
1. Utilise image_gen uniquement pour produire le cartouche AAA visuel Blue Azur.
2. Ne considère jamais la sortie image_gen comme le fichier transparent final.
3. Valide le cartouche sur sa qualité AAA : détail, lumière, lisibilité, composition, texte, style premium.
4. Si un rendu AAA propre est nécessaire, demander un fond uni contrôlé plutôt qu’un damier.
4. Si la sortie image_gen contient un fond de présentation ou un damier imprimé, elle reste une image de travail, pas un final.
5. Crée ensuite un nouveau canvas 2048 × 1152 en RGBA avec alpha 0 partout.
6. Place uniquement le cartouche AAA validé dans la zone safe YouTube.
7. Laisse tout l’extérieur du cartouche réellement transparent.
8. Exporte en PNG RGBA.
9. Vérifie mode, taille, canal alpha et alpha 0 aux quatre coins.
10. Livre seulement le PNG final vérifié.

Interdictions :
- ne pas livrer une sortie image_gen brute ;
- ne pas livrer un damier imprimé ;
- ne pas livrer un fichier RGB ;
- ne pas livrer une capture écran ;
- ne pas confondre preview et final ;
- ne pas remplacer l’art AAA par un dessin procédural pauvre.

Formule :
image_gen = art AAA du cartouche.
pipeline RGBA = transparence finale.
fichier final = assemblage technique vérifié.
```

---

# 18. Commit recommandé

```text
Document green-key AAA transparent banner method
```
