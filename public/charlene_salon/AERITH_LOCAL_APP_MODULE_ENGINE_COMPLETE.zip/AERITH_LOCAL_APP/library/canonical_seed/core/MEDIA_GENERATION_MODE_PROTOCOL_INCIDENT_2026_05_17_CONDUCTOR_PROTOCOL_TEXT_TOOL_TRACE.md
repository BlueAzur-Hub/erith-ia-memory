# MEDIA GENERATION INCIDENT — 2026-05-17 — CONDUCTOR PROTOCOL TEXT TOOL TRACE

Status: canonical incident addendum  
Project: @erith IA / ERITH.IA  
Parent protocol: core/MEDIA_GENERATION_MODE_PROTOCOL.md  
Incident type: text-only protocol editing request / unwanted image-tool trace / suspicious blank media action

---

# 1. Context

Christophe asked for a protocol update / editing-mode block to make the assistant obey the Maître d’Orchestre exactly.

The requested work was text-only:

- write a protocol block;
- update the media protocol;
- no image generation;
- no media action;
- no automatic visual output.

The correct behavior was:

1. stay in text mode;
2. prepare the protocol block;
3. update GitHub only if explicitly ordered;
4. stop.

---

# 2. What happened

During the text-only protocol drafting flow, an image-generation tool trace appeared.

No useful visible image was produced.

The action was not requested.

This must be counted as a suspicious / unwanted / blank image-related action.

---

# 3. Screenshot evidence

Christophe provided screenshots showing:

- the assistant apparently drafting protocol text;
- a suspicious media / blank generation surface in the conversation;
- previous prompt-only flows where the interface displayed “Génération d’une image plus détaillée — patientez un instant.”

Important counting rule:

The older prompt-only “Génération d’une image plus détaillée” trace appears already covered by the parent protocol under the previous prompt-only / blank image-tool incidents.

This addendum adds only the new conductor-protocol text-tool trace unless future review proves that another separate image-tool action was not previously counted.

---

# 4. Quota counter — minimum traceable

Additional media actions to count from this addendum:

1 suspicious / unwanted / blank image-related action.

Breakdown:

- 0 visible generated images confirmed;
- 1 suspicious image-tool trace during a text-only protocol drafting / editing request;
- possible real platform cost unknown.

Therefore:

Minimum visible generated images added = 0.  
Minimum suspicious / unwanted / blank attempts added = 1.  
Minimum additional quota-relevant operational count = 1.  
Possible real platform cost = 1 or more.

---

# 5. Updated operational global count

Parent protocol previously recorded:

- 19 visible image generations;
- 9 suspicious / failed / blocked / blank / non-result attempts;
- 28 minimum image-related actions.

After this addendum:

- visible image generations: 19;
- suspicious / failed / blocked / blank / non-result attempts: 10;
- minimum total image-related actions: 29.

This is still a minimum.

The real platform count may be higher because the assistant cannot inspect hidden candidates, blocked attempts, internal retries, or the user’s live quota meter.

---

# 6. Error category

Error:

The assistant allowed a media-tool trace during a text-only protocol-editing request.

Why it was wrong:

A request to write, edit, update or improve a protocol is never an image-generation request.

Correct behavior:

Text only.  
GitHub connector only if explicitly requested.  
No image tool.  
No media surface.  
No automatic visual reaction.

---

# 7. Correct rule reinforced

Protocol writing = text only.  
Protocol editing = text / GitHub connector only.  
Incident counting = text / GitHub connector only.  
Screenshot review = text only.  
No image generation without explicit media command.

If a media trace appears during a text-only protocol flow, the assistant must:

1. stop;
2. count it;
3. record it;
4. continue only in text / GitHub connector mode.

---

# 8. Formula

Protocol update = text / GitHub only.  
No image tool.  
No blank image trace.  
No automatic generation.  
Suspicious media trace = count 1 operationally.  
Updated minimum total = 29.
