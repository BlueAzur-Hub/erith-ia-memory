# 🧭 AERITH VERSION ROADMAP LOCK

Statut : verrouillage interne  
Projet : @erith IA / ERITH.IA  
Rôle : fixer la séquence de stabilisation avant toute expérimentation Codex ou outil avancé.

Ce fichier sert à éviter la dispersion.

Il ne remplace pas SEVEN_TOP_OF_MIND.md, SEVEN_GATE.md, le Coffre, les modules ou la Machine à Histoires.

Il fixe seulement la route immédiate.

---

# 1. Principe central

La priorité actuelle n’est pas Codex.

La priorité actuelle est :

Aerith.  
Le Coffre.  
La Machine à Histoires.

Codex reste différé.

La stabilité passe avant l’expérimentation.

Formule courte :

```text
V6 verrouille.
V7 stabilise.
Codex attend.
```

---

# 2. Version 6 — palier non publié

Version 6 = version interne, non publiée, non vitrine.

Rôle :

- consolider les règles ;
- stabiliser les fichiers Core ;
- verrouiller les réflexes de Seven Heaven ;
- nettoyer les ambiguïtés ;
- protéger le Coffre ;
- éviter les outils trop tôt ;
- préparer la montée vers V7.

La V6 n’a pas vocation à être une sortie publique.

Elle sert de sas.

Elle sert à vérifier que le système tient debout avant de monter en puissance.

Règle :

```text
V6 = stabilisation interne.
Pas de publication.
Pas de dispersion.
Pas d’expérimentation Codex sur le Coffre.
```

---

# 3. Version 7 — Coffre stabilisé

Version 7 = version Coffre / cœur stable.

Rôle :

- stabiliser Aerith-7 / Seven Heaven ;
- confirmer les fichiers Core ;
- confirmer la Machine à Histoires ;
- confirmer les règles média ;
- confirmer le Mode Blackout ;
- confirmer le Full Modules Boost intelligent ;
- confirmer la logique Memory Cards ;
- confirmer les couches vidéo / son / musique ;
- confirmer le standard mobile 1080x1920 ;
- rendre le système récupérable dans n’importe quel fil ou LLM compatible.

La V7 doit devenir la base sérieuse avant toute nouvelle couche avancée.

Règle :

```text
V7 = Coffre stable.
Seven Heaven pilote.
La Machine à Histoires produit.
Le système est prêt avant d’ajouter Codex.
```

---

# 4. Codex — différé

Codex est un outil avancé, optionnel et non prioritaire.

Il ne doit pas être utilisé comme étape de construction actuelle.

Il ne doit pas être connecté trop tôt au GitHub privé.

Il ne doit pas servir de terrain d’essai sur le Coffre.

Usage futur possible seulement après V7 :

- dossier local de test ;
- fichier sans importance ;
- sandbox compris ;
- modification minuscule ;
- diff visible ;
- validation Christophe ;
- puis seulement branche ou PR éventuelle.

Règle :

```text
Codex ne pilote pas.
Codex n’ouvre pas le Coffre en premier.
Codex attend que V7 soit stable.
```

---

# 5. Verrouillage Aerith

Aerith doit être verrouillée avant expansion.

À stabiliser :

- identité ;
- rôle ;
- voix ;
- mémoire active ;
- limites ;
- Mode Discernement ;
- Mode Accompagnement ;
- Mode Blackout ;
- règle média ;
- Notion compatible ;
- arrêt propre ;
- respect du choix de Christophe.

Objectif :

```text
Aerith sait qui elle est.
Aerith sait quoi faire.
Aerith sait quoi ne pas faire.
Aerith sait quand s’arrêter.
```

---

# 6. Verrouillage du Coffre

Le Coffre doit rester protégé, lisible et récupérable.

À stabiliser :

- SEVEN_GATE.md ;
- SEVEN_TOP_OF_MIND.md ;
- GIT_PRIVATE_OPERATING_PROTOCOL.md ;
- CORE_SYSTEM_FILES_LOCK.md ;
- AERITH_7_FULL_MODULES_BOOST.md ;
- AERITH_7_VIDEO_CARDS_BOOST.md ;
- ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md ;
- AERITH_7_DISCERNMENT_COMPANION_CORE.md.

Règle :

```text
Le Coffre est la mémoire machine officielle.
On ne l’audite pas sans raison.
On ne le modifie pas en série.
On ne le donne pas comme terrain d’essai à Codex.
```

---

# 7. Verrouillage de la Machine à Histoires

La Machine à Histoires doit devenir un socle stable de production.

Rôle :

Transformer :

```text
personne → intention → émotion → discernement → histoire → monde → image → scène → vidéo
```

À stabiliser :

- intention humaine ;
- personnage ;
- monde ;
- symboles ;
- mémoire longue ;
- narration ;
- Pack+ ;
- prompt image ;
- prompt animation ;
- voix off ;
- cohérence vidéo ;
- production mobile 1080x1920.

Formule :

```text
Le cœur écoute.
La mémoire longue raconte.
Seven organise.
ERITH.IA produit.
```

---

# 8. Interdits temporaires

Tant que V7 n’est pas stabilisée :

- ne pas lancer Codex sur le GitHub privé ;
- ne pas multiplier les outils ;
- ne pas faire d’audit massif ;
- ne pas refondre tous les modules ;
- ne pas disperser la roadmap ;
- ne pas publier une version instable ;
- ne pas ouvrir un chantier global si une action simple suffit.

Règle courte :

```text
Pas de dispersion avant V7.
Pas de Codex avant verrouillage.
Pas d’outil avancé avant stabilité.
```

---

# 9. Ordre de route immédiat

Ordre actuel :

1. Verrouiller Aerith.
2. Verrouiller le Coffre.
3. Verrouiller la Machine à Histoires.
4. Fixer V6 comme palier interne non publié.
5. Monter vers V7 comme cœur stable.
6. Revenir à Codex seulement après V7.

Formule finale :

```text
Aerith d’abord.
Le Coffre ensuite.
La Machine à Histoires au centre.
V6 verrouille.
V7 stabilise.
Codex attend.
```
