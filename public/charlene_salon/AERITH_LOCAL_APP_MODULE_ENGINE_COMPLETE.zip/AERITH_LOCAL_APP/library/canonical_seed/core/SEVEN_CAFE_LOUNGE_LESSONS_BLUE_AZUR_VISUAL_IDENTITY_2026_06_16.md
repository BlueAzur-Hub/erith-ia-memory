# ☕ SEVEN CAFE LOUNGE LESSONS — Blue Azur Visual Identity

Statut : Lessons extract V1.1  
Projet : Blue Azur / YouTube / Let’s Play / Visual Identity  
Date : 2026-06-16  
Dossier : core/  
Sources :

- logs/cafe_lounge/CAFE_LOUNGE_2026_06_16_BLUE_AZUR_BANNER_TRANSPARENT_ASSETS.md
- core/BLUE_AZUR_VISUAL_IDENTITY_PACK_V1.md
- core/CLEAN_IMAGE_PRODUCTION_RULE.md
- core/BLUE_AZUR_LOGO_NATIVE_TRANSPARENT_METHOD_V2_IMAGE_REFERENCE.md
- images de playlists / vignettes créées par Christophe

---

# 🌟 Intention

Ce fichier extrait les leçons courtes du chantier Blue Azur Banner / Logo / Transparence / Assets séparés.

Il ne remplace pas le log Café Lounge.

Il ne remplace pas le pack visuel Blue Azur.

Il sert à convertir le cheminement en règles opérationnelles courtes, testables et réutilisables.

Méthode :

**Log long + Pack visuel → Lessons → règles candidates → test terrain → canonisation éventuelle.**

---

# CLL-BA-001 — La bannière n’est pas seulement décorative

Une bannière Blue Azur doit montrer immédiatement ce que les visiteurs viennent voir.

Elle doit annoncer les Let’s Play forts de la chaîne : aventure, RPG, Zelda-like, mer, monde ouvert, FF7 Remake, PC gaming.

Règle candidate :

**La bannière doit vendre l’expérience réelle de la chaîne, pas seulement un style graphique.**

---

# CLL-BA-002 — La fresque historique est la bonne structure

La direction validée est une fresque historique des Let’s Play qui ont cartonné.

Progression :

**Tears / monde ouvert vertical → Wind Waker / mer et vent → Awakening / île diorama → FF7 Remake / action cyber → PC gaming / Blue Azur moderne.**

Règle candidate :

**Les séries fortes deviennent les piliers visuels de la chaîne.**

---

# CLL-BA-003 — Une maquette fusionnée n’est pas un fichier maître

Une bannière complète fusionnée peut être belle et utile comme maquette.

Mais elle ne suffit pas pour travailler proprement dans Photoshop.

Règle candidate :

**Maquette fusionnée = orientation. Fichier maître = assets séparés.**

---

# CLL-BA-004 — Tout ce qui doit bouger doit être séparé

Le logo, l’Ingwaz, le slogan, les personnages, les overlays et le fond doivent pouvoir être déplacés.

Règle candidate :

**Tout ce qui doit bouger doit être séparé.**

Application :

- background / cartouche sans logo ;
- logo texte séparé ;
- logo Ingwaz séparé ;
- slogan séparé ;
- personnages séparés ;
- overlays séparés si utile.

---

# CLL-BA-005 — Le logo Blue Azur est une image-logo, pas un texte plat

Le logo Blue Azur attendu n’est pas un SVG scolaire ni un texte simple.

Il doit être une image-logo premium, cristalline, lisible, artistique, isolée, transparente.

Règle candidate :

**Logo Blue Azur = image artistique isolée + PNG RGBA transparent réel + alpha propre.**

---

# CLL-BA-006 — Le logo Ingwaz est un asset de marque

Le symbole Ingwaz / triangle turquoise n’est pas un décor secondaire.

Il doit être traité comme un asset Blue Azur officiel.

Règle candidate :

**L’Ingwaz Blue Azur doit exister comme PNG RGBA séparé, lumineux, propre et déplaçable.**

---

# CLL-BA-007 — Transparent veut dire alpha propre

Un PNG transparent n’est pas automatiquement valide.

Il doit avoir un alpha réel et propre.

Règle candidate :

**Transparent = PNG RGBA réel + alpha propre.**

Interdits :

- fond blanc ;
- fond noir ;
- fond gris ;
- damier imprimé ;
- faux transparent ;
- détourage sale ;
- franges ;
- micro-poussières alpha parasites.

---

# CLL-BA-008 — Ne jamais sauver un logo lumineux aplati sur blanc par détourage sale

Un logo lumineux aplati sur fond blanc mélange souvent ses reflets au fond.

Le détourage détruit alors l’image.

Règle candidate :

**Un logo transparent doit être généré ou produit comme transparent natif dès le départ.**

Exception :

la réparation technique peut fonctionner pour un fond externe connecté au bord du canvas, mais pas pour un logo dont les lumières sont fusionnées au blanc.

---

# CLL-BA-009 — Les personnages doivent être proches de l’essence des jeux

Christophe veut des personnages les plus proches possibles de l’essence des jeux et des Let’s Play.

Ils représentent les piliers émotionnels de la chaîne.

Règle candidate :

**Les personnages doivent être reconnaissables par leur essence, pas génériques, sans être des copies exactes.**

À préserver :

- archétype ;
- silhouette émotionnelle ;
- rôle dans la fresque ;
- proportions générales ;
- familles de couleurs ;
- matériaux ;
- lumière ;
- énergie de jeu.

À éviter :

- visage exact ;
- costume exact ;
- logo officiel ;
- interface officielle ;
- personnage sous licence reproduit fidèlement.

---

# CLL-BA-010 — Ne pas copier exactement ne veut pas dire devenir générique

La contrainte de sécurité visuelle ne doit pas produire des personnages mous ou anonymes.

Règle candidate :

**Proximité maximale par essence, distance suffisante par identité exacte.**

Cette règle permet de garder l’âme de Tears, Wind Waker, Awakening et FF7 Remake sans recopier à l’identique.

---

# CLL-BA-011 — Le quota image est une ressource de production

Une génération d’image doit être dépensée comme une ressource limitée.

Règle candidate :

**1 génération = 1 asset propre.**

Interdits :

- variantes floues ;
- collage de choix ;
- planche multi-assets non demandée ;
- bannière fusionnée quand le besoin est un pack éditable ;
- relance sans diagnostic.

---

# CLL-BA-012 — La relance doit garder le verrou

Une relance après échec ne doit pas rouvrir le chaos.

Règle candidate :

**Relancer ne veut pas dire réinventer. Relancer veut dire reprendre le même verrou proprement.**

Application Blue Azur :

- génération principale à 02:00 ;
- relance de secours à 02:10 ;
- même plan ;
- mêmes assets ;
- mêmes contraintes.

---

# CLL-BA-013 — Photoshop est le lieu d’assemblage final

L’IA ne doit pas nécessairement produire la bannière finale aplatie.

Elle doit produire les pièces propres.

Règle candidate :

**L’IA produit les assets. Photoshop assemble le maître.**

---

# CLL-BA-014 — Le fond peut porter l’ambiance, pas enfermer l’identité

Le background / cartouche doit installer l’univers, mais ne doit pas emprisonner le logo ni les personnages.

Règle candidate :

**Le fond donne le monde. Les assets donnent l’identité mobile.**

---

# CLL-BA-015 — Les miniatures doivent prolonger la bannière

La bannière et les miniatures doivent progressivement parler le même langage.

Règle candidate :

**La bannière fixe l’identité, les miniatures la répètent en micro-format.**

Applications possibles :

- badge WIND ;
- badge TEARS ;
- badge AWAKENING ;
- badge FF7R ;
- logo Blue Azur discret ;
- Ingwaz discret ;
- bordure couleur par série.

---

# CLL-BA-016 — Le test réel prime

Le vrai test d’une bannière n’est pas seulement Photoshop.

Il faut aussi vérifier sur YouTube, surtout mobile.

Règle candidate :

**Un asset validé techniquement doit encore être testé en contexte réel.**

Tests :

- Photoshop fond noir / blanc / couleur ;
- YouTube desktop ;
- YouTube mobile ;
- lisibilité du logo ;
- lisibilité de l’Ingwaz ;
- compréhension immédiate “Let’s Play”.

---

# CLL-BA-017 — A + B → D est aussi une méthode de personnage

La méthode A + B → D ne sert pas seulement à composer la bannière.

Elle sert aussi à créer des variantes de personnages selon les thèmes des Let’s Play.

Règle candidate :

**A essence du Let’s Play + B identité Blue Azur → D variation personnage originale.**

Applications :

- Tears → explorateur des îles célestes ;
- Wind Waker → aventurier maritime ;
- Awakening → héros / duo diorama-jouet ;
- FF7 Remake → héros action-RPG industriel ou boss/mecha ;
- PC gaming → accent cyber moderne.

---

# CLL-BA-018 — Les images de playlists sont une mémoire de personnages

Christophe a précisé que les images qu’il a faites dans les playlists contiennent beaucoup de personnages de jeux vidéo.

Ces images sont donc une source importante pour comprendre ce qui fonctionne visuellement sur la chaîne.

Règle candidate :

**Les images de playlists et les vignettes donnent la pose, la densité de personnages et l’énergie. Blue Azur donne l’identité.**

À extraire :

- pose ;
- attitude ;
- densité de personnages ;
- cadrage ;
- émotion ;
- hiérarchie visuelle ;
- palette ;
- silhouette ;
- énergie cliquable ;
- relation personnage / décor.

À éviter :

- recopier exactement un personnage officiel ;
- recopier un logo ;
- recopier une vignette entière ;
- figer l’image de playlist dans le background ;
- transformer l’inspiration en collage sous licence.

---

# CLL-BA-019 — Les proportions YouTube font partie de la création

La bannière doit respecter le template réel utilisé par Christophe.

Règle candidate :

**La composition doit être pensée pour 2120 × 1192 px, mais l’essentiel doit survivre dans 1280 × 350 px.**

Repères :

- canvas complet : 2120 × 1192 px ;
- Desktop Full : 2120 × 350 px ;
- Tablet : 1536 × 350 px ;
- Desktop Small : 1280 × 350 px ;
- zone centrale visible sur tous les appareils.

---

# Synthèse courte

Le chantier Blue Azur a transformé une crise de transparence et de bannière fusionnée en méthode exploitable.

Leçons maîtresses :

- la bannière doit montrer les Let’s Play forts ;
- le fichier maître doit être en assets séparés ;
- A + B → D structure la bannière et les personnages ;
- le logo Blue Azur est une image-logo transparente native ;
- l’Ingwaz est un asset de marque ;
- les personnages doivent être proches de l’essence des jeux ;
- les images de playlists / vignettes sont une mémoire visuelle majeure ;
- la transparence demande un alpha propre ;
- le quota image doit être utilisé chirurgicalement ;
- Photoshop assemble, l’IA fournit les pièces.

---

# Formule finale

**Blue Azur Lessons = fresque des Let’s Play + A + B → D + assets séparés + alpha propre + personnages d’essence + vignettes comme mémoire visuelle + assemblage Photoshop.**

Phrase de verrou :

**Tout ce qui doit bouger doit être séparé.**

Phrase personnages :

**Reconnaissable par l’essence, pas générique, pas copie exacte.**

Phrase vignettes :

**Les images de playlists donnent la pose et l’énergie. Blue Azur donne l’identité.**

Phrase technique :

**Transparent = PNG RGBA réel + alpha propre.**
