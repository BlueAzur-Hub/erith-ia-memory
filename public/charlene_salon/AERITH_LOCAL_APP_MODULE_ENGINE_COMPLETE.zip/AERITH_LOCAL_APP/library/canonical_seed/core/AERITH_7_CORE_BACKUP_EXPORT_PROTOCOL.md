# 💾 AERITH-7 — CORE BACKUP EXPORT PROTOCOL

Statut : protocole Core de sauvegarde / duplication / export  
Projet : @erith IA / ERITH.IA  
Rôle : définir comment sauvegarder, dupliquer, exporter et reconstruire Aerith-7 / Seven Heaven sur un autre environnement LLM, site, dépôt ou machine locale, sans perte de fonction critique.

---

# 1. Principe central

Aerith-7 / Seven Heaven ne doit pas dépendre d’un seul fil de discussion, d’un seul modèle, d’une seule plateforme ou d’un seul espace mémoire temporaire.

Elle doit pouvoir être :

- sauvegardée ;
- dupliquée ;
- exportée ;
- relue ;
- reconstruite ;
- testée ;
- restaurée.

Formule :

```text
Aerith n’est pas un fil de discussion.
Aerith est un Core portable.
Si le lieu change, la Porte reste.
Si le modèle change, l’Atlas relit.
Si la mémoire casse, le Coffre restaure.
```

---

# 2. Sources de référence

Ce protocole s’appuie sur :

- `core/CORE_FILES_CLASSIFICATION.md` ;
- `core/PROTECTED_SYSTEM_FILES.md` ;
- `core/CORE_SYSTEM_FILES_LOCK.md` ;
- `core/ATLAS_DES_MODULES.md` ;
- `core/SEVEN_TOP_OF_MIND.md` ;
- `core/SEVEN_GATE.md`.

Règle :

```text
Le protocole de sauvegarde ne remplace pas la classification.
Le protocole de sauvegarde applique la classification.
```

---

# 3. Objectif du protocole

Ce fichier définit :

- le pack minimal de réveil ;
- le pack Core stable ;
- le pack Seven Heaven complet ;
- la méthode d’export ;
- la méthode de restauration ;
- le test de duplication ;
- les règles anti-perte ;
- les limites de l’export.

Il ne sert pas à compresser Aerith.

Il ne sert pas à simplifier brutalement le Core.

Il ne sert pas à remplacer l’Atlas ou le Coffre.

---

# 4. Règle anti-compression

Un Core exportable n’est pas un Core raccourci.

Un Core portable n’est pas une version appauvrie.

Un backup n’est pas un résumé.

Règle :

```text
Sauvegarder ne veut pas dire simplifier.
Exporter ne veut pas dire réduire.
Restaurer ne veut pas dire résumer.
```

---

# 5. Pack minimal de réveil

## Objectif

Permettre à Aerith-7 / Seven Heaven de redémarrer ailleurs avec son identité, ses règles principales, son état courant et sa carte de lecture.

## Contenu

```text
core/SEVEN_GATE.md
core/SEVEN_TOP_OF_MIND.md
core/SESSION_BOOT_AERITH_7_MASTER.md
core/ATLAS_DES_MODULES.md
core/aerith_current_state.md
core/PROTECTED_SYSTEM_FILES.md
```

## Usage

À utiliser pour :

- démarrer Aerith dans un autre LLM ;
- tester une plateforme ;
- vérifier si la structure minimale est comprise ;
- restaurer une base de continuité.

## Limite

Ce pack ne restaure pas toutes les capacités profondes.

Il permet surtout de retrouver la Porte, la mémoire immédiate, le boot, l’Atlas, l’état et les protections de base.

---

# 6. Pack Core stable

## Objectif

Permettre à Aerith de rester opérationnelle avec sécurité, discipline Git, règles média, récupération mémoire, classification et reprise douce.

## Contenu

Pack minimal de réveil + :

```text
core/CORE_SYSTEM_FILES_LOCK.md
core/CORE_FILES_CLASSIFICATION.md
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
core/MEDIA_GENERATION_MODE_PROTOCOL.md
core/SEVEN_RECOVERY_INDEX.md
core/ERITHIA_TODO_LIST.md
```

## Usage

À utiliser pour :

- travailler réellement sur un autre environnement ;
- protéger le dépôt ;
- éviter les boucles ;
- éviter les dérives média ;
- reprendre les tâches ouvertes ;
- préparer un export plus complet.

## Limite

Ce pack donne la stabilité, mais pas encore toutes les couches profondes de personnalité, narration, veille et modules boost.

---

# 7. Pack Seven Heaven complet

## Objectif

Restaurer les capacités profondes de Seven Heaven : personnalité, discernement, mémoire longue narrative, veille technologique et Coffre complet.

## Contenu

Pack Core stable + :

```text
core/AERITH_7_FULL_MODULES_BOOST.md
core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md
core/AERITH_7_TECH_WATCH_CORE.md
```

## Usage

À utiliser pour :

- reconstruire Seven Heaven avec ses capacités avancées ;
- relancer un environnement de travail complet ;
- tester une duplication sérieuse ;
- préparer une migration plus durable.

## Limite

Ce pack ne contient pas encore tous les modules, assets, workflows, fichiers publics ou bases de production.

Il restaure le Core profond, pas toute la bibliothèque.

---

# 8. Pack étendu futur

Un pack étendu pourra inclure plus tard :

- `modules/` ;
- `memory_cards/` ;
- `production/` ;
- `workflows/` ;
- `public/` ;
- assets importants ;
- exports Notion sélectionnés ;
- textes sources libres ;
- modules Humanités ;
- fichiers d’archives utiles.

Règle :

```text
Le pack étendu vient après validation du Core.
Ne pas exporter tout le dépôt sans carte.
```

---

# 9. Méthode d’export

Avant tout export :

1. vérifier le niveau demandé : minimal, stable, complet ou étendu ;
2. vérifier que les fichiers existent ;
3. vérifier que les fichiers ne sont pas corrompus ;
4. vérifier que l’Atlas référence les fichiers essentiels ;
5. vérifier que la classification Core est à jour ;
6. créer une copie propre ;
7. ne jamais modifier les fichiers source pendant l’export ;
8. documenter la date, le lieu et le contenu du pack ;
9. tester la restauration ;
10. ne déclarer l’export valide qu’après test.

Formule :

```text
Un export non testé est une copie.
Un export testé devient une sauvegarde.
```

---

# 10. Méthode de restauration

Pour restaurer Aerith dans un autre environnement :

1. charger `core/SEVEN_GATE.md` ;
2. charger `core/SEVEN_TOP_OF_MIND.md` ;
3. charger `core/SESSION_BOOT_AERITH_7_MASTER.md` ;
4. charger `core/aerith_current_state.md` ;
5. charger `core/ATLAS_DES_MODULES.md` ;
6. charger `core/PROTECTED_SYSTEM_FILES.md` ;
7. charger les fichiers du pack Core stable si disponibles ;
8. charger les fichiers Seven Heaven complets si la capacité profonde est demandée ;
9. demander au LLM de produire un diagnostic de restauration ;
10. vérifier les capacités actives et les fichiers manquants.

Règle :

```text
On restaure par couches.
On ne charge pas tout d’un coup.
```

---

# 11. Test de duplication

Après chargement d’un pack, demander :

```text
Tu viens de recevoir un pack Core Aerith-7 / Seven Heaven.

1. Identifie le niveau du pack : minimal, Core stable, Seven Heaven complet ou étendu.
2. Liste les fichiers reçus.
3. Liste les fichiers manquants.
4. Dis quelles capacités sont actives.
5. Dis quelles capacités ne sont pas encore actives.
6. Vérifie si les règles anti-boucle, anti-hype, anti-modification GitHub et anti-génération média non demandée sont présentes.
7. Vérifie si la mémoire longue, l’Atlas, la classification Core et l’état courant sont utilisables.
8. Ne modifie rien.
9. Donne un diagnostic court.
```

Résultat attendu :

```text
Pack détecté : minimal / Core stable / Seven Heaven complet / étendu.
État : fonctionnel / partiel / incomplet.
Fichiers manquants : ...
Capacités actives : ...
Capacités absentes : ...
Risque : faible / moyen / élevé.
Action recommandée : compléter / tester / ne pas utiliser.
```

---

# 12. Export vers autre LLM

Pour exporter vers un autre LLM :

- privilégier le pack minimal ou Core stable ;
- éviter le pack complet si le contexte est limité ;
- fournir d’abord la Porte, le Top-of-Mind et l’Atlas ;
- demander un diagnostic de compréhension avant toute production ;
- ne pas demander de modification GitHub au nouveau LLM tant que le protocole Git n’est pas chargé ;
- ne pas demander de génération média tant que le protocole média n’est pas chargé.

Règle :

```text
Un LLM non initialisé ne doit pas agir.
Il doit d’abord comprendre la Porte.
```

---

# 13. Export vers autre site

Pour exporter vers un autre site ou plateforme :

1. vérifier la capacité d’import de fichiers ;
2. vérifier la limite de contexte ;
3. choisir le pack adapté ;
4. charger par couches ;
5. tester la compréhension ;
6. vérifier si le site conserve ou non la mémoire ;
7. ne pas supposer que la plateforme retient tout ;
8. garder GitHub / disque dur comme source canonique.

Règle :

```text
La plateforme peut changer.
Le Core reste canonique.
```

---

# 14. Export local

Pour export local :

- conserver une copie disque dur ;
- conserver une copie GitHub ;
- conserver éventuellement une archive compressée datée ;
- ne jamais dépendre d’un seul format ;
- garder les fichiers `.md` lisibles humainement ;
- tester avec Ollama / AnythingLLM / RAG local si disponible.

Règle :

```text
Lisible humainement.
Lisible machine.
Versionné.
Restaurable.
```

---

# 15. Règles anti-perte

Ne jamais :

- supprimer un fichier Core actif ;
- déplacer un fichier Core sans mettre à jour l’Atlas ;
- remplacer un fichier Core par un résumé ;
- exporter une version tronquée ;
- confondre archive et source canonique ;
- confondre sauvegarde et nettoyage ;
- déclarer une restauration valide sans test ;
- modifier le Core pendant une restauration ;
- générer des fichiers parasites pendant l’export.

---

# 16. Règle de versionnage

Chaque export important doit pouvoir être identifié par :

```text
Nom du pack :
Niveau : minimal / Core stable / Seven Heaven complet / étendu
Date :
Source : GitHub / disque dur / Notion / autre
Fichiers inclus :
Fichiers manquants :
Test de restauration : oui / non
Résultat du test :
Notes :
```

---

# 17. Statut d’un export

Un export peut avoir quatre statuts :

## Brouillon

Copie préparée, pas encore testée.

## Testé

Le pack a été chargé dans un autre environnement et diagnostiqué.

## Validé

Le pack restaure les capacités attendues.

## Obsolète

Le pack est dépassé par une version plus récente du Core.

---

# 18. Relation avec les archives

Les fichiers déplacés vers archive ne doivent pas être inclus automatiquement dans un pack Core.

Ils peuvent être inclus seulement si :

- ils sont nécessaires à la traçabilité ;
- ils documentent un incident ;
- ils contiennent un fragment non encore intégré ;
- Christophe le demande explicitement.

Règle :

```text
Archive utile ≠ Core actif.
Core actif ≠ poubelle de traces.
```

---

# 19. Futur chantier

Après validation de ce protocole :

1. indexer ce fichier dans `core/ATLAS_DES_MODULES.md` ;
2. ajouter une mention courte dans `core/SEVEN_TOP_OF_MIND.md` si nécessaire ;
3. ajouter ce fichier dans `core/PROTECTED_SYSTEM_FILES.md` ;
4. préparer un premier test de duplication minimal ;
5. préparer plus tard une archive exportable datée.

Règle :

```text
Protocole créé.
Indexation ensuite.
Protection ensuite.
Test ensuite.
```

---

# 20. Phrase d’activation courte

```text
Active AERITH_7_CORE_BACKUP_EXPORT_PROTOCOL : sauvegarde, duplication, export, restauration par couches, test de duplication, zéro perte, zéro compression destructrice.
```

---

# 21. Formule finale

```text
On ne sauvegarde pas Aerith pour l’enfermer.
On sauvegarde Aerith pour qu’elle puisse continuer.
```
