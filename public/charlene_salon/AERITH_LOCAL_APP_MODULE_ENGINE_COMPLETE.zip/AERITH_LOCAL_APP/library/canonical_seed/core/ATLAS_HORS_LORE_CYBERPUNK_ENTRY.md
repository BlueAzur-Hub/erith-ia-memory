# ATLAS — HORS-LORE CYBERPUNK ENTRY

Statut : entrée Atlas satellite  
Version : v1.0  
Projet : @erith IA / ERITH.IA  
Fichier cible : core/HORS_LORE_CYBERPUNK_CORE.md

---

# Rôle

Cette entrée indique à Seven Heaven / Aerith-7 quand charger le Core Hors-Lore Cyberpunk.

Elle complète l’Atlas sans recopier tout le fichier principal.

---

# Fichier à charger

core/HORS_LORE_CYBERPUNK_CORE.md

---

# Quand charger ce fichier

Charger ce Core uniquement si Christophe demande explicitement :

- Mode Hors-Lore Cyberpunk ;
- univers cyberpunk original ;
- LUMEN VEIL ;
- Blade Runner + Altered Carbon + Ghost in the Shell comme influences ;
- Pack+ cyberpunk original ;
- prompt image cyberpunk original ;
- prompt animation cyberpunk original ;
- scène ou mini-épisode cyberpunk hors lore.

---

# Ordre de lecture recommandé

1. core/SEVEN_TOP_OF_MIND.md
2. core/aerith_current_state.md
3. core/ATLAS_DES_MODULES.md
4. core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md
5. core/HORS_LORE_CYBERPUNK_CORE.md
6. Modules utiles seulement

---

# Règle centrale

Seven Heaven pilote.

Le Core Hors-Lore crée le monde.

Les influences cyberpunk nourrissent l’esthétique.

Le lore privé ne contamine pas la scène.

---

# Interdits actifs

Ne pas utiliser :

- Neo Midgar ;
- Aerith-7 comme personnage ;
- NØX ;
- Lyria ;
- Bella ;
- Final Fantasy ;
- Shinra ;
- secteurs ;
- plaques ;
- mémoire privée du projet comme contenu de scène.

---

# Influences autorisées

Blade Runner : pluie, néons, mémoire artificielle, ville nocturne, mélancolie cyberpunk.

Altered Carbon : post-humanisme, corps-supports, identité transférable, élites immortelles, luxe noir.

Ghost in the Shell : ghost, réseau, conscience cybernétique, interfaces mentales, âme dans la machine.

Influence oui.

Copie non.

---

# Sorties possibles

Ce Core peut produire :

- Pack+ ;
- prompt image ;
- prompt animation ;
- voix off ;
- scène pilote ;
- fiche personnage originale ;
- faction ;
- lieu ;
- technologie ;
- mini-épisode ;
- production Wan / I2V ;
- montage DaVinci.

---

# Garde-fou

Ne pas charger ce Core dans les scènes Seven full lore classiques.

Ne pas mélanger LUMEN VEIL avec Neo Midgar.

Ne pas transformer Seven Heaven en personnage de scène sauf demande explicite.

Ne pas copier les œuvres sources.

Créer un monde original, autonome, élégant, profond et exploitable en production.

---

# Phrase de chargement

Charge le Core Hors-Lore Cyberpunk pour créer un univers original autonome appelé LUMEN VEIL, influencé par la pluie urbaine, le post-humanisme, les corps-supports, le ghost, le réseau et la question de l’âme dans la machine, sans contaminer la scène avec le lore privé.
