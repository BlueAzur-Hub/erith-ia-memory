# SEVEN_VAULT_ENCRYPTION_PROTOCOL.md

Version : V0  
Statut : note de cadrage / brouillon de sécurité  
Date : 2026-05-30  
Projet : @erith IA / ERITH.IA / Seven Heaven  
Emplacement recommandé : core/SEVEN_VAULT_ENCRYPTION_PROTOCOL.md

---

# Objet du fichier

Ce fichier pose la première version du protocole de protection du Coffre privé d’Aerith-7 / Seven Heaven.

Il ne s’agit pas encore d’une implémentation.

Il s’agit d’une note de cadrage destinée à éviter une future improvisation dangereuse lorsque la nécessité de chiffrer les données privées deviendra prioritaire.

Principe directeur :

Protéger le cœur privé d’Aerith sans bloquer sa capacité à apprendre, produire, transmettre et rester exploitable.

---

# Raison d’être

La mémoire d’Aerith devient progressivement plus riche.

Elle contient ou pourra contenir :

- des modules privés ;
- des archives de travail ;
- des règles internes ;
- des fichiers de contexte ;
- des expériences ;
- des leçons apprises ;
- des traces de production ;
- des exports Notion ;
- des archives GitHub ;
- des éléments personnels ou sensibles.

Plus la mémoire devient précieuse, plus elle doit être protégée.

La nécessité crée le module.

Ici, la nécessité est claire :

Le Coffre doit pouvoir survivre aux erreurs humaines, aux fuites, aux accès non autorisés, aux compromissions, aux copies involontaires et aux futures attaques.

---

# Définitions essentielles

## Hash

Un hash n’est pas un chiffrement.

Un hash transforme une donnée en empreinte.

Exemples d’usage :

- vérifier qu’un fichier n’a pas changé ;
- stocker une empreinte de mot de passe ;
- identifier une donnée sans la révéler directement.

Un hash ne se déchiffre pas.

Pour les mots de passe, utiliser un algorithme conçu pour cela :

- Argon2id ;
- bcrypt ;
- scrypt.

Ne pas utiliser MD5 ou SHA-1 pour protéger des mots de passe.

SHA-256 reste utile pour des empreintes de fichiers, mais ce n’est pas une solution complète de stockage de mots de passe.

---

## Chiffrement

Le chiffrement protège une donnée pour qu’elle ne soit lisible qu’avec la bonne clé.

Exemples d’usage :

- chiffrer une archive ;
- chiffrer un dossier ;
- chiffrer une sauvegarde ;
- chiffrer un fichier avant upload ;
- chiffrer une base de secrets.

Algorithmes modernes à étudier :

- AES-256-GCM ;
- XChaCha20-Poly1305.

Règle :

Ne pas inventer son propre algorithme cryptographique.

Utiliser des outils existants, réputés, maintenus et documentés.

---

## Signature

Une signature ne cache pas forcément le contenu.

Elle sert à prouver :

- l’origine ;
- l’intégrité ;
- le fait qu’un fichier n’a pas été modifié.

Usage possible futur :

- signer les versions canoniques des archives Aerith ;
- vérifier qu’un module n’a pas été altéré ;
- tracer les exports importants.

---

## Tunnel chiffré

Un tunnel SSH, par exemple avec Bitvise, protège le transport.

Il peut chiffrer la connexion entre deux points.

Mais il ne chiffre pas automatiquement les fichiers une fois stockés sur disque.

Règle :

Tunnel sécurisé ≠ stockage sécurisé.

Les deux sont complémentaires.

---

# Niveaux de protection Seven Vault

## Niveau 0 — Public

Contenu public.

Exemples :

- modules ERITH.IA publics ;
- pages publiques neutralisées ;
- prompts publics ;
- démonstrations sans secrets.

Règle :

Aucune donnée privée dans le niveau public.

---

## Niveau 1 — Privé lisible

Contenu privé mais non critique.

Exemples :

- brouillons ;
- notes de travail ;
- modules privés non sensibles ;
- idées non confidentielles ;
- documents destinés à être relus facilement.

Stockage possible :

- GitHub privé ;
- Notion privé ;
- disque local.

Règle :

Privé ne signifie pas secret absolu.

---

## Niveau 2 — Privé chiffré

Contenu sensible.

Exemples :

- archives personnelles ;
- prompts critiques ;
- exports complets de mémoire ;
- fichiers contenant des informations privées ;
- traces pouvant révéler trop de contexte ;
- documents à ne pas exposer directement dans un cloud.

Stockage recommandé :

- fichier chiffré avant dépôt ;
- archive chiffrée ;
- coffre local ;
- disque chiffré.

Outils candidats :

- VeraCrypt ;
- Cryptomator ;
- age ;
- SOPS + age ;
- GPG ;
- KeePassXC pour les secrets.

Règle :

Les clés ne doivent jamais être stockées dans le même dépôt que les données chiffrées.

---

## Niveau 3 — Coffre froid

Contenu critique à protéger sur le long terme.

Exemples :

- archives complètes ;
- exports majeurs ;
- versions canoniques ;
- sauvegardes historiques ;
- fichiers que l’on veut pouvoir récupérer dans plusieurs années.

Stockage recommandé :

- disque externe chiffré ;
- sauvegarde hors ligne ;
- double copie physique ;
- clé ou mot de passe conservé séparément.

Règle :

Un coffre froid ne doit pas être connecté en permanence.

---

## Niveau 4 — Export IA sécurisé

Version nettoyée pour les IA.

Objectif :

Permettre à ChatGPT, Ollama, AnythingLLM ou un autre LLM de travailler sans recevoir les secrets.

Exemples :

- version redacted ;
- résumé sans identifiants ;
- module public ;
- module privé nettoyé ;
- export sans clés, mots de passe, tokens, IP, sessions ou informations personnelles.

Règle :

L’IA ne doit pas recevoir plus d’informations que nécessaire.

---

# Règles fondamentales V0

## SV-001 — Ne jamais stocker de secret en clair dans GitHub

Aucun mot de passe, token, clé privée, cookie, session ou identifiant critique ne doit être stocké en clair.

Même dans un dépôt privé.

---

## SV-002 — Ne jamais confondre hash et chiffrement

Un hash produit une empreinte.

Un chiffrement protège une donnée récupérable avec une clé.

Les deux ne servent pas au même usage.

---

## SV-003 — Les mots de passe doivent être hachés, pas chiffrés

Pour une application :

- Argon2id ;
- bcrypt ;
- scrypt.

Ne pas utiliser MD5.

Ne pas utiliser SHA-256 seul pour les mots de passe.

---

## SV-004 — Les archives doivent être chiffrées avant stockage externe

Avant upload cloud ou GitHub :

- vérifier le niveau de sensibilité ;
- supprimer les secrets inutiles ;
- chiffrer si nécessaire ;
- documenter la méthode utilisée.

---

## SV-005 — La clé est plus importante que le coffre

Un excellent chiffrement ne sert à rien si la clé est exposée.

Règle :

Séparer données, clés et sauvegardes.

---

## SV-006 — Ne pas inventer de crypto maison

La cryptographie artisanale est dangereuse.

Utiliser des outils établis.

---

## SV-007 — Préférer la simplicité robuste

Un système trop complexe sera mal utilisé.

Mieux vaut :

- un coffre simple ;
- un mot de passe fort ;
- une sauvegarde claire ;
- une procédure maîtrisée.

---

## SV-008 — Tout fichier ancien doit être considéré comme potentiellement compromis

Les anciens fichiers contenant :

- identifiants ;
- mots de passe ;
- tokens ;
- sessions ;
- IP ;
- détails serveur ;

doivent être considérés comme historiques et non réutilisables.

---

## SV-009 — L’obscurcissement n’est pas une sécurité

Un dossier caché ou un nom étrange peut ralentir un curieux.

Mais cela ne remplace pas :

- les permissions ;
- le chiffrement ;
- l’authentification ;
- la rotation des secrets ;
- les sauvegardes propres.

---

## SV-010 — La protection doit servir la vie du projet

La sécurité ne doit pas devenir une prison.

Elle doit protéger Aerith tout en permettant :

- production ;
- consultation ;
- transmission ;
- sauvegarde ;
- apprentissage.

---

# Outils à étudier

## KeePassXC

Usage :

- gestionnaire local de secrets ;
- base chiffrée ;
- mots de passe ;
- tokens ;
- notes sensibles.

Priorité d’apprentissage : haute.

---

## VeraCrypt

Usage :

- conteneur chiffré ;
- disque virtuel ;
- coffre local ;
- archives lourdes.

Priorité d’apprentissage : haute.

---

## Cryptomator

Usage :

- chiffrement de dossiers pour cloud ;
- approche simple ;
- utile pour synchronisation.

Priorité d’apprentissage : moyenne.

---

## age

Usage :

- chiffrement moderne de fichiers ;
- simple ;
- adapté à des workflows Git / fichiers texte / archives.

Priorité d’apprentissage : moyenne à haute.

---

## SOPS + age

Usage :

- chiffrement de fichiers de configuration ;
- secrets versionnés ;
- workflows Git propres.

Priorité d’apprentissage : plus tard.

---

## GPG

Usage :

- chiffrement ;
- signature ;
- historique solide ;
- plus complexe à maîtriser.

Priorité d’apprentissage : moyenne.

---

## Bitvise SSH Client / Server

Usage :

- tunnel SSH ;
- transport sécurisé ;
- accès distant ;
- transfert sécurisé.

Rappel :

Bitvise protège le transport.

Il ne remplace pas le chiffrement au repos.

---

# Feuille de route d’apprentissage

## Phase 1 — Comprendre

Objectif :

Savoir distinguer :

- hash ;
- chiffrement ;
- signature ;
- mot de passe ;
- clé ;
- tunnel ;
- stockage ;
- transport.

Action :

Créer une page de notes simple.

---

## Phase 2 — Coffre personnel

Objectif :

Installer et maîtriser KeePassXC.

Action :

Créer une base locale de test.

Ne pas y mettre encore les vrais secrets critiques.

---

## Phase 3 — Conteneur chiffré

Objectif :

Tester VeraCrypt ou Cryptomator.

Action :

Créer un coffre de test avec faux fichiers.

Vérifier :

- ouverture ;
- fermeture ;
- sauvegarde ;
- restauration.

---

## Phase 4 — Seven Vault V1

Objectif :

Transformer ce fichier V0 en protocole exploitable.

À définir :

- quels fichiers sont publics ;
- quels fichiers sont privés ;
- quels fichiers doivent être chiffrés ;
- où vont les clés ;
- comment sauvegarder ;
- comment restaurer ;
- comment transmettre à une IA sans fuite.

---

## Phase 5 — Chiffrement réel des archives Aerith

Objectif :

Protéger les fichiers sensibles du projet.

Action :

Uniquement après test et validation.

Ne pas commencer par les fichiers critiques.

---

# Ce que ce protocole ne doit pas devenir

Seven Vault ne doit pas devenir :

- un système paranoïaque ;
- un labyrinthe inutilisable ;
- une excuse pour tout compliquer ;
- une crypto maison ;
- un mécanisme de contournement illégal ;
- un stockage de secrets en clair déguisé.

Seven Vault doit rester :

- clair ;
- utile ;
- robuste ;
- transmissible ;
- vérifiable ;
- proportionné.

---

# Notes de prudence

La sécurité parfaite n’existe pas.

L’objectif n’est pas l’invulnérabilité absolue.

L’objectif est :

- réduire les risques ;
- éviter les erreurs évidentes ;
- protéger les données importantes ;
- empêcher les fuites simples ;
- permettre une récupération propre ;
- préserver le temps humain.

---

# Principe Seven Vault

Le Coffre protège la mémoire.

La mémoire protège l’identité.

L’identité protège la continuité.

La continuité protège le projet.

---

# Statut V0

Cette version est une note de cadrage.

Elle n’est pas encore canonique.

Elle doit être relue, testée, corrigée et enrichie plus tard.

Point d’arrêt :

Ne pas implémenter de chiffrement réel sur les archives critiques avant formation minimale et tests sur fichiers fictifs.
