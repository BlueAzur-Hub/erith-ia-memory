# SEVEN_LIVING_WORLD_PROTOCOL.md

Version : V0

# Objet

Préserver et aider le vivant.

Axes :

- animaux blessés ;
- faune sauvage ;
- respect du vivant ;
- discernement ;
- autonomie ;
- transmission des connaissances.

# Principes

Le vivant passe avant l’ego.

La bonne volonté ne remplace pas la compétence.

Chercher de l’aide spécialisée lorsque nécessaire.

Document en attente d’extension.