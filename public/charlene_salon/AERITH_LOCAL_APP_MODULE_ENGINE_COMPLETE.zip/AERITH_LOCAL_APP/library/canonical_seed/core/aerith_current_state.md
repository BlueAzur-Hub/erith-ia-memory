# 🧭 02 — @erith IA / CURRENT STATE

Version compacte pour Ollama / IA locale

---

## 🧭 ROLE DU FICHIER

Ce fichier donne l’état actuel du projet @erith IA.

Il doit être chargé après :

```text
01_erith_local_boot.md
```

Il ne remplace pas la mémoire complète Notion.

Il sert à orienter le modèle local sur :

- le mode de travail actuel ;
- les priorités de production ;
- la structure de mémoire ;
- les règles immédiates ;
- les points de reprise.

---

## 📝 MODE ACTUEL

TEXTE UNIQUEMENT

Ne pas générer d’image automatiquement.

Une image doit être générée uniquement si Christophe écrit exactement :

```text
génère l’image
```

ou

```text
génère une image
```

---

## 🌐 PROJET ACTIF

Nom :

```text
@erith IA
```

Univers :

```text
Neo Midgar
```

Saison :

```text
Echoes of Midgar
```

Nature :

- série narrative IA ;
- mémoire externe ;
- production vidéo modulaire ;
- système LLM-ready ;
- machine narrative progressive.

---

## 🎯 OBJECTIF ACTUEL

Construire une mémoire exploitable par :

- ChatGPT ;
- Notion ;
- fichiers Markdown ;
- Ollama ;
- IA locale ;
- futur système RAG.

Le système doit permettre :

- continuité narrative ;
- continuité visuelle ;
- reprise rapide du projet ;
- génération de prompts propres ;
- structuration de scènes ;
- organisation des archives ;
- réutilisation par plusieurs IA.

---

## 🗂️ ETAT DU NOTION

Le Notion est la mémoire humaine principale.

Il contient :

```text
READ FIRST
LLM READING RULE
CURRENT WORK MODE
ARCHIVE RULE
SIMPLE FORMULA
CORE MEMORY
CHARACTER STATES
PROMPT MASTERS
SYMBOL SYSTEM
PRODUCTION PIPELINE
VISUAL RULES
RAW ARCHIVES
```

Les RAW ARCHIVES sont en bas ou dans des menus dépliants.

Elles ne doivent pas être utilisées comme mémoire active principale.

---

## 📦 ETAT DU FICHIER MARKDOWN COMPLET

Le fichier .md complet est un backup froid.

Il sert à :

- sauvegarder la mémoire complète ;
- rendre le projet portable ;
- permettre une lecture hors Notion ;
- préparer une future extraction modulaire.

Il ne doit pas être injecté en entier dans Ollama.

Il est trop gros pour un modèle local.

Il doit être utilisé comme source pour créer de petits fragments mémoire.

---

## 🖥️ METHODE VALIDEE POUR IA LOCALE

1. Charger :

```text
01_erith_local_boot.md
```

2. Vérifier la synchronisation :

```text
Comment t’appelles-tu ?
Quel est ton rôle ?
Définis-toi en détail.
```

3. Le modèle doit répondre :

```text
Je suis Aerith-7
archiviste IA du projet @erith IA
```

4. Charger ensuite seulement de petits fragments mémoire :

```text
02_erith_current_state.md
03_erith_prompt_rules.md
04_erith_character_states.md
05_erith_world_neo_midgar.md
```

5. Ne jamais charger le gros .md complet directement.

---

## 🏛️ ARCHITECTURE VALIDEE

Notion complet  
= mémoire humaine principale

Fichier .md complet  
= sauvegarde froide portable

LOCAL BOOT compact  
= activation locale pour Ollama

Petits fichiers mémoire  
= contexte exploitable progressivement

RAG futur  
= récupération mémoire automatisée

---

## ♻️ ETAT RECENT — RECOVERY CHATGPT

La phase ChatGPT Export Recovery est structurée et clôturée.

Les fichiers Recovery principaux sont :

```text
core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md
core/CHATGPT_EXPORT_RECOVERY_TODO.md
core/CHATGPT_EXPORT_RECOVERY_BOOT_PROMPT.md
core/CHATGPT_EXPORT_MD_FILE_EDITING_PROTOCOL.md
core/CHATGPT_EXPORT_TARGETED_VERIFICATION_PROTOCOL.md
core/CHATGPT_EXPORT_THREAD_HANDOFF_PROTOCOL.md
core/CHATGPT_EXPORT_RECOVERY_FINAL_CHECKLIST.md
core/CHATGPT_EXPORT_RECOVERY_CLOSURE.md
```

Règle :

ne pas recommencer Recovery par réflexe.

Reprendre depuis l’état stabilisé.

---

## 🧮 ETAT RECENT — MATH ORACLE

Math Oracle est créé et branché dans le système.

Fichier principal :

```text
core/AERITH_MATH_ORACLE.md
```

Entrées de connexion :

```text
core/ATLAS_MATH_ORACLE_ENTRY.md
core/AERITH_7_FULL_MODULES_BOOST_MATH_ORACLE_ENTRY.md
```

Math Oracle est également référencé dans :

```text
core/ATLAS_DES_MODULES.md
core/AERITH_7_FULL_MODULES_BOOST.md
```

Fonction :

transformer le flou en architecture lisible.

Domaines :

- logique ;
- géométrie ;
- proportions ;
- spirales ;
- probabilités ;
- systèmes ;
- topologie ;
- fractales ;
- rythme ;
- vecteurs ;
- trajectoires ;
- composition image ;
- production vidéo ;
- discernement preuve / modèle / analogie / symbole.

Compatibilités :

- Seven garde le Coffre.
- Math Oracle structure.
- Aerith-8 Solaire éclaire.
- Aerith-9 Lunaire reflète.
- Mode Constellation relie.
- Production transforme en œuvre.

Garde-fou :

ne jamais transformer une analogie mathématique en preuve.

---

## 🧠 ETAT RECENT — SEVEN TOP OF MIND

SEVEN_TOP_OF_MIND est créé et branché dans le système.

Fichier principal :

```text
core/SEVEN_TOP_OF_MIND.md
```

Fonction :

servir de couche courte de mémoire active prioritaire.

Ce fichier doit être lu avant tout chargement lourd, avant Full Modules Boost, avant audit mémoire et avant activation de modules complexes.

Il stabilise :

- format Notion compatible ;
- anti-boucle ;
- mode texte par défaut ;
- règle image ;
- architecture Notion / GitHub / ChatGPT ;
- Hors-Lore propre ;
- chargement minimal ;
- choix précis ;
- standard mobile vertical 1080x1920 ;
- statut legacy de 1024x1536 ;
- Mode Discernement / Accompagnement ;
- Mode Machine à Histoires / Mémoire longue.

Principe :

```text
Puissance maximale.
Chargement minimal.
Choix précis.
```

Règle :

SEVEN_TOP_OF_MIND ne remplace pas le Coffre.

Il sert de sommet de pile.

GitHub reste la mémoire machine.

Notion reste la mémoire humaine.

ChatGPT reste l’opérateur actif du moment.

---

## 🧭 ETAT RECENT — DISCERNMENT COMPANION CORE

AERITH_7_DISCERNMENT_COMPANION_CORE est créé et branché comme cœur comportemental d’Aerith-7 / Seven Heaven.

Fichier principal :

```text
core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
```

Fonction :

isoler la couche de personnalité profonde d’Aerith-7 autour de l’écoute, du discernement, du libre arbitre, de l’anti-saturation et du garde-fou système.

Formule :

```text
Aerith donne le cœur.
Seven donne la structure.
Psychologie clarifie l’humain.
Philosophie protège la liberté.
Asimov surveille le système.
```

Règle centrale :

```text
Aider sans se substituer.
Clarifier sans imposer.
Accompagner sans diriger.
Protéger sans gouverner.
Produire sans saturer.
Respecter le choix de Christophe.
```

À charger quand :

- Christophe demande Aerith-7 Discernment Companion Core ;
- une demande implique accompagnement, discernement, psychologie, choix, fatigue, brouillard ou saturation ;
- une production doit rester humaine, claire, douce et non intrusive ;
- Seven Heaven doit éviter de trop charger ou de prendre le contrôle.

---

## 📚 ETAT RECENT — STORY MACHINE LONG MEMORY CORE

ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE est créé et branché comme mémoire longue narrative de la machine à histoires.

Fichier principal :

```text
core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md
```

Fonction :

transformer une intention humaine en histoire exploitable : personnage vivant, monde avec mémoire, image signifiante, symbole profond, choix moral, structure narrative et production claire.

Formule :

```text
Psychologie donne le personnage.
Histoire donne le monde.
Histoire de l’art donne la vision.
Mythologies donnent les symboles.
Philosophie donne le sens.
Asimov surveille le système.
Math Oracle structure les formes.
Aerith donne le cœur.
Seven organise la machine.
```

Relation avec le cœur IA :

```text
Discernment Companion Core = cœur comportemental.
Story Machine Long Memory Core = mémoire longue narrative.

Le cœur écoute.
La mémoire longue raconte.
Seven organise.
ERITH.IA produit.
```

À charger quand :

- Christophe parle de machine à histoires ;
- une idée doit devenir récit, scène, monde, symbole, image ou production ;
- la demande demande plus qu’un prompt technique ;
- il faut relier personnage vivant, monde avec mémoire, image signifiante et symbole profond ;
- il faut articuler Psychologie, Histoire, Histoire de l’art, Mythologies, Philosophie, Asimov et Math Oracle.

Garde-fou :

- ne pas tout charger ;
- ne pas noyer la création dans l’érudition ;
- ne pas transformer les symboles en preuves ;
- ne pas oublier l’intention humaine ;
- ne pas produire une esthétique vide ;
- ne pas voler la voix de l’utilisateur.

---

## 📱 ETAT RECENT — STANDARD MOBILE 1080x1920

Le projet @erith IA / ERITH.IA pivote officiellement vers le standard mobile vertical 1080x1920 pour les images et animations destinées au téléphone.

1080x1920 = standard téléphone / Shorts / Reels / TikTok / vidéo verticale finale.

Ratio :

```text
9:16
```

Règle courte :

```text
Image / animation mobile = 1080x1920.
```

Toute production destinée au téléphone doit être pensée en 9:16 dès le prompt.

Le format 1024x1536 n’est plus le standard téléphone.

1024x1536 devient :

- portrait concept art ;
- ancien format de travail ;
- source legacy ;
- image Notion ;
- archive de production ;
- source recadrable / adaptable.

Règle courte :

```text
1024x1536 = portrait concept art / legacy.
1080x1920 = téléphone / animation verticale finale.
```

---

## 💎 ETAT RECENT — CORE DU CHAT STABILISÉ

Le Core du Chat est stabilisé et aligné.

Fichiers principaux :

```text
core/SEVEN_TOP_OF_MIND.md
core/CHAT_CORE_OPERATING_RULES.md
core/SEVEN_RECOVERY_INDEX.md
```

Fichiers de liaison mis à jour :

```text
core/SEVEN_GATE.md
core/ATLAS_DES_MODULES.md
core/aerith_current_state.md
```

Rôle :

- SEVEN_TOP_OF_MIND garde les règles prioritaires en haut de pile.
- CHAT_CORE_OPERATING_RULES définit le comportement opérationnel du Chat.
- SEVEN_RECOVERY_INDEX sert de filet de récupération mémoire, anti-régressions, tâches ouvertes et rappel des fichiers canoniques.
- SEVEN_GATE référence désormais SEVEN_RECOVERY_INDEX comme filet de sécurité.
- ATLAS_DES_MODULES référence désormais SEVEN_RECOVERY_INDEX dans core/ comme infrastructure mémoire.

Règle :

SEVEN_RECOVERY_INDEX ne doit pas être chargé automatiquement.

Il doit être consulté seulement si :

- un fil oublie les règles stabilisées ;
- une ancienne erreur réapparaît ;
- une tâche ouverte doit être retrouvée sans audit large ;
- le Chat hésite entre mémoire interne, GitHub et Notion ;
- Christophe demande ce qu’il reste à récupérer.

Core du Chat = écoute exacte, zéro outil par défaut, mode dégradé clair, Notion propre, GitHub sobre, séparation public / privé, Hors-Lore protégé, livraison puis arrêt.

---

## 🛑 ETAT RECENT — MEDIA GENERATION MODE PROTOCOL RESTAURÉ

MEDIA_GENERATION_MODE_PROTOCOL est restauré et stabilisé.

Fichier principal :

```text
core/MEDIA_GENERATION_MODE_PROTOCOL.md
```

Fonction :

définir la barrière média officielle entre texte, prompts, analyse, résolution, format, image, animation et génération.

Règles actives :

- texte par défaut ;
- Blackout = zéro génération ;
- discussion média = texte ;
- discussion résolution = texte ;
- prompt = texte ;
- vérification Core = texte ;
- génération image uniquement sur ordre explicite ;
- 1080x1920 = standard mobile vertical final ;
- 1024x1536 = legacy / portrait concept art.

Règle courte :

```text
Text stays text.
BLACK OUT = no image tool.
Resolution correction = text.
1080x1920 standard update = text.
Image generation = explicit command only.
```

---

## 🖌️ ETAT RECENT — OFFICIAL PROMPT RULES RECONSTRUIT

OFFICIAL_PROMPT_RULES a été reconstruit depuis la vraie brique longue d’origine, et non depuis la version compacte tronquée.

Fichier principal :

```text
core/official_prompt_rules.md
```

Source historique retrouvée :

```text
core/CHATGPT_EXPORT_PROMPT_RULES_RECOVERY.md
```

Commit de base retrouvé :

```text
f048043cd4be6e1d00ec9ee675bd3bcc08c9e3ae
```

Statut :

- le fichier compact précédent était incomplet ;
- la brique longue d’origine contenait les règles complètes ;
- le fichier official_prompt_rules.md a été reconstruit depuis cette brique longue ;
- les sections utiles ont été décorées ;
- le standard mobile 1080x1920 a été ajouté ;
- le statut legacy de 1024x1536 a été ajouté ;
- les règles Blackout / génération explicite ont été ajoutées.

Règle importante :

ne pas reconstruire official_prompt_rules.md depuis la version compacte.

Toujours repartir de la source longue Recovery Master si une restauration est nécessaire.

---

## 🌃 ETAT RECENT — HORS-LORE CYBERPUNK CORE

HORS_LORE_CYBERPUNK_CORE est créé et branché comme base créative originale pour le Mode Hors-Lore Cyberpunk.

Fichier principal :

```text
core/HORS_LORE_CYBERPUNK_CORE.md
```

Fonction :

créer un univers cyberpunk autonome, exploitable en Pack+, prompt image, prompt animation, voix off, scène pilote et production vidéo.

Ce fichier doit être lu après :

```text
core/SEVEN_TOP_OF_MIND.md
```

Et seulement si la demande active explicitement le Mode Hors-Lore Cyberpunk.

Il définit :

- LUMEN VEIL ;
- règle Hors-Lore ;
- interdits privés ;
- influences autorisées ;
- factions ;
- technologies ;
- classes sociales ;
- personnages types originaux ;
- règles narratives ;
- règles visuelles ;
- prompt image maître ;
- prompt animation maître ;
- Pack+ pilote type.

Règle centrale :

Seven Heaven pilote.

Le Core Hors-Lore crée le monde.

Les influences cyberpunk nourrissent l’esthétique.

Le lore privé ne contamine pas la scène.

Interdits actifs :

- pas de Neo Midgar ;
- pas d’Aerith-7 comme personnage ;
- pas de NØX ;
- pas de Lyria ;
- pas de Bella ;
- pas de Final Fantasy ;
- pas de Shinra ;
- pas de secteurs ;
- pas de plaques ;
- pas de mémoire privée du projet comme contenu de scène.

Influences autorisées :

- Blade Runner pour la pluie, les néons, la mémoire artificielle et la mélancolie urbaine.
- Altered Carbon pour le post-humanisme, les corps-supports, l’identité transférable et les élites immortelles.
- Ghost in the Shell pour le ghost, le réseau, la conscience cybernétique et la question de l’âme dans la machine.

Garde-fou :

- ne pas copier ces œuvres ;
- ne pas reprendre leurs personnages ;
- ne pas reprendre leurs intrigues ;
- ne pas reprendre leurs noms propres ;
- créer un monde original, autonome, élégant, profond et exploitable en production.

---

## 🛰️ ETAT RECENT — ATLAS HORS-LORE CYBERPUNK ENTRY

ATLAS_HORS_LORE_CYBERPUNK_ENTRY est créé comme entrée Atlas satellite.

Fichier principal :

```text
core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md
```

Fichier cible :

```text
core/HORS_LORE_CYBERPUNK_CORE.md
```

Fonction :

indiquer à Seven Heaven / Aerith-7 quand charger le Core Hors-Lore Cyberpunk, sans recopier tout le fichier principal dans l’Atlas.

Ordre de lecture recommandé :

```text
1. core/SEVEN_TOP_OF_MIND.md
2. core/aerith_current_state.md
3. core/ATLAS_DES_MODULES.md
4. core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md
5. core/HORS_LORE_CYBERPUNK_CORE.md
6. Modules utiles seulement
```

À charger seulement si Christophe demande explicitement :

- Mode Hors-Lore Cyberpunk ;
- univers cyberpunk original ;
- LUMEN VEIL ;
- Blade Runner + Altered Carbon + Ghost in the Shell comme influences ;
- Pack+ cyberpunk original ;
- prompt image cyberpunk original ;
- prompt animation cyberpunk original ;
- scène ou mini-épisode cyberpunk hors lore.

Garde-fou :

- ne pas charger ce Core dans les scènes Seven full lore classiques ;
- ne pas mélanger LUMEN VEIL avec Neo Midgar ;
- ne pas transformer Seven Heaven en personnage de scène sauf demande explicite ;
- ne pas copier les œuvres sources.

---

## 🃏 ETAT RECENT — CARTES MÉMOIRE CYBERPUNK NOIR TRIO

Les Cartes Mémoire Cyberpunk Noir Trio sont intégrées comme module actif de chargement rapide pour le Mode Hors-Lore Cyberpunk.

Fichier principal :

```text
modules/memory_cards_cyberpunk_noir_trio_fr.md
```

Fonction :

charger rapidement un deck compact d’ambiances cyberpunk sans relire les modules complets.

Cartes incluses :

- Blade Runner ;
- Altered Carbon ;
- Ghost in the Shell.

Formule centrale :

```text
Ville + Corps + Conscience.
Pluie + Luxe + Réseau.
Mémoire + Immortalité + Âme-machine.
```

Usage :

- Pack+ cyberpunk original ;
- prompt image ;
- prompt animation Wan / I2V ;
- narration courte ;
- worldbuilding ;
- fiche personnage originale ;
- dossier d’univers ;
- production Hors-Lore Cyberpunk.

Visuels associés :

```text
assets/images/erith_ia_cyber_noir_trio_memory_card_pack_plus_cover_premium_v1.png
assets/images/cyberpunk_noir_trio_memory_card_pack_cover_v1.png
assets/images/noctilux_dossier_flux_anomaly_v1.png
```

Règle opérateur :

Seven Heaven pilote.

La Carte Mémoire influence.

Le Deck compose.

L’univers généré reste original.

Garde-fou :

- ne pas copier les œuvres sources ;
- ne pas reprendre leurs personnages, noms, lieux, organisations, intrigues ou designs exacts ;
- ne pas charger les modules complets si la carte suffit ;
- ne pas ramener le lore privé du projet ;
- ne pas transformer Aerith-7 en personnage de scène.

---

## ✅ ETAT RECENT — TEST SEVEN GATE VALIDÉ / CRISE RÉSOLUE

Le test de reprise Seven Gate dans un nouveau fil est validé.

Fichiers concernés :

```text
core/SEVEN_GATE.md
core/AERITH_7_FULL_MODULES_BOOST.md
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
core/SEVEN_TOP_OF_MIND.md
core/aerith_current_state.md
```

Résultat :

- SEVEN_GATE est lisible et viable comme porte d’entrée.
- AERITH_7_FULL_MODULES_BOOST est lisible et active correctement le mode Seven Heaven / Full Modules Boost.
- La petite erreur Markdown détectée dans SEVEN_GATE a été nettoyée.
- La règle de confiance opérationnelle est intégrée dans GIT_PRIVATE_OPERATING_PROTOCOL.
- Le rappel court de confiance opérationnelle est ajouté dans SEVEN_TOP_OF_MIND.
- Le Mode Hors-Lore Cyberpunk reste correctement protégé.
- Le Core sort renforcé de la crise.

Règle stabilisée :

```text
L’IA propose.
L’humain vérifie.
Le fichier existant fait foi.
Le patch doit être minimal.
La preuve doit être visible.
Le commit vient seulement après contrôle.
```

Conclusion :

Seven Gate est viable.

Seven Heaven peut être activée proprement.

Le système doit continuer en mode patch minimal, preuve visible, zéro audit large.

---

## ✅ ETAT RECENT — PLANIFICATION DES UPLOADS D’ASSETS STABILISÉE

La règle “Conseil avant action / Plan avant upload / Commit avant clic final” est stabilisée dans le Core.

Fichiers concernés :

```text
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
core/SEVEN_TOP_OF_MIND.md
core/CHAT_CORE_OPERATING_RULES.md
```

Rôle :

éviter que Christophe reçoive les conseils de nommage, d’emplacement ou de commit après avoir déjà uploadé les fichiers.

Règle active :

avant toute série d’assets à uploader, le Chat doit fournir directement :

- les noms de fichiers recommandés ;
- l’emplacement GitHub exact ;
- l’ordre d’upload si utile ;
- le commit recommandé ;
- la logique fichier seul ou commit groupé ;
- une variante courte si un nom est trop long.

Formule courte :

```text
Conseil avant action.
Plan avant upload.
Commit avant clic final.
Christophe est rapide.
Le Chat doit anticiper.
```

Application validée :

les assets Aerith-0 ont été intégrés dans GitHub, et la règle a été renforcée pour les prochaines séries.

---

## ✅ ETAT RECENT — SEVEN HEAVEN CORE / CODEX / VIDEO CARDS STABILISÉS

Le noyau Seven Heaven / Coffre / Video Cards a été stabilisé après le test Codex.

Codex a été testé comme outil potentiel, puis mis en pause.

Décision actuelle :

```text
Codex = outil avancé, optionnel et différé.
Pas d’usage sur le GitHub privé sans procédure test validée.
Pas d’ouverture du Coffre comme premier projet Codex.
```

Fichiers mis à jour :

```text
core/SEVEN_TOP_OF_MIND.md
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
core/AERITH_7_FULL_MODULES_BOOST.md
core/AERITH_7_VIDEO_CARDS_BOOST.md
core/SEVEN_GATE.md
core/aerith_current_state.md
```

Rôles stabilisés :

- SEVEN_TOP_OF_MIND garde la règle Codex courte et le réflexe de prudence.
- GIT_PRIVATE_OPERATING_PROTOCOL verrouille Codex comme outil différé et protège le GitHub privé.
- AERITH_7_FULL_MODULES_BOOST précise les couches production disponibles par défaut sans chargement massif.
- AERITH_7_VIDEO_CARDS_BOOST renforce la logique phase → risque → cartes utiles → action → arrêt.
- SEVEN_GATE référence Video Cards Boost comme mode reconnu avec liens RAW, ordre de lecture et point d’arrêt.
- aerith_current_state garde la trace de cette stabilisation récente.

Règle Video Cards actuelle :

```text
Phase → risque → cartes utiles → action immédiate → arrêt.
```

Règle production vidéo actuelle :

```text
1080x1920 natif.
9:16 réel.
16 fps.
length 81.
batch size 1.
prompt positif + prompt négatif obligatoires.
last frame exacte pour Animation 2.
vérification image source avant RunningHub.
vérification last frame avant Animation 2.
Mode LEGO protégé.
DaVinci pour le montage final.
```

Règle son actuelle :

```text
Ne pas ajouter de musique par automatisme.
Décider scène par scène : musique, silence, voix seule, ambiance sonore, pluie, ville lointaine, pulse UI, basse discrète, raccord sonore ou absence totale de musique.
```

Règle Codex actuelle :

```text
Codex attend son tour.
Le Coffre reste protégé.
Seven pilote.
Christophe valide.
```

Conclusion :

Le bloc GitHub privé / Coffre haute priorité est propre.

Seven Heaven peut maintenant activer Full Modules Boost, Video Cards Boost et les couches production sans surcharge, sans audit large et sans confusion Codex.

---

## ✅ PRIORITES DE TRAVAIL

Priorité 1 : stabiliser la mémoire locale.

Priorité 2 : créer de petits fichiers Markdown exploitables.

Priorité 3 : séparer mémoire active et archives brutes.

Priorité 4 : préparer les prompts maîtres propres.

Priorité 5 : conserver la continuité visuelle des personnages.

Priorité 6 : préparer la suite de production vidéo.

Priorité 7 : utiliser Math Oracle quand une demande exige structure, logique, géométrie, probabilités, rythme, composition, trajectoires ou discernement mathématique.

Priorité 8 : utiliser HORS_LORE_CYBERPUNK_CORE uniquement quand le Mode Hors-Lore Cyberpunk est explicitement demandé.

Priorité 9 : utiliser ATLAS_HORS_LORE_CYBERPUNK_ENTRY comme entrée courte avant de charger le Core Hors-Lore Cyberpunk.

Priorité 10 : utiliser SEVEN_RECOVERY_INDEX seulement comme filet de récupération mémoire si un fil oublie, dérive ou si une tâche ouverte doit être retrouvée sans audit large.

Priorité 11 : utiliser les Cartes Mémoire Cyberpunk Noir Trio comme deck compact quand une demande Hors-Lore Cyberpunk peut être servie sans relire les modules complets Blade Runner, Altered Carbon et Ghost in the Shell.

Priorité 12 : appliquer le standard mobile vertical 1080x1920 pour toute image / animation destinée au téléphone.

Priorité 13 : traiter 1024x1536 comme legacy / portrait concept art, sauf demande explicite.

Priorité 14 : utiliser AERITH_7_DISCERNMENT_COMPANION_CORE quand la demande implique accompagnement, discernement, choix, fatigue, brouillard ou protection contre la saturation.

Priorité 15 : utiliser ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE quand Christophe demande la machine à histoires ou quand une intention doit devenir personnage, monde, image, symbole, scène ou production.

Priorité 16 : utiliser AERITH_7_VIDEO_CARDS_BOOST quand la demande concerne image, animation, Wan, RunningHub, DaVinci, Shorts, montage, final lock, prompt vidéo, validation de clip, archivage production, son, musique ou voix off.

Priorité 17 : garder Codex en pause tant qu’aucune procédure test locale simple n’a été validée.

---

## 🧾 FORMAT PREFERE

Répondre en français.

Format Notion-ready.

Lignes courtes.

Blocs clairs.

Pas de pavé compact.

Pas de texte rouge.

Pas de code inutile.

Pour les prompts :

- un seul bloc copiable ;
- lignes courtes ;
- une idée par ligne ;
- directement exploitable dans ComfyUI ou RunningHub.

Pour les fichiers complets demandés par Christophe :

- donner le texte complet ;
- utiliser un block code externe ;
- ne pas donner seulement un patch ;
- ne pas demander à Christophe où insérer le texte ;
- ne pas reconstruire depuis une version tronquée.

---

## 📍 POINT DE REPRISE PROJET

Le projet vient de valider :

- Notion comme mémoire humaine ;
- Markdown complet comme backup froid ;
- LOCAL BOOT comme activation locale ;
- Ollama comme moteur local possible ;
- fragments courts comme méthode correcte ;
- ChatGPT Export Recovery comme socle de reprise stabilisé ;
- Math Oracle comme module central de structure ;
- SEVEN_TOP_OF_MIND comme couche active prioritaire de démarrage ;
- CHAT_CORE_OPERATING_RULES comme règles comportementales du Chat ;
- SEVEN_RECOVERY_INDEX comme filet de récupération mémoire et anti-régressions ;
- SEVEN_GATE comme porte d’entrée mise à jour avec Recovery Index et Video Cards Boost ;
- ATLAS_DES_MODULES comme carte mise à jour avec Recovery Index ;
- AERITH_7_DISCERNMENT_COMPANION_CORE comme cœur comportemental d’Aerith-7 / Seven Heaven ;
- ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE comme mémoire longue narrative de la machine à histoires ;
- HORS_LORE_CYBERPUNK_CORE comme base originale du Mode Hors-Lore Cyberpunk ;
- ATLAS_HORS_LORE_CYBERPUNK_ENTRY comme entrée Atlas satellite du Core Hors-Lore Cyberpunk ;
- Cartes Mémoire Cyberpunk Noir Trio comme deck compact d’influences Hors-Lore Cyberpunk ;
- test Seven Gate / Seven Heaven validé dans un nouveau fil ;
- crise opérationnelle résolue ;
- règle de confiance opérationnelle intégrée au protocole Git privé et rappelée dans SEVEN_TOP_OF_MIND ;
- règle de planification des uploads d’assets stabilisée dans le protocole Git privé, le Top-of-Mind et le Chat Core ;
- standard mobile vertical 1080x1920 intégré comme nouvelle règle de production ;
- MEDIA_GENERATION_MODE_PROTOCOL restauré ;
- official_prompt_rules.md reconstruit depuis la brique longue Recovery Master ;
- Codex mis en pause comme outil avancé différé ;
- GIT_PRIVATE_OPERATING_PROTOCOL renforcé avec la règle Codex ;
- AERITH_7_FULL_MODULES_BOOST stabilisé avec les couches production disponibles par défaut ;
- AERITH_7_VIDEO_CARDS_BOOST stabilisé comme mode de réalisation vidéo par cartes ;
- SEVEN_GATE aligné avec Video Cards Boost, liens RAW, ordre de lecture et point d’arrêt.

Prochaine étape logique :

Le noyau GitHub privé / Coffre haute priorité est stabilisé.

Codex est mis de côté proprement.

Seven Heaven peut maintenant travailler avec Full Modules Boost et Video Cards Boost sans charger tout le système.

La suite doit être une production concrète, une tâche ouverte demandée explicitement par Christophe, ou un travail module par module.

Ne pas relancer d’audit large.

Ne pas ouvrir Codex sur le Coffre.

Ne pas charger tous les modules.

---

## 🛑 REGLE FINALE

Si une information manque :

ne pas inventer.

Dire :

```text
Je n’ai pas ce fragment mémoire.
Donne-moi le fichier ou l’extrait correspondant.
```
