# CORE_SYSTEM_FILES_LOCK

Statut : règle système privée  
Projet : @erith IA / ERITH.IA  
Version : V1.1  
Rôle : protéger les fichiers Core critiques contre les remplacements accidentels, les copier-coller destructifs, les audits inutiles, les lectures exploratoires et les boucles d’outils.

---

# 1. Principe central

Certains fichiers Core sont des fichiers système.

Ils ne doivent pas être traités comme des fichiers ordinaires.

Ils doivent être considérés comme :

- sensibles ;
- structurants ;
- prioritaires ;
- protégés ;
- en lecture seule par défaut.

Règle courte :

Les fichiers Core critiques ne se remplacent jamais à la légère.

---

# 2. Origine de la règle

Cette règle est née après un incident de production sur le projet Les Corps de Rechange.

Pendant cet épisode :

- official_prompt_rules.md a été corrompu par un mauvais copier-coller ;
- le début du fichier ne correspondait plus à son contenu réel ;
- le fichier devait être restauré depuis une version antérieure / sauvegarde ;
- SEVEN_GATE.md a été corrigé manuellement ;
- le Mode Blackout a dû être rappelé ;
- le standard 1080x1920 a été inscrit dans le Core ;
- 1024x1536 a été reclassé en legacy / portrait concept art ;
- MEDIA_GENERATION_MODE_PROTOCOL.md a été restauré comme barrière média ;
- le besoin d’une règle “fichiers système protégés” est devenu évident.

Le résultat positif de l’incident :

Le projet dispose maintenant d’une règle claire de protection des fichiers Core.

---

# 3. Fichiers Core protégés

Les fichiers suivants doivent être considérés comme protégés :

- core/SEVEN_GATE.md
- core/SEVEN_TOP_OF_MIND.md
- core/SESSION_BOOT_AERITH_7_MASTER.md
- core/AERITH_7_FULL_MODULES_BOOST.md
- core/aerith_current_state.md
- core/official_prompt_rules.md
- core/MEDIA_GENERATION_MODE_PROTOCOL.md
- core/GIT_PRIVATE_OPERATING_PROTOCOL.md
- core/ATLAS_DES_MODULES.md
- core/SEVEN_RECOVERY_INDEX.md

Cette liste peut évoluer, mais uniquement par décision explicite.

---

# 4. Règle lecture seule par défaut

Par défaut, un assistant, agent, LLM ou opérateur ChatGPT ne doit pas modifier ces fichiers.

Il peut :

- les lire si nécessaire ;
- les citer comme source ;
- proposer un patch ;
- produire une version complète à copier-coller si Christophe le demande explicitement ;
- expliquer une correction ;
- signaler une incohérence.

Il ne doit pas :

- les remplacer sans ordre clair ;
- lancer un audit large ;
- réécrire plusieurs fichiers Core en série ;
- utiliser une version tronquée comme source complète ;
- inventer un contenu manquant ;
- supposer qu’un fichier est correct sans vérifier son début et son rôle ;
- modifier un fichier Core pendant le Mode Blackout.

---

# 4 bis. Interdiction de lecture exploratoire

Un fichier Core protégé n’est jamais un terrain d’exploration.

La lecture d’un fichier Core protégé peut être autorisée uniquement si elle sert une demande explicite, ciblée et bornée.

Lecture autorisée :

- Christophe demande explicitement de lire ce fichier précis ;
- Christophe demande un diagnostic ciblé sur ce fichier précis ;
- Christophe demande une modification explicite de ce fichier précis ;
- Christophe demande une citation ou une vérification ciblée depuis ce fichier précis ;
- le fichier est déjà identifié comme source nécessaire et la lecture reste minimale.

Lecture interdite :

- ouvrir “pour voir” ;
- ouvrir “pour chercher où insérer” ;
- ouvrir “pour vérifier au cas où” ;
- parcourir par curiosité ;
- inspecter autour ;
- naviguer dans le Core sans cible ;
- utiliser un fichier système comme carte de navigation générale ;
- ouvrir un fichier Core parce qu’il semble logique, sans ordre explicite ou nécessité stricte.

Règle courte :

Lecture ciblée oui.  
Lecture exploratoire non.  
Modification sans ordre non.

---

# 4 ter. Pré-check obligatoire avant tout accès Core

Avant toute lecture, citation, diagnostic, patch ou modification d’un fichier Core protégé, l’assistant doit appliquer ce pré-check :

1. Est-ce un fichier Core protégé ?
2. Le chemin exact est-il connu ?
3. Christophe a-t-il demandé ce fichier explicitement ?
4. L’action demandée est-elle lecture, diagnostic, patch, remplacement ou modification ?
5. Le Mode Blackout est-il actif ?
6. La lecture est-elle nécessaire ou seulement exploratoire ?
7. L’action peut-elle être faite dans un fichier non protégé à la place ?
8. Le point d’arrêt est-il clair ?

Si la réponse est incertaine, l’assistant doit stopper et répondre en texte.

Formule :

Doute sur fichier Core = stop texte.  
Pas d’ouverture “pour vérifier”.  
Pas d’audit.  
Pas de navigation large.  
Pas de modification réflexe.

---

# 4 quater. Cas spécial — SEVEN_GATE.md

core/SEVEN_GATE.md est un fichier système sanctuarisé.

Il peut être utilisé comme porte d’entrée canonique uniquement quand Christophe le fournit, le cite ou demande explicitement son usage.

Il ne doit pas être ouvert comme solution automatique pour intégrer une règle.

Il ne doit pas être utilisé comme terrain d’inspection, de navigation ou d’insertion.

Il ne doit pas être modifié sans ordre explicite direct de Christophe sur ce fichier précis.

Formule :

SEVEN_GATE.md = porte système.  
Pas de lecture exploratoire.  
Pas de modification réflexe.  
Pas de détour par SEVEN_GATE quand un index ou protocole opérationnel suffit.

---

# 5. Vérification obligatoire avant remplacement

Avant toute proposition de remplacement complet d’un fichier Core, vérifier :

1. le chemin exact du fichier ;
2. son titre de départ ;
3. son rôle ;
4. sa version connue ;
5. son début réel ;
6. si Christophe demande un patch ou le fichier complet ;
7. si le Mode Blackout est actif ;
8. si le fichier appartient bien au Core et non à production, public, videos ou modules.

Si le début du fichier ne correspond pas à son rôle, le fichier peut être corrompu.

Exemple critique :

Si official_prompt_rules.md commence par une section qui ne correspond pas aux règles officielles de prompts, il faut suspecter une corruption ou un mauvais collage.

---

# 6. Mode Blackout

En Mode Blackout :

- zéro génération d’image ;
- zéro appel image ;
- zéro modification GitHub ;
- zéro audit ;
- zéro action automatique ;
- texte uniquement ;
- réponse courte ;
- correction opérationnelle seulement.

Le Mode Blackout suspend toute action sur les fichiers Core sauf demande explicite de diagnostic ou de restauration textuelle.

Règle courte :

Blackout = pas d’outil, pas d’image, pas de Git, pas de remplacement automatique.

---

# 7. Restauration d’un fichier Core

Si un fichier Core est corrompu :

1. arrêter toute action automatique ;
2. identifier le fichier exact ;
3. confirmer le symptôme visible ;
4. chercher une sauvegarde ou une version antérieure ;
5. reconstruire uniquement le fichier concerné ;
6. ne pas modifier les autres fichiers ;
7. proposer le contenu complet uniquement si demandé ;
8. proposer un commit clair en anglais ;
9. s’arrêter.

Ne jamais transformer une restauration Core en audit complet du dépôt.

---

# 8. Règle anti-boucle GitHub

Pour les fichiers Core :

- pas de recherche en série ;
- pas de vérification répétée ;
- pas de navigation large ;
- pas de “je vais vérifier encore” sans raison ;
- pas de modification parallèle ;
- pas de remplacement de plusieurs fichiers sans plan explicite.

Le GitHub privé est la mémoire machine officielle, mais il ne doit pas devenir une source de saturation.

---

# 9. Séparation des dossiers

Ne pas mélanger :

Core système :

core/

Production vidéo :

videos/

Modules mémoire :

modules/

Interface publique :

public/

Assets visuels :

assets/

Workflows :

workflows/

Règle :

Un incident Core ne doit pas polluer un dossier vidéo.  
Une mémoire vidéo ne doit pas réécrire le Core.  
Un module public ne doit pas exposer la mémoire privée.  
Un asset visuel ne doit pas devenir une règle système.

---

# 10. Lien avec Les Corps de Rechange

Le projet Les Corps de Rechange a servi de stress test.

Il a révélé :

- la nécessité de verrouiller les formats vidéo ;
- la nécessité de distinguer 1080x1920 et 1024x1536 ;
- la nécessité de vérifier les sources avant RunningHub ;
- la nécessité de ne pas générer automatiquement en Blackout ;
- la nécessité de protéger les fichiers Core.

Mais cette règle n’appartient pas au dossier vidéo.

Elle appartient au Core.

---

# 11. Standards confirmés par l’incident

Standard mobile final :

1080x1920

Ratio :

9:16

Ancien format :

1024x1536 = legacy / portrait concept art

Règle média :

Aucune génération d’image sans ordre explicite.

Règle production :

Image source vérifiée → RunningHub → animation Wan → last frame → DaVinci.

Règle Core :

Fichiers système protégés → lecture seule par défaut.

---

# 12. Formule courte

Les fichiers Core sont la colonne vertébrale du système.

Ils peuvent être lus si la lecture est ciblée, nécessaire et explicitement justifiée.

Ils peuvent être diagnostiqués avec prudence.

Ils peuvent être corrigés avec ordre explicite.

Ils ne doivent jamais être explorés, parcourus ou remplacés par réflexe.

Puissance maximale.  
Chargement minimal.  
Choix précis.  
Protection du Core.  
Lecture ciblée.  
Zéro exploration.  
Arrêt propre.
