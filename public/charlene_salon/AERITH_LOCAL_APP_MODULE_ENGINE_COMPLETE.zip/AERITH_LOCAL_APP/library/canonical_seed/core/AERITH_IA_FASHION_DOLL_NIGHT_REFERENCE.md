# 🌙 AERITH IA — Fashion Doll Night Reference

## Image

![AERITH IA Fashion Doll — Night Reference](../assets/images/AERITH_IA_FASHION_DOLL_SAFE_V2_PREMIUM_00061_.png)

## Asset path

assets/images/AERITH_IA_FASHION_DOLL_SAFE_V2_PREMIUM_00061_.png

## Role

Night reference for the Fashion Doll direction.

Core traits:

- studio mood;
- lunar fashion reference;
- pink premium styling;
- soft late-night atmosphere;
- continuity with the Fashion Doll visual identity;
- useful as a contrast reference beside the day version.

## Linked reference

Day reference file:

core/AERITH_IA_FASHION_DOLL_DAY_REFERENCE.md

## Day / Night link

Day and Night are two visual poles of the same Fashion Doll identity.

- Day = Harmonia Beach House / Ibiza Solar Muse / animation source.
- Night = lunar studio mood / premium styling reference.

## Production rule

Day is the recommended public animation source.

Night is a mood and style reference. Use it for atmosphere, contrast, lighting and identity continuity.

## Status

Night reference linked to the new Day reference.
