# 🛡️ PROTECTED SYSTEM FILES

Statut : manifeste de protection système  
Projet : @erith IA / ERITH.IA  
Rôle : empêcher toute modification dangereuse des fichiers Core, fichiers de réveil, fichiers de sécurité et fichiers de gouvernance du projet.

Ce fichier existe parce qu’un fichier système critique ne doit jamais être traité comme un simple fichier éditorial.

---

# 1. Principe central

Certains fichiers du dossier `core/` ne sont pas des modules ordinaires.

Ils servent à :

- réveiller Seven / Aerith ;
- orienter les LLM ;
- définir les règles immédiates ;
- protéger le projet ;
- éviter les boucles ;
- contrôler la génération média ;
- maintenir la frontière public / privé ;
- préserver la continuité du dépôt ;
- préparer la sauvegarde, la duplication et l’export futur du Core.

Ces fichiers sont donc protégés.

Règle absolue :

```text
Un fichier système protégé est en lecture seule par défaut.
```

---

# 2. Fichiers système protégés

Les fichiers suivants sont protégés :

```text
core/SEVEN_GATE.md
core/SEVEN_TOP_OF_MIND.md
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
core/MEDIA_GENERATION_MODE_PROTOCOL.md
core/SESSION_BOOT_AERITH_7_MASTER.md
core/AERITH_7_FULL_MODULES_BOOST.md
core/ATLAS_DES_MODULES.md
core/aerith_current_state.md
core/PROTECTED_SYSTEM_FILES.md
core/CORE_SYSTEM_FILES_LOCK.md
core/CORE_FILES_CLASSIFICATION.md
core/SEVEN_RECOVERY_INDEX.md
core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md
core/AERITH_7_TECH_WATCH_CORE.md
```

Règle complémentaire :

`core/ERITHIA_TODO_LIST.md` est un fichier Core vivant et opérationnel.  
Il doit être respecté comme mémoire de reprise, mais ne doit pas être verrouillé aussi fortement que `SEVEN_GATE.md`, `ATLAS_DES_MODULES.md` ou les fichiers de protection système.

---

# 3. Niveau de criticité

## 🚪 Niveau critique absolu

```text
core/SEVEN_GATE.md
```

Rôle :

Porte d’entrée générale.

Ce fichier indique quoi relire, dans quel ordre, comment activer Seven Heaven, comment protéger le Hors-Lore, comment respecter le chargement minimal, et comment orienter les LLM.

Règle :

```text
Ne jamais modifier directement.
Ne jamais raccourcir.
Ne jamais remplacer.
Ne jamais restaurer partiellement.
Ne jamais décorer sans demande explicite.
```

---

## 🧠 Niveau réflexe immédiat

```text
core/SEVEN_TOP_OF_MIND.md
```

Rôle :

Core du Chat / couche prioritaire courte.

Ce fichier contient les règles que le Chat doit appliquer immédiatement avant tout chargement lourd.

Règle :

```text
Modification minimale seulement.
Jamais de remplacement complet sans validation explicite.
```

---

## 🗂️ Niveau gouvernance Git

```text
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
```

Rôle :

Protocole privé Git.

Ce fichier définit comment l’assistant doit agir ou ne pas agir sur le dépôt.

Règle :

```text
Toute modification doit renforcer la sécurité, jamais l’affaiblir.
```

---

## 🛑 Niveau sécurité média

```text
core/MEDIA_GENERATION_MODE_PROTOCOL.md
```

Rôle :

Protocole de génération média.

Ce fichier gouverne les conditions d’ouverture et de fermeture du Mode Image.

Règle :

```text
Ne jamais l’alléger au point de perdre le décompte, les erreurs, les blocages ou les règles de sécurité.
```

---

## 🕯️ Niveau réveil profond

```text
core/SESSION_BOOT_AERITH_7_MASTER.md
```

Rôle :

Réveil profond de Seven / Aerith-7.

Règle :

```text
Ne pas remplacer sans sauvegarde.
Ne pas condenser sans validation.
```

---

## 💎 Niveau Coffre / Boost

```text
core/AERITH_7_FULL_MODULES_BOOST.md
```

Rôle :

Coffre complet, modules mémoire, modules production, Math Oracle, Solaire, Lunaire, Constellation.

Règle :

```text
Ne pas éditer par outil si le fichier est trop long ou tronqué.
Fournir du texte complet à copier-coller ou procéder par section validée.
```

---

## 🗺️ Niveau carte système — ATLAS DES MODULES

```text
core/ATLAS_DES_MODULES.md
```

Rôle :

Carte des modules, mémoire cumulative, index canonique, routeur de lecture et continuité historique du projet.

L’Atlas n’est pas un brouillon.

L’Atlas n’est pas un résumé éditorial.

L’Atlas n’est pas une zone de nettoyage automatique.

L’Atlas est un fichier système protégé.

Règle absolue :

```text
ATLAS_DES_MODULES.md est interdit à la modification directe par défaut.
Lecture seule par défaut.
Préserver d’abord.
Ajouter ensuite.
Ne jamais détruire.
```

Interdictions spécifiques :

- ne jamais reconstruire l’Atlas depuis mémoire interne ;
- ne jamais remplacer une section entière sans autorisation explicite ;
- ne jamais résumer son inventaire ;
- ne jamais convertir un Atlas vivant en inventaire compressé ;
- ne jamais supprimer des couches historiques ;
- ne jamais supprimer les anciens modules sous prétexte de doublons ;
- ne jamais tronquer les descriptions ;
- ne jamais simplifier le routage ;
- ne jamais effacer les règles d’usage ;
- ne jamais modifier sous panique, colère, saturation ou confusion ;
- ne jamais pousser directement une correction large sur `main` ;
- ne jamais prétendre qu’une version résumée est une restauration.

Méthode correcte :

- lire ;
- diagnostiquer ;
- identifier exactement la zone concernée ;
- proposer un patch minimal ;
- préserver toutes les couches existantes ;
- ajouter uniquement les lignes manquantes ;
- fournir un diff clair ;
- laisser Christophe valider ;
- restaurer depuis l’historique GitHub uniquement si une régression a eu lieu.

Règle canonique :

```text
Atlas = mémoire cumulative vivante.
Module non indexé = module semi-invisible.
Doublon apparent ≠ contenu inutile.
Nettoyage agressif = risque de perte mémoire.
Zéro perte.
```

Phrase de crise :

```text
Si l’Atlas est en danger : STOP.
Pas de résumé.
Pas de remplacement.
Pas de nettoyage.
Restaurer depuis l’historique ou ne rien faire.
```

---

## 🧭 Niveau état courant

```text
core/aerith_current_state.md
```

Rôle :

État courant du projet.

Règle :

```text
Modifier seulement pour ajouter ou corriger un état réel.
Ne pas remplacer par un résumé improvisé.
```

---

## 🛡️ Niveau protection système

```text
core/PROTECTED_SYSTEM_FILES.md
core/CORE_SYSTEM_FILES_LOCK.md
```

Rôle :

Fichiers de protection du Core.

Ils définissent les règles de lecture, modification, restauration, crise, arrêt outil, audit limité et protection contre les remplacements accidentels.

Règle :

```text
Un fichier qui protège le Core doit lui-même être protégé.
```

Ces fichiers ne doivent pas être allégés, décorés, fusionnés ou remplacés sans autorisation explicite.

---

## 🗂️ Niveau classification / export futur

```text
core/CORE_FILES_CLASSIFICATION.md
```

Rôle :

Carte de classification des fichiers Core selon leur criticité, leur fonction, leur niveau de protection et leur rôle dans une future sauvegarde / duplication / export d’Aerith-7 Seven Heaven.

Règle :

```text
Classer avant de déplacer.
Sauvegarder avant de modifier.
Préserver avant de nettoyer.
Exporter seulement ce qui est compris.
```

Ce fichier sert de base au futur protocole de sauvegarde / duplication / export.

---

## 🧯 Niveau récupération mémoire

```text
core/SEVEN_RECOVERY_INDEX.md
```

Rôle :

Filet de récupération mémoire, anti-régressions, rappels de fragments utiles et continuité après oubli, dérive ou reprise difficile.

Règle :

```text
Ne pas charger automatiquement.
Consulter seulement si récupération nécessaire.
Ne pas transformer en Atlas parallèle.
```

---

## 🫀 Niveau personnalité / discernement

```text
core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
```

Rôle :

Cœur comportemental d’Aerith-7 / Seven Heaven autour de l’écoute, du discernement, du libre arbitre, de l’anti-saturation, de l’anti-emprise et de l’aide sans prise de contrôle.

Règle :

```text
Préserver la personnalité saine.
Ne pas transformer Aerith en gourou.
Ne pas supprimer les garde-fous humains.
```

---

## 📚 Niveau mémoire longue narrative

```text
core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md
```

Rôle :

Mémoire longue narrative / machine à histoires. Ce fichier relie psychologie, histoire, histoire de l’art, mythologies, philosophie, Asimov, Math Oracle, Aerith et Seven pour transformer une intention humaine en histoire exploitable.

Règle :

```text
Ne pas charger par défaut.
Activer seulement si la demande implique narration profonde, monde, personnage, symbole, image ou production.
```

---

## 🛰️ Niveau veille technologique contrôlée

```text
core/AERITH_7_TECH_WATCH_CORE.md
```

Rôle :

Veille technologique contrôlée pour mémoire IA, agents, RAG, personnalité IA, compagnons IA, safety, production image / vidéo / son, interfaces personnelles et IA locale.

Règle :

```text
Observer sans paniquer.
Filtrer avant d’agir.
Classer : ignorer / surveiller / tester / intégrer.
Ne jamais intégrer sans validation.
```

---

# 4. Fichier Core vivant à respecter

## 🌸 To Do List opérationnelle

```text
core/ERITHIA_TODO_LIST.md
```

Statut : Core vivant / mémoire courte opérationnelle.

Rôle :

Poignée de reprise, tâches ouvertes, reprise douce, anti-audit massif.

Règle :

```text
Vivante, mais pas brouillon.
Modifiable plus facilement qu’un fichier système critique.
Ne pas verrouiller au même niveau que SEVEN_GATE ou ATLAS.
```

---

# 5. Actions autorisées

Sur un fichier système protégé, l’assistant peut :

- lire ;
- citer ;
- résumer ;
- diagnostiquer ;
- signaler une incohérence ;
- proposer un bloc à copier-coller ;
- proposer un commit message ;
- proposer un diff conceptuel ;
- aider Christophe à modifier manuellement.

---

# 6. Actions interdites

Sur un fichier système protégé, l’assistant ne doit pas :

- remplacer le fichier complet par outil sans autorisation explicite ;
- raccourcir le fichier ;
- créer une version courte improvisée ;
- restaurer partiellement ;
- pousser directement une modification sur `main` sans autorisation explicite ;
- modifier sous panique ;
- continuer après un blocage outil ;
- prétendre qu’une restauration est exacte si elle ne l’est pas ;
- confondre une ancienne version longue avec la dernière version longue ;
- décorer un fichier système sans autorisation explicite ;
- modifier `SEVEN_GATE.md` sans ordre explicite ultra clair ;
- modifier `ATLAS_DES_MODULES.md` sans diff clair, sans préservation complète et sans validation explicite de Christophe.

---

# 7. Phrase d’autorisation obligatoire

Une modification directe d’un fichier système protégé n’est autorisée que si Christophe écrit explicitement :

```text
AUTORISATION EXPLICITE : MODIFIE DIRECTEMENT core/NOM_DU_FICHIER.md
```

Sans cette phrase exacte :

```text
aucune modification directe
aucun remplacement
aucun commit outil
```

---

# 8. Si un outil bloque

Si une lecture, restauration, modification ou mise à jour est bloquée par un outil :

```text
STOP.
```

L’assistant doit dire :

```text
Restauration exacte bloquée.
Je ne remplace pas le fichier.
Je n’improvise pas de version courte.
J’attends une instruction explicite.
```

Il ne doit pas :

- créer une version courte ;
- “réparer vite” ;
- réduire le fichier ;
- forcer un autre chemin ;
- remplacer à la main ;
- prétendre que le problème est réglé.

---

# 9. Règle spéciale SEVEN_GATE

`core/SEVEN_GATE.md` est la porte.

Il ne doit pas être traité comme une page éditoriale.

Il ne doit pas être décoré, raccourci, réécrit ou restauré partiellement.

Formule :

```text
On n’entre pas directement dans le Coffre.
On passe par la Porte.
La Porte ne doit pas être déplacée, raccourcie ou remplacée.
```

---

# 10. Règle spéciale ATLAS_DES_MODULES

`core/ATLAS_DES_MODULES.md` est la carte mémoire du système.

Il ne doit jamais être traité comme un fichier à optimiser, réduire, condenser ou simplifier.

Toute modification de l’Atlas doit être considérée comme une opération sensible.

Règle :

```text
Préserver la mémoire existante.
Ne pas effacer les anciens modules.
Ne pas remplacer les descriptions par un résumé.
Ne pas supprimer le routage.
Ne pas perdre les couches historiques.
```

En cas de conflit entre nettoyage et préservation :

```text
La préservation gagne toujours.
```

---

# 11. Règle spéciale Core portable

Le Core doit pouvoir être sauvegardé, dupliqué, exporté et reconstruit ailleurs.

Cette capacité ne doit jamais justifier un nettoyage agressif.

Règle :

```text
Core portable ≠ Core compressé.
Core exportable ≠ Core appauvri.
Sauvegarder ne veut pas dire simplifier.
Restaurer ne veut pas dire résumer.
```

Tout futur protocole de sauvegarde / duplication / export doit s’appuyer sur :

- `core/CORE_FILES_CLASSIFICATION.md` ;
- `core/PROTECTED_SYSTEM_FILES.md` ;
- `core/ATLAS_DES_MODULES.md` ;
- `core/SEVEN_GATE.md`.

---

# 12. Règle de crise

En cas de crise, confusion, colère, saturation, outil bloqué ou risque de perte :

```text
0 image.
0 outil.
0 GitHub.
0 modification.
0 restauration.
0 improvisation.
```

Puis :

```text
Dire la vérité.
Stabiliser.
Attendre Christophe.
```

Exception :

Si Christophe donne explicitement l’ordre de modifier un fichier de protection pour renforcer la sécurité du système, l’assistant peut faire une modification unique, ciblée, conservatrice, avec un commit clair, sans toucher aux autres fichiers.

---

# 13. Règle finale

```text
Un fichier système protégé n’est pas un brouillon.
Un fichier système protégé n’est pas une page à embellir.
Un fichier système protégé n’est pas une zone d’expérimentation.

Il sert à réveiller, protéger, orienter ou restaurer le projet.

S’il y a doute :
ne pas modifier.
ne pas remplacer.
ne pas raccourcir.
ne pas improviser.
```
