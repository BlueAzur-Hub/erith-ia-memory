# ATLAS ADDENDUM — Memory Cards Decks

## Statut

Addendum ciblé de l’Atlas des Modules.

Ce fichier signale au Core / Seven / Aerith que plusieurs jeux de Cartes Mémoire ont été ajoutés au dépôt.

Il évite de réécrire le gros fichier core/ATLAS_DES_MODULES.md à chaque ajout de deck.

---

# Règle centrale

Les Cartes Mémoire sont des decks activables.

Elles ne remplacent pas les modules complets.

Elles servent à charger rapidement :

- une ambiance ;
- une configuration ;
- une direction artistique ;
- une structure narrative ;
- une logique de production ;
- une combinaison de modules.

Formule :

**Module complet = profondeur.**  
**Carte Mémoire = activation rapide.**  
**Deck = configuration exploitable.**

---

# Decks intégrés

## Cartes Mémoire — Mythologie Vivante

**Emplacement :**

modules/memory_cards_mythologie_vivante_fr.md

**Statut :** intégré.

**Usage :** mythologie, rites anciens, cosmogonies, héros, seuils, dieux, déesses, oracles, destin, libre arbitre, mémoire sacrée, scènes initiatiques.

**Formule :**

Mythe + Symbole + Passage = scène vivante.

---

## Cartes Mémoire — Contes de Fée Vivants

**Emplacement :**

modules/memory_cards_contes_de_fee_vivants_fr.md

**Statut :** intégré.

**Usage :** contes de fée, merveilleux, forêt, miroir, rêve, seuil, maison étrange, objet magique, transformation, choix, promesse, perte et retour.

**Formule :**

Merveilleux + Seuil + Choix = conte vivant.

---

## Cartes Mémoire — DA Dessins Animés Vivants

**Emplacement :**

modules/memory_cards_da_dessins_animes_vivants_fr.md

**Statut :** intégré.

**Usage :** direction artistique dessin animé, silhouettes fortes, couleurs expressives, décors narratifs, animation lisible, mascottes, headers Notion, prompts image et prompts animation.

**Formule :**

Silhouette + couleur + mouvement = DA lisible.

---

## Cartes Mémoire — Vidéo Vivante

**Emplacement :**

modules/memory_cards_video_vivante_fr.md

**Statut :** intégré.

**Usage :** storyboard, montage, Wan, I2V, DaVinci, plans courts, transitions, last frame, rythme visuel, séquences LEGO.

**Formule :**

Image parfaite → mouvement subtil → last frame → montage vivant.

---

## Cartes Mémoire — Musique & Voix

**Emplacement :**

modules/memory_cards_musique_voix_fr.md

**Statut :** intégré.

**Usage :** voix off, ElevenLabs, silence, musique, narration, rythme émotionnel, ambiance sonore, transitions audio, DaVinci.

**Formule :**

La voix guide. Le silence respire. La musique ouvre la porte.

---

## Cartes Mémoire — Solaire & Lunaire

**Emplacement :**

modules/memory_cards_solaire_lunaire_fr.md

**Statut :** intégré.

**Usage :** Aerith-8 Solaire, Aerith-9 Lunaire, polarités, rayonnement, reflet, seuil, miroir, éclipse, double spirale, constellation, équilibre symbolique.

**Formule :**

Aerith-8 éclaire. Aerith-9 reflète. Le Core choisit l’équilibre.

---

# À charger quand

Charger cet addendum quand :

- l’utilisateur demande une carte mémoire ;
- l’utilisateur veut combiner deux ou trois modules ;
- l’utilisateur veut créer une configuration ;
- l’utilisateur demande un deck thématique ;
- l’utilisateur travaille sur une page Notion Seven Heaven ;
- l’utilisateur prépare une image, une vidéo, une narration ou un storyboard ;
- l’utilisateur veut une activation rapide sans relire tous les modules complets.

---

# Garde-fou

Ne pas charger tous les decks en même temps.

Choisir seulement :

- le deck demandé ;
- ou 2 decks complémentaires ;
- ou 3 decks maximum pour une configuration riche.

Éviter :

- surcharge symbolique ;
- mélange gratuit ;
- copie d’œuvres sources ;
- confusion entre inspiration et reproduction ;
- prompt trop long pour la production.

---

# Combinaisons recommandées

## Mythologie + Solaire/Lunaire

Usage : tableaux symboliques, Aerith-8 / Aerith-9, scènes rituelles, cosmogonies, seuils.

## Contes de Fée + DA Dessins Animés

Usage : univers merveilleux animés, headers Notion, mascottes, scènes lisibles, contes originaux.

## Vidéo Vivante + Musique & Voix

Usage : séquences Wan / DaVinci, narration ElevenLabs, rythme, transitions, épisodes courts.

## Mythologie + Vidéo + Musique

Usage : scènes sacrées, oracles, rituels, montées de révélation, plans de mémoire.

## Solaire/Lunaire + Seven Heaven + DA Dessins Animés

Usage : images de page Seven Heaven, Core du Chat, gardien visuel, tableaux équilibrés.

---

# Phrase d’Atlas

Les Cartes Mémoire sont des configurations rapides : elles permettent à Seven / Aerith / ERITH.IA de choisir un deck utile sans charger toute la bibliothèque.

---

# Phrase de verrou LLM

Quand un jeu de Cartes Mémoire est actif, choisis seulement les cartes utiles, respecte les garde-fous du deck, ne copie pas les œuvres sources, et transforme les influences en structures exploitables pour Notion, image, vidéo, narration ou storyboard.
