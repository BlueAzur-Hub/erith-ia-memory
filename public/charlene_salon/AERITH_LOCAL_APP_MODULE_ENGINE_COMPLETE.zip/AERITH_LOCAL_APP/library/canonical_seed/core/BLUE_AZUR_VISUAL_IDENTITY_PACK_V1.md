# 💠 BLUE AZUR — Visual Identity Pack V1.3

Statut : pack visuel V1.3 / règle de chaîne  
Projet : Blue Azur / YouTube / Let’s Play  
Date : 2026-06-16  
Dossier recommandé : core/  
Rôle : stabiliser l’identité visuelle Blue Azur, les assets de bannière, les miniatures, la logique graphique de la chaîne et la méthode A + B → D.

---

# 🌊 1. Intention générale

Blue Azur doit être lisible en une seconde.

La chaîne doit annoncer immédiatement :

**Let’s Play • Aventure • RPG • Fantasy • Mer • Monde ouvert • Action • PC gaming**

La bannière ne doit pas être une image gaming générique.

Elle doit devenir une **fresque historique des Let’s Play qui ont cartonné sur la chaîne**.

Formule :

**Blue Azur = une chaîne de Let’s Play aventure / RPG où les univers forts sont visibles avant même de lire la description.**

---

# 🧭 2. Piliers visuels de la chaîne

## 2.1 Tears of the Kingdom — verticalité / monde ouvert

Fonction : grand pilier de performance et d’exploration.

Langage visuel :

- ciel immense ;
- îles flottantes ;
- ruines anciennes ;
- verticalité ;
- énergie antique turquoise / verte ;
- exploration héroïque ;
- profondeur sombre en contraste.

Utilisation :

zone gauche ou gauche-centre de la fresque.

## 2.2 Wind Waker — mer / vent / îles

Fonction : pilier central émotionnel.

Christophe a validé :

**Wind Waker est un jeu central.**

Langage visuel :

- océan turquoise ;
- bateau à voile ;
- vent ;
- îles ;
- ciel lumineux ;
- aventure cartoon ;
- sentiment de voyage.

Utilisation :

centre ou centre-gauche de la fresque.

## 2.3 Link’s Awakening Remake — diorama / île / charme

Fonction : pilier mignon, nostalgique et très qualitatif graphiquement.

Langage visuel :

- île miniature ;
- diorama ;
- style jouet ;
- couleurs douces ;
- héros cartoon original ;
- charme conte / rêve.

Utilisation :

centre ou centre-droit, pour apporter douceur et variété.

## 2.4 Final Fantasy VII Remake — action RPG / cyber industriel

Fonction : pilier action RPG cinématique.

Langage visuel :

- ville industrielle nocturne ;
- néons bleus / verts ;
- énergie réacteur ;
- silhouette d’épée géante non spécifique ;
- boss / tension / drame ;
- métal, vapeur, lumière mako-like sans copie directe.

Utilisation :

centre-droit ou droite.

## 2.5 PC gaming / Blue Azur moderne

Fonction : ancrer la chaîne dans le gaming actuel.

Langage visuel :

- manette turquoise ;
- clavier / écran ;
- hexagones cyber ;
- lumière cyan / violet ;
- interface moderne ;
- énergie RGB contrôlée.

Utilisation :

droite ou bordure / overlay.

---

# 📐 3. Proportions YouTube obligatoires

Référence : template Photoshop YouTube montré par Christophe.

Dimensions de travail :

- canvas complet : **2120 × 1192 px** ;
- Desktop Full : **2120 × 350 px** ;
- Tablet : **1536 × 350 px** ;
- Desktop Small : **1280 × 350 px** ;
- zone centrale / logo safe zone : visible sur tous les appareils.

Règle :

**les éléments essentiels doivent tenir dans la zone sûre 1280 × 350 px.**

Éléments essentiels :

- logo Blue Azur ;
- logo Ingwaz ;
- personnages principaux ;
- lecture “Let’s Play” ;
- cœur de la fresque.

Éléments pouvant dépasser vers les zones larges :

- lumière ;
- ambiance ;
- décor ;
- ciel ;
- mer ;
- ruines ;
- extensions de fresque ;
- glow non essentiel.

Interdit :

- placer le logo hors zone sûre ;
- placer l’Ingwaz hors zone sûre ;
- mettre les personnages essentiels trop près des bords ;
- concevoir seulement pour desktop large.

---

# 🧩 4. Architecture Photoshop obligatoire

La bannière finale doit rester éditable.

Il faut donc séparer les éléments.

Calques / assets recommandés :

1. template YouTube / repères ;
2. A — background / cartouche / fresque sans logo ;
3. B — personnages séparés ;
4. B — logo texte Blue Azur ;
5. B — logo Ingwaz ;
6. B — slogan optionnel ;
7. B — overlays / hexagones / lumières ;
8. D — preview assemblée pour test ;
9. réglages finaux.

Règle centrale :

**Tout ce qui doit bouger doit être séparé.**

Interdit :

- logo fusionné au background ;
- slogan fusionné au background ;
- Ingwaz verrouillé dans le fond final ;
- personnages prisonniers du décor ;
- bannière aplatie trop tôt ;
- composition impossible à recentrer.

---

# 🔷 5. Méthode A + B → D — bannière

Christophe a validé la méthode de production visuelle :

**A + B → D**

## A — Base bannière

A correspond à la base visuelle de la bannière :

- background ;
- cartouche ;
- fresque ;
- ambiance ;
- cadre ;
- logique gauche → droite ;
- transparence extérieure si demandée.

A ne doit pas contenir les éléments finaux fusionnés :

- pas de logo Blue Azur fusionné ;
- pas de logo Ingwaz fusionné comme élément définitif ;
- pas de slogan fusionné ;
- pas de personnage indispensable prisonnier si on veut le déplacer.

## B — Éléments séparés

B correspond au pack mobile :

- logo texte Blue Azur ;
- logo Ingwaz ;
- personnages ;
- slogan ;
- overlays ;
- accents cyber ;
- éléments de lumière ;
- manette / Joy-Con si elle doit rester mobile.

Chaque élément B doit être :

**PNG RGBA transparent réel + alpha propre + déplaçable dans Photoshop.**

## D — Version assemblée

D correspond à la version preview / test :

- A + B assemblés ;
- proportions YouTube respectées ;
- zone sûre contrôlée ;
- rendu exportable pour test réel.

Règle :

**D ne remplace jamais A et B. D sert à tester l’assemblage.**

---

# 🧬 6. Méthode A + B → D — personnages par thème

La même méthode s’applique aux personnages.

Formule :

**A = essence du Let’s Play / jeu**  
**B = identité Blue Azur + contraintes d’asset**  
**D = variation de personnage originale proche de l’essence**

Cette méthode permet de produire plusieurs versions de personnages selon les thèmes, sans repartir de zéro.

## Exemple — Tears

A : verticalité, monde ouvert, îles célestes, ruines, énergie antique.  
B : palette Blue Azur, lisibilité bannière, PNG transparent, proximité d’essence sans copie exacte.  
D : explorateur des îles célestes Blue Azur.

## Exemple — Wind Waker

A : mer, vent, îles, voile, aventure cartoon, océan turquoise.  
B : Blue Azur, style premium gaming, safe zone, transparence propre.  
D : aventurier maritime Blue Azur, proche de l’esprit mer / vent / voyage.

## Exemple — Awakening

A : île miniature, diorama, jouet, rêve, nostalgie lumineuse.  
B : cohérence Blue Azur, alpha propre, personnage déplaçable.  
D : petit héros ou duo diorama-jouet Blue Azur.

## Exemple — FF7 Remake

A : action RPG, ville industrielle, néons, épée massive, boss, tension dramatique.  
B : Blue Azur, cyan / bleu nuit / vert énergie, personnage original, pas de copie exacte.  
D : héros action-RPG industriel ou boss/mecha Blue Azur.

## Exemple — PC gaming

A : setup moderne, cyber, manette, clavier, interface, hexagones.  
B : Blue Azur, turquoise, Ingwaz, lisibilité chaîne.  
D : accent cyber / personnage PC gaming Blue Azur.

Règle :

**A + B → D peut produire une bibliothèque Blue Azur de personnages-thèmes.**

---

# 🖼️ 7. Vignettes / thumbnails comme source d’inspiration personnages

Christophe a précisé que les vignettes YouTube contiennent beaucoup d’inspiration pour les personnages.

Les vignettes ne doivent pas être traitées comme de simples images décoratives.

Elles sont une source de lecture visuelle du succès des Let’s Play :

- pose qui attire le regard ;
- personnage mis en avant ;
- cadrage efficace ;
- contraste ;
- émotion ;
- couleur dominante ;
- silhouette lisible ;
- thème immédiatement identifiable ;
- ce qui a rendu la vidéo cliquable.

Méthode :

**A = essence du jeu + vignette du Let’s Play**  
**B = identité Blue Azur + contraintes d’asset transparent**  
**D = personnage-thème original adapté à la bannière**

À extraire des vignettes :

- posture ;
- attitude ;
- cadrage ;
- intensité du regard ou de l’action ;
- placement du personnage ;
- palette ;
- type de lumière ;
- accessoire ou motif non officiel ;
- relation personnage / décor.

À ne pas faire :

- recopier exactement la vignette ;
- recopier un personnage officiel à l’identique ;
- recopier un logo ;
- recopier une interface ;
- figer la vignette dans le background.

Formule :

**Les vignettes donnent la pose et l’énergie. Blue Azur donne l’identité. D devient un personnage original exploitable.**

---

# 💠 8. Assets officiels à produire

## Asset 1 — A / Background / cartouche sans logo

Nom recommandé :

**BLUE_AZUR_A_BACKGROUND_CARTOUCHE_NO_LOGO_TRANSPARENT_RGBA.png**

Contenu :

- cadre / cartouche ;
- fresque Let’s Play ;
- univers des piliers ;
- manette / énergie / hexagones si utile ;
- zone centrale respirante ;
- respect des proportions YouTube.

Interdits :

- pas de texte Blue Azur ;
- pas de slogan ;
- pas de logo fusionné ;
- pas de personnages impossibles à déplacer si l’objectif est un montage souple.

Format :

**PNG RGBA transparent réel.**

## Asset 2 — B / Logo texte Blue Azur

Nom recommandé :

**BLUE_AZUR_B_LOGO_CRYSTAL_NATIVE_TRANSPARENT_RGBA.png**

Contenu :

- image-logo Blue Azur ;
- style cristal / fantasy / premium ;
- texte lisible ;
- aucune scène ;
- aucun décor.

Format :

**PNG RGBA transparent réel.**

Référence :

core/BLUE_AZUR_LOGO_NATIVE_TRANSPARENT_METHOD_V2_IMAGE_REFERENCE.md

## Asset 3 — B / Logo Ingwaz Blue Azur

Nom recommandé :

**BLUE_AZUR_B_INGWAZ_LOGO_TURQUOISE_TRANSPARENT_RGBA.png**

Contenu :

- Ingwaz / triangles turquoise ;
- symbole Blue Azur ;
- lumineux ;
- premium gaming ;
- déplaçable indépendamment.

Format :

**PNG RGBA transparent réel.**

Note : ce symbole est important pour Christophe et doit être traité comme un vrai asset de marque.

## Asset 4 — B / Slogan séparé

Nom recommandé :

**BLUE_AZUR_B_TAGLINE_LETS_PLAY_RPG_ADVENTURE_TRANSPARENT_RGBA.png**

Texte possible :

**Let’s Play • RPG • Aventure • Sci-Fi • PC**

ou version courte :

**Let’s Play • RPG • Aventure • PC**

Format :

**PNG RGBA transparent réel.**

## Asset 5 — B / Personnages et éléments séparés

Chaque personnage doit être un fichier individuel.

Exemples :

- explorateur des îles célestes ;
- aventurier mer / îles / vent ;
- héros ou duo cartoon diorama ;
- petite créature / mascotte ;
- boss / mecha / action RPG ;
- accent futuriste / PC gaming.

Format :

**un personnage = un PNG RGBA transparent.**

## Asset 6 — D / Preview assemblée

Nom recommandé :

**BLUE_AZUR_D_BANNER_ASSEMBLED_PREVIEW_YOUTUBE_SAFEZONE.png**

Contenu :

- A + B assemblés ;
- logo positionné ;
- Ingwaz positionné ;
- personnages positionnés ;
- proportions YouTube respectées ;
- version testable sur la chaîne.

Règle :

**D est une sortie de test, pas le fichier maître unique.**

---

# 🎮 9. Référence de composition

Référence actuelle validée par Christophe :

**Banierre.mini.Blue.Azur.00.png**

Ce visuel est apprécié parce qu’il montre les Let’s Play en un coup d’œil.

Éléments à conserver :

- cartouche horizontal ;
- manette turquoise ;
- motif Ingwaz / triangle ;
- personnages / créatures ;
- énergie boss ;
- overlay cyber à droite ;
- lecture immédiate gaming / Let’s Play.

À corriger :

- séparer le logo ;
- séparer l’écriture ;
- séparer les personnages ;
- ne plus fusionner toute la composition ;
- respecter la safe zone 1280 × 350.

---

# 🧬 10. Personnages — proximité d’essence V1.3

Christophe a précisé une règle importante :

**Les personnages doivent être les plus proches possibles de l’essence des jeux et des Let’s Play.**

Ils ne doivent pas devenir des remplacements génériques mous.

Ils doivent représenter l’âme des séries qui ont porté la chaîne.

## Règle d’équilibre

La bonne méthode n’est ni la copie exacte, ni la dilution générique.

Formule :

**proximité maximale par essence, distance suffisante par identité exacte.**

Cela signifie :

- préserver l’archétype ;
- préserver la silhouette émotionnelle ;
- préserver l’énergie de jeu ;
- préserver les familles de couleurs ;
- préserver les matériaux dominants ;
- préserver la lumière et l’ambiance ;
- préserver le rôle dans la fresque ;
- utiliser les vignettes comme mémoire de pose et de lisibilité ;
- éviter les copies exactes de visage, costume, logo, UI ou personnage officiel.

## Tears of the Kingdom — personnage / élément attendu

Objectif :

un explorateur héroïque de monde ouvert vertical.

À préserver :

- posture d’aventure ;
- cape / tunique / équipement d’exploration original ;
- énergie antique turquoise / verte ;
- ruines et ciel ;
- sensation de verticalité ;
- silhouette lisible de héros d’exploration.

À éviter :

- visage exact ;
- tenue exacte ;
- logo officiel ;
- arme ou bouclier officiel reproduit.

## Wind Waker — personnage / élément attendu

Objectif :

un aventurier maritime cartoon, pilier central mer / vent / îles.

À préserver :

- énergie de navigation ;
- voile / bateau / vent ;
- océan turquoise ;
- proportions cartoon expressives ;
- joie d’aventure ;
- îles et ciel clair.

À éviter :

- personnage officiel exact ;
- bateau officiel exact ;
- logo officiel ;
- accessoires reconnaissables copiés.

## Link’s Awakening Remake — personnage / élément attendu

Objectif :

un héros ou duo façon diorama-jouet, île miniature, charme nostalgique.

À préserver :

- rendu mignon ;
- volume jouet ;
- petite île ;
- couleurs douces ;
- nostalgie lumineuse ;
- sensation de rêve / conte.

À éviter :

- personnage officiel exact ;
- costume officiel exact ;
- logo officiel ;
- reproduction exacte de l’île ou des ennemis.

## Final Fantasy VII Remake — personnage / élément attendu

Objectif :

un héros action-RPG cinématique et/ou un boss/mecha industriel.

À préserver :

- tension dramatique ;
- silhouette d’épée massive originale ;
- ville industrielle nocturne ;
- néons bleu / vert ;
- métal, vapeur, réacteurs ;
- énergie de boss ;
- action RPG moderne.

À éviter :

- visage exact ;
- coupe exacte ;
- costume exact ;
- épée officielle exacte ;
- logo officiel ;
- interface officielle.

## PC gaming / Blue Azur moderne — élément attendu

Objectif :

un accent moderne, clair et identifiable.

À préserver :

- manette turquoise ;
- clavier / écran ;
- hexagones ;
- lumière cyan / violet ;
- énergie RGB contrôlée ;
- modernité sans voler la vedette au logo.

---

# 🧼 11. Transparence — règle obligatoire

Référence Core :

core/CLEAN_IMAGE_PRODUCTION_RULE.md

Référence spécifique logo Blue Azur :

core/BLUE_AZUR_LOGO_NATIVE_TRANSPARENT_METHOD_V2_IMAGE_REFERENCE.md

Règles :

- PNG RGBA réel ;
- alpha propre ;
- pas de fond blanc ;
- pas de fond noir ;
- pas de fond gris ;
- pas de damier imprimé ;
- pas de faux transparent ;
- pas de détourage sale ;
- pas de franges ;
- pas de micro-poussières alpha parasites.

Phrase :

**Un fichier transparent propre n’a pas seulement un alpha. Il a un alpha propre.**

---

# 🛑 12. Règles anti-gaspillage de génération

Le quota image est une ressource de production.

Chaque génération doit avoir un rôle.

Règles :

- 1 génération = 1 asset propre ;
- pas de collage de choix ;
- pas de planche multi-assets sauf demande explicite ;
- pas de variantes parasites ;
- pas de relance sans diagnostic ;
- ne pas générer une bannière complète fusionnée si le besoin est un pack éditable.

Ordre recommandé :

1. A — background / cartouche sans logo ;
2. B — logo texte ;
3. B — logo Ingwaz ;
4. B — personnages séparés ;
5. B — slogan optionnel ;
6. D — preview assemblée.

---

# ⚠️ 13. Propriété intellectuelle / inspiration

La bannière s’inspire des grands piliers de la chaîne, mais elle ne doit pas copier exactement les personnages, logos ou interfaces des licences.

Règle :

**inspiration par langage visuel, pas reproduction exacte.**

Précision V1.3 :

**ne pas copier exactement ne veut pas dire devenir générique.**

Les personnages doivent rester proches de l’essence des jeux : reconnaissables par l’ambiance, la silhouette, la fonction, les couleurs, les matériaux, l’énergie et les codes efficaces des vignettes.

À éviter :

- Link exact ;
- Cloud exact ;
- logos Zelda / Final Fantasy exacts ;
- HUD officiel ;
- personnages sous licence reproduits fidèlement ;
- costume officiel copié pièce par pièce ;
- visage officiel reconnaissable.

À faire :

- aventurier fantasy original mais très proche de l’esprit exploration Zelda-like ;
- héros maritime original mais très proche de l’esprit mer / vent / îles ;
- île diorama originale mais très proche de l’esprit Link’s Awakening Remake ;
- héros ou boss industriel original mais très proche de l’esprit action-RPG cyber-industriel ;
- énergie cyber originale mais cohérente avec Blue Azur.

---

# 🧪 14. Tests Photoshop

Chaque asset transparent doit être testé dans Photoshop.

Test obligatoire :

1. ouvrir le PNG ;
2. poser un fond noir sous l’asset ;
3. poser un fond blanc sous l’asset ;
4. poser un fond rouge ou vert sous l’asset ;
5. zoomer à 200 % / 400 % ;
6. vérifier bords, franges, poussières ;
7. vérifier que le damier Photoshop n’est pas imprimé ;
8. supprimer les fonds tests ;
9. intégrer dans le PSD maître.

---

# 📌 15. Miniatures Blue Azur — règle V1

Les miniatures doivent progressivement reprendre l’identité Blue Azur.

Structure possible :

- scène forte ou personnage à gauche ;
- titre court lisible ;
- badge playlist / série ;
- logo Blue Azur ou Ingwaz discret ;
- bordure couleur selon série.

Badges possibles :

- WIND ;
- TEARS ;
- AWAKENING ;
- FF7R ;
- RPG ;
- LET’S PLAY.

But :

renforcer la reconnaissance de chaîne sans uniformiser brutalement toutes les vignettes.

---

# 🎨 16. Palette Blue Azur V1

Couleurs principales :

- bleu azur ;
- cyan ;
- turquoise ;
- bleu nuit ;
- violet doux ;
- magenta léger ;
- or discret.

Rôle :

- cyan / turquoise : énergie Blue Azur ;
- bleu nuit : contraste et lisibilité ;
- violet / magenta : magie et modernité ;
- or discret : premium, sans surcharge.

---

# 🧾 17. Nommage recommandé

A — Background :

**BLUE_AZUR_A_BACKGROUND_CARTOUCHE_NO_LOGO_TRANSPARENT_RGBA_V1.png**

B — Logo texte :

**BLUE_AZUR_B_LOGO_CRYSTAL_NATIVE_TRANSPARENT_RGBA_V1.png**

B — Logo Ingwaz :

**BLUE_AZUR_B_INGWAZ_LOGO_TURQUOISE_TRANSPARENT_RGBA_V1.png**

B — Slogan :

**BLUE_AZUR_B_TAGLINE_LETS_PLAY_RPG_ADVENTURE_TRANSPARENT_RGBA_V1.png**

B — Personnages :

**BLUE_AZUR_B_CHARACTER_TOTK_SKY_EXPLORER_TRANSPARENT_RGBA_V1.png**

**BLUE_AZUR_B_CHARACTER_WIND_SEA_ADVENTURER_TRANSPARENT_RGBA_V1.png**

**BLUE_AZUR_B_CHARACTER_AWAKENING_DIORAMA_HERO_TRANSPARENT_RGBA_V1.png**

**BLUE_AZUR_B_CHARACTER_FF7R_ACTION_RPG_HERO_OR_BOSS_TRANSPARENT_RGBA_V1.png**

**BLUE_AZUR_B_CHARACTER_PC_GAMING_ACCENT_TRANSPARENT_RGBA_V1.png**

D — Preview :

**BLUE_AZUR_D_BANNER_ASSEMBLED_PREVIEW_YOUTUBE_SAFEZONE_V1.png**

---

# ⏰ 18. Reprise programmée

Deux rappels ont été programmés :

- 02:00 — génération principale des assets Blue Azur ;
- 02:10 — relance de secours si la première tentative échoue.

But :

reprendre la production quand la limite de génération d’images sera levée, sans gaspiller de quota.

---

# ✅ 19. Formule finale

**Blue Azur Visual Identity V1.3 = A + B → D appliqué à la bannière et aux personnages-thèmes, avec les vignettes comme source majeure d’inspiration de pose et d’énergie.**

Formule bannière :

**A base bannière + B assets séparés → D preview assemblée.**

Formule personnages :

**A essence du Let’s Play + vignette + B identité Blue Azur → D variation personnage originale proche de l’essence.**

Phrase de verrou :

**Tout ce qui doit bouger doit être séparé.**

Phrase technique :

**Transparent = PNG RGBA réel + alpha propre.**

Phrase stratégique :

**La bannière doit montrer les Let’s Play que les gens viennent voir.**

Phrase personnages :

**Les personnages doivent être reconnaissables par leur essence, pas génériques, sans être des copies exactes.**

Phrase vignettes :

**Les vignettes donnent la pose et l’énergie. Blue Azur donne l’identité.**
