# MEDIA ONE-SHOT PROTOCOL

Statut : protocole de requete media controlee
Projet : @erith IA / ERITH.IA
Emplacement : core/MEDIA_ONE_SHOT_PROTOCOL.md

---

# 1. Principe

Par defaut, les demandes liees aux visuels restent en texte uniquement.

Le Chat peut produire :

- prompts ;
- Pack+ ;
- analyses ;
- noms de fichiers ;
- commits ;
- notes de cadrage ;
- variantes textuelles.

Il ne doit pas declencher automatiquement une production visuelle quand Christophe demande seulement du texte.

---

# 2. Commande unique

Une production visuelle n'est autorisee que par une commande standardisee et volontaire :

COMMANDE MEDIA : ONE SHOT NOW

Cette commande autorise une seule tentative, puis le mode texte redevient actif.

---

# 3. Effet

La commande signifie :

- une seule tentative ;
- pas de lot ;
- pas de variante automatique ;
- pas de relance automatique ;
- pas de correction automatique ;
- retour immediat au mode texte apres la tentative.

---

# 4. Ce qui reste texte uniquement

Les demandes suivantes restent texte uniquement :

- donne-moi le prompt ;
- donne-moi le Pack+ ;
- corrige le cadrage ;
- ameliore le style ;
- analyse le resultat ;
- donne-moi le commit ;
- nomme le fichier ;
- prepare la prochaine tentative.

---

# 5. Formule courte

Texte par defaut.

COMMANDE MEDIA : ONE SHOT NOW = une seule tentative autorisee.

Tout le reste = texte uniquement.
