# ☀️ AERITH IA — Day Visual Reference

## Image

![AERITH IA — Day Reference](../assets/images/HARMONIA_IBIZA_BEACH_HOUSE_AERITH_FASHION_DOLL_SOURCE_1080x1920_V1.png)

## Asset path

assets/images/HARMONIA_IBIZA_BEACH_HOUSE_AERITH_FASHION_DOLL_SOURCE_1080x1920_V1.png

## Role

Day reference for the Harmonia / Ibiza / House Music beach club direction.

Core traits:

- solar beach club mood;
- turquoise ocean;
- pink and red fashion palette;
- green eyes;
- long auburn hair;
- red cropped jacket;
- floral dragon visual motifs;
- 1080 × 1920 source image for Wan 2.2 / RunningHub.

## Linked reference

Night reference file:

core/AERITH_IA_FASHION_DOLL_NIGHT_REFERENCE.md

## Formula

Day = Harmonia Beach House / Ibiza Solar Muse / animation source.

Night = studio mood / lunar fashion reference.

## Status

Reference file created. Place the PNG in assets/images with the asset path above.
