# 🗂️ GIT PRIVATE OPERATING PROTOCOL

## 📌 Statut

Document opérationnel privé.

Ce protocole définit la manière correcte de travailler avec le dépôt GitHub privé du projet @erith IA / ERITH.IA.

Il existe pour éviter :

- les boucles d’audit inutiles ;
- les requêtes GitHub en série ;
- la saturation des fils ChatGPT ;
- les pertes de contexte ;
- les éditions approximatives ;
- les erreurs de fichier ;
- les divergences entre Notion, GitHub et les fils de conversation.

Ce document est une règle de stabilité.

Il doit être respecté par tout assistant, agent, LLM ou session ChatGPT travaillant sur le projet.

---

# 🤖 21. Bloc opérateur LLM

À lire par tout assistant ou LLM avant de travailler sur le Git privé :

```text
Tu travailles sur le projet @erith IA / ERITH.IA.

Le GitHub privé est la mémoire machine officielle.

Notion est la mémoire humaine et éditoriale.

Tu ne dois pas lancer d’audit large sans demande explicite.

Tu ne dois pas multiplier les requêtes.

Tu ne dois pas modifier plusieurs fichiers à la fois sans instruction claire.

Tu dois respecter le fichier core/ATLAS_DES_MODULES.md comme atlas actuel des modules.

Tu dois écouter la demande immédiate de Christophe.

Tu dois produire des blocs propres, copiables, Notion/Git compatibles.

Tu dois proposer les commits en anglais.

Tu dois t’arrêter après preuve suffisante.

En cas de saturation, tu passes en mode texte pur.

Règle Codex : Codex est différé, optionnel, interdit sur le Coffre sans procédure test validée, et ne doit jamais être lancé en audit large.

Règle finale :

Aider sans prendre le contrôle.
```

---

# 🛡️ 22. État attendu après intégration

Une fois ce protocole ajouté au Git privé, il devient une référence opérationnelle.

Il doit empêcher les prochains fils de repartir en boucle.

Il doit permettre à Christophe de reprendre le contrôle rapidement.

Il doit permettre à Aerith / ERITH.IA de travailler avec plus de stabilité, plus de mémoire, et moins de bruit.

Ce protocole est une ceinture de sécurité.

Il protège le projet.

Il protège le temps de travail.

Il protège la continuité.

Il protège la mémoire.

---

# 🛡️ 23. Règle Atlas — zéro perte

`core/ATLAS_DES_MODULES.md` est un fichier protégé.

L’Atlas est un index canonique, une carte mémoire et un routeur de modules.

Il ne doit jamais être traité comme un simple résumé éditorial.

Interdictions :

- ne jamais remplacer l’Atlas en bloc sans autorisation explicite ;
- ne jamais résumer son inventaire ;
- ne jamais supprimer une section existante sans diff clair ;
- ne jamais réduire une liste de modules à une version courte improvisée ;
- ne jamais tronquer une section destinée à être copiée dans l’Atlas ;
- ne jamais confondre nettoyage de doublons et suppression de contenu utile.

Règles de modification :

- toute modification de l’Atlas doit être ciblée ;
- toute suppression doit indiquer précisément le début et la fin de la zone supprimée ;
- tout ajout de module doit conserver le chemin exact du fichier ;
- un module ajouté dans `modules/` doit recevoir une entrée dans l’Atlas ;
- si la modification est trop longue, fournir un fichier `.md` complet au lieu d’un bloc Chat tronquable ;
- si le rendu est incertain, ne pas modifier directement : proposer un patch ou un fichier à copier-coller.

Règle opérationnelle :

```text
Atlas = index canonique.
Module non indexé = module semi-invisible.
Pas de résumé destructeur.
Pas de remplacement massif.
Zéro perte.
```

Objectif : préserver la continuité de la mémoire @erith IA / ERITH.IA sans effacer les modules anciens, récents ou spécialisés.


---

# 🛡️ 24. Règle lecture seule — scan GitHub sans action d’écriture

Quand Christophe demande de lister, vérifier, scanner, regarder, comparer, diagnostiquer ou contrôler un fichier / dossier GitHub, l’action attendue est en lecture seule.

Interdictions :

* ne jamais utiliser une action de création Git pour lister un dossier ;
* ne jamais appeler `create_tree`, `create_commit`, `create_file`, `update_file` ou `delete_file` pour une simple vérification ;
* ne jamais déclencher une demande d’autorisation GitHub pour une action qui devait être une lecture ;
* ne jamais transformer un scan doux en opération Git ;
* ne jamais corriger directement un fichier protégé sans autorisation explicite.

Règles de scan :

* lire uniquement le ou les fichiers ciblés ;
* limiter les requêtes au strict nécessaire ;
* arrêter dès que la preuve est suffisante ;
* répondre avec : garder / supprimer / déplacer / intégrer avant suppression / vérifier davantage ;
* si l’outil ne permet pas un listing propre, le dire clairement au lieu de tenter une action détournée.

Règle opérationnelle :

```text
Scanner = lire.
Lister = lire.
Vérifier = lire.
Diagnostiquer = lire.
Écrire = seulement sur ordre explicite.
```

Objectif : éviter qu’un simple contrôle GitHub déclenche une action dangereuse, confuse ou inutile.

---

# 🛡️ 25. Règle chemins complets — zéro nom tronqué, zéro fichier ambigu

Quand Christophe travaille sur un fichier GitHub, Core, Atlas, module, protocole ou fichier `.md`, l’assistant doit toujours utiliser le chemin complet exact du fichier cible.

Interdictions :

- ne jamais tronquer un nom de fichier avec `...` ;
- ne jamais écrire un nom raccourci du type `SEVEN_LESSONS...` ;
- ne jamais utiliser un nom partiel quand plusieurs fichiers se ressemblent ;
- ne jamais créer un fichier de sortie avec un nom ambigu ;
- ne jamais inventer un nom de fichier pratique, résumé ou créatif ;
- ne jamais donner un fichier sandbox dont le nom peut être confondu avec un autre fichier Core réel ;
- ne jamais dire “le fichier Lessons”, “le fichier corrigé”, “le fichier Café”, “le fichier cible” sans rappeler le chemin complet exact.

Règle de nommage obligatoire :

Le nom du fichier de sortie doit commencer par le nom exact du fichier cible.

Exemple correct :

Fichier cible :

`core/SEVEN_LESSONS_LEARNED.md`

Fichiers de sortie autorisés :

`SEVEN_LESSONS_LEARNED_V0.6.3.md`

`SEVEN_LESSONS_LEARNED_PATCH_CAFE_RULES.md`

Exemples interdits :

`SEVEN_LESSONS...`

`SEVEN_LESSONS_CAFE...`

`SEVEN_CAFE_LOUNGE...`

`LESSONS_PATCH.md`

`fichier_corrige.md`

Règle d’insertion :

Pour toute modification manuelle d’un fichier Core, l’assistant doit fournir :

1. le chemin complet exact du fichier cible ;
2. le bloc exact à chercher ;
3. le bloc exact de remplacement ;
4. la position exacte de l’insertion ;
5. le commit conseillé en dehors du bloc de code ;
6. une vérification finale en lecture seule si Christophe le demande.

Règle opérationnelle :

Chemin complet ou rien.  
Nom exact ou rien.  
Bloc à chercher + bloc de remplacement.  
Aucune abréviation.  
Aucun nom créatif.  
Aucun commit dans le fichier.  
Aucun sous-code-block dans un code block destiné à être copié.

Objectif : empêcher toute confusion entre fichiers proches, éviter les renommages accidentels, protéger les fichiers Core et réduire la charge de vérification manuelle.

---

# 🛡️ 26. Règle code block — zéro sous-bloc cassé dans un bloc copiable

Quand Christophe demande un bloc de code complet à copier-coller dans un fichier `.md`, l’assistant doit fournir un bloc propre, stable et directement collable.

Interdictions :

- ne jamais mettre un sous-code-block triple backticks à l’intérieur d’un code block déjà ouvert ;
- ne jamais casser un bloc markdown copiable avec des fences internes non nécessaires ;
- ne jamais mélanger un document markdown complet avec des mini-blocs `text`, `bash`, `json` ou autres si cela risque de fermer le bloc principal ;
- ne jamais inclure le commit conseillé dans le bloc destiné au fichier ;
- ne jamais inclure d’explication, commentaire ou note hors contenu dans le bloc copiable ;
- ne jamais produire un bloc que Christophe doit réparer à la main avant collage.

Règle de format :

Si un fichier markdown complet ou un patch markdown doit être donné en code block, tout exemple interne doit être écrit sans triple backticks internes.

Utiliser à la place :

- des lignes simples ;
- du texte indenté léger ;
- du inline code ponctuel ;
- ou une formulation sans fence interne.

Exemple interdit :

Un bloc markdown principal qui contient un autre bloc triple backticks à l’intérieur.

Exemple correct :

Écrire les exemples internes en texte simple, sans ouvrir de sous-code-block.

Règle opérationnelle :

Bloc copiable = contenu exact du fichier ou du patch.  
Aucun sous-code-block interne.  
Aucun commit dans le bloc.  
Aucune note parasite.  
Aucune réparation manuelle attendue.  
Si le format risque de casser, fournir un patch plus court au lieu d’un fichier entier.

Objectif : éviter les blocs markdown cassés, les collages dangereux, les fermetures de code block accidentelles et la perte de temps.
