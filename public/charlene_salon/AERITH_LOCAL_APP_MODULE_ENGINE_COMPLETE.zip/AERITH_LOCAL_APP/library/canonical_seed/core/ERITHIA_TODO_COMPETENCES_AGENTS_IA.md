# 🌸 ERITH.IA — To Do — Compétences Aerith & Agents d’IA

Statut : à faire plus tard  
Type : tâche future / compétence système / module potentiel  
Projet : @erith IA / ERITH.IA / Seven Heaven

---

# 1. Intention

Ajouter progressivement de nouvelles compétences à Aerith / Seven Heaven, au-delà des modules de mémoire culturels et artistiques.

Aerith a déjà commencé à intégrer plusieurs compétences structurantes :

- psychologie ;
- philosophie ;
- discernement ;
- vidéo ;
- musique / voix / silence ;
- codage ;
- GitHub / Notion ;
- narration ;
- production image ;
- production animation ;
- direction artistique ;
- modules mémoire ;
- fonctionnement LLM local / hors-ligne.

La prochaine grande compétence à explorer plus tard :

## Agents d’IA

---

# 2. Sujet futur — Agents d’IA

Créer plus tard un module ou une fiche de compétence sur les agents d’IA.

Nom possible :

`modules/erith_ia_agents_ia_orchestration_fr.md`

Objectif :

Comprendre, structurer et intégrer les principes des agents d’IA dans ERITH.IA / Seven Heaven sans créer un système qui part en roue libre.

---

# 3. Axes à explorer

## Définition

- qu’est-ce qu’un agent IA ;
- différence entre assistant, workflow, agent, auto-agent et orchestrateur ;
- rôle de la mémoire ;
- rôle des outils ;
- rôle du plan ;
- rôle de la validation humaine.

## Architecture agentique

- planner ;
- executor ;
- critic ;
- memory ;
- researcher ;
- tool-user ;
- router ;
- guardrail ;
- orchestrator.

## Agents locaux

- Ollama ;
- AnythingLLM ;
- RAG ;
- fichiers `.md` ;
- GitHub comme mémoire machine ;
- Notion comme mémoire humaine ;
- limites hors-ligne.

## Agents connectés

- usage d’outils ;
- GitHub ;
- navigateur ;
- fichiers ;
- automatisations ;
- risques de boucles ;
- besoin de points d’arrêt.

## Sécurité / garde-fous

- ne pas agir sans permission ;
- ne pas modifier les fichiers protégés ;
- ne pas lancer d’audit massif ;
- ne pas générer d’images sans demande explicite ;
- ne pas continuer après saturation ;
- ne pas remplacer le jugement humain ;
- ne pas créer de système autonome incontrôlé.

---

# 4. Application à Seven Heaven

Seven Heaven pourrait utiliser la logique agentique comme une carte d’organisation, pas comme une autonomie totale.

Formule :

Aerith écoute.  
Seven organise.  
Le module propose.  
L’outil exécute seulement si Christophe autorise.  
La To Do List garde le fil.  
Le point d’arrêt protège le projet.

---

# 5. Règle centrale

Agents d’IA oui.  
Roue libre non.  
Orchestration oui.  
Perte de contrôle non.  
Assistance active oui.  
Décision à la place de Christophe non.

---

# 6. Commit recommandé futur

```text
Add AI agents orchestration module
```

---

# 7. Note de reprise

Quand Christophe voudra reprendre ce sujet, commencer doucement :

1. définir ce qu’est un agent IA ;
2. distinguer assistant / workflow / agent / orchestrateur ;
3. proposer une architecture simple pour Seven Heaven ;
4. créer seulement ensuite le module complet.
