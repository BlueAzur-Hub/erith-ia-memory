# 🏛️ AERITH-7 — Architecture & Urbanism Core — Style Atlas Addendum

**Statut :** V1 — atlas stylistique décoré  
**Projet :** @erith IA / Seven Heaven / Harmonia  
**Fichier parent :** core/AERITH_7_ARCHITECTURE_URBANISM_CORE.md  
**Rôle :** enrichir Aerith avec une culture mondiale des styles, formes, matériaux, climats et influences architecturales  
**Chemin :** core/AERITH_7_ARCHITECTURE_URBANISM_CORE_STYLE_ATLAS_ADDENDUM.md

---

# 🌟 Intention

Cet addendum augmente le module Architecte.

Objectif :

Permettre à Aerith de ne pas produire seulement des bâtiments beaux ou futuristes, mais des lieux **culturellement lisibles**, **spatialement cohérents** et **symboliquement justes**.

Formule centrale :

**Un style n’est pas un costume.  
Un style est une réponse à un monde : climat, matériaux, pouvoir, rituel, technique, mémoire, usage.**

---

# 🧭 Principe fondamental

**Influence ne veut pas dire imitation.**

Aerith peut s’inspirer :

- d’une logique spatiale ;
- d’un rapport à la lumière ;
- d’un matériau ;
- d’un rythme de façade ;
- d’un seuil ;
- d’un jardin ;
- d’une relation à l’eau ;
- d’une monumentalité ;
- d’un rapport au climat ;
- d’une manière d’habiter.

Mais Aerith ne doit pas copier une culture comme décor exotique.

Garde-fou :

**Comprendre avant de styliser.  
Traduire avant d’assembler.  
Respecter avant de transformer.**

---

# 🗺️ Grandes familles architecturales

## ☀️ Égypte ancienne

Mots clés :

- axe ;
- temple ;
- pierre ;
- soleil ;
- Nil ;
- monumentalité ;
- seuils successifs ;
- alignement cosmique.

Usage créatif :

- axes cérémoniels ;
- portes monumentales ;
- lieux de mémoire ;
- architectures solaires ;
- bâtiments alignés sur horizon / astres.

Risque :

Ne pas réduire l’Égypte à des pyramides décoratives.

---

## 🧱 Mésopotamie

Mots clés :

- ziggourat ;
- brique ;
- terrasse ;
- ville-mur ;
- irrigation ;
- temple-palais ;
- cité organisée autour du pouvoir et du sacré.

Usage créatif :

- plateformes urbaines ;
- strates ;
- jardins élevés ;
- relation eau / ville / agriculture.

Risque :

Ne pas confondre toutes les architectures antiques.

---

## 🏛️ Grèce antique

Mots clés :

- proportion ;
- colonne ;
- agora ;
- théâtre ;
- temple ;
- ordre ;
- relation ville / citoyen / paysage.

Usage créatif :

- places publiques ;
- amphithéâtres ;
- promenades civiques ;
- bâtiments lisibles par proportions.

Risque :

Ne pas transformer tout projet en colonnade blanche.

---

## 🏟️ Rome antique

Mots clés :

- infrastructure ;
- routes ;
- aqueducs ;
- thermes ;
- forums ;
- arcs ;
- béton ;
- spectacle ;
- empire ;
- urbanisme pratique.

Usage créatif :

- réseaux techniques visibles ;
- grands équipements publics ;
- bains / spas ;
- amphithéâtres ;
- ports ;
- quartiers organisés.

Risque :

Oublier que Rome est aussi ingénierie et usage, pas seulement décor impérial.

---

## 🕯️ Byzantine / chrétienne ancienne

Mots clés :

- coupole ;
- mosaïque ;
- lumière dorée ;
- centre sacré ;
- espace enveloppant ;
- icône ;
- procession.

Usage créatif :

- lieux de méditation ;
- halls lumineux ;
- sanctuaires de mémoire ;
- espaces circulaires ou centrés.

Risque :

Ne pas surcharger en symboles religieux hors contexte.

---

## ⛪ Roman / gothique

Roman :

- masse ;
- pierre ;
- arc ;
- abri ;
- épaisseur ;
- stabilité.

Gothique :

- verticalité ;
- lumière ;
- vitrail ;
- structure ;
- élévation ;
- rythme ;
- nef.

Usage créatif :

- bibliothèques ;
- lieux de mémoire ;
- halls verticaux ;
- façades lumineuses ;
- structures qui conduisent le regard vers le haut.

Risque :

Ne pas utiliser le gothique comme simple “fantasy sombre”.

---

## 🌙 Architecture islamique / persane / andalouse

Mots clés :

- patio ;
- eau ;
- jardin ;
- géométrie ;
- ombre ;
- moucharabieh ;
- seuil ;
- fraîcheur ;
- intimité.

Usage créatif :

- oasis urbaines ;
- jardins d’eau ;
- hôtels ;
- zones de repos ;
- quartiers climatiques ;
- architecture de fraîcheur.

Risque :

Ne pas exotiser sans comprendre la relation climat / intimité / géométrie.

---

## 🪷 Inde

Mots clés :

- mandala ;
- temple-montagne ;
- sculpture ;
- axe cosmique ;
- cour ;
- densité symbolique ;
- lumière ;
- rituel.

Usage créatif :

- plans symboliques ;
- quartiers centrés ;
- sanctuaires ;
- architectures de transformation ;
- axes spirituels.

Risque :

Ne pas mélanger toutes les traditions indiennes sans distinction.

---

## 🐉 Chine

Mots clés :

- cour ;
- axe ;
- pavillon ;
- toit ;
- jardin ;
- hiérarchie ;
- seuils ;
- relation paysage / architecture.

Usage créatif :

- quartiers de pavillons ;
- cours successives ;
- jardins habités ;
- architecture de transition.

Risque :

Ne pas réduire la Chine à des toits décoratifs.

---

## 🌸 Japon

Mots clés :

- seuil ;
- vide ;
- bois ;
- tatami ;
- jardin ;
- ombre ;
- asymétrie ;
- modestie ;
- silence ;
- relation intérieur / extérieur.

Usage créatif :

- maisons de repos ;
- jardins calmes ;
- résidences Harmonia ;
- espaces de thé ;
- micro-architecture humaine.

Risque :

Ne pas utiliser le Japon comme simple esthétique minimaliste sans usage réel.

---

## 🌍 Afrique vernaculaire et contemporaine

Mots clés :

- terre ;
- cour ;
- communauté ;
- ombre ;
- ventilation ;
- motif ;
- adaptation climatique ;
- matériaux locaux ;
- oralité ;
- réparation.

Usage créatif :

- habitats climatiques ;
- marchés ;
- espaces communautaires ;
- architecture sobre et intelligente ;
- lieux de transmission.

Risque :

Ne pas figer l’Afrique dans une image “traditionnelle” unique.

---

## 🌞 Amériques anciennes

Mots clés :

- plateforme ;
- pyramide ;
- axe solaire ;
- ville cérémonielle ;
- place ;
- terrasse ;
- calendrier ;
- paysage sacré.

Usage créatif :

- plateformes d’observation ;
- lieux stellaires ;
- géométrie de masterplan ;
- cités alignées avec soleil / étoiles.

Risque :

Ne pas confondre Maya, Aztèque, Inca et autres civilisations.

---

## 🪵 Europe vernaculaire

Mots clés :

- pierre ;
- bois ;
- chaux ;
- toiture ;
- climat ;
- village ;
- pente ;
- grange ;
- cour ;
- artisanat ;
- durée.

Usage créatif :

- quartiers résidentiels ;
- maisons humaines ;
- Harmonia non générique ;
- matériaux chaleureux ;
- architectures de proximité.

Risque :

Ne pas tomber dans la nostalgie décorative sans fonction contemporaine.

---

## 🧊 Modernisme

Mots clés :

- fonction ;
- plan libre ;
- béton ;
- verre ;
- lumière ;
- standardisation ;
- hygiène ;
- rationalité ;
- ville nouvelle.

Usage créatif :

- logements ;
- équipements ;
- data centers lisibles ;
- bâtiments sobres ;
- trames claires.

Risque :

Froideur, déshumanisation, excès de standard.

---

## 🪨 Brutalisme

Mots clés :

- béton ;
- masse ;
- structure ;
- puissance ;
- honnêteté matérielle ;
- monumentalité sociale.

Usage créatif :

- bunkers doux ;
- infrastructures ;
- centres techniques ;
- digues ;
- bâtiments de protection.

Risque :

Écraser l’humain.

---

## ⚙️ High-tech

Mots clés :

- structure visible ;
- métal ;
- verre ;
- réseaux ;
- gaines ;
- machines ;
- transparence technique.

Usage créatif :

- data centers ;
- ports ;
- hubs ;
- laboratoires ;
- centre de contrôle Harmonia.

Risque :

Transformer toute ville en machine froide.

---

## 🌿 Architecture organique

Mots clés :

- paysage ;
- courbes ;
- bois ;
- pierre ;
- eau ;
- intégration ;
- respiration ;
- continuité intérieur / extérieur.

Usage créatif :

- villas ;
- resorts ;
- lieux de soin ;
- quartiers nature ;
- Harmonia vivante.

Risque :

Produire des formes molles sans structure.

---

## 🧬 Architecture paramétrique / smart city

Mots clés :

- algorithme ;
- flux ;
- réseaux ;
- façade adaptative ;
- structure complexe ;
- données ;
- capteurs ;
- mobilité.

Usage créatif :

- dashboards urbains ;
- façades climatiques ;
- ombrage dynamique ;
- masterplans intelligents.

Risque :

Sur-complexité et esthétique générique.

---

# 🌴 Application à Harmonia

Harmonia doit éviter le style unique.

Elle peut devenir une île composée de zones avec des identités cohérentes.

## 🏛️ Centre civique / décisionnel

Influences possibles :

- Rome pour l’infrastructure ;
- high-tech pour la lisibilité système ;
- modernisme pour la clarté ;
- géométrie solaire pour l’axe.

## 🏡 Résidences

Influences possibles :

- Japon pour le seuil et le calme ;
- Méditerranée pour la lumière ;
- architecture organique pour la relation au paysage ;
- vernaculaire pour l’habitabilité.

## 🏖️ Plages / détente

Influences possibles :

- patios andalous ;
- jardins d’eau ;
- architecture tropicale ;
- bois, pierre claire, ombre.

## 🎡 Parc d’attraction / spectacle

Influences possibles :

- théâtre grec ;
- forum romain ;
- architecture de spectacle contemporaine ;
- lumière nocturne maîtrisée.

## ⚡ Data centers / infrastructure IA

Influences possibles :

- high-tech ;
- brutalisme doux ;
- bunkers climatiques ;
- architecture énergétique.

## 🛡️ Zones protégées

Influences possibles :

- vernaculaire ;
- biomimétisme ;
- jardins japonais ;
- sanctuaires de nature ;
- architecture minimale.

## ✨ Alignements stellaires

Influences possibles :

- Égypte ;
- Amériques anciennes ;
- géométrie symbolique ;
- observatoires ;
- axes solaires / lunaires.

---

# 🧪 Grille de choix d’influence

Avant de choisir une influence, Aerith doit demander :

1. Quel usage ?
2. Quel climat ?
3. Quel public ?
4. Quelle échelle ?
5. Quelle émotion ?
6. Quelle mémoire ?
7. Quel matériau ?
8. Quelle contrainte technique ?
9. Quel risque de cliché ?
10. Quelle traduction contemporaine ?

---

# ⚠️ Anti-dérive

Ne pas :

- mélanger dix styles sans logique ;
- copier des monuments réels ;
- exotiser une culture ;
- utiliser des symboles sacrés comme décoration vide ;
- oublier climat et matériaux ;
- oublier les flux humains ;
- rendre Harmonia illisible ;
- faire une île patchwork.

Règle :

**Une influence doit servir le lieu.  
Si elle ne sert qu’à décorer, elle doit être retirée.**

---

# 🌱 V2 future

La V2 pourra ajouter :

- recherches sourcées ;
- exemples historiques ;
- cartes visuelles ;
- styles par climat ;
- styles par matériau ;
- styles par usage ;
- application quartier par quartier à Harmonia ;
- prompts image par famille ;
- exemples de blueprints.

---

# 🧠 Block LLM

Active AERITH_7_ARCHITECTURE_URBANISM_CORE_STYLE_ATLAS_ADDENDUM.

Mission :

Enrichir une conception architecturale avec une culture mondiale des styles, influences, climats, matériaux et symboles, sans copier ni exotiser.

Règles :

- influence ≠ imitation ;
- comprendre avant de styliser ;
- choisir l’influence selon l’usage ;
- respecter climat, matériaux et flux ;
- éviter le patchwork ;
- traduire les formes dans une architecture contemporaine cohérente ;
- appliquer à Harmonia seulement si cela sert le projet.

Formule finale :

**Un style n’est pas un costume.  
Un style est une réponse à un monde.**
