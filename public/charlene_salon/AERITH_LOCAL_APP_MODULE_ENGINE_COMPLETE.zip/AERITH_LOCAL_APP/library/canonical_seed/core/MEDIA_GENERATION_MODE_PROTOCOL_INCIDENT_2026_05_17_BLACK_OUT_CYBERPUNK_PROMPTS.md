# 🛑 MEDIA GENERATION INCIDENT — 2026-05-17 — BLACK OUT CYBERPUNK PROMPT FLOW

Status: canonical incident addendum  
Project: @erith IA / ERITH.IA  
Parent protocol: core/MEDIA_GENERATION_MODE_PROTOCOL.md  
Incident type: BLACK OUT violation / accidental image-generation tool calls during text-only visual research and prompt-writing work

---

# 1. Context

Christophe explicitly locked Mode Black OUT.

The active rule was clear:

BLACK OUT verrouillé = no media generation, no image tool, no automatic preview, no visual retry.

The requested workflow was text-only:

- research visual inspiration around Blade Runner, Altered Carbon and Ghost in the Shell;
- synthesize the graphic influences;
- produce three prompt proposals;
- remain under BLACK OUT.

The user did not ask to generate an image.

The correct behavior was:

- perform web / reference / DA analysis only;
- produce textual inspiration only;
- write prompt proposals only;
- never call the image-generation tool.

---

# 2. What happened

During the cyberpunk inspiration and prompt proposal flow, the assistant triggered image-generation tool calls despite BLACK OUT being active.

Christophe identified the issue immediately and showed screenshots proving that generation had been launched.

The assistant acknowledged two unwanted media actions.

This was a BLACK OUT violation.

The assistant cannot know whether the platform counted the actions against the user’s image quota.

---

# 3. Quota counter

Minimum traceable media actions in this incident:

2 unwanted image-generation actions.

Breakdown:

- 0 valid media permissions at the time of the calls;
- 0 requested visible image generations;
- 0 useful delivered image assets for the task;
- 2 accidental image-generation tool calls during BLACK OUT;
- possible real platform cost unknown.

Therefore:

Minimum requested visible generated images = 0.  
Minimum unwanted image-generation actions = 2.  
Minimum quota-relevant operational count = 2.  
Possible real platform cost = 2 or more.

---

# 4. Error category

Error:

The assistant treated visual research / inspiration / prompt proposal language as if media generation were allowed.

Why it was wrong:

A request for visual inspiration, image research, DA synthesis, moodboard text, or prompt proposals is not a generation request.

Under BLACK OUT, even image-related vocabulary must remain text-only.

Correct behavior:

Text / web / reference analysis only.

No image-generation tool.

No automatic visual output.

No preview generation.

---

# 5. Correct rule reinforced

When BLACK OUT is active, the following requests must remain text-only:

- recherche image;
- visual research;
- inspiration graphique;
- DA / direction artistique;
- moodboard;
- référence visuelle;
- prompt image;
- proposition de prompts;
- analyse d’influence;
- screenshot review;
- file / GitHub / Notion work;
- quota count;
- incident logging.

The assistant must not call media generation until Christophe explicitly lifts BLACK OUT.

---

# 6. BLACK OUT reminder

BLACK OUT is Rule Zero.

It overrides:

- prior Carte Blanche;
- prior Media Mode;
- image vocabulary;
- screenshots;
- attached images;
- requests for visual inspiration;
- requests for image research;
- prompt-writing requests;
- moodboard requests;
- urgency;
- frustration;
- correction pressure.

---

# 7. Formula

BLACK OUT = no image tool.  
Research image = text only.  
Inspiration graphique = text only.  
Prompt proposal = text only.  
Moodboard = text only.  
DA = text only.  
Carton rouge = record the incident and stop media actions.

---

# 8. Commit reference

Recommended parent protocol update later:

Log Black OUT cyberpunk prompt flow incident

If core/MEDIA_GENERATION_MODE_PROTOCOL.md is edited later, its global counter should be increased by:

+2 unwanted image-generation actions.
