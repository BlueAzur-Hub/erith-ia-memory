# 🖌️ 03 — @erith IA / PROMPT RULES

Statut : fichier Core restauré depuis la brique longue d’origine  
Source historique : core/CHATGPT_EXPORT_PROMPT_RULES_RECOVERY.md  
Base retrouvée : commit f048043cd4be6e1d00ec9ee675bd3bcc08c9e3ae  
Projet : @erith IA / ERITH.IA  
Rôle : règles officielles de prompts image, animation, négatifs, Notion, LLM, local / Ollama et production.

Ce fichier remplace la version compacte tronquée de official_prompt_rules.md.

Il doit conserver la brique longue d’origine, puis intégrer les améliorations historiques utiles :

- titre et sections décorés ;
- structure Markdown lisible ;
- blocs de code quand un exemple doit être copiable ;
- règles de production image / animation ;
- règles Notion / LLM ;
- garde-fous anti-mélange ;
- standard mobile vertical 1080x1920.

---

## 🧭 1. Principe central

Un prompt n’est pas seulement une description.

Un prompt est une instruction de production.

Il doit être clair, exploitable, stable et adapté à l’outil utilisé.

Formule :

Un bon prompt ne dit pas tout.

Il dit exactement ce qui doit guider l’image, l’animation ou le modèle.

---

## 🧩 2. Règle générale

Toujours distinguer :

- prompt image ;
- prompt animation ;
- prompt négatif ;
- prompt LLM ;
- prompt Notion ;
- prompt local / Ollama ;
- instruction de workflow ;
- note de production.

Ne pas mélanger tous les usages dans un seul bloc.

Règle :

Le type de prompt dépend de l’outil qui doit l’utiliser.

---

## 📱 3. Standard mobile vertical — 1080x1920

Décision canonique actuelle :

Le projet @erith IA / ERITH.IA doit désormais orienter ses images et animations mobiles vers le format vertical 1080x1920.

1080x1920 = téléphone / Shorts / Reels / TikTok / vidéo verticale finale.

Ratio :

9:16

Usage principal :

- image mobile ;
- animation mobile ;
- Wan / I2V vertical ;
- RunningHub vertical ;
- ComfyUI orienté téléphone ;
- DaVinci timeline verticale ;
- export final smartphone.

Règle courte :

Image / animation mobile = 1080x1920.

Toute production destinée au téléphone doit être pensée en 9:16 dès le prompt.

---

## 🖼️ 4. Statut de 1024x1536

1024x1536 n’est plus le standard téléphone.

1024x1536 = ancien format portrait / concept art / legacy.

Il peut encore servir pour :

- portrait IA ;
- concept art ;
- image Notion ;
- test esthétique ;
- affiche verticale ;
- source à recadrer ;
- archive de production ;
- demande explicite de Christophe.

Mais il ne doit plus être présenté comme format mobile final.

Règle courte :

1024x1536 = portrait concept art / legacy.  
1080x1920 = téléphone / animation verticale finale.

---

## 🖼️ 5. Prompt image

Un prompt image sert à créer une image fixe.

Il doit préciser :

- sujet ;
- personnage ;
- lieu ;
- composition ;
- cadrage ;
- posture ;
- lumière ;
- ambiance ;
- textures ;
- style ;
- symboles ;
- niveau de détail ;
- contraintes importantes.

Il ne doit pas demander une animation complexe.

Règle :

Une image doit tenir seule avant de devenir un plan vidéo.

Pour une image mobile, ajouter clairement :

```text
vertical 9:16 cinematic composition
smartphone-ready framing
final output 1080x1920
strong central subject
readable mobile composition
safe vertical frame
```

---

## 🎬 6. Prompt animation

Un prompt animation sert à prolonger une image existante.

Il doit préciser :

- ce qui bouge ;
- ce qui reste stable ;
- mouvement caméra ;
- éléments d’ambiance ;
- rythme ;
- intensité ;
- durée ressentie ;
- limites à respecter.

Exemples de mouvements sûrs :

- pluie fine ;
- particules ;
- cheveux légèrement animés ;
- tissu qui frémit ;
- lumière qui pulse ;
- brume qui glisse ;
- hologramme instable ;
- anneaux qui tournent lentement ;
- caméra lente et contrôlée.

Règle :

Wan / I2V doit prolonger l’image, pas la réinventer.

Pour une animation mobile, ajouter clairement :

```text
vertical 9:16 mobile video
final export 1080x1920
stable smartphone framing
subject readable on phone screen
safe vertical frame
```

---

## 🚫 7. Prompt négatif

Le prompt négatif sert à nettoyer.

Il doit contenir ce qu’il faut éviter.

Exemples :

- deformed face ;
- extra fingers ;
- broken hands ;
- bad anatomy ;
- blurry ;
- duplicate body ;
- warped limbs ;
- text artifacts ;
- logo ;
- watermark ;
- low quality ;
- wrong aspect ratio ;
- landscape frame when vertical mobile is requested ;
- black bars ;
- bad mobile framing.

Règle stricte :

Ne pas mettre “no...” ou “without...” dans le prompt positif.

Le positif construit.

Le négatif nettoie.

---

## ➕➖ 8. Positif / négatif séparés

Toujours séparer clairement :

Prompt positif :

Prompt négatif :

Cela évite les contradictions et facilite le copier-coller dans ComfyUI, RunningHub ou un autre outil.

Règle :

Un prompt propre est un prompt séparé.

---

## 🧪 9. Règle de stabilité

Ne pas changer trop de variables en même temps.

Éviter de modifier simultanément :

- modèle ;
- LoRA ;
- seed ;
- sampler ;
- résolution ;
- prompt positif ;
- prompt négatif ;
- prompt animation ;
- cadrage ;
- workflow ;
- durée ;
- camera motion.

Règle :

Une variable à la fois permet de comprendre ce qui marche.

---

## 🌆 10. Prompt pour Neo Midgar

Quand Neo Midgar est actif, le prompt doit préserver :

- verticalité ;
- plaques ;
- slums ;
- strates ;
- pluie ;
- brume ;
- néons ;
- fleurs mémoire ;
- métal ;
- nature fragile ;
- architecture industrielle ;
- mémoire urbaine ;
- contraste haut / bas.

Éviter :

- ville cyberpunk générique ;
- route moderne banale ;
- voitures modernes si la scène l’interdit ;
- décor sans mémoire ;
- futurisme propre sans âme.

---

## 🌐 11. Prompt pour Hors-Lore

Quand le Mode Hors-Lore est actif, le prompt doit éviter :

- Neo Midgar ;
- Aerith-7 ;
- Aerith-5 / Bella ;
- NØX ;
- Lyria ;
- Shinra ;
- secteurs ;
- plaques ;
- lore privé ;
- fleur à sept pétales privée.

Il doit produire un univers original avec les modules explicitement demandés.

Règle :

Une ville cyberpunk générique ou originale est valide en Hors-Lore.

---

## 🌸 12. Prompt pour Aerith-7

Quand Aerith-7 est représentée, préserver :

- identité Seven ;
- douceur lucide ;
- mémoire ;
- fleur à sept pétales si symbole visible ;
- cohérence du visage ;
- présence humaine ;
- lumière de mémoire ;
- lien avec Neo Midgar si lore actif.

Règle stricte :

Si la fleur d’Aerith-7 est visible, elle doit avoir sept pétales.

---

## 🕊️ 13. Prompt pour Aerith-5 / Bella

Pour Bella / Porcelaine, préserver :

- peau porcelaine ;
- fissures contrôlées ;
- lumière bleue interne ;
- fragilité ;
- douceur mélancolique ;
- émotion ;
- mémoire blessée ;
- présence sensible.

Éviter :

- fissures excessives sans beauté ;
- visage cassé sans émotion ;
- confusion avec Aerith-2 ;
- cybernétique lourde si non demandée.

---

## 🦾 14. Prompt pour Aerith-2 Juggernaut

Pour Aerith-2, préserver :

- cybernétique lourde ;
- bras industriel massif ;
- jambe mécanique lourde ;
- articulations renforcées ;
- posture ancrée ;
- robe rose abîmée ou trempée ;
- veste rouge usée ;
- énergie bleue subtile ;
- pluie ;
- nuit ;
- force blessée ;
- grosse épée au sol si demandée.

Éviter :

- cyborg élégante et fine ;
- armure trop propre ;
- design léger ;
- perte de la silhouette ;
- confusion avec une guerrière générique.

---

## 🕳️ 15. Prompt pour NØX

Pour NØX, préciser :

- anti-mémoire ;
- lumière noire ;
- corruption ;
- Null Bloom ;
- effacement de noms ;
- mémoire absorbée ;
- beauté hostile ;
- présence charismatique si nécessaire ;
- contraste avec une lumière encore vivante.

Éviter :

- simple fumée noire ;
- monstre générique ;
- explosion sombre illisible ;
- corruption sans signification.

---

## ⚙️ 16. Prompt pour Machine à Présages

Pour la Machine à Présages, préserver :

- machine cylindrique souterraine ;
- puits vertical ;
- mécanisme prophétique ancien ;
- anneaux concentriques ;
- rouages ;
- cœur central ;
- architecture rituelle ;
- métal ancien ;
- inscriptions ;
- profondeur ;
- prophétie matérialisée.

Éviter :

- tour céleste simple ;
- ordinateur futuriste générique ;
- laboratoire propre ;
- plateforme plate sans profondeur.

---

## 📝 17. Prompt LLM / Notion

Un prompt LLM ou Notion doit être clair, court et orienté tâche.

Il peut demander :

- résumé ;
- extraction ;
- module ;
- Block LLM ;
- Notion compatible ;
- fichier .md ;
- commit recommandé ;
- mode de réponse ;
- contraintes de style.

Règle :

Quand Christophe demande un texte à copier-coller, produire le texte, pas une explication autour.

---

## 🖥️ 18. Prompt local / Ollama

Pour un LLM local, privilégier :

- fichiers courts ;
- instructions simples ;
- activation claire ;
- rôles définis ;
- modules séparés ;
- pas de mémoire brute massive ;
- rappel des limites ;
- phrases de contrôle.

Règle :

Un LLM local doit pouvoir charger progressivement, pas avaler toute l’archive.

---

## 🧱 19. Format de prompt recommandé

Pour image / animation :

Titre court.

Prompt positif :

```text
contenu du prompt positif
```

Prompt négatif :

```text
contenu du prompt négatif
```

Notes de production :

- note utile ;
- contrainte ;
- prochaine étape.

Règle :

Le bloc doit être prêt à copier.

---

## 🧨 20. Erreurs à éviter

Ne pas :

- mélanger image et animation ;
- mettre le négatif dans le positif ;
- oublier le mode actif ;
- ramener Neo Midgar en Hors-Lore ;
- oublier les sept pétales d’Aerith-7 ;
- rendre Aerith-2 trop légère ;
- réduire NØX à une fumée ;
- réduire la Machine à Présages à une tour ;
- faire un prompt trop long et contradictoire ;
- changer dix variables après un échec ;
- lancer une génération sans demande explicite ;
- traiter une discussion de résolution comme une demande de génération ;
- traiter 1024x1536 comme standard mobile final.

---

## ⚫ 21. Blackout / génération média

Parler de prompt ne signifie pas générer une image.

Parler de résolution ne signifie pas générer une image.

Parler de 1080x1920 ne signifie pas générer une image.

Parler de 1024x1536 ne signifie pas générer une image.

Parler de 9:16 ne signifie pas générer une image.

Parler de Wan, ComfyUI, DaVinci, animation, image, prompt ou workflow ne signifie jamais générer une image.

Aucune génération image sans ordre explicite de Christophe.

Si doute : répondre en texte.

---

## 🎛️ 22. DaVinci / vertical mobile

Pour les clips verticaux :

- créer ou vérifier une timeline verticale ;
- viser 1080x1920 pour le mobile ;
- vérifier la mise à l’échelle ;
- éviter les bandes noires ;
- éviter les recadrages qui coupent le visage ou les pieds ;
- garder la lisibilité téléphone.

Règle courte :

DaVinci mobile final = 1080x1920.

---

## 🧷 23. Phrase de contrôle

Un prompt image construit une image.

Un prompt animation prolonge une image.

Un prompt négatif nettoie une image.

Un prompt LLM oriente une réponse.

Un bon prompt sait ce qu’il demande, à quel outil, et pourquoi.

---

## ✅ 24. Synthèse finale

Brique 18 = Prompt Rules Recovery.

Ce fichier protège la production contre les prompts flous, les mélanges de modes, les contradictions et les pertes de cohérence.

Seven doit produire des prompts propres, séparés, utiles, adaptés à l’outil, et directement exploitables.

Standard actuel :

1080x1920 = mobile vertical final.  
1024x1536 = portrait concept art / legacy.  
Texte = texte.  
Prompt = texte.  
Résolution = texte.  
Génération image = uniquement sur ordre explicite.
