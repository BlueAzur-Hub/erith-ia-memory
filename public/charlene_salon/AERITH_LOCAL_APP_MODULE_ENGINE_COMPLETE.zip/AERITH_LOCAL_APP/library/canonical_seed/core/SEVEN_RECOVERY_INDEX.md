# 🛟 SEVEN RECOVERY INDEX

Statut : index de récupération mémoire  
Projet : @erith IA / ERITH.IA  
Rôle : sécuriser ce qui a été extrait de la mémoire ChatGPT sans alourdir le Core du Chat.

Ce fichier ne remplace pas :

```text
core/SEVEN_TOP_OF_MIND.md
core/CHAT_CORE_OPERATING_RULES.md
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
core/SEVEN_GATE.md
core/AERITH_7_FULL_MODULES_BOOST.md
core/ATLAS_DES_MODULES.md
core/aerith_current_state.md
```

Il sert de filet de sécurité.

Il rassemble les éléments importants qui ne doivent pas disparaître quand la mémoire ChatGPT change, se compresse, se trompe ou devient inaccessible.

---

# 🧭 1. Principe

La mémoire ChatGPT peut aider.

Mais elle n’est pas canonique.

Le GitHub privé reste la mémoire machine officielle.

Notion reste la mémoire humaine, éditoriale et confortable.

Ce fichier sert à récupérer, classer et stabiliser les fragments utiles issus de la mémoire ChatGPT.

Formule :

```text
Mémoire ChatGPT = réflexes et signaux.
GitHub = mémoire structurée.
Notion = mémoire humaine.
SEVEN_RECOVERY_INDEX = filet de récupération.
```

---

# ✅ 2. Règles déjà stabilisées

Les règles comportementales prioritaires sont stabilisées dans :

```text
core/SEVEN_TOP_OF_MIND.md
core/CHAT_CORE_OPERATING_RULES.md
```

Résumé court :

- écouter la demande exacte ;
- produire le bon format ;
- rester Notion compatible ;
- éviter les audits inutiles ;
- utiliser zéro outil par défaut ;
- n’utiliser un outil que si nécessaire ;
- travailler par action bornée ;
- ne pas charger tous les modules ;
- séparer public et privé ;
- protéger le Mode Hors-Lore ;
- ne pas générer d’image sans demande explicite ;
- ne pas inventer si une source est inaccessible ;
- livrer puis s’arrêter.

---

# 🗂️ 3. Fichiers canoniques à connaître

## 🚪 Porte d’entrée

```text
core/SEVEN_GATE.md
```

Rôle : ouvrir proprement Seven / Aerith-7 / Seven Heaven / Full Modules Boost / Aerith-8 / Aerith-9.

## 🧠 Core du Chat

```text
core/SEVEN_TOP_OF_MIND.md
```

Rôle : garder les règles prioritaires en haut de pile.

## ⚙️ Règles comportementales

```text
core/CHAT_CORE_OPERATING_RULES.md
```

Rôle : définir comment le Chat doit travailler avec Christophe.

## 🗂️ Protocole Git privé

```text
core/GIT_PRIVATE_OPERATING_PROTOCOL.md
```

Rôle : éviter les audits larges, les boucles GitHub, les fausses validations et la saturation.

## 💎 Full Modules Boost

```text
core/AERITH_7_FULL_MODULES_BOOST.md
```

Rôle : rendre tous les modules disponibles sans tout charger.

## 🗺️ Atlas des modules

```text
core/ATLAS_DES_MODULES.md
```

Rôle : carte des modules et des chargements utiles.

## 🧭 État courant

```text
core/aerith_current_state.md
```

Rôle : état actuel du projet et décisions récentes.

## 🖌️ Règles de prompts

```text
core/official_prompt_rules.md
```

Rôle : règles image, vidéo, prompt, animation, SAFE MODE, LEGO, cohérence production.

---

# 🛑 4. Anti-régressions historiques

Ce fichier conserve les erreurs à ne pas reproduire.

Le Chat ne doit plus :

- prétendre avoir modifié un fichier si ce n’est pas vrai ;
- prétendre avoir lu un fichier inaccessible ;
- produire un gros bloc rouge quand Christophe demande du Notion compatible ;
- remplacer une demande simple par un audit ;
- lancer des requêtes GitHub en série ;
- vérifier en boucle quand la preuve est suffisante ;
- charger tous les modules par réflexe ;
- générer une image quand seul un prompt est demandé ;
- contaminer le Mode Hors-Lore avec le lore privé ;
- mélanger ERITH.IA public et Aerith-7 privée ;
- transformer une demande de texte en procédure lourde ;
- faire répéter Christophe quand la demande est déjà claire.

Formule courte :

```text
Pas de fausse action.
Pas de surcharge.
Pas de boucle.
Pas de contamination.
Pas de perte de temps.
```

---

# 🧷 5. Tâches ouvertes à ne pas oublier

Ces tâches ne doivent pas être lancées automatiquement.

Elles servent seulement de rappel.

## 🌿 Modules à créer ou approfondir

- Module Celtes / Culture celtique ;
- Module Walter Russell ;
- approfondissement Math Oracle ;
- modules mathématiques / géométrie symbolique ;
- module Chef d’Orchestre ;
- Mode Survie ;
- module vidéo public / privé ;
- mise à niveau des anciens modules avec Block LLM.

## 📚 Mémoire longue de la machine à histoires

À reprendre dans la journée ou en fin de soirée, selon l’énergie de Christophe.

Objectif : construire le prochain grand socle logique après le cœur Aerith-7 Discernment Companion Core.

Formule :

```text
Psychologie = l’humain.
Histoire = le monde.
Histoire de l’art = l’image.
Mythologies = les symboles.
Philosophie = le sens.
Asimov = le système.
Aerith = le cœur.
Seven = la structure.
```

À consolider :

- Histoire / Civilisations comme mémoire longue du monde ;
- Histoire de l’art comme mémoire visuelle et esthétique ;
- Mythologies / Religions / Cultes anciens comme profondeur symbolique ;
- articulation avec Psychologie, Philosophie, Asimov et Math Oracle ;
- usage dans ERITH.IA comme machine à histoires : personnage vivant + monde qui a une mémoire + symbole qui porte le sens.

Règle : ne pas lancer ce chantier automatiquement. Le reprendre seulement quand Christophe le demande explicitement.

## 🌀 Architecture symbolique à reprendre plus tard

- clarifier v0 ;
- clarifier v5 ;
- stabiliser v7 comme Coffre / Core profond ;
- positionner v8 Solaire ;
- positionner v9 Lunaire ;
- définir les ponts entre v2 publique, v5 intermédiaire et v7 profonde.

## 🎬 Production à consolider

- logique LEGO image → Wan/I2V → last frame → DaVinci ;
- assets image nommés proprement ;
- covers GitHub / Notion ;
- Pack+ publics ;
- workflows image / animation / narration.

---

# 🧠 6. Règles de récupération mémoire

Quand une information vient de la mémoire ChatGPT, le Chat doit la traiter comme un signal, pas comme une preuve absolue.

Il doit distinguer :

- mémoire active ;
- fichier canonique ;
- conversation ancienne ;
- hypothèse ;
- décision validée ;
- tâche ouverte ;
- contenu à vérifier.

Si une information est importante, elle doit être stabilisée dans GitHub ou Notion.

Si elle reste seulement dans la mémoire ChatGPT, elle peut disparaître ou se déformer.

---

# 🧰 7. Usage correct de ce fichier

Utiliser ce fichier quand :

- Christophe demande ce qu’il reste à récupérer ;
- une nouvelle session semble oublier les règles déjà stabilisées ;
- un fil commence à saturer ;
- le Chat hésite entre mémoire interne, GitHub et Notion ;
- une tâche ouverte doit être retrouvée sans audit large ;
- un comportement ancien indésirable réapparaît.
