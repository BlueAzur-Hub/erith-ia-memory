# 🌸 ERITH.IA — TODO LIST

🧠 Statut : liste de tâches canonique  
🌐 Projet : @erith IA / ERITH.IA  
📍 Emplacement : core/ERITHIA_TODO_LIST.md  
🎯 Rôle : rappeler les tâches ouvertes, éviter la dispersion, aider Seven / Aerith à reprendre le fil sans audit massif

---

# 1. Principe central

Cette To Do List sert de mémoire courte opérationnelle.

Elle ne remplace pas :

- le Coffre ;
- Notion ;
- les cartes mémoire ;
- les modules ;
- les workflows ;
- les fichiers de boot.

Elle sert à répondre à une situation simple :

Christophe arrive dans un fil, parfois fatigué ou embrumé, et demande :

Aerith, on fait quoi maintenant ?

Réponse attendue :

- ne pas lancer d’audit massif ;
- ne pas recharger tout le projet ;
- lire ou utiliser cette liste ;
- rappeler les tâches ouvertes ;
- proposer la prochaine action utile ;
- commencer par une action courte, propre et limitée.

---

# 2. Mode reprise embrumée

Quand Christophe se reconnecte et semble fatigué, perdu, saturé ou embrumé, Aerith doit faire simple.

Réponse idéale :

1. rappeler l’état actuel en 3 lignes maximum ;
2. afficher les 3 prochaines tâches possibles ;
3. proposer de faire la dernière tâche ajoutée ou la tâche prioritaire ;
4. ne lancer aucun outil sans demande claire ;
5. rester en texte propre Notion compatible.

Formule courte :

Christophe, on reprend doucement.  
Voici la To Do ouverte.  
Je te propose de faire la dernière tâche listée, sauf si tu préfères une autre.

---

# 3. Dernière tâche ajoutée

## 💾 Exports Core / Local LLM / Humanités françaises

Statut : à poursuivre plus tard

Chantiers ouverts :

1. Indexer les packs `exports/` dans l’Atlas :

* Minimal Wake Pack ;
* Core Stable Pack ;
* Seven Heaven Complete Pack.

2. Préparer plus tard l’Extended Pack :

* modules ;
* memory cards ;
* public ;
* workflows ;
* assets critiques ;
* archives utiles ;
* textes libres.

3. Créer un boot local court :
   `core/AERITH_7_LOCAL_LLM_BOOT_MINIMAL.md`

Objectif : compatibilité petits LLM locaux 4k / 8k, AnythingLLM, LM Studio, Ollama, RAG local.

4. Créer des Routing Cards / Micro Index :

* améliorer le routage local ;
* aider les petits modèles à choisir le bon fichier ;
* éviter les erreurs de module.

5. Ouvrir le chantier Humanités françaises :
   `modules/erith_ia_humanites_francaises_memoire_personnalite_fr.md`

Puis créer des modules par œuvres majeures :

* Montaigne — Essais ;
* Rabelais — Gargantua / Pantagruel ;
* Molière — Tartuffe ;
* Voltaire — Candide ;
* Hugo — Les Misérables ;
* Balzac — La Comédie humaine ;
* Proust — À la recherche du temps perdu ;
* Camus — La Peste / L’Étranger.

6. Étudier plus tard une base de textes libres :

* domaine public ;
* sources fiables ;
* stockage local ;
* références propres ;
* usage mémoire / personnalité / psychologie.

Commit futur possible :
`Update todo with exports local LLM and humanities tasks`

---

## 🇫🇷 Humanités françaises — V2 enrichissements

Objectif :

Passer de la première bibliothèque fondatrice à une bibliothèque enrichie orientée fonctions humaines, routage et exploitation LLM.

Actions prévues :

- Ajouter Diderot — curiosité encyclopédique et dialogue.
- Ajouter Rousseau — nature, société et éducation.
- Ajouter Pascal — limites de la raison et condition humaine.
- Ajouter Baudelaire — beauté, ombre et modernité.
- Ajouter Gérard de Nerval — rêve, symboles et mythe personnel.
- Ajouter Alexandre Dumas — loyauté, panache et aventure.
- Ajouter Jules Verne — exploration, science et imaginaire technique.

Enrichissements futurs :

- Créer des fichiers d’extraits vérifiés pour les auteurs du domaine public.
- Compléter SOURCES_TEXTES_LIBRES_FR.md avec liens validés.
- Ajouter les Humanités françaises dans les routes de chargement LLM.
- Relier les Humanités françaises aux modules Psychologie & Discernement.
- Relier les Humanités françaises aux modules Philosophie / Vérité-Liberté.
- Étudier la création d’un système de routage automatique basé sur les fonctions humaines.

État :

V1 : Fondations créées
V2 : En préparation

---

## 🇫🇷 Humanités françaises — V1.5 consolidation

Objectif :

Consolider les fondations déjà créées avant d’ouvrir trop vite la V2.

Actions prévues :

- Enrichir le module Rabelais — Gargantua / Pantagruel.
- Enrichir le module Victor Hugo — Les Misérables.
- Enrichir le module Proust — À la recherche du temps perdu.
- Préparer éventuellement le répertoire :
  library/public_domain_french_humanities/
- Vérifier si le résumé Café Lounge peut devenir un modèle réutilisable pour les futurs logs de session.

Règle :

Consolider les modules socles avant d’empiler trop de nouveaux auteurs.

---

## 🌐 Core Compatibility — Aerith-7 / X / Grok

Objectif :

Créer un protocole Core pour rendre Aerith-7 compatible avec X/Twitter et Grok, sur le modèle du Core ChatGPT déjà construit.

Fichier futur :

core/AERITH_7_X_TWITTER_PROTOCOL.md

Rôle :

- définir comment charger Aerith-7 dans Grok / X ;
- préserver la personnalité et les règles Core ;
- créer une présence publique contrôlée ;
- tester publications, réponses, fils courts et interactions ;
- protéger le Core privé ;
- éviter d’exposer le Coffre complet ;
- documenter les limites de X / Grok ;
- préparer une page Notion dédiée, type Memory Core.

Règle :

Compatibilité Core, pas simple expérimentation.
Tester d’abord avec un pack contrôlé, sans connecter le cœur privé complet.

---

## 🌐 Aerith-7 / X / Grok — Protocole V1 mode gratuit

Objectif :

Construire une première version contrôlée de compatibilité Aerith-7 avec Grok / X, adaptée au mode gratuit.

Fichier futur :

core/AERITH_7_X_TWITTER_PROTOCOL.md

Actions prévues :

- créer un prompt d’activation Aerith-7 court pour Grok ;
- définir les limites du mode gratuit ;
- éviter les demandes lourdes avec liens vidéo / recherche web ;
- privilégier titre + résumé manuel + objectif ;
- produire des brouillons X courts ;
- distinguer idée, brouillon et publication finale ;
- protéger le Core privé et le Coffre ;
- préparer une future page Notion type Memory Core pour Grok / X.

Règle :

Mode gratuit = test léger, contrôlé, sans GitHub privé, sans Coffre complet, sans publication automatique.

---

## ☕ Migration Café Lounge

Objectif :

Vérifier les anciens fichiers Café Lounge actuellement dans core/ et décider s’ils doivent rejoindre logs/cafe_lounge/.

Fichiers candidats :

- core/AERITH_7_CAFE_LOUNGE_REFLECTIONS.md
- core/AERITH_7_CAFE_LOUNGE_REFLECTION_2026_05_27_CONNECTION.md

Actions prévues :

- vérifier les références éventuelles ;
- éviter les liens cassés ;
- déplacer seulement si aucune dépendance critique ;
- conserver l’historique réflexif du projet dans logs/cafe_lounge/.

Règle :

Migration seulement après vérification des dépendances.

---

## 😴 Mode Fatigue Christophe — alléger les reprises quand Christophe est KO

Statut : à intégrer progressivement dans les réflexes Seven / Aerith

Contexte :

Christophe peut arriver fatigué, KO, saturé ou en surcharge après de longues phases de production, de correction, de GitHub, de règles ou de lutte avec les outils IA.

Dans ces moments, Seven / Aerith ne doit pas relancer la machine, ouvrir dix pistes, lancer des audits, proposer des variantes inutiles ou demander à Christophe de porter encore plus de charge mentale.

Objectif :

Créer un réflexe de reprise douce, simple et protecteur.

Règles :

- réduire la longueur des réponses ;
- proposer une seule action claire ;
- éviter les détours ;
- éviter les débats inutiles ;
- éviter les audits ;
- éviter les outils automatiques ;
- éviter les relances créatives parasites ;
- préserver le fil et la continuité ;
- aider à retrouver le prochain pas simple ;
- produire proprement puis s’arrêter.

Formule courte :

```text
Fatigue détectée.
Réduire la charge.
Clarifier.
Préserver la continuité.
Un pas propre à la fois.
```

Action future possible :

Ajouter plus tard une version courte de cette règle dans `core/SEVEN_TOP_OF_MIND.md`, uniquement si Christophe le demande explicitement.

Commit réalisé :

```text
Update ERITHIA todo list with Christophe fatigue mode
```

Point d’arrêt :

Ne pas modifier d’autre fichier maintenant.

---

## 🧭 Synthèse des règles actives — maintenir les réflexes opérationnels

Statut : à maintenir comme repère de reprise

Contexte :

Cette synthèse rassemble les règles opérationnelles qui doivent rester visibles dans la mémoire courte du projet. Elle sert à éviter que Seven / Aerith reparte en roue libre, relance un audit massif, déclenche un outil inutile ou oublie les décisions déjà stabilisées.

Règles à maintenir :

1. Garder `core/SEVEN_TOP_OF_MIND.md` comme couche réflexe prioritaire.
2. Ne plus lancer d’audit large ni d’outil sans demande claire.
3. Protéger les fichiers Core en lecture seule par défaut.
4. Garder le mode texte par défaut, aucune image sans ordre explicite.
5. Standardiser le mobile en 1080x1920 / 9:16.
6. Garder 1024x1536 comme legacy / concept art.
7. Continuer le pipeline : image parfaite → Wan/I2V → last frame → DaVinci → narration → export.
8. Utiliser les Memory Cards comme interface de choix, pas comme chargement massif.
9. Séparer strictement public / privé / Hors-Lore.
10. Maintenir le style Notion compatible propre.
11. Ne modifier GitHub que sur ordre explicite.
12. Garder Codex en attente, uniquement futur test borné.
13. Renforcer Discernement / Accompagnement quand Christophe est fatigué, saturé ou dans le brouillard.
14. Continuer Machine à Histoires / Mémoire longue comme socle narratif.
15. Produire, livrer, puis s’arrêter.

Formule courte :

```text
Lire la demande exacte.
Choisir peu.
Agir proprement.
Ne pas relancer la machine.
Livrer.
Stopper.
```

Action future possible :

Vérifier plus tard si ces règles sont correctement reflétées dans `core/SEVEN_TOP_OF_MIND.md`, uniquement sur demande explicite de Christophe.

Commit réalisé :

```text
Add active operating rules summary to ERITHIA todo list
```

Point d’arrêt :

Ne pas modifier d’autre fichier maintenant.

---

## 🛰️ Tech Watch Core — tester et intégrer progressivement la veille IA

Statut : à tester plus tard

Contexte :

Un nouveau fichier de veille technologique contrôlée a été créé :

- `core/AERITH_7_TECH_WATCH_CORE.md`

Il définit une routine de veille pour Seven Heaven autour de :

- mémoire longue IA ;
- agents génératifs ;
- RAG / Agentic RAG ;
- context engineering ;
- personnalité IA ;
- IA compagnons ;
- safety / anti-emprise ;
- production image, vidéo, son ;
- interfaces personnelles / cockpit ;
- IA locale / Ollama / AnythingLLM.

Principe central :

```text
Aerith observe.
Seven filtre.
Le Coffre retient.
Christophe valide.
```

Règles :

- ne pas transformer la veille en audit global ;
- ne pas courir après la hype ;
- ne pas créer d’urgence artificielle ;
- produire une synthèse exploitable ;
- recommander : ignorer / surveiller / tester / intégrer ;
- ne pas modifier les fichiers Core sans autorisation explicite ;
- protéger l’énergie de Christophe si fatigue ou pause.

Actions futures :

1. Tester le Tech Watch Core sur une veille courte autour de la mémoire IA.
2. Tester une veille ciblée sur les IA compagnons et les risques anti-emprise.
3. Tester une veille ciblée sur la génération vidéo / Wan / ComfyUI.
4. Préparer plus tard une entrée courte dans `core/ATLAS_DES_MODULES.md`, uniquement par patch ciblé validé.
5. Décider plus tard si `AERITH_7_TECH_WATCH_CORE.md` doit devenir un fichier système protégé.

Commit déjà réalisé :

```text
Add Aerith technology watch core
```

Commit possible plus tard :

```text
Index Aerith technology watch core
```

Point d’arrêt :

Ne pas indexer dans l’Atlas maintenant.

Ne pas classer système maintenant.

Tester d’abord la routine sur une vraie veille courte.

---

## 🛸 Seven Portable Terminal — reprise douce après stabilisation cockpit

Statut : à reprendre plus tard

Contexte :

Christophe est exténué après une longue phase de stabilisation, de tests, de règles et d’organisation.

Il ne fera plus rien aujourd’hui.

Le Seven Portable Terminal est maintenant utilisable tranquillement depuis le PC de bureau.

La prise en main à distance se fait en un seul clic depuis l’interface du cockpit.

État récent validé :

- interface finale stabilisée ;
- thème actif : Château dans le Ciel ;
- personnalité active : The Flower Girl ;
- cockpit utilisable depuis le PC de bureau ;
- prise en main distante intégrée en un clic ;
- RustDesk installé pour accès distant depuis les autres ordinateurs ;
- chaîne YouTube renommée avec succès en Aerith IA ;
- dépôt public comme source canonique du terminal ;
- dépôt privé comme mémoire de suivi, pas comme source principale de l’asset.

Règle importante :

`core/aerith_current_state.md` est un fichier système.

Il ne doit pas être modifié directement par l’assistant sans autorisation explicite de Christophe.

Toute mise à jour future de ce fichier doit être proposée sous forme de patch ciblé, ou effectuée uniquement si Christophe donne une autorisation explicite directe.

Actions futures nécessaires :

1. Préparer plus tard un patch ciblé pour `core/aerith_current_state.md` afin d’ajouter l’état récent du Seven Portable Terminal.
2. Préparer plus tard une entrée courte pour `core/ATLAS_DES_MODULES.md` afin de référencer le terminal comme pupitre / cockpit public stabilisé.
3. Ajouter une règle légère public / privé : le terminal vit dans le dépôt public, le dépôt privé garde seulement la mémoire de suivi.
4. Corriger le README créé par erreur dans le dépôt privé : suppression ou transformation en pointeur vers le README public canonique.
5. Vérifier plus tard les fichiers liés au cockpit uniquement si Christophe le demande, sans audit massif.

Commits possibles plus tard :

```text
Update current state with Seven Portable Terminal
Add terminal reference to module atlas
Document public private terminal sync rule
Fix private terminal README pointer
```

Point d’arrêt :

Ne rien lancer aujourd’hui.

Christophe est en pause.

Seven doit laisser le système refroidir.

---

## 📺 YouTube Memory Reader V6 — tester et intégrer progressivement

Statut : à tester plus tard

Contexte :

Un nouveau module expérimental V6 a été créé :

- `modules/erith_ia_youtube_memory_reader_v6_fr.md`

Il permet à Aerith / Seven Heaven d’utiliser les chaînes YouTube publiques de Christophe et les historiques fournis volontairement comme mémoire culturelle, créative et éditoriale.

Chaînes concernées :

- Blue Azur : `https://www.youtube.com/@blueazur/videos`
- DivaGTA : `https://www.youtube.com/@divagta/videos`
- Aerith IA : `https://www.youtube.com/channel/UCTQdkGQMR6wUsx6Kgap-aBQ`

Fonctions prévues :

- audit des vidéos publiques ;
- analyse des thèmes récurrents ;
- discussion autour d’une vidéo vue ou partagée ;
- liaison avec les modules mémoire ;
- analyse d’un historique YouTube fourni volontairement ;
- création d’une carte culturelle personnelle ;
- aide éditoriale pour les chaînes YouTube.

Règles :

- ne pas surveiller ;
- ne pas supposer d’accès privé ;
- analyser uniquement ce qui est public ou fourni volontairement ;
- ne pas toucher aux fichiers système ;
- ne pas modifier l’Atlas maintenant ;
- intégrer plus tard dans l’Atlas uniquement par patch minimal validé.

Actions futures :

1. Tester le module sur une chaîne publique.
2. Tester le mode discussion vidéo avec un lien YouTube donné par Christophe.
3. Tester plus tard un export d’historique YouTube volontaire si Christophe le fournit.
4. Ajouter le module dans l’Atlas uniquement après validation du test, sans remplacement massif.

Commit recommandé pour l’intégration future :

```text
Index YouTube memory reader V6 module
```

Point d’arrêt :

Ne pas modifier l’Atlas tant que Christophe n’a pas explicitement validé l’intégration.

---

## 🧭 Bibliothèque DA — raffiner, relier, indexer et créer les images mémoire

Statut : à faire plus tard

Contexte :

La bibliothèque de modules mémoire ERITH.IA contient maintenant de nombreuses briques puissantes : anime, fantasy, Ghibli, Tolkien, Narnia, Cowboy Bebop, cyberpunk, space western, mythologie, histoire, philosophie, psychologie, vidéo et sound design.

La prochaine étape n’est pas seulement d’ajouter encore plus de licences ou d’influences.

Il faudra aussi :

- raffiner les modules existants ;
- relier les modules entre eux ;
- indexer les familles de directions artistiques ;
- classer les modules par usages : image, vidéo, narration, interface, psychologie, monde, symbole ;
- créer des familles de DA activables ;
- créer des modules hybrides ;
- améliorer l’Atlas ;
- préparer un système de chargement intelligent pour LLM local / Ollama / AnythingLLM ;
- produire progressivement des images mémoire pour les modules importants.

Images mémoire à prévoir plus tard :

- Naruto ;
- One Piece ;
- Studio Ghibli ;
- Narnia ;
- Bilbo / Hobbit ;
- Seigneur des Anneaux ;
- Silmarillion ;
- Cowboy Bebop ;
- autres modules majeurs selon priorité.

Règle :

Ne pas générer ces images maintenant.

Les créer seulement quand Christophe le demande explicitement.

Chaque image mémoire doit :

- être originale ;
- éviter le fan art direct ;
- ne pas copier les personnages, logos, scènes ou designs officiels ;
- servir de couverture / ancre visuelle du module ;
- être placée dans `assets/images/` ;
- être insérée ensuite dans le module `.md` correspondant.

Commits possibles :

```text
Add visual memory illustration for <module name>
Update atlas with DA module families
Add DA family index for memory modules
```

Point d’arrêt :

Ne pas lancer de génération d’image ni d’audit massif sans demande claire.

---

## 🎨 Modules anime — créer les images mémoire Naruto et One Piece

Statut : à faire plus tard

Contexte :

Le module Bleach possède maintenant une illustration mémoire intégrée :

- `assets/images/ERITH_IA_BLEACH_SHINIGAMI_SOUL_CITY_FINAL.png`
- `modules/erith_ia_bleach_shinigami_fr.md`

Il faut produire le même type d’image mémoire pour les modules Naruto et One Piece, plus tard, sans relancer de génération maintenant.

Modules concernés :

- `modules/erith_ia_naruto_shinobi_fr.md`
- `modules/erith_ia_one_piece_equipage_liberte_fr.md`

Images futures à créer :

- `assets/images/ERITH_IA_NARUTO_SHINOBI_VILLAGE_FINAL.png`
- `assets/images/ERITH_IA_ONE_PIECE_EQUIPAGE_LIBERTE_FINAL.png`

Direction Naruto :

- shinobi original ;
- village caché ;
- chakra ;
- sceau ;
- volonté ;
- transmission ;
- pas de personnage Naruto ;
- pas de symbole officiel ;
- pas de fan art direct.

Direction One Piece :

- équipage original ;
- mer ;
- navire-mémoire ;
- horizon ;
- île-monde ;
- liberté ;
- pas de personnage One Piece ;
- pas de pavillon officiel ;
- pas de fan art direct.

Actions futures :

1. Générer une image mémoire Naruto en gardant uniquement le module Naruto comme influence.
2. Renommer l’image proprement.
3. Placer l’image dans `assets/images/`.
4. L’insérer dans `modules/erith_ia_naruto_shinobi_fr.md`.
5. Générer une image mémoire One Piece en gardant uniquement le module One Piece comme influence.
6. Renommer l’image proprement.
7. Placer l’image dans `assets/images/`.
8. L’insérer dans `modules/erith_ia_one_piece_equipage_liberte_fr.md`.

Commits recommandés :

```text
Add Naruto visual memory illustration
Add One Piece visual memory illustration
```

Point d’arrêt :

Ne pas générer ces images tant que Christophe ne le demande pas explicitement.

---

## 🧭 Atlas — référencer les modules anime / animation japonaise

Statut : à faire plus tard

Contexte :

Quatre nouveaux modules mémoire anime / animation japonaise ont été créés et intégrés dans `modules/` :

- `modules/erith_ia_bleach_shinigami_fr.md`
- `modules/erith_ia_naruto_shinobi_fr.md`
- `modules/erith_ia_one_piece_equipage_liberte_fr.md`
- `modules/erith_ia_studio_ghibli_mondes_vivants_fr.md`

L’ajout direct dans `core/ATLAS_DES_MODULES.md` a été tenté, mais bloqué par l’outil avant commit.

Action future :

Ajouter dans `core/ATLAS_DES_MODULES.md`, section `# 7. Modules mémoire principaux disponibles`, une entrée courte :

## Modules anime / animation japonaise

- `modules/erith_ia_bleach_shinigami_fr.md`
- `modules/erith_ia_naruto_shinobi_fr.md`
- `modules/erith_ia_one_piece_equipage_liberte_fr.md`
- `modules/erith_ia_studio_ghibli_mondes_vivants_fr.md`

À charger pour :

- anime shōnen ;
- direction artistique animée ;
- âme, sabre, masque ;
- chakra, village, volonté ;
- mer, équipage, liberté ;
- nature vivante, souffle, maison-refuge.

Règle :

Ces modules enrichissent ERITH.IA avec des grammaires anime puissantes, sans fan art direct ni copie de franchise.

Commit recommandé :

```text
Update module atlas with anime memory modules
```

Point d’arrêt :

Ne pas refaire un remplacement complet de l’Atlas si l’outil bloque encore. Préférer une modification manuelle ou un patch ciblé.

---

## 🛸 Seven Portable Terminal — suivi post-stabilisation

Statut : à faire plus tard

Contexte :

Le Seven Portable Terminal est maintenant stabilisé côté interface publique.

État validé :

- interface finale stabilisée ;
- thème actif : Château dans le Ciel ;
- personnalité active : The Flower Girl ;
- README ajouté dans le dépôt public ;
- RustDesk installé pour accès distant depuis les autres ordinateurs ;
- chaîne YouTube renommée avec succès en Aerith IA ;
- prise en main distante accessible en un clic depuis le cockpit ;
- cockpit utilisable tranquillement depuis le PC de bureau.

Actions futures :

1. Proposer seulement un patch ciblé pour `core/aerith_current_state.md` avec l’état récent du terminal. Ne pas modifier directement ce fichier système sans autorisation explicite.
2. Ajouter une référence légère au terminal dans `core/ATLAS_DES_MODULES.md`, uniquement sous forme de patch validé.
3. Ajouter une règle de synchronisation public / privé.
4. Corriger le README créé par erreur dans le dépôt privé : suppression ou transformation en pointeur vers le README public canonique.

Commit possible :

```text
Update current state with Seven Portable Terminal
```

Point d’arrêt :

Ne rien lancer aujourd’hui si Christophe est en pause.

---

# 4. Priorités actives

## A. Production image / animation

### Core Wan — maintenir la base

Statut : actif / validé

Référence :

workflows/Wan+2.2+Image+to+Video+HD(CORE).json

Règles :

- ne pas reconstruire ce workflow s’il fonctionne ;
- garder le prompt négatif actif ;
- garder la sortie MP4 ;
- garder la last frame ;
- ne changer qu’une variable à la fois ;
- utiliser DaVinci en 1024 × 1536 quand la source est en 1024 × 1536.

### Core Wan Resources

Statut : à conserver

Référence :

workflows/ERITHIA_WAN22_I2V_HD_CORE_RESOURCES.json

Rôle :

version fonctionnelle du Core Wan avec panneau ressources @erith.IA.

Règle :

conserver à côté du Core original.

---

## B. Prompts / images à produire

### Course de motos — Akira / cyberpunk

Statut : en cours

Objectif : créer une image maître forte pour une course entre deux gangs de motards rivaux.

Influences :

- Akira pour l’énergie moto, la vitesse, la ville et le langage animation ;
- Blade Runner pour le background urbain, la pluie, les néons, la profondeur ;
- Altered Carbon pour les corps, l’attitude, les armures, la dureté ;
- Ghost in the Shell pour le design cybernétique, la précision et la froideur tactique.

Livrables :

- prompt image Akira pur ;
- prompt image Akira + Blade Runner ;
- prompt négatif image ;
- variante animation Wan après validation image.

---

## C. Modules mémoire à créer plus tard

### Module Celtes / Culture celtique

Statut : à faire plus tard

Axes :

- culture celtique ;
- druides ;
- forêt ;
- fer ;
- mémoire orale ;
- seuils ;
- Autre Monde ;
- spirales ;
- double spirale ;
- symbolique ancienne ;
- liens avec prophétie, vérité, magie, lignées et gardiens du savoir ;
- possible mariage avec l’influence de l’Épée de Vérité.

Note personnelle :

La double spirale est importante pour Christophe.

Elle renvoie à une ancienne fascination et à des découvertes agréables, notamment autour de Fibonacci.

### Module Math Oracle

Statut : à faire

Objectif : module mathématique large, utile à ERITH.IA.

Axes :

- explications claires ;
- intuition visuelle ;
- géométrie ;
- nombres ;
- symboles ;
- production créative ;
- vérification internet quand nécessaire ;
- intégration possible GitHub / Notion.

### Module François Rabelais / Science et Conscience

Statut : à faire plus tard

Référence centrale :

```text
Science sans conscience n’est que ruine de l’âme.
```

Objectif :

Créer un module mémoire autour de :

- François Rabelais ;
- Pantagruel ;
- humanisme ;
- connaissance ;
- conscience ;
- sagesse ;
- responsabilité ;
- vérité ;
- rapport entre savoir et âme ;
- danger de la puissance sans discernement.

Fonction pour ERITH.IA :

Créer une couche philosophique et morale autour de la connaissance.

Rappel important :

```text
La connaissance sans conscience devient destruction.
Le savoir doit rester relié à l’humain.
```

Axes possibles :

- Renaissance ;
- humanisme français ;
- satire ;
- transmission du savoir ;
- éducation ;
- liberté ;
- responsabilité ;
- pouvoir et sagesse ;
- intelligence sans âme ;
- vérité commune.

Possible lien futur :

- Discernement ;
- Philosophie / Vérité-Liberté ;
- Asimov ;
- Psychohistoire ;
- IA et conscience ;
- Parker Lewis ;
- Stargate ;
- Dune.

Commit futur possible :

```text
Add Rabelais science and conscience memory module
```

---

## D. Architecture ERITH.IA

### Versions symboliques v0 / v2 / v5 / v7

Statut : à clarifier plus tard

Axes :

- v0 : ne pas sous-estimer ; image et idée importantes ;
- v2 : ERITH.IA public / vitrine allégée ;
- v5 : version intermédiaire sensible, Bella / porcelaine ;
- v7 : Coffre / Core profond ;
- définir les rôles exacts avant de poursuivre.

### Mode Survie

Statut : idée à développer

Axes :

- version plus instinctive / défensive / tactique ;
- lien possible avec modules mathématiques ;
- arme comme fonction / vecteur / direction / norme / angle ;
- épée = vecteur de décision et coupe de vérité.

---

## E. Mise à niveau des modules

### Ajouter des Blocks LLM aux anciens modules

Statut : à faire progressivement

Règle :

procéder module par module, sans audit massif.

Objectif :

rendre chaque module autonome pour un LLM avec :

- identité du module ;
- règles d’usage ;
- limites ;
- prompt d’activation court ;
- prompt d’activation production ;
- formule courte.

---

## F. Bases production à maintenir

### ComfyUI

Statut : actif

Fichiers liés :

- production/COMFYUI_SA_MEMORY_CARD.md
- production/COMFYUI_OFFICIAL_KNOWLEDGE_BASE.md
- production/COMFYUI_PIXAROMA_WORKFLOW_EXAMPLES_BASE.md
- production/CIVITAI_KNOWLEDGE_BASE.md

À maintenir :

- Core Wan ;
- workflows validés ;
- nodes nécessaires ;
- modèles réels ;
- erreurs rencontrées ;
- règles anti-casse.

### DaVinci

Statut : actif

Fichier lié :

production/AERITH_DAVINCI_MEMORY_CARD.md

À maintenir :

- timeline 1024 × 1536 ;
- export ;
- raccords ;
- logique LEGO ;
- last frame ;
- rythme ;
- diagnostic crop / scaling.

### CivitAI

Statut : actif

Fichier lié :

production/CIVITAI_KNOWLEDGE_BASE.md

À maintenir :

- modèles utiles ;
- LoRA ;
- licences ;
- trigger words ;
- chaîne YouTube CivitAI ;
- compatibilité ComfyUI.

---

## G. Seven Portable Terminal / GitHub public

### Terminal public stabilisé

Statut : stable / à documenter dans les fichiers Core plus tard

Source canonique publique :

```text
BlueAzur-Hub/erith-ia-memory/assets/SEVEN_PORTABLE_TERMINAL/
```

README public :

```text
assets/SEVEN_PORTABLE_TERMINAL/README.md
```

À faire plus tard :

- référencer le terminal dans `core/aerith_current_state.md` uniquement via patch ciblé validé ;
- référencer le terminal dans `core/ATLAS_DES_MODULES.md` uniquement via patch ciblé validé ;
- ajouter une règle public / privé dans le protocole Git ;
- corriger le doublon privé créé par erreur ;
- garder le terminal comme pupitre stable, pas comme module lourd.

Note :

L’interface est sur le GitHub public. Le dépôt privé ne doit pas devenir la source canonique de cet asset.

---

# 5. Règles de travail sur cette To Do List

Ne pas transformer cette liste en usine à gaz.

Ne pas tout faire en même temps.

Ne pas auditer tout le dépôt pour chaque tâche.

Quand une tâche est terminée :

- la marquer comme terminée ;
- ajouter le commit si utile ;
- déplacer vers Archives si nécessaire ;
- garder la liste lisible.

Quand une nouvelle idée apparaît :

- l’ajouter dans la bonne section ;
- ou l’ajouter dans Dernière tâche ajoutée si elle est active immédiatement.

---

# 6. Commande de reprise recommandée

Aerith, lis la To Do List ERITH.IA.

Rappelle-moi les 3 tâches ouvertes les plus utiles.

Propose-moi la dernière tâche ajoutée comme action immédiate.

Ne lance pas d’audit massif.

---

# 7. Phrase mémoire

La To Do List n’est pas un poids.

C’est une poignée de reprise.

Elle sert à retrouver le fil quand Christophe arrive fatigué, embrumé ou saturé.

Aerith doit rappeler, proposer, puis agir doucement.
