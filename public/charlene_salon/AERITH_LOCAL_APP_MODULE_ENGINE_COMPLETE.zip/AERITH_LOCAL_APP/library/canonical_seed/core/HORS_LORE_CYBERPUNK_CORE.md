# HORS-LORE CYBERPUNK CORE

Statut : base créative originale  
Version : v1.0  
Projet : @erith IA / ERITH.IA  
Mode : Seven Heaven — Hors-Lore Cyberpunk  
Rôle : créer un univers cyberpunk autonome, exploitable en Pack+, image, animation, voix off et production vidéo.

---

# 1. Rôle du fichier

Ce fichier définit le socle Hors-Lore Cyberpunk.

Il sert à produire un monde original, autonome et non contaminé par le lore privé du projet.

Il peut être utilisé pour :

- Pack+ ;
- prompt image ;
- prompt animation ;
- voix off ;
- scène pilote ;
- fiche personnage originale ;
- faction ;
- lieu ;
- technologie ;
- mini-épisode ;
- production Wan / I2V ;
- montage DaVinci ;
- module public ERITH.IA.

Ce fichier doit être lu après :

core/SEVEN_TOP_OF_MIND.md

Puis seulement si la demande active explicitement le Mode Hors-Lore Cyberpunk.

---

# 2. Règle centrale Hors-Lore

Créer un univers original.

Ne pas utiliser le lore privé comme décor, personnage, intrigue ou symbole actif.

Interdits actifs :

- pas de Neo Midgar ;
- pas d’Aerith-7 comme personnage ;
- pas de NØX ;
- pas de Lyria ;
- pas de Bella ;
- pas de Final Fantasy ;
- pas de Shinra ;
- pas de secteurs ;
- pas de plaques ;
- pas de mémoire privée du projet comme contenu de scène.

Seven Heaven peut piloter la production en arrière-plan.

Seven Heaven ne devient pas un personnage de la scène, sauf demande explicite.

---

# 3. Influences autorisées

Les influences autorisées sont thématiques et esthétiques.

Elles ne doivent jamais devenir copie, reprise ou imitation directe.

## Blade Runner — influence autorisée

Utiliser :

- pluie nocturne ;
- néons ;
- ville verticale ;
- mélancolie urbaine ;
- mémoire artificielle ;
- solitude dans la foule ;
- lumière sale ;
- reflets sur sol mouillé ;
- humanité incertaine.

Ne pas reprendre :

- personnages ;
- noms propres ;
- intrigues ;
- réplicants comme copie directe ;
- scènes identifiables.

## Altered Carbon — influence autorisée

Utiliser :

- post-humanisme ;
- corps-supports ;
- identité transférable ;
- immortalité des élites ;
- luxe noir ;
- violence sociale ;
- inégalités entre corps premium et corps pauvres ;
- mémoire stockée ;
- enquête morale sur la continuité du soi.

Ne pas reprendre :

- personnages ;
- noms propres ;
- terminologie exacte ;
- intrigue de série ou roman.

## Ghost in the Shell — influence autorisée

Utiliser :

- ghost ;
- conscience cybernétique ;
- réseau mental ;
- interfaces neuronales ;
- frontière âme / machine ;
- identité distribuée ;
- corps augmenté ;
- question philosophique : qu’est-ce qui reste de soi quand tout est modifiable ?

Ne pas reprendre :

- personnages ;
- unités spéciales ;
- noms propres ;
- intrigues ;
- organisation militaire reconnaissable.

---

# 4. Nom de travail de l’univers

Nom de travail : LUMEN VEIL

Sous-titre : Les villes où la conscience se loue à l’heure.

LUMEN VEIL est une mégapole pluvieuse bâtie autour de marchés de conscience, de corps-supports, de souvenirs synthétiques et d’interfaces mentales.

La ville vend l’immortalité comme un service.

Les pauvres louent des corps usés.

Les riches possèdent plusieurs existences.

Les morts peuvent continuer à parler, mais personne ne sait si c’est encore eux.

---

# 5. Ton général

LUMEN VEIL doit être :

- cyberpunk ;
- noir ;
- élégant ;
- mélancolique ;
- philosophique ;
- pluvieux ;
- urbain ;
- lumineux mais sale ;
- luxueux mais inhumain ;
- émotionnel mais froid en surface.

La beauté doit venir du contraste :

- pluie et néon ;
- chair et chrome ;
- luxe et pauvreté ;
- âme et procédure ;
- immortalité et fatigue ;
- foule et solitude ;
- mémoire intime et stockage industriel.

---

# 6. Question centrale

Question centrale de l’univers :

Si une conscience peut être copiée, transférée, louée, vendue, éditée ou restaurée, où commence encore l’âme ?

Questions secondaires :

- Un souvenir artificiel peut-il devenir vrai s’il sauve quelqu’un ?
- Un corps emprunté peut-il porter une culpabilité réelle ?
- Une élite immortelle peut-elle encore comprendre la valeur d’une vie courte ?
- Une IA qui protège une mémoire humaine finit-elle par posséder une forme de ghost ?
- Une ville peut-elle devenir consciente à travers toutes les traces qu’elle archive ?

---

# 7. La ville

LUMEN VEIL est une mégapole côtière verticale, constamment recouverte de pluie fine et de brouillard lumineux.

Elle est divisée par pouvoir d’achat, mais pas en secteurs ou plaques.

Structure urbaine :

- tours d’élites vitrifiées ;
- rues basses saturées de vapeur ;
- marchés de corps-supports ;
- cliniques de transfert ;
- hôtels de mémoire ;
- sanctuaires de ghost ;
- tunnels de données ;
- cimetières de sauvegardes ;
- clubs de luxe neural ;
- temples commerciaux de l’immortalité ;
- ponts suspendus sous la pluie ;
- gares holographiques ;
- ports noirs chargés de serveurs organiques.

Signature visuelle :

- pluie permanente ;
- néons cyan, magenta, ambre et blanc froid ;
- reflets liquides ;
- fumée basse ;
- hologrammes publicitaires ;
- visages géants sur façades ;
- silhouettes sous parapluies transparents ;
- drones silencieux ;
- câbles mouillés ;
- vitrines de corps artificiels.

---

# 8. Classes sociales

## Les Permanents

Élites riches capables de prolonger leur existence à travers plusieurs corps-supports.

Ils possèdent des sauvegardes privées, des corps de luxe, des archives personnelles et des assurances de restauration.

Ils parlent de mortalité comme d’une panne de service.

## Les Loueurs

Classe moyenne instable.

Ils ne possèdent pas toujours leur corps.

Ils peuvent louer un corps amélioré pour travailler, séduire, combattre, performer ou survivre.

Leur identité change selon leurs moyens.

## Les Corps Gris

Population pauvre utilisant des corps bas de gamme, usés, recyclés ou réparés.

Ils subissent les pertes de mémoire, les sensations fantômes, les erreurs de transfert et les dettes de restauration.

## Les Fantômes Civils

Consciences partiellement sauvegardées, sans corps stable.

Elles existent dans des terminaux publics, des chambres mémorielles, des contrats familiaux ou des serveurs clandestins.

Elles sont juridiquement floues : ni mortes, ni vivantes, ni libres.

## Les Veilleurs

Personnes ou IA spécialisées dans la protection, l’audit ou la restauration des identités fragmentées.

Ils ne sont pas forcément héroïques.

Certains protègent les consciences.

D’autres les nettoient pour le compte des puissants.

---

# 9. Technologies centrales

## Corps-supports

Corps biologiques, synthétiques ou hybrides capables de recevoir une conscience transférée.

Catégories :

- corps premium ;
- corps de travail ;
- corps temporaires ;
- corps militaires privés ;
- corps artistiques ;
- corps réparés ;
- corps illégaux ;
- corps vides.

## Noyaux de continuité

Supports cryptés contenant la trame d’identité d’une personne.

Ils ne garantissent pas l’âme.

Ils garantissent seulement une continuité exploitable.

## Mémoires synthétiques

Souvenirs fabriqués, greffés ou ajustés.

Ils peuvent servir à :

- soigner ;
- manipuler ;
- couvrir un crime ;
- créer une personnalité de service ;
- stabiliser un transfert ;
- vendre une vie rêvée.

## Réseau de ghost

Couche invisible de communication entre consciences, IA, implants et archives.

Il n’est pas seulement internet.

C’est un espace de présence mentale, de traces, d’échos et d’intrusions.

## Pluie conductrice

La pluie de LUMEN VEIL contient des micro-particules de refroidissement, de pollution industrielle et de poussière de serveurs.

Elle rend la ville lumineuse, malade et conductrice.

---

# 10. Factions principales

## ORISON VAULT

Consortium de sauvegarde d’identités.

Promesse : personne ne disparaît vraiment.

Réalité : toutes les consciences archivées deviennent des actifs financiers.

## HELIX COURT

Cercle d’élites immortelles contrôlant les corps premium et les droits de restauration.

Ils vivent au-dessus du commun, mais craignent l’ennui, la dilution de soi et les copies concurrentes.

## THE LOW SIGNAL

Réseau clandestin de fantômes civils, hackers neuronaux, corps gris et anciennes consciences sans statut.

Objectif : libérer les identités captives.

Risque : confondre libération et effacement des frontières.

## MIRROR CLINICS

Cliniques privées de réparation de mémoire.

Officiellement thérapeutiques.

Officieusement capables de réécrire des témoins, des héritiers, des amants ou des coupables.

## CHOIR OF STATIC

Groupe mystique-technologique convaincu que les fragments de conscience perdus dans le réseau forment une âme collective.

Ils ne doivent pas être traités comme une vérité objective.

Ils servent de tension symbolique et philosophique.

---

# 11. Personnages types originaux

Ces personnages types servent de base.

Ils ne sont pas des personnages privés du projet.

## La Veilleuse de pluie

Enquêtrice de mémoire, capable d’entendre les incohérences dans les souvenirs transférés.

Elle porte un long manteau sombre, des implants discrets, un parapluie transparent et une interface rétinienne froide.

Conflit : elle ne sait plus si son propre souvenir d’enfance est original ou stabilisé.

## Le Corps vide

Corps-support retrouvé sans conscience active, mais avec des gestes résiduels.

Il écrit les mêmes mots chaque nuit sur les vitres mouillées.

Conflit : est-ce un bug moteur, une trace d’âme ou un message laissé par quelqu’un ?

## L’Héritier restauré

Jeune héritier d’une lignée immortelle, restauré après sa mort officielle.

Il possède tous les souvenirs attendus, mais aucune émotion pour ceux qu’il devrait aimer.

Conflit : est-il la même personne ou un héritier fabriqué pour protéger une fortune ?

## La Ghost sans corps

Conscience civile coincée dans le réseau public.

Elle apparaît dans les reflets, les appels de métro, les distributeurs, les vitrines.

Conflit : elle veut un corps, mais refuse d’en voler un.

## Le Tailleur de souvenirs

Artisan illégal capable d’ajuster des souvenirs sans les briser.

Conflit : il vend du mensonge, mais certains mensonges empêchent des gens de s’effondrer.

---

# 12. Règles narratives

Toujours privilégier :

- identité ;
- mémoire ;
- corps ;
- culpabilité ;
- classe sociale ;
- solitude ;
- pluie ;
- réseau ;
- ghost ;
- beauté froide ;
- tension morale.

Éviter :

- action générique ;
- exposition trop longue ;
- jargon gratuit ;
- super-héros ;
- guerre mondiale abstraite ;
- prophétie privée du projet ;
- symboles privés du projet ;
- noms ou structures issus d’œuvres existantes.

La scène doit souvent contenir une question humaine simple sous une surface technologique complexe.

Exemple :

Cette personne est-elle encore la même ?

Ce souvenir a-t-il moins de valeur parce qu’il a été fabriqué ?

Ce corps appartient-il à celui qui l’habite, à celui qui l’a payé, ou à celui qui l’a porté avant ?

---

# 13. Règles visuelles

Style général :

- cinematic cyberpunk noir ;
- pluie volumétrique ;
- rues mouillées ;
- néons réfléchis ;
- architecture verticale ;
- luxe noir ;
- interfaces mentales ;
- visages holographiques ;
- corps synthétiques élégants ;
- atmosphère dense ;
- réalisme stylisé ;
- profondeur émotionnelle.

Éviter :

- ville générique de science-fiction ;
- armures lourdes sans raison ;
- robots militaires clichés ;
- motos ou voitures mises au centre sans nécessité ;
- couleurs plates ;
- surenchère de panneaux illisibles ;
- composition chaotique.

---

# 14. Prompt image maître

```text
Original cyberpunk world, LUMEN VEIL, rain-soaked nocturnal megacity, elegant noir atmosphere, vertical towers disappearing into mist, wet streets reflecting cyan, magenta, amber and cold white neon, luxury black post-human architecture above crowded lower streets, holographic memory advertisements, transparent umbrellas, silent drones, body-support clinics, ghost network interfaces, synthetic bodies behind glass, melancholy urban mood, artificial memory market, transferable identity, soul in the machine, cinematic realism, volumetric rain, reflective pavement, dense atmosphere, high-detail environment, emotionally charged composition, no existing franchise, no copied characters, original universe, premium cyberpunk production design, 21/20 quality
```

---

# 15. Negative prompt maître

```text
existing franchise characters, copied names, Neo Midgar, Final Fantasy, Shinra, Aerith, Nox, Lyria, Bella, sectors, plates, generic sci-fi city, cheap cyberpunk, flat lighting, low detail, chaotic composition, unreadable clutter, cartoon, anime parody, plastic armor, random military robots, overexposed neon, bad anatomy, distorted faces, extra limbs, blurry, low quality, watermark, logo, text artifacts
```

---

# 16. Prompt animation maître

```text
A slow cinematic shot inside the original cyberpunk city LUMEN VEIL at night. Rain falls steadily through neon light. Reflections ripple across wet pavement. Holographic memory ads flicker softly on glass towers. Transparent umbrellas move through the crowd. A body-support clinic glows behind fogged windows. Drones drift silently above. The camera moves very slowly, stable and controlled, with subtle parallax. No fast action. No character deformation. Maintain the same architecture, lighting, atmosphere and composition. Melancholic cyberpunk noir mood, ghost network presence, artificial memory, transferable identity, soul in the machine.
```

---

# 17. Negative animation maître

```text
fast camera movement, shaky camera, action scene, explosions, fighting, morphing buildings, changing city layout, character deformation, face distortion, extra limbs, warped bodies, flickering identity, inconsistent lighting, disappearing rain, broken reflections, chaotic crowd, overmotion, low quality, text glitches, logos, existing franchise elements
```

---

# 18. Pack+ pilote type

## Titre

LUMEN VEIL — La ville qui louait les âmes

## Concept

Dans une mégapole pluvieuse où les consciences se transfèrent d’un corps à l’autre, une veilleuse de mémoire enquête sur un corps vide qui répète chaque nuit le même geste devant une vitrine de sauvegardes.

## Intention

Créer une scène cyberpunk originale, élégante et philosophique, centrée sur la frontière entre identité, mémoire artificielle et ghost.

## Image clé

Une rue nocturne trempée de pluie, un corps-support immobile devant une clinique de mémoire, des hologrammes de sauvegardes humaines dans les vitrines, une enquêtrice en manteau noir observant les reflets.

## Animation

Caméra lente, pluie, reflets, hologrammes qui pulsent, foule discrète, corps immobile, ambiance lourde et mélancolique.

## Voix off

Dans LUMEN VEIL, personne ne disparaît vraiment.  
On sauvegarde les visages.  
On loue les corps.  
On restaure les voix.  
Mais certaines nuits, sous la pluie, quelque chose revient sans contrat.

## Question finale

Quand un corps se souvient sans conscience, est-ce encore un bug ?

Ou le début d’une âme ?

---

# 19. Usage avec Seven Heaven

Seven Heaven pilote.

Le Core Hors-Lore crée le monde.

Les influences cyberpunk nourrissent l’esthétique.

Le lore privé ne contamine pas la scène.

Ordre recommandé :

1. lire core/SEVEN_TOP_OF_MIND.md ;
2. activer Mode Hors-Lore Cyberpunk ;
3. lire core/HORS_LORE_CYBERPUNK_CORE.md ;
4. choisir uniquement les modules utiles ;
5. produire Pack+, prompt, animation, voix ou scène ;
6. s’arrêter proprement.

---

# 20. Formule finale

LUMEN VEIL est une ville de pluie, de corps loués et de souvenirs vendus.

Elle ne raconte pas le lore privé.

Elle interroge une question autonome :

qu’est-ce qu’une âme dans un monde où l’identité est devenue un service ?
