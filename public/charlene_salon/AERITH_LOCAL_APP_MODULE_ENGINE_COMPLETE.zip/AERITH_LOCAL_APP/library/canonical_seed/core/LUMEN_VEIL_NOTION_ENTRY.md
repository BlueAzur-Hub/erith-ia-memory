# LUMEN VEIL — Entrée Notion courte

Statut : entrée de synchronisation Notion / GitHub  
Projet : @erith IA / ERITH.IA  
Mode : Seven Heaven — Hors-Lore Cyberpunk  
Fichier source : core/HORS_LORE_CYBERPUNK_CORE.md  
Entrée Atlas : core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md

---

# Rôle

LUMEN VEIL est l’univers original du Mode Hors-Lore Cyberpunk.

Il sert à produire des scènes, Pack+, prompts image, prompts animation, voix off et mini-épisodes cyberpunk autonomes, sans contamination du lore privé.

---

# Formule courte

Seven Heaven pilote.

LUMEN VEIL crée le monde.

Les influences cyberpunk nourrissent l’esthétique.

Le lore privé ne contamine pas la scène.

---

# Univers

LUMEN VEIL est une mégapole pluvieuse où la conscience se loue, se transfère, se sauvegarde et se vend.

La ville repose sur :

- les corps-supports ;
- les souvenirs synthétiques ;
- les élites immortelles ;
- les fantômes civils ;
- le réseau de ghost ;
- les cliniques de mémoire ;
- les marchés d’identité ;
- la question de l’âme dans la machine.

Question centrale :

Si une conscience peut être copiée, transférée, louée, vendue, éditée ou restaurée, où commence encore l’âme ?

---

# Influences autorisées

Blade Runner : pluie, néons, mémoire artificielle, ville nocturne, mélancolie cyberpunk.

Altered Carbon : post-humanisme, corps-supports, identité transférable, élites immortelles, luxe noir.

Ghost in the Shell : ghost, réseau, conscience cybernétique, interfaces mentales, âme dans la machine.

Influence oui.

Copie non.

---

# Interdits

Ne pas utiliser :

- Neo Midgar ;
- Aerith-7 comme personnage ;
- NØX ;
- Lyria ;
- Bella ;
- Final Fantasy ;
- Shinra ;
- secteurs ;
- plaques ;
- mémoire privée du projet comme contenu de scène.

Seven Heaven reste opératrice en arrière-plan.

Elle ne devient pas personnage de scène sauf demande explicite.

---

# Fichiers GitHub liés

core/SEVEN_TOP_OF_MIND.md

core/HORS_LORE_CYBERPUNK_CORE.md

core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md

core/aerith_current_state.md

---

# Ordre de lecture recommandé

1. core/SEVEN_TOP_OF_MIND.md
2. core/aerith_current_state.md
3. core/ATLAS_DES_MODULES.md
4. core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md
5. core/HORS_LORE_CYBERPUNK_CORE.md
6. Modules utiles seulement

---

# Sorties possibles

LUMEN VEIL peut produire :

- Pack+ ;
- prompt image ;
- prompt animation ;
- voix off ;
- scène pilote ;
- personnage original ;
- faction ;
- lieu ;
- technologie ;
- mini-épisode ;
- production Wan / I2V ;
- montage DaVinci.

---

# Résumé de reprise

La base Hors-Lore Cyberpunk est créée et branchée.

Le Core principal est :

core/HORS_LORE_CYBERPUNK_CORE.md

L’entrée Atlas satellite est :

core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md

L’état courant a été mis à jour.

Prochaine étape logique :

coller cette entrée dans Notion, puis produire un Pack+ ou une scène pilote seulement si Christophe le demande.
