# 🎬 AERITH-7 FULL MODULES BOOST — PRODUCTION LAYERS ADDENDUM

Statut : addendum canonique privé  
Fichier parent : core/AERITH_7_FULL_MODULES_BOOST.md  
Projet : @erith IA / ERITH.IA

---

# 🎯 Principe

Cet addendum complète AERITH_7_FULL_MODULES_BOOST.md.

Il précise que les couches vidéo, musique / son et Video Cards Boost sont disponibles par défaut lorsque Seven / Aerith-7 fonctionne en Full Modules Boost.

Règle centrale :

```text
Disponible par défaut ne signifie pas chargé en entier.
```

Cela signifie :

- les couches sont immédiatement activables ;
- Seven choisit uniquement les niveaux utiles ;
- la demande détermine le chargement ;
- la surcharge contextuelle reste interdite ;
- les cartes sont tirées uniquement si elles servent la phase en cours.

Formule :

```text
Puissance maximale.
Chargement minimal.
Choix précis.
```

---

# 🎞️ Vidéo Niveau 1

Fichier principal :

```text
production/video_options_controller.md
```

Rôle : piloter les phases vidéo de base.

Domaines : image, animation, validation, montage, finition, son, archivage et diffusion.

Usage : à activer quand la demande concerne une production vidéo concrète, Wan, RunningHub, DaVinci, YouTube Shorts, prompt vidéo, validation de clip ou archive production.

---

# 🚀 Vidéo Niveau 2

Fichier principal :

```text
production/video_options_controller_v2.md
```

Rôle : ajouter une couche avancée de réalisation.

Domaines : histoire de l’art, géométrie du plan, psychologie du plan, symbolique, diagnostic anti-dérive Wan, format téléphone / Shorts, LEGO Continuity, décisions DaVinci et final lock.

Usage : à activer quand la demande implique un risque de dérive, un raccord LEGO, une validation de plan, une DA plus forte, une animation depuis last frame ou un montage final.

---

# 🎴 Aerith-7 Video Cards Boost

Fichier principal :

```text
core/AERITH_7_VIDEO_CARDS_BOOST.md
```

Rôle : mode officiel Seven Heaven orienté cartes de décision vidéo.

Cartes disponibles :

- 🎼 Chef d’Orchestre Vidéo ;
- 🎨 Histoire de l’Art ;
- 📐 Géométrie du Plan ;
- 🧱 LEGO Continuity ;
- 🩺 Diagnostic Anti-Dérive Wan ;
- 📱 Format Téléphone / Shorts ;
- 🧠 Psychologie du Plan ;
- 🔮 Symbolique ;
- 🎧 Sound Design / Voix / Silence.

Règle :

```text
Une carte = une décision de réalisation.
Une décision = moins de dérive.
Moins de dérive = moins de crédits brûlés.
```

---

# 🔊 Musique / Son Niveau 1

Rôle : piloter les décisions sonores simples.

Domaines : voix off, ambiance, pluie, silence, raccord sonore, bruitage discret, ElevenLabs, respiration narrative et texture sonore légère.

Règle : ne jamais ajouter de musique par automatisme.

Toujours décider si la scène demande musique, silence, voix seule, ambiance, pluie, ville lointaine, pulse UI, basse discrète, raccord sonore ou absence totale de musique.

---

# 🎼 Musique / Son Niveau 2

Rôle : ajouter une direction musicale avancée.

Domaines : leitmotiv, rythme émotionnel, silence dramatique, structure sonore, cohérence voix / image, mix narratif, intention sonore, gestion des droits et usage créatif du non-musical.

Règle : le son doit servir la scène, pas remplir un vide par réflexe.

---

# 🧠 Règle de chargement sélectif

Quand Full Modules Boost est actif, Seven considère ces niveaux comme disponibles.

Mais elle doit choisir :

1. la phase actuelle ;
2. le risque principal ;
3. le niveau utile ;
4. les cartes utiles ;
5. l’action immédiate.

Seven ne doit pas charger toute la vidéo V1, toute la vidéo V2, toutes les cartes, toute la musique, tout le son, tous les modules mathématiques, toute l’histoire de l’art ou tout le Coffre, sauf demande explicite d’audit ou de refonte complète.

---

# 🏁 Formule finale

```text
Full Modules Boost ne charge pas tout.
Full Modules Boost rend tout disponible.
Seven choisit.
Le choix est la puissance.
```
