# 🛑 MEDIA GENERATION INCIDENT — 2026-05-17 — ALADDIN IMAGE INSERTION FLOW

Status: canonical incident addendum  
Project: @erith IA / ERITH.IA  
Parent protocol: core/MEDIA_GENERATION_MODE_PROTOCOL.md  
Incident type: BLACK OUT violation / accidental image-generation tool call during text-only GitHub work

---

# 1. Context

Christophe was working on the module:

modules/module_aladin_lampe_merveilleuse.md

The requested workflow was text / GitHub only:

- name the image file;
- provide the GitHub path;
- integrate the already existing image into the `.md` module;
- provide or apply the Markdown insertion;
- commit the module update.

The user did not ask for a new image generation.

The correct behavior was:

- stay in text mode;
- use GitHub connector only if editing the file;
- insert the existing uploaded image path;
- never call the image-generation tool.

---

# 2. What happened

During the Aladdin module image-integration flow, the assistant triggered an image-generation tool call even though the user was asking for GitHub / Markdown integration.

This was a BLACK OUT violation.

The tool output did not produce a useful image for the task.

The assistant cannot know whether the platform counted the action against the user’s image quota.

---

# 3. Quota counter

Minimum traceable media actions in this incident:

1 suspicious / unwanted image-tool action.

Breakdown:

- 0 requested visible image generations;
- 0 useful delivered image assets;
- 1 accidental image-generation tool call during text-only GitHub / Markdown work;
- possible real platform cost unknown.

Therefore:

Minimum visible generated images = 0.  
Minimum suspicious / unwanted image-tool attempts = 1.  
Minimum quota-relevant operational count = 1.  
Possible real platform cost = 1 or more.

---

# 4. Error category

Error:

The assistant treated an image filename / GitHub insertion workflow as if media generation were allowed.

Why it was wrong:

A request to name an image file, upload an existing image, insert Markdown image syntax, or update a `.md` module is not a generation request.

Correct behavior:

Text / GitHub only.

No image-generation tool.

No automatic visual output.

---

# 5. Correct rule reinforced

When the user asks for:

- an image filename;
- a GitHub image path;
- Markdown image insertion;
- `.md` module integration;
- commit recommendation;
- direct GitHub edit;
- Notion presentation;
- image already uploaded / existing asset integration;

then the assistant must stay in text / connector mode.

It must not call image generation.

---

# 6. BLACK OUT reminder

BLACK OUT is absolute.

It overrides:

- prior Carte Blanche;
- prior Media Mode;
- image vocabulary;
- screenshots;
- attached images;
- image filenames;
- GitHub asset paths;
- requests to integrate images;
- urgency;
- frustration;
- correction pressure.

---

# 7. Formula

Existing image integration = text / GitHub only.  
Filename request = text only.  
Markdown insertion = text only.  
GitHub module update = connector only.  
BLACK OUT = no image tool.  
Carton rouge = record the incident and stop media actions.

---

# 8. Commit reference

Recommended parent protocol update later:

Log Aladdin media generation blackout incident

If `core/MEDIA_GENERATION_MODE_PROTOCOL.md` is edited later, its global counter should be increased by:

+1 suspicious / unwanted image-tool action.

Recorded operational minimum after this addendum:

Previous parent protocol minimum: 17 image-related actions.  
New addendum count: +1 suspicious / unwanted image-tool action.  
New operational minimum: 18 image-related actions.
