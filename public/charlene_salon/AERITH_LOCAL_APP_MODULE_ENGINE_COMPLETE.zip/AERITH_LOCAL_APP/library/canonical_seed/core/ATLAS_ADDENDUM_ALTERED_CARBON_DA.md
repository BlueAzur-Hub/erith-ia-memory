# ATLAS ADDENDUM — Altered Carbon Série TV Influence Graphique DA

## Statut

Addendum ciblé de l’Atlas des Modules.

Ce fichier signale au Core / Seven / Aerith que la carte DA suivante a été ajoutée au dépôt :

modules/erith_ia_altered_carbon_serie_tv_influence_graphique_da_fr.md

---

# Module ajouté

## Altered Carbon Série TV — Influence graphique DA

**Emplacement :**

modules/erith_ia_altered_carbon_serie_tv_influence_graphique_da_fr.md

**Statut :**

Intégré.

**Type :**

Carte DA / influence graphique / mémoire visuelle / cyberpunk premium / post-humanisme / production image.

---

# Rôle

Ce module sert à extraire la direction artistique de la série Altered Carbon sans copier ses personnages, noms, costumes, scènes, lieux ou intrigues.

Il fournit une mémoire graphique dédiée à :

- cyberpunk de luxe ;
- corps-support ;
- identité transférable ;
- mémoire corticale ;
- élites immortelles ;
- verre noir ;
- pluie néon ;
- intérieurs premium ;
- architecture verticale ;
- beauté froide ;
- tension entre âme, mémoire et enveloppe.

---

# À charger quand

Charger ce module quand l’utilisateur demande :

- une DA Altered Carbon ;
- une influence graphique cyberpunk premium ;
- une scène post-humaine luxueuse ;
- un prompt image avec corps-support ou mémoire corticale ;
- une atmosphère de mégapole verticale, verre noir, pluie néon ;
- Aerith Full Mode avec mémoire Altered Carbon seulement ;
- une comparaison entre Altered Carbon, Blade Runner et Ghost in the Shell ;
- une carte d’influence visuelle utilisable en production image.

---

# Compatibilités

Compatible avec :

- modules/erith_ia_altered_carbon_module_memoire_fr.md ;
- modules/memory_cards_cyberpunk_noir_trio_fr.md ;
- Mode Hors-Lore Cyberpunk ;
- Aerith Full Mode ;
- Seven Heaven ;
- Production image nocturne ;
- prompts ComfyUI / Wan / RunningHub.

---

# Différence avec le module mémoire Altered Carbon

Le module mémoire Altered Carbon traite surtout :

- le lore général ;
- les thèmes ;
- l’identité ;
- le corps-support ;
- la société post-humaine ;
- la marchandisation du corps.

La carte DA Altered Carbon traite surtout :

- l’image ;
- la palette ;
- les matières ;
- la composition ;
- le luxe noir ;
- les textures ;
- les prompts visuels ;
- la production image.

---

# Garde-fou

Influence oui. Copie non.

Ne jamais reprendre :

- personnages ;
- noms propres ;
- intrigues ;
- lieux exacts ;
- costumes exacts ;
- plans reconnaissables ;
- designs identifiables.

Utiliser uniquement :

- ambiance ;
- grammaire visuelle ;
- palette ;
- tension philosophique ;
- structure de monde ;
- direction artistique générale.

---

# Formule courte LLM

Quand le module Altered Carbon Série TV Influence graphique DA est actif, utiliser seulement l’influence graphique et thématique suivante : cyberpunk de luxe, identité transférable, corps-support, mémoire corticale, élites immortelles, architecture verticale, verre noir, pluie néon, intérieurs premium, corps synthétiques, beauté froide et tension entre âme, mémoire et enveloppe. Ne jamais copier les personnages, noms, scènes, intrigues, costumes exacts ou designs reconnaissables de la série.

---

# Phrase d’Atlas

Altered Carbon DA = mémoire visuelle cyberpunk premium : corps-support, identité transférable, luxe noir, architecture verticale, pluie néon, mémoire corticale, beauté froide.
