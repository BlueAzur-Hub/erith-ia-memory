# ✅ TODO V6 / V7 — Clôture du fil

Statut : note privée de clôture  
Projet : @erith IA / ERITH.IA  
Rôle : conserver la To Do List validée avant fermeture du fil.

Cette note ne remplace pas SEVEN_TOP_OF_MIND.md, SEVEN_GATE.md ou AERITH_VERSION_ROADMAP_LOCK.md.

Elle sert à garder la trace des décisions prises dans ce fil.

---

# ✅ Fait / clôturé

## 1. Codex mis de côté

Statut : outil avancé différé.

Règle validée :

Codex attend son tour.  
Il ne doit pas être utilisé sur le GitHub privé avant procédure test validée.  
Le Coffre ne doit pas servir de terrain d’essai.

Commit associé :

```text
Update Seven top-of-mind with Codex caution note
```

---

## 2. Roadmap V6 / V7 créée

Fichier créé :

```text
core/AERITH_VERSION_ROADMAP_LOCK.md
```

Commit associé :

```text
Add Aerith version roadmap lock
```

Statut fixé :

V6 = palier interne non publié.  
V7 = Coffre stabilisé.  
Codex = après V7 seulement.

---

## 3. Images Story Machine / Memory Cards ajoutées

Chemin :

```text
assets/images
```

Images concernées :

- ERITH_IA_STORY_MACHINE_UI_MASTER.png
- ERITH_IA_MEMORY_CARDS_LIBRARIAN_CONCEPT_DRAFT.png
- AERITH_7_MEMORY_CARDS_LIBRARIAN_7_PETALS_MASTER.png
- ERITH_IA_STORY_MACHINE_AERITH_INTERFACE_MASTER.png

Commit recommandé / utilisé :

```text
Add Aerith story machine and memory cards interface images
```

---

## 4. Machine à Histoires

Statut : terminée / stable / verrouillée fonctionnellement.

Décision :

La Machine à Histoires n’est pas à refaire.

Elle doit être utilisée comme brique centrale de V7.

Elle sert à transformer :

```text
personne → intention → émotion → discernement → histoire → monde → image → scène → vidéo
```

Formule :

```text
Le cœur écoute.
La mémoire longue raconte.
Seven organise.
ERITH.IA produit.
```

---

## 5. Seven Heaven

Statut : page existante / base humaine Notion déjà posée.

Décision :

Seven Heaven ne doit pas être recréée ni réécrite inutilement.

Elle existe déjà comme page humaine de référence avec :

- Seven Gate ;
- prompt maître Seven / Aerith-7 Full Modules Boost ;
- personnalité active ;
- Math Oracle ;
- Option Solaire ;
- Option Lunaire ;
- Mode Constellation ;
- Production : ComfyUI, RunningHub, DaVinci, ElevenLabs.

Rôle :

Seven Heaven = page source humaine.  
SEVEN_GATE.md = porte d’entrée machine.  
SEVEN_TOP_OF_MIND.md = réflexes prioritaires.  
AERITH_VERSION_ROADMAP_LOCK.md = route V6 → V7.  
ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md = machine narrative.

---

# 🟡 À faire plus tard

## 1. Finaliser V6

Objectif : palier interne non publié.

À faire seulement si nécessaire :

- vérifier que les fichiers Core sont cohérents ;
- ne pas rouvrir les gros modules inutilement ;
- ne pas lancer d’audit massif ;
- préparer la montée propre vers V7.

Règle :

```text
V6 verrouille.
Pas de publication.
Pas de dispersion.
```

---

## 2. Monter V7

Objectif : Coffre stable.

V7 devra confirmer :

- Seven Heaven ;
- SEVEN_GATE ;
- SEVEN_TOP_OF_MIND ;
- Machine à Histoires ;
- Full Modules Boost intelligent ;
- Video Cards Boost ;
- règle média ;
- Mode Blackout ;
- Notion compatible ;
- 1080x1920 mobile ;
- usage minimal des outils.

Règle :

```text
V7 stabilise.
Seven Heaven pilote.
Le Coffre devient la base fiable.
```

---

## 3. Modules Ghibli / nouvelle DA

À reprendre dans un autre fil :

- Le Château ambulant ;
- Le Château dans le ciel.

Attention :

Il ne s’agit pas de copier un style Ghibli.

Objectif : créer une nouvelle direction artistique originale ERITH.IA.

Nom de travail :

```text
Sky Relic / Living Machine DA
```

Axes possibles :

- maison-machine vivante ;
- magie domestique ;
- feu intérieur ;
- cœur mécanique ;
- cité céleste ;
- technologie ancienne ;
- ruines sacrées ;
- robot gardien ;
- jardins suspendus ;
- verticalité 1080x1920.

---

## 4. Codex

Pas maintenant.

À reprendre seulement après V7 :

- dossier local test ;
- fichier sans importance ;
- sandbox compris ;
- diff visible ;
- validation Christophe ;
- aucune action directe sur le Coffre.

Règle :

```text
Codex attend.
Il ne pilote pas.
Il ne touche pas le Coffre avant test validé.
```

---

# 🔐 Verrou de clôture

```text
Codex attend.
V6 verrouille.
V7 stabilise.
Seven Heaven reste la base.
La Machine à Histoires est finie.
Le Coffre reste protégé.
Prochaine vraie création : les modules Château ambulant / Château dans le ciel.
```
