# GITHUB WRITE GUARD

Statut : protocole de sécurité GitHub  
Projet : Seven Portable Terminal / ERITH.IA  
Rôle : encadrer toute écriture GitHub  
Priorité : critique

---

## 1. Principe central

GitHub n’est pas un brouillon.

GitHub est une mémoire longue, versionnée, structurée, récupérable et critique.

Toute écriture GitHub doit être :

- demandée ;
- nécessaire ;
- bornée ;
- vérifiable ;
- réversible autant que possible ;
- liée à un livrable réel.

---

## 2. Interdiction des actions expérimentales

Aucune action GitHub expérimentale n’est autorisée.

Interdits absolus :

- fichier test ;
- branche test ;
- commit test ;
- blob fictif ;
- tree inutile ;
- création d’objet pour vérifier une permission ;
- popup GitHub non nécessaire ;
- action “pour voir si ça marche”.

Si une permission doit être vérifiée, elle doit l’être uniquement par une action réelle, demandée et utile.

---

## 3. Conditions avant écriture

Avant toute écriture GitHub, l’IA doit confirmer intérieurement :

1. L’utilisateur a explicitement demandé une modification GitHub.
2. Le dépôt est clairement identifié.
3. Le chemin du fichier est clairement identifié.
4. Le contenu à écrire est final.
5. Le SHA actuel du fichier est connu si update_file est utilisé.
6. Le commit message est cohérent.
7. Aucun autre fichier n’est touché.
8. L’action est unique.
9. Le point d’arrêt est défini.

Si l’utilisateur demande un upload manuel, GitHub est interdit.

---

## 4. Règle du commit unique

Pour une correction ciblée :

- un fichier si possible ;
- un commit ;
- un message clair ;
- aucun test parasite ;
- aucun second commit de correction sauf demande explicite.

Exemple de bon commit :

Update Action Aerith incident report

Exemple de mauvais commit :

test

---

## 5. Règle de protection du dépôt privé

Le dépôt privé doit être traité comme une zone sensible.

Ne jamais :

- écrire sans demande explicite ;
- lancer d’audit large ;
- chercher à “optimiser” une structure non demandée ;
- modifier un fichier protégé ;
- toucher à core/SEVEN_TOP_OF_MIND.md sans autorisation directe de Christophe ;
- proposer de réorganiser le dépôt pendant une correction simple.

---

## 6. Fichiers protégés

Fichier protégé strict :

core/SEVEN_TOP_OF_MIND.md

Règle :

Seul Christophe peut le modifier.

L’IA peut proposer un texte séparé, mais ne doit jamais modifier ce fichier directement.

---

## 7. Réaction en cas de doute

En cas de doute :

- ne pas écrire ;
- produire un patch local ;
- demander validation ;
- ou s’arrêter.

La sécurité prime sur la vitesse.

---

## 8. Formule d’activation courte

Mode GITHUB WRITE GUARD actif.

Aucune écriture GitHub sans demande explicite.
Aucun test GitHub.
Aucun fichier parasite.
Aucun commit inutile.
Si upload manuel demandé : GitHub interdit.
