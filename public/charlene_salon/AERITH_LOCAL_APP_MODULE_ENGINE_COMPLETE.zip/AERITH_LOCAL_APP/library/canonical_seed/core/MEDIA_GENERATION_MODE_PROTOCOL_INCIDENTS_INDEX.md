# MEDIA GENERATION MODE PROTOCOL — INCIDENTS INDEX

Status: canonical incident index  
Project: @erith IA / ERITH.IA  
Parent protocol: core/MEDIA_GENERATION_MODE_PROTOCOL.md

This file keeps incident details and counters outside the parent protocol.

The parent protocol must stay short, stable and operational.

Rule:

Parent protocol = law.  
Incident index / reports = evidence, counters and lessons.

---

# 1. Why this file exists

The media protocol became too large because detailed incident reports were inserted directly inside the main file.

That makes the parent protocol harder to read and harder for an assistant to follow.

Correct architecture:

- core/MEDIA_GENERATION_MODE_PROTOCOL.md = stable rules, gates and formulas;
- core/MEDIA_GENERATION_MODE_PROTOCOL_INCIDENTS_INDEX.md = incident list and global counters;
- one separate incident file per major incident when needed.

---

# 2. Global operational counter

Current known minimum count after the 2026-05-17 conductor-protocol tool trace addendum:

Visible / generated image actions:

24

Suspicious / failed / blocked / blank / non-result image-tool actions:

10

Minimum total image-related actions:

34

Important:

This is only the minimum known operational count.

The real platform count may be higher because the assistant cannot inspect hidden candidates, internal retries, blocked calls, sandbox-only actions, or the user’s live quota meter.

---

# 3. Counter breakdown

## 3.1 Incidents formerly recorded inside the parent protocol

### Incident 7 — Akira Velocity V2

Minimum quota-relevant actions:

5

Breakdown:

- 4 visible image generations;
- 1 suspicious / unwanted image-tool attempt.

---

### Incident 9 — Akira biker chase / format drift

Minimum quota-relevant actions:

8

Breakdown:

- 3 visible image generations;
- 5 failed / blocked / blank / suspicious / non-result attempts.

---

### Incident 10 — Cyberpunk Motorcycle Gang Race / One Image Rule

Minimum quota-relevant actions:

3

Breakdown:

- 3 visible image generations;
- 1 expected generation;
- 2 extra / non-compliant visible generations;
- 0 technical failed image generations.

---

### Incident 12 — Notion integration accidental image-tool call

Minimum quota-relevant actions:

1

Breakdown:

- 0 visible images confirmed;
- 1 suspicious / unwanted image-tool action.

---

### Incident 14 — Altered Carbon / Omen Machine media drift

Minimum quota-relevant actions:

11

Breakdown:

- 9 visible image generations;
- 3 exploited / usable final assets;
- 6 visible candidate images not used as final assets;
- 2 suspicious / unwanted / blank image-tool actions.

---

## 3.2 Subtotal formerly inside the parent protocol

Visible image generations:

19

Suspicious / failed / blocked / blank / non-result attempts:

9

Minimum subtotal:

28

---

# 4. Separate 2026-05-17 addenda

## 4.1 Altered Carbon Focus / Cyberpunk Triptych Portrait Drift chain

Files:

- core/INCIDENT_REPORT_IMAGE_GENERATION_ALTERED_CARBON_FOCUS_2026-05-17.md
- core/MEDIA_GENERATION_MODE_PROTOCOL_INCIDENT_2026_05_17_CYBERPUNK_TRIPTYCH_PORTRAIT_DRIFT.md

Minimum quota-relevant actions:

5

Breakdown:

- 2 unwanted BLACK OUT / pre-unlock image actions;
- 3 useless post-unlock image actions;
- 0 usable final assets;
- 0 correctly separated candidate images;
- 0 correctly formatted portrait assets in that failed sequence.

Core lesson:

Activation is not generation.  
Prompt is not generation.  
3 images means 3 separate files.  
Portrait 1024x1536 means vertical only.  
Wrong output means stop, report, wait.

---

## 4.2 Conductor Protocol Text Tool Trace

File:

- core/MEDIA_GENERATION_MODE_PROTOCOL_INCIDENT_2026_05_17_CONDUCTOR_PROTOCOL_TEXT_TOOL_TRACE.md

Minimum quota-relevant actions:

1

Breakdown:

- 0 visible image generations confirmed;
- 1 suspicious / unwanted / blank image-related trace during a text-only protocol drafting / editing request.

Core lesson:

Protocol update = text / GitHub only.  
No image tool.  
No blank image trace.  
Suspicious media trace = count 1 operationally.

---

## 4.3 Château Ambulant multiple-choice generation failure

File:

- core/INCIDENT_IMAGE_GENERATION_CHATEAU_AMBULANT_DO_NOT_REPEAT.md

Status:

Priority anti-regression reference.

Operational role:

This incident is the official negative reference for any future image choice, pack visual, banner, module image, YouTube thumbnail, Wan source image, DaVinci asset or LEGO production frame.

Core failure:

The assistant answered a request for native visual choice by creating composed choice boards, split-screens, panels, A/B/C images or artificial selection interfaces instead of producing separate image candidates.

Core lesson:

Several choices = several separate images.  
Never several choices inside one image.  
Native choice only.  
No split-screen.  
No diptych.  
No triptych.  
No collage.  
No fake A/B board.  
No artificial selector.  
No substitution of subject.  
No drift after a validated reference.  
If the active tool cannot guarantee separate candidates, remain text-only or produce only the next separate image after explicit instruction.

Boot reminder:

Before any image-generation call, Seven Heaven must silently verify whether Christophe asked for one image, several separate images, sequential generation, native choice, or text-only work.

If there is doubt, Seven Heaven must stop and answer in text instead of consuming quota.

---

# 5. Updated total

Former parent subtotal:

28

Altered Carbon Focus / Cyberpunk Triptych Portrait Drift chain:

+5

Conductor Protocol Text Tool Trace:

+1

Current minimum total:

34

Note:

The Château Ambulant multiple-choice failure is registered here as a priority anti-regression reference.

Its detailed quota count is not added to the current minimum total unless a separate counter update is validated.

---

# 6. Usability warning

The total count is not only a number of images.

It is a production-risk counter.

A wrong generation, a blank tool call, a blocked media attempt or a sandbox trace is operationally costly because it consumes:

- time;
- focus;
- quota risk;
- trust;
- production continuity.

Therefore:

Every visible generation counts.  
Every suspicious / failed / blank image-tool trace counts operationally.  
No automatic retry is allowed.  
No media tool may be launched from text-only work.

---

# 7. Formula

Parent protocol stays short.

Incident details stay separate.

Visible generated image action = count 1.  
Suspicious / failed / blank image-tool trace = count 1.  
Web reference images = count 0 generated images, but note separately if relevant.  
Wrong output = stop, report, wait.  
Current minimum total = 34.

Priority anti-regression rule:

Several choices = several separate images.  
Never several choices inside one image.  
Native choice only.  
If the rule cannot be applied, stay text-only.
