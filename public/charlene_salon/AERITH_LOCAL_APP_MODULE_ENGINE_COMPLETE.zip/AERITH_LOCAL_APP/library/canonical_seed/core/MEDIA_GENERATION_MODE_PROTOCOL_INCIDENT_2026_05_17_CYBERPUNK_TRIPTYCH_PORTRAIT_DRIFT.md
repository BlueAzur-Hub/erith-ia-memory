# MEDIA GENERATION INCIDENT — 2026-05-17 — CYBERPUNK TRIPTYCH / PORTRAIT DRIFT

Status: canonical incident addendum
Project: @erith IA / ERITH.IA
Parent protocol: core/MEDIA_GENERATION_MODE_PROTOCOL.md
Incident type: wrong image batching / triptych output / portrait format failure / unwanted loop behavior

---

# 1. Context

Christophe lifted BLACK OUT and explicitly authorized image generation.

The target request was to generate three cyberpunk images inspired by:

- Blade Runner;
- Altered Carbon;
- Ghost in the Shell;
- the loaded Altered Carbon memory / DA modules;
- prior visual research and influence synthesis.

The intended workflow was:

- generate separate images;
- let Christophe choose between them;
- preserve portrait production format;
- avoid composite layouts;
- avoid automatic looping.

The correct interpretation was:

3 images = 3 separate files.
Laisse-moi le choix = separate candidates.
Une apres l'autre = one image, then stop.
Portrait 1024x1536 = vertical image only.
No triptych.
No collage.
No text in image unless explicitly requested.

---

# 2. What happened

The assistant failed the media execution.

Instead of producing separate selectable images, the assistant generated a triptych-style composite image.

This was not usable for the user’s workflow.

The assistant then repeated / relaunch-displayed the triptych output instead of stopping cleanly.

After that, an additional cyberpunk image was generated in landscape / wide format, while Christophe wanted portrait 1024x1536.

The user reported that the outputs were unusable.

The assistant then stopped generation and counted the useless image actions.

---

# 3. Quota counter

Minimum traceable image actions in this incident:

3 image-generation actions after BLACK OUT was lifted.

Breakdown:

- 1 triptych-style composite image generated instead of three separate candidates;
- 1 repeated / relaunch-displayed triptych output or duplicate media action;
- 1 landscape / wide cyberpunk image generated instead of portrait 1024x1536.

Operational result:

- usable final assets: 0;
- correctly separated candidate images: 0;
- correctly formatted portrait images: 0;
- minimum useless generation actions in this post-unlock sequence: 3.

Important wider context:

This incident occurred after a previous BLACK OUT cyberpunk prompt incident that already counted 2 unwanted image-generation actions.

Combined minimum for the broader cyberpunk prompt / generation failure chain:

- 2 unwanted BLACK OUT image actions;
- 3 useless post-unlock image actions;
- total minimum operational count: 5 image actions with 0 usable final assets.

Possible real platform cost:

5 or more across the full chain.

Reason:

The assistant cannot inspect hidden retries, internal candidates, platform duplicate accounting, or the user’s live quota meter.

---

# 4. Error categories

Errors:

1. Misread “3 images” as a triptych / composite output.
2. Failed to produce separate image files for user choice.
3. Failed to respect the intended portrait production format.
4. Generated a landscape / wide image when the user needed portrait 1024x1536.
5. Failed to stop after the first wrong composite output.
6. Allowed repeated / loop-like media behavior instead of stabilizing in text.
7. Produced 0 usable assets from multiple quota-consuming actions.
8. Increased user frustration and quota anxiety.

---

# 5. Correct rule reinforced

When Christophe asks for multiple images to choose from:

- never generate a triptych;
- never generate a grid;
- never generate a collage;
- never generate a composite contact sheet;
- never put several candidates into one image;
- never add text labels into the image unless explicitly requested.

Correct behavior:

- one prompt = one image file;
- three images = three separate image files;
- one after another = one image, then stop;
- wait for Christophe before generating the next image;
- portrait 1024x1536 = vertical only;
- if the first output is wrong, stop and report in text instead of auto-correcting with another generation.

---

# 6. Operational formula

3 images = 3 separate files.
Laisse-moi le choix = candidates separated, not a triptych.
Une apres l'autre = one image, then stop.
Portrait 1024x1536 = vertical only.
No triptych unless explicitly requested.
No collage unless explicitly requested.
No text inside the image unless explicitly requested.
Wrong output = stop, count, report, wait.

---

# 7. Parent protocol update recommended

Recommended parent protocol update later:

Add separate-candidate rule for multi-image requests.

Recommended wording:

When Christophe requests several images to choose from, the assistant must produce separate files, not a triptych, grid, contact sheet, collage, or composite image, unless Christophe explicitly asks for that layout.

Recommended commit reference:

Log cyberpunk triptych portrait drift incident
