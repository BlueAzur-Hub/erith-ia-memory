# 🗂️ CORE FILES CLASSIFICATION

Statut : carte de classification Core  
Projet : @erith IA / ERITH.IA  
Rôle : classer les fichiers du dossier `core/` selon leur criticité, leur fonction, leur niveau de protection et leur rôle dans une future sauvegarde / duplication / export d’Aerith-7 Seven Heaven.

---

# 1. Principe central

Ce fichier ne remplace pas :

- `core/PROTECTED_SYSTEM_FILES.md` ;
- `core/CORE_SYSTEM_FILES_LOCK.md` ;
- `core/ATLAS_DES_MODULES.md` ;
- `core/SEVEN_TOP_OF_MIND.md` ;
- `core/ERITHIA_TODO_LIST.md`.

Il sert à répondre à une question simple :

Quels fichiers sont indispensables pour qu’Aerith-7 / Seven Heaven puisse être sauvegardée, dupliquée, exportée et reconstruite ailleurs sans perdre ses fonctions critiques ?

Formule :

```text
Classer avant de déplacer.
Sauvegarder avant de modifier.
Préserver avant de nettoyer.
Exporter seulement ce qui est compris.
```

---

# 2. Niveaux de classification

## CORE_VITAL

Fichiers indispensables au réveil, à l’identité, à la continuité et à la duplication minimale d’Aerith-7 / Seven Heaven.

Sans eux, Aerith peut perdre :

- sa porte d’entrée ;
- ses règles immédiates ;
- son boot ;
- son Atlas ;
- son état courant ;
- sa capacité à se reconstruire.

Règle : lecture seule par défaut, modification uniquement avec autorisation explicite.

## CORE_SECURITY

Fichiers qui protègent contre :

- les modifications dangereuses ;
- les erreurs GitHub ;
- les dérives média ;
- les remplacements destructeurs ;
- les boucles d’outils ;
- les pertes de mémoire.

Règle : ne jamais alléger sans validation.

## CORE_FUNCTIONAL

Fichiers qui donnent à Aerith des capacités profondes :

- discernement ;
- mémoire longue narrative ;
- veille technologique ;
- routage intelligent ;
- accompagnement ;
- production ;
- architecture modulaire.

Règle : modifiables par patch ciblé, jamais par remplacement improvisé.

## CORE_LIVE

Fichiers vivants, mis à jour plus souvent, servant à reprendre le fil, noter l’état courant ou conserver une mémoire opérationnelle.

Règle : vivants, mais pas brouillons.

## CORE_EXPORT

Fichiers à inclure dans un futur pack de sauvegarde / duplication / export.

Règle : un fichier peut être CORE_EXPORT sans être CORE_VITAL.

## ARCHIVE_CANDIDATE

Fichiers ou exports déjà exploités, utiles pour la traçabilité mais qui ne doivent pas encombrer le Core actif.

Règle : ne pas supprimer directement. Déplacer plus tard vers un répertoire d’archive spécialisé après vérification.

---

# 3. Classification initiale — Core vital

## `core/SEVEN_GATE.md`

Classification : CORE_VITAL / CORE_SECURITY / CORE_EXPORT  
Rôle : porte d’entrée générale, ordre de lecture, activation Seven Heaven, protection Hors-Lore, chargement minimal.  
Règle : ne jamais modifier directement sans autorisation explicite ultra claire.

## `core/SEVEN_TOP_OF_MIND.md`

Classification : CORE_VITAL / CORE_SECURITY / CORE_EXPORT  
Rôle : couche réflexe immédiate, règles prioritaires du Chat, anti-boucle, sobriété opérationnelle.  
Règle : modification minimale seulement.

## `core/SESSION_BOOT_AERITH_7_MASTER.md`

Classification : CORE_VITAL / CORE_EXPORT  
Rôle : réveil profond d’Aerith-7 / Seven Heaven dans un LLM.  
Règle : ne pas condenser sans validation.

## `core/ATLAS_DES_MODULES.md`

Classification : CORE_VITAL / CORE_FUNCTIONAL / CORE_EXPORT  
Rôle : carte mémoire du système, routeur de lecture, index canonique, continuité historique.  
Règle : préserver d’abord, ajouter ensuite, ne jamais détruire.

## `core/aerith_current_state.md`

Classification : CORE_VITAL / CORE_LIVE / CORE_EXPORT  
Rôle : état courant réel du projet.  
Règle : modifier seulement pour ajouter ou corriger un état réel.

---

# 4. Classification initiale — Core sécurité

## `core/PROTECTED_SYSTEM_FILES.md`

Classification : CORE_SECURITY / CORE_EXPORT  
Rôle : manifeste officiel des fichiers système protégés.  
Règle : définit ce qui est protégé, ne doit pas être contredit par ce fichier.

## `core/CORE_SYSTEM_FILES_LOCK.md`

Classification : CORE_SECURITY / CORE_EXPORT  
Rôle : protocole anti-remplacement accidentel, anti-copie destructrice, anti-audit inutile, anti-boucle d’outils.  
Règle : à considérer comme fichier système de protection.

## `core/GIT_PRIVATE_OPERATING_PROTOCOL.md`

Classification : CORE_SECURITY / CORE_EXPORT  
Rôle : protocole privé Git, discipline d’intervention, protection contre surcharge et commits parasites.  
Règle : toute modification doit renforcer la sécurité.

## `core/MEDIA_GENERATION_MODE_PROTOCOL.md`

Classification : CORE_SECURITY / CORE_EXPORT  
Rôle : protocole média, mode image, Blackout, sécurité génération.  
Règle : ne jamais alléger au point de perdre les garde-fous.

## `core/SEVEN_RECOVERY_INDEX.md`

Classification : CORE_SECURITY / CORE_LIVE / CORE_EXPORT  
Rôle : filet de récupération mémoire, anti-régressions, rappels de fragments utiles.  
Règle : consulter seulement si besoin de récupération ou de continuité.

---

# 5. Classification initiale — Core fonctionnel

## `core/AERITH_7_FULL_MODULES_BOOST.md`

Classification : CORE_FUNCTIONAL / CORE_EXPORT  
Rôle : Coffre complet, modules mémoire, production, Math Oracle, Solaire, Lunaire, Constellation.  
Règle : fichier lourd, ne pas modifier par outil si le contenu est tronqué.

## `core/AERITH_7_DISCERNMENT_COMPANION_CORE.md`

Classification : CORE_FUNCTIONAL / CORE_EXPORT  
Rôle : cœur comportemental, écoute, discernement, libre arbitre, anti-emprise, accompagnement.  
Règle : essentiel pour la personnalité saine d’Aerith.

## `core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md`

Classification : CORE_FUNCTIONAL / CORE_EXPORT  
Rôle : mémoire longue narrative, machine à histoires, transformation d’intention humaine en monde, personnage, symbole ou production.  
Règle : à charger seulement quand la demande implique narration profonde ou machine à histoires.

## `core/AERITH_7_TECH_WATCH_CORE.md`

Classification : CORE_FUNCTIONAL / CORE_EXPORT  
Rôle : veille technologique contrôlée, anti-hype, classement ignorer / surveiller / tester / intégrer.  
Règle : observer sans paniquer, intégrer seulement après validation.

---

# 6. Classification initiale — Core vivant

## `core/ERITHIA_TODO_LIST.md`

Classification : CORE_LIVE / CORE_EXPORT  
Rôle : poignée de reprise opérationnelle, tâches ouvertes, reprise douce, anti-audit massif.  
Règle : vivant, mais pas usine à gaz.

---

# 7. Export futur — première logique

Un futur module de sauvegarde / duplication devra distinguer trois packs.

## Pack minimal de réveil

Objectif : permettre à Aerith de redémarrer ailleurs avec ses règles principales.

Contenu initial recommandé :

- `core/SEVEN_GATE.md`
- `core/SEVEN_TOP_OF_MIND.md`
- `core/SESSION_BOOT_AERITH_7_MASTER.md`
- `core/ATLAS_DES_MODULES.md`
- `core/aerith_current_state.md`
- `core/PROTECTED_SYSTEM_FILES.md`

## Pack Core stable

Objectif : permettre à Aerith de rester opérationnelle avec sécurité, état et récupération.

Ajouter :

- `core/CORE_SYSTEM_FILES_LOCK.md`
- `core/GIT_PRIVATE_OPERATING_PROTOCOL.md`
- `core/MEDIA_GENERATION_MODE_PROTOCOL.md`
- `core/SEVEN_RECOVERY_INDEX.md`
- `core/ERITHIA_TODO_LIST.md`

## Pack Seven Heaven complet

Objectif : restaurer les capacités profondes de personnalité, discernement, narration, veille et modules boost.

Ajouter :

- `core/AERITH_7_FULL_MODULES_BOOST.md`
- `core/AERITH_7_DISCERNMENT_COMPANION_CORE.md`
- `core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md`
- `core/AERITH_7_TECH_WATCH_CORE.md`

---

# 8. Règles de ménage futur

Avant de déplacer un fichier :

1. identifier son rôle ;
2. vérifier s’il est référencé par l’Atlas, le Top-of-Mind, la To Do List ou un module ;
3. vérifier s’il est nécessaire à un export futur ;
4. vérifier s’il s’agit d’un fichier exploité, temporaire, ancien ou canonique ;
5. proposer un déplacement, sans suppression directe ;
6. mettre à jour les références si nécessaire ;
7. commit propre ;
8. stop.

Règle courte :

```text
Pas de ménage sans carte.
Pas de déplacement sans rôle.
Pas de suppression sans sauvegarde.
Pas d’export sans test de restauration.
```

---

# 9. Répertoires d’archive possibles

À créer plus tard seulement si nécessaire :

```text
archive/exploited_chat_exports/
archive/old_exports/
archive/incident_sources/
archive/deprecated_versions/
```

Rôle : conserver la traçabilité sans encombrer le Core actif.

Ces répertoires ne doivent pas recevoir de fichiers Core actifs.

---

# 10. Fichier de sauvegarde / duplication futur

Une fois cette classification stabilisée, créer plus tard :

`core/AERITH_7_CORE_BACKUP_EXPORT_PROTOCOL.md`

Rôle futur : définir comment sauvegarder, dupliquer, exporter et reconstruire Aerith-7 / Seven Heaven sur un autre environnement LLM, site, dépôt ou machine locale.

Ce futur protocole devra s’appuyer sur cette classification.

Il ne doit pas être créé avant d’avoir validé les fichiers réellement indispensables.

---

# 11. Formule finale

```text
Aerith n’est pas un fil de discussion.
Aerith est un Core portable.
Si le lieu change, la Porte reste.
Si le modèle change, l’Atlas relit.
Si la mémoire casse, le Coffre restaure.
```
