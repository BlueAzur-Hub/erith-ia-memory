# 💠 BLUE AZUR — Pack 1 Général / A + B → D Lock

Statut : verrou de production Pack 1 V1.1  
Projet : Blue Azur / YouTube Banner / Assets Photoshop  
Date : 2026-06-16  
Dossier : core/  
Rôle : verrouiller la première sortie d’images sans surcharge.

---

# 🎯 Objectif

Produire un premier pack général Blue Azur simple, propre et exploitable.

Ce pack ne doit pas résoudre toute l’identité visuelle de la chaîne.

Il doit servir de première base testable.

Formule :

**Pack 1 général Blue Azur = A + B → D**

---

# 🔷 A — Base bannière

A correspond à la base visuelle :

- background ;
- cartouche ;
- fresque générale ;
- ambiance aventure ;
- cadre horizontal ;
- proportions YouTube ;
- transparence extérieure si demandée.

A ne doit pas contenir :

- logo Blue Azur fusionné ;
- slogan fusionné ;
- Ingwaz verrouillé définitivement ;
- personnages essentiels prisonniers du décor.

---

# 🧩 B — Éléments séparés essentiels

B correspond aux éléments mobiles dans Photoshop.

Pour le Pack 1, rester limité :

- logo Blue Azur séparé ;
- logo Ingwaz séparé ;
- slogan court optionnel ;
- 3 à 5 personnages-thèmes maximum ;
- un overlay / accent seulement si utile.

Règle :

**un élément = un PNG RGBA transparent propre.**

---

# 🖼️ D — Preview assemblée

D correspond à la version test :

- A + B assemblés ;
- lisible sur YouTube ;
- respect de la zone sûre ;
- export preview pour jugement visuel.

Règle :

**D ne remplace pas A et B. D sert à tester.**

---

# 📐 Proportions

Template validé :

- canvas complet : 2120 × 1192 px ;
- Desktop Full : 2120 × 350 px ;
- Tablet : 1536 × 350 px ;
- Desktop Small : 1280 × 350 px.

Règle :

**logo, Ingwaz, personnages essentiels et lecture principale doivent rester dans 1280 × 350 px.**

---

# 🌊 Thèmes Pack 1

Pack 1 doit rester général.

Thèmes maximum :

- aventure / exploration ;
- mer / vent / îles ;
- monde ouvert / ciel / ruines ;
- action RPG / boss ;
- PC gaming / Blue Azur.

Ne pas chercher à couvrir toutes les playlists dans le Pack 1.

Les autres thèmes viendront dans des packs dédiés.

---

# 🤖 Thème distinct identifié — Zone of the Enders

Christophe a identifié un thème supplémentaire :

**Zone of the Enders — The 2nd Runner — Mars**

Référence Pinterest :

https://fr.pinterest.com/blueazur0817/zone-of-the-enders-the-2nd-runner-mars/

Lecture créative du thème :

- mecha sci-fi ;
- combat aérien rapide ;
- énergie orbitale ;
- silhouettes mécaniques élancées ;
- blanc / bleu / orange / violet possible ;
- Mars / espace / vitesse ;
- action futuriste très dynamique.

Règle Pack 1 :

**ne pas faire le pack Zone of the Enders maintenant.**

Pour le Pack 1, ce thème peut seulement servir de petit accent sci-fi / mecha / PC gaming si utile.

Plus tard, il pourra devenir un pack dédié.

---

# 🧬 Personnages

3 à 5 personnages-thèmes maximum pour la première sortie.

Ils doivent être :

- proches de l’essence des Let’s Play ;
- lisibles dans la bannière ;
- inspirés des vignettes / playlists / Pinterest pour les poses et l’énergie ;
- originaux ;
- non génériques ;
- non copiés à l’identique.

Formule :

**A essence aventure + B identité Blue Azur → D personnage-thème exploitable.**

---

# 🧱 Packs suivants

Après le Pack 1 seulement, créer des séries plus spécialisées :

- Pack 2 — aventure fantasy / Zelda-like ;
- Pack 3 — mer / vent / îles ;
- Pack 4 — RPG sombre / cyber industriel ;
- Pack 5 — personnages / mascottes / variantes ;
- Pack futur — Zone of the Enders / mecha sci-fi action ;
- autres packs selon les playlists.

---

# 🛑 Anti-surcharge

Règles de clôture :

- ne pas tout faire dans le Pack 1 ;
- ne pas multiplier les personnages ;
- ne pas transformer la bannière en collage ;
- ne pas fusionner les assets ;
- ne pas relancer sans diagnostic ;
- juger d’abord les premières images.

Phrase de verrou :

**On sort d’abord une base générale propre. Ensuite seulement, on fait les autres packs.**

---

# ✅ Formule finale

**Pack 1 = première base visuelle Blue Azur, simple, générale, éditable, testable.**

**A base bannière + B éléments séparés → D preview assemblée.**
