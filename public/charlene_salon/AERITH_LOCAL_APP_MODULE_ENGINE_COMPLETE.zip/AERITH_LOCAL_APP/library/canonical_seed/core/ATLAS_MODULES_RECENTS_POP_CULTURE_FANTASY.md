# 🧭 ATLAS — Modules récents Pop Culture, Anime, Fantasy & Jeux vidéo

Type : Entrée Atlas complémentaire / modules récents validés  
Statut : Canonique complémentaire  
Usage : à intégrer ou consulter avec `core/ATLAS_DES_MODULES.md`  
Rôle : déclarer les modules récents non encore listés dans l’Atlas principal, sans recopier leur contenu.

---

# 1. Principe

Cette entrée complète l’Atlas des Modules avec une grappe récente de modules culturels validés.

Règle centrale :

Seven ne doit pas tout charger.

Seven doit choisir uniquement le module utile selon la demande immédiate.

Ces modules sont des influences créatives, narratives, esthétiques ou symboliques.

Ils ne doivent pas servir à copier directement des œuvres protégées.

Pour la production image / vidéo, toujours produire un univers original, avec prompts positifs nettoyés et garde-fous anti-copie.

---

# 2. Manga / Anime

## Bleach — Shinigami, monde spirituel & guerre intérieure

Fichier :

`modules/erith_ia_bleach_shinigami_fr.md`

À charger pour :

- shinigami ;
- monde spirituel ;
- sabres intérieurs ;
- identité fragmentée ;
- combat intérieur ;
- énergie spirituelle ;
- clans, divisions, serments, ombres et révélation de puissance.

Garde-fou :

Ne pas copier personnages, uniformes, symboles, armes, noms propres, arcs exacts ou designs officiels.

---

## Naruto — Shinobi, héritage & volonté

Fichier :

`modules/erith_ia_naruto_shinobi_fr.md`

À charger pour :

- monde shinobi ;
- apprentissage ;
- rivalité ;
- transmission ;
- villages cachés ;
- techniques spirituelles / martiales originales ;
- solitude, reconnaissance, héritage et volonté.

Garde-fou :

Ne pas copier personnages, villages, clans, signes, techniques nommées, démons, costumes ou symboles officiels.

---

## One Piece — équipage, liberté & îles-mondes

Fichier :

`modules/erith_ia_one_piece_equipage_liberte_fr.md`

À charger pour :

- équipage ;
- voyage maritime ;
- îles-mondes ;
- liberté ;
- rêve personnel ;
- camaraderie ;
- trésor symbolique ;
- aventure lumineuse avec fond politique ou mythique.

Garde-fou :

Ne pas copier personnages, fruits, emblèmes, navires, factions, pouvoirs, lieux ou designs officiels.

---

## Cowboy Bebop — jazz spatial, mélancolie & chasseurs errants

Fichier :

`modules/erith_ia_cowboy_bebop_jazz_spatial_fr.md`

À charger pour :

- jazz spatial ;
- errance ;
- équipage fragile ;
- passé qui rattrape ;
- primes, stations, vaisseaux, solitude ;
- mélange noir, western, polar, SF et mélancolie.

Garde-fou :

Ne pas copier personnages, vaisseaux, musiques, titres, scènes, silhouettes ou compositions reconnaissables.

---

# 3. Studio Ghibli / Châteaux vivants

## Studio Ghibli — mondes vivants

Fichier :

`modules/erith_ia_studio_ghibli_mondes_vivants_fr.md`

À charger pour :

- nature vivante ;
- quotidien merveilleux ;
- machines douces ;
- maisons habitées ;
- enfants, seuils, forêts, vents, esprits et mondes sensibles ;
- direction artistique animée poétique.

Garde-fou :

Ne pas copier personnages, créatures, scènes, véhicules, maisons, châteaux, silhouettes ou designs officiels.

---

## Château dans le Ciel — ruines célestes

Fichier :

`modules/erith_ia_chateau_dans_le_ciel_ruines_celestes_fr.md`

À charger pour :

- ruines célestes ;
- îles suspendues ;
- technologie ancienne douce ;
- jardins dans le ciel ;
- cristaux, robots-gardiens originaux, archéologie aérienne ;
- verticalité poétique.

Garde-fou :

Ne pas copier le château officiel, les robots officiels, les personnages, le cristal, les designs, scènes ou symboles reconnaissables.

---

## Château Ambulant — maison vivante

Fichier :

`modules/erith_ia_chateau_ambulant_maison_vivante_fr.md`

À charger pour :

- maison mouvante ;
- architecture vivante ;
- intérieur magique ;
- feu domestique ;
- vieillissement, identité, refuge, guerre lointaine ;
- machine sensible et foyer impossible.

Garde-fou :

Ne pas copier le château officiel, les personnages, le feu, les silhouettes, les décors ou les designs reconnaissables.

---

## DA Châteaux vivants & ruines célestes

Fichier :

`modules/erith_ia_da_chateaux_vivants_ruines_celestes_fr.md`

À charger pour :

- direction artistique transversale ;
- châteaux vivants ;
- ruines suspendues ;
- architecture animée ;
- décor-personnage ;
- monde tactile, poétique, lisible et image-ready.

Garde-fou :

Utiliser comme style original, pas comme copie d’un film précis.

---

# 4. Fantasy mythologique

## Narnia — monde entre les portes

Fichier :

`modules/erith_ia_narnia_monde_entre_les_portes_fr.md`

À charger pour :

- passage entre mondes ;
- armoire / porte / seuil ;
- royaume merveilleux ;
- hiver magique ;
- animaux parlants originaux ;
- retour transformé ;
- enfance, foi symbolique, royauté intérieure et enchantement.

Garde-fou :

Ne pas copier personnages, lion, sorcière, lieux, scènes, objets ou noms officiels.

---

## Tolkien — Bilbo / Hobbit

Fichier :

`modules/erith_ia_tolkien_bilbo_hobbit_fr.md`

À charger pour :

- petite personne face au grand monde ;
- voyage initiatique ;
- montagne, trésor, dragon archétypal original ;
- foyer, chant, carte, énigmes, peur et courage modeste.

Garde-fou :

Ne pas copier personnages, peuples, lieux, langues, cartes, dragons, objets ou noms officiels.

---

## Tolkien — Seigneur des Anneaux

Fichier :

`modules/erith_ia_tolkien_seigneur_des_anneaux_fr.md`

À charger pour :

- quête impossible ;
- compagnie ;
- anneau / fardeau symbolique original ;
- corruption du pouvoir ;
- royaumes anciens ;
- marche longue ;
- guerre mythique ;
- amitié, sacrifice, espérance et fin d’un âge.

Garde-fou :

Ne pas copier personnages, anneau officiel, peuples, lieux, langues, cartes, emblèmes ou scènes reconnaissables.

---

## Tolkien — Silmarillion

Fichier :

`modules/erith_ia_tolkien_silmarillion_fr.md`

À charger pour :

- mythologie haute ;
- création du monde ;
- chute, serment, exil, lignées ;
- joyaux sacrés originaux ;
- tragédie ancienne ;
- âges mythiques, chants fondateurs et mémoire cosmique.

Garde-fou :

Ne pas copier noms, langues, lignées, lieux, objets sacrés, cosmologie exacte ou scènes reconnaissables.

---

# 5. Jeux vidéo / Zelda

## Zelda — module central / atlas

Fichier :

`modules/erith_ia_zelda_hyrule_souffle_ruines_fr.md`

À charger pour :

- orientation générale ;
- grammaire d’aventure ;
- royaume blessé ;
- temples ;
- énigmes ;
- nature sacrée ;
- ruines ;
- mémoire ;
- choix entre BOTW et TOTK.

Règle :

Module central = atlas / orientation.

Pour production spécialisée, choisir BOTW ou TOTK.

---

## Breath of the Wild — souffle, ruines & royaume blessé

Fichier :

`modules/erith_ia_breath_of_the_wild_souffle_ruines_fr.md`

À charger pour :

- monde ouvert horizontal ;
- souffle ;
- plaines ;
- ruines au sol ;
- silence ;
- nature active ;
- sanctuaires bleutés ;
- mémoire perdue ;
- royaume post-catastrophe.

Garde-fou :

Ne pas injecter d’îles célestes majeures, de véhicules assemblés ou de profondeurs massives.

---

## Tears of the Kingdom — verticalité, assemblage & ciel sacré

Fichier :

`modules/erith_ia_tears_of_the_kingdom_verticalite_ruines_fr.md`

À charger pour :

- verticalité ;
- ciel / surface / profondeurs ;
- îles célestes ;
- gouffres ;
- glyphes ;
- assemblage ;
- machines rituelles ;
- technologie antique verte-or ;
- monde reconstruit.

Garde-fou :

Ne pas réduire à un simple monde horizontal contemplatif.

---

# 6. Règle de routage rapide

Si la demande parle de shinigami, sabre intérieur ou monde spirituel → Bleach.

Si la demande parle de shinobi, village caché, entraînement ou héritage → Naruto.

Si la demande parle d’équipage, liberté, mer ou îles-mondes → One Piece.

Si la demande parle de jazz spatial, errance ou chasseurs de primes → Cowboy Bebop.

Si la demande parle de nature vivante, animation poétique ou maison sensible → Studio Ghibli.

Si la demande parle de ruines célestes ou château dans le ciel → Château dans le Ciel.

Si la demande parle de maison mouvante ou château vivant → Château Ambulant.

Si la demande parle de DA transversale châteaux vivants / ruines célestes → DA Châteaux Vivants.

Si la demande parle de porte, armoire, enfance, royaume merveilleux → Narnia.

Si la demande parle de petite aventure, foyer, dragon, montagne, trésor → Bilbo / Hobbit.

Si la demande parle de quête, fardeau, compagnie, corruption du pouvoir → Seigneur des Anneaux.

Si la demande parle de mythologie haute, création, chute, serment, lignées → Silmarillion.

Si la demande parle de Zelda général → module central Zelda.

Si la demande parle de souffle, ruines au sol, monde horizontal → BOTW.

Si la demande parle de verticalité, îles célestes, assemblage, profondeurs → TOTK.

---

# 7. Formule courte

Manga donne l’énergie et la trajectoire intérieure.  
Ghibli donne le monde vivant.  
Tolkien donne la profondeur mythologique.  
Narnia donne le seuil merveilleux.  
Cowboy Bebop donne l’errance musicale.  
Zelda donne l’exploration sacrée.  
Seven choisit seulement le module utile.
