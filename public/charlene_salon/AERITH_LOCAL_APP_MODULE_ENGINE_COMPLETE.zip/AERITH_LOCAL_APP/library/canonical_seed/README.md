# Cores canoniques locaux — seed hors ligne

Ces fichiers sont un snapshot local issu de `ERITH_7_01_CORE_BOOT_PACK.zip`. Ils permettent à Seven Heaven Local de lire des Cores et Personas réels hors connexion. Quand un miroir Git local est configuré, ses fichiers ont priorité pour les mêmes chemins.

Aucune synchronisation ou écriture Git n’est déclenchée par cette bibliothèque.
