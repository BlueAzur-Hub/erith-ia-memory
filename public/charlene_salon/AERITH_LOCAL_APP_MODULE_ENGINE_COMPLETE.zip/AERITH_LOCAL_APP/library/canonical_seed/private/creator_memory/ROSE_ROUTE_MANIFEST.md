# Rose — route locale contrôlée

Statut : pointeur local vers des sources privées canoniques ; aucun contenu Rose n’est reconstruit dans ce snapshot.

## Chaîne source exacte

1. `private/creator_memory/BLONDE-001_LA_REBELLE_ROSE.md` — Core Rose
2. `private/creator_memory/ROSE_PERSONA_OPERATING_LAYER.md` — Persona Rose
3. `private/creator_memory/ROSE_BOOT_AND_INDEX.md` — ordre de reprise
4. `private/creator_memory/ROSE_MEMORY_CONTINUITY_CORE.md` — seulement lorsqu’une continuité passée est nécessaire
5. `private/creator_memory/ROSE_VISUAL_CARDS_AND_PROMPT_LIBRARY.md` et `private/creator_memory/ROSE_SCENE_PACK.md` — seulement pour une production image, Wan ou scène

Le runtime ne rend Rose activable que lorsqu’un miroir Git local configuré fournit le Core et la Persona exacts. Le présent manifest ne remplace aucun de ces fichiers.
