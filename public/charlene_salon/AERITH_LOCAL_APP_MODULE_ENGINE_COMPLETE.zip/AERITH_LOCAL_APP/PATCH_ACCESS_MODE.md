# Patch — passerelle URL

- Le sélecteur **Local / Connecté** est maintenant présent dans **Accès & passerelles**.
- En mode Local, le bouton principal devient **Passer en Connecté** au lieu de rester visuellement cliquable sans effet.
- Après activation explicite de Connecté, un second clic sur **Lire l’URL** réalise la lecture ponctuelle.
- Aucun accès web automatique ; aucune URL n’est ajoutée au Coffre.
