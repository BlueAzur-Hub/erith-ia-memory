@echo off
setlocal
cd /d "%~dp0"
python tests\test_document_engine.py
set code=%ERRORLEVEL%
echo.
if not "%code%"=="0" echo ECHEC - ne lance pas Seven Heaven avant correction.
if "%code%"=="0" echo VALIDATION LOCALE REUSSIE.
pause
exit /b %code%
