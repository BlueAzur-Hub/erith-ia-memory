@echo off
setlocal EnableExtensions
set "APP_DIR=%~dp0"
where ollama >nul 2>nul
if errorlevel 1 (
  echo Ollama n'est pas accessible dans le PATH.
  echo Installe ou ouvre Ollama, puis relance ce fichier.
  pause
  exit /b 1
)
echo Reconstruction explicite de aerith:base depuis AERITH_BASE.Modelfile...
ollama create aerith:base -f "%APP_DIR%AERITH_BASE.Modelfile"
if errorlevel 1 (
  echo.
  echo Reconstruction non terminee. Aucun fichier Seven Heaven n'a ete modifie.
  pause
  exit /b 1
)
echo.
echo aerith:base est reconstruit. Tu peux ensuite lancer START_AERITH_LOCAL.bat.
pause
endlocal
