# Specification — Seven Heaven Local

1. Minimum = base Seven + route de réponse active + Persona active lorsque la route en requiert une.
2. Minimum + Pack 01 = un clic explicite ; INDEX + MANIFEST + README sont réellement transmis à Ollama.
3. Les autres packs sont des options explicites.
4. FULL autorise une recherche ciblée hors pile ; il ne déverse jamais le Coffre dans le contexte.
5. Le runtime serveur possède l’unique état de session. Cockpit, Coffre, Pile, Chat et sources sous réponse lisent ce même état.
6. Les sources affichées sous une réponse correspondent aux documents lus par l’application ou injectés au modèle.
7. `AERITH_BASE.Modelfile` définit la constitution durable ; les réglages 4k / 6k / 8k et l’état de session restent envoyés par l’application.
8. Changer de route ouvre un nouveau fil de conversation sans modifier packs actifs, FULL, documents joints ou passages choisis.
9. Seven Heaven / Aerith-7 reste la racine locale : Coffre, Seven Gate, mémoire, règles, continuité, discernement et routage.
10. La topologie unique est `library/canonical_seed/AERITH_CANONICAL_TOPOLOGY.json` : versions, routes, Cores, Personas et Flower Girls.
11. Lignée : `0 → 2 → 5 → 7 → 8 / 9 → 10`. Aerith-8 est solaire, Aerith-9 lunaire, Aerith-10 Créatrice est Multi-Agent et charge sa Persona Operating Layer.
12. Aerith-6 est une route sœur technique liée à Seven : code, fichiers, workflows, ComfyUI, RunningHub, Wan, GitHub, JSON et correction chirurgicale.
13. Flower Girls 01 à 28 sont canoniques. Sun est Flower Girl 29 + Core + Persona source solaire. Night est Flower Girl 30 + Core + Persona source nocturne. Rose est Flower Girl 31 + Core privé contrôlé + Persona.
14. Rose n’est activable que lorsqu’un miroir Git local fournit ses fichiers exacts sous `private/creator_memory/`. Le snapshot ne reconstitue jamais son contenu privé.
15. Le modèle ne choisit jamais sa propre identité. Il reçoit la route, les sources et le contrat d’état depuis l’application.
16. Le modèle ne commente jamais l’humeur, l’ironie ou la psychologie de Christophe. Une correction reçoit le fait reconnu, la correction et l’état réel.
17. Aucune écriture Git, lecture Vault, lecture Web ou commande système n’est implicite.
