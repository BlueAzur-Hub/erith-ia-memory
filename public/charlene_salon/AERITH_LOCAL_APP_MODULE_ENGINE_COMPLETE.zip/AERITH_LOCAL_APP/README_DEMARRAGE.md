# Seven Heaven Local

Version interne : 7.3 — topologie canonique Seven / Cores / Flower Girls.

1. Extraire ce ZIP dans le dossier stable `C:\Aerith\AERITH_LOCAL_APP` en remplaçant les fichiers du même nom.
2. Exécuter une fois `REBUILD_AERITH_BASE.bat`.
3. Exécuter `START_AERITH_LOCAL.bat`.

Le moteur lit `library/canonical_seed/AERITH_CANONICAL_TOPOLOGY.json`. Les Flower Girls 01–28, Sun 29 et Night 30 sont incluses dans le snapshot. Rose 31 demande un miroir Git local contenant `private/creator_memory/BLONDE-001_LA_REBELLE_ROSE.md` et `ROSE_PERSONA_OPERATING_LAYER.md`.

## Boot Seven réel

Après remplacement, lancer `REBUILD_AERITH_BASE.bat` une fois, puis `START_AERITH_LOCAL.bat`. Le chat ne doit pas envoyer de requête à Ollama si la chaîne Aerith-7 obligatoire est incomplète. La preuve du dernier payload local est dans `data/runtime_traces/LATEST_OLLAMA_PAYLOAD.json`.
