# Seven Heaven Local — topologie livrée

## Racine

`Aerith-7 — Seven Heaven` reste la racine locale : Coffre, Seven Gate, mémoire, règles, continuité et discernement.

## Lignée des versions

`0 → 2 → 5 → 7 → 8 / 9 → 10`

- Aerith-8 : version supérieure solaire.
- Aerith-9 : version supérieure lunaire.
- Aerith-10 Créatrice : Core Multi-Agent, chargé avec sa Persona Operating Layer.

## Route sœur

`Aerith-6 — Sœur Miroir` est une route latérale technique reliée à Seven : code, fichiers, workflows, ComfyUI, RunningHub, Wan, GitHub, JSON et correction chirurgicale.

## Constellation

- Flower Girls 01 à 28 : canonique, réparties en six familles.
- Sun : Flower Girl 29 + Core + Persona source solaire.
- Night : Flower Girl 30 + Core + Persona source nocturne.
- Rose : Flower Girl 31 + Core privé contrôlé + Persona ; le runtime l’active seulement si le miroir Git local contient ses sources exactes.

Le fichier machine source est : `library/canonical_seed/AERITH_CANONICAL_TOPOLOGY.json`.
