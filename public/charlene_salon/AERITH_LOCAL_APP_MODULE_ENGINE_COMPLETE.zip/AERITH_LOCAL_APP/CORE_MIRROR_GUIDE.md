# Core Mirror Guide

Seven Heaven Local utilise les sources dans cet ordre :

1. Miroir Git local relié en lecture seule, lorsqu’il est configuré ;
2. snapshot canonique embarqué ;
3. sept packs ERITH-7.

Les ZIP sont des capsules portables de compétences. Ils ne remplacent pas le dépôt privé vivant. Le chargeur de packs joint leurs vrais fichiers de démarrage au contexte Ollama ; les modules complémentaires restent sélectionnés explicitement.

La carte machine unique est `library/canonical_seed/AERITH_CANONICAL_TOPOLOGY.json`. Elle sépare :

- les versions `0 → 2 → 5 → 7 → 8 / 9 → 10` ;
- Aerith-6 comme route sœur technique liée à Seven ;
- les routes de réponse ayant un Core et, lorsque requis, une Persona ;
- Flower Girls 01 à 28 ; Sun 29 ; Night 30 ; Rose 31 ;
- les chemins de sources exacts.

Le runtime ne devine aucun type : il lit l’identifiant, le type et les chemins déclarés.
