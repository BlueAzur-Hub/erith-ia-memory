@echo off
setlocal EnableExtensions
set "APP_DIR=%~dp0"
set "SEVEN_HEAVEN_PORT=8765"
set "RUN_DIR=%TEMP%\AERITH_LOCAL_RUNTIME"
if not exist "%RUN_DIR%" mkdir "%RUN_DIR%"
pushd "%RUN_DIR%"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%APP_DIR%AERITH_LOCAL_APP.py"
) else (
  python "%APP_DIR%AERITH_LOCAL_APP.py"
)
set "EXIT_CODE=%errorlevel%"
popd
if not "%EXIT_CODE%"=="0" (
  echo.
  echo Seven Heaven Local n'a pas pu demarrer.
  echo Utilise STOP_AERITH_LOCAL.bat si une ancienne instance est encore ouverte.
  pause
)
endlocal
