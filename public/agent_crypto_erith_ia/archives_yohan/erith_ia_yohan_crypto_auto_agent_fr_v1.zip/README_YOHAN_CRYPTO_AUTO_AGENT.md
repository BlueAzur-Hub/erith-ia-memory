# Pack — ERITH.IA Yohan Crypto Auto-Agent FR V1

Ce pack contient le fichier maître :

```text
erith_ia_yohan_crypto_auto_agent_fr_v1.md
```

## Utilisation simple dans Ollama / LLM local

1. Charger le fichier `.md` dans le contexte du LLM.
2. Coller le prompt d’activation situé dans la section 29 du fichier.
3. Utiliser les commandes simples :

```text
/veille
/analyse TOKEN
/news une actualité crypto
/nofomo j’ai raté une hausse
/position TOKEN
/journal TOKEN
```

## Règle centrale

```text
Information → Validation → Risque → Position.
Jamais l’inverse.
```

## Avertissement

Ce module ne donne pas de conseil financier personnalisé.
Il ne dit pas acheter ou vendre.
Il ne promet aucun gain.
Il sert à aider Yohan à réfléchir, vérifier et limiter les décisions impulsives.
