# Atlas-10 Crypto — Pack local V1.0

Ce pack exportable contient le Core, la Persona et le visuel canonique transmis par Christophe.

## Finalité

Atlas-10 Crypto est destiné à fonctionner sur le Ryzen 7 avec un modèle local.

Architecture recommandée :

Agent-Crypto dans Firefox  
→ snapshot structuré de la page  
→ Bridge local Atlas sur `127.0.0.1`  
→ Ollama ou LM Studio  
→ résumé Atlas affiché dans Agent-Crypto

Aucun appel API OpenAI payant n'est requis.

## Fichiers

- `ATLAS_10_CRYPTO_MULTI_AGENT_CORE.md`
- `ATLAS_10_CRYPTO_PERSONA_OPERATING_LAYER.md`
- `ATLAS_10_CRYPTO_EMPEREUR_SOLAIRE_CORE_VISUAL.png`
- `ATLAS_10_CRYPTO_LOCAL_BOOT.md`
- `ATLAS_10_CRYPTO_RUNTIME_CONFIG.json`
- `ATLAS_10_CRYPTO_INTERFACE_INTEGRATION.md`
- `MANIFEST_SHA256.md`

## Intégrité

Le Core et la Persona sont copiés sans modification depuis les fichiers fournis.

Leur verrou reste applicable :

- lecture autorisée ;
- export autorisé ;
- proposition de patch autorisée ;
- aucune modification directe du Core protégé sur GitHub.

## Runtimes locaux

### Ollama

URL locale attendue :

`http://127.0.0.1:11434`

### LM Studio

URL locale OpenAI-compatible attendue :

`http://127.0.0.1:1234/v1`

### AnythingLLM

AnythingLLM reste optionnel. Il est utile pour une base documentaire et du RAG, mais n'est pas nécessaire pour que la page Agent-Crypto transmette son snapshot courant à Atlas.

## Limites

Ce pack ne contient :

- aucun modèle LLM ;
- aucune clé ;
- aucun mot de passe ;
- aucun wallet ;
- aucun ordre financier ;
- aucun backend déjà lancé.

Il constitue le profil Atlas-10 Crypto prêt à être chargé par le futur Bridge local.
