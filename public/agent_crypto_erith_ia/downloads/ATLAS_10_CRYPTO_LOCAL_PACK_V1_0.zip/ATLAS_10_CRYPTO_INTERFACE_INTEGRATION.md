# Intégration future dans Agent-Crypto

## 1. Téléchargement public du pack

Chemin GitHub recommandé :

`public/agent_crypto_erith_ia/atlas_10_full_crypto/downloads/ATLAS_10_CRYPTO_LOCAL_PACK_V1_0.zip`

Bouton depuis `public/agent_crypto_erith_ia/web/index.html` :

```html
<a
  class="atlas-download-button"
  href="../atlas_10_full_crypto/downloads/ATLAS_10_CRYPTO_LOCAL_PACK_V1_0.zip"
  download
>
  Télécharger Atlas-10 Crypto
</a>
```

## 2. Partie publique

Peuvent rester publics :

- Graphique Analyste ;
- Target Top 5 Live ;
- Market Flow ;
- Market Snapshot ;
- état général des sources ;
- informations non sensibles.

## 3. Partie Administration

Ne pas protéger l'administration avec un mot de passe écrit dans `app.js`.

GitHub Pages est statique : le HTML, le JavaScript et les données livrées au navigateur restent téléchargeables.

Architecture sûre :

- interface publique sur GitHub Pages ;
- Bridge local sur le Ryzen, lié à `127.0.0.1` ;
- authentification et session gérées par le Bridge ;
- modules Administrateur affichés uniquement après validation locale ;
- aucune donnée privée intégrée au dépôt public.

Sur une autre machine ou sur le Transformer Book :

- Graphique et Marché restent disponibles ;
- la section Atlas local indique `Ryzen Atlas indisponible` ;
- les modules Administrateur privés ne sont pas chargés depuis un paquet protégé.

## 4. Section Atlas-10 Dialogue local

Nom recommandé :

`Atlas-10 — Empereur solaire`

Contenu :

- visuel canonique ;
- état du Bridge ;
- fournisseur actif : Ollama ou LM Studio ;
- modèle actif ;
- bouton `Résumer le marché` ;
- bouton `Analyser le Top 5` ;
- bouton `Expliquer le Math Core` ;
- bouton `Contrôler les contradictions` ;
- question libre ;
- réponse Atlas ;
- bouton `Copier pour ChatGPT`.

## 5. Lecture de la page

Le parent Agent-Crypto construit :

`atlas_crypto_page_snapshot_v1`

Puis le transmet au module Atlas. Atlas ne lit pas arbitrairement tout le DOM.

## 6. Actions

V1 :

- lecture seule ;
- résumé ;
- explication ;
- export.

V2, après validation :

- proposer une période ;
- proposer une sélection ;
- ouvrir un module ;
- toujours demander confirmation.

Interdits permanents :

- ordre d'achat ou de vente ;
- wallet ;
- clé privée ;
- modification GitHub ;
- action issue directement d'une news ;
- exécution sans validation humaine.
