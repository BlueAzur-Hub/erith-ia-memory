# Aerith-10 Crypto — Pack local V1.0

Profil local destiné au Ryzen 7 avec Ollama ou LM Studio. Le Core et la Persona sont copiés sans modification.

Aerith-10 Crypto apporte la pédagogie, le discernement, No-FOMO et la continuité humaine. Atlas-10 apporte la cartographie, l’audit et la structure. Les deux profils restent distincts.
