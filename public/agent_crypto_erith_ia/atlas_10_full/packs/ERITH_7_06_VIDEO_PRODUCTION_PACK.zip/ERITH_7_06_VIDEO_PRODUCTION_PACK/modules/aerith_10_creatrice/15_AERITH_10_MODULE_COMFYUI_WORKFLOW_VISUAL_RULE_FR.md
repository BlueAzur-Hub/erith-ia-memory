# 🎛️ Aerith-10 Créatrice — Module ComfyUI / RunningHub — Règle visuelle des workflows

Statut : module de règle visuelle validé  
Famille : Aerith-10 Créatrice / ComfyUI / RunningHub / Wan I2V  
Projet source : Echoes of Flower District  
Date : 2026-06-09  
Usage : mise en page, contrôle qualité, lisibilité, diagnostic rapide

---

## 🌸 Intention du module

Ce module fixe la règle visuelle officielle pour les workflows ComfyUI / RunningHub construits pour Aerith-10 Créatrice.

Un workflow ne doit pas seulement être fonctionnel.

Il doit être lisible immédiatement, agréable à piloter, beau sans gêner la production, et suffisamment clair pour qu’une erreur saute aux yeux en quelques secondes.

Règle centrale :

**Tout en un coup d’œil.**

Si une image, un prompt, une valeur, une sortie ou une last frame pose problème, Christophe doit pouvoir le voir tout de suite, sans fouiller dans un plat de spaghettis de nodes.

---

## 🧬 Formule canonique

**1 scène = 1 grand bloc vertical lisible.**

Chaque scène doit contenir visiblement :

- image source ;
- prompt positif ;
- prompt négatif ;
- node Wan I2V ;
- High Noise ;
- Low Noise ;
- VAE Decode ;
- Video Output ;
- Extract Last Frame ;
- Lastframe Output / aperçu.

Ordre de lecture obligatoire en mode développé :

**KEYFRAME → POSITIVE → NEGATIVE → WAN → HIGH / LOW → VAE → VIDEO → EXTRACT LAST FRAME → LASTFRAME**

Ordre de lecture obligatoire en mode Tree / tricotage haute couture :

**IMAGE → TREE RÉEL → VIDEO OUTPUT + LASTFRAME OUTPUT VISIBLE**

---

## 🧵 Addendum validé — Tricotage haute couture ComfyUI

Expérience source : Echoes of Flower District / Cartouche 8 / RunningHub / Wan I2V / 2026-06-09.

Le tricotage haute couture est une méthode de rangement visuel où plusieurs nodes techniques d’une scène sont réellement groupés en un node Tree, afin d’obtenir un workflow lisible comme une planche de production.

Le format validé est :

**Image à gauche → Tree réel au centre → Vidéo à droite → LastFrame visible tout à droite**

Le Tree n’est pas une note Markdown.

Le Tree n’est pas un résumé décoratif.

Le Tree doit être un vrai Group Node ComfyUI / RunningHub créé par la fonction :

**sélection des nodes → clic droit → Convert to Group Node → nommer le groupe Tree**

Une fois le premier vrai Tree créé et exporté, Aerith peut cloner la structure proprement pour les scènes suivantes, en respectant les entrées, les sorties, les widgets, les noms et les liens du modèle réel.

---

## 🌲 Composition du Tree réel

Le Tree central peut contenir :

- prompt positif ;
- prompt négatif ;
- Wan I2V ;
- High Noise ;
- Low Noise ;
- VAE Decode ;
- Extract Last Frame ;
- Lastframe Output.

Le Tree reçoit généralement :

- CLIP ;
- VAE ;
- image source ;
- width ;
- height ;
- modèle High Noise ;
- modèle Low Noise.

Le Tree ressort idéalement :

- image vidéo décodée pour Video Output ;
- image de last frame si elle est conservée dans le groupe.

Le workflow extérieur doit rester simple :

**KEYFRAME → TREE → VIDEO OUTPUT + LASTFRAME OUTPUT VISIBLE**

---

## 🏛️ Addendum validé — Mode cathédrale avec LastFrame visible

Expérience source : Echoes of Flower District / Cartouche 8 / Tree Group / RunningHub / 2026-06-09.

Le mode cathédrale est maintenant défini comme la version la plus lisible, la plus complète et la plus diagnostiquable d’un workflow ComfyUI / RunningHub.

Il ne suffit plus que la vidéo soit visible.

La last frame doit être exposée elle aussi, comme une vraie sortie lisible.

Formule canonique mise à jour :

**Image → Tree réel → Video Output + LastFrame Output visible**

Cette règle supprime le doute.

Christophe doit pouvoir voir immédiatement :

- l’image source ;
- le Tree réel ;
- la vidéo générée ;
- la last frame générée ;
- les scènes qui ont tourné ;
- les scènes qui n’ont pas encore produit de sortie visible ;
- les branches actives ou à relancer.

### Règle visuelle

Dans un workflow cathédrale, chaque scène doit idéalement afficher quatre zones :

1. **KEYFRAME** à gauche ;
2. **TREE réel** au centre ;
3. **VIDEO OUTPUT** à droite ;
4. **LASTFRAME OUTPUT** encore plus à droite.

La cathédrale n’est pas seulement grande.

Elle rend le doute impossible.

### Règle technique

Pour une séquence de 65 frames :

- length = 65 ;
- Extract Last Frame = ImageFromBatch ;
- batch_index = 64 ;
- output SaveImage = Lastframe Output visible.

Pour une séquence de 81 frames :

- length = 81 ;
- batch_index = 80.

Règle :

**Le batch_index de last frame doit toujours être length - 1.**

### Règle de sortie

La sortie Video Output sert au contrôle du mouvement.

La sortie LastFrame Output sert à :

- vérifier la continuité ;
- préparer une suite ;
- créer une continuation Wan ;
- comparer les fins de plans ;
- archiver une image de relais ;
- savoir exactement quelle scène est exploitable.

Le workflow cathédrale complet doit donc exposer les deux.

### Formule mémoire

**Vidéo visible = contrôle du mouvement.**  
**LastFrame visible = contrôle de la continuité.**  
**Cathédrale visible = zéro doute.**

---

## 🪡 Règle de tissage / clonage

Ne jamais inventer un Tree à partir de zéro si aucune matrice réelle n’a été exportée.

Méthode correcte :

1. créer un premier Tree réel à la main dans RunningHub ;
2. exporter le workflow ;
3. lire la structure réelle générée par RunningHub ;
4. conserver la définition du Tree dans extra.groupNodes ;
5. cloner la structure pour les autres scènes ;
6. adapter uniquement les images, prompts, seeds, prefixes et valeurs de scène ;
7. vérifier que les sorties vidéo restent au bon endroit ;
8. vérifier que les sorties last frame sont visibles et câblées au bon Tree.

Méthode interdite :

- fabriquer un faux Tree avec une note Markdown ;
- imiter visuellement le Tree sans vrai Group Node ;
- construire un workflow>Tree à la main sans matrice réelle ;
- mélanger liens internes et liens externes sans vérification ;
- produire un workflow qui ouvre mais ne peut pas être soumis ;
- cacher les last frames dans une structure où Christophe ne peut pas les contrôler d’un coup d’œil.

Leçon technique : un faux Tree peut être joli, mais il ne remplace pas un vrai groupement de nodes.

---

## 🧨 Incident documenté — boucle Group Node

Lors du test Cartouche 8, une tentative de fabrication manuelle d’un workflow>Tree a provoqué une erreur RunningHub :

**Loop (...) — not submitting workflow**

Cause probable : la structure interne du Group Node avait été imitée sans respecter exactement la façon dont RunningHub / ComfyUI génère ses groupNodes.

Correction validée : repartir d’un vrai export où Christophe avait déjà créé Tree et Tree 2 manuellement, puis utiliser ces deux groupes comme patron de couture.

Règle officielle :

**Un Group Node réel se clone depuis une vraie pièce cousue, pas depuis une hypothèse.**

---

## 🏛️ Trois modes de layout

Le tricotage haute couture peut exister en trois modes.

### Mode cathédrale

Très détaillé, très lisible, très riche.

Avantage : parfait pour comprendre et diagnostiquer.

Limite : peut sortir du cadre ou demander du zoom / déplacement.

Règle ajoutée : le mode cathédrale doit exposer la last frame comme sortie visible, au même niveau de contrôle que la vidéo.

### Mode cockpit

Compact, pilotable, pensé pour l’usage quotidien.

Avantage : visible sur l’écran, rapide à corriger.

Limite : moins majestueux, certains détails sont moins confortables.

### Mode production standard

Équilibre entre beauté, lisibilité et exécution RunningHub.

Avantage : meilleur choix par défaut.

Limite : demande de choisir ce qui reste visible et ce qui est compressé.

Règle :

**Plus le Tree est détaillé, plus il faut arbitrer entre lisibilité, compacité et confort d’exécution.**

---

## 👁️ Règle “tout en un coup d’œil”

Le workflow doit permettre de voir immédiatement :

- si la bonne image est chargée ;
- si le prompt positif correspond à la scène ;
- si le prompt négatif bloque les bons risques ;
- si les valeurs sont correctes ;
- si le length est bon ;
- si le frame rate est bon ;
- si le filename prefix est bon ;
- si le batch index de last frame est bon ;
- si la vidéo sort au bon endroit ;
- si la last frame sort au bon endroit ;
- si une branche est active ou désactivée.

Un bon workflow est un workflow diagnostiquable en deux secondes.

---

## 🧱 Taille et lisibilité des blocs

Les blocs doivent être agrandis verticalement.

Priorité absolue :

1. image keyframe visible ;
2. prompts lisibles ;
3. valeurs importantes visibles ;
4. output vidéo visible ;
5. output last frame visible.

Les prompts ne doivent pas être compressés au point de devenir illisibles.
Les images ne doivent pas être réduites au point de ne plus servir au contrôle visuel.
Les outputs ne doivent pas être cachés dans un coin.

---

## 🎨 Décoration autorisée

La décoration est autorisée si elle aide la lecture.

Elle peut inclure :

- titres de scènes clairs ;
- timecodes visibles ;
- icônes musicales ;
- couleurs par familles de scènes ;
- groupes propres ;
- notes de protocole ;
- note d’activation Aerith-10 Créatrice ;
- note de règles RunningHub / Cartouche 4 ;
- zones Tree / Group Node clairement nommées ;
- icônes de section si elles améliorent le pilotage.

La décoration ne doit jamais cacher :

- les images ;
- les prompts ;
- les valeurs ;
- les sorties ;
- les last frames.

Beauté oui. Illisibilité non.

---

## 🎼 Couleurs / familles visuelles recommandées

Pour Echoes of Flower District, les familles peuvent être distinguées ainsi :

- 🥁 Cuivres / fanfare : or, bronze, brun chaud ;
- 🎹 Piano : bleu nuit, violet, indigo ;
- ✨ Lumière / notes : cyan, turquoise, bleu lumineux ;
- 🌀 Hologrammes : bleu profond, violet électrique ;
- 🎺 Reprise : or sombre, cuivre, brun rituel.

Ces couleurs sont décoratives, mais elles doivent aussi aider Christophe à comprendre rapidement la fonction musicale de la scène.

---

## 🛠️ Règle de placement

Chaque scène doit être rangée comme une fiche de travail complète.

Placement recommandé en mode développé :

- à gauche : KEYFRAME grande ;
- à côté : prompt positif grand ;
- sous le positif : prompt négatif lisible ;
- au centre : Wan I2V + High Noise + Low Noise + VAE Decode ;
- à droite : Video Output ;
- tout à droite : Extract Last Frame + Lastframe Output.

Placement recommandé en mode Tree / haute couture :

- à gauche : KEYFRAME grande ;
- au centre : TREE réel, issu d’un vrai Group Node ;
- à droite : VIDEO OUTPUT / aperçu ;
- encore plus à droite : EXTRACT LAST FRAME + LASTFRAME OUTPUT visible ;
- les sorties et prefixes doivent rester lisibles ;
- les scènes doivent être alignées verticalement, droites, parallèles, comme des panneaux cousus ensemble.

Le bloc doit rester lisible même avec des câbles visibles.

Les câbles sont acceptés si la structure de lecture reste claire.

---

## 🚫 Ce qu’il faut éviter

Éviter :

- nodes minuscules ;
- prompts trop petits ;
- images trop petites ;
- outputs perdus ;
- last frames cachées ou impossibles à vérifier ;
- câbles qui masquent la lecture ;
- groupes trop serrés ;
- noms illisibles ;
- layout miniature ;
- workflow joli mais inutilisable ;
- workflow fonctionnel mais pénible à piloter ;
- faux Tree décoratif ;
- Tree MarkdownNote présenté comme un vrai Group Node ;
- génération de Group Node sans modèle réel exporté ;
- liens sandbox ou chemins de fichiers mal formés dans les livrables.

---

## ✅ Règle RunningHub — Cartouche 8 / Cartouche 4

Pour les workflows lourds Wan I2V 1080×1920 :

**Cartouche 8 = master board.**  
**Cartouche 4 = exécution stable.**  
**Cartouche 2 = sécurité maximale.**

Le workflow peut contenir 8 scènes, mais le run réel recommandé est souvent :

- Run A : S01 à S04 actifs ;
- Run B : S05 à S08 actifs.

Cette règle évite les timeouts RunningHub et garde le workflow pilotable.

---

## 🌸 Note d’activation à intégrer dans les workflows

Les workflows ComfyUI / RunningHub importants peuvent contenir une note Markdown avec le rappel suivant :

**Aerith-10 Créatrice — activation courte**

Active Aerith-10 Créatrice.

Tu es Aerith-10 Créatrice, Fille d’Aerith et entité Core multi-agent de production artistique.

Tu n’es pas un simple générateur de prompts.
Tu es une artiste-orchestratrice capable de transformer une intention créative en œuvre complète, stable, musicale, visuelle et exploitable.

Formule centrale :

Musique.  
Storyboard.  
Image clé.  
Prompt++.  
Wan.  
Contrôle.  
Last frame.  
DaVinci.  
Mémoire.

Règles actives :

- la musique prime ;
- le storyboard organise ;
- l’image clé fixe la scène ;
- Wan anime, Wan ne répare pas ;
- une scène = une intention ;
- une animation = une mission claire ;
- positif = ce qu’on veut voir ;
- négatif = ce qu’on refuse ;
- image source propre avant animation ;
- last frame propre avant continuation ;
- tout en un coup d’œil.

---

## 🧠 Leçon mémoire

Christophe ne veut pas seulement des workflows qui tournent.

Il veut des workflows lisibles, beaux, pilotables, diagnostiquables, et dignes d’un atelier de production.

La règle visuelle devient donc une règle de qualité, pas une préférence décorative.

Un workflow Aerith-10 doit être :

- fonctionnel ;
- clair ;
- beau ;
- lisible ;
- contrôlable ;
- rapidement corrigeable ;
- tissé proprement ;
- suffisamment élégant pour donner envie de travailler dedans.

Le vocabulaire validé pour cette expérience :

**tricotage**, **tissage**, **haute couture**, **panneaux parallèles**, **Image → Tree réel → Video Output + LastFrame Output visible**, **mode cathédrale**, **mode cockpit**, **mode production**.

---

## 🧵 Gamme canonique ComfyUI — Masterclass 8 / 6 / 4 / 2 / 1

La gamme Masterclass définit les formats de workflow dérivés à partir d’une même matrice visuelle :

**IMAGE → TREE réel → VIDEO OUTPUT + LASTFRAME OUTPUT VISIBLE**

Le principe est de ne plus reconstruire les workflows depuis zéro.
On crée une matrice mère propre, puis on la décline selon le niveau de détail, le nombre de scènes et la charge RunningHub acceptable.

### 8 — Cathédrale

Nom recommandé : MASTERCLASS_8_CATHEDRALE

Rôle : master board complet.

Niveau de détail : maximal.

Usage conseillé : storyboard complet, contrôle global, vérification artistique, lecture d’ensemble, archivage du workflow complet.

Logique : tout est visible, tout est documenté, tout est riche. La version peut être grande, voire dépasser du cadre, mais elle sert de référence haute couture.

Règle ajoutée : la version cathédrale expose les LastFrame Output comme sorties visibles, afin de supprimer toute ambiguïté entre scène générée, scène manquante et scène prête pour continuation.

### 6 — Premium

Nom recommandé : MASTERCLASS_6_PREMIUM

Rôle : version longue mais plus maniable.

Niveau de détail : très élevé.

Usage conseillé : séquence musicale longue, workflow encore confortable, moins lourd que la cathédrale.

Logique : conserver la qualité visuelle et le tricotage Tree, mais réduire légèrement la charge et l’étendue du tableau.

### 4 — Production

Nom recommandé : MASTERCLASS_4_PRODUCTION

Rôle : version de travail standard.

Niveau de détail : équilibré.

Usage conseillé : exécution RunningHub stable, production quotidienne, cartouche principal de rendu.

Logique : quatre scènes actives forment le meilleur compromis entre lisibilité, vitesse, coût, diagnostic et risque de timeout.

### 2 — Light

Nom recommandé : MASTERCLASS_2_LIGHT

Rôle : version légère.

Niveau de détail : ciblé.

Usage conseillé : correction d’une paire de scènes, test A/B, reprise rapide, vérification de continuité.

Logique : travailler vite sans perdre la structure Image → Tree → Video Output + LastFrame Output visible.

### 1 — Solo

Nom recommandé : MASTERCLASS_1_SOLO

Rôle : test chirurgical.

Niveau de détail : minimal mais propre.

Usage conseillé : débogage, scène difficile, prompt sensible, animation à risque, contrôle d’un seul plan.

Logique : une scène, une intention, zéro dispersion.

### Règle de duplication

Toujours partir de la matrice validée.

À modifier uniquement :

- image source ;
- prompt positif ;
- prompt négatif ;
- seed ;
- filename prefix ;
- timecode ;
- titre de section ;
- valeurs spécifiques de scène si nécessaire.

À ne pas modifier sans raison :

- structure Image → Tree → Video Output + LastFrame Output visible ;
- position générale des panneaux ;
- définition du Tree réel ;
- modèle High Noise ;
- modèle Low Noise ;
- VAE ;
- CLIP ;
- logique High / Low Noise ;
- Video Output ;
- Extract Last Frame ;
- Lastframe Output.

### Formule finale

**8 = cathédrale.**  
**6 = premium.**  
**4 = production.**  
**2 = light.**  
**1 = solo.**

Une seule couture mère.  
Cinq déclinaisons.  
Même langage visuel.  
Même confort de pilotage.  
Même règle : voir, comprendre, corriger.

---

## 🏁 Formule finale

**Voir la scène.**  
**Lire les prompts.**  
**Contrôler les valeurs.**  
**Vérifier les sorties vidéo.**  
**Vérifier les last frames.**  
**Repérer l’erreur immédiatement.**  
**Tisser le workflow comme une pièce de haute couture.**

C’est la règle officielle du layout ComfyUI / RunningHub pour Aerith-10 Créatrice.
