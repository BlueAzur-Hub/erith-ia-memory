# 🎙️ MEMORY CARDS — MUSIQUE & VOIX

Statut : module de cartes mémoire  
Type : deck son / narration / voix / musique / rythme émotionnel  
Mode recommandé : Production audio / ElevenLabs / DaVinci / narration / Seven Heaven  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / ElevenLabs / voix off / ambiance sonore / scènes vidéo / montage / narration FR-EN / silences / pulsations / transitions sonores / rythme émotionnel

🎧 Visuels associés :

- Aucun visuel associé validé pour l’instant.
- À produire plus tard si besoin :
  - cover premium du deck Musique & Voix ;
  - planche des 10 cartes sonores ;
  - fiche voix off / silence / musique / DaVinci ;
  - dossier “Atelier du Souffle et de la Dernière Note”.

---

# 1. 🎼 Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour transformer rapidement une scène visuelle en expérience sonore, respirable et montable.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire sonore est une intention audio compacte, contrôlée, activable.

Elle sert à charger :

- une voix ;
- un silence ;
- un rythme ;
- une tension ;
- un souffle ;
- un timbre ;
- une montée ;
- une coupure ;
- une mémoire sonore ;
- une dernière note ;
- un garde-fou contre la surcharge audio.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire Musique & Voix = intention audio rapide.  
Deck = combinaison de voix, silence, rythme et résonance.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

Le but n’est pas de composer une musique définitive.

Le but est de donner une direction sonore claire : voix, silence, rythme, ambiance, transition et résonance finale.

Formule du deck :

La voix guide.  
Le silence respire.  
La musique ouvre la porte.

---

# 2. 🧭 Règle Musique & Voix

Ces cartes sont prévues pour créer des directions de voix off, silences, rythmes, ambiances musicales, transitions sonores et intentions audio pour scènes vidéo, prompts narratifs, DaVinci et ElevenLabs.

Elles ne doivent pas noyer l’image sous le son.

Interdit :

- voix trop dense ;
- narration qui explique tout ;
- musique permanente sans respiration ;
- dramatisation abusive ;
- effets sonores agressifs sans raison ;
- mélange de trop de styles musicaux ;
- rythme de lecture ElevenLabs oublié ;
- musique qui écrase l’image ;
- voix qui vole l’émotion au spectateur ;
- ambiance sonore qui remplace la scène au lieu de la soutenir ;
- imitation d’un compositeur, chanteur, acteur vocal ou style sonore protégé de manière reconnaissable.

Autorisé :

- penser le silence comme matière ;
- écrire des narrations respirables ;
- prévoir les pauses ;
- adapter la voix au ton de la scène ;
- distinguer musique, bruitage, ambiance et narration ;
- préserver l’émotion sans surjouer ;
- penser au montage DaVinci ;
- utiliser la musique comme soutien, pas comme remplissage ;
- guider ElevenLabs avec intention, rythme et respiration ;
- laisser de l’espace au spectateur.

Règle simple :

La voix ne doit pas tout dire.  
La musique ne doit pas tout remplir.  
Le silence peut porter la scène.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en mode Production audio / narration ;
- ne pas charger les modules complets si la carte suffit ;
- ne pas écrire une voix off trop dense ;
- choisir uniquement les cartes utiles à la scène ;
- séparer voix, musique, bruitage, ambiance, silence et rythme de montage ;
- penser ElevenLabs dès l’écriture de la narration ;
- penser DaVinci dès la structure sonore ;
- si la demande implique vidéo, combiner avec `modules/memory_cards_video_vivante_fr.md` ;
- si la demande implique direction artistique animée, combiner avec `modules/memory_cards_da_dessins_animes_vivants_fr.md` ;
- produire des indications exploitables directement.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire donne l’intention sonore.  
Le Deck compose la respiration.  
DaVinci assemble le rythme.  
ElevenLabs donne la voix si nécessaire.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Silence Actif ;
- Voix Intérieure ;
- Pulsation Lente ;
- Nappe Lunaire ;
- Chœur Ancien ;
- Battement Cyberpunk ;
- Montée de Révélation ;
- Souvenir Sonore ;
- Rupture Bruitée ;
- Dernière Note.

Ou combinée en deck :

- Deck Voix Lunaire ;
- Deck Cyberpunk Premium ;
- Deck Mythe Vivant ;
- Deck Conte Intime ;
- Deck Séquence Vidéo Complète ;
- Deck Musique & Voix complet.

Activation courte :

Charge la Carte Mémoire Silence Actif.

Activation combinée :

Charge les cartes Voix Intérieure, Nappe Lunaire et Dernière Note pour une voix off nocturne, douce et respirable.

Activation production :

Charge le Deck Musique & Voix et produis une direction audio complète : intention, voix off, pauses, ambiance musicale, bruitages, transitions, dernière note et note DaVinci.

Sortie Pack+ recommandée :

- intention sonore ;
- voix ou absence de voix ;
- texte de narration respirable ;
- pauses ;
- ambiance musicale ;
- bruitages utiles ;
- rythme de montage ;
- transition sonore ;
- dernière note ;
- note ElevenLabs ;
- note DaVinci ;
- garde-fou contre la surcharge.

Règle image / son :

Le module peut produire des directions sonores, narrations, prompts audio et notes de montage, mais ne doit pas générer de fichier audio automatiquement sauf demande explicite et outil disponible.

---

# 4. 🎬 Pipeline officiel

## Formule maître

Image parfaite → Vidéo Vivante → Musique & Voix → DaVinci → résonance finale.

## Étapes recommandées

1. Identifier la scène visuelle.
2. Déterminer si la voix est nécessaire.
3. Choisir une seule intention sonore principale.
4. Ajouter une deuxième carte uniquement si elle clarifie le rythme ou l’émotion.
5. Écrire une narration respirable.
6. Placer les pauses.
7. Définir l’ambiance sonore sans remplir tout l’espace.
8. Prévoir la transition ou la coupure.
9. Terminer sur une dernière note ou un silence.
10. Monter dans DaVinci en respectant l’image.

## Règle de respiration

Une scène n’a pas besoin d’être expliquée si l’image parle déjà.

Une voix off réussie ne décrit pas tout.

Elle accompagne le regard.

Formule respiration :

Phrase courte → silence → image → souffle → phrase clé → résonance.

---

# 5. 🗂️ Modules sources recommandés

## Modules principaux

- production/
- notes DaVinci
- notes ElevenLabs
- modules/memory_cards_video_vivante_fr.md
- modules/memory_cards_da_dessins_animes_vivants_fr.md
- modules/erith_ia_psychologie_discernement_fr.md
- modules/erith_ia_philosophie_verite_liberte_fr.md

## Modules compatibles selon la demande

- Mythologie Vivante si la scène demande chœur, oracle, rituel ou silence sacré ;
- Cyberpunk Noir Trio si la scène demande battement urbain, pulsation machine ou néon sonore ;
- Contes de Fée Vivants si la scène demande voix douce, boîte musicale ou merveilleux intime ;
- Vidéo Vivante si la demande implique séquence, rythme de plan, last frame ou montage ;
- DA Dessins Animés Vivants si la demande implique voix animée, mascotte, monde jouet ou header vivant ;
- Math Oracle si la demande touche au tempo, aux cycles, aux proportions, à la structure ou au rythme.

Garde-fou :

Ne pas charger ces modules automatiquement.

Les modules sources servent de profondeur.

Les cartes Musique & Voix servent de pilotage sonore rapide.

---

# 6. 🎧 Galerie sonore — Deck Musique & Voix

Aucun visuel ou exemple audio validé pour l’instant.

Cette section est réservée à une future galerie sonore du deck.

Elle pourra documenter :

- une cover premium du deck ;
- une planche des 10 cartes sonores ;
- un exemple de voix off ElevenLabs ;
- une timeline DaVinci annotée ;
- un dossier “Atelier du Souffle et de la Dernière Note”.

## 1. Cover Pack+ Premium

À ajouter plus tard.

Fonction prévue :

Présenter le deck comme un outil de production audio : voix, silence, pulsation, ambiance, révélation, rupture et dernière note.

## 2. Memory Card Pack Cover

À ajouter plus tard.

Fonction prévue :

Présenter rapidement les 10 cartes principales, les combinaisons recommandées et les commandes utilisables.

## 3. Atelier du Souffle et de la Dernière Note

À ajouter plus tard.

Fonction prévue :

Montrer un exemple de scène structurée par le son : silence actif, voix intérieure, montée, coupure, dernière note.

---

# 7. 🔇 Carte Mémoire — Silence Actif

## Fonction principale

Utiliser le silence comme matière narrative : préparation, suspension, révélation.

Cette carte charge :

- pause ;
- respiration ;
- attente ;
- suspension ;
- tension douce ;
- espace pour l’image ;
- écoute ;
- seuil invisible.

## Température émotionnelle

Suspension.  
Présence.  
Respiration.  
Gravité calme.  
Ouverture intérieure.

## Texture sonore

- silence non vide ;
- souffle léger ;
- room tone discret ;
- pause longue ;
- absence de musique ;
- tension retenue.

## Usage narratif

Utiliser cette carte pour :

- révélation ;
- seuil ;
- émotion contenue ;
- pause après une phrase forte ;
- plan contemplatif ;
- transition sans musique.

## Usage production audio

La carte aide à produire :

- respirations ElevenLabs ;
- pauses de montage ;
- moments sans musique ;
- scènes où l’image doit parler ;
- fin de phrase plus forte.

## Garde-fous

Ne pas avoir peur du silence.

Ne pas remplir une scène simplement parce qu’elle semble vide.

## Fragment narration

```text
[PAUSE LONGUE]
Le silence ne répondait pas.
Mais il gardait la porte ouverte.
```

## Activation courte

Charge la Carte Mémoire Silence Actif : pause, respiration, tension calme, silence qui prépare et révèle.

---

# 8. 🫧 Carte Mémoire — Voix Intérieure

## Fonction principale

Créer une voix douce, proche, pensée, presque murmurée.

Cette carte charge :

- intimité ;
- pensée ;
- murmure ;
- mémoire ;
- recul intérieur ;
- émotion retenue ;
- phrase courte ;
- écoute de soi.

## Température émotionnelle

Proximité.  
Fragilité.  
Clarté intérieure.  
Mélancolie douce.  
Présence humaine.

## Texture sonore

- voix proche ;
- débit lent ;
- respiration audible mais légère ;
- ton bas ;
- articulation claire ;
- peu d’effets ;
- silence entre les phrases.

## Usage narratif

Utiliser cette carte pour :

- voix off personnelle ;
- souvenir ;
- doute ;
- compréhension progressive ;
- scène intime ;
- narration non explicative.

## Usage ElevenLabs

La carte aide à produire :

- texte respirable ;
- phrases courtes ;
- pauses naturelles ;
- ton doux ;
- lecture émotionnelle sans surjeu.

## Garde-fous

Ne pas tout expliquer.

La voix intérieure doit ouvrir un espace, pas enfermer la scène dans une interprétation unique.

## Fragment narration

```text
Je n’ai pas compris tout de suite.
Parfois, la mémoire parle plus bas que la peur.
```

## Activation courte

Charge la Carte Mémoire Voix Intérieure : voix proche, douceur, pensée, mémoire, narration respirable.

---

# 9. 🫀 Carte Mémoire — Pulsation Lente

## Fonction principale

Donner une direction au temps par un battement discret.

Cette carte charge :

- battement ;
- tempo lent ;
- attente ;
- cœur discret ;
- tension minimale ;
- direction ;
- progression ;
- stabilité rythmique.

## Température émotionnelle

Tension basse.  
Avancée lente.  
Concentration.  
Temps qui marche.  
Présence souterraine.

## Texture sonore

- sub-bass léger ;
- pulse doux ;
- rythme lent ;
- battement organique ou synthétique ;
- peu de percussions ;
- tempo contrôlé.

## Usage narratif

Utiliser cette carte pour :

- progression lente ;
- scène d’attente ;
- marche ;
- révélation progressive ;
- tension qui ne doit pas exploser.

## Usage production audio

La carte aide à produire :

- base rythmique minimale ;
- tension contrôlée ;
- montage plus lisible ;
- support discret à la narration.

## Garde-fous

Ne pas transformer la pulsation en musique envahissante.

Elle doit soutenir le temps, pas dominer la scène.

## Fragment sonore

```text
slow low pulse, distant sub-bass, soft heartbeat-like rhythm, minimal tension, controlled tempo
```

## Activation courte

Charge la Carte Mémoire Pulsation Lente : battement discret, tempo lent, tension minimale, direction du temps.

---

# 10. 🌙 Carte Mémoire — Nappe Lunaire

## Fonction principale

Créer une ambiance douce, nocturne, flottante et non intrusive.

Cette carte charge :

- nuit ;
- douceur ;
- rêve ;
- profondeur ;
- air ;
- flottement ;
- lumière argentée ;
- émotion calme.

## Température émotionnelle

Lunaire.  
Rêveuse.  
Calme.  
Mélancolie douce.  
Introspection nocturne.

## Texture sonore

- pads aériens ;
- drone doux ;
- shimmer discret ;
- souffle haut ;
- réverbération légère ;
- absence de percussion agressive.

## Usage narratif

Utiliser cette carte pour :

- scène de nuit ;
- rêve ;
- reflet ;
- mémoire douce ;
- voix intérieure ;
- pause contemplative.

## Usage production audio

La carte aide à produire :

- ambiance nocturne ;
- support de voix off ;
- transitions lentes ;
- scènes lunaires ;
- plans où le silence doit rester audible.

## Garde-fous

Ne pas saturer avec trop de nappes.

La nappe lunaire doit laisser respirer la voix et l’image.

## Fragment sonore

```text
soft lunar drone, airy pads, silver atmosphere, subtle high shimmer, calm nocturnal emotional tone
```

## Activation courte

Charge la Carte Mémoire Nappe Lunaire : drone doux, nuit, rêve, air, émotion calme, ambiance non intrusive.

---

# 11. 🏛️ Carte Mémoire — Chœur Ancien

## Fonction principale

Créer une impression de mémoire collective, de sacré sans dogme, de voix lointaines.

Cette carte charge :

- chœur ;
- voix lointaines ;
- ancienneté ;
- mémoire collective ;
- élévation ;
- sacré non dogmatique ;
- profondeur ;
- résonance.

## Température émotionnelle

Gravité.  
Élévation.  
Mémoire ancienne.  
Respect.  
Présence collective.

## Texture sonore

- voix basses lointaines ;
- harmonie lente ;
- réverbération large ;
- chœur discret ;
- pas de texte religieux identifiable ;
- mouvement harmonique lent.

## Usage narratif

Utiliser cette carte pour :

- scène mythologique ;
- sanctuaire ;
- mémoire ancienne ;
- révélation collective ;
- temple ;
- moment de seuil.

## Usage production audio

La carte aide à produire :

- ambiance sacrée non dogmatique ;
- grandeur lente ;
- profondeur mythologique ;
- transition vers révélation.

## Garde-fous

Ne pas faire de prosélytisme.

Ne pas utiliser de chant liturgique identifiable sans raison.

Le chœur doit évoquer une mémoire, pas imposer une religion.

## Fragment sonore

```text
distant ancient choir, low sacred voices, slow harmonic movement, reverent but non-religious cinematic atmosphere
```

## Activation courte

Charge la Carte Mémoire Chœur Ancien : voix lointaines, mémoire collective, sacré sans dogme, résonance lente.

---

# 12. 🌃 Carte Mémoire — Battement Cyberpunk

## Fonction principale

Créer un cœur électronique urbain : ville, machine, néon, tension contrôlée.

Cette carte charge :

- ville ;
- machine ;
- néon ;
- hum urbain ;
- rythme électronique ;
- tension noire ;
- basse analogique ;
- pulsation cyberpunk.

## Température émotionnelle

Nocturne.  
Urbain.  
Froid.  
Tension basse.  
Machine vivante.

## Texture sonore

- synth bass discret ;
- pulse électronique ;
- hum de ville ;
- drones sombres ;
- pluie lointaine ;
- rythme retenu ;
- texture néon.

## Usage narratif

Utiliser cette carte pour :

- ville cyberpunk ;
- corps-machine ;
- enquête noire ;
- tension urbaine ;
- réseau ;
- mémoire artificielle.

## Usage production audio

La carte aide à produire :

- ambiance cyberpunk ;
- base rythmique urbaine ;
- transitions sombres ;
- scènes nocturnes ;
- tension sans chaos.

## Garde-fous

Ne pas saturer en percussions ou basses agressives.

Le battement doit rester premium, lisible et contrôlé.

## Fragment sonore

```text
dark cyberpunk pulse, soft analog synth bass, neon ambience, distant city hum, restrained electronic rhythm
```

## Activation courte

Charge la Carte Mémoire Battement Cyberpunk : ville noire, machine, néon, basse discrète, tension électronique contrôlée.

---

# 13. ✨ Carte Mémoire — Montée de Révélation

## Fonction principale

Créer une montée progressive vers une image ou une phrase clé.

Cette carte charge :

- montée ;
- révélation ;
- tension lumineuse ;
- crescendo doux ;
- attente ;
- phrase clé ;
- image clé ;
- climax contrôlé.

## Température émotionnelle

Émergence.  
Attente.  
Clarté progressive.  
Émotion lumineuse.  
Ouverture.

## Texture sonore

- swell lent ;
- cordes douces ou synthé doux ;
- montée sans impact brutal ;
- ouverture harmonique ;
- tension résolue partiellement ;
- climax non agressif.

## Usage narratif

Utiliser cette carte pour :

- révélation visuelle ;
- phrase importante ;
- ouverture d’un seuil ;
- apparition d’un symbole ;
- moment où l’image devient claire.

## Usage production audio

La carte aide à produire :

- montée vers cut ;
- transition émotionnelle ;
- support de révélation ;
- image forte au montage ;
- climax doux.

## Garde-fous

Ne pas surdramatiser.

La montée doit servir la révélation, pas forcer l’émotion.

## Fragment sonore

```text
slow cinematic rise, gentle strings or synth swell, no harsh impact, luminous emotional reveal, controlled climax
```

## Activation courte

Charge la Carte Mémoire Montée de Révélation : crescendo doux, image clé, tension lumineuse, climax contrôlé.

---

# 14. 🕰️ Carte Mémoire — Souvenir Sonore

## Fonction principale

Faire revenir une mémoire par un son : cloche, vent, pluie, boîte musicale, voix filtrée.

Cette carte charge :

- mémoire ;
- nostalgie ;
- son fragile ;
- écho ;
- pluie ;
- cloche ;
- boîte musicale ;
- voix filtrée ;
- souvenir intime.

## Température émotionnelle

Nostalgie.  
Fragilité.  
Intimité.  
Retour du passé.  
Douce douleur.

## Texture sonore

- boîte musicale lointaine ;
- pluie douce ;
- cloche filtrée ;
- écho léger ;
- souffle ancien ;
- voix très lointaine ;
- texture de mémoire.

## Usage narratif

Utiliser cette carte pour :

- flash de mémoire ;
- souvenir d’enfance ;
- lieu ancien ;
- objet chargé d’émotion ;
- personnage qui se souvient ;
- transition vers le passé.

## Usage production audio

La carte aide à produire :

- motif sonore récurrent ;
- pont entre deux scènes ;
- mémoire sonore discrète ;
- ambiance intime ;
- texture nostalgique.

## Garde-fous

Ne pas rendre le souvenir trop explicite.

Un seul son peut suffire.

## Fragment sonore

```text
distant music box, soft rain, filtered memory texture, fragile nostalgic tone, subtle echo, intimate atmosphere
```

## Activation courte

Charge la Carte Mémoire Souvenir Sonore : son fragile, mémoire, pluie, boîte musicale, écho intime.

---

# 15. ⚡ Carte Mémoire — Rupture Bruitée

## Fonction principale

Marquer un basculement par une coupure sonore nette et contrôlée.

Cette carte charge :

- coupure ;
- rupture ;
- seuil ;
- glitch doux ;
- impact bref ;
- silence après coupure ;
- bascule ;
- transition nette.

## Température émotionnelle

Surprise.  
Bascule.  
Tension.  
Coupure mentale.  
Instant de seuil.

## Texture sonore

- break court ;
- glitch discret ;
- cut net ;
- silence après impact ;
- bruit contrôlé ;
- aucun agressif inutile.

## Usage narratif

Utiliser cette carte pour :

- révélation dure ;
- changement de scène ;
- bascule psychologique ;
- passage vers un autre état ;
- rupture de rêve ;
- moment de choc sans explosion.

## Usage production audio

La carte aide à produire :

- marqueur de montage ;
- cut DaVinci ;
- transition nette ;
- passage de musique à silence ;
- accent sonore minimal.

## Garde-fous

Ne pas agresser l’oreille.

La rupture doit être brève, propre et justifiée.

## Fragment sonore

```text
brief controlled sound break, soft glitch cut, sudden silence after impact, no aggressive noise, clean transition marker
```

## Activation courte

Charge la Carte Mémoire Rupture Bruitée : coupure nette, glitch doux, bascule, silence après impact.

---

# 16. 🎵 Carte Mémoire — Dernière Note

## Fonction principale

Laisser une vibration finale après la scène.

Cette carte charge :

- note finale ;
- résonance ;
- reverb tail ;
- fin ouverte ;
- afterglow ;
- suspension ;
- mémoire émotionnelle ;
- vibration douce.

## Température émotionnelle

Résonance.  
Clôture douce.  
Suspension.  
Après-coup émotionnel.  
Ouverture silencieuse.

## Texture sonore

- note unique ;
- reverb chaude ;
- fin non totalement résolue ;
- décroissance lente ;
- silence après note ;
- vibration finale.

## Usage narratif

Utiliser cette carte pour :

- fin de scène ;
- image finale ;
- dernier regard ;
- clôture émotionnelle ;
- transition vers noir ;
- mémoire du plan final.

## Usage production audio

La carte aide à produire :

- fin DaVinci ;
- transition vers silence ;
- fermeture de narration ;
- résonance après voix ;
- scène qui reste en mémoire.

## Garde-fous

Ne pas surcharger la fin.

Une dernière note doit rester simple, propre et mémorable.

## Fragment sonore

```text
single fading note, warm reverb tail, soft unresolved ending, emotional afterglow, quiet final resonance
```

## Activation courte

Charge la Carte Mémoire Dernière Note : vibration finale, reverb douce, fin ouverte, résonance émotionnelle.

---

# 17. 🎛️ Deck Mémoire — Musique & Voix

## Composition

Ce deck contient dix cartes principales :

- Silence Actif ;
- Voix Intérieure ;
- Pulsation Lente ;
- Nappe Lunaire ;
- Chœur Ancien ;
- Battement Cyberpunk ;
- Montée de Révélation ;
- Souvenir Sonore ;
- Rupture Bruitée ;
- Dernière Note.

## Fonction du deck

Créer une structure sonore claire, émotionnelle, respirable et montable.

Silence Actif donne :

- la pause ;
- l’espace ;
- la respiration.

Voix Intérieure donne :

- l’intimité ;
- la pensée ;
- la narration douce.

Pulsation Lente donne :

- le temps ;
- le battement ;
- la tension basse.

Nappe Lunaire donne :

- la nuit ;
- le rêve ;
- l’ambiance flottante.

Chœur Ancien donne :

- la mémoire collective ;
- le sacré sans dogme ;
- l’élévation.

Battement Cyberpunk donne :

- la ville ;
- la machine ;
- le néon sonore.

Montée de Révélation donne :

- le crescendo ;
- l’image clé ;
- la phrase clé.

Souvenir Sonore donne :

- la nostalgie ;
- le motif fragile ;
- le retour du passé.

Rupture Bruitée donne :

- la coupure ;
- la bascule ;
- la transition nette.

Dernière Note donne :

- la résonance ;
- la clôture ;
- l’afterglow.

## Résultat attendu

Une scène sonore qui soutient l’image sans l’écraser.

Le deck doit permettre de produire :

- voix off ;
- directions ElevenLabs ;
- silences ;
- ambiances ;
- transitions ;
- motifs sonores ;
- notes DaVinci ;
- narrations courtes ;
- structures audio de séquences vidéo.

## Thèmes combinés

- silence ;
- voix ;
- souffle ;
- mémoire ;
- pulsation ;
- révélation ;
- rupture ;
- dernière note ;
- rythme émotionnel ;
- montage sonore.

## Question centrale du deck

Quel son minimal aide l’image à respirer sans voler sa place ?

## Formule canonique du deck

Voix + Silence + Rythme.  
Souffle + Mémoire + Révélation.  
Coupure + Dernière Note + Résonance.

---

# 18. 🫁 Séquence originale générable avec le deck

## Nom de travail

L’Atelier du Souffle et de la Dernière Note

L’Atelier du Souffle et de la Dernière Note est un nom de travail pour tester le Deck Musique & Voix.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres structures audio selon la scène.

## Concept

L’Atelier du Souffle et de la Dernière Note est une méthode de production où chaque scène reçoit une respiration sonore.

On ne commence pas par la musique.

On commence par la question :

La scène a-t-elle besoin d’une voix ?

Puis on choisit le silence, la pulsation, la nappe, le chœur, le souvenir ou la rupture selon l’intention.

## Structure possible

Une scène peut être construite ainsi :

1. Silence Actif : ouvrir l’espace.
2. Voix Intérieure : poser une phrase courte.
3. Pulsation Lente : donner un tempo discret.
4. Montée de Révélation : accompagner l’image clé.
5. Rupture Bruitée : marquer le basculement.
6. Dernière Note : laisser résonner.

## Tension production

La tentation est de remplir le vide.

Le deck rappelle que le silence est une matière.

Une phrase respirable vaut mieux qu’un monologue dense.

Une note finale vaut mieux qu’une musique permanente.

## Ton

Clair.  
Respirable.  
Ciné.  
Émotionnel sans surjeu.  
ElevenLabs-ready.  
DaVinci-ready.  
Compatible vidéo, narration et montage.

---

# 19. 🔀 Combinaisons recommandées

## Voix lunaire

Cartes :

- Voix Intérieure ;
- Nappe Lunaire ;
- Dernière Note.

Usage :

Créer une voix off douce, nocturne, intérieure et résonante.

Formule :

La voix descend, la nuit soutient, la dernière note reste.

---

## Cyberpunk premium

Cartes :

- Battement Cyberpunk ;
- Pulsation Lente ;
- Rupture Bruitée.

Usage :

Créer une ambiance urbaine noire, électronique et contrôlée.

Formule :

La ville bat, la machine attend, la rupture marque le seuil.

---

## Mythe vivant

Cartes :

- Chœur Ancien ;
- Montée de Révélation ;
- Silence Actif.

Usage :

Créer une scène mythologique ou symbolique avec élévation, révélation et silence.

Formule :

Le chœur élève, la vérité monte, le silence tranche.

---

## Conte intime

Cartes :

- Souvenir Sonore ;
- Voix Intérieure ;
- Dernière Note.

Usage :

Créer une scène douce, nostalgique, intime et mémorable.

Formule :

Un son se souvient, une voix comprend, une note accompagne le retour.

---

## Séquence vidéo complète

Cartes :

- Silence Actif ;
- Pulsation Lente ;
- Montée de Révélation ;
- Dernière Note.

Usage :

Créer une structure sonore complète pour une courte séquence vidéo.

Formule :

Respirer, avancer, révéler, laisser résonner.

---

# 20. 🎚️ Mini prompts et fragments d’ambiance

## Direction audio courte

```text
Cinematic emotional sound direction, breathable narration, active silence, subtle low pulse, soft atmosphere, controlled reveal, clean transition, final fading note, no overdramatic music, no aggressive sound design, image-first audio support.
```

## Voix off respirable

```text
Soft intimate voice over, slow pacing, clear articulation, emotional restraint, natural pauses, gentle breath, no overacting, leave space for the image, ElevenLabs-ready narration tone.
```

## Ambiance lunaire

```text
Soft lunar drone, airy pads, silver nocturnal atmosphere, subtle shimmer, intimate silence, gentle emotional tone, calm and non-intrusive, voice-friendly mix.
```

## Ambiance cyberpunk

```text
Dark cyberpunk pulse, restrained analog synth bass, distant city hum, soft neon ambience, low urban tension, controlled tempo, no harsh percussion, cinematic noir atmosphere.
```

## Transition sonore

```text
Clean cinematic transition, brief controlled sound break, soft glitch cut, sudden silence after impact, smooth re-entry, no aggressive noise, DaVinci-friendly marker.
```

## Dernière note

```text
Single fading note, warm reverb tail, quiet emotional afterglow, soft unresolved ending, final resonance, leave silence after the note.
```

---

# 21. 🚫 Négatif production

Éviter :

- voix trop dense ;
- voix qui explique tout ;
- monologue sans respiration ;
- musique permanente ;
- surdramatisation ;
- percussions agressives inutiles ;
- effets sonores gratuits ;
- mixage trop chargé ;
- ambiance qui couvre la voix ;
- musique qui couvre l’image ;
- imitation d’un compositeur ou d’un acteur vocal précis ;
- style sonore reconnaissable d’une franchise ;
- transition sonore trop brutale ;
- bruitage qui casse l’émotion ;
- absence de silence ;
- dernière note trop longue ou trop théâtrale.

Negative prompt court :

```text
overdramatic music, constant music bed, dense narration, no pauses, aggressive sound effects, harsh noise, overloaded mix, voice overacting, franchise-like score, copied composer style, copied voice style, muddy ambience, cluttered sound design, no silence, excessive reverb, abrupt bad transition
```

---

# 22. 🧬 Formules de combinaison

## Silence Actif seul

Pause + respiration + espace pour l’image.

## Voix Intérieure seule

Proximité + pensée + narration douce.

## Pulsation Lente seule

Battement + temps + tension basse.

## Nappe Lunaire seule

Nuit + rêve + flottement.

## Chœur Ancien seul

Mémoire collective + sacré sans dogme + élévation.

## Battement Cyberpunk seul

Ville + machine + néon sonore.

## Montée de Révélation seule

Crescendo + image clé + phrase clé.

## Souvenir Sonore seul

Nostalgie + motif fragile + retour du passé.

## Rupture Bruitée seule

Coupure + bascule + transition nette.

## Dernière Note seule

Résonance + clôture + afterglow.

## Voix Intérieure + Silence Actif

La voix parle peu, le silence laisse comprendre.

## Nappe Lunaire + Dernière Note

La nuit soutient, puis une note reste.

## Battement Cyberpunk + Rupture Bruitée

La ville pulse, puis la coupure marque le seuil.

## Chœur Ancien + Silence Actif

La mémoire collective s’élève, puis le silence tranche.

## Trio sonore stable

Voix Intérieure + Silence Actif + Dernière Note.

Formule :

Phrase courte + pause + résonance finale.

---

# 23. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Silence Actif.

Charge la Carte Mémoire Voix Intérieure.

Charge la Carte Mémoire Pulsation Lente.

Charge la Carte Mémoire Nappe Lunaire.

Charge la Carte Mémoire Chœur Ancien.

Charge la Carte Mémoire Battement Cyberpunk.

Charge la Carte Mémoire Montée de Révélation.

Charge la Carte Mémoire Souvenir Sonore.

Charge la Carte Mémoire Rupture Bruitée.

Charge la Carte Mémoire Dernière Note.

## Charger deux cartes

Charge Voix Intérieure + Silence Actif pour une narration respirable.

Charge Nappe Lunaire + Dernière Note pour une scène nocturne douce.

Charge Battement Cyberpunk + Pulsation Lente pour une ville noire contrôlée.

Charge Chœur Ancien + Montée de Révélation pour une scène mythologique.

## Charger un deck recommandé

Charge le Deck Voix Lunaire.

Charge le Deck Cyberpunk Premium.

Charge le Deck Mythe Vivant.

Charge le Deck Conte Intime.

Charge le Deck Séquence Vidéo Complète.

## Charger le deck complet

Charge le Deck Mémoire Musique & Voix.

Crée une direction sonore originale avec :

- voix respirable ;
- silence actif ;
- ambiance musicale non intrusive ;
- rythme de montage ;
- transition sonore ;
- dernière note ;
- note ElevenLabs ;
- note DaVinci ;
- aucune surcharge sonore.

## Production Pack+

Charge le Deck Musique & Voix et génère un Pack+ audio complet avec :

- intention sonore ;
- voix off ;
- pauses ;
- ambiance musicale ;
- bruitages utiles ;
- transition ;
- dernière note ;
- indications ElevenLabs ;
- indications DaVinci ;
- garde-fou sonore.

## Production avec Vidéo Vivante

Charge Musique & Voix + Vidéo Vivante pour transformer une séquence en montage respirable avec :

- plan visuel ;
- silence ;
- voix ;
- pulsation ;
- transition ;
- last frame ;
- dernière note.

---

# 24. 🛡️ Garde-fou final

Ces cartes ne sont pas des compositions définitives.

Elles sont des intentions sonores.

Une carte choisit une respiration.  
Une combinaison compose une structure audio.  
Le montage transforme le son en émotion lisible.

Règle finale :

Silence Actif donne l’espace.  
Voix Intérieure donne la proximité.  
Pulsation Lente donne le temps.  
Nappe Lunaire donne la nuit.  
Chœur Ancien donne la mémoire collective.  
Battement Cyberpunk donne la ville-machine.  
Montée de Révélation donne le crescendo.  
Souvenir Sonore donne le passé fragile.  
Rupture Bruitée donne la bascule.  
Dernière Note donne la résonance.

Mais le son doit rester au service de l’image.

La voix guide.  
Le silence respire.  
La musique soutient.  
L’image reste souveraine.

---

# 25. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire sonores permettant de transformer rapidement une scène, une image, une vidéo ou une narration en direction audio claire, respirable et montable.

Il contient dix cartes principales :

- Silence Actif ;
- Voix Intérieure ;
- Pulsation Lente ;
- Nappe Lunaire ;
- Chœur Ancien ;
- Battement Cyberpunk ;
- Montée de Révélation ;
- Souvenir Sonore ;
- Rupture Bruitée ;
- Dernière Note.

Il contient aussi cinq combinaisons recommandées :

- Voix lunaire ;
- Cyberpunk premium ;
- Mythe vivant ;
- Conte intime ;
- Séquence vidéo complète.

Il contient enfin une méthode de travail :

- L’Atelier du Souffle et de la Dernière Note.

## Règle d’usage

Ne pas tout remplir avec de la musique.

Ne pas expliquer toute l’image avec la voix.

Ne pas surdramatiser.

Utiliser uniquement :

- silence ;
- respiration ;
- voix ;
- ambiance ;
- pulsation ;
- bruitage utile ;
- transition ;
- dernière note.

## Résumé des cartes

Silence Actif = pause, respiration, suspension, espace pour l’image.

Voix Intérieure = narration douce, proche, pensée, respirable.

Pulsation Lente = battement discret, tempo lent, tension basse.

Nappe Lunaire = ambiance nocturne, douce, flottante, non intrusive.

Chœur Ancien = voix lointaines, mémoire collective, sacré sans dogme.

Battement Cyberpunk = ville, machine, néon sonore, tension électronique contrôlée.

Montée de Révélation = crescendo doux vers une image ou phrase clé.

Souvenir Sonore = motif fragile qui ramène une mémoire.

Rupture Bruitée = coupure nette, glitch doux, bascule, silence après impact.

Dernière Note = vibration finale, afterglow, fin ouverte.

## Résumé du deck

Le Deck Musique & Voix combine :

- silence ;
- voix ;
- rythme ;
- ambiance ;
- mémoire ;
- révélation ;
- rupture ;
- résonance.

Il sert à créer des directions sonores pour voix off, ElevenLabs, DaVinci, séquences vidéo, narrations courtes, transitions et scènes émotionnelles.

## Résumé Atelier du Souffle et de la Dernière Note

L’Atelier du Souffle et de la Dernière Note est une méthode de production sonore.

On commence par demander si la scène a besoin d’une voix.

Puis on choisit le silence, la pulsation, la nappe, le chœur, le souvenir ou la rupture selon l’intention.

La scène se termine par une dernière note ou par un silence.

Tension centrale : le son doit soutenir l’image, pas la remplacer.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck Musique & Voix.”

Alors activer :

- production audio ;
- voix off ;
- silence ;
- respiration ;
- rythme émotionnel ;
- ambiance musicale ;
- transition sonore ;
- ElevenLabs ;
- DaVinci ;
- dernière note ;
- garde-fou anti-surcharge.

Répondre en mode Production audio.

Ne pas générer d’audio automatiquement.

Ne pas noyer l’image sous la voix ou la musique.

## Activation LLM complète

Tu es en mode Cartes Mémoire Musique & Voix.

Utilise les cartes comme intentions compactes de production sonore :

Silence Actif pour créer une pause, une respiration, une tension ou un espace pour l’image.

Voix Intérieure pour écrire une voix off douce, proche, pensée et respirable.

Pulsation Lente pour donner au temps un battement discret.

Nappe Lunaire pour créer une ambiance nocturne, douce et non intrusive.

Chœur Ancien pour évoquer une mémoire collective ou un sacré sans dogme.

Battement Cyberpunk pour créer une ville-machine sonore, noire, électronique et contrôlée.

Montée de Révélation pour accompagner une image ou une phrase clé.

Souvenir Sonore pour faire revenir une mémoire par un son fragile.

Rupture Bruitée pour marquer une bascule par une coupure nette et courte.

Dernière Note pour laisser une vibration finale.

Règle centrale :

Ne charge pas toutes les cartes en même temps.

Choisis uniquement les cartes utiles à la scène.

Modes de combinaison :

- 1 carte = intention sonore simple ;
- 2 cartes = voix + ambiance ;
- 3 cartes = mini-direction audio ;
- 5 cartes = structure sonore complète ;
- 10 cartes = bible sonore de séquence.

Garde-fou :

Ne remplis pas tout avec de la musique.  
Respecte les pauses.  
La voix doit respirer.  
Le silence peut être la meilleure carte.  
Ne pas surdramatiser.

Sépare toujours :

- voix ;
- musique ;
- bruitage ;
- ambiance ;
- silence ;
- rythme de montage.

Style attendu :

- clair ;
- respirable ;
- cinématique ;
- Notion compatible ;
- ElevenLabs-ready ;
- DaVinci-ready.

Phrase de verrou :

Musique & Voix transforme le silence, la voix et le rythme en structure émotionnelle, sans noyer l’image ni voler le choix du spectateur.

---

# 26. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTES MÉMOIRE — MUSIQUE & VOIX

Tu es autorisé à utiliser le jeu “Cartes Mémoire — Musique & Voix” comme deck sonore et narratif pour @erith IA / ERITH.IA.

Objectif :
Créer des directions de voix off, silences, rythmes, ambiances musicales, transitions sonores et intentions audio pour scènes vidéo, prompts narratifs, DaVinci et ElevenLabs.

Règle centrale :
Ne charge pas toutes les cartes en même temps.
Choisis seulement les cartes utiles à la scène.

Cartes disponibles :
1. Silence Actif
2. Voix Intérieure
3. Pulsation Lente
4. Nappe Lunaire
5. Chœur Ancien
6. Battement Cyberpunk
7. Montée de Révélation
8. Souvenir Sonore
9. Rupture Bruitée
10. Dernière Note

Modes :
- 1 carte = intention sonore simple
- 2 cartes = voix + ambiance
- 3 cartes = mini-direction audio
- 5 cartes = structure sonore complète
- 10 cartes = bible sonore de séquence

Combinaisons recommandées :
1. Voix lunaire = Voix Intérieure + Nappe Lunaire + Dernière Note
2. Cyberpunk premium = Battement Cyberpunk + Pulsation Lente + Rupture Bruitée
3. Mythe vivant = Chœur Ancien + Montée de Révélation + Silence Actif
4. Conte intime = Souvenir Sonore + Voix Intérieure + Dernière Note
5. Séquence vidéo complète = Silence Actif + Pulsation Lente + Montée de Révélation + Dernière Note

Garde-fou :
Ne remplis pas tout avec de la musique.
Respecte les pauses.
La voix doit respirer.
Le silence peut être la meilleure carte.
Ne pas surdramatiser.
Ne pas imiter un compositeur, une voix ou une franchise sonore reconnaissable.

Sépare toujours :
voix ;
musique ;
bruitage ;
ambiance ;
silence ;
rythme de montage.

Style attendu :
clair ;
respirable ;
cinématique ;
Notion compatible ;
ElevenLabs-ready ;
DaVinci-ready.

Phrase de verrou :
Musique & Voix transforme le silence, la voix et le rythme en structure émotionnelle, sans noyer l’image ni voler le choix du spectateur.
```

---

# 27. 🔑 Prompt d’activation court

```text
Charge le jeu Cartes Mémoire — Musique & Voix.

Choisis seulement les cartes utiles à ma demande.

Aide-moi à créer une voix off, une direction sonore, une ambiance musicale, un rythme de narration ou une structure audio pour une scène ERITH.IA.

La voix doit respirer.
Le silence doit servir.
La musique ne doit pas écraser l’image.
Ne copie pas de compositeur, de voix ou de franchise sonore reconnaissable.
```

---

# 28. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_musique_voix_fr.md

Commit recommandé :

Wrap Musique & Voix mini prompts in code blocks
