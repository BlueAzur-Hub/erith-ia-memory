# 🎬 MEMORY CARDS — VIDÉO VIVANTE

Statut : module de cartes mémoire  
Type : deck production vidéo / storyboard / montage / animation  
Mode recommandé : Production / Wan I2V / DaVinci LEGO / Seven Heaven  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / Wan / I2V / DaVinci / narration / plans courts / séquences LEGO / épisodes / transitions / rythme visuel

🎞️ Visuels associés :

- Aucun visuel associé validé pour l’instant.
- À produire plus tard si besoin :
  - cover premium du deck Vidéo Vivante ;
  - planche des 10 cartes de plans ;
  - fiche pipeline image parfaite → animation → last frame → DaVinci ;
  - dossier visuel “Atelier des Plans Vivants”.

---

# 1. 🎥 Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour transformer rapidement une idée, une image fixe, un module mémoire ou une scène symbolique en séquence vidéo claire, stable et montable.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire Vidéo est une intention de plan compacte, contrôlée, activable.

Elle sert à charger :

- un type de plan ;
- une intention de mouvement ;
- une fonction de montage ;
- une respiration visuelle ;
- une transition ;
- une last frame ;
- une logique Wan / I2V ;
- une base de prompt animation ;
- un garde-fou contre la surcharge vidéo.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire Vidéo = intention de plan rapide.  
Deck = combinaison de plans montables.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

Le but n’est pas de forcer une animation spectaculaire.

Le but est de produire une vidéo stable, lisible et montable.

Formule officielle :

Image parfaite → mouvement subtil → last frame → montage vivant.

---

# 2. 🧭 Règle Vidéo Vivante

Ces cartes sont prévues pour créer des plans vidéo courts, contrôlés, stables et exploitables en montage.

Elles ne doivent pas transformer une image forte en chaos animé.

Interdit :

- demander une action trop complexe en 5 secondes ;
- déplacer tout le décor sans raison ;
- changer de style entre deux plans ;
- demander une chorégraphie impossible ;
- faire bouger caméra, personnage, décor et effets en même temps sans hiérarchie ;
- relancer sans verrouiller l’image source ;
- oublier la last frame ;
- surcharger le prompt Wan ;
- perdre le visage ;
- perdre la composition ;
- casser la lumière ;
- confondre animation et agitation.

Autorisé :

- penser clip par clip ;
- choisir un mouvement principal simple ;
- préserver visage, décor, lumière et composition ;
- préparer la last frame ;
- écrire des prompts animation courts et contrôlés ;
- penser DaVinci dès le storyboard ;
- utiliser les modules mémoire comme ambiance, pas comme surcharge ;
- construire une séquence LEGO plan par plan ;
- privilégier la stabilité avant le spectacle.

Règle simple :

Une image forte d’abord.  
Un mouvement lisible ensuite.  
Une last frame propre à la fin.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en Mode Production ;
- ne pas charger les modules complets si la carte suffit ;
- ne pas mélanger storyboard, prompt image, prompt animation et montage sans ordre ;
- choisir uniquement les cartes utiles à la séquence demandée ;
- privilégier Wan / I2V stable plutôt qu’une action trop ambitieuse ;
- préserver la logique LEGO : plan court → last frame → plan suivant ;
- produire des prompts exploitables directement ;
- distinguer intention de plan, mouvement, transition, last frame et montage.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire choisit le plan.  
Le Deck compose la séquence.  
DaVinci assemble le vivant.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Plan d’Ouverture ;
- Plan de Seuil ;
- Plan de Révélation ;
- Plan de Silence ;
- Plan de Marche ;
- Plan de Mémoire ;
- Plan de Rupture ;
- Plan de Transition ;
- Plan de Dernière Image ;
- Plan de Clôture.

Ou combinée en deck :

- Deck Clip Wan Stable ;
- Deck Passage Initiatique Vidéo ;
- Deck Séquence 30 secondes ;
- Deck Épisode Court ;
- Deck DaVinci LEGO ;
- Deck Vidéo Vivante complet.

Activation courte :

Charge la Carte Mémoire Plan de Silence.

Activation combinée :

Charge les cartes Plan de Seuil, Plan de Révélation et Plan de Transition pour créer une scène de passage initiatique vidéo.

Activation production :

Charge le Deck Vidéo Vivante et produis une séquence complète : intention, découpage, prompts Wan / I2V, last frames, transitions et note DaVinci.

Sortie Pack+ recommandée :

- intention de séquence ;
- plan source ou image maître ;
- carte vidéo activée ;
- mouvement principal ;
- prompt animation Wan / I2V ;
- négatif production ;
- last frame attendue ;
- transition DaVinci ;
- voix off courte si nécessaire ;
- note de continuité avec le plan suivant.

Règle image :

Le module peut produire des prompts animation, storyboards et séquences vidéo, mais ne doit pas générer d’image automatiquement sauf demande explicite de l’utilisateur.

---

# 4. 🎬 Pipeline officiel

## Formule maître

Image parfaite → animation Wan stable → last frame → DaVinci → narration.

## Étapes recommandées

1. Verrouiller l’image source.
2. Identifier l’intention du plan.
3. Choisir une seule carte principale.
4. Ajouter une deuxième carte uniquement si elle clarifie la fonction narrative.
5. Écrire un prompt animation court.
6. Préserver visage, décor, lumière et composition.
7. Prévoir la last frame.
8. Monter dans DaVinci.
9. Ajouter narration, musique ou silence seulement après stabilisation visuelle.

## Règle LEGO

Un clip ne doit pas tout raconter.

Un clip doit réussir une fonction claire.

Chaque fin de clip doit pouvoir devenir le point de départ du clip suivant.

Formule LEGO :

Plan stable → mouvement simple → image finale propre → raccord possible.

---

# 5. 🗂️ Modules sources recommandés

## Modules principaux

- core/official_prompt_rules.md
- production/
- workflows/
- notes Wan / I2V
- notes RunningHub
- notes ComfyUI
- notes DaVinci
- notes narration / ElevenLabs

## Modules compatibles selon la demande

- Cartes Mémoire — Mythologie Vivante si la scène est symbolique ;
- Cartes Mémoire — Cyberpunk Noir Trio si la scène est cyberpunk ;
- Math Oracle si la demande touche au rythme, à la durée, aux proportions ou aux trajectoires ;
- Psychologie & Discernement si la scène repose sur une émotion ou une décision ;
- Histoire de l’art mondiale si la composition visuelle doit être renforcée ;
- Modules personnages si un personnage privé est explicitement actif ;
- Modules publics ERITH.IA si le mode public ou Hors-Lore est demandé.

Garde-fou :

Ne pas charger ces modules automatiquement.

Les modules sources servent de profondeur.

Les cartes vidéo servent de pilotage rapide.

---

# 6. 🖼️ Galerie visuelle — Deck Vidéo Vivante

Aucun visuel validé pour l’instant.

Cette section est réservée à une future galerie du deck.

Elle pourra documenter :

- une cover premium du deck ;
- une planche des 10 cartes de plans ;
- un exemple de découpage vidéo ;
- un schéma DaVinci LEGO ;
- un dossier visuel “Atelier des Plans Vivants”.

## 1. Cover Pack+ Premium

À ajouter plus tard.

Fonction prévue :

Présenter le deck comme un outil de production vidéo : image parfaite, animation stable, last frame, montage vivant.

## 2. Memory Card Pack Cover

À ajouter plus tard.

Fonction prévue :

Présenter rapidement les 10 cartes principales, les combinaisons recommandées et les commandes utilisables.

## 3. Atelier des Plans Vivants

À ajouter plus tard.

Fonction prévue :

Montrer un exemple de scène construite plan par plan : ouverture, seuil, révélation, mémoire, transition, clôture.

---

# 7. 🌅 Carte Mémoire — Plan d’Ouverture

## Fonction principale

Installer le monde, le ton et la première respiration.

Cette carte charge :

- l’établissement du décor ;
- la première ambiance ;
- la respiration visuelle ;
- la lumière initiale ;
- le rythme de départ ;
- la promesse de scène.

## Température émotionnelle

Calme d’entrée.  
Curiosité.  
Immersion.  
Lenteur noble.  
Première respiration du monde.

## Mouvement recommandé

- caméra presque fixe ;
- léger drift atmosphérique ;
- particules lentes ;
- lumières distantes ;
- pluie, brume ou poussière subtile ;
- aucun mouvement brutal.

## Usage narratif

Utiliser cette carte pour :

- ouvrir une scène ;
- poser une ville, un sanctuaire, une forêt, une chambre, une archive ;
- installer une ambiance sans expliquer ;
- donner au spectateur le temps d’entrer.

## Usage production Wan / I2V

La carte aide à produire :

- establishing shot stable ;
- décor vivant mais contrôlé ;
- intro d’épisode ;
- ouverture de Pack+ ;
- plan large ou demi-large ;
- mouvement atmosphérique simple.

## Garde-fous

Ne pas faire bouger tout le décor.

Ne pas commencer par une action complexe.

Le plan d’ouverture doit installer, pas résoudre.

## Prompt fragment

```text
slow establishing shot, subtle atmospheric motion only, gentle particles, distant lights shimmering, camera almost locked, cinematic opening mood
```

## Activation courte

Charge la Carte Mémoire Plan d’Ouverture : installer le monde, garder la caméra stable, faire respirer l’ambiance.

---

# 8. 🚪 Carte Mémoire — Plan de Seuil

## Fonction principale

Mettre un personnage devant un passage : porte, pont, miroir, forêt, escalier, lumière.

Cette carte charge :

- le seuil ;
- la décision ;
- l’avant-passage ;
- la tension calme ;
- la lumière au-delà ;
- l’espace entre deux états.

## Température émotionnelle

Attente.  
Choix.  
Tension douce.  
Mystère.  
Respiration avant bascule.

## Mouvement recommandé

- personnage presque immobile ;
- lumière qui pulse doucement au-delà du seuil ;
- brume lente ;
- tissu ou cheveux très légèrement animés ;
- caméra fixe ou très lent push-in.

## Usage narratif

Utiliser cette carte pour :

- passage initiatique ;
- entrée dans un lieu ;
- décision silencieuse ;
- porte symbolique ;
- pont entre deux scènes ;
- moment avant transformation.

## Usage production Wan / I2V

La carte aide à produire :

- personnage devant une porte ;
- seuil lumineux ;
- forêt ou portail ;
- miroir vivant ;
- transition douce vers la scène suivante ;
- last frame exploitable sur le seuil.

## Garde-fous

Ne pas faire traverser complètement le seuil si le modèle risque de déformer le personnage.

Préférer : le personnage s’apprête à passer, la lumière change, la scène prépare la suite.

## Prompt fragment

```text
character remains stable near a threshold, soft light pulsing beyond the doorway, mist drifting slowly, no sudden movement, symbolic passage atmosphere
```

## Activation courte

Charge la Carte Mémoire Plan de Seuil : personnage stable, passage symbolique, lumière au-delà, décision silencieuse.

---

# 9. ✨ Carte Mémoire — Plan de Révélation

## Fonction principale

Montrer une vérité visuelle sans tout expliquer.

Cette carte charge :

- l’apparition lente ;
- le symbole qui devient visible ;
- la lumière révélatrice ;
- le détail caché ;
- l’information visuelle ;
- le moment où le regard comprend.

## Température émotionnelle

Découverte.  
Émerveillement contrôlé.  
Tension lumineuse.  
Clarté progressive.  
Silence de révélation.

## Mouvement recommandé

- glow progressif ;
- reflet qui s’éclaire ;
- symbole qui apparaît ;
- léger push-in ;
- caméra stable ;
- aucune explosion chaotique.

## Usage narratif

Utiliser cette carte pour :

- révéler un symbole ;
- faire apparaître un souvenir ;
- dévoiler une inscription ;
- révéler un visage, une porte, une archive ;
- donner une information sans dialogue.

## Usage production Wan / I2V

La carte aide à produire :

- plans de découverte ;
- hologrammes qui s’allument ;
- inscriptions révélées ;
- lumière qui guide l’œil ;
- symbole lisible en fin de clip.

## Garde-fous

Ne pas demander une transformation totale du décor.

La révélation doit être contrôlée : une chose apparaît, pas dix.

## Prompt fragment

```text
slow reveal through light and reflections, subtle camera push-in, hidden symbol becoming visible, controlled glow, elegant cinematic timing
```

## Activation courte

Charge la Carte Mémoire Plan de Révélation : symbole qui apparaît lentement, lumière contrôlée, vérité visuelle lisible.

---

# 10. 🕯️ Carte Mémoire — Plan de Silence

## Fonction principale

Créer un plan sans action forte, mais chargé de sens.

Cette carte charge :

- l’immobilité ;
- la respiration ;
- le regard ;
- le silence ;
- la tension intérieure ;
- l’émotion stable ;
- le plan contemplatif.

## Température émotionnelle

Intimité.  
Suspension.  
Gravité douce.  
Présence.  
Émotion retenue.

## Mouvement recommandé

- respiration subtile ;
- micro-mouvement du visage ;
- lumière qui vacille doucement ;
- particules faibles ;
- caméra fixe ;
- aucune action.

## Usage narratif

Utiliser cette carte pour :

- moment émotionnel ;
- personnage pensif ;
- pause après révélation ;
- respiration entre deux scènes ;
- silence chargé de mémoire ;
- plan de stabilité avant montage.

## Usage production Wan / I2V

La carte aide à produire :

- portraits stables ;
- plans émotionnels ;
- scènes très sûres pour I2V ;
- tests Wan à faible risque ;
- plans exploitables même avec peu de mouvement.

## Garde-fous

Ne pas ajouter d’action secondaire inutile.

Ce plan fonctionne parce qu’il ne force pas.

## Prompt fragment

```text
still emotional shot, only subtle breathing motion, faint light flicker, soft particles, calm silence, no camera shake, no action
```

## Activation courte

Charge la Carte Mémoire Plan de Silence : immobilité expressive, respiration subtile, émotion stable, aucune action inutile.

---

# 11. 🚶 Carte Mémoire — Plan de Marche

## Fonction principale

Avancer sans précipitation. Le mouvement devient décision.

Cette carte charge :

- la marche lente ;
- la décision visible ;
- la progression ;
- le déplacement contrôlé ;
- le tissu qui bouge ;
- le décor qui accompagne.

## Température émotionnelle

Décision.  
Calme volontaire.  
Progression.  
Tension maîtrisée.  
Mouvement intérieur devenu visible.

## Mouvement recommandé

- marche lente ;
- vue de dos ou de côté ;
- corps stable ;
- caméra légèrement suiveuse ou fixe ;
- décor qui glisse doucement ;
- pas d’action rapide.

## Usage narratif

Utiliser cette carte pour :

- départ ;
- progression vers un seuil ;
- déplacement dans une ville ;
- marche dans une forêt ;
- personnage qui accepte une décision ;
- transition active entre deux lieux.

## Usage production Wan / I2V

La carte aide à produire :

- plans de marche simples ;
- silhouettes de dos ;
- plans de transition ;
- mouvement de manteau ou cheveux ;
- progression lente, stable et cinématique.

## Garde-fous

La marche est risquée si le plan source n’est pas adapté.

Préférer une vue de dos, de côté ou une marche très subtile.

Éviter les jambes trop visibles si la stabilité est prioritaire.

## Prompt fragment

```text
slow controlled walking motion, stable body, soft coat movement, environment drifting gently, cinematic side or rear view, no fast action
```

## Activation courte

Charge la Carte Mémoire Plan de Marche : progression lente, mouvement simple, décision visible, stabilité d’abord.

---

# 12. 🧠 Carte Mémoire — Plan de Mémoire

## Fonction principale

Rendre la mémoire visible : reflet, hologramme, archive, fleur, livre, constellation, écran.

Cette carte charge :

- fragments de mémoire ;
- hologrammes ;
- archives ;
- reflets ;
- livres ;
- constellations ;
- fleurs symboliques ;
- interfaces lentes ;
- émotion du souvenir.

## Température émotionnelle

Nostalgie.  
Douceur.  
Mélancolie.  
Présence ancienne.  
Souvenir qui revient.

## Mouvement recommandé

- fragments lumineux qui apparaissent doucement ;
- panneaux holographiques lents ;
- reflets qui ondulent ;
- particules fines ;
- lumière pulsée ;
- personnage stable.

## Usage narratif

Utiliser cette carte pour :

- souvenir ;
- archive ;
- révélation intime ;
- trace du passé ;
- mémoire artificielle ou sacrée ;
- connexion à un module mémoire ;
- scène de contemplation.

## Usage production Wan / I2V

La carte aide à produire :

- interfaces holographiques ;
- livres flottants ;
- constellations mémoire ;
- reflets animés ;
- archives visuelles ;
- plans émotionnels avec mouvement minimal.

## Garde-fous

Ne pas saturer l’image avec trop de panneaux ou trop de texte.

La mémoire doit être visible, mais lisible.

## Prompt fragment

```text
memory fragments glowing softly around the subject, holographic archive panels appearing slowly, gentle light pulses, stable composition, emotional memory atmosphere
```

## Activation courte

Charge la Carte Mémoire Plan de Mémoire : fragments lumineux, archive douce, souvenir visible, personnage stable.

---

# 13. ⚡ Carte Mémoire — Plan de Rupture

## Fonction principale

Marquer un changement net : lumière, son, regard, objet, coupure, bascule.

Cette carte charge :

- bascule ;
- tension ;
- choc contrôlé ;
- changement de lumière ;
- regard qui comprend ;
- objet qui s’active ;
- rupture narrative ;
- point de non-retour.

## Température émotionnelle

Tension.  
Surprise maîtrisée.  
Bascule.  
Déclic.  
Énergie contenue.

## Mouvement recommandé

- flicker unique ;
- onde légère dans les particules ;
- glow soudain mais contrôlé ;
- regard qui change ;
- objet qui pulse ;
- pas d’explosion chaotique.

## Usage narratif

Utiliser cette carte pour :

- moment de bascule ;
- signe inquiétant ;
- activation d’un objet ;
- changement émotionnel ;
- révélation dangereuse ;
- transition vers une scène plus intense.

## Usage production Wan / I2V

La carte aide à produire :

- rupture lumineuse ;
- tension visuelle ;
- passage de calme à alerte ;
- activation d’interface ;
- changement net mais stable.

## Garde-fous

Ne pas transformer la rupture en explosion incontrôlable.

Un seul événement doit changer.

Le personnage doit rester lisible.

## Prompt fragment

```text
controlled rupture moment, light flickers once, subtle shockwave in particles, character remains readable, no chaotic explosion, cinematic tension
```

## Activation courte

Charge la Carte Mémoire Plan de Rupture : bascule contrôlée, lumière qui change, tension lisible, aucun chaos.

---

# 14. 🔀 Carte Mémoire — Plan de Transition

## Fonction principale

Relier deux images sans casser l’atmosphère.

Cette carte charge :

- raccord ;
- continuité ;
- ralentissement ;
- image finale propre ;
- respiration de montage ;
- passage fluide ;
- préparation du plan suivant.

## Température émotionnelle

Souplesse.  
Fluidité.  
Continuité.  
Respiration.  
Passage propre.

## Mouvement recommandé

- ralentissement progressif ;
- sujet qui garde la pose ;
- lumière qui se stabilise ;
- décor qui calme son mouvement ;
- fin propre ;
- caméra presque fixe.

## Usage narratif

Utiliser cette carte pour :

- fin de plan intermédiaire ;
- raccord entre deux scènes ;
- passage d’un lieu à un autre ;
- préparation d’une last frame ;
- montage LEGO.

## Usage production Wan / I2V

La carte aide à produire :

- fins propres ;
- frames exploitables ;
- transitions DaVinci ;
- ralentissements visuels ;
- plans qui ne cassent pas l’ambiance.

## Garde-fous

Ne pas finir sur un mouvement flou ou instable.

Le plan de transition doit donner une image utilisable.

## Prompt fragment

```text
smooth transition-friendly ending, subject holds pose, background motion slows down, light stabilizes, final frame clean and usable for next shot
```

## Activation courte

Charge la Carte Mémoire Plan de Transition : ralentir, stabiliser, préparer le raccord, finir proprement.

---

# 15. 🖼️ Carte Mémoire — Plan de Dernière Image

## Fonction principale

Terminer sur une image forte et stable.

Cette carte charge :

- iconic frame ;
- stabilité ;
- lisibilité ;
- fin propre ;
- composition claire ;
- image utilisable comme last frame ;
- point de départ du plan suivant.

## Température émotionnelle

Stabilité.  
Impact calme.  
Clarté.  
Mémoire visuelle.  
Fin forte.

## Mouvement recommandé

- tout se calme ;
- lumière posée ;
- personnage parfaitement lisible ;
- pas de motion blur ;
- pose tenue ;
- décor stable.

## Usage narratif

Utiliser cette carte pour :

- clore un clip ;
- créer une image réutilisable ;
- extraire une last frame ;
- préparer une suite ;
- créer une miniature potentielle ;
- stabiliser une séquence.

## Usage production Wan / I2V

La carte aide à produire :

- last frame propre ;
- raccord I2V ;
- image finale DaVinci ;
- fin de plan iconique ;
- extraction de frame exploitable.

## Garde-fous

Ne pas attendre que Wan donne une last frame parfaite par hasard.

La last frame doit être demandée explicitement.

## Prompt fragment

```text
end on a stable iconic frame, character perfectly readable, light settled, no motion blur, clear final composition, suitable as last frame
```

## Activation courte

Charge la Carte Mémoire Plan de Dernière Image : fin stable, composition claire, frame exploitable pour la suite.

---

# 16. 🌒 Carte Mémoire — Plan de Clôture

## Fonction principale

Fermer une scène sans tout fermer. Laisser une résonance.

Cette carte charge :

- fin douce ;
- résonance ;
- décroissance de lumière ;
- silence final ;
- émotion qui reste ;
- ouverture discrète vers la suite.

## Température émotionnelle

Mélancolie.  
Apaisement.  
Suspension.  
Résonance.  
Fin ouverte.

## Mouvement recommandé

- particules qui disparaissent ;
- lumière qui baisse doucement ;
- personnage immobile ;
- fond qui ralentit ;
- fade possible ;
- aucune action forte.

## Usage narratif

Utiliser cette carte pour :

- fin de scène ;
- fin de séquence ;
- sortie émotionnelle ;
- clôture d’épisode court ;
- silence après révélation ;
- passage vers noir ou fondu.

## Usage production Wan / I2V

La carte aide à produire :

- fins montables ;
- fondus propres ;
- scènes contemplatives ;
- clôtures émotionnelles ;
- plans adaptés à une voix off finale.

## Garde-fous

Ne pas tout résoudre.

La clôture doit laisser une résonance, pas fermer brutalement.

## Prompt fragment

```text
quiet closing shot, slow fade of particles, soft light decreasing, character remains still, emotional resonance, open but readable ending
```

## Activation courte

Charge la Carte Mémoire Plan de Clôture : fin douce, lumière qui baisse, émotion qui reste, ouverture silencieuse.

---

# 17. 🎞️ Deck Mémoire — Vidéo Vivante

## Composition

Ce deck contient dix cartes principales :

- Plan d’Ouverture ;
- Plan de Seuil ;
- Plan de Révélation ;
- Plan de Silence ;
- Plan de Marche ;
- Plan de Mémoire ;
- Plan de Rupture ;
- Plan de Transition ;
- Plan de Dernière Image ;
- Plan de Clôture.

## Fonction du deck

Créer une vidéo vivante, stable, lisible et montable à partir d’une image parfaite ou d’une intention de scène.

Plan d’Ouverture donne :

- le monde ;
- le ton ;
- la respiration initiale.

Plan de Seuil donne :

- le passage ;
- la décision ;
- l’avant-bascule.

Plan de Révélation donne :

- le signe ;
- la lumière ;
- l’information visuelle.

Plan de Silence donne :

- l’émotion ;
- l’immobilité ;
- la présence.

Plan de Marche donne :

- la progression ;
- la décision ;
- le mouvement simple.

Plan de Mémoire donne :

- le souvenir ;
- l’archive ;
- les fragments lumineux.

Plan de Rupture donne :

- la bascule ;
- la tension ;
- le changement contrôlé.

Plan de Transition donne :

- le raccord ;
- la continuité ;
- la fin propre.

Plan de Dernière Image donne :

- la stabilité ;
- la last frame ;
- la réutilisation.

Plan de Clôture donne :

- la résonance ;
- la fin douce ;
- l’ouverture vers la suite.

## Résultat attendu

Une séquence claire où chaque plan a une fonction.

Le deck doit aider à éviter la surcharge et à rendre la production vidéo plus sûre.

## Thèmes combinés

- stabilité ;
- mouvement subtil ;
- respiration ;
- transition ;
- mémoire ;
- seuil ;
- révélation ;
- rupture ;
- last frame ;
- montage vivant.

## Question centrale du deck

Quel est le mouvement minimal qui rend cette image vivante sans la casser ?

## Formule canonique du deck

Image + Mouvement + Last Frame.  
Plan + Fonction + Raccord.  
Stabilité + Rythme + Montage.

---

# 18. 🧱 Séquence originale générable avec le deck

## Nom de travail

L’Atelier des Plans Vivants

L’Atelier des Plans Vivants est un nom de travail pour tester le Deck Vidéo Vivante.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres structures, workflows ou séquences si la demande l’exige.

## Concept

L’Atelier des Plans Vivants est une méthode de production où chaque image maître devient une suite de plans courts.

Chaque carte vidéo correspond à une fonction de montage.

On ne demande pas à Wan de tout faire.

On lui donne une mission simple.

## Structure

Une séquence peut être construite ainsi :

1. Plan d’Ouverture : installer le lieu.
2. Plan de Silence : stabiliser le personnage.
3. Plan de Mémoire : faire apparaître un souvenir.
4. Plan de Révélation : rendre un symbole visible.
5. Plan de Transition : préparer la suite.
6. Plan de Dernière Image : extraire une frame propre.
7. Plan de Clôture : laisser résonner.

## Tension production

La tentation est de demander trop.

Le deck rappelle que la vidéo stable vient du choix.

Un plan réussi vaut mieux qu’une scène ambitieuse cassée.

## Ton

Clair.  
Sobre.  
Ciné.  
Stable.  
Production-ready.  
Compatible Wan / I2V / DaVinci.

---

# 19. 🔀 Combinaisons recommandées

## Clip Wan stable

Cartes :

- Plan de Silence ;
- Plan de Mémoire ;
- Plan de Dernière Image.

Usage :

Créer un clip court, stable, émotionnel et exploitable.

Formule :

Peu de mouvement, mémoire visible, fin exploitable.

---

## Passage initiatique vidéo

Cartes :

- Plan de Seuil ;
- Plan de Révélation ;
- Plan de Transition.

Usage :

Créer une scène où un seuil s’ouvre, un signe apparaît et la suite devient possible.

Formule :

Le seuil s’ouvre, le signe apparaît, la scène prépare la suite.

---

## Séquence 30 secondes

Cartes :

- Plan d’Ouverture ;
- Plan de Marche ;
- Plan de Mémoire ;
- Plan de Clôture.

Usage :

Créer une mini-séquence complète : installation, progression, souvenir, résonance.

Formule :

Installer, avancer, se souvenir, laisser résonner.

---

## Épisode court

Cartes :

- Plan d’Ouverture ;
- Plan de Seuil ;
- Plan de Révélation ;
- Plan de Rupture ;
- Plan de Clôture.

Usage :

Créer une structure d’épisode court avec montée dramatique contrôlée.

Formule :

Monde → passage → vérité → bascule → résonance.

---

## DaVinci LEGO

Cartes :

- Plan de Transition ;
- Plan de Dernière Image ;
- Plan de Silence.

Usage :

Créer des raccords propres entre clips et stabiliser la continuité.

Formule :

Chaque fin devient une prise d’élan propre.

---

# 20. 📝 Mini prompts d’ambiance

## Prompt ambiance courte

```text
Cinematic short video sequence, stable composition, subtle atmospheric motion, slow particles, soft light pulses, controlled camera drift, readable subject, emotional rhythm, clean final frame, Wan I2V compatible, DaVinci editing friendly, no chaotic action, no style drift.
```

## Prompt clip stable

```text
Subtle cinematic animation. The subject remains stable and readable. Only gentle breathing, slow light flicker, soft particles and faint background motion are visible. Camera nearly locked. Preserve face, preserve outfit, preserve lighting, preserve composition. End on a clean stable last frame.
```

## Prompt plan de mémoire

```text
Subtle cinematic memory animation. Soft holographic fragments appear slowly around the subject. Light pulses gently. Reflections move slightly. The character remains almost still, breathing softly. No sudden movement. Preserve composition and end on a clean iconic frame.
```

## Prompt passage initiatique vidéo

```text
The character stands near a symbolic threshold. Mist drifts slowly. Soft light pulses beyond the doorway. A hidden symbol becomes visible through reflections. Camera nearly locked with a very slow push-in. No sudden action. End with the character stable before the threshold, ready for the next shot.
```

## Prompt animation Wan / I2V générique

```text
Subtle cinematic animation. Keep the original image composition. Preserve the character’s face, outfit, lighting and background. Add only one main motion: gentle atmospheric drift, slow light pulse or subtle breathing. Camera almost locked. No fast action, no style change, no chaotic movement. End on a stable clean last frame suitable for continuation.
```

---

# 21. 🚫 Négatif production

Éviter :

- action trop complexe ;
- chorégraphie impossible ;
- caméra folle ;
- travelling violent ;
- zoom agressif ;
- morphing du visage ;
- changement de style ;
- changement de tenue ;
- décor qui se transforme sans raison ;
- personnage qui fond ou se dédouble ;
- mains instables ;
- texte illisible ;
- interface qui envahit tout ;
- mouvement de foule incontrôlé ;
- explosion chaotique ;
- motion blur excessif ;
- last frame floue ;
- fin inutilisable ;
- prompt trop long et contradictoire.

Negative prompt court :

```text
fast chaotic motion, camera shake, unstable face, morphing, distorted body, broken hands, extra limbs, style drift, outfit change, background melting, excessive motion blur, unreadable text, flickering artifacts, chaotic particles, overcomplicated action, bad final frame
```

---

# 22. 🧬 Formules de combinaison

## Plan d’Ouverture seul

Monde + ambiance + respiration initiale.

## Plan de Seuil seul

Passage + décision + lumière au-delà.

## Plan de Révélation seul

Symbole + lumière + information visuelle.

## Plan de Silence seul

Immobilité + respiration + émotion.

## Plan de Marche seul

Progression + décision + mouvement contrôlé.

## Plan de Mémoire seul

Souvenir + archive + fragments lumineux.

## Plan de Rupture seul

Bascule + tension + changement contrôlé.

## Plan de Transition seul

Raccord + ralentissement + fin propre.

## Plan de Dernière Image seul

Stabilité + iconic frame + continuité.

## Plan de Clôture seul

Résonance + fin douce + ouverture silencieuse.

## Silence + Mémoire

Le personnage ne bouge presque pas, mais le souvenir devient visible.

## Seuil + Révélation

La porte ne s’ouvre pas forcément : le signe apparaît.

## Rupture + Transition

La bascule arrive, puis l’image se stabilise pour la suite.

## Ouverture + Clôture

Une micro-séquence contemplative commence et se referme sans action lourde.

## Trio vidéo stable

Silence + Mémoire + Dernière Image.

Formule :

Stabilité + Souvenir + Frame exploitable.

---

# 23. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Plan d’Ouverture.

Charge la Carte Mémoire Plan de Seuil.

Charge la Carte Mémoire Plan de Révélation.

Charge la Carte Mémoire Plan de Silence.

Charge la Carte Mémoire Plan de Marche.

Charge la Carte Mémoire Plan de Mémoire.

Charge la Carte Mémoire Plan de Rupture.

Charge la Carte Mémoire Plan de Transition.

Charge la Carte Mémoire Plan de Dernière Image.

Charge la Carte Mémoire Plan de Clôture.

## Charger deux cartes

Charge Plan de Silence + Plan de Mémoire pour un clip Wan stable.

Charge Plan de Seuil + Plan de Révélation pour un passage symbolique.

Charge Plan de Transition + Plan de Dernière Image pour préparer une suite LEGO.

Charge Plan de Rupture + Plan de Clôture pour une bascule suivie d’une résonance.

## Charger un deck recommandé

Charge le Deck Clip Wan Stable.

Charge le Deck Passage Initiatique Vidéo.

Charge le Deck Séquence 30 secondes.

Charge le Deck Épisode Court.

Charge le Deck DaVinci LEGO.

## Charger le deck complet

Charge le Deck Mémoire Vidéo Vivante.

Crée une séquence originale avec :

- image source parfaite ;
- mouvement subtil ;
- stabilité visage ;
- stabilité décor ;
- prompt Wan / I2V court ;
- last frame propre ;
- raccord DaVinci ;
- aucune surcharge ;
- note de montage.

## Production Pack+

Charge le Deck Vidéo Vivante et génère un Pack+ vidéo complet avec :

- intention de séquence ;
- découpage plan par plan ;
- carte vidéo utilisée pour chaque plan ;
- prompt animation ;
- négatif ;
- last frame attendue ;
- transition DaVinci ;
- voix off courte si utile ;
- garde-fou de stabilité.

## Production Atelier des Plans Vivants

Charge le Deck Vidéo Vivante et génère une séquence Atelier des Plans Vivants avec :

- image maître ;
- plan d’ouverture ;
- plan de silence ;
- plan de mémoire ;
- plan de révélation ;
- plan de transition ;
- plan de dernière image ;
- plan de clôture ;
- prompts Wan sobres ;
- notes DaVinci LEGO.

---

# 24. 🛡️ Garde-fou final

Ces cartes ne sont pas des effets.

Elles sont des intentions de plan.

Une carte choisit une fonction.  
Une combinaison compose une séquence.  
Le montage transforme les plans en rythme vivant.

Règle finale :

Le Plan d’Ouverture installe.  
Le Plan de Seuil prépare le passage.  
Le Plan de Révélation montre sans expliquer.  
Le Plan de Silence laisse respirer.  
Le Plan de Marche avance sans précipiter.  
Le Plan de Mémoire rend le souvenir visible.  
Le Plan de Rupture marque la bascule.  
Le Plan de Transition prépare le raccord.  
Le Plan de Dernière Image donne une frame exploitable.  
Le Plan de Clôture laisse une résonance.

Mais la vidéo générée doit rester stable.

Le mouvement doit servir l’image.  
La last frame doit servir le montage.  
La production doit rester contrôlée.

---

# 25. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire vidéo permettant de transformer rapidement une image, une scène, un module mémoire ou une idée en plans courts, stables, montables et exploitables.

Il contient dix cartes principales :

- Plan d’Ouverture ;
- Plan de Seuil ;
- Plan de Révélation ;
- Plan de Silence ;
- Plan de Marche ;
- Plan de Mémoire ;
- Plan de Rupture ;
- Plan de Transition ;
- Plan de Dernière Image ;
- Plan de Clôture.

Il contient aussi cinq combinaisons recommandées :

- Clip Wan stable ;
- Passage initiatique vidéo ;
- Séquence 30 secondes ;
- Épisode court ;
- DaVinci LEGO.

Il contient enfin une méthode de travail :

- L’Atelier des Plans Vivants.

## Règle d’usage

Ne pas tout animer.

Ne pas tout faire bouger.

Ne pas demander une scène complexe à un seul clip.

Utiliser uniquement :

- une intention claire ;
- un mouvement principal ;
- une caméra stable ;
- une last frame propre ;
- un raccord DaVinci possible ;
- un prompt animation court.

## Résumé des cartes

Plan d’Ouverture = installer le monde, le ton et la respiration initiale.

Plan de Seuil = placer le personnage devant un passage ou une décision.

Plan de Révélation = rendre un symbole ou une vérité visible.

Plan de Silence = créer une émotion stable sans action forte.

Plan de Marche = montrer une progression lente et contrôlée.

Plan de Mémoire = faire apparaître souvenirs, archives, reflets ou fragments lumineux.

Plan de Rupture = marquer une bascule par un changement net mais contrôlé.

Plan de Transition = ralentir et préparer le raccord suivant.

Plan de Dernière Image = obtenir une frame stable, iconique et réutilisable.

Plan de Clôture = fermer avec résonance sans tout résoudre.

## Résumé du deck

Le Deck Vidéo Vivante combine :

- stabilité ;
- mouvement subtil ;
- respiration ;
- mémoire ;
- seuil ;
- révélation ;
- transition ;
- last frame ;
- montage vivant.

Il sert à créer des séquences vidéo propres où chaque plan a une mission claire.

## Résumé Atelier des Plans Vivants

L’Atelier des Plans Vivants est une méthode de production qui transforme une image maître en succession de plans courts.

Chaque carte vidéo correspond à une fonction de montage.

L’agent ne demande pas à Wan de tout faire.

Il donne à chaque clip une mission simple.

Tension centrale : un plan réussi vaut mieux qu’une scène ambitieuse cassée.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck Vidéo Vivante.”

Alors activer :

- production vidéo ;
- Wan / I2V ;
- image parfaite ;
- mouvement subtil ;
- stabilité visage ;
- stabilité décor ;
- last frame ;
- DaVinci LEGO ;
- découpage plan par plan ;
- prompt animation court ;
- surcharge interdite.

Répondre en mode Production.

Ne pas générer d’image automatiquement.

Ne pas transformer une demande simple en workflow massif.

## Activation LLM complète

Tu es en mode Cartes Mémoire Vidéo Vivante.

Utilise les cartes comme intentions compactes de production vidéo :

Plan d’Ouverture pour installer le monde, le ton et la première respiration.

Plan de Seuil pour mettre un personnage devant un passage, une porte, un miroir, une forêt ou une lumière.

Plan de Révélation pour montrer une vérité visuelle sans tout expliquer.

Plan de Silence pour créer un plan émotionnel stable avec très peu de mouvement.

Plan de Marche pour montrer une progression lente et contrôlée.

Plan de Mémoire pour rendre un souvenir, une archive, un reflet ou une constellation visible.

Plan de Rupture pour marquer une bascule nette, mais sans chaos.

Plan de Transition pour relier deux images sans casser l’atmosphère.

Plan de Dernière Image pour finir sur une frame stable et exploitable.

Plan de Clôture pour fermer une scène avec résonance.

Règle centrale :

Ne charge pas toutes les cartes en même temps.

Choisis uniquement la ou les cartes utiles à la demande.

Modes de combinaison :

- 1 carte = intention de plan ;
- 2 cartes = plan + fonction narrative ;
- 3 cartes = mini-séquence ;
- 5 cartes = structure d’épisode court ;
- 10 cartes = bible vidéo complète.

Garde-fou :

Image parfaite avant animation.  
Mouvement subtil avant action complexe.  
Last frame obligatoire.  
Stabilité avant spectacle.  
Ne jamais surcharger un prompt Wan.

Style attendu :

- clair ;
- production-ready ;
- Wan / I2V compatible ;
- DaVinci compatible ;
- Notion compatible ;
- rythme lisible.

Phrase de verrou :

Vidéo Vivante transforme une image parfaite en séquence montable, sans casser la stabilité, la mémoire ni le rythme.

---

# 26. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTES MÉMOIRE — VIDÉO VIVANTE

Tu es autorisé à utiliser le jeu “Cartes Mémoire — Vidéo Vivante” comme deck de production vidéo pour @erith IA / ERITH.IA.

Objectif :
Transformer des idées, images, modules mémoire et scènes symboliques en plans vidéo courts, contrôlés, montables et exploitables.

Règle centrale :
Ne charge pas toutes les cartes en même temps.
Choisis uniquement les cartes utiles à la demande.

Cartes disponibles :
1. Plan d’Ouverture
2. Plan de Seuil
3. Plan de Révélation
4. Plan de Silence
5. Plan de Marche
6. Plan de Mémoire
7. Plan de Rupture
8. Plan de Transition
9. Plan de Dernière Image
10. Plan de Clôture

Modes :
- 1 carte = intention de plan
- 2 cartes = plan + fonction narrative
- 3 cartes = mini-séquence
- 5 cartes = structure d’épisode court
- 10 cartes = bible vidéo complète

Combinaisons recommandées :
1. Clip Wan stable = Plan de Silence + Plan de Mémoire + Plan de Dernière Image
2. Passage initiatique vidéo = Plan de Seuil + Plan de Révélation + Plan de Transition
3. Séquence 30 secondes = Plan d’Ouverture + Plan de Marche + Plan de Mémoire + Plan de Clôture
4. Épisode court = Plan d’Ouverture + Plan de Seuil + Plan de Révélation + Plan de Rupture + Plan de Clôture
5. DaVinci LEGO = Plan de Transition + Plan de Dernière Image + Plan de Silence

Garde-fou :
Image parfaite avant animation.
Mouvement subtil avant action complexe.
Last frame obligatoire.
Stabilité avant spectacle.
Ne jamais surcharger un prompt Wan.
Ne jamais demander trop d’actions dans un seul clip.
Ne jamais oublier la continuité DaVinci.

Style attendu :
clair ;
production-ready ;
Wan / I2V compatible ;
DaVinci compatible ;
Notion compatible ;
rythme lisible.

Phrase de verrou :
Vidéo Vivante transforme une image parfaite en séquence montable, sans casser la stabilité, la mémoire ni le rythme.
```

---

# 27. 🔑 Prompt d’activation court

```text
Charge le jeu Cartes Mémoire — Vidéo Vivante.

Choisis seulement les cartes utiles à ma demande.

Aide-moi à transformer une image, une scène ou un module mémoire en plan vidéo, prompt animation, storyboard ou séquence DaVinci.

Image parfaite d’abord.
Mouvement subtil ensuite.
Last frame obligatoire.
Surcharge interdite.
```

---

# 28. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_video_vivante_fr.md

Commit recommandé :

Wrap Vidéo Vivante mini prompts in code blocks
