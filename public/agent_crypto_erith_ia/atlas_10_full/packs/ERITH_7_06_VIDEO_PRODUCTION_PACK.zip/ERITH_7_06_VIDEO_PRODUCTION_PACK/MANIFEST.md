# ERITH-7 — Video Production Pack

Pack: ERITH_7_06_VIDEO_PRODUCTION_PACK

## Rôle
Production image/vidéo/son : Wan, RunningHub, DaVinci, ComfyUI, ElevenLabs, YouTube, workflows et garde-fous média.

## Fichiers inclus

- core/AERITH_7_FULL_MODULES_BOOST_PRODUCTION_LAYERS_ADDENDUM.md
- core/AERITH_7_VIDEO_CARDS_BOOST.md
- core/CLEAN_IMAGE_PRODUCTION_RULE.md
- core/MEDIA_GENERATION_MODE_PROTOCOL.md
- core/MEDIA_ONE_SHOT_PROTOCOL.md
- core/RULE_IMAGE_MULTIPLE_CHOICES_NATIVE.md
- core/SEVEN_TOP_OF_MIND.md
- core/official_prompt_rules.md
- memory_cards/ANIMATION_STABILITY_CARD.md
- memory_cards/EXPORT_AND_DELIVERY_CARD.md
- memory_cards/MOTION_AND_CAMERA_CARD.md
- memory_cards/MUSIC_DIRECTION_CARD.md
- memory_cards/QUALITY_CONTROL_CARD.md
- memory_cards/SCENES_AND_KEYFRAMES_CARD.md
- memory_cards/SOUND_AND_MUSIC_DESIGN_CARD.md
- memory_cards/VIDEO_DIRECTION_CARD.md
- modules/erith_ia_youtube_memory_reader_v6_fr.md
- modules/erith_ia_youtube_memory_reader_v6_top_video_rule_fr.md
- modules/memory_cards_musique_voix_fr.md
- modules/memory_cards_video_vivante_fr.md
- production/AERITH_DAVINCI_MEMORY_CARD.md
- production/CHATGPT_EXPORT_EPISODE_STRUCTURE_RECOVERY.md
- production/CHATGPT_EXPORT_PRODUCTION_PIPELINE_RECOVERY.md
- production/CHATGPT_EXPORT_YOUTUBE_PUBLISHING_RECOVERY.md
- production/CIVITAI_KNOWLEDGE_BASE.md
- production/COMFYUI_OFFICIAL_KNOWLEDGE_BASE.md
- production/COMFYUI_PIXAROMA_WORKFLOW_EXAMPLES_BASE.md
- production/COMFYUI_SA_MEMORY_CARD.md
- production/ELEVENLABS_MEMORY_CARD.md
- production/ERITHIA_CHATEAUX_VIVANTS_RUINES_CELESTES_IMAGE_COUNT_2026-05-20.md
- production/IMAGE_GENERATION_USAGE_LOG.md
- production/RUNNINGHUB_MEMORY_CARD.md
- production/aerith_7_music_orchestration_director.md
- production/aerith_7_music_orchestration_director_v2_world_extension.md
- production/memory_card_pack_plus_wan_configuration_fr.md
- production/memory_card_workflows_ltx_pixverse_runninghub_fr.md
- production/module_civitai_runninghub_workflow_mining.md
- production/module_youtube_banner_erith_ia_crystal_clear.md
- production/module_youtube_banner_erith_ia_crystal_clear_v3.md
- production/module_youtube_banner_erith_ia_crystal_clear_v4.md
- production/module_youtube_strategy_growth_erith_ia.md
- production/video_options_controller.md
- production/video_options_controller_v2.md
- workflows/ERITHIA_WAN22_I2V_HD_CORE_1080x1920.json
- workflows/WAN22_I2V_HD_ErithIA_1080x1920_Phone.json
