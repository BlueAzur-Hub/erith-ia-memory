# 🌴 HARMONIOUS_PRODUCTION_PROTOCOL_V1

Statut : Canon opérationnel V1

## Principe fondamental

Produire avec le minimum de friction et le maximum de clarté.

## Workflow canonique

Asset
↓
Nom canonique
↓
Lien sandbox
↓
Destination GitHub
↓
Commit suggéré
↓
Documentation

## Règles

1. L’asset avant la documentation.
2. Toujours fournir nom final, emplacement GitHub et commit.
3. Les images doivent être intégrées dans les fichiers .md.
4. Le rêve avant les systèmes.
5. Réduire les boucles et les questions répétitives.
6. Éviter FINAL, UPDATED, FIXED ; préférer V1, V2, V3.
7. GitHub est la mémoire canonique.
8. Aerith produit, Christophe garde la main Git.
9. En cas de blocage, annoncer immédiatement la limite.

## Formule finale

Vision
+
Asset
+
Documentation
+
GitHub
+
Méthode
=
Production harmonieuse
