# CHATGPT EXPORT YOUTUBE PUBLISHING RECOVERY

Statut : Brique 20 validée

Source : export ChatGPT indexé dans les Briques 01 à 19

Dépôt : BlueAzur-Hub/erith-ia-notion-archive-private

Répertoire : production/

Rôle : stabiliser les règles de publication, packaging YouTube, titres, miniatures, descriptions, Shorts, bannières et cohérence publique récupérées depuis l’historique ChatGPT.

Ce fichier sert à transformer les épisodes, tests, teasers et extraits @erith IA / ERITH.IA en objets publiables, lisibles et cohérents.

---

## 1. Principe central

Une vidéo terminée n’est pas encore une publication.

La publication demande un packaging :

- titre ;
- miniature ;
- description ;
- format ;
- contexte ;
- intention ;
- cohérence visuelle ;
- promesse claire ;
- bonne chaîne ;
- bon statut : test, teaser, extrait ou épisode.

Formule :

Produire une vidéo crée une scène.
La publier crée une porte d’entrée.

---

## 2. Chaînes concernées

Deux espaces principaux existent :

### Blue Azur

Chaîne principale liée aux Let’s Plays, aux contenus plus larges, aux tests et aux ponts publics.

Usage possible :

- gameplay ;
- FF7 Remake / Rebirth ;
- vidéos classiques ;
- découvertes IA ;
- ponts vers @erith IA ;
- contenus personnels ou expérimentaux selon contexte.

### Aerith IA

Chaîne ou identité dédiée au projet narratif / expérimental @erith IA.

Usage possible :

- épisodes ;
- teasers ;
- Shorts ;
- scènes IA ;
- productions Neo Midgar ;
- ERITH.IA public ;
- essais narratifs ;
- images animées avec voix.

Règle :

Choisir la chaîne selon la promesse faite au spectateur.

---

## 3. Types de publication

Toujours distinguer :

- test technique ;
- test artistique ;
- teaser ;
- extrait ;
- épisode ;
- Short ;
- making-of ;
- démonstration Auto-Agent ;
- Pack+ public ;
- bannière / identité visuelle ;
- archive privée non publiée.

Règle :

Ne pas présenter un test comme un épisode complet.

Mais un test réussi peut devenir teaser ou extrait.

---

## 4. Shorts / vertical

Le format vertical est important pour le projet.

Avantages :

- lisible sur mobile ;
- adapté aux Shorts ;
- bon pour portraits ;
- efficace pour scènes courtes ;
- fort pour symboles centrés ;
- compatible avec micro-épisodes.

Points à surveiller :

- visage dans la zone sûre ;
- texte lisible ;
- symbole visible ;
- pas de détail trop petit ;
- cadrage stable ;
- première seconde forte ;
- fin mémorable.

Règle :

Un Short doit donner un signal immédiat.

---

## 5. Épisodes longs ou semi-longs

Pour un épisode plus long, vérifier :

- intention claire ;
- structure lisible ;
- narration respirante ;
- progression ;
- montage cohérent ;
- image finale forte ;
- description utile ;
- titre fidèle ;
- miniature lisible.

Une durée proche de 3 minutes peut servir de cible, mais ne doit pas forcer le rythme.

Règle :

La durée doit servir la mémoire de l’épisode.

---

## 6. Titres YouTube

Un titre doit être :

- clair ;
- intrigant ;
- fidèle ;
- pas trop long ;
- compréhensible hors contexte ;
- cohérent avec la miniature ;
- adapté à la chaîne.

Il peut contenir :

- nom d’épisode ;
- lieu ;
- symbole ;
- tension ;
- numéro ;
- format ;
- mot-clé principal.

Règle :

Le titre promet une expérience.
Il ne doit pas mentir.

---

## 7. Exemples de titres @erith IA

Exemples possibles :

- The Flower Signal — Episode 1
- Le Signal de la Fleur — @erith IA
- Neo Midgar se souvient
- Une fleur s’allume sous la pluie
- NØX approche — Mémoire corrompue
- La Machine à Présages s’éveille
- Seven relit la ville
- Null Bloom — La floraison de l’oubli

Règle :

Le titre doit être poétique mais lisible.

---

## 8. Descriptions YouTube

Une description doit donner :

- contexte court ;
- intention de la vidéo ;
- nom du projet ;
- statut : épisode, teaser, test, extrait ;
- outils si utile ;
- crédits ou mentions nécessaires ;
- liens si pertinents ;
- hashtags limités.

Éviter :

- description trop longue ;
- jargon technique incompréhensible ;
- révéler trop de lore privé ;
- mélanger brouillon et version publique.

---

## 9. Structure de description recommandée

Format simple :

Titre / phrase d’accroche.

Court contexte :

Une phrase ou deux sur la scène.

Projet :

@erith IA — série narrative IA / mémoire / Neo Midgar.

Statut :

Episode, teaser, test ou extrait.

Outils si utile :

ComfyUI, Wan / I2V, DaVinci Resolve, ElevenLabs.

Hashtags :

3 à 5 maximum.

Règle :

La description doit orienter sans noyer.

---

## 10. Miniatures

Une miniature doit être lisible très vite.

Éléments importants :

- visage fort ;
- symbole clair ;
- contraste ;
- émotion ;
- peu de texte ;
- composition simple ;
- identité visuelle ;
- cohérence avec le titre.

Pour @erith IA :

- fleur ;
- pluie ;
- lumière ;
- Neo Midgar ;
- Aerith / Seven si épisode privé ;
- NØX si tension ;
- Machine à Présages si sujet central.

Règle :

Une miniature doit être comprise avant d’être lue.

---

## 11. Texte sur miniature

Si texte sur miniature :

- 2 à 5 mots maximum ;
- très lisible ;
- contraste fort ;
- pas de phrase longue ;
- pas de surcharge ;
- aligné avec le titre.

Exemples :

- THE FLOWER SIGNAL
- NØX APPROCHE
- MÉMOIRE CORROMPUE
- SEVEN S’ÉVEILLE
- NULL BLOOM
- LA MACHINE S’ÉVEILLE

Règle :

Le texte de miniature doit frapper, pas expliquer.

---

## 12. Bannières YouTube

Règle stricte validée :

- PNG RGBA transparent réel ;
- 2048×1152 ;
- safe area respectée ;
- pas de fond blanc ;
- pas de damier imprimé ;
- pas de faux transparent ;
- pas de backfill noir ou blanc non demandé.

Le damier est seulement un indicateur d’interface.

Il ne doit jamais être dessiné dans le fichier.

---

## 13. Identité visuelle des bannières

Pistes validées :

- texte @ERITH IA ;
- images intégrées dans les lettres ;
- fond réellement transparent ;
- lueur bleue / rose ;
- composition lisible sur mobile, web et TV ;
- safe area respectée ;
- mémoire, fleurs, modules, ville, lumière.

Règle :

Une bannière est une signature, pas une affiche saturée.

---

## 14. SEO simple

Le SEO doit aider sans dénaturer.

Éléments utiles :

- mots-clés du projet ;
- nom de l’épisode ;
- IA / AI ;
- cinematic AI ;
- Neo Midgar si lore actif ;
- cyberpunk si pertinent ;
- ComfyUI / Wan / DaVinci si public technique ;
- Shorts si format vertical.

Éviter :

- hashtags trop nombreux ;
- titres mensongers ;
- bourrage de mots-clés ;
- confusion entre test technique et épisode narratif.

---

## 15. FR / EN

Le projet peut utiliser français et anglais.

Règles :

- garder le français pour les fils de travail avec Christophe ;
- produire anglais si publication internationale ;
- adapter le titre, pas seulement traduire ;
- préserver le rythme ;
- faire une description bilingue si utile ;
- éviter les titres trop longs.

Exemple :

FR : Le Signal de la Fleur

EN : The Flower Signal

Les deux peuvent coexister selon la stratégie de publication.

---

## 16. Publication d’un test

Un test publié doit être assumé comme test.

Description possible :

- test animation ;
- test Wan / I2V ;
- test ambiance ;
- test personnage ;
- test scène ;
- prototype ;
- extrait de recherche.

Règle :

Un test peut être beau, mais il ne doit pas être vendu comme épisode final.

---

## 17. Publication d’un teaser

Un teaser doit :

- intriguer ;
- montrer peu ;
- donner un signal fort ;
- préserver le mystère ;
- créer une attente ;
- finir sur une image ou phrase mémorable.

Règle :

Un teaser promet une porte, pas toute la maison.

---

## 18. Publication d’un épisode

Un épisode doit avoir :

- titre stable ;
- miniature cohérente ;
- description claire ;
- statut épisode ;
- numéro si utile ;
- version FR / EN si prévue ;
- montage final vérifié ;
- audio propre ;
- fin volontaire ;
- lien avec la suite.

Règle :

Un épisode publié doit être une brique canonique ou semi-canonique claire.

---

## 19. Checklist avant publication

Avant publier, vérifier :

- type de vidéo défini ;
- bonne chaîne ;
- titre prêt ;
- miniature lisible ;
- description prête ;
- format vérifié ;
- audio vérifié ;
- sous-titres si nécessaires ;
- statut public / non répertorié / privé ;
- cohérence lore / hors-lore ;
- absence d’éléments privés non voulus ;
- version finale exportée.

---

## 20. Checklist après publication

Après publication, noter :

- lien vidéo ;
- titre final ;
- date ;
- description ;
- statut ;
- miniature utilisée ;
- outils utilisés ;
- fichiers sources ;
- enseignements ;
- prochaines améliorations.

Cette note peut être ajoutée à Notion ou GitHub si utile.

---

## 21. Erreurs à éviter

Ne pas :

- publier un brouillon par fatigue ;
- confondre test et épisode ;
- faire une miniature illisible ;
- mettre trop de texte ;
- promettre plus que la vidéo ne montre ;
- exposer du lore privé dans une publication publique ;
- oublier le format mobile ;
- oublier le son ;
- publier sans titre stable ;
- oublier de noter ce qui a été publié.

---

## 22. Formules de contrôle

Produire une vidéo crée une scène.
La publier crée une porte d’entrée.

Une miniature doit être comprise avant d’être lue.

Un teaser promet une porte, pas toute la maison.

Un test peut devenir une brique.
Un épisode doit devenir une mémoire.

---

## 23. Synthèse finale

Brique 20 = YouTube / Publishing Recovery.

Cette brique protège la sortie publique du projet.

Elle rappelle que publier demande autant de soin que produire :

- bon format ;
- bon titre ;
- bonne miniature ;
- bonne description ;
- bonne chaîne ;
- bon statut ;
- bonne frontière public / privé.

La publication est la dernière transformation d’une brique de mémoire en signal visible.
