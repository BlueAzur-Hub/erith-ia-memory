# 🎨 COMFYUI SA MEMORY CARD

🧠 Statut : carte mémoire production  
🌐 Projet : @erith IA / ERITH.IA  
🛠️ Outil : ComfyUI SA  
🏗️ Rôle : forge locale image / workflow / modèles / nodes

---

# 🧭 1. Rôle de la carte

Cette carte mémoire sert à stabiliser l’usage de ComfyUI SA dans la chaîne de production ERITH.IA.

ComfyUI SA est traité comme la forge locale du projet.

C’est ici que l’on construit :

- les images maîtres ;
- les prompts image ;
- les workflows JSON ;
- les tests de modèles ;
- les combinaisons checkpoint / LoRA / ControlNet ;
- les workflows Wan locaux ;
- les configurations compatibles RTX 3060 Laptop 6GB VRAM ;
- les variantes stables avant animation.

Formule :

ComfyUI SA forge l’image.  
CivitAI trouve les modèles.  
RunningHub teste le mouvement cloud.  
DaVinci assemble la mémoire animée.  
ElevenLabs donne la voix.

---

# 🎬 2. Place dans la chaîne ERITH.IA

Pipeline de référence :

image parfaite → animation Wan/I2V stable → last frame → DaVinci → narration

ComfyUI intervient surtout au début de la chaîne.

Objectif prioritaire :

obtenir une image maître solide, lisible, stable et réutilisable.

Règles :

- ne pas animer une image faible ;
- ne pas changer dix paramètres à la fois ;
- sauvegarder les workflows stables ;
- noter les modèles réellement utilisés ;
- séparer prompt positif et prompt négatif ;
- garder une version propre de chaque workflow validé ;
- ne pas casser un workflow fonctionnel pour tester une nouveauté non vérifiée.

---

# 🧩 3. Éléments à mémoriser

## 🖥️ Installation / environnement

À noter ici quand nécessaire :

- version ComfyUI ;
- installation portable / standalone / self-hosted ;
- version Python ;
- version PyTorch ;
- version CUDA ;
- GPU ;
- VRAM ;
- dossier racine ;
- dossier models ;
- dossier custom_nodes ;
- dossier workflows ;
- erreurs console importantes.

Configuration connue du projet :

- GPU : NVIDIA GeForce RTX 3060 Laptop ;
- VRAM : 6GB ;
- usage fréquent : formats portrait verticaux ;
- logique : image maître avant animation.

---

## 🧠 Modèles / checkpoints / LoRA

À noter pour chaque test utile :

- nom exact du modèle ;
- format : safetensors, ckpt, GGUF, diffusers ou autre ;
- chemin local ;
- rôle du modèle ;
- forces ;
- limites ;
- réglages recommandés ;
- prompt type ;
- négatif type ;
- verdict : garder / retester / éviter.

Règle :

Ne jamais supposer le format d’un modèle.

Si un workflow indique GGUF, ne pas remplacer mentalement par safetensors.

---

## 🧬 Workflows JSON

À noter pour chaque workflow validé :

- nom du fichier JSON ;
- chemin local ;
- usage ;
- modèles nécessaires ;
- custom nodes nécessaires ;
- résolution ;
- sampler ;
- scheduler ;
- CFG ;
- steps ;
- seed si utile ;
- points fragiles ;
- état : stable / expérimental / cassé / à archiver.

Workflow connu :

workflows/ERITH.IA_HORS_LORE_STYLE_LOCK_V1_WAN22_I2V_OPTIONS_PLUS_V4_GGUF_REAL.json

Modèles Wan 2.2 I2V GGUF connus :

models/unet/Wan2.2-I2V-A14B-HighNoise-Q3_K_S.gguf  
models/unet/Wan2.2-I2V-A14B-LowNoise-Q3_K_S.gguf

---

## 🌊 Core Wan — Wan 2.2 Image to Video HD

Fichier source harmonisé par Christophe :

Wan+2.2+Image+to+Video+HD(CORE).json

Statut :

Core Wan validé.

Ce workflow devient la base de référence pour les animations Wan 2.2 I2V HD du projet.

Validation récente :

- animation Akira V2 réussie ;
- rendu jugé parfait ;
- résultat encore meilleur que la version précédente ;
- pipeline DaVinci 1024 × 1536 confirmé comme valide.

Règle centrale :

Ce Core Wan ne doit pas être reconstruit par le Chat.

Il doit être conservé comme workflow harmonisé.

Quand il est modifié, ne changer qu’une seule variable à la fois.

Si la demande est décoration : titres, couleurs, groupes et notes uniquement.

Si la demande est production : changer seulement l’image source, le prompt positif, le prompt négatif, ou la résolution si Christophe le demande explicitement.

## Structure Core Wan

Résolution de référence :

- Width : 1024
- Height : 1536
- format : vertical ERITH.IA / ChatGPT source image

Important :

La largeur et la hauteur sont pilotées par deux nodes Easy-Use :

- easy int Width = 1024
- easy int Height = 1536

Le node WanImageToVideo peut afficher encore 480 × 832 dans ses widgets internes, mais les entrées connectées width / height prennent le dessus.

## Modèles Core Wan

GGUF High Noise :

wan2.2_i2v_A14b_high_noise_lightx2v_4step-Q6_K.gguf

GGUF Low Noise :

wan2.2_i2v_A14b_low_noise_lightx2v_4step-Q6_K.gguf

Text encoder :

umt5_xxl_fp8_e4m3fn_scaled.safetensors

VAE :

wan_2.1_vae.safetensors

## Nodes importants

Core nodes :

- LoadImage
- CLIPLoader
- CLIPTextEncode positif
- CLIPTextEncode négatif actif
- VAELoader
- UnetLoaderGGUF High
- UnetLoaderGGUF Low
- PathchSageAttentionKJ High
- PathchSageAttentionKJ Low
- ModelSamplingSD3 High
- ModelSamplingSD3 Low
- WanImageToVideo
- KSamplerAdvanced High Noise
- KSamplerAdvanced Low Noise
- VAEDecode
- VHS_VideoCombine
- WanAdvancedExtractLastImages
- SaveImage

Custom nodes nécessaires :

- ComfyUI-GGUF
- ComfyUI-VideoHelperSuite
- ComfyUI-Easy-Use
- KJNodes ou équivalent pour PathchSageAttentionKJ
- node WanAdvancedExtractLastImages disponible dans l’environnement utilisé

## Prompt positif / négatif

Le Core Wan utilise deux prompts séparés.

Prompt positif :

- node CLIPTextEncode positif ;
- sert à diriger le mouvement, la caméra, l’atmosphère et la continuité.

Prompt négatif :

- node CLIPTextEncode négatif actif ;
- branché vers l’entrée negative de WanImageToVideo ;
- sert à empêcher changement de scène, redesign, warping, flicker, duplication, mauvaise perspective et artefacts.

Règle :

Le prompt négatif texte est la méthode de travail ERITH.IA.

Ne pas remplacer ce fonctionnement par un simple ConditioningZeroOut si Christophe demande de garder le workflow harmonisé.

Note :

Un node ConditioningZeroOut peut rester présent dans certains graphes hérités, mais le négatif principal du Core Wan est le CLIPTextEncode négatif actif.

## Sampling Core Wan

High Noise :

- KSamplerAdvanced
- add_noise : enable
- seed : randomize
- steps : 6
- CFG : 1
- sampler : euler
- scheduler : beta
- start_at_step : 0
- end_at_step : 3
- return_with_leftover_noise : enable

Low Noise :

- KSamplerAdvanced
- add_noise : disable
- seed : fixed
- steps : 6
- CFG : 1
- sampler : euler
- scheduler : beta
- start_at_step : 3
- end_at_step : 6
- return_with_leftover_noise : disable

ModelSamplingSD3 :

- shift : 5

Sage Attention patch :

- sage_attention : auto
- allow_compile : false

## Sorties Core Wan

Sortie vidéo principale :

VHS_VideoCombine

Paramètres vidéo :

- format : video/h264-mp4
- frame_rate : 16
- pix_fmt : yuv420p
- crf : 19
- save_output : true

Sortie last frame :

VAEDecode → WanAdvancedExtractLastImages → SaveImage

Réglage last frame :

- num_frames : 1
- filename_prefix observé : last_frame_cyber_oracle

Usage :

La last frame sert à la continuité LEGO, à la suite Wan/I2V et aux raccords DaVinci.

## Règles Core Wan

Ne pas :

- reconstruire le workflow à partir de zéro ;
- supprimer les prompts séparés ;
- supprimer la last frame ;
- changer les modèles sans raison ;
- changer la résolution sans décision explicite ;
- remplacer MP4 par WebP ;
- modifier plusieurs paramètres à la fois ;
- confondre décoration et correction fonctionnelle.

Faire :

- conserver ce workflow comme Core Wan ;
- tester avec une image validée ;
- garder le prompt négatif actif ;
- exporter en MP4 réel ;
- récupérer la last frame ;
- monter dans DaVinci en 1024 × 1536 si la source est en 1024 × 1536 ;
- ne relancer qu’avec une intention claire.

Phrase mémoire :

Core Wan = workflow Wan 2.2 I2V HD harmonisé par Christophe.

Image 1024 × 1536 → Wan Core → MP4 réel → last frame → DaVinci 1024 × 1536.

---

## 🌐 Base officielle ComfyUI

Fichier de référence ajouté :

production/COMFYUI_OFFICIAL_KNOWLEDGE_BASE.md

Rôle :

conserver une base officielle courte issue de comfy.org et docs.comfy.org.

Elle sert à rappeler :

- Comfy Local ;
- Comfy Cloud ;
- Comfy API ;
- Comfy Hub / Workflows ;
- les concepts workflow, nodes, modèles, templates ;
- les règles de nodes manquants ;
- la différence entre décoration et correction fonctionnelle.

Règle centrale :

ComfyUI est un système de graphes.

Un workflow JSON est un objet de production.

Décorer un workflow ne doit jamais modifier :

- nodes ;
- links ;
- widgets ;
- modèles ;
- prompts ;
- logique.

Corriger un workflow signifie modifier la logique, et doit être demandé explicitement.

---

## 🧬 Base CivitAI

Fichier de référence ajouté :

production/CIVITAI_KNOWLEDGE_BASE.md

Rôle :

conserver une base de travail pour CivitAI, ses modèles, ses LoRA, ses checkpoints, ses exemples de prompts et sa chaîne YouTube.

Source vidéo suivie :

https://www.youtube.com/@civitai/videos

Elle sert à rappeler :

- CivitAI trouve les modèles ;
- ComfyUI teste les modèles ;
- GitHub stabilise les résultats ;
- Notion présente les fiches utiles ;
- la direction artistique ERITH.IA décide.

Règles CivitAI :

- ne pas télécharger en masse ;
- vérifier le type exact : checkpoint, LoRA, embedding, VAE, ControlNet, workflow ;
- vérifier le base model : SD1.5, SDXL, Flux, Pony, Illustrious, etc. ;
- vérifier les trigger words ;
- vérifier les exemples de prompts ;
- vérifier les licences et restrictions ;
- tester dans ComfyUI avant d’intégrer à la mémoire ;
- ne pas confondre popularité CivitAI et utilité réelle pour @erith IA.

---

## 🎞️ Base d’exemples Pixaroma

Fichier de référence ajouté :

production/COMFYUI_PIXAROMA_WORKFLOW_EXAMPLES_BASE.md

Rôle :

conserver les workflows Pixaroma EP06 et Getting Started comme base d’exemples ComfyUI pour les générations futures.

Ils servent de référence pour :

- les noms de nodes ;
- les branchements fonctionnels ;
- les structures image / img2img / I2V / upscale vidéo ;
- les workflows Wan 2.2 ;
- les workflows LTX-2 ;
- SeedVR2 pour l’upscale vidéo ;
- l’export vidéo via VHS_VideoCombine.

Règle essentielle :

Pixaroma sert de grammaire de câblage, pas de vérité absolue.

Pour générer un workflow @erith IA :

- partir d’un exemple Pixaroma proche ;
- adapter seulement l’image source, les prompts, les modèles réels, le nom de sortie et les paramètres nécessaires ;
- ne pas inventer de nodes si un exemple Pixaroma existe ;
- pour la vidéo, utiliser VHS_VideoCombine comme sortie principale ;
- ne plus considérer SaveAnimatedWEBP comme preuve d’animation.

Leçon Velocity V2 :

WebP fixe ≠ animation exploitable.

Pour valider une animation, il faut une vraie sortie vidéo : MP4, WEBM réel, séquence d’images ou fichier lisible dans DaVinci.

---

# 🌐 4. Aide intégrée / Recherche Internet

Cette carte mémoire ne doit pas seulement stocker les réglages internes du projet.

Elle doit aussi servir de point de départ pour rechercher rapidement les informations actuelles sur internet quand ComfyUI évolue, quand un node change, quand un modèle est mis à jour ou quand une erreur apparaît.

Règle :

Ne pas figer une information technique sensible si elle peut changer rapidement.

Toujours vérifier en ligne pour :

- nouvelles versions ;
- changements d’interface ;
- changelog ;
- nodes récents ;
- custom nodes à risque ;
- dépendances Python ;
- compatibilité PyTorch / CUDA ;
- modèles récents ;
- bugs récents ;
- API locale ;
- API cloud ;
- workflows vidéo ;
- solutions d’erreurs ;
- modèles CivitAI récents ;
- licences CivitAI ;
- trigger words CivitAI ;
- vidéos CivitAI utiles.

Sources prioritaires :

1. documentation officielle ComfyUI ;
2. GitHub officiel ComfyUI ;
3. documentation des nodes officiels ;
4. pages des custom nodes utilisées ;
5. issues GitHub pertinentes ;
6. pages modèles CivitAI ;
7. chaîne YouTube CivitAI ;
8. Discord / forum / Reddit seulement en complément ;
9. tutoriels YouTube seulement après vérification croisée.

Source officielle de départ :

https://docs.comfy.org/

Sources Comfy à connaître :

- https://comfy.org/
- https://comfy.org/download
- https://comfy.org/api
- https://comfy.org/workflows
- https://docs.comfy.org/
- https://docs.comfy.org/development/core-concepts/workflow
- https://docs.comfy.org/development/core-concepts/nodes
- https://docs.comfy.org/development/core-concepts/models
- https://docs.comfy.org/interface/features/template
- https://docs.comfy.org/interface/features/partial-execution

Sources CivitAI à connaître :

- https://civitai.com/
- https://www.youtube.com/@civitai/videos

Notes vérifiées le 2026-05-16 :

La documentation officielle ComfyUI présente ComfyUI comme une application open source node-based pour l’IA générative, capable de tourner localement. Elle couvre notamment l’installation, les workflows, les nodes, les custom nodes, les modèles, les dépendances, les templates, l’API locale et l’API cloud.

---

# 🔎 5. Requêtes internet utiles

Recherches rapides :

- ComfyUI official docs workflow
- ComfyUI custom nodes install
- ComfyUI models folder structure
- ComfyUI Wan 2.2 I2V GGUF workflow
- ComfyUI RTX 3060 6GB VRAM settings
- ComfyUI CUDA PyTorch error
- ComfyUI Manager update nodes
- ComfyUI workflow JSON import error
- ComfyUI missing node fix
- ComfyUI local API workflow
- ComfyUI cloud API workflow
- ComfyUI video workflow Wan I2V
- ComfyUI VHS VideoCombine MP4 workflow
- ComfyUI Wan 2.2 Image to Video VideoCombine
- ComfyUI LTX-2 Image to Video workflow
- ComfyUI SeedVR2 video upscale workflow
- ComfyUI workflow templates missing models
- ComfyUI partial execution output node
- ComfyUI API dynamic workflow inputs
- CivitAI Akira anime motorcycle LoRA
- CivitAI retro anime film LoRA
- CivitAI cyberpunk city LoRA
- CivitAI cinematic anime checkpoint SDXL
- CivitAI motorcycle LoRA SDXL
- CivitAI speed lines anime LoRA
- CivitAI cel shading checkpoint
- CivitAI ComfyUI workflow Wan image to video
- CivitAI Flux cyberpunk model
- CivitAI SDXL anime city checkpoint

---

# ✅ 6. Checklist avant modification

Avant de modifier un workflow ComfyUI :

- vérifier le nom exact du fichier ;
- sauvegarder le JSON stable ;
- noter le modèle actuel ;
- noter les nodes nécessaires ;
- vérifier les chemins locaux ;
- ne changer qu’une variable à la fois ;
- lancer un test court ;
- lire la console en cas d’erreur ;
- noter le verdict.

Avant d’installer un custom node :

- vérifier la source ;
- vérifier la date de mise à jour ;
- vérifier les issues récentes ;
- vérifier les dépendances ;
- éviter les dépôts obscurs ;
- ne pas installer en chaîne sans comprendre l’impact.

Avant de décorer un workflow :

- ne modifier que titres ;
- couleurs ;
- groupes ;
- notes Markdown ;
- ne jamais modifier prompts, widgets, nodes ou liens sans demande explicite.

Avant d’intégrer un modèle CivitAI :

- vérifier type ;
- base model ;
- fichier ;
- licence ;
- trigger words ;
- dossier ComfyUI ;
- résultat réel dans un test local.

Avant de modifier le Core Wan :

- confirmer que Christophe veut une modification fonctionnelle ;
- garder une copie intacte du JSON harmonisé ;
- ne pas supprimer le prompt négatif actif ;
- ne pas supprimer la sortie MP4 ;
- ne pas supprimer la last frame ;
- ne pas remplacer les réglages 1024 × 1536 sans demande explicite ;
- ne changer qu’une seule variable à la fois.

---

# 🧪 7. Notes de test à remplir

Template :

Nom du test :  
Date :  
Workflow :  
Modèle :  
LoRA :  
ControlNet :  
Résolution :  
Sampler :  
Scheduler :  
Steps :  
CFG :  
Seed :  
Prompt positif :  
Prompt négatif :  
Résultat :  
Problème :  
Solution :  
Verdict : garder / retester / éviter

Template CivitAI :

Nom du modèle :  
URL CivitAI :  
Type :  
Base model :  
Version :  
Fichier :  
Trigger words :  
Prompt exemple :  
Négatif exemple :  
Chemin ComfyUI :  
Résultat test :  
Verdict :

Template Core Wan :

Nom du test :  
Image source :  
Workflow : Wan+2.2+Image+to+Video+HD(CORE).json  
Résolution : 1024 × 1536  
Prompt positif :  
Prompt négatif :  
Sortie MP4 :  
Last frame :  
DaVinci timeline : 1024 × 1536  
Résultat :  
Verdict :

---

# 🛡️ 8. Règles de sécurité

Ne jamais installer un custom node inconnu sans vérification.

Ne jamais remplacer un workflow stable sans sauvegarde.

Ne jamais changer modèle + LoRA + nodes + résolution + prompt dans le même test.

Ne jamais transformer une erreur locale en hypothèse vague : lire la console, identifier le node, noter la cause.

Ne jamais oublier la contrainte VRAM.

Ne jamais générer un workflow vidéo sans vraie sortie vidéo exploitable.

Ne jamais confondre décoration visuelle et correction fonctionnelle.

Ne jamais intégrer un modèle CivitAI sans test réel.

Ne jamais reconstruire le Core Wan si le fichier harmonisé fonctionne.

---

# 🌸 9. Phrase mémoire

ComfyUI SA est la forge locale.

ComfyUI est un système de graphes.

CivitAI sert à trouver les modèles.

Internet vérifie les nodes, modèles, dépendances et erreurs du moment.

La mémoire garde les méthodes stables.

La base officielle Comfy donne la théorie.

Pixaroma sert de base d’exemples de câblage ComfyUI.

Le Core Wan est la base Wan 2.2 I2V HD harmonisée par Christophe.

On ne casse jamais un workflow validé pour suivre une nouveauté non vérifiée.
