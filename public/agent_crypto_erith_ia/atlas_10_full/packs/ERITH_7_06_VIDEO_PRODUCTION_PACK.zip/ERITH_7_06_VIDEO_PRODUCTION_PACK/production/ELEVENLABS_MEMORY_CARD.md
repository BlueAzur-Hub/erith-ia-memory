# ELEVENLABS MEMORY CARD

Statut : carte mémoire production  
Projet : @erith IA / ERITH.IA  
Outil : ElevenLabs  
Rôle : voix / narration / doublage / respiration / incarnation sonore

---

# 1. Rôle de la carte

Cette carte mémoire sert à stabiliser l’usage d’ElevenLabs dans la chaîne de production ERITH.IA.

ElevenLabs est traité comme la chambre de voix du projet.

C’est ici que l’on organise :

- voix off ;
- narration française ;
- narration anglaise ;
- doublage ;
- diction ;
- respiration ;
- pauses ;
- rythme oral ;
- prononciation ;
- exports audio ;
- versions FR / EN ;
- réglages vocaux ;
- voix validées ;
- erreurs à éviter ;
- alignement avec DaVinci.

Formule :

ComfyUI SA forge l’image.  
RunningHub teste le mouvement cloud.  
DaVinci assemble la mémoire animée.  
ElevenLabs donne la voix.

---

# 2. Place dans la chaîne ERITH.IA

Pipeline de référence :

image parfaite → animation Wan/I2V stable → last frame → DaVinci → narration

ElevenLabs intervient surtout au moment où le texte devient présence.

Objectif prioritaire :

produire une voix claire, émotionnelle, contrôlée et compatible avec le montage DaVinci.

Règles :

- garder un script texte propre avant génération ;
- prévoir les pauses ;
- éviter les phrases trop longues ;
- vérifier la prononciation des noms propres ;
- produire une version FR propre ;
- produire une version EN propre si nécessaire ;
- écouter avant d’intégrer dans DaVinci ;
- conserver les meilleurs réglages ;
- ne pas utiliser de voix clonée sans consentement clair.

---

# 3. Éléments à mémoriser

## Voix utilisées

À noter pour chaque voix validée :

- nom de la voix ;
- voice ID si utile ;
- langue ;
- modèle ;
- usage ;
- stabilité ;
- similarité ;
- expressivité ;
- style ;
- rythme naturel ;
- forces ;
- limites ;
- prononciations à surveiller ;
- verdict : garder / retester / éviter.

---

## Scripts et narration

À noter pour chaque production :

- titre du script ;
- langue ;
- durée visée ;
- durée obtenue ;
- nombre de caractères ;
- voix utilisée ;
- réglages ;
- pauses ;
- émotion visée ;
- version intégrée dans DaVinci ;
- corrections de prononciation ;
- verdict.

Règle :

La voix ne doit pas seulement lire.

Elle doit porter le rythme, l’image et l’émotion du montage.

---

# 4. Aide intégrée / Recherche Internet

Cette carte mémoire ne doit pas seulement stocker les voix et réglages validés.

Elle doit aussi servir de point de départ pour vérifier les capacités actuelles d’ElevenLabs, les modèles disponibles, les limites, les crédits, les nouvelles fonctions et les règles d’usage.

Règle :

Ne pas supposer qu’un réglage ancien est encore optimal.

Toujours vérifier en ligne pour :

- modèles vocaux récents ;
- langues supportées ;
- limites de caractères ;
- crédits / tarifs ;
- doublage ;
- text to speech ;
- speech to text ;
- forced alignment ;
- pronunciation dictionary ;
- voice changer ;
- voice isolator ;
- sound effects ;
- music ;
- voice agents ;
- règles de clonage vocal ;
- API ;
- SDK ;
- changements de l’application web.

Sources prioritaires :

1. documentation officielle ElevenLabs ;
2. changelog officiel ;
3. pages officielles API / SDK ;
4. pages officielles des modèles ;
5. documentation sécurité / voice cloning ;
6. retours communautaires seulement en complément ;
7. tutoriels YouTube seulement après vérification croisée.

Source officielle de départ :

https://elevenlabs.io/docs

Notes vérifiées le 2026-05-14 :

La documentation officielle ElevenLabs présente des fonctions comme Text to Speech, Speech to Text, Music, Text to Dialogue, Voice Changer, Voice Isolator, Dubbing, Sound Effects, Voices, Forced Alignment et Voice Agents. Elle indique aussi des usages via API REST, SDK Python / TypeScript et application web sans code.

---

# 5. Requêtes internet utiles

Recherches rapides :

- ElevenLabs official docs text to speech
- ElevenLabs voice settings stability similarity style
- ElevenLabs multilingual French voice settings
- ElevenLabs dubbing docs
- ElevenLabs forced alignment docs
- ElevenLabs pronunciation dictionary
- ElevenLabs voice cloning safety
- ElevenLabs credits pricing
- ElevenLabs voice isolator
- ElevenLabs sound effects docs
- ElevenLabs voice agents docs
- ElevenLabs API Python SDK
- ElevenLabs French narration best settings

---

# 6. Checklist avant génération voix

Avant de générer :

- vérifier le script ;
- vérifier la langue ;
- vérifier la durée visée ;
- vérifier le modèle ;
- vérifier la voix ;
- vérifier les réglages ;
- prévoir les pauses ;
- corriger les noms propres ;
- vérifier le nombre de caractères ;
- vérifier le coût en crédits ;
- conserver la version texte.

Après génération :

- écouter en entier ;
- repérer les erreurs de prononciation ;
- vérifier les respirations ;
- vérifier le rythme ;
- vérifier l’émotion ;
- vérifier le format audio ;
- importer dans DaVinci ;
- noter les corrections.

---

# 7. Notes de test à remplir

Template :

Titre :  
Date :  
Langue :  
Voix :  
Voice ID :  
Modèle :  
Réglages :  
Texte source :  
Durée visée :  
Durée obtenue :  
Crédits / coût :  
Qualité diction :  
Qualité émotion :  
Respiration :  
Pauses :  
Prononciation :  
Format export :  
Intégration DaVinci :  
Problème :  
Solution :  
Verdict : garder / retester / éviter

---

# 8. Règles de sécurité voix

Ne jamais utiliser une voix clonée sans consentement clair.

Ne jamais supposer qu’une voix est libre d’usage si la licence n’est pas vérifiée.

Ne jamais publier une voix qui imite une personne réelle sans cadre autorisé.

Ne jamais sacrifier la clarté du script pour une émotion excessive.

Ne jamais effacer le texte source validé.

---

# 9. Règles de narration ERITH.IA

Pour une narration ERITH.IA :

- phrases courtes ;
- images claires ;
- souffle contrôlé ;
- rythme respirable ;
- émotion sans surjeu ;
- pauses assumées ;
- diction nette ;
- version française propre ;
- version anglaise si nécessaire ;
- calage DaVinci avant export final.

Pour une narration hors-lore cyberpunk :

- ton noir ;
- mélancolie urbaine ;
- tension douce ;
- voix proche ;
- mystère ;
- précision ;
- pas de lore privé ;
- pas de noms internes ;
- univers original.

---

# 10. Phrase mémoire

ElevenLabs est la chambre de voix.

Internet vérifie les modèles, limites, droits et fonctions actuelles.

La carte mémoire conserve les voix validées, les réglages utiles et les erreurs à ne pas répéter.

La voix doit servir l’image, pas l’écraser.
