# 🌐 COMFYUI — OFFICIAL KNOWLEDGE BASE

🧠 Statut : base de connaissance officielle courte  
🌐 Projet : @erith IA / ERITH.IA  
🛠️ Source principale : comfy.org et docs.comfy.org  
🗓️ Vérification : 2026-05-16

Ce fichier complète la carte ComfyUI principale.

Il sert à donner au Chat / Seven / aux LLM une base officielle stable avant de générer, corriger ou décorer des workflows ComfyUI.

---

# 1. Carte de l’écosystème Comfy

## ComfyUI / Comfy

Comfy est présenté comme un moteur de création IA visuelle pour les professionnels qui veulent contrôler les modèles, les paramètres et les sorties.

Principe central :

modèles → nodes → liens → workflow → sortie.

ComfyUI est une interface et un moteur d’inférence node-based pour l’IA générative. Les workflows se construisent comme des graphes de nodes.

## Comfy Local

Comfy Local sert à exécuter ComfyUI sur sa propre machine.

À retenir pour @erith IA :

- idéal pour la forge locale ;
- compatible avec les modèles open source ;
- utile pour tester, comprendre, modifier et versionner les workflows ;
- dépend fortement du GPU, de la VRAM, des modèles installés et des custom nodes.

## Comfy Cloud

Comfy Cloud sert à exécuter les workflows avec des GPU cloud.

À retenir :

- utile pour les jobs vidéo lourds ;
- évite certaines limites VRAM locales ;
- même workflow possible entre Local et Cloud si les nodes et modèles existent ;
- ne dispense pas de vérifier les nodes manquants et les modèles attendus.

## Comfy API

Comfy API sert à transformer un workflow en endpoint de production.

Logique :

workflow stable → export API → paramètres injectés dynamiquement → suivi de progression → récupération des sorties.

À retenir pour plus tard :

- utile pour automatiser des générations ;
- chaque prompt, image, seed ou paramètre de node peut devenir une entrée dynamique ;
- priorité actuelle : stabiliser les workflows avant d’automatiser.

## Comfy Hub / Workflows

Comfy Hub regroupe des workflows communautaires et des modèles populaires.

Catégories utiles :

- Image ;
- Text to Image ;
- Image to Video ;
- Text to Video ;
- Video ;
- Video to Video ;
- Image Edit ;
- Partner Nodes.

Modèles observés dans la zone workflows :

- Wan2.2 ;
- LTX ;
- Seedance ;
- Grok ;
- Qwen Image Edit ;
- Z-Image-Turbo.

---

# 2. Concepts officiels à retenir

## Workflow

Un workflow ComfyUI est un graphe de nodes connectés.

Il peut générer différents types de médias : image, vidéo, audio, modèle IA, agent IA ou autres sorties.

Un workflow peut être sauvegardé :

- dans les métadonnées d’une image générée ;
- dans un fichier JSON lisible et versionnable.

Règle @erith IA :

un workflow JSON est un objet de production. On le versionne, on le nomme proprement et on évite de modifier sa logique sans demande explicite.

## Nodes

Les nodes sont les blocs de base.

Ils reçoivent des entrées, exécutent une fonction et produisent des sorties.

Les liens doivent respecter les types de données : model, CLIP, VAE, conditioning, latent, image, mask, nombres, etc.

Règle @erith IA :

ne jamais modifier un câblage fonctionnel juste pour décorer un fichier.

Décorer signifie : titres, couleurs, groupes, notes visuelles.

Corriger signifie : modifier nodes, liens, widgets ou logique. Cela doit être demandé explicitement.

## Nodes manquants

Quand un workflow importé affiche un node manquant, deux causes principales existent :

- ComfyUI trop ancien pour un node core ;
- custom node absent de l’installation.

Réponse correcte :

identifier le node manquant, puis vérifier s’il faut mettre à jour ComfyUI ou installer le custom node nécessaire.

## Modèles

Les modèles sont les fichiers de poids : checkpoints, VAE, LoRA, ControlNet, upscalers, text encoders, diffusion models, etc.

Ils ne sont pas tous inclus avec ComfyUI.

Ils doivent être placés dans les bons dossiers sous ComfyUI/models ou déclarés via extra_model_paths.

Règle @erith IA :

ne jamais supposer qu’un modèle existe. Toujours respecter les noms réellement présents dans la machine ou dans RunningHub.

## Templates

Les Workflow Templates servent de base officielle pour les modèles supportés et certains custom nodes.

Quand un template est chargé, ComfyUI peut détecter les modèles manquants et proposer leur téléchargement.

Règle @erith IA :

avant d’inventer un workflow, chercher s’il existe un template officiel ou un exemple fiable proche.

## Partial Execution

Partial Execution permet de lancer seulement une branche du workflow jusqu’à un node de sortie.

Usage utile :

- tester une branche SaveImage ;
- vérifier un export vidéo ;
- éviter de relancer tout un workflow lourd.

Limite :

fonction disponible sur les nodes de sortie compatibles et dépendante de la version du frontend.

---

# 3. Règles de génération de workflows pour Seven / Chat

Quand Seven génère un workflow ComfyUI :

1. Identifier le type de workflow : image, img2img, I2V, T2V, V2V, upscale, API.
2. Chercher d’abord une base fiable : template officiel, Pixaroma, workflow validé local, workflow RunningHub fonctionnel.
3. Conserver la logique si le workflow fonctionne.
4. Ne modifier que ce qui est demandé.
5. Si la demande est décoration : titres, couleurs, groupes, notes, rien d’autre.
6. Si la demande est correction : expliquer précisément les nodes, liens ou widgets modifiés.
7. Vérifier les nodes custom : ComfyUI-GGUF, VideoHelperSuite, Easy-Use, KJNodes, etc.
8. Vérifier les modèles : noms exacts, dossiers exacts, type exact.
9. Pour la vidéo, prévoir une vraie sortie vidéo : MP4, WEBM réel ou séquence d’images.
10. Ne jamais considérer un WebP fixe comme preuve d’animation.

---

# 4. Base de données courte

## Comfy Local

Rôle : forge locale.

Usage @erith IA : image maître, tests modèles, JSON, ComfyUI SA, RTX 3060 Laptop 6GB VRAM.

Point de vigilance : VRAM, custom nodes, chemins modèles.

## Comfy Cloud / RunningHub-like

Rôle : exécution cloud de workflows lourds.

Usage @erith IA : Wan / I2V / vidéo lourde.

Point de vigilance : nodes manquants, modèles non disponibles, exports vidéo.

## Comfy API

Rôle : industrialiser un workflow stable.

Usage futur : génération automatisée, paramètres dynamiques, production en série.

Point de vigilance : ne pas automatiser un workflow non stabilisé.

## Comfy Hub

Rôle : bibliothèque de workflows communautaires.

Usage @erith IA : inspiration, comparaison, recherche de graphes récents.

Point de vigilance : vérifier les nodes et modèles avant usage.

## Documentation officielle

Rôle : source de vérité technique.

Usage @erith IA : comprendre workflow, nodes, modèles, links, templates, API, erreurs.

Point de vigilance : ComfyUI évolue vite, donc vérifier les pages actuelles quand une erreur apparaît.

---

# 5. Sources officielles à consulter

- https://comfy.org/
- https://comfy.org/download
- https://comfy.org/api
- https://comfy.org/workflows
- https://docs.comfy.org/
- https://docs.comfy.org/development/core-concepts/workflow
- https://docs.comfy.org/development/core-concepts/nodes
- https://docs.comfy.org/development/core-concepts/models
- https://docs.comfy.org/interface/features/template
- https://docs.comfy.org/interface/features/partial-execution

---

# 6. Phrase mémoire

ComfyUI est un système de graphes.

Les workflows sont des fichiers JSON vivants.

Les nodes sont les briques.

Les modèles sont les poids.

Les liens sont le câblage.

La décoration ne doit jamais casser la logique.

La correction doit toujours être explicite.

Pour @erith IA : image maître d’abord, animation stable ensuite, sortie vidéo réelle, last frame, DaVinci.
