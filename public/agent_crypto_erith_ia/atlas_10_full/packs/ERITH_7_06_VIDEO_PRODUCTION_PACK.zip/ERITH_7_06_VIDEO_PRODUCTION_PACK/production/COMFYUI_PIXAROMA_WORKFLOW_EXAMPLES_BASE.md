# 🎬 COMFYUI — PIXAROMA WORKFLOWS BASE EXAMPLES

🎨 Statut : addendum de référence pour la carte ComfyUI  
🧠 Projet : @erith IA / ERITH.IA  
📦 Source : archive Workflow.zip, issue des workflows Pixaroma

Ce fichier ne remplace pas la carte ComfyUI principale.

Il sert à ajouter une base d’exemples fiables pour aider le Chat / Seven / les LLM à générer des workflows ComfyUI plus compatibles avec la configuration réelle.

---

# 🧭 1. Principe

Les workflows Pixaroma doivent être utilisés comme exemples de câblage, pas comme vérité absolue.

Ils servent à apprendre :

- les noms exacts de nodes ;
- les branchements ComfyUI fonctionnels ;
- les sorties vidéo correctes ;
- les structures Wan / LTX / upscale ;
- la différence entre workflow image et workflow vidéo ;
- les formats d’export réellement exploitables.

Règle importante :

Un workflow généré pour @erith IA doit rester adapté au projet, mais s’appuyer sur ces exemples quand il faut produire un JSON ComfyUI compatible.

---

# 📦 2. Archive de référence

Archive locale de référence :

Workflow.zip

Contenu observé :

## 🖼️ Getting Started / image

- 0 Help and Resources.json
- 1 Juggernaut Reborn txt2img.json
- 2 Juggernaut Reborn img2img.json
- 3 Juggernaut Reborn txt2img + Lora.json
- 4 Juggernaut Reborn txt2img + ControlNet.json
- 5a Z-Image Turbo Fp8 AIO txt2img.json
- 5b Z-Image Turbo Fp8 txt2img.json
- 5c Z-Image Turbo GGUF txt2img.json
- 6 Z-Image Turbo Fp8 AIO txt2img + Lora.json
- 7 Z-Image Turbo Fp8 AIO txt2img + ControlNet.json

## 🎞️ EP06 / vidéo

- LTX-2 Image to Video with Audio.json
- LTX-2 Image to Video with Custom Audio.json
- Video Upscale SeedVR2.json
- Wan 2.2 Image to Video.json
- Wan 2.2 Image to Video + Lora.json

---

# 🛠️ 3. Utilité pour @erith IA

Ces workflows sont utiles pour trois fonctions.

## 🖼️ 3.1 Génération d’images fixes

Les workflows Juggernaut / Z-Image servent surtout de grammaire ComfyUI :

- CheckpointLoaderSimple ;
- CLIPTextEncode ;
- EmptyLatentImage / EmptySD3LatentImage ;
- KSampler ;
- VAEDecode ;
- SaveImage ;
- LoadImage ;
- VAEEncode ;
- ControlNetApplyAdvanced ;
- LoraLoaderModelOnly ;
- UnetLoaderGGUF.

Usage recommandé :

Référence de câblage image uniquement.

Ne pas utiliser ces workflows comme base directe pour animer Velocity V2 si le master existe déjà.

## 🎥 3.2 Animation image-to-video

Les workflows Wan 2.2 Image to Video sont la base principale pour l’animation.

Ils montrent une structure correcte :

- LoadImage ;
- CLIPLoader ;
- VAELoader ;
- UnetLoaderGGUF HighNoise ;
- UnetLoaderGGUF LowNoise ;
- ModelSamplingSD3 ;
- CLIPTextEncode positif ;
- ConditioningZeroOut / négatif ;
- WanImageToVideo ;
- KSamplerAdvanced HighNoise ;
- KSamplerAdvanced LowNoise ;
- VAEDecode ;
- VHS_VideoCombine.

Point clé :

Pour la vidéo, la sortie fiable n’est pas SaveAnimatedWEBP.

La sortie fiable est :

VHS_VideoCombine

avec export vidéo réel.

## 🔍 3.3 Upscale vidéo

SeedVR2 sert de référence pour la fin de pipeline.

Structure utile :

- VHS_LoadVideo ;
- VHS_VideoInfo ;
- SeedVR2LoadDiTModel ;
- SeedVR2LoadVAEModel ;
- SeedVR2VideoUpscaler ;
- VHS_VideoCombine.

Usage recommandé :

Après validation d’une animation courte, pas avant.

---

# ⚠️ 4. Leçon importante après le test Velocity V2

Erreur constatée :

Un WebP peut être fixe.

Donc :

WebP fixe ≠ animation exploitable.

Pour valider une animation, il faut une vraie sortie vidéo :

- MP4 ;
- WEBM réel ;
- fichier vidéo lisible dans DaVinci ;
- ou séquence d’images complète.

Règle pour les futurs workflows :

Ne jamais considérer SaveAnimatedWEBP comme preuve suffisante d’animation.

Toujours prévoir :

- VHS_VideoCombine pour la vidéo ;
- SaveImage pour la last frame ;
- éventuellement PreviewImage seulement comme confort visuel.

---

# 🎞️ 5. Référence Wan 2.2 Pixaroma

Workflow principal :

Wan 2.2/Wan 2.2 Image to Video.json

Structure observée :

- CLIPLoader : umt5_xxl_fp8_e4m3fn_scaled.safetensors
- type : wan
- VAE : wan_2.1_vae.safetensors
- WanImageToVideo : 480 x 832, 81 frames, batch 1
- VideoCombine : H264 MP4, 16 fps, yuv420p, CRF 19

Modèles GGUF Pixaroma :

- wan2.2_i2v_A14b_high_noise_lightx2v_4step-Q6_K.gguf
- wan2.2_i2v_A14b_low_noise_lightx2v_4step-Q6_K.gguf

Réglages sampler Pixaroma :

HighNoise :

- KSamplerAdvanced
- steps : 6
- CFG : 1
- sampler : euler
- scheduler : beta
- start : 0
- end : 3
- return_with_leftover_noise : enable

LowNoise :

- KSamplerAdvanced
- steps : 6
- CFG : 1
- sampler : euler
- scheduler : beta
- start : 3
- end : 6
- return_with_leftover_noise : disable

ModelSamplingSD3 :

- shift : 5

---

# 🖥️ 6. Différence avec notre config locale connue

La config locale @erith IA déjà connue utilisait plutôt :

- Wan2.2-I2V-A14B-HighNoise-Q3_K_S.gguf
- Wan2.2-I2V-A14B-LowNoise-Q3_K_S.gguf
- umt5_xxl_fp8_e4m3fn_scaled.safetensors
- wan_2.1_vae.safetensors

La structure est proche, mais les poids GGUF et les réglages sampler peuvent différer.

Conclusion :

Pour générer un workflow local, utiliser la structure Pixaroma.

Pour choisir les modèles exacts, respecter les fichiers présents dans la machine de Christophe.

Pour RunningHub, préférer la structure Pixaroma si les nodes et modèles correspondent.

---

# 🧩 7. Règle de génération future

Quand le Chat génère un workflow ComfyUI vidéo pour @erith IA :

1. Identifier le type exact :
   - image ;
   - img2img ;
   - image-to-video ;
   - upscale vidéo ;
   - audio-video.

2. Choisir un workflow Pixaroma de référence.

3. Ne changer que :
   - image source ;
   - prompts ;
   - nom de sortie ;
   - résolution / durée si nécessaire ;
   - modèles si la config locale impose d’autres noms.

4. Ne pas inventer des nodes si un exemple Pixaroma existe.

5. Pour toute vidéo, utiliser VHS_VideoCombine comme sortie principale.

6. Pour la continuité LEGO, ajouter une last frame PNG.

---

# 🏍️ 8. Application à Velocity V2

Master source :

velocity_v2_reference.png

Pipeline correct :

velocity_v2_reference.png  
→ WanImageToVideo  
→ KSamplerAdvanced HighNoise  
→ KSamplerAdvanced LowNoise  
→ VAEDecode  
→ VHS_VideoCombine MP4  
→ last frame PNG  
→ DaVinci Resolve

Ne pas refaire :

- SD1.5 redraw ;
- LoRA image ;
- ControlNet image ;
- SaveAnimatedWEBP seul ;
- workflow image déguisé en workflow vidéo.

---

# 🗂️ 9. Placement recommandé dans GitHub

Archive de référence :

workflows/reference/pixaroma/Workflow.zip

Fichier d’index conseillé :

production/COMFYUI_PIXAROMA_WORKFLOW_EXAMPLES_BASE.md

Lien depuis la carte principale :

production/COMFYUI_SA_MEMORY_CARD.md

Section à ajouter dans la carte principale :

Pixaroma workflow examples base

Phrase courte :

Les workflows Pixaroma EP06 et Getting Started sont conservés comme base d’exemples ComfyUI pour les générations futures. Ils servent de référence de câblage, de noms de nodes, de structure Wan/LTX/SeedVR2 et surtout d’export vidéo via VHS_VideoCombine.

---

# ✅ 10. Commit recommandé

Add Pixaroma workflow examples base
