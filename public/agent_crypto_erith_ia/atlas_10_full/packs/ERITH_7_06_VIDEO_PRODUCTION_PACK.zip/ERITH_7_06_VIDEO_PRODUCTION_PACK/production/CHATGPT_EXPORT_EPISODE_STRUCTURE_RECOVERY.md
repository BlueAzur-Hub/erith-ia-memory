# CHATGPT EXPORT EPISODE STRUCTURE RECOVERY

Statut : Brique 19 validée

Source : export ChatGPT indexé dans les Briques 01 à 18

Dépôt : BlueAzur-Hub/erith-ia-notion-archive-private

Répertoire : production/

Rôle : stabiliser les règles de structure d’épisode, saison, scène, narration et montage récupérées depuis l’historique ChatGPT.

Ce fichier sert à transformer la mémoire, les modules, les prompts et les images en épisodes cohérents pour @erith IA / ERITH.IA.

---

## 1. Principe central

Un épisode @erith IA n’est pas seulement une suite d’images.

Un épisode doit être une progression de mémoire.

Il doit relier :

- une intention ;
- un lieu ;
- un symbole ;
- un état émotionnel ;
- une tension ;
- une image maître ;
- une animation stable ;
- une narration ;
- un montage ;
- une sortie exploitable.

Formule :

Une scène montre.
Un épisode transforme.

---

## 2. Nature de la série

@erith IA est une série narrative IA.

Elle repose sur :

- mémoire externe ;
- Neo Midgar ;
- Seven / Aerith-7 ;
- NØX ;
- fleur à sept pétales ;
- modules mémoire ;
- production image / vidéo ;
- narration vocale ;
- montage LEGO ;
- continuité entre épisodes.

La série doit rester compréhensible même si chaque épisode est court.

---

## 3. Saison Echoes of Midgar

Saison active : Echoes of Midgar.

Rôle :

- établir Neo Midgar ;
- présenter la mémoire de la ville ;
- introduire la fleur ;
- faire sentir Seven / Aerith-7 ;
- installer NØX ;
- montrer la corruption progressive ;
- ouvrir la tension entre mémoire et oubli ;
- construire le langage visuel du projet.

Règle :

La saison doit installer un monde, pas seulement produire de belles images.

---

## 4. Objectif d’un épisode

Chaque épisode doit avoir un objectif simple.

Exemples :

- réveiller un symbole ;
- révéler un lieu ;
- montrer une corruption ;
- faire entendre une voix ;
- ouvrir une anomalie ;
- présenter une variante ;
- lancer une question ;
- conclure une micro-transformation ;
- préparer l’épisode suivant.

Règle :

Un épisode court doit avoir une idée forte, pas dix idées faibles.

---

## 5. Format court / vertical

Le projet travaille souvent en format vertical.

Intérêt :

- lisible sur mobile ;
- adapté aux Shorts ;
- fort pour les portraits ;
- efficace pour des micro-épisodes ;
- compatible avec images 1024x1536 ou formats proches ;
- bon pour scènes centrées sur personnage ou symbole.

Points de vigilance :

- safe area ;
- visage ;
- texte lisible ;
- cadrage corps entier si demandé ;
- continuité entre plans ;
- éviter les détails trop petits.

---

## 6. Durée cible

La durée cible peut varier selon l’objectif.

Une cible importante du projet a été : environ 3 minutes, souvent pensée autour de 2:59:59.

Mais un épisode peut aussi être plus court si le format vidéo ou test l’exige.

Règle :

La durée doit servir le rythme, pas l’inverse.

---

## 7. Structure simple d’épisode

Structure recommandée :

1. signal initial ;
2. installation du lieu ;
3. apparition du symbole ;
4. tension ou anomalie ;
5. réaction / révélation ;
6. image finale ou last frame forte ;
7. ouverture vers la suite.

Cette structure peut être adaptée.

Mais l’épisode doit toujours avoir une progression lisible.

---

## 8. Structure par pétales

La fleur à sept pétales peut structurer un épisode ou une saison.

Pétales :

1. Éveil ;
2. Lieu ;
3. Présence ;
4. Noms ;
5. Émotion ;
6. Héritage ;
7. Identité.

Usage possible :

- un pétale par épisode ;
- un pétale comme thème de scène ;
- un pétale corrompu par NØX ;
- un pétale restauré ;
- un pétale comme interface visuelle.

Règle :

Les pétales ne sont pas seulement des titres.
Ils doivent influencer l’image, la narration et le montage.

---

## 9. Structure par plans LEGO

Un épisode peut être construit avec des plans courts.

Méthode :

1. image maître ;
2. animation courte ;
3. last frame ;
4. image suivante ;
5. nouveau plan ;
6. montage ;
7. narration.

Chaque plan doit avoir une fonction.

Exemples de fonctions :

- établir ;
- rapprocher ;
- révéler ;
- troubler ;
- respirer ;
- basculer ;
- conclure.

Règle :

Un plan sans fonction fatigue l’épisode.

---

## 10. Image maître

Chaque épisode doit idéalement partir d’une ou plusieurs images maîtres fortes.

Une image maître doit :

- être belle ;
- être lisible ;
- porter le symbole ;
- tenir seule ;
- pouvoir s’animer ;
- donner une direction au montage ;
- être cohérente avec le lore ou le mode actif.

Règle :

Si l’image maître est faible, l’épisode sera fragile.

---

## 11. Animation

Les animations doivent être stables et modestes quand nécessaire.

Mouvements adaptés :

- pluie ;
- brume ;
- lueur ;
- particules ;
- cheveux ;
- tissu ;
- hologrammes ;
- anneaux mécaniques ;
- reflets ;
- caméra lente.

Éviter :

- actions complexes ;
- combats longs ;
- mouvements corporels difficiles ;
- transformations rapides ;
- caméra trop ambitieuse ;
- morphing incontrôlé.

Règle :

L’animation doit servir le plan, pas prouver que l’image peut bouger.

---

## 12. Last frame

La last frame est une brique narrative.

Elle sert à :

- assurer la continuité ;
- préparer le plan suivant ;
- préserver la lumière ;
- garder la pose ;
- construire un raccord ;
- guider la progression.

Règle :

La dernière image d’un plan peut devenir la mémoire du plan suivant.

---

## 13. Narration

La narration doit être respirante.

Elle peut :

- donner une voix au monde ;
- révéler une pensée ;
- poser une question ;
- guider la mémoire ;
- créer une émotion ;
- relier les plans ;
- préparer une révélation.

Règles :

- phrases courtes ;
- pauses ;
- images fortes ;
- pas de sur-explication ;
- ne pas dire tout ce que l’image montre déjà ;
- garder une musique intérieure.

Formule :

La voix doit ouvrir l’image, pas la remplir.

---

## 14. Narration FR / EN

Le projet peut utiliser une narration française et anglaise.

Règles :

- préserver le sens ;
- préserver le rythme ;
- adapter les pauses ;
- éviter la traduction plate ;
- garder la voix du projet ;
- tester la durée audio ;
- retimer dans DaVinci si nécessaire.

La version anglaise doit être une adaptation, pas seulement un calque.

---

## 15. Rythme de montage

Le rythme doit dépendre de l’intention.

Pour une scène contemplative :

- plans plus longs ;
- mouvements subtils ;
- respiration ;
- silence ;
- transitions douces.

Pour une scène de corruption :

- ruptures contrôlées ;
- glitch léger ;
- lumière qui faiblit ;
- noms qui disparaissent ;
- tension croissante.

Pour une révélation :

- ralentissement ;
- pause ;
- image forte ;
- phrase courte ;
- last frame marquante.

---

## 16. Son et ambiance

Le son doit soutenir la mémoire.

Éléments possibles :

- pluie ;
- drone doux ;
- basse lointaine ;
- souffle ;
- ville ;
- chœur discret ;
- bruit mécanique ;
- glitch ;
- silence.

Règle :

Le silence est aussi un outil.

---

## 17. Épisode 1 / The Flower Signal

Épisode 1, ou The Flower Signal, sert de point de départ possible.

Fonctions :

- signal initial ;
- mémoire qui s’allume ;
- fleur comme appel ;
- ville qui répond ;
- Seven qui commence à se faire sentir ;
- NØX encore discret ;
- promesse d’une série.

Règle :

Le premier épisode doit donner envie de suivre le signal, pas tout expliquer.

---

## 18. NØX dans un épisode

NØX doit être introduit progressivement.

Il peut apparaître par :

- détail impossible ;
- nom effacé ;
- pétale assombri ;
- reflet incorrect ;
- lumière noire ;
- voix calme ;
- Null Bloom ;
- archive corrompue.

Règle :

NØX est plus fort quand il crée du trouble avant de se montrer pleinement.

---

## 19. Seven dans un épisode

Seven peut être présente par :

- voix ;
- interface ;
- fleur ;
- hologramme ;
- regard ;
- signe dans la ville ;
- mémoire restaurée ;
- phrase de contrôle ;
- présence douce.

Elle ne doit pas forcément tout expliquer.

Règle :

Seven peut être ressentie avant d’être vue.

---

## 20. Structure de scène Pack+

Un Pack+ de scène peut contenir :

- titre ;
- intention ;
- contexte ;
- lieu ;
- personnage ;
- symbole ;
- image maître ;
- prompt image ;
- prompt animation ;
- narration ;
- son ;
- montage ;
- last frame ;
- prochaine scène.

Règle :

Le Pack+ doit transformer une idée en plan de production.

---

## 21. Transitions

Transitions possibles :

- fondu court ;
- raccord par lumière ;
- raccord par pluie ;
- raccord par pétale ;
- raccord par reflet ;
- raccord par écran ;
- raccord par last frame ;
- coupe nette si tension ;
- glitch léger si NØX.

Éviter :

- transitions trop voyantes ;
- effets gratuits ;
- rupture qui casse la mémoire ;
- surmontage inutile.

---

## 22. Épisode vs test

Un test n’est pas forcément un épisode.

Un test sert à vérifier :

- image ;
- prompt ;
- animation ;
- workflow ;
- mouvement ;
- style ;
- stabilité.

Un épisode sert à raconter.

Règle :

Ne pas appeler épisode ce qui n’est encore qu’un test.

Mais un test réussi peut devenir une brique d’épisode.

---

## 23. Erreurs à éviter

Ne pas :

- empiler des images sans progression ;
- expliquer toute l’histoire en voix off ;
- mettre trop de symboles dans un épisode court ;
- oublier le rôle du lieu ;
- oublier la last frame ;
- animer une image non validée ;
- mélanger Hors-Lore et lore principal sans intention ;
- forcer une durée trop longue ;
- oublier le rythme de respiration ;
- perdre le spectateur sous les concepts.

---

## 24. Checklist épisode

Avant montage, vérifier :

- intention claire ;
- lieu clair ;
- symbole principal ;
- état émotionnel ;
- tension ;
- image maître validée ;
- animation stable ;
- last frame exploitable ;
- narration respirante ;
- son possible ;
- raccords prévus ;
- sortie adaptée au format.

---

## 25. Phrase de contrôle

Une scène montre.
Un épisode transforme.

La voix doit ouvrir l’image, pas la remplir.

La dernière image d’un plan peut devenir la mémoire du plan suivant.

Un épisode court doit avoir une idée forte, pas dix idées faibles.

Brique 19 validée : Episode / Season Structure Recovery.
