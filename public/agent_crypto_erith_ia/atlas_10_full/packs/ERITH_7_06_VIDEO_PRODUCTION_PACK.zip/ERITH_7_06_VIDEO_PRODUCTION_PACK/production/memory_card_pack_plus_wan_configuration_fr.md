# CARTE MÉMOIRE — PACK+ WAN CONFIGURATION ERITH.IA

Statut : Carte Mémoire workflow  
Type : Pack+ / Wan / I2V / prompt animation / configuration / production vidéo  
Mode recommandé : Seven Heaven / Production / Réalisateur / ComfyUI / RunningHub / Wan 2.2  
Langue : français  
Usage : ERITH.IA / Pack+ / image-to-video / workflow Wan / prompt animation / DaVinci / LEGO continuity

---

# 1. Rôle de la carte

Cette Carte Mémoire définit notre configuration Pack+ Wan.

Elle sert à transformer une idée ou une image maître en pack exploitable pour animation I2V.

Elle ne remplace pas le workflow JSON.

Elle sert à préparer correctement :

- image source ;
- prompt animation ;
- négatif animation ;
- durée ;
- mouvement ;
- caméra ;
- last frame ;
- raccord DaVinci ;
- critères de validation ;
- relance contrôlée ;
- notes de production.

Formule centrale :

Pack+ prépare.  
Wan anime.  
La last frame relie.  
DaVinci assemble.

---

# 2. Pipeline canonique Pack+ Wan

Ordre obligatoire :

1. Valider l’image maître.
2. Définir la fonction du plan.
3. Écrire le prompt animation.
4. Écrire le négatif animation.
5. Choisir la durée.
6. Choisir le niveau de mouvement.
7. Lancer un test court.
8. Vérifier la stabilité.
9. Extraire la last frame si utile.
10. Monter dans DaVinci.
11. Noter le verdict.

Règle :

Ne pas lancer Wan si l’image source n’est pas validée.

---

# 3. Configuration Wan GGUF connue

Workflow JSON confirmé :

`workflows/ERITH.IA_HORS_LORE_STYLE_LOCK_V1_WAN22_I2V_OPTIONS_PLUS_V4_GGUF_REAL.json`

Modèles attendus :

`ComfyUI/models/unet/Wan2.2-I2V-A14B-HighNoise-Q3_K_S.gguf`

`ComfyUI/models/unet/Wan2.2-I2V-A14B-LowNoise-Q3_K_S.gguf`

Text encoder attendu :

`ComfyUI/models/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors`

VAE attendu :

`ComfyUI/models/vae/wan_2.1_vae.safetensors`

Configuration SAFE connue :

- width : 480 ;
- height : 832 ;
- length : 81 frames ;
- batch : 1 ;
- high noise : 20 steps, CFG 3.5, euler/simple, start 0 → 10 ;
- low noise : 20 steps, CFG 3.5, euler/simple, start 10 → 10000 ;
- export : WEBM VP9, 16 fps ;
- preview : Animated WEBP, 16 fps ;
- last frame : ImageFromBatch index 80.

Option Fast Test :

- width : 480 ;
- height : 832 ;
- length : 49 frames ;
- high noise steps : 12 ;
- low noise steps : 12 ;
- fps : 16.

Option HQ manuelle :

- width : 704 ;
- height : 1280 ;
- length : 81 ou 121 ;
- fps : 16.

Garde-fou :

Ne pas lancer HQ avant validation SAFE.

---

# 4. Structure Pack+ Wan

Un Pack+ Wan doit contenir :

## 1. Nom du plan

Nom court, clair, exploitable.

Exemple :

Plan 01 — Apparition sous la pluie

## 2. Fonction du plan

Définir à quoi sert le plan.

Exemples :

- installer le décor ;
- révéler le personnage ;
- activer un symbole ;
- préparer le raccord ;
- conclure une micro-séquence.

## 3. Image source

Indiquer :

- nom du fichier image ;
- format ;
- orientation ;
- état : validée / test / fragile ;
- éléments à préserver.

## 4. Prompt positif animation

Décrire :

- ce qui bouge ;
- ce qui reste stable ;
- type de caméra ;
- intensité du mouvement ;
- atmosphère ;
- lumière ;
- durée émotionnelle.

## 5. Prompt négatif animation

Empêcher :

- morphing visage ;
- changement de tenue ;
- nouveaux personnages ;
- action non demandée ;
- caméra chaotique ;
- transformation ;
- perte de composition.

## 6. Réglages recommandés

Indiquer :

- moteur ;
- workflow ;
- résolution ;
- durée ;
- fps ;
- mouvement ;
- last frame ;
- export.

## 7. Critères de validation

Le plan est validé si :

- visage stable ;
- silhouette stable ;
- tenue stable ;
- décor stable ;
- mouvement utile ;
- caméra contrôlée ;
- fin exploitable ;
- raccord possible.

## 8. Relance contrôlée

Si relance :

- choisir une seule correction ;
- ne pas changer tout le prompt ;
- ne pas changer modèle + image + durée + caméra en même temps ;
- noter la cause de l’échec.

---

# 5. Prompt animation maître Wan

```text
Subtle cinematic image-to-video animation. Preserve the original image composition, character identity, face, outfit, silhouette, lighting and background. The character remains almost still, with only natural micro-movements. Add slow atmospheric motion: gentle light shimmer, faint particles, rain or mist if present, subtle cloth movement, soft environmental pulses. Camera nearly locked, very slow cinematic drift only. No transformation, no new characters, no outfit change, no face morphing, no fast action, no chaotic motion. The goal is a stable production-ready clip for LEGO continuity and DaVinci editing.
```

---

# 6. Négatif animation maître Wan

```text
face morphing, identity drift, outfit change, hairstyle change, new characters, duplicate person, extra limbs, distorted hands, distorted face, broken anatomy, chaotic motion, fast motion, camera shake, extreme zoom, sudden pan, transformation, scene change, background collapse, flickering body, unreadable text, logo, watermark, low quality, blurry, compression artifacts, over-animation, bad last frame
```

---

# 7. Pack+ Wan — template complet

## Nom du plan

À remplir.

## Fonction du plan

À remplir.

## Image source

Fichier : à remplir.  
Statut : validée / test / fragile.  
Orientation : vertical / horizontal / carré.  
Éléments à préserver : visage, tenue, décor, lumière, symbole, cadrage.

## Prompt positif animation

```text
À remplir.
```

## Prompt négatif animation

```text
À remplir.
```

## Réglages recommandés

Moteur : Wan 2.2 I2V GGUF local ou RunningHub Wan.  
Workflow : ERITH.IA_HORS_LORE_STYLE_LOCK_V1_WAN22_I2V_OPTIONS_PLUS_V4_GGUF_REAL.json ou équivalent.  
Résolution SAFE : 480x832.  
Durée SAFE : 81 frames.  
FPS : 16.  
Mouvement : subtil / moyen / interdit action complexe.  
Last frame : oui si suite LEGO.  
Export : WEBM + WEBP preview + last frame PNG.

## Critères de validation

- visage stable ;
- tenue stable ;
- décor stable ;
- mouvement cohérent ;
- caméra propre ;
- pas de transformation ;
- fin exploitable ;
- raccord DaVinci possible.

## Verdict

Garder / retester / rejeter.

## Correction si relance

Une seule correction prioritaire : à remplir.

---

# 8. Pack+ Wan — version courte

```text
Plan: [nom]
Function: [installer / révéler / transmettre / conclure]
Source image: [fichier]
Animation: subtle cinematic I2V, preserve identity, preserve outfit, preserve composition, minimal motion, atmospheric movement only, nearly locked camera.
Negative: face morphing, outfit change, new characters, chaotic motion, camera shake, transformation, bad anatomy, bad last frame.
Settings: Wan 2.2 I2V, 480x832, 81 frames, 16 fps, last frame enabled.
Validation: stable face, stable outfit, stable background, useful motion, clean ending.
```

---

# 9. Règles de mouvement

## Mouvement idéal

- pluie ;
- brume ;
- poussière ;
- particules ;
- halos ;
- interface ;
- lumière ;
- respiration légère ;
- cheveux très subtils ;
- tissu très subtil ;
- arrière-plan vivant mais calme.

## Mouvement risqué

- marche complète ;
- combat ;
- course ;
- danse ;
- rotation caméra ;
- transformation ;
- interaction complexe ;
- plusieurs personnages ;
- mains très visibles ;
- changement d’expression fort.

Règle :

Plus le personnage est précieux, plus le mouvement doit être sobre.

---

# 10. Règles crédits / Mako

Avant chaque lancement, demander :

Ce plan sert à quoi ?

Est-ce que l’image source est assez forte ?

Le mouvement est-il simple ?

Le raccord est-il prévu ?

La relance aurait-elle une correction claire ?

Règle :

Une génération = une intention claire.

Pas de shotgun.

---

# 11. Compatibilité Hors-Lore

En mode Hors-Lore, le Pack+ Wan doit rappeler :

- univers original ;
- pas de lore privé ;
- pas de personnages privés ;
- pas de franchise copiée ;
- influence autorisée seulement si demandée ;
- style lock respecté.

Négatif Hors-Lore possible :

```text
copyrighted character, franchise design, private lore, Neo Midgar, Aerith, Aerith-7, NØX, Shinra, Final Fantasy, copied costume, copied logo, copied city, recognizable IP
```

---

# 12. Compatibilité Carte Mémoire

Un Pack+ Wan peut charger une Carte Mémoire, mais une seule ou deux maximum au départ.

Exemples :

- Carte Altered Carbon seule ;
- Carte Cyberpunk Noir Trio ;
- Carte Spirale, Lumière & Kundalini ;
- Carte Géométrie Vivante & Math Oracle ;
- Carte Histoire & Histoire de l’Art ;
- Carte Religions, Mythologies & Cultes anciens.

Garde-fou :

Ne pas mélanger cyberpunk, religion, géométrie, art et psychologie dans un seul plan si le visuel devient illisible.

---

# 13. Commandes utilisables

Crée un Pack+ Wan pour cette image.

Crée un Pack+ Wan SAFE en 480x832, 81 frames, 16 fps.

Crée un Pack+ Wan Hors-Lore avec last frame.

Analyse ce résultat Wan et donne verdict : garder / retester / rejeter.

Prépare la relance Wan avec une seule correction prioritaire.

Convertis ce prompt image en prompt animation Wan.

Prépare une séquence LEGO en trois Pack+ Wan.

---

# 14. Résumé LLM inclus

## Fonction de la carte

Cette Carte Mémoire définit la configuration Pack+ Wan ERITH.IA.

Elle transforme une image maître ou une idée en plan I2V exploitable avec prompt positif, négatif, réglages, critères de validation, relance contrôlée et raccord DaVinci.

## Configuration connue

Workflow confirmé :

`workflows/ERITH.IA_HORS_LORE_STYLE_LOCK_V1_WAN22_I2V_OPTIONS_PLUS_V4_GGUF_REAL.json`

Modèles :

- `Wan2.2-I2V-A14B-HighNoise-Q3_K_S.gguf` ;
- `Wan2.2-I2V-A14B-LowNoise-Q3_K_S.gguf` ;
- `umt5_xxl_fp8_e4m3fn_scaled.safetensors` ;
- `wan_2.1_vae.safetensors`.

Réglages SAFE :

- 480x832 ;
- 81 frames ;
- 16 fps ;
- high noise 20 steps CFG 3.5 ;
- low noise 20 steps CFG 3.5 ;
- WEBM / WEBP / last frame index 80.

## Activation LLM courte

Quand l’utilisateur demande :

“Crée un Pack+ Wan.”

Alors produire :

- nom du plan ;
- fonction du plan ;
- image source ;
- prompt animation ;
- négatif animation ;
- réglages recommandés ;
- critères de validation ;
- relance contrôlée ;
- raccord DaVinci / last frame.

## Activation LLM complète

Tu es en mode Carte Mémoire Pack+ Wan Configuration ERITH.IA.

Prépare chaque plan comme une brique LEGO stable.

Ne lance jamais une animation sans image source validée, fonction claire et mouvement simple.

Utilise Wan pour produire des clips courts, sobres, stables et raccordables.

Préserve le visage, la silhouette, la tenue, le décor, la lumière et la composition.

Prépare toujours un prompt négatif anti-morphing, anti-dérive, anti-transformation et anti-chaos caméra.

Si relance, une seule correction prioritaire.

## Formule finale

Pack+ prépare.

Wan anime.

La last frame relie.

DaVinci assemble.

Une génération = une intention claire.
