# 🧬 CIVITAI — KNOWLEDGE BASE

🧠 Statut : base de connaissance production  
🌐 Projet : @erith IA / ERITH.IA  
🛠️ Domaine : modèles IA, LoRA, checkpoints, références créatives, veille vidéo  
📺 Chaîne YouTube suivie : https://www.youtube.com/@civitai/videos  
🗓️ Vérification initiale : 2026-05-16

Ce fichier complète la carte ComfyUI.

Il sert à donner au Chat / Seven / aux LLM une base stable pour comprendre CivitAI, utiliser le site comme source de modèles, éviter les erreurs de compatibilité et mieux préparer les workflows ComfyUI.

---

# 1. Rôle de CivitAI dans le projet

CivitAI est une plateforme centrale pour trouver, comparer et tester des ressources d’IA générative visuelle.

Pour @erith IA, CivitAI sert surtout à repérer :

- checkpoints ;
- LoRA ;
- modèles SD1.5 ;
- modèles SDXL ;
- modèles Flux ;
- styles anime / manga / cyberpunk ;
- modèles réalistes ;
- embeddings / textual inversions ;
- ControlNet / outils liés ;
- exemples de prompts ;
- images de démonstration ;
- réglages utilisés par les créateurs ;
- compatibilités avec ComfyUI ;
- tendances récentes de la communauté.

Formule :

CivitAI trouve les modèles.  
ComfyUI les teste.  
La carte mémoire garde ce qui fonctionne.  
DaVinci assemble les résultats validés.

---

# 2. Positionnement opérationnel

CivitAI n’est pas une mémoire canonique du projet.

C’est une source externe de ressources.

Un modèle trouvé sur CivitAI doit toujours être vérifié avant d’être intégré à un workflow.

Règles :

- ne jamais supposer qu’un modèle CivitAI est compatible avec la config locale ;
- vérifier la base model : SD1.5, SDXL, Flux, Pony, Illustrious, etc. ;
- vérifier le type exact : checkpoint, LoRA, VAE, embedding, ControlNet, workflow ;
- vérifier le format : safetensors, ckpt, GGUF, diffusers, etc. ;
- vérifier le placement dans ComfyUI/models ;
- vérifier les trigger words ;
- vérifier les prompts d’exemple ;
- vérifier les warnings de licence, NSFW, restrictions, usage commercial ;
- noter les réglages qui marchent réellement dans la carte ComfyUI.

---

# 3. Types de ressources à distinguer

## Checkpoint

Un checkpoint est un modèle principal.

Usage :

- base de génération image ;
- style global ;
- rendu général ;
- cohérence visage / décor / matière.

À vérifier :

- base model ;
- taille du fichier ;
- VAE recommandé ;
- sampler recommandé ;
- CFG recommandé ;
- steps ;
- résolution optimale ;
- exemples d’images ;
- prompts associés.

## LoRA

Un LoRA est une couche d’influence ajoutée au modèle principal.

Usage :

- personnage ;
- costume ;
- style ;
- objet ;
- pose ;
- ambiance ;
- correction esthétique.

À vérifier :

- base model compatible ;
- trigger words ;
- force recommandée ;
- risques de surpoids ;
- conflit avec d’autres LoRA ;
- stabilité sur plusieurs seeds ;
- rendu dans ComfyUI.

Règle @erith IA :

un LoRA ne doit pas prendre le contrôle de l’image entière sauf si c’est explicitement recherché.

## Embedding / Textual Inversion

Usage :

- correction de détails ;
- style léger ;
- négatif spécialisé ;
- amélioration ou réduction d’un type de défaut.

À vérifier :

- compatibilité avec le checkpoint ;
- placement exact ;
- mot déclencheur ;
- effet réel dans ComfyUI.

## VAE

Usage :

- couleur ;
- contraste ;
- décodage image ;
- stabilité visuelle.

À vérifier :

- VAE recommandé par le modèle ;
- VAE intégré ou séparé ;
- compatibilité SD1.5 / SDXL / autre.

## ControlNet / Guidance

Usage :

- composition ;
- profondeur ;
- pose ;
- lineart ;
- canny ;
- référence structurelle.

À vérifier :

- modèle ControlNet exact ;
- préprocesseur ;
- force ;
- start/end percent ;
- risque de rigidité excessive.

## Workflow / ComfyUI example

Usage :

- comprendre un câblage ;
- récupérer une structure de nodes ;
- comparer avec Pixaroma ou workflow local ;
- apprendre les paramètres associés à un modèle.

Règle :

un workflow CivitAI doit être traité comme exemple, pas comme vérité absolue.

---

# 4. Fiche d’analyse modèle CivitAI

Template à remplir pour chaque modèle utile :

Nom du modèle :  
URL CivitAI :  
Type : checkpoint / LoRA / embedding / VAE / ControlNet / workflow  
Base model :  
Version :  
Fichier :  
Taille :  
Format :  
Licence / restrictions :  
NSFW : oui / non / incertain  
Usage commercial : oui / non / incertain  
Trigger words :  
Prompt positif exemple :  
Prompt négatif exemple :  
Sampler recommandé :  
Scheduler recommandé :  
Steps :  
CFG :  
Résolution :  
VAE recommandé :  
LoRA strength recommandé :  
Chemin ComfyUI :  
Custom nodes nécessaires :  
Résultat test local :  
Résultat RunningHub :  
Verdict : garder / tester / éviter  
Notes :

---

# 5. Règles de compatibilité avec ComfyUI

Avant d’utiliser un modèle CivitAI dans ComfyUI :

1. Télécharger le bon fichier.
2. Placer le fichier dans le bon dossier.
3. Rafraîchir ComfyUI.
4. Vérifier que le node le voit.
5. Ne pas confondre checkpoint et LoRA.
6. Ne pas placer un LoRA dans checkpoints.
7. Ne pas placer un checkpoint dans loras.
8. Vérifier le nom exact affiché dans le node.
9. Noter la config qui marche.
10. Ne pas modifier plusieurs paramètres à la fois.

Chemins génériques :

- checkpoints → ComfyUI/models/checkpoints
- loras → ComfyUI/models/loras
- vae → ComfyUI/models/vae
- controlnet → ComfyUI/models/controlnet
- embeddings → ComfyUI/models/embeddings
- unet / diffusion_models → selon l’installation locale

Règle importante :

Le nom affiché dans ComfyUI peut dépendre du dossier, du refresh et du node utilisé.

---

# 6. Usage pour @erith IA

CivitAI est utile pour plusieurs familles de production.

## Image maître

Chercher :

- checkpoint stable ;
- style cohérent ;
- rendu maîtrisé ;
- modèle compatible avec RTX 3060 Laptop 6GB VRAM ;
- prompts lisibles ;
- résultats constants.

## Style anime / Akira / cyberpunk

Chercher :

- checkpoints anime semi-réalistes ;
- LoRA film anime rétro ;
- LoRA véhicule / moto ;
- LoRA ville cyberpunk ;
- lineart / cel shading ;
- prompts de vitesse ;
- exemples avec routes, néons, mégalopoles, perspectives.

## Personnage / costume / identité

Chercher :

- LoRA personnage ;
- LoRA outfit ;
- LoRA pose ;
- LoRA cheveux / accessoires ;
- modèle qui ne détruit pas le visage.

## Décor / architecture

Chercher :

- LoRA urbanisme ;
- architecture futuriste ;
- mégastructures ;
- cités verticales ;
- environnements industriels ;
- matte painting.

## Préparation animation

CivitAI peut aider à trouver une image maître, mais l’animation doit rester séparée.

Règle :

image parfaite d’abord, animation Wan/I2V ensuite.

Ne pas chercher à corriger une mauvaise image avec l’animation.

---

# 7. Chaîne YouTube CivitAI

Source suivie :

https://www.youtube.com/@civitai/videos

Rôle dans le projet :

- veille sur les nouveautés CivitAI ;
- tutoriels modèles ;
- démonstrations de workflows ;
- explications LoRA / checkpoint / génération ;
- tendances de la plateforme ;
- repérage de méthodes utiles pour ComfyUI ;
- repérage de vidéos à transformer plus tard en notes de production.

Important :

La chaîne YouTube sert de source de veille, pas de source canonique unique.

Chaque vidéo utile doit être résumée dans une fiche séparée avant intégration.

Template vidéo :

Titre vidéo :  
URL :  
Date :  
Sujet :  
Outil : CivitAI / ComfyUI / LoRA / Flux / SDXL / vidéo / autre  
Résumé court :  
Nodes ou modèles mentionnés :  
Paramètres utiles :  
Application possible @erith IA :  
À tester : oui / non  
Verdict : garder / archiver / ignorer

---

# 8. Veille CivitAI recommandée

Recherches utiles :

- CivitAI Akira anime motorcycle LoRA
- CivitAI retro anime film LoRA
- CivitAI cyberpunk city LoRA
- CivitAI cinematic anime checkpoint SDXL
- CivitAI motorcycle LoRA SDXL
- CivitAI speed lines anime LoRA
- CivitAI cel shading checkpoint
- CivitAI ComfyUI workflow Wan image to video
- CivitAI Flux cyberpunk model
- CivitAI SDXL anime city checkpoint

Filtres à utiliser :

- base model ;
- model type ;
- rating / popularity ;
- date updated ;
- images d’exemple ;
- licence ;
- creator notes.

---

# 9. Garde-fous

Ne pas télécharger en masse.

Ne pas installer des modèles sans vérifier le type.

Ne pas mélanger trop de LoRA dans un test.

Ne pas supposer qu’un modèle populaire est adapté au projet.

Ne pas ignorer la licence.

Ne pas utiliser un modèle NSFW ou borderline pour une production publique sans contrôle strict.

Ne pas conserver un modèle qui produit de beaux exemples mais échoue dans notre pipeline.

Ne pas oublier la VRAM locale.

Ne pas confondre esthétique CivitAI et direction artistique ERITH.IA.

---

# 10. Base de données courte

## CivitAI

Rôle : bibliothèque externe de modèles, images d’exemple, prompts et tendances.

Usage @erith IA : recherche modèle / LoRA / style / prompt.

Risque : compatibilité, licence, NSFW, surpromesse des exemples.

## CivitAI Models

Rôle : trouver checkpoints, LoRA, embeddings, VAE, ControlNet.

Usage @erith IA : enrichir la forge ComfyUI.

Risque : mauvais dossier, mauvais base model, trigger words oubliés.

## CivitAI Images

Rôle : observer les prompts et paramètres utilisés.

Usage @erith IA : comprendre le style d’un modèle.

Risque : image très sélectionnée, seed chanceux, post-processing non indiqué.

## CivitAI YouTube

Rôle : veille vidéo et pédagogie.

Usage @erith IA : transformer les vidéos utiles en fiches de production.

Risque : ne pas confondre vidéo informative et preuve de compatibilité locale.

## CivitAI + ComfyUI

Rôle : modèle trouvé sur CivitAI, testé dans ComfyUI.

Usage @erith IA : stabiliser un workflow reproductible.

Risque : nodes manquants, modèles mal placés, réglages non adaptés.

---

# 11. Phrase mémoire

CivitAI sert à trouver.

ComfyUI sert à tester.

GitHub sert à stabiliser.

Notion sert à présenter.

La direction artistique ERITH.IA décide.

Un modèle CivitAI n’entre dans la mémoire que s’il est testé, compris et utile.