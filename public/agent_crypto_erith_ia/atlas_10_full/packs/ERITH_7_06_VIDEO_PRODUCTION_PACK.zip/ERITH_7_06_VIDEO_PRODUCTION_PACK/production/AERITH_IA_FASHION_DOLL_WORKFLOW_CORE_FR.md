# 🌸 AERITH IA — Fashion Doll Workflow Core FR

## Présentation courte

Ce fichier synthétise la direction Fashion Doll validée pour ComfyUI, Wan 2.2 et RunningHub.

Direction actuelle :

- héroïne adulte originale ;
- esthétique fashion doll réaliste ;
- identité rose / florale ;
- cheveux longs brun-auburn ;
- yeux verts ;
- ruban rose ;
- veste courte rouge / cuir glossy ;
- bijoux roses et étoile ;
- tatouage dragon floral ;
- variations Day / Night liées entre elles.

Objectif : conserver une base lisible, stable, propre et exploitable pour image fixe, img2img et animation I2V.

---

## 🔗 Document lié — Night / Sun WakeUp LEGO

Ce workflow général possède une application de production directe :

production/aerith_night_sun_wakeup/LEGO_AERITH_NIGHT_SUN_WAKEUP.md

Ce fichier LEGO met en pratique la même direction Fashion Doll dans une chaîne verticale concrète :

- Night → Dawn → Sun → Sun Arrival ;
- marche réelle, raccords et last frames ;
- prompts image et prompts Wan ;
- continuité du visage, du costume, des cheveux, du dragon floral et du décor ;
- montage DaVinci en briques de 5 secondes.

### Relation entre les deux documents

- Ce fichier Fashion Doll est le **cadre général** : identité, Day / Night, workflow, réglages et règles de stabilité.
- Le fichier LEGO Night / Sun WakeUp est le **cas d’application détaillé** : une séquence précise qui applique ce cadre.

### Lecture LLM attendue

Ces deux fichiers concernent la même héroïne adulte originale et la même direction visuelle : cheveux longs brun-auburn, yeux verts, rubans roses, boléro rouge, tenue rose, tatouage dragon floral sur le bras gauche et la jambe gauche, continuité Day / Night, production Wan / RunningHub.

Pour produire ou prolonger la séquence Night / Sun, lire ce fichier comme doctrine générale puis consulter le fichier LEGO comme protocole opérationnel.

**Fashion Doll Workflow = doctrine et règles générales.**  
**Night / Sun WakeUp LEGO = application de production concrète.**

---

## Références visuelles Core

### ☀️ Aerith de Jour — Harmonia Ibiza Beach House

Fichier :

core/AERITH_IA_FASHION_DOLL_DAY_REFERENCE.md

Image :

../assets/images/HARMONIA_IBIZA_BEACH_HOUSE_AERITH_FASHION_DOLL_SOURCE_1080x1920_V1.png

Rôle :

- image source officielle pour animation Wan 2.2 / RunningHub ;
- plage solaire ;
- Harmonia / Ibiza / House Music ;
- format téléphone 1080 × 1920 ;
- marche lente vers caméra ;
- cheveux, veste, mer et foule lointaine en mouvement doux.

### 🌙 Aerith de Nuit — Fashion Doll Night

Fichier :

core/AERITH_IA_FASHION_DOLL_NIGHT_REFERENCE.md

Image :

../assets/images/AERITH_IA_FASHION_DOLL_SAFE_V2_PREMIUM_00061_.png

Rôle :

- référence nocturne ;
- mood studio ;
- contraste lunaire ;
- continuité rose / fashion doll ;
- utile pour éclairage, ambiance et variation esthétique.

---

## Lien Day / Night

Aerith de Jour et Aerith de Nuit ne sont pas deux directions séparées.

Ce sont deux pôles d’une même identité :

- Jour : solaire, plage, house music, animation, production publique.
- Nuit : lunaire, studio, mood, contraste, référence esthétique.

Formule :

**Le jour donne le mouvement. La nuit donne le mystère.**

---

## Configuration locale cible

Workflow pensé pour un poste local du type :

- Ryzen 7 ;
- RTX 3060 Laptop 6 GB VRAM ;
- 16 GB RAM ;
- ComfyUI local.

Principes :

- workflow lisible ;
- une variable à la fois ;
- image source propre avant animation ;
- stabilité avant ambition ;
- pas de reconstruction inutile.

---

## Architecture ComfyUI recommandée

### Image fixe / img2img

CheckpointLoaderSimple  
→ CLIP Text Encode Positif  
→ CLIP Text Encode Négatif  
→ LoadImage  
→ VAEEncode  
→ KSampler  
→ VAEDecode  
→ SaveImage

### Animation Wan 2.2 / I2V

LoadImage  
→ CLIP Text Encode Positif  
→ CLIP Text Encode Négatif  
→ WanImageToVideo  
→ KSampler High Noise  
→ KSampler Low Noise  
→ VAEDecode  
→ Video Combine

---

## Réglages image fixe recommandés

- résolution de travail : 768 × 1152 ou 832 × 1216 ;
- upscale ensuite vers 1024 × 1536 si besoin ;
- sampler : DPM++ 2M Karras ;
- steps : 28 à 35 ;
- CFG : 5.5 à 7 ;
- denoise img2img : 0.30 à 0.40 pour rester proche de la source.

Lecture rapide :

- 0.30 = très proche ;
- 0.35 = équilibre recommandé ;
- 0.42 = réinterprétation plus forte ;
- 0.50+ = risque de dérive plus fort.

---

## Réglages Wan 2.2 / RunningHub recommandés

- format : 1080 × 1920 ;
- durée : 5 secondes ;
- fps : 16 ;
- length : 81 ;
- batch : 1 ;
- mouvement : lent, noble, stable ;
- caméra : dolly-in très léger ;
- action : un pas ou deux vers caméra ;
- mouvement secondaire : cheveux, veste, mer, foule lointaine.

Règle :

**Premier test = marche lente + cheveux + veste + fond vivant.**

Pas de danse, pas de rotation, pas de zoom agressif au premier test.

---

## Prompt animation — Day / Harmonia Ibiza Beach House

cinematic slow walk toward camera, elegant woman walking naturally on a luxury tropical beach club deck at noon, Harmonia Ibiza house music atmosphere, confident calm gaze, vivid green eyes, very long auburn hair flowing softly in the sea breeze, pink ribbon moving gently, red cropped leather jacket with rolled-up sleeves catching sunlight, pink beach fashion outfit, refined jewelry, pink choker, five-star pendant, colorful turquoise and emerald dragon tattoos on left arm and left leg with pink flowers, subtle natural body movement, soft hair motion, soft jacket motion, gentle skirt motion, elegant heels stepping carefully, stable full body, centered composition, camera slowly dolly-in, slight parallax in palm trees and beach lounge, turquoise ocean shimmering in background, subtle DJ booth activity far behind her, elegant party crowd softly moving in the distance, premium AAA summer music video, cinematic realism, bright noon sunlight, clean anatomy, smooth temporal consistency, no motion reset

---

## Prompt négatif animation

unstable anatomy, distorted face, face morphing, bad hands, bad feet, broken heels, twisted legs, crossed legs, extra limbs, duplicate body, tattoo morphing, tattoo disappearing, blurry tattoo, jacket melting, hair covering face, skirt flickering, background chaos, crowd taking focus, camera shake, fast motion, jump cut, motion reset, warped body, low quality, blur, flicker, glitch, deformation

---

## Tatouage dragon floral

Direction retenue :

- dragon turquoise, émeraude et bleu profond ;
- accents roses ;
- fleurs roses autour du dragon ;
- lignes d’encre propres ;
- tatouage lisible ;
- placement bras gauche et jambe gauche ;
- style premium, élégant, floral.

Add-on positif :

colorful neo-traditional dragon tattoo, turquoise and emerald dragon, pink flowers around the dragon, elegant black ink linework, vivid colors, realistic ink on skin, readable tattoo detail, premium tattoo design, floral dragon motif on left arm and left leg

Add-on négatif :

bad tattoo, blurry tattoo, smeared tattoo, unreadable tattoo, random marks on skin, distorted dragon, broken dragon body, messy ink, low detail tattoo, tattoo on wrong side, too many tattoos, logo tattoo, text tattoo

---

## LLM block

Tu travailles sur une direction AERITH IA Fashion Doll.

Préserve :

- identité adulte originale ;
- cheveux longs brun-auburn ;
- ruban rose ;
- yeux verts ;
- palette rose / rouge / corail ;
- bijoux roses et étoile ;
- tatouage dragon floral ;
- contraste Day / Night.

Utilise :

- Day pour production et animation ;
- Night pour mood, contraste et référence esthétique.

Règle centrale :

**Le jour donne le mouvement. La nuit donne le mystère. Une variable à la fois.**

---

## Statut

Statut actuel : **Day / Night linkage V1 validé**.

La référence de jour devient la source prioritaire pour Wan 2.2 / RunningHub.

La référence de nuit reste une brique de contraste visuel.