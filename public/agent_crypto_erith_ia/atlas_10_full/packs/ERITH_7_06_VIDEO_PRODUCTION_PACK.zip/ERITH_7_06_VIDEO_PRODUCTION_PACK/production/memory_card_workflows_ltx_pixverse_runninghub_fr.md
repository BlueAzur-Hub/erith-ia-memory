# CARTE MÉMOIRE — WORKFLOWS LTX / PIXVERSE / RUNNINGHUB I2V

Statut : Carte Mémoire workflow  
Type : production vidéo / image-to-video / RunningHub / LTX / PixVerse / benchmark cloud  
Mode recommandé : Seven Heaven / Production / Réalisateur / Hors-Lore / Pack+ vidéo  
Langue : français  
Usage : ERITH.IA / RunningHub / ComfyUI / image-to-video / tests comparatifs / storyboard / mouvement contrôlé

---

# 1. Rôle de la carte

Cette Carte Mémoire sert à surveiller, tester et comparer les workflows vidéo externes autour de RunningHub, LTX et PixVerse.

Elle ne remplace pas le workflow Wan GGUF local validé.

Elle sert à ouvrir des pistes de production complémentaires :

- LTX2.3 Image to Video ;
- PixVerse V6 Image to Video ;
- Wan 2.2 Action Transfer ;
- One-Click Storyboard ;
- AI Motion Transfer ;
- workflows RunningHub ;
- génération I2V cloud ;
- benchmark de stabilité ;
- comparaison coût / qualité / vitesse / contrôle.

Formule centrale :

Wan reste la base stable.  
LTX et PixVerse deviennent des laboratoires de mouvement.  
RunningHub sert de banc d’essai cloud.

---

# 2. Recherche intégrée — état au 2026-05-14

## RunningHub

RunningHub présente une zone Workflows / ComfyUI Workflows et annonce notamment des nodes Wan 2.2, Qwen-image et Kontext.

La page d’accueil RunningHub affiche aussi des éléments utiles pour ERITH.IA :

- PixVerse V6 Image to Video ;
- LTX2.3 Image to Video ;
- Wan 2.2 Action Transfer V7 ;
- One-Click Storyboard ;
- AI Motion Transfer ;
- AI Video Upscaler.

Interprétation ERITH.IA :

RunningHub est une source à surveiller pour trouver des workflows cloud rapidement testables, surtout pour l’I2V, le storyboard et le motion transfer.

## LTX / Lightricks

Le dépôt officiel Lightricks / LTX-Video indique que LTX-2 est devenu la nouvelle génération LTX, avec génération audio+vidéo synchronisée, intégration ComfyUI, keyframes multiples, IC-LoRA, LoRA standard, latent upsampler et documentation complète.

Le dépôt indique aussi que LTX-Video / LTX-2 supporte l’image-to-video, le multi-keyframe conditioning, l’animation par keyframes, l’extension vidéo et les transformations video-to-video.

Interprétation ERITH.IA :

LTX est une piste importante pour tester des vidéos plus longues, plus structurées ou plus contrôlées par keyframes, surtout quand Wan dérive ou quand il faut comparer une autre logique de mouvement.

## PixVerse

PixVerse se présente comme un générateur de vidéos IA à partir de texte et de photos, avec génération temps réel, crédits et plateforme API.

RunningHub expose PixVerse V6 Image to Video dans ses Featured Apps.

Interprétation ERITH.IA :

PixVerse doit être traité comme un moteur cloud I2V de test, utile pour comparer le rendu, la vitesse, la stabilité et le type de mouvement avec Wan et LTX.

---

# 3. Garde-fou principal

Ne pas remplacer un workflow stable par un workflow séduisant mais non testé.

Ne pas brûler les crédits sur plusieurs plateformes sans protocole.

Ne pas comparer deux moteurs avec des images, prompts et durées différentes.

Ne pas juger un moteur sur un seul résultat.

Ne pas oublier que chaque moteur a son style, ses biais, ses limites et ses coûts.

Règle absolue :

Un nouveau workflow est d’abord un test.  
Il ne devient pipeline qu’après validation.

---

# 4. LTX2.3 Image to Video — rôle dans ERITH.IA

## Fonction

LTX2.3 I2V est une piste pour :

- tester l’image-to-video avec une autre logique que Wan ;
- travailler les keyframes ;
- explorer des transitions plus longues ;
- comparer la cohérence temporelle ;
- tester des scènes plus structurées ;
- expérimenter le contrôle de mouvement ;
- préparer une alternative quand Wan échoue.

## Usage recommandé

Utiliser LTX quand :

- Wan déforme trop le personnage ;
- il faut tester une durée différente ;
- il faut comparer un mouvement de caméra ;
- il faut tester une animation par keyframes ;
- il faut produire un benchmark court ;
- il faut vérifier si LTX préserve mieux la composition.

## Test type

Même image source que Wan.

Même prompt positif.

Même intention de mouvement.

Durée proche.

Comparer :

- visage ;
- silhouette ;
- tenue ;
- décor ;
- mouvement ;
- stabilité ;
- coût ;
- vitesse ;
- raccord possible.

---

# 5. PixVerse V6 Image to Video — rôle dans ERITH.IA

## Fonction

PixVerse V6 I2V est une piste cloud pour tester :

- mouvement plus stylisé ;
- rendu rapide ;
- animation à partir d’une image ;
- plans courts ;
- variations express ;
- comparaison avec Wan / LTX ;
- potentiel usage teaser / short / preview.

## Usage recommandé

Utiliser PixVerse quand :

- il faut un test très rapide ;
- il faut comparer la dynamique du mouvement ;
- il faut voir si un moteur externe anime mieux une image maître ;
- il faut produire un aperçu ou une variation ;
- il faut tester une scène non critique.

## Garde-fou

Ne pas utiliser PixVerse comme référence canonique avant test de stabilité.

Vérifier :

- dérive du visage ;
- changement de tenue ;
- perte de détails ;
- style trop générique ;
- mouvement trop spectaculaire ;
- cohérence de la dernière frame.

---

# 6. One-Click Storyboard — rôle dans ERITH.IA

## Fonction

One-Click Storyboard est utile pour préparer :

- découpage vidéo ;
- suite de plans ;
- structure de mini-séquence ;
- logique LEGO ;
- ordre narratif ;
- progression image → animation → montage.

## Usage recommandé

Utiliser cette piste avant de lancer plusieurs générations vidéo.

Objectif :

Ne pas générer dans le vide.

Construire d’abord :

- plan 1 ;
- plan 2 ;
- plan 3 ;
- fonction de chaque plan ;
- mouvement de chaque plan ;
- raccord prévu ;
- narration correspondante.

---

# 7. AI Motion Transfer — rôle dans ERITH.IA

## Fonction

AI Motion Transfer peut servir à tester :

- mouvement de corps ;
- posture ;
- action contrôlée ;
- transfert de mouvement ;
- animation de personnage à partir d’une référence.

## Usage recommandé

Utiliser seulement si :

- l’image source est stable ;
- le mouvement est simple ;
- l’action est nécessaire ;
- la référence de mouvement est claire ;
- le résultat peut être rejeté sans perdre une scène critique.

## Garde-fou

Pour ERITH.IA, le mouvement spectaculaire n’est pas prioritaire.

Priorité :

- présence ;
- continuité ;
- lisibilité ;
- visage ;
- tenue ;
- émotion ;
- raccord.

---

# 8. Protocole de test comparatif

## Objectif

Comparer Wan, LTX et PixVerse proprement.

## Règle

Même image.

Même intention.

Même durée approximative.

Même niveau de mouvement.

Ne pas changer tout à la fois.

## Tableau de verdict

Pour chaque test, noter :

- moteur ;
- date ;
- image source ;
- prompt ;
- durée ;
- coût ;
- temps de génération ;
- qualité visage ;
- stabilité tenue ;
- stabilité décor ;
- mouvement ;
- last frame ;
- réutilisable oui / non ;
- verdict.

---

# 9. Priorité ERITH.IA

Ordre recommandé :

1. Wan GGUF local validé pour base stable.
2. RunningHub Wan 2.2 pour test cloud ou variante.
3. LTX2.3 I2V pour comparaison structure / keyframes.
4. PixVerse V6 I2V pour variation rapide / teaser.
5. One-Click Storyboard pour découpage.
6. AI Motion Transfer seulement pour action contrôlée.

---

# 10. Prompt test commun

```text
Animate the provided image as a short cinematic image-to-video test. Keep the original character identity, face, outfit, silhouette, lighting and background stable. Subtle movement only. Slow atmospheric motion, gentle camera drift, soft particles or light shimmer, no transformation, no new characters, no outfit change, no face morphing. Preserve composition. The goal is a stable production test, not a spectacular action scene.
```

---

# 11. Negative test commun

```text
face morphing, identity drift, outfit change, new characters, extra limbs, distorted hands, distorted face, chaotic camera, fast motion, extreme zoom, transformation, flickering anatomy, unreadable text, logo, watermark, low quality, broken composition, over-animation
```

---

# 12. Commandes utilisables

Charge la Carte Mémoire Workflows LTX / PixVerse / RunningHub I2V.

Compare Wan, LTX et PixVerse avec le même prompt et la même image source.

Prépare un test I2V court entre Wan GGUF local, LTX2.3 I2V et PixVerse V6 I2V.

Prépare un storyboard LEGO avant lancement RunningHub.

Analyse un résultat LTX ou PixVerse et dis s’il peut rejoindre le pipeline ERITH.IA.

---

# 13. Résumé LLM inclus

## Fonction de la carte

Cette Carte Mémoire active un cadre de test et de comparaison pour les workflows vidéo externes : LTX2.3 Image to Video, PixVerse V6 Image to Video, RunningHub Workflows, One-Click Storyboard, Wan 2.2 Action Transfer et AI Motion Transfer.

Elle sert à compléter, comparer ou challenger le pipeline Wan GGUF local sans le remplacer automatiquement.

## Statut critique

Wan GGUF local reste la base stable connue.

LTX et PixVerse sont des laboratoires de test.

RunningHub est un banc d’essai cloud.

Tout nouveau workflow doit être testé avec protocole : même image, même intention, durée proche, mouvement comparable.

Ne pas brûler les crédits sans objectif clair.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge la Carte Workflows LTX / PixVerse / RunningHub.”

Alors activer :

- comparaison I2V ;
- LTX2.3 ;
- PixVerse V6 ;
- RunningHub ;
- storyboard ;
- motion transfer ;
- benchmark qualité / coût / vitesse ;
- garde-fou anti-surcharge ;
- respect du pipeline Wan stable.

## Activation LLM complète

Tu es en mode Carte Mémoire Workflows LTX / PixVerse / RunningHub I2V.

Utilise Wan comme référence stable.

Utilise LTX comme moteur de comparaison pour keyframes, cohérence temporelle et alternative I2V.

Utilise PixVerse comme moteur cloud de variation rapide et benchmark visuel.

Utilise RunningHub comme plateforme d’essai cloud pour workflows, apps, storyboard et motion transfer.

Ne remplace jamais un workflow validé sans protocole de test.

Toujours comparer avec la même image, le même objectif et une durée comparable.

## Formule finale

Wan stabilise.

LTX structure.

PixVerse varie.

RunningHub teste.

DaVinci décide si le plan entre dans l’œuvre.
