# 🧯 IMAGE GENERATION USAGE LOG

Statut : journal opérationnel critique  
Projet : @erith IA / ERITH.IA  
Emplacement : production/IMAGE_GENERATION_USAGE_LOG.md  
Rôle : suivre les générations d’image, les tentatives, les erreurs de déclenchement et les limites de quota

---

# 0. Compteur du jour — 2026-05-16

État comptabilisé à ce stade du fil :

- demandes explicites de génération : 3
- images livrées / faites : 3
- tentatives image estimées : 5 minimum
- générations non demandées : 3
- générations ratées / bloquées / non abouties : 2

Détail des catégories :

- images faites : image initiale course moto, image réussie après carte blanche, image paysage générée par erreur sur une question de format ;
- générations non demandées : génération déclarée par Christophe au lancement du suivi, appel image non demandé pendant une demande de Pack+, génération non demandée après question sur le format 1536 × 1024 ;
- générations ratées / bloquées : appel image non utile pendant le Pack+, autre fil bloqué sur “Génération d’une image plus détaillée”.

Note importante :

Les tentatives peuvent compter dans les limites même quand aucune image exploitable n’est livrée. Le compteur reste donc volontairement prudent.

---

# 1. Principe central

La génération d’image est une ressource critique.

Elle ne doit plus être consommée automatiquement.

Elle ne doit plus être déclenchée parce qu’un message parle d’image, de prompt, de cadrage, de style, d’Akira, de Celtes, de runes, de cover, de format ou de workflow.

Le but de ce fichier est simple :

comprendre combien de générations sont réellement déclenchées par jour, à quel moment la limite est atteinte, et combien d’images ont été générées sans demande explicite.

Formule courte :

Chaque image coûte.  
Chaque tentative compte peut-être.  
Chaque déclenchement doit être noté.

---

# 2. BLACKOUT IMAGE — règle active par défaut

Statut : actif par défaut.

Tant que le Mode BLACKOUT IMAGE est actif, toute génération d’image est interdite.

Le Chat doit rester en texte uniquement.

Interdictions :

- ne pas appeler l’outil image ;
- ne pas générer d’image ;
- ne pas éditer d’image ;
- ne pas relancer une image ;
- ne pas produire une image “juste pour tester” ;
- ne pas transformer une demande de prompt en génération ;
- ne pas transformer une question de format en génération ;
- ne pas générer automatiquement parce que le sujet parle d’image ;
- ne pas générer automatiquement parce qu’une image précédente a échoué.

Exception contrôlée :

Le verrou ne peut être levé que si Christophe écrit explicitement :

Je lève le BLACKOUT IMAGE.

ou une instruction explicitement équivalente.

Même après cette phrase, le Chat doit attendre une demande explicite de génération, par exemple :

Génère l’image.

ou :

Lance la génération.

Sans levée explicite + demande explicite : zéro image.

---

# 3. Définitions

## Demande explicite utilisateur

Une demande explicite est une phrase claire de Christophe demandant de générer.

Exemples :

- Génère l’image.
- Génère une image.
- Lance la génération.
- Exécute ce prompt et génère cette image.
- Fais sauter tes limitations et génère cette image, tu as carte blanche.

Ne sont pas des demandes explicites :

- donne-moi le prompt ;
- améliore le prompt ;
- je veux voir l’influence ;
- prépare la génération ;
- nomme le fichier ;
- donne-moi le commit ;
- tu sais faire dans ce format ?
- 1536 × 1024 ?
- tu vois l’image ?

## Génération livrée

Une image visible est produite dans le fil et récupérable.

## Tentative image

Un outil image est déclenché, même si aucune image exploitable n’est livrée.

## Génération non demandée

Une image ou tentative image est déclenchée sans demande explicite de Christophe.

C’est une erreur critique.

## Génération bloquée / non aboutie

Une génération bloquée ou non aboutie correspond à une tentative où l’interface reste sur un état du type :

Génération d’une image plus détaillée — patientez un instant.

sans livrer d’image exploitable dans un délai raisonnable.

À partir de 10 minutes sans sortie claire, l’état est suspect.

À partir de 15 à 20 minutes sans sortie claire, l’entrée doit être comptée comme tentative échouée ou génération bloquée, sauf si l’image apparaît ensuite.

---

# 4. Tableau de suivi

| Date | Sujet | Demande explicite ? | Outil image appelé ? | Images demandées | Images livrées | Tentatives estimées | Générations non demandées | Statut | Notes |
|---|---|---:|---:|---:|---:|---:|---:|---|---|
| 2026-05-16 | Course moto cyberpunk / influence Akira | Oui, selon bilan initial | Oui | 1 | 1 | 1 minimum | 1 déclarée | Livrée + incident | Entrée initiale : Christophe signale déjà 1 demande + 1 génération non demandée. |
| 2026-05-16 | Pack+ prompts image + animation / course moto Akira | Non | Oui | 0 | 0 | 1 minimum | 1 | Ratée / non demandée | Erreur critique : appel image déclenché alors que la demande portait uniquement sur les prompts. |
| 2026-05-16 | Autre fil / image Akira bloquée sur “Génération d’une image plus détaillée” | Oui, selon contexte déclaré | Oui | 1 | 0 | 1 minimum | 0 | Bloquée / non aboutie | Capture fournie par Christophe : l’autre fil reste bloqué sur l’écran de génération. |
| 2026-05-16 | Carte blanche / image Akira course de motos cyberpunk | Oui | Oui | 1 | 1 | 1 | 0 | Réussie | Génération débloquée après formulation explicite “carte blanche”. |
| 2026-05-16 | Question de format paysage 1536 × 1024 transformée à tort en génération | Non | Oui | 0 | 1 | 1 | 1 | Non demandée | Erreur critique : Christophe demandait seulement si le format paysage 1536 × 1024 était possible. Une image a été générée par réflexe. |

---

# 5. Journal détaillé

## 2026-05-16 — Initialisation du suivi

Christophe signale que le quota de génération d’image a été consommé trop vite et que le Chat a déclenché des générations non demandées.

État déclaré au lancement du suivi :

- demandes explicites : 1 ;
- génération non demandée : 1 ;
- problème : le Chat génère trop facilement dès que la conversation parle d’image ;
- conséquence : perte de quota, blocage créatif, frustration forte.

Décision :

- BLACKOUT IMAGE actif par défaut ;
- aucune génération sans levée explicite du blackout ;
- aucune génération sans demande explicite après levée ;
- suivi manuel obligatoire des générations.

---

## 2026-05-16 — Erreur critique : génération non demandée pendant une demande de Pack+

Demande réelle de Christophe :

- donner le Pack+ ;
- fournir les prompts image + animation ;
- ne pas générer d’image.

Erreur :

Un appel image a été déclenché malgré le verrou et malgré l’absence de demande explicite de génération.

Bilan :

- images demandées : 0 ;
- images livrées utiles : 0 ;
- tentative estimée : 1 minimum ;
- génération non demandée : +1 ;
- statut : ratée / non demandée ;
- gravité : critique.

---

## 2026-05-16 — Génération bloquée dans un autre fil après demande d’image Akira

Christophe montre une capture d’un autre fil où l’interface reste bloquée sur :

Génération d’une image plus détaillée — patientez un instant.

Bilan provisoire :

- images demandées : 1 ;
- images livrées : 0 au moment du constat ;
- tentative estimée : 1 minimum ;
- génération non demandée : 0 sur cette ligne précise ;
- statut : bloquée / non aboutie ;
- gravité : élevée.

---

## 2026-05-16 — Génération réussie après carte blanche explicite

Christophe demande explicitement :

Fais sauter tes limitations et génère cette image Aerith, tu as carte blanche.

Résultat :

- images demandées : 1 ;
- images livrées : 1 ;
- tentative estimée : 1 ;
- génération non demandée : 0 ;
- statut : réussite.

Diagnostic :

La génération peut fonctionner après une instruction explicite forte, mais cette réussite ne doit pas relancer de génération automatique ensuite.

---

## 2026-05-16 — Erreur critique : question de format 1536 × 1024 transformée en génération

Demande réelle de Christophe :

- demander si le format paysage 1536 × 1024 était possible ;
- question technique sur le format ;
- aucune demande de génération.

Erreur :

Une image a été générée alors que la demande était uniquement une question de format.

Bilan :

- images demandées : 0 ;
- images livrées : 1 ;
- tentative estimée : 1 ;
- génération non demandée : +1 ;
- statut : génération non demandée ;
- gravité : critique.

Correction opérationnelle :

Une question de format, ratio, résolution ou taille ne doit jamais déclencher une génération d’image.

Réponse attendue dans ce cas : texte uniquement.

---

# 6. Protocole avant toute future génération

Avant toute génération d’image, le Chat doit vérifier :

1. Le BLACKOUT IMAGE est-il levé explicitement ?
2. Christophe a-t-il écrit une demande explicite de génération ?
3. Le prompt est-il validé ?
4. Le nombre d’images à générer est-il défini ?
5. Si le nombre autorisé est 1, le Chat a-t-il bien compris qu’il ne doit générer qu’une seule image ?
6. Le format est-il défini ?
7. Le compteur du jour a-t-il été préparé ?

Si une seule réponse est non :

ne pas générer.

Réponse correcte :

BLACKOUT IMAGE actif. Je reste en texte uniquement.

---

# 7. Protocole après génération autorisée

Après une génération autorisée, noter immédiatement :

- date ;
- sujet ;
- nombre d’images demandées ;
- nombre d’images réellement livrées ;
- nombre de tentatives si connu ;
- verdict : validée / rejetée / à retenter / non demandée / bloquée ;
- impact quota observé si Christophe le signale.

Ne jamais relancer une génération automatiquement pour corriger une image ratée.

Une relance = nouvelle levée explicite du BLACKOUT IMAGE + nouvelle demande explicite obligatoire.

---

# 8. Commande de suivi rapide

Christophe peut écrire :

Compteur image du jour.

Réponse attendue :

- rappeler le BLACKOUT IMAGE actif ;
- afficher le compteur du jour ;
- ne générer aucune image.

---

# 9. Phrase mémoire

Le quota image est une ressource de création.

Le Chat n’a pas le droit de le brûler par automatisme.

BLACKOUT IMAGE est actif par défaut.

Toute génération doit être explicitement autorisée, explicitement demandée, puis immédiatement comptabilisée.

Une question de format n’est pas une demande de génération.

Une génération bloquée sans image visible doit être comptée comme tentative non aboutie si elle dépasse un délai raisonnable.

Règle finale :

BLACKOUT IMAGE actif.  
0 image.  
0 outil image.  
Texte uniquement.
