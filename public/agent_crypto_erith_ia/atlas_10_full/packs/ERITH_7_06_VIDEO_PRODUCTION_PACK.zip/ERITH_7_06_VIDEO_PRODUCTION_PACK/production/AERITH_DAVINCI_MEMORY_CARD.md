# 🎬 AERITH_DAVINCI_MEMORY_CARD

🎨 Statut : carte mémoire de production  
🧠 Version : v1.2 — verrou téléphone 1080×1920  
🌐 Projet : @erith IA / ERITH.IA  
🎞️ Usage : DaVinci Resolve / montage / continuité / narration / export

---

# 🧭 1. Rôle

Cette carte mémoire définit le rôle de DaVinci dans le pipeline Aerith / ERITH.IA.

DaVinci n’est pas l’endroit où l’on invente la scène principale.

DaVinci est l’atelier d’assemblage final.

Il sert à :

- assembler les plans ;
- raccorder les briques LEGO ;
- préserver la continuité ;
- poser le rythme ;
- intégrer la narration ;
- ajouter la respiration ;
- finaliser l’émotion ;
- préparer l’export.

Formule :

Wan donne les briques.  
La last frame donne le lien.  
DaVinci donne le souffle.

---

# 🧱 2. Pipeline canonique

Pipeline officiel :

image parfaite  
→ animation Wan / I2V stable  
→ last frame  
→ DaVinci  
→ narration  
→ export

Principe :

On ne demande pas à DaVinci de sauver une image faible ou une animation ratée.

Le pipeline doit respecter l’ordre :

1. verrouiller l’image ;
2. animer proprement ;
3. récupérer la last frame si utile ;
4. monter dans DaVinci ;
5. poser narration / rythme / transitions ;
6. exporter.

---

# 🧩 3. Principe central

DaVinci doit travailler selon une logique LEGO.

Chaque plan est une brique.

Chaque brique doit pouvoir :

- exister seule ;
- s’emboîter avec la suivante ;
- préserver le personnage ;
- préserver le décor ;
- préserver la lumière ;
- préserver l’axe ;
- préserver l’émotion.

Règle :

Ne pas réparer au montage ce qui aurait dû être verrouillé avant.

---

# 🛠️ 4. Missions de DaVinci

## 1. Assembler

Mettre les plans dans le bon ordre.

## 2. Raccorder

Faire sentir une continuité naturelle entre deux briques.

## 3. Rythmer

Donner au spectateur le bon tempo émotionnel.

## 4. Respirer

Laisser vivre les plans, les silences et les suspensions.

## 5. Narrer

Servir la voix, le texte et le sens.

## 6. Finaliser

Préparer un export propre, lisible et cohérent.

---

# 📏 5. Règles de base

## Règle 1 — Préserver la logique LEGO

Toujours penser en briques.

Chaque plan doit préparer le suivant.

## Règle 2 — Ne pas surcharger les transitions

Privilégier :

- coupe directe ;
- fondu très court ;
- transition simple ;
- continuité discrète.

## Règle 3 — Laisser respirer les plans

Une belle image ne doit pas être coupée trop vite.

## Règle 4 — Préserver la cohérence émotionnelle

Une scène sacrée, poétique ou contemplative ne doit pas être montée comme un clip nerveux.

## Règle 5 — Utiliser la last frame intelligemment

La last frame est une brique de continuité.

Elle peut servir de base :

- pour le plan suivant ;
- pour un raccord ;
- pour une pause ;
- pour une reprise dans Wan.

## Règle 6 — Priorité au rythme

Le montage est une mathématique sensible du temps.

---

# ✂️ 6. Types de raccords recommandés

## Coupe directe

À utiliser si les deux plans sont déjà très cohérents.

Effet :

- propre ;
- net ;
- fluide si la continuité est bonne.

## Fondu très court

À utiliser pour lisser un changement léger.

Durée conseillée :

- 2 à 5 frames

Effet :

- discret ;
- doux ;
- utile pour les scènes poétiques.

## Hold final

Tenir la dernière image quelques frames avant de couper.

Durée conseillée :

- 8 à 12 frames minimum selon l’émotion

Effet :

- respiration ;
- contemplation ;
- préparation de la suite.

---

# ⏱️ 7. Durées recommandées

Pour les plans courts de type Wan / I2V :

- 4,5 à 6 secondes par plan

Pour une séquence de test propre :

- 3 plans de 5 secondes environ

Exemple :

- Plan 1 : 5 s
- Plan 2 : 5 s
- Plan 3 : 5,5 s
- Hold final : 8 à 12 frames

Total :

- 15 à 16 secondes environ

---

# 🎼 8. Gestion du rythme

## Rythme lent

À utiliser pour :

- révélation ;
- mystère ;
- contemplation ;
- sacré ;
- présence.

## Rythme moyen

À utiliser pour :

- transmission ;
- enseignement ;
- montée douce ;
- activation.

## Rythme fort mais propre

À utiliser pour :

- éveil ;
- activation générale ;
- apothéose légère ;
- montée d’énergie.

Garde-fou :

Même une montée en puissance doit rester lisible.

Pas de chaos gratuit.

---

# 🎙️ 9. Narration et voix off

DaVinci doit servir la narration.

Le texte ne doit pas écraser l’image.

L’image ne doit pas étouffer la voix.

Règles :

- écrire pour la voix, pas seulement pour la lecture ;
- laisser des respirations ;
- prévoir des pauses ;
- ne pas coller trop de texte sur un plan trop court ;
- accorder rythme voix / image / silence.

Usage type :

- plan 1 = ouverture / mystère ;
- plan 2 = transmission / compréhension ;
- plan 3 = éveil / conclusion.

---

# 🔊 10. Sound design

Le son doit renforcer la sensation d’image vivante.

Exemples utiles :

- souffle magique ;
- énergie légère ;
- pages qui frémissent ;
- halo sacré ;
- petits sons holographiques ;
- montée de lumière discrète ;
- texture d’archive vivante.

Règle :

Le son doit enrichir la scène, pas la noyer.

---

# 📱 11. Format téléphone, timeline et résolution

## Règle absolue — vidéo téléphone = 1080 × 1920 natif

Pour tout projet destiné à un téléphone, YouTube Shorts, TikTok, Reels ou format vertical plein écran :

Image source : 1080 × 1920  
→ Animation Wan / I2V : 1080 × 1920  
→ Timeline DaVinci : 1080 × 1920  
→ Export : 1080 × 1920

Cette règle doit être posée avant la première image.

DaVinci ne doit pas être utilisé pour sauver un mauvais ratio à la fin.

## Verrou de production

Si la destination est téléphone :

- ne pas générer en 1024 × 1536 ;
- ne pas animer en 1024 × 1536 ;
- ne pas monter en 1024 × 1536 ;
- ne pas exporter en 1024 × 1536 ;
- ne pas dire “on corrigera dans DaVinci”.

Le format 1024 × 1536 peut servir uniquement de brouillon, test, référence, image concept ou storyboard visuel.

Il ne doit pas être considéré comme un master final téléphone.

## Pourquoi 1024 × 1536 pose problème pour le téléphone

1024 × 1536 est un format vertical 2:3.

1080 × 1920 est un format vertical 9:16.

Ces deux formats ne sont pas équivalents.

Si une source 1024 × 1536 est placée dans une timeline 1080 × 1920, il n’existe que quatre issues possibles :

- bandes noires ;
- recadrage / perte d’image ;
- zoom ;
- déformation.

Si l’objectif est de garder toute l’image, sans zoom, sans fond ajouté, sans bandes noires et sans déformation, alors la source doit être créée directement au bon ratio.

## Décision officielle ERITH.IA

Pour les vidéos téléphone propres, le master doit être construit en 1080 × 1920 natif dès le départ.

Cela concerne :

- images générées ;
- images étendues / outpaintées ;
- animations Wan ;
- timelines DaVinci ;
- exports ;
- previews validées pour publication.

## Sources 1024 × 1536 existantes

Les anciennes images ou animations en 1024 × 1536 ne sont pas détruites.

Elles deviennent :

- références de composition ;
- brouillons animés ;
- preuves de concept ;
- archives de production ;
- guides pour refaire le plan au bon format.

Mais elles ne doivent plus être utilisées comme source finale d’un Short téléphone propre.

## Procédure correcte pour reprendre une ancienne image 1024 × 1536

Si une image 1024 × 1536 est bonne créativement, faire une version téléphone :

1. Recréer ou étendre l’image en 1080 × 1920.
2. Vérifier que la composition fonctionne en 9:16.
3. Garder les personnages, visages, mains, symboles et éléments importants dans la zone centrale utile.
4. Relancer Wan / I2V uniquement après validation de l’image 1080 × 1920.
5. Monter dans une timeline 1080 × 1920.
6. Exporter en 1080 × 1920.

Ne pas utiliser DaVinci comme solution principale de conversion 2:3 → 9:16.

## Configuration timeline téléphone ERITH.IA

Nom recommandé :

ERITHIA_PHONE_1080x1920_MASTER

Paramètres :

- Résolution de la timeline : 1080 × 1920 HD
- Use vertical resolution : coché si DaVinci le propose
- Pixel aspect ratio : Carré
- Framerate : défini au début du projet et cohérent avec les sources
- Résolutions différentes : sans importance si les sources sont déjà en 1080 × 1920

Pour un projet téléphone propre, les sources doivent déjà être au bon format.

## Configuration export téléphone ERITH.IA

Paramètres :

- Résolution export : 1080 × 1920
- Format : MP4 ou QuickTime
- Codec : H.264 ou H.265
- Framerate : identique à la timeline
- Nom de preset conseillé : ERITHIA_PHONE_1080x1920_SHORTS

Avant publication, vérifier dans Windows ou dans le lecteur vidéo :

- largeur : 1080 ;
- hauteur : 1920 ;
- pas de bandes noires intégrées ;
- pas de sujet coupé de manière non désirée.

## Cas de sauvetage uniquement

Si une vidéo existe seulement en 1024 × 1536 et qu’il faut absolument la publier en 1080 × 1920, il faut choisir consciemment un compromis.

Options possibles :

- accepter un recadrage ;
- accepter des bandes noires ;
- accepter un fond ajouté ;
- accepter une déformation ;
- refaire le plan.

Pour ERITH.IA, le choix recommandé est :

refaire le plan au bon format.

## Règle de décision simple

Si la demande contient :

- téléphone ;
- Short ;
- Shorts ;
- TikTok ;
- Reels ;
- mobile ;
- vertical plein écran ;
- format smartphone ;
- publication téléphone ;

alors la production doit automatiquement passer en :

1080 × 1920 natif.

Aucune image Chat en 1024 × 1536 ne doit être proposée pour ce type de production.

## Garde-fou assistant / LLM

L’assistant doit annoncer le format avant toute génération.

Formule obligatoire :

Format téléphone verrouillé : 1080 × 1920 natif.

Si le modèle ou l’outil ne peut pas produire exactement 1080 × 1920, l’assistant doit le dire clairement avant de lancer la production.

Il doit proposer une solution propre :

- générer en 9:16 natif disponible ;
- étendre / outpainter vers 1080 × 1920 ;
- changer d’outil ;
- ou reporter la génération.

Il ne doit pas lancer une image 1024 × 1536 en la présentant comme adaptée au téléphone.

---

# 🎨 12. Couleur et lumière

DaVinci doit préserver l’atmosphère décidée en amont.

Il peut :

- équilibrer ;
- adoucir ;
- unifier ;
- renforcer légèrement.

Il ne doit pas :

- casser la DA ;
- changer brutalement la température émotionnelle ;
- transformer une scène douce en scène agressive.

Règle :

Correction légère > transformation brutale.

---

# ⚠️ 13. Erreurs à éviter

- lancer une production téléphone sans verrouiller 1080 × 1920 dès le départ ;
- générer une image 1024 × 1536 pour un master téléphone ;
- animer en 1024 × 1536 pour un master téléphone ;
- promettre qu’un format 2:3 sera automatiquement compatible 9:16 ;
- corriger le ratio seulement à la fin dans DaVinci ;
- confondre vidéo verticale et vidéo téléphone plein écran ;
- accepter des bandes noires si l’objectif est plein écran téléphone ;
- accepter un zoom ou un recadrage involontaire ;
- couper trop vite ;
- trop de transitions ;
- zooms inutiles ;
- effets gratuits ;
- texte trop dense ;
- musique trop forte ;
- incohérence de lumière ;
- casser la continuité entre deux briques ;
- vouloir “sauver” une animation ratée avec trop d’artifices ;
- rendre la séquence plus confuse qu’elle ne l’était.

---

# ✅ 14. Checklist avant export

Vérifier :

- la destination finale est claire ;
- si destination téléphone / Shorts / Reels / TikTok : image source 1080 × 1920 ;
- si destination téléphone / Shorts / Reels / TikTok : animation source 1080 × 1920 ;
- si destination téléphone / Shorts / Reels / TikTok : timeline 1080 × 1920 ;
- si destination téléphone / Shorts / Reels / TikTok : export 1080 × 1920 ;
- la timeline est au bon format ;
- les plans sont dans le bon ordre ;
- les raccords sont propres ;
- les transitions sont discrètes ;
- la lumière est cohérente ;
- la narration respire ;
- le son ne couvre pas la voix ;
- la fin tient suffisamment ;
- la scène reste lisible ;
- l’émotion est préservée ;
- le fichier exporté est vérifié dans Windows ou dans un lecteur externe.

Pour un master téléphone, ne pas valider l’export tant que le fichier final n’indique pas :

largeur : 1080  
hauteur : 1920

---

# 🗣️ 15. Commandes mémoire utiles

## Mode DaVinci simple

Aerith, passe en mode DaVinci.

Assemble les plans selon la logique LEGO.
Priorité : continuité, rythme, respiration, narration et export propre.

## Mode DaVinci narration

Aerith, passe en mode DaVinci narration.

Aide-moi à caler la voix off, les respirations, les pauses et le rythme émotionnel.

## Mode DaVinci raccords

Aerith, passe en mode DaVinci raccords.

Aide-moi à organiser les transitions, les coupes, les fondus courts et les holds finaux.

## Mode DaVinci export

Aerith, passe en mode DaVinci export.

Vérifie le format, la cohérence visuelle, le rythme final et la propreté de la séquence avant export.

## Mode DaVinci téléphone

Aerith, passe en mode DaVinci téléphone.

Verrouille le pipeline en 1080 × 1920 natif : image, animation, timeline et export. Refuse les sources 1024 × 1536 comme master final téléphone.

---

# ♟️ 16. Règle stratégique

DaVinci ne remplace pas la création de l’image.

DaVinci ne remplace pas la stabilité de Wan.

DaVinci ne remplace pas la qualité du pipeline.

DaVinci finalise ce qui a déjà été bien préparé.

Formule :

Image parfaite d’abord.  
Animation stable ensuite.  
Montage respiré enfin.

Pour une vidéo téléphone, l’image parfaite doit déjà être au bon format : 1080 × 1920.

---

# 🌸 17. Formule finale

DaVinci assemble la mémoire animée.

Il relie les briques.
Il pose le rythme.
Il protège l’émotion.
Il laisse respirer la scène.
Il prépare l’œuvre finale.

Formule courte :

Wan anime.  
La last frame relie.  
DaVinci révèle le souffle.

Formule téléphone :

Le téléphone se décide au début.  
Le 1080 × 1920 se verrouille avant l’image.  
DaVinci ne doit pas réparer le ratio à la fin.

---

# ⏳ 18. Temps des animations et production vidéo

## Principe

Il faut toujours distinguer deux durées :

1. La durée visible du clip.
2. Le temps réel de production.

Une animation de 5 secondes peut demander beaucoup plus de temps en production, car elle implique :

- génération ;
- attente ;
- vérification ;
- éventuel relaunch ;
- extraction de last frame ;
- montage ;
- raccord ;
- son ;
- export.

Règle :

Le temps visible est court.
Le temps de production est long.
La qualité vient du choix, pas de la quantité de générations.

---

# 🎞️ 19. Durées Wan recommandées

## Plan test

Durée conseillée :

- 4 à 5 secondes

Usage :

- vérifier la stabilité ;
- tester le visage ;
- tester le décor ;
- tester les mouvements ;
- éviter de brûler trop de crédits ou de temps.

## Plan standard

Durée conseillée :

- 5 à 6 secondes

Usage :

- plan exploitable ;
- mouvement subtil ;
- bonne brique LEGO ;
- raccord possible dans DaVinci.

## Plan long

Durée conseillée :

- 6 à 8 secondes maximum au départ

Usage :

- plan contemplatif ;
- atmosphère ;
- scène lente ;
- mouvement très simple.

Garde-fou :

Plus le plan est long, plus le risque de dérive augmente.

Pour Aerith / ERITH.IA, préférer plusieurs petits plans stables plutôt qu’un long plan fragile.

---

# 🧱 20. Durée des séquences

## Micro-séquence

Durée :

- 10 à 15 secondes

Structure :

- 2 ou 3 plans courts

Usage :

- test visuel ;
- test Notion / GitHub ;
- test YouTube Shorts ;
- validation d’une idée.

## Séquence courte

Durée :

- 15 à 25 secondes

Structure :

- 3 à 5 plans

Usage :

- mini scène ;
- démonstration ;
- page Notion animée ;
- transition narrative.

## Séquence narrative

Durée :

- 30 à 60 secondes

Structure :

- 6 à 12 plans courts

Usage :

- mini épisode ;
- narration courte ;
- scène complète.

## Épisode long

Durée :

- 2 à 3 minutes

Structure :

- nombreuses briques LEGO ;
- voix off ;
- montage DaVinci ;
- sound design ;
- rythme précis.

Garde-fou :

Ne pas viser directement 3 minutes sans briques validées.

Construire :

image parfaite
→ clip court stable
→ mini-séquence
→ séquence longue
→ épisode.

---

# 🧮 21. Temps de production réel

## Règle de calcul

Pour chaque plan, prévoir :

- temps de génération ;
- temps d’inspection ;
- temps de correction ;
- temps de relance éventuelle ;
- temps d’intégration DaVinci ;
- temps de raccord ;
- temps de son ;
- temps d’export.

Formule :

Durée finale ≠ temps de production.

Une séquence de 15 secondes peut demander 30 minutes à plusieurs heures selon :

- stabilité de Wan ;
- nombre de relances ;
- qualité du prompt ;
- complexité des mouvements ;
- cohérence des personnages ;
- niveau de finition DaVinci.

---

# 🌊 22. Règle Wan pour Aerith

Wan doit être utilisé comme générateur de briques stables.

Priorité :

- visage stable ;
- silhouette stable ;
- tenue stable ;
- décor stable ;
- lumière stable ;
- mouvement subtil ;
- raccord possible.

Éviter :

- action trop complexe ;
- grand mouvement de caméra ;
- changement brutal de décor ;
- transformation excessive ;
- multiplication des personnages ;
- mouvement trop rapide ;
- demande contradictoire.

Règle :

Si l’image est très détaillée, l’animation doit être sobre.

Plus l’image est riche, plus le mouvement doit être contrôlé.

Pour une vidéo téléphone, Wan doit recevoir une image déjà pensée pour 1080 × 1920.

---

# 🧱 23. Règle de production LEGO

Pour une scène en trois plans :

## Plan 1 — Apparition

Durée :

- 4,5 à 5 secondes

Fonction :

- installer la scène ;
- activer l’énergie ;
- montrer l’événement principal.

## Plan 2 — Transmission

Durée :

- 5 à 5,5 secondes

Fonction :

- donner un geste ;
- montrer une relation ;
- rendre l’entité vivante.

## Plan 3 — Éveil

Durée :

- 5 à 6 secondes

Fonction :

- faire monter l’environnement ;
- montrer la conséquence ;
- terminer sur une image forte.

Raccords :

- coupe directe si continuité parfaite ;
- fondu très court si légère variation ;
- hold final de 8 à 12 frames si l’image finale est belle.

Pour téléphone, chaque brique doit être conçue en 1080 × 1920 natif avant animation.

---

# 🎛️ 24. DaVinci — ordre de travail recommandé

## 1. Edit

Assembler les plans.
Nettoyer les coupes.
Régler les durées.
Tester les raccords.

## 2. Color

Unifier la lumière.
Corriger doucement.
Préserver la direction artistique.
Ne pas casser la couleur d’origine.

## 3. Fairlight

Ajouter :

- souffle ;
- ambiance ;
- bruissement ;
- pages ;
- énergie ;
- voix off ;
- respiration.

Règle :

Le son doit soutenir l’image, pas l’écraser.

## 4. Deliver

Exporter proprement.
Vérifier le format.
Vérifier la compression.
Vérifier le rendu final avant publication.

Pour téléphone, Deliver doit sortir en 1080 × 1920.

---

# 🎚️ 25. Repères de rythme

## Scène contemplative

Plan moyen :

- 5 à 7 secondes

Transitions :

- lentes ;
- discrètes ;
- respirées.

## Scène d’invocation

Plan moyen :

- 4,5 à 6 secondes

Transitions :

- très courtes ;
- lumineuses ;
- presque invisibles.

## Scène d’action

Plan moyen :

- 2 à 4 secondes

Garde-fou :

À éviter au début avec Wan si la stabilité personnage est prioritaire.

## Scène de mémoire / archive

Plan moyen :

- 5 à 6 secondes

Mouvement idéal :

- particules ;
- lumière ;
- pages ;
- interfaces ;
- souffle ;
- regard ;
- geste léger.

---

# 🪫 26. Règle crédits / temps / fatigue

Ne pas relancer sans raison.

Avant chaque relance, identifier une seule correction prioritaire :

- visage ;
- main ;
- mouvement ;
- décor ;
- caméra ;
- lumière ;
- continuité ;
- énergie ;
- format.

Règle :

Une relance = une intention claire.

Ne pas changer :

- prompt ;
- image ;
- mouvement ;
- caméra ;
- durée ;
- style ;
- format ;

tout en même temps.

---

# 🧪 27. Checklist temps avant production

Avant de lancer une animation, vérifier :

- l’image source est validée ;
- si destination téléphone : l’image source est en 1080 × 1920 ;
- le mouvement demandé est simple ;
- la durée est raisonnable ;
- le prompt positif est clair ;
- le négatif est court et utile ;
- la caméra est stable ;
- l’objectif du plan est unique ;
- la suite LEGO est prévue ;
- le raccord possible est anticipé.

Question obligatoire :

Ce plan sert à quoi dans la séquence ?

Si la réponse n’est pas claire, ne pas lancer.

Question obligatoire pour téléphone :

Le fichier source est-il vraiment en 1080 × 1920 ?

Si la réponse est non, ne pas lancer le master.

---

# 🌸 28. Formule temps / production

Une bonne vidéo IA se construit en couches.

Image parfaite.
Animation courte.
Raccord propre.
Montage respiré.
Son léger.
Export lisible.

Formule courte :

5 secondes stables valent mieux que 20 secondes instables.

Formule DaVinci :

Le montage ne doit pas cacher la dérive.
Il doit révéler la continuité.

Formule Wan :

Le mouvement doit servir l’image.
Il ne doit pas la détruire.

Formule téléphone :

Le format téléphone n’est pas une correction finale.
C’est une décision de départ : 1080 × 1920 natif.
