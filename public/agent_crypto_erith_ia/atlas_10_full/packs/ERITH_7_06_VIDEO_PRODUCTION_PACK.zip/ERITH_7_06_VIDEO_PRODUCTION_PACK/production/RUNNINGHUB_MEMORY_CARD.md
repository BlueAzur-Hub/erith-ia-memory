# RUNNINGHUB MEMORY CARD

Statut : carte mémoire production  
Projet : @erith IA / ERITH.IA  
Outil : RunningHub  
Rôle : laboratoire cloud workflows / ComfyUI / Wan / I2V / tests rapides

---

# 1. Rôle de la carte

Cette carte mémoire sert à stabiliser l’usage de RunningHub dans la chaîne de production ERITH.IA.

RunningHub est traité comme le laboratoire cloud du projet.

C’est ici que l’on cherche, teste, compare et classe :

- workflows ComfyUI cloud ;
- workflows Wan ;
- workflows image-to-video ;
- workflows portrait vertical ;
- workflows last frame ;
- workflows avec caméra fixe ;
- workflows de mouvements subtils ;
- workflows d’upscale ;
- workflows de génération image ;
- workflows de génération vidéo ;
- coûts en coins ;
- stabilité visage / personnage / décor.

Formule :

ComfyUI SA forge l’image.  
RunningHub teste le mouvement cloud.  
DaVinci assemble la mémoire animée.  
ElevenLabs donne la voix.

---

# 2. Place dans la chaîne ERITH.IA

Pipeline de référence :

image parfaite → animation Wan/I2V stable → last frame → DaVinci → narration

RunningHub intervient surtout après l’image maître.

Objectif prioritaire :

obtenir une animation courte, stable et exploitable, sans brûler les coins inutilement.

Règles :

- ne pas lancer une série de tests au hasard ;
- partir d’une image source propre ;
- utiliser un prompt simple ;
- tester une seule variable à la fois ;
- préserver visage, silhouette, vêtements et décor ;
- privilégier mouvement subtil et caméra fixe ;
- récupérer la last frame uniquement si le clip est stable ;
- noter le coût approximatif ;
- arrêter un workflow qui dérive trop.

---

# 3. Éléments à mémoriser

## Workflows RunningHub

À noter pour chaque workflow testé :

- nom du workflow ;
- lien RunningHub ;
- auteur si utile ;
- catégorie ;
- modèle utilisé ;
- résolution ;
- durée ;
- fps si visible ;
- coût approximatif ;
- input requis ;
- prompt positif ;
- prompt négatif ;
- seed si visible ;
- stabilité personnage ;
- stabilité visage ;
- stabilité décor ;
- qualité mouvement ;
- qualité last frame ;
- verdict : garder / retester / éviter.

---

## Critères de sélection

Un workflow utile pour ERITH.IA doit idéalement être :

- compatible image-to-video ;
- stable sur personnage ;
- stable sur visage ;
- stable sur décor ;
- compatible portrait vertical ;
- capable de mouvement subtil ;
- compatible caméra fixe ou très contrôlée ;
- capable de produire une last frame exploitable ;
- raisonnable en coût ;
- lisible dans ses paramètres ;
- réutilisable.

---

# 4. Aide intégrée / Recherche Internet

Cette carte mémoire ne doit pas seulement stocker les workflows testés.

Elle doit aussi servir de point de départ pour rechercher rapidement les workflows actuels, les modèles disponibles, les tendances utiles et les changements de plateforme.

Règle :

RunningHub évolue vite.

Ne pas supposer qu’un workflow vu hier est encore le meilleur aujourd’hui.

Toujours vérifier en ligne pour :

- nouveaux workflows ;
- workflows Wan récents ;
- modèles vidéo récents ;
- tendances Hot / Latest / Trusted ;
- coûts ;
- limites ;
- résolutions disponibles ;
- workflows portrait ;
- workflows last frame ;
- workflows face consistency ;
- bugs récents ;
- changements d’interface.

Sources prioritaires :

1. page officielle RunningHub Workflows ;
2. pages individuelles des workflows ;
3. documentation ou aide RunningHub si disponible ;
4. pages officielles des modèles utilisés ;
5. retours communautaires seulement en complément ;
6. tutoriels YouTube seulement après vérification croisée.

Source officielle de départ :

https://www.runninghub.ai/workflows

Notes vérifiées le 2026-05-14 :

La page Workflows de RunningHub présente des workflows ComfyUI et propose des sections de tri comme For You, Trusted, Hot et Latest. Les tendances visibles incluent notamment des workflows liés à Wan 2.2, Qwen-image et Kontext pour l’image et la vidéo IA.

---

# 5. Requêtes internet utiles

Recherches rapides :

- RunningHub Wan 2.2 I2V workflow
- RunningHub ComfyUI workflow image to video
- RunningHub portrait video workflow
- RunningHub last frame workflow
- RunningHub fixed camera I2V workflow
- RunningHub face consistency workflow
- RunningHub Wan 2.2 480x832 workflow
- RunningHub Qwen image workflow
- RunningHub Kontext workflow
- RunningHub workflow cost coins
- RunningHub latest video workflow
- RunningHub trusted Wan workflow
- RunningHub stable character video workflow

---

# 6. Checklist avant test

Avant de lancer un workflow RunningHub :

- vérifier le nom du workflow ;
- vérifier si le workflow est récent ;
- vérifier s’il est Trusted / Hot / Latest ;
- vérifier l’input demandé ;
- vérifier la résolution ;
- vérifier le coût approximatif ;
- préparer une image source propre ;
- préparer un prompt simple ;
- préparer un négatif court ;
- ne modifier qu’une variable ;
- noter le résultat.

Après le test :

- télécharger le résultat ;
- observer visage / silhouette / décor ;
- vérifier la stabilité de la caméra ;
- vérifier si la last frame est exploitable ;
- noter le coût ;
- classer garder / retester / éviter.

---

# 7. Notes de test à remplir

Template :

Nom du workflow :  
Lien :  
Date :  
Catégorie :  
Modèle :  
Input :  
Résolution :  
Durée :  
Coût approximatif :  
Image source :  
Prompt positif :  
Prompt négatif :  
Mouvement demandé :  
Stabilité visage :  
Stabilité personnage :  
Stabilité décor :  
Caméra :  
Last frame exploitable : oui / non  
Problème :  
Solution possible :  
Verdict : garder / retester / éviter

---

# 8. Gestion des coins

Les coins RunningHub sont une ressource de production.

Règles :

- ne pas shotgun relaunch ;
- ne pas relancer sans comprendre l’échec ;
- garder un coussin de sécurité ;
- tester court avant de produire long ;
- préférer une image source très solide ;
- éviter les prompts trop chargés ;
- arrêter vite un workflow qui détruit le personnage.

Formule :

Un test RunningHub doit produire une information utile, même s’il échoue.

---

# 9. Règles de sécurité

Ne pas lancer une série de workflows en aveugle.

Ne pas confondre workflow populaire et workflow utile au projet.

Ne pas brûler les coins pour corriger une image source faible.

Ne pas garder un workflow qui déforme systématiquement le visage.

Ne pas construire la continuité LEGO sur une last frame instable.

---

# 10. Phrase mémoire

RunningHub est le laboratoire cloud.

Internet sert à trouver les workflows vivants.

La carte mémoire sert à ne garder que les workflows vraiment utiles à la chaîne LEGO.

On teste peu, on observe bien, on garde seulement ce qui sert.
