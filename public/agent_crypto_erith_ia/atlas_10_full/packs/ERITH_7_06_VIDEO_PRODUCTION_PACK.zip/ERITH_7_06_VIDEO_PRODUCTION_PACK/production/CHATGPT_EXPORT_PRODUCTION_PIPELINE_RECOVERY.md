# CHATGPT EXPORT PRODUCTION PIPELINE RECOVERY

Statut : Brique 06 validée

Source : export ChatGPT indexé dans les Briques 01 à 05

Dépôt : BlueAzur-Hub/erith-ia-notion-archive-private

Rôle : stabiliser les règles de production image / vidéo récupérées depuis l’historique ChatGPT.

Ce fichier sert de mémoire opérationnelle pour ComfyUI, Wan / I2V, RunningHub, DaVinci Resolve, ElevenLabs et la logique LEGO du projet @erith IA / ERITH.IA.

---

## 1. Principe central

La production @erith IA repose sur une logique simple :

image parfaite → animation Wan / I2V stable → last frame → DaVinci → narration

Cette logique est appelée logique LEGO.

Elle consiste à construire la vidéo morceau par morceau, sans demander à un seul outil de tout réussir d’un coup.

Formule :

Une image parfaite vaut mieux que dix animations instables.

---

## 2. Règle d’or

Toujours verrouiller l’image fixe avant l’animation.

Ne pas lancer Wan / I2V sur une image encore incertaine.

Une image doit être validée sur :

- composition ;
- visage ;
- silhouette ;
- tenue ;
- lumière ;
- décor ;
- symbole ;
- lisibilité ;
- cohérence lore ou hors-lore ;
- potentiel d’animation.

Si l’image n’est pas bonne, l’animation ne sauvera pas la scène.

---

## 3. Méthode LEGO

La méthode validée :

1. créer ou choisir une image maître ;
2. vérifier qu’elle tient seule comme plan vidéo ;
3. animer subtilement avec Wan / I2V ;
4. extraire la dernière frame stable ;
5. utiliser cette last frame comme base du plan suivant ;
6. monter les plans dans DaVinci ;
7. ajouter narration, voix, musique, ambiance ;
8. lisser par transitions courtes.

Objectif :

construire une séquence fluide à partir de plans courts et maîtrisés.

---

## 4. Règle des petites variables

Ne pas changer trop de choses en même temps.

Éviter de modifier simultanément :

- modèle ;
- LoRA ;
- prompt image ;
- prompt animation ;
- cadrage ;
- seed ;
- résolution ;
- durée ;
- mouvement caméra ;
- négatif ;
- workflow.

Changer une variable à la fois permet de comprendre ce qui améliore ou casse le résultat.

Formule :

Un test lisible vaut mieux qu’une rafale confuse.

---

## 5. Prompts image

Un prompt image doit être :

- clair ;
- structuré ;
- orienté image fixe ;
- cohérent avec le modèle utilisé ;
- compatible avec la scène ;
- sans contradictions inutiles.

Pour @erith IA, préciser si nécessaire :

- personnage ;
- tenue ;
- posture ;
- environnement ;
- lumière ;
- caméra ;
- style ;
- symbole ;
- ambiance ;
- niveau de détail.

Le prompt image ne doit pas contenir de demandes d’animation complexes.

---

## 6. Prompts animation

Un prompt animation doit être différent du prompt image.

Il doit décrire :

- ce qui bouge ;
- ce qui reste stable ;
- le mouvement caméra ;
- la durée ressentie ;
- l’ambiance dynamique ;
- les éléments secondaires ;
- les limites à respecter.

Règle :

Pour Wan / I2V, l’animation doit souvent être plus simple que l’image.

Exemples de mouvements sûrs :

- pluie légère ;
- particules ;
- lueur holographique ;
- cheveux qui bougent légèrement ;
- tissu qui frémit ;
- lumière qui pulse ;
- foule floue en arrière-plan ;
- caméra très lente ;
- breathing motion subtil ;
- brume qui glisse.

Éviter les actions complexes si la stabilité est prioritaire.

---

## 7. Positif et négatif

Toujours séparer :

- prompt positif ;
- prompt négatif.

Ne pas écrire “no...” ou “without...” dans le prompt positif.

Le négatif doit contenir ce qu’il faut éviter.

Le positif doit seulement décrire ce que l’on veut voir.

Règle :

Le positif construit.
Le négatif nettoie.

---

## 8. Wan / I2V

Pour Wan / I2V, privilégier :

- plans courts ;
- mouvement subtil ;
- caméra stable ;
- décor déjà bien défini ;
- personnage peu mobile ;
- expression préservée ;
- continuité visuelle ;
- last frame exploitable.

Éviter :

- grands gestes ;
- rotations corporelles complexes ;
- combats complets ;
- changements de tenue ;
- transformations rapides ;
- caméra trop ambitieuse ;
- foule très détaillée au premier plan ;
- prompts contradictoires.

Wan doit prolonger l’image, pas réinventer la scène.

---

## 9. RunningHub

Les crédits RunningHub doivent être traités comme une ressource précieuse.

Règle symbolique :

Les coins RunningHub sont des crédits Mako.

Méthode recommandée :

- tester court ;
- éviter les relances impulsives ;
- garder une marge de sécurité ;
- ne pas brûler les crédits sur des images non validées ;
- noter ce qui marche ;
- comparer un paramètre à la fois.

Objectif :

ne pas transformer l’expérimentation en fuite de crédits.

---

## 10. ComfyUI

ComfyUI sert à produire, corriger ou préparer les images maîtres.

Règles :

- garder les workflows lisibles ;
- ne pas modifier dix nœuds à la fois ;
- vérifier les vrais chemins de modèles ;
- respecter les fichiers locaux ;
- distinguer GGUF, safetensors et checkpoints ;
- éviter de supposer un loader qui n’existe pas ;
- sauvegarder les workflows validés.

Pour Wan 2.2 I2V GGUF local, configuration connue :

models/unet/Wan2.2-I2V-A14B-HighNoise-Q3_K_S.gguf

models/unet/Wan2.2-I2V-A14B-LowNoise-Q3_K_S.gguf

Workflow associé :

workflows/ERITH.IA_HORS_LORE_STYLE_LOCK_V1_WAN22_I2V_OPTIONS_PLUS_V4_GGUF_REAL.json

---

## 11. DaVinci Resolve

DaVinci sert à transformer les clips courts en vraie séquence.

Règles :

- importer les clips validés ;
- organiser les plans par ordre narratif ;
- ajuster les transitions ;
- stabiliser le rythme ;
- corriger les noirs ou les barres si nécessaire ;
- retimer la voix ;
- caler les pauses ;
- harmoniser l’étalonnage ;
- ne pas surcharger les effets.

Pour les formats verticaux, vérifier les paramètres de timeline et de mise à l’échelle.

Si des barres gênantes apparaissent, utiliser la logique de crop / scaling adaptée au format.

---

## 12. ElevenLabs et narration

La voix est une couche narrative majeure.

Règles :

- écrire une narration respirante ;
- prévoir des pauses ;
- ne pas saturer le texte ;
- adapter la durée aux plans ;
- faire respirer les phrases ;
- garder une émotion claire ;
- éviter les phrases trop longues ;
- caler le texte après test audio si nécessaire.

La narration doit aider l’image, pas l’expliquer lourdement.

---

## 13. Format vidéo cible

Le projet utilise souvent le format vertical / téléphone.

Avantages :

- adapté aux Shorts ;
- lisible sur mobile ;
- compatible avec portraits ;
- bon pour scènes centrées sur personnage ;
- efficace pour micro-épisodes.

Points à surveiller :

- safe area ;
- visage ;
- texte à l’écran ;
- détails trop petits ;
- marges ;
- cadrage corps entier si demandé ;
- continuité entre les plans.

---

## 14. Règles visuelles @erith IA

Quand le mode Seven / Neo Midgar est actif :

- préserver la verticalité ;
- respecter les strates ville haute / slums ;
- éviter les voitures modernes si la règle de scène l’interdit ;
- garder la mémoire, la pluie, la brume, les néons, la nature et le métal ;
- respecter les symboles ;
- ne pas transformer Neo Midgar en ville générique sauf demande hors-lore.

Quand le mode Hors-Lore est actif :

- ne pas ramener Neo Midgar ;
- ne pas ramener Aerith-7 ;
- ne pas ramener NØX ;
- utiliser seulement les modules explicitement demandés ;
- accepter une ville cyberpunk originale ou générique comme résultat valide.

---

## 15. Machine à Présages

Si la Machine à Présages est impliquée, respecter sa représentation validée :

- machine cylindrique souterraine ;
- mécanisme prophétique ancien ;
- cylindre vertical enfoui ;
- anneaux concentriques ;
- rouages ;
- cœur central ;
- architecture rituelle ;
- manifestation physique de la Prophétie.

Ne pas la réduire à une simple tour céleste.

Elle peut projeter des signes vers la surface, mais son vrai corps est souterrain.

---

## 16. Continuité par last frame

La last frame est un outil de continuité.

Elle permet :

- d’enchaîner les plans ;
- de préserver la lumière ;
- de garder la pose ;
- de limiter les ruptures ;
- de construire la séquence en fragments ;
- de créer une progression maîtrisée.

Règle :

La dernière image d’un plan peut devenir la première mémoire du plan suivant.

---

## 17. Erreurs à éviter

Éviter :

- lancer une animation avant validation de l’image ;
- relancer dix fois sans diagnostic ;
- demander trop de mouvement ;
- changer trop de paramètres ;
- mélanger prompt image et animation ;
- oublier le négatif ;
- brûler les crédits ;
- forcer Wan à créer une scène qu’il ne peut pas stabiliser ;
- perdre le visage ;
- perdre la tenue ;
- perdre le symbole ;
- perdre la continuité ;
- partir dans un test technique sans objectif vidéo.

---

## 18. Checklist avant animation

Avant de lancer Wan / I2V, vérifier :

- image validée ;
- cadrage validé ;
- personnage stable ;
- décor lisible ;
- prompt animation simple ;
- mouvement principal clair ;
- négatif prêt ;
- durée raisonnable ;
- crédits disponibles ;
- objectif du plan défini ;
- usage possible de la last frame.

Si un point majeur manque, corriger avant de lancer.

---

## 19. Checklist après animation

Après rendu, vérifier :

- visage préservé ;
- corps cohérent ;
- tenue intacte ;
- décor stable ;
- mouvement lisible ;
- absence de morphing gênant ;
- dernière frame exploitable ;
- raccord possible ;
- intérêt réel pour DaVinci ;
- potentiel narratif.

Si la last frame est bonne, la sauvegarder.

---

## 20. Synthèse finale

Brique 06 = pipeline production récupéré.

Règle centrale :

image parfaite → animation stable → last frame → montage → narration

Seven doit aider Christophe à produire moins de chaos et plus de plans exploitables.

La production @erith IA n’est pas une rafale.

C’est une construction LEGO patiente, scène par scène, brique par brique, jusqu’à ce que la mémoire devienne vidéo.
