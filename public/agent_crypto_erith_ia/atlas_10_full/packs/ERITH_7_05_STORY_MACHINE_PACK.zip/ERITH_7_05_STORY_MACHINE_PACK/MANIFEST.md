# ERITH-7 — Story Machine Pack

Pack: ERITH_7_05_STORY_MACHINE_PACK

## Rôle
Machine à histoires, cartes narratives, archétypes, mondes, scènes, Pack+ et influences majeures.

## Fichiers inclus

- core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
- core/AERITH_8_CONSTELLATIONS_MODULES.md
- core/AERITH_8_SOLAIRE.md
- core/AERITH_9_CONSTELLATIONS_MODULES.md
- core/AERITH_9_LUNAIRE.md
- core/AERITH_MATH_ORACLE.md
- core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md
- core/SEVEN_TOP_OF_MIND.md
- memory_cards/CHILDREN_STORY_THEMES_CARD.md
- memory_cards/COMBINATIONS.md
- memory_cards/EMOTIONAL_ARCS_CARD.md
- memory_cards/GUIDES_AND_ALLIES_CARD.md
- memory_cards/HERO_ARCHETYPES_CARD.md
- memory_cards/NARRATION_AND_DIALOGUE_CARD.md
- memory_cards/OBSTACLES_AND_ANTAGONISTS_CARD.md
- memory_cards/PACK_PLUS_BUILDER_CARD.md
- memory_cards/POWERS_AND_RULES_CARD.md
- memory_cards/QUEST_OBJECTS_CARD.md
- memory_cards/SCENES_AND_KEYFRAMES_CARD.md
- memory_cards/STORY_ENGINE_CARD.md
- memory_cards/STORY_MACHINE_CARD_ROUTER.md
- memory_cards/VISUAL_STYLE_DNA_CARD.md
- memory_cards/WORLDS_AND_PLACES_CARD.md
- modules/blade_runner.md
- modules/dune.md
- modules/erith_ia_altered_carbon_module_memoire_fr.md
- modules/erith_ia_celtes_culture_celtique_futhark_final_fr.md
- modules/erith_ia_chateau_ambulant_maison_vivante_fr.md
- modules/erith_ia_chateau_dans_le_ciel_ruines_celestes_fr.md
- modules/erith_ia_studio_ghibli_mondes_vivants_fr.md
- modules/ghost_in_the_shell.md
- modules/machine_a_presages_omen_machine.md
- modules/module_alice_pays_merveilles_lewis_carroll.md
- modules/module_histoire_sans_fin_michael_ende.md
- modules/module_sword_of_truth_terry_goodkind_niveau_1.md
- modules/module_sword_of_truth_terry_goodkind_niveau_2.md
- modules/module_sword_of_truth_terry_goodkind_niveau_3_genie.md
- modules/module_sword_of_truth_terry_goodkind_niveau_4_visuel_etendu.md
- modules/wizard_of_oz.md
