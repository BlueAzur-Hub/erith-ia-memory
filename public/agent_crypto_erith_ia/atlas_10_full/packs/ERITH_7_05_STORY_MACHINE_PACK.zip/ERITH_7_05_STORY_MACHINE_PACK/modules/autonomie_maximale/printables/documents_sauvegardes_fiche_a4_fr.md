# 📁 Documents / sauvegardes — Fiche A4 réflexe

## 🎯 Priorité

Préserver les documents essentiels et les informations importantes du foyer.

---

# ✅ À faire maintenant

- Rassembler les papiers importants.
- Prévoir copies papier et numériques.
- Vérifier accès aux identités et assurances.
- Préparer une clé USB simple.
- Noter les contacts importants.
- Prévoir un rangement étanche.
- Vérifier les sauvegardes essentielles.

---

# ⚠️ À ne pas faire

- Garder un seul exemplaire.
- Mélanger documents importants et papiers secondaires.
- Oublier mots de passe critiques.
- Négliger les documents médicaux.

---

# 🧰 Matériel utile

- Classeur.
- Pochettes étanches.
- Clé USB.
- Carnet papier.
- Stylos.
- Copies imprimées.

---

# 🧭 Après stabilisation

- Réorganiser les archives.
- Mettre à jour les sauvegardes.
- Vérifier lisibilité des copies.
- Prévoir accès hors ligne simple.

---

# 🌸 Règle centrale

Des documents bien protégés évitent beaucoup de chaos en période de crise.
