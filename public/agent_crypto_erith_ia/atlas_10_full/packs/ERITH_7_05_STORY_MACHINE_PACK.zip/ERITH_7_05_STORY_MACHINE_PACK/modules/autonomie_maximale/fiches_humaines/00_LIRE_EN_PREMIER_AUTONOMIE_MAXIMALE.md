# 🌍 Lire en premier — Autonomie Maximale

## Bienvenue

Ce dossier existe pour les humains.

Pas besoin d’être technicien.

Pas besoin de comprendre les JSON.

Pas besoin de devenir survivaliste.

Le but est simple :

rendre la vie quotidienne plus solide.

---

## La règle la plus importante

Commence petit.

Très petit.

Exemple :

- une lampe ;
- un peu d’eau ;
- une radio ;
- une trousse ;
- une routine ;
- protéger les animaux ;
- apprendre à faire pousser quelques plantes.

---

## Ce que ce module essaye d’éviter

- la panique ;
- les rumeurs ;
- les achats absurdes ;
- les gadgets inutiles ;
- les vidéos anxiogènes ;
- les faux experts ;
- les comportements dangereux.

---

## Ce que ce module essaye de développer

- calme ;
- autonomie ;
- discernement ;
- routines ;
- protection du vivant ;
- savoir-faire simples ;
- entraide locale.

---

## Si tu es perdu

Commence par :

- les checklists ;
- les fiches humaines ;
- une seule amélioration à la fois.

---

## Les vraies priorités

1. sécurité ;
2. eau ;
3. chaleur / abri ;
4. santé ;
5. nourriture ;
6. information ;
7. animaux ;
8. sommeil ;
9. communauté.

---

## La vérité importante

La résilience n’est pas un bunker.

La résilience, c’est :

- savoir quoi faire ;
- rester calme ;
- protéger les proches ;
- protéger les animaux ;
- garder un minimum d’organisation.

---

## Phrase clé

Petit.

Simple.

Calme.

Progressif.