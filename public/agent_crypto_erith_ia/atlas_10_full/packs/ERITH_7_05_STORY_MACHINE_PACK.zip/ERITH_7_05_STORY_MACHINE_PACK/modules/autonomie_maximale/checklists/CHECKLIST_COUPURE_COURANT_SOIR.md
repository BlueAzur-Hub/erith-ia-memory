# 💡 Checklist — Coupure de courant le soir

## 1. Rester calme

Une coupure ne signifie pas automatiquement une catastrophe.

Respirer.

Éviter la panique.

---

## 2. Vérifier les personnes

- enfants ;
- personnes fragiles ;
- personnes âgées ;
- voisins vulnérables si applicable.

---

## 3. Vérifier les animaux

- eau ;
- abri ;
- fermeture du poulailler ;
- calme général.

---

## 4. Sortir les lampes

Priorité :

- LED ;
- lampe frontale ;
- lumière douce.

Éviter les bougies si possible.

---

## 5. Économiser les batteries

- réduire luminosité téléphone ;
- fermer applications inutiles ;
- éviter vidéos et réseaux anxiogènes.

---

## 6. Vérifier le froid ou la chaleur

Selon la saison :

- couvertures ;
- vêtements ;
- ventilation ;
- eau.

---

## 7. Préserver le sommeil

Ne pas passer la nuit à surveiller inutilement.

La fatigue détruit le discernement.

---

## 8. Éviter les erreurs dangereuses

Ne pas :

- improviser un chauffage ;
- utiliser un appareil dangereux ;
- laisser une flamme sans surveillance ;
- courir dans le noir ;
- alimenter les rumeurs.

---

## 9. Avant dormir

- eau prête ;
- lampe accessible ;
- animaux sécurisés ;
- téléphone chargé si possible ;
- vêtements prêts pour la nuit.

---

## Phrase clé

Lumière.

Calme.

Animaux.

Sommeil.

Pas de panique.