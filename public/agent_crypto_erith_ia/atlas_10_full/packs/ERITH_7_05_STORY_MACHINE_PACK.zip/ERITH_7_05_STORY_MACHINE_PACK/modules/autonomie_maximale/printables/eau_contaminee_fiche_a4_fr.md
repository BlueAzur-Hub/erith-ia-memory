# 🚱 Eau contaminée — Fiche A4 réflexe

## 🎯 Priorité

Éviter de boire une eau dangereuse et protéger rapidement le foyer.

---

# ✅ À faire maintenant

- Stopper immédiatement la consommation suspecte.
- Utiliser uniquement une eau sûre.
- Séparer eau potable et eau non potable.
- Prévoir purification si possible.
- Vérifier les personnes fragiles.
- Prévoir les besoins des animaux.
- Nettoyer les contenants utiles.
- Suivre les consignes fiables disponibles.

---

# ⚠️ À ne pas faire

- Boire une eau douteuse.
- Mélanger eau propre et eau suspecte.
- Négliger les symptômes inhabituels.
- Ignorer les alertes sanitaires fiables.

---

# 🧰 Matériel utile

- Eau stockée.
- Filtres.
- Pastilles de purification.
- Contenants propres.
- Savon.
- Jerricans.

---

# 🧭 Après stabilisation

- Organiser les réserves.
- Prévoir purification durable.
- Nettoyer les équipements.
- Préserver les contenants propres.

---

# 🌸 Règle centrale

En cas de doute sur l’eau : ne pas boire avant vérification ou traitement.
