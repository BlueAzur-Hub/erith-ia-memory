# 🖨️ PRINTABLES — AUTONOMIE MAXIMALE

## 🌍 Rôle

Ce dossier contient les fiches A4 imprimables du module Autonomie Maximale.

Objectif :

- consultation rapide ;
- usage hors ligne ;
- impression papier ;
- accès simple en situation de stress ;
- aide familiale immédiate.

Ces fiches ne remplacent pas les pages Notion complètes ni les bases JSON.

Elles servent de fiches réflexes courtes.

---

# 🧭 Fiches disponibles

## ⚡ Urgences immédiates

- [💡 Coupure de courant](./coupure_de_courant_fiche_a4_fr.md)
- [💧 Coupure d’eau](./coupure_eau_fiche_a4_fr.md)
- [🩹 Accident / premiers secours](./accident_premiers_secours_fiche_a4_fr.md)
- [🔥 Incendie domestique](./incendie_domestique_fiche_a4_fr.md)
- [🚱 Eau contaminée](./eau_contaminee_fiche_a4_fr.md)

---

## ⚠️ Risques majeurs

- [🎒 Évacuation](./evacuation_fiche_a4_fr.md)
- [🏠 Confinement](./confinement_fiche_a4_fr.md)
- [☢️ Alerte nucléaire / radiologique](./alerte_nucleaire_radiologique_fiche_a4_fr.md)

---

## 📻 Communication / organisation

- [📻 Communication sans Internet](./communication_sans_internet_fiche_a4_fr.md)
- [📁 Documents / sauvegardes](./documents_sauvegardes_fiche_a4_fr.md)

---

# 🧩 Structure des fiches

Chaque fiche suit la même logique :

- 🎯 Priorité
- ✅ À faire maintenant
- ⚠️ À ne pas faire
- 🧰 Matériel utile
- 🧭 Après stabilisation
- 🌸 Règle centrale

---

# 🧠 Philosophie

Le but n’est pas la peur.

Le but est :

- rester calme ;
- agir vite ;
- éviter les erreurs graves ;
- protéger les personnes ;
- protéger les animaux ;
- préserver les ressources ;
- garder une organisation simple.

---

# 🌸 Règle centrale

Une fiche imprimable doit rester courte, claire et exploitable immédiatement.
