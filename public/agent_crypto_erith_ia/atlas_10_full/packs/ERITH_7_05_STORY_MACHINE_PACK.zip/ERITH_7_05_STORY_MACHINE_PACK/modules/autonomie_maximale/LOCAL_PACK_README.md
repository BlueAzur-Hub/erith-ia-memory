# 💾 LOCAL PACK — AUTONOMIE MAXIMALE

## 🌍 Objectif

Ce fichier explique comment préparer une version locale autonome du module Autonomie Maximale.

But :

- fonctionner sans Internet ;
- conserver les données importantes ;
- utiliser les JSON localement ;
- garder les printables accessibles ;
- préparer une clé USB ou un PC secondaire ;
- réduire la dépendance au cloud.

---

# 🧭 Minimum recommandé

Prévoir au minimum :

- un PC portable ;
- une clé USB ;
- une copie locale du module ;
- les printables ;
- les JSON ;
- une carte papier ;
- des documents importants.

---

# 📦 Dossiers importants

## 📁 Module principal

modules/autonomie_maximale/

---

## 📁 JSON

modules/autonomie_maximale/data/

Contient :

- bases IA ;
- connaissances spécialisées ;
- routines ;
- données de résilience.

---

## 📁 Printables

modules/autonomie_maximale/printables/

Contient :

- fiches A4 ;
- versions imprimables ;
- réflexes rapides ;
- consultation hors ligne.

---

# 💻 Préparer une copie locale

## Méthode simple

1. Télécharger le dépôt GitHub en ZIP.
2. Extraire le ZIP.
3. Copier le dossier :

modules/autonomie_maximale/

4. Le placer :

- sur le PC principal ;
- sur le Transformer Book ;
- sur une clé USB ;
- éventuellement sur un téléphone.

---

# 🧠 Utilisation avec IA locale

Possible avec :

- Ollama ;
- LM Studio ;
- AnythingLLM ;
- autres LLM locaux.

Les JSON servent alors de mémoire spécialisée.

---

# 🖨️ Usage hors ligne

Les fiches printables doivent rester accessibles même :

- sans Internet ;
- sans IA ;
- sans cloud ;
- avec peu de batterie.

Le papier reste une couche importante du système.

---

# 🌸 Règle centrale

Le LLM aide.

Mais la vraie résilience repose d’abord sur :

- les documents ;
- les routines ;
- les cartes ;
- les réflexes ;
- les connaissances locales ;
- les supports hors ligne.
