# 🗂️ INDEX DATA — AUTONOMIE MAXIMALE

## 🌍 Rôle

Cet index recense les bases JSON du module Autonomie Maximale.

Ces fichiers forment une mémoire hors ligne exploitable par :

- humain ;
- Notion ;
- GitHub ;
- LLM local ;
- impression papier ;
- interface Aerith / Seven Heaven.

Objectif : permettre une résilience civile calme, autonome, non paranoïaque, centrée sur la protection du vivant.

---

## 🧭 Règle d’usage

Ne jamais charger toutes les briques sans raison.

Toujours sélectionner uniquement les bases utiles à la situation :

- eau ;
- nourriture ;
- santé ;
- énergie ;
- animaux ;
- jardin ;
- information ;
- météo ;
- psychologie ;
- routines.

---

## 🧩 Bases data confirmées

### 💧 Eau, pluie, hygiène

- eau_purification_stockage_fr.json
- eau_pluie_recuperation_stockage_fr.json
- hygiene_toilettes_dechets_crise_fr.json

### 🥫 Nourriture, stocks, conservation

- nourriture_reserves_conservation_fr.json
- conservation_aliments_hors_ligne_fr.json
- cuisine_sobre_recettes_crise_fr.json
- graines_germees_fr.json
- famine_penurie_durable_fr.json

### 🌱 Jardin, semences, sols, vivant

- potager_jardin_resilient_fr.json
- semences_graines_reproductibles_fr.json
- calendrier_semis_lune_saisons_fr.json
- faune_sauvage_cueillette_discernement_fr.json

### 🐾 Animaux, basse-cour, biodiversité

- animaux_domestiques_et_crise_fr.json
- basse_cour_poules_coq_crise_fr.json
- biodiversite_pollinisateurs_fr.json

### 🩺 Santé, premiers secours, prudence

- premiers_secours_hygiene_fr.json
- sommeil_stress_moral_crise_fr.json
- gestion_stress_panique_discernement_fr.json
- propheties_peurs_collectives_discernement_fr.json

### ⚡ Énergie, lumière, nuit, maison

- energie_chaleur_lumiere_fr.json
- autonomie_energetique_domestique_fr.json
- nuit_obscurite_eclairage_securite_fr.json
- accidents_domestiques_betise_humaine_fr.json
- outils_reparations_maintenance_fr.json
- vetements_textiles_protection_climat_fr.json

### 📻 Information, documents, communication

- communication_information_radio_hors_ligne_fr.json
- documents_papiers_sauvegardes_hors_ligne_fr.json
- routines_quotidiennes_checklists_foyer_fr.json
- education_transmission_competences_fr.json

### 🗺️ Territoire, mobilité, météo

- cartographie_france_resilience_civile_fr.json
- mobilite_transport_evacuations_civiles_fr.json
- meteo_climat_alertes_locales_fr.json

### ⚠️ Risques majeurs, confinement, instabilité

- alerte_nucleaire_radiologique_fr.json
- guerre_troubles_civils_fr.json
- confinement_foyer_crise_fr.json

### 🤝 Communauté, économie, entraide

- entraide_voisinage_reseau_local_fr.json
- economie_budget_troc_crise_fr.json

---

## 🛡️ Garde-fous globaux

Le module refuse :

- violence ;
- paranoïa ;
- exploitation ;
- marché noir ;
- pseudo-science dangereuse ;
- promesses de sécurité totale ;
- identification risquée de plantes ou champignons ;
- dépendance totale à Internet ;
- dépendance totale à une autorité extérieure ;
- discours de peur sans solution concrète.

---

## 🌿 Formule courte

Autonomie calme.

Mémoire hors ligne.

Protection du vivant.

Chargement minimal.

Action précise.
