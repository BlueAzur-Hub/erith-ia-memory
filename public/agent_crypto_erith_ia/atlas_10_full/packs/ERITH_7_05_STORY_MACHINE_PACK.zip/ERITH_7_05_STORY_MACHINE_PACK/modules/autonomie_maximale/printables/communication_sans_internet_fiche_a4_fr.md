# 📻 Communication sans Internet — Fiche A4 réflexe

## 🎯 Priorité

Maintenir des informations fiables et des liens humains même sans réseau Internet.

---

# ✅ À faire maintenant

- Préserver les batteries.
- Prévoir une radio.
- Utiliser SMS si le réseau est saturé.
- Noter les informations importantes sur papier.
- Définir des points de contact simples.
- Prévoir horaires de communication.
- Vérifier les proches fragiles.
- Limiter les rumeurs.

---

# ⚠️ À ne pas faire

- Croire immédiatement toutes les informations.
- Vider les batteries inutilement.
- Dépendre d’une seule source.
- Propager des rumeurs.

---

# 🧰 Matériel utile

- Radio.
- Piles.
- Carnet.
- Stylos.
- Batteries externes.
- Chargeurs.
- Liste de contacts papier.

---

# 🧭 Après stabilisation

- Organiser les contacts prioritaires.
- Prévoir des messages courts.
- Préserver les moyens de recharge.
- Maintenir une information calme et vérifiée.

---

# 🌸 Règle centrale

Sans Internet, l’information fiable et les liens humains deviennent essentiels.
