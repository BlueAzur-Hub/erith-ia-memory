# ☢️ Alerte nucléaire / radiologique — Fiche A4 réflexe

## 🎯 Priorité

Réduire l’exposition et protéger rapidement le foyer.

---

# ✅ À faire maintenant

- Rentrer immédiatement à l’intérieur.
- Faire entrer les animaux.
- Fermer portes, fenêtres et aérations.
- Couper ventilation si nécessaire.
- S’éloigner des fenêtres.
- Préparer eau, radio et éclairage.
- Écouter uniquement les consignes fiables.
- Éviter les déplacements inutiles.
- Isoler les vêtements exposés si nécessaire.
- Se laver doucement si exposition suspectée.

---

# ⚠️ À ne pas faire

- Sortir observer la situation.
- Propager des rumeurs.
- Consommer eau ou aliments suspects.
- Ouvrir les fenêtres inutilement.
- Prendre des médicaments sans consigne fiable.

---

# 🧰 Matériel utile

- Radio.
- Eau.
- Nourriture emballée.
- Savon.
- Sacs fermés.
- Lampes.
- Batteries.

---

# 🧭 Après stabilisation

- Maintenir le confinement.
- Vérifier les informations locales.
- Préserver les ressources.
- Maintenir le calme du foyer.

---

# 🌸 Règle centrale

En alerte radiologique : rentrer, fermer, écouter, attendre.
