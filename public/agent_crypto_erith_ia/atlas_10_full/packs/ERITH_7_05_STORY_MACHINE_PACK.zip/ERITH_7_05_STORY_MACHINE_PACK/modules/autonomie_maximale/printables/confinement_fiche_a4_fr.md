# 🏠 Confinement — Fiche A4 réflexe

## 🎯 Priorité

Stabiliser le foyer, préserver les ressources et maintenir le calme.

---

# ✅ À faire maintenant

- Faire rentrer les personnes et animaux.
- Limiter les sorties.
- Vérifier eau et nourriture.
- Préparer éclairage et communication.
- Organiser une routine simple.
- Préserver les batteries.
- Maintenir hygiène minimale.
- Limiter les informations anxiogènes.
- Vérifier les personnes fragiles.

---

# ⚠️ À ne pas faire

- Créer une atmosphère de peur.
- Gaspiller les ressources.
- Surcharger les personnes fragiles d’informations.
- Négliger sommeil et repas.

---

# 🧰 Matériel utile

- Eau.
- Nourriture.
- Radio.
- Lampes.
- Batteries.
- Jeux ou activités calmes.
- Médicaments.

---

# 🧭 Après stabilisation

- Maintenir des horaires réguliers.
- Réorganiser les ressources.
- Préserver le moral du foyer.
- Préparer une durée plus longue si nécessaire.

---

# 🌸 Règle centrale

Un confinement stable repose sur routines simples, calme et organisation.
