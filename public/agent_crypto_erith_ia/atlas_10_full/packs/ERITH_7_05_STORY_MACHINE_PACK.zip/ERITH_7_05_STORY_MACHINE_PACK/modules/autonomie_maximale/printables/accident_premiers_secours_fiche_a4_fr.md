# 🩹 Accident / premiers secours — Fiche A4 réflexe

## 🎯 Priorité

Protéger la victime, éviter l’aggravation et prévenir les secours si nécessaire.

---

# ✅ À faire maintenant

- Rester calme.
- Sécuriser la zone.
- Vérifier conscience et respiration.
- Appeler les secours si nécessaire.
- Arrêter un saignement important.
- Mettre la victime en position adaptée.
- Couvrir pour éviter le froid.
- Rassurer la personne.
- Éloigner les curieux.
- Préparer les informations utiles pour les secours.

---

# ⚠️ À ne pas faire

- Déplacer inutilement une victime.
- Donner à boire à une personne inconsciente.
- Paniquer.
- Laisser seule une personne fragile.
- Utiliser des gestes non maîtrisés.

---

# 🧰 Matériel utile

- Trousse de secours.
- Gants.
- Compresses.
- Bandages.
- Couverture.
- Lampe.
- Téléphone chargé.

---

# 🧭 Après stabilisation

- Noter les événements importants.
- Vérifier les autres personnes.
- Réorganiser le matériel utilisé.
- Prévoir repos et surveillance.

---

# 🌸 Règle centrale

En premiers secours : protéger, alerter, calmer, surveiller.
