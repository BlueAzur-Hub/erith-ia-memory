# 💧 Coupure d’eau — Fiche A4 réflexe

## 🎯 Priorité

Préserver l’eau potable, l’hygiène minimale et le calme du foyer.

---

# ✅ À faire maintenant

- Vérifier si la coupure est locale ou générale.
- Stocker immédiatement l’eau encore disponible.
- Remplir bouteilles, casseroles et contenants propres.
- Limiter immédiatement le gaspillage.
- Prévoir une eau séparée pour les toilettes.
- Utiliser d’abord l’eau potable pour boire.
- Prévoir une hygiène simple et minimale.
- Vérifier les personnes fragiles.
- Prévoir les besoins des animaux.
- Suivre les informations fiables si disponibles.

---

# ⚠️ À ne pas faire

- Gaspiller l’eau restante.
- Boire une eau douteuse sans traitement.
- Négliger l’hygiène des mains.
- Utiliser toute l’eau pour le nettoyage.
- Paniquer ou multiplier les achats inutiles.

---

# 🧰 Matériel utile

- Bouteilles propres.
- Jerricans.
- Pastilles de purification.
- Filtres simples.
- Savon.
- Lingettes.
- Seaux.
- Eau de secours.

---

# 🧭 Après stabilisation

- Organiser les réserves.
- Prévoir rationnement simple.
- Séparer eau potable et eau sanitaire.
- Préparer récupération d’eau si nécessaire.
- Vérifier régulièrement les informations locales.

---

# 🌸 Règle centrale

En coupure d’eau, chaque litre devient précieux.
