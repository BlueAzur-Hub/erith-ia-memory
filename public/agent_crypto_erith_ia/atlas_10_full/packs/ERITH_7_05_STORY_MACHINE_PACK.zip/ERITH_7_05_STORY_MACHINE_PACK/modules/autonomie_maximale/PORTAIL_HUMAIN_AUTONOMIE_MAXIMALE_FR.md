# 🌍 Portail humain — Autonomie Maximale

## Lire en premier

Bienvenue.

Ce portail est la porte d’entrée humaine du module Autonomie Maximale.

Tu n’as pas besoin d’être informaticien.

Tu n’as pas besoin de lire les fichiers JSON.

Les fichiers JSON sont les bases de données pour les IA, les LLM locaux et les recherches internes.

Pour un humain, il faut commencer ici.

---

## À quoi sert ce module ?

Autonomie Maximale sert à rendre un foyer, une famille ou une petite communauté moins fragile.

Le but n’est pas d’avoir peur.

Le but est de savoir quoi faire simplement quand quelque chose se dégrade :

- coupure d’électricité ;
- coupure d’eau ;
- tempête ;
- canicule ;
- panique ;
- problème avec les animaux ;
- besoin de jardiner ;
- besoin de conserver de la nourriture ;
- besoin de s’organiser sans Internet.

---

## Le plus simple

Si tu es perdu, commence par les checklists.

Dossier :

checklists/

Elles sont faites pour agir vite, sans lire toute la base.

---

## Si tu veux comprendre doucement

Commence par les fiches humaines.

Dossier :

fiches_humaines/

Elles expliquent les sujets avec des mots simples.

---

## Si tu veux utiliser une IA

Utilise :

20_BLOCK_LLM_AUTONOMIE_MAXIMALE_FR.md

Puis donne à l’IA :

- l’index data ;
- les fichiers JSON utiles ;
- ta situation concrète.

Exemple :

“J’ai une coupure de courant ce soir, deux poules et un coq, je suis fatigué. Fais-moi une checklist simple.”

---

## Carte rapide

### 💡 Plus de courant

Va vers :

- CHECKLIST_COUPURE_COURANT_SOIR.md
- fiche coupure électrique
- fiche nuit / éclairage

### 💧 Plus d’eau

Va vers :

- CHECKLIST_EAU_HYGIENE.md
- fiche coupure d’eau
- fiche hygiène / toilettes

### 🐔 Animaux / poules

Va vers :

- CHECKLIST_ANIMAUX_POULES_CHATS_CHIENS.md
- fiche protéger les animaux
- fiche basse-cour

### 🌱 Jardin débutant

Va vers :

- CHECKLIST_JARDIN_DEBUTANT.md
- fiche jardin grand débutant
- fiche semis / saisons

### 😰 Peur / panique / rumeurs

Va vers :

- CHECKLIST_CALME_PANIQUE_RUMEURS.md
- fiche éviter la panique
- fiche communication hors ligne

---

## Ce qu’il ne faut pas faire

Ne commence pas par les JSON si tu veux lire humainement.

Ne cherche pas à tout lire d’un coup.

Ne prépare pas dans la peur.

Ne transforme pas l’autonomie en obsession.

---

## Formule courte

README = présentation.

Portail humain = point de départ simple.

Fiches humaines = explications lisibles.

Checklists = actions rapides.

JSON = base machine pour IA.

Block LLM = comportement de l’IA.

---

## Phrase clé

On ne prépare pas la fin du monde.

On protège la vie quotidienne.