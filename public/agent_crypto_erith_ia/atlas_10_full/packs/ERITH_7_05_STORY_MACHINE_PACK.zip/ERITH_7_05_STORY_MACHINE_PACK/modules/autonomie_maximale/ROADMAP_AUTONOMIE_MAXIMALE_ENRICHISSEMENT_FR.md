# 🧭 ROADMAP — ENRICHISSEMENT AUTONOMIE MAXIMALE

## 🌍 Objectif

Cette roadmap sert à planifier l’enrichissement du module Autonomie Maximale sans repartir dans une production confuse.

Le but n’est pas d’ajouter des fichiers au hasard.

Le but est d’identifier les vrais manques utiles après les premiers tests locaux avec AnythingLLM / LM Studio.

---

# ✅ État actuel validé

Le module dispose déjà de :

- portail humain Notion ;
- bases JSON ;
- fiches A4 imprimables ;
- prompts d’usage pour IA locale ;
- pack local ZIP ;
- test fonctionnel dans AnythingLLM ;
- réponses utiles sur eau, évacuation, communication, jardin, alerte nucléaire, guerre / troubles civils.

Le système doit être compris comme :

- bibliothèque documentaire locale ;
- aide à la consultation ;
- relais cognitif de crise ;
- support de calme, sécurité et information.

Il ne doit pas être vendu comme un “Jarvis” autonome ou omniscient.

---

# 🧩 Priorité 1 — Sac 48h / 72h

## Besoin

Créer une base claire pour préparer un sac réaliste de départ rapide.

## Contenus à produire plus tard

- sac 24h ;
- sac 48h ;
- sac 72h ;
- sac pour personne seule ;
- sac avec animal ;
- sac hiver / froid ;
- sac été / chaleur ;
- sac évacuation à pied ;
- sac évacuation voiture.

## Questions LLM à viser

- Je dois quitter la maison maintenant, que prendre ?
- Prépare-moi un sac 48h à pied.
- Que prendre si j’ai un chien / chat ?
- Que prendre si je dois dormir dehors une nuit ?

---

# 🗺️ Priorité 2 — Cartes, orientation, territoire

## Besoin

Le module manque encore de supports d’orientation concrets.

## Contenus à produire plus tard

- cartes papier à posséder ;
- carte locale ;
- carte départementale ;
- carte routière ;
- carte IGN / randonnée ;
- points d’eau ;
- routes secondaires ;
- forêts ;
- lieux de repli possibles ;
- itinéraires vers proches ;
- points de rendez-vous familiaux.

## Garde-fou

Ne pas publier d’informations personnelles, de cachettes privées ou d’itinéraires sensibles.

---

# 🩹 Priorité 3 — Premiers secours / blessures

## Besoin

Renforcer les fiches de premiers secours et la trousse d’urgence.

## Contenus à produire plus tard

- trousse de premiers secours familiale ;
- saignement ;
- brûlure ;
- chute ;
- fracture suspecte ;
- hypothermie ;
- déshydratation ;
- malaise ;
- médicament essentiel ;
- personnes fragiles.

## Garde-fou

Ne jamais remplacer les secours, un médecin ou une formation officielle.

---

# 🔥 Priorité 4 — Chaleur, feu, froid, abri

## Besoin

Renforcer les scénarios où il faut rester au chaud, se protéger du froid ou produire une chaleur minimale.

## Contenus à produire plus tard

- se réchauffer sans électricité ;
- éviter l’intoxication au monoxyde ;
- dormir au froid ;
- feu extérieur prudent ;
- abri temporaire ;
- pluie / humidité ;
- vêtements par couches ;
- couverture de survie ;
- poncho / bâche.

## Garde-fou

Priorité à la sécurité incendie, à la ventilation et à l’évitement des comportements dangereux.

---

# 🌿 Priorité 5 — Plantes, champignons, nourriture sauvage

## Besoin

Sujet très utile mais très sensible.

## Contenus à produire plus tard

- plantes comestibles communes ;
- plantes toxiques communes ;
- confusion dangereuse ;
- champignons : prudence maximale ;
- ressources fiables ;
- guides papier ;
- formation terrain ;
- photos uniquement comme support, jamais comme preuve.

## Garde-fou majeur

Ne jamais identifier une plante ou un champignon uniquement avec une IA.

Ne jamais conseiller de consommer une plante ou un champignon sans certitude indépendante.

---

# 🛡️ Priorité 6 — Sécurité, discrétion, repli

## Besoin

Répondre aux scénarios de peur, troubles civils, pillage, agression, sans basculer dans la paranoïa ou la violence.

## Contenus à produire plus tard

- éviter les zones dangereuses ;
- discrétion ;
- bruit / lumière ;
- rester invisible ;
- rejoindre un lieu sûr ;
- point de rendez-vous ;
- voisinage fiable ;
- documents ;
- communication courte ;
- ne pas provoquer ;
- partir plutôt que confronter.

## Garde-fou

Le module doit rester défensif, civil, prudent et non violent.

---

# 📻 Priorité 7 — Communication de crise

## Besoin

Améliorer les réponses quand téléphone, Internet ou radio ne fonctionnent plus.

## Contenus à produire plus tard

- messages papier ;
- panneau d’urgence ;
- carnet de contacts ;
- codes familiaux simples ;
- points de rendez-vous ;
- horaires fixes ;
- voisins ;
- relais humains ;
- quoi écrire sur une feuille en cas de départ.

---

# 🧠 Priorité 8 — Prompts et tests utilisateur

## Besoin

Continuer à tester le système avec des questions réalistes.

## Tests utiles

- Je dois quitter la maison maintenant.
- Je n’ai plus d’eau.
- Je dois rassurer quelqu’un.
- Je suis seul sans téléphone.
- Je dois dormir dehors.
- Je dois protéger mes animaux.
- J’entends des rumeurs de danger.
- J’ai une coupure de courant longue.
- Je dois préparer un sac 72h.

---

# 🚫 À ne pas faire

- Ajouter des fichiers sans usage clair.
- Multiplier les index inutiles.
- Créer une nouvelle architecture à chaque doute.
- Promettre une IA autonome parfaite.
- Remplacer les secours ou les sources officielles.
- Publier des conseils dangereux sur plantes, champignons, armes ou confrontation.

---

# 🌸 Règle centrale

On enrichit uniquement à partir de besoins réels testés.

Chaque nouvelle brique doit aider à :

- rassurer ;
- sécuriser ;
- informer ;
- orienter ;
- prioriser ;
- réduire la panique.
