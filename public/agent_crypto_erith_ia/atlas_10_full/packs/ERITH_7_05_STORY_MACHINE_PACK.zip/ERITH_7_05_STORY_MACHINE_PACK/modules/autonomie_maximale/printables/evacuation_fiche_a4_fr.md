# 🎒 Évacuation — Fiche A4 réflexe

## 🎯 Priorité

Quitter la zone rapidement, calmement et avec l’essentiel.

---

# ✅ À faire maintenant

- Suivre les consignes fiables.
- Préparer les personnes et animaux.
- Prendre papiers importants.
- Prévoir eau, téléphone et chargeurs.
- Couper gaz ou électricité si nécessaire et possible.
- Fermer le logement.
- Utiliser un itinéraire simple.
- Prévenir un proche.
- Garder le calme du groupe.

---

# ⚠️ À ne pas faire

- Perdre du temps sur des objets secondaires.
- Surcharger les sacs.
- Ignorer les consignes locales.
- Se séparer inutilement.
- Retourner dans une zone dangereuse.

---

# 🧰 Matériel utile

- Sac prêt.
- Eau.
- Papiers.
- Téléphone.
- Lampe.
- Médicaments.
- Nourriture simple.
- Affaires chaudes.

---

# 🧭 Après stabilisation

- Vérifier toutes les personnes.
- Réorganiser le matériel.
- Préserver les batteries.
- Noter les informations utiles.

---

# 🌸 Règle centrale

Une évacuation efficace repose sur simplicité, calme et rapidité.
