# 💡 Coupure de courant — Fiche A4 réflexe

## 🎯 Priorité

Garder la lumière, la communication, l’eau, le froid alimentaire et le calme du foyer.

---

# ✅ À faire maintenant

- Rester calme.
- Vérifier si la coupure est locale ou générale.
- Couper les appareils sensibles.
- Garder le réfrigérateur et le congélateur fermés.
- Préparer lampes, piles, batteries et radio.
- Économiser immédiatement les téléphones.
- Garder une source de lumière accessible.
- Vérifier les personnes fragiles.
- Faire entrer les animaux si nécessaire.
- Préserver l’eau disponible.
- Éviter les déplacements inutiles.
- Suivre les informations fiables si disponibles.

---

# ⚠️ À ne pas faire

- Ouvrir sans arrêt le frigo ou le congélateur.
- Utiliser barbecue, brasero ou groupe électrogène à l’intérieur.
- Multiplier les bougies sans surveillance.
- Vider les batteries avec vidéos ou réseaux sociaux.
- Surcharger les multiprises au retour du courant.
- Paniquer ou relayer des rumeurs.

---

# 🧰 Matériel utile

- Lampes LED.
- Lampe frontale.
- Piles.
- Batteries externes.
- Radio à piles ou dynamo.
- Chargeurs.
- Eau potable.
- Couvertures.
- Ouvre-boîte manuel.
- Nourriture simple.
- Téléphone chargé.

---

# 🧭 Après stabilisation

- Organiser une pièce principale.
- Planifier l’usage des batteries.
- Consommer d’abord les aliments fragiles si la coupure dure.
- Noter les informations utiles.
- Préparer une solution pour la nuit.
- Vérifier voisins ou proches fragiles si possible.

---

# 🌸 Règle centrale

En coupure de courant, on protège d’abord la lumière, la communication, le froid alimentaire et le calme.
