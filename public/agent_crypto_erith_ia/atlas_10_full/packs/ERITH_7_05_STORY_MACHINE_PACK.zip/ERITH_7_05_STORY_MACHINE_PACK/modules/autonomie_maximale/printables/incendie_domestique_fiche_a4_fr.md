# 🔥 Incendie domestique — Fiche A4 réflexe

## 🎯 Priorité

Faire sortir les personnes et animaux rapidement et éviter l’intoxication par les fumées.

---

# ✅ À faire maintenant

- Donner l’alerte immédiatement.
- Faire évacuer les personnes.
- Faire sortir les animaux si possible sans danger.
- Rester proche du sol en présence de fumée.
- Fermer les portes derrière soi si possible.
- Appeler les secours.
- Couper gaz ou électricité seulement si sûr.
- Rejoindre un point extérieur sécurisé.
- Vérifier les personnes fragiles.

---

# ⚠️ À ne pas faire

- Retourner chercher des objets.
- Ouvrir une porte très chaude.
- Utiliser un ascenseur.
- Respirer les fumées inutilement.
- Revenir dans le bâtiment sans autorisation.

---

# 🧰 Matériel utile

- Détecteurs de fumée.
- Extincteur.
- Lampe.
- Téléphone.
- Couverture.
- Plan d’évacuation simple.

---

# 🧭 Après stabilisation

- Vérifier toutes les personnes.
- Prévoir relogement temporaire si nécessaire.
- Noter les informations utiles.
- Sécuriser les animaux.

---

# 🌸 Règle centrale

Dans un incendie, la fumée tue souvent avant les flammes.
