# 🎨 MEMORY CARDS — DA DESSINS ANIMÉS VIVANTS

Statut : module de cartes mémoire  
Type : deck de direction artistique / animation / image / storyboard  
Mode recommandé : Direction artistique animée / Production image / Production vidéo / Seven Heaven  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / prompts image / prompts animation / style locks / personnages / décors / scènes animées / univers originaux / headers Notion / mascottes / storyboard

🖼️ Visuels associés :

- Aucun visuel associé validé pour l’instant.
- À produire plus tard si besoin :
  - cover premium du deck DA Dessins Animés Vivants ;
  - planche des 10 cartes visuelles ;
  - fiche mascotte / header Notion animé ;
  - dossier visuel “Atelier du Dessin Animé Vivant”.

---

# 1. 🎨 Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour charger rapidement une direction artistique animée claire, expressive, originale et exploitable.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire DA est une influence compacte, contrôlée, activable.

Elle sert à charger :

- une grammaire visuelle ;
- une silhouette ;
- une palette émotionnelle ;
- une logique de décor ;
- une intention de mouvement ;
- une qualité de ligne ;
- une lumière animée ;
- une mascotte ou compagnon ;
- une image finale lisible ;
- un garde-fou contre la copie et la surcharge.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire DA = direction visuelle rapide.  
Deck = combinaison de principes animés.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

Le but n’est pas de copier des dessins animés existants.

Le but est d’extraire une grammaire visuelle utile : formes, couleurs, lisibilité, silhouettes, émotion, rythme, mise en scène, exagération contrôlée, décor narratif et mouvement clair.

Formule du deck :

Silhouette + couleur + mouvement = DA lisible.

---

# 2. 🧭 Règle DA Dessins Animés Vivants

Ces cartes sont prévues pour créer des scènes, personnages, headers, prompts image, prompts animation, mascottes et storyboards dans une direction artistique animée originale.

Elles ne doivent pas copier un studio, une œuvre, un personnage ou un design reconnaissable.

Interdit :

- copier un studio précis ;
- copier un personnage reconnaissable ;
- reprendre des designs, scènes, costumes ou palettes exactes ;
- imiter une œuvre au point d’être reconnaissable ;
- demander “dans le style exact de” une œuvre protégée ;
- surcharger l’image ;
- rendre l’animation illisible ;
- mélanger trop de styles contradictoires ;
- faire un style “dessin animé” générique sans direction ;
- casser la cohérence entre image et animation.

Autorisé :

- créer des styles originaux ;
- penser lisibilité avant détail ;
- privilégier les formes fortes ;
- garder les personnages reconnaissables par leur silhouette ;
- rendre les décors narratifs ;
- préparer des prompts image / animation exploitables ;
- adapter la complexité au moteur utilisé ;
- séparer inspiration, style, technique et copie ;
- utiliser des principes généraux : silhouette, couleur, ligne, lumière, mouvement, émotion.

Règle simple :

Inspirer sans copier.  
Styliser sans imiter.  
Créer une animation originale et lisible.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en direction artistique originale ;
- ne pas charger les modules complets si la carte suffit ;
- ne pas copier un studio ou un personnage existant ;
- utiliser le deck comme filtre de lisibilité animée ;
- choisir uniquement les cartes utiles à la demande ;
- préserver la cohérence entre image, animation et storyboard ;
- si la demande implique vidéo, combiner avec `modules/memory_cards_video_vivante_fr.md` ;
- produire des prompts exploitables directement ;
- distinguer inspiration, style, technique, contrainte de production et sortie créative.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire donne la direction visuelle.  
Le Deck compose le style animé.  
Vidéo Vivante met en mouvement si nécessaire.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Silhouette Iconique ;
- Palette Émotionnelle ;
- Décor-Personnage ;
- Mouvement Clair ;
- Exagération Douce ;
- Ligne Claire ;
- Lumière de Studio Animé ;
- Animal Compagnon ;
- Monde Jouet ;
- Final Tableau.

Ou combinée en deck :

- Deck Mascotte du Core ;
- Deck Conte Animé ;
- Deck Header Notion Animé ;
- Deck Animation Wan Stable ;
- Deck DA Onirique ;
- Deck DA Dessins Animés Vivants complet.

Activation courte :

Charge la Carte Mémoire Silhouette Iconique.

Activation combinée :

Charge les cartes Silhouette Iconique, Animal Compagnon et Lumière de Studio Animé pour créer une mascotte originale premium.

Activation production :

Charge le Deck DA Dessins Animés Vivants et produis un Pack+ complet : concept visuel, personnage, décor, prompt image, prompt animation, négatif, garde-fous et note storyboard.

Sortie Pack+ recommandée :

- concept visuel ;
- personnage ou mascotte ;
- silhouette ;
- palette émotionnelle ;
- décor ;
- prompt image ;
- prompt animation Wan / I2V si nécessaire ;
- négatif production ;
- note de lisibilité ;
- note de continuité si la scène devient une séquence vidéo.

Règle image :

Le module peut produire des prompts image, prompts animation, storyboards, headers et mascottes, mais ne doit pas générer d’image automatiquement sauf demande explicite de l’utilisateur.

---

# 4. 🗂️ Modules sources recommandés

## Modules principaux

- modules/erith_ia_histoire_de_l_art_mondiale_master_fr.md
- modules/erith_ia_psychologie_discernement_fr.md
- modules/erith_ia_philosophie_verite_liberte_fr.md
- modules/memory_cards_contes_de_fee_vivants_fr.md
- modules/memory_cards_mythologie_vivante_fr.md

## Modules compatibles selon la demande

- Alice / merveilleux / absurde doux ;
- Oz / route / couleur / monde étrange ;
- NeverEnding Story / imagination / créature / livre vivant ;
- Cyberpunk Noir Trio si dessin animé cyberpunk ;
- Altered Carbon si animation cyberpunk premium ;
- Aerith-8 Solaire si tableau lumineux ;
- Aerith-9 Lunaire si rêve / nuit / reflet ;
- Vidéo Vivante si animation, storyboard, Wan / I2V ou séquence demandée ;
- Math Oracle si rythme, proportions, trajectoire ou structure visuelle sont importants.

Garde-fou :

Ne pas charger ces modules automatiquement.

Les modules sources servent de profondeur.

Les cartes DA servent de direction artistique rapide.

---

# 5. 🖼️ Galerie visuelle — Deck DA Dessins Animés Vivants

Aucun visuel validé pour l’instant.

Cette section est réservée à une future galerie du deck.

Elle pourra documenter :

- une cover premium du deck ;
- une planche des 10 cartes ;
- un exemple de mascotte originale ;
- un header Notion animé ;
- un décor-personnage ;
- un dossier visuel “Atelier du Dessin Animé Vivant”.

## 1. Cover Pack+ Premium

À ajouter plus tard.

Fonction prévue :

Présenter le deck comme un outil de direction artistique : silhouette, couleur, mouvement, décor, lumière, ligne claire et émotion.

## 2. Memory Card Pack Cover

À ajouter plus tard.

Fonction prévue :

Présenter rapidement les 10 cartes principales, les tirages recommandés et les commandes utilisables.

## 3. Atelier du Dessin Animé Vivant

À ajouter plus tard.

Fonction prévue :

Montrer un exemple d’univers animé original : personnage lisible, décor vivant, palette émotionnelle, compagnon animal et final tableau.

---

# 6. 🧍 Carte Mémoire — Silhouette Iconique

## Fonction principale

Créer un personnage reconnaissable même en ombre.

Cette carte charge :

- silhouette ;
- forme simple ;
- identité visuelle ;
- contraste ;
- posture ;
- icône ;
- lisibilité ;
- design clair ;
- mémorisation immédiate.

## Température émotionnelle

Clarté.  
Impact.  
Présence.  
Identité forte.  
Reconnaissance immédiate.

## Textures visuelles

- grandes formes lisibles ;
- posture nette ;
- costume simple mais mémorable ;
- accessoires limités ;
- proportions expressives ;
- contraste clair ;
- silhouette stable.

## Thèmes actifs

- design de personnage ;
- identité visuelle ;
- mascotte ;
- logo vivant ;
- vignette ;
- storyboard ;
- animation-ready.

## Question utile

Reconnaît-on le personnage même sans détails ?

## Usage narratif

Utiliser cette carte pour :

- créer un personnage principal ;
- créer une mascotte ;
- renforcer une identité de héros ;
- rendre une silhouette mémorable ;
- préparer une vignette ou une bannière.

## Usage production image

La carte aide à produire :

- character sheets ;
- mascottes ;
- poses fortes ;
- silhouettes propres ;
- designs lisibles ;
- personnages compatibles animation.

## Garde-fous

Ne pas copier une silhouette célèbre.

Ne pas empiler trop d’accessoires.

Si la silhouette ne fonctionne pas en ombre, le design n’est pas encore assez clair.

## Prompt fragment

```text
iconic animated character silhouette, clear shape language, readable full body design, strong pose, simple but memorable costume, expressive proportions, clean animation-ready design
```

## Activation courte

Charge la Carte Mémoire Silhouette Iconique : forme forte, posture claire, personnage reconnaissable même en ombre.

---

# 7. 🎨 Carte Mémoire — Palette Émotionnelle

## Fonction principale

Faire porter l’état intérieur de la scène par la couleur.

Cette carte charge :

- couleur ;
- émotion ;
- harmonie ;
- contraste ;
- chaleur ;
- froid ;
- humeur ;
- lumière ;
- lisibilité ;
- atmosphère.

## Température émotionnelle

Variable selon la scène.

La couleur peut annoncer :

- joie ;
- peur ;
- douceur ;
- mystère ;
- aventure ;
- mélancolie ;
- émerveillement ;
- danger.

## Textures visuelles

- aplats expressifs ;
- contraste chaud / froid ;
- lumière lisible ;
- harmonie simple ;
- palette limitée ;
- couleur narrative ;
- ambiance claire.

## Thèmes actifs

- émotion visuelle ;
- moodboard ;
- scène lisible ;
- ambiance animée ;
- direction artistique ;
- continuité de séquence.

## Question utile

Quelle émotion la couleur doit-elle annoncer ?

## Usage narratif

Utiliser cette carte pour :

- orienter l’émotion avant le texte ;
- distinguer deux lieux ;
- marquer un changement intérieur ;
- créer une progression de scène ;
- renforcer un conte ou un rêve.

## Usage production image

La carte aide à produire :

- palettes de scène ;
- ambiances couleur ;
- headers ;
- storyboards ;
- images cohérentes ;
- séquences avec continuité chromatique.

## Garde-fous

Ne pas multiplier les couleurs sans hiérarchie.

La palette doit servir l’émotion, pas décorer au hasard.

## Prompt fragment

```text
expressive animated color palette, clear emotional lighting, harmonious shapes, warm and cool contrast, readable mood, stylized but elegant visual direction
```

## Activation courte

Charge la Carte Mémoire Palette Émotionnelle : couleur narrative, émotion lisible, contraste clair, harmonie animée.

---

# 8. 🏠 Carte Mémoire — Décor-Personnage

## Fonction principale

Créer un décor qui n’est pas un fond, mais une présence narrative.

Cette carte charge :

- décor ;
- monde ;
- architecture ;
- maison ;
- ville ;
- forêt ;
- mémoire ;
- lieu vivant ;
- narration visuelle ;
- personnalité du décor.

## Température émotionnelle

Immersion.  
Curiosité.  
Présence du monde.  
Mystère doux.  
Lieu qui semble regarder.

## Textures visuelles

- architecture expressive ;
- maison penchée ;
- ruelle stylisée ;
- forêt douce ;
- détails de conte ;
- objets parlants ;
- profondeur lisible ;
- décor mémorable.

## Thèmes actifs

- monde vivant ;
- décor narratif ;
- environnement-personnage ;
- lieu qui protège ;
- lieu qui ment ;
- mémoire du décor ;
- immersion.

## Question utile

Que sait le décor que le personnage ignore ?

## Usage narratif

Utiliser cette carte pour :

- maison magique ;
- ville étrange ;
- forêt initiatique ;
- chambre intérieure ;
- atelier vivant ;
- lieu protecteur ou inquiétant.

## Usage production image

La carte aide à produire :

- backgrounds animés ;
- décors de storyboard ;
- lieux iconiques ;
- mondes de conte ;
- headers Notion ;
- images où le décor raconte.

## Garde-fous

Ne pas traiter le décor comme une simple texture de fond.

Un décor-personnage doit avoir une intention claire.

## Prompt fragment

```text
animated environment as a character, expressive architecture, storybook details, readable depth, stylized shapes, strong atmosphere, environment tells the story
```

## Activation courte

Charge la Carte Mémoire Décor-Personnage : lieu vivant, architecture expressive, décor qui raconte l’histoire.

---

# 9. 🌀 Carte Mémoire — Mouvement Clair

## Fonction principale

Créer une animation lisible plutôt qu’une animation complexe.

Cette carte charge :

- mouvement ;
- rythme ;
- geste ;
- lisibilité ;
- boucle ;
- respiration ;
- pose ;
- anticipation ;
- simplicité ;
- animation contrôlée.

## Température émotionnelle

Fluidité.  
Clarté.  
Confiance.  
Rythme simple.  
Action lisible.

## Textures visuelles

- geste unique ;
- pose claire ;
- anticipation légère ;
- boucle douce ;
- mouvement secondaire subtil ;
- caméra stable ;
- animation propre.

## Thèmes actifs

- Wan / I2V ;
- storyboard ;
- prompt animation ;
- boucle courte ;
- mouvement de personnage ;
- lisibilité du geste.

## Question utile

Quel est le seul mouvement vraiment nécessaire ?

## Usage narratif

Utiliser cette carte pour :

- geste expressif ;
- respiration ;
- regard ;
- main qui se lève ;
- personnage qui avance doucement ;
- décor qui bouge peu mais juste.

## Usage production animation

La carte aide à produire :

- prompts Wan sobres ;
- animations I2V stables ;
- mouvements simples ;
- storyboards lisibles ;
- transitions propres.

## Garde-fous

Ne pas demander plusieurs actions simultanées.

Un mouvement clair vaut mieux qu’une chorégraphie confuse.

## Prompt fragment

```text
clear simple animation movement, readable gesture, slow controlled motion, expressive pose change, subtle secondary motion, animation-ready composition, no chaotic movement
```

## Activation courte

Charge la Carte Mémoire Mouvement Clair : un geste lisible, un rythme simple, aucune animation chaotique.

---

# 10. 🙂 Carte Mémoire — Exagération Douce

## Fonction principale

Amplifier une émotion sans rendre la scène ridicule.

Cette carte charge :

- exagération ;
- expression ;
- émotion ;
- douceur ;
- timing ;
- regard ;
- mains ;
- posture ;
- comédie légère ;
- stylisation expressive.

## Température émotionnelle

Tendresse.  
Humour léger.  
Émotion amplifiée.  
Poésie.  
Expressivité élégante.

## Textures visuelles

- yeux expressifs ;
- posture arrondie ;
- mains lisibles ;
- micro-comédie ;
- proportions stylisées ;
- expression douce ;
- timing visible.

## Thèmes actifs

- émotion ;
- personnage attachant ;
- scène poétique ;
- comédie légère ;
- douceur visuelle ;
- expressivité animée.

## Question utile

Quelle émotion doit être amplifiée sans casser la scène ?

## Usage narratif

Utiliser cette carte pour :

- personnage attachant ;
- scène de conte ;
- émotion douce ;
- réaction expressive ;
- moment drôle mais élégant ;
- regard ou posture significative.

## Usage production image

La carte aide à produire :

- expressions de personnage ;
- portraits animés ;
- scènes poétiques ;
- mascottes ;
- moments d’émotion lisible.

## Garde-fous

Ne pas exagérer jusqu’à la caricature involontaire.

L’exagération doit servir l’émotion, pas la remplacer.

## Prompt fragment

```text
soft expressive animation style, gentle exaggeration, emotional eyes, readable facial expression, elegant stylized proportions, poetic cartoon realism
```

## Activation courte

Charge la Carte Mémoire Exagération Douce : émotion amplifiée, expression élégante, comédie légère, aucune caricature inutile.

---

# 11. ✒️ Carte Mémoire — Ligne Claire

## Fonction principale

Créer une image propre, lisible, structurée par les contours et les formes nettes.

Cette carte charge :

- contour ;
- ligne ;
- clarté ;
- propreté ;
- aplats ;
- hiérarchie ;
- lisibilité ;
- composition ;
- simplicité ;
- élégance graphique.

## Température émotionnelle

Calme visuel.  
Propreté.  
Équilibre.  
Lisibilité.  
Confiance graphique.

## Textures visuelles

- contours nets ;
- formes propres ;
- aplats contrôlés ;
- détails limités ;
- composition claire ;
- hiérarchie visuelle ;
- absence de clutter.

## Thèmes actifs

- header Notion ;
- carte visuelle ;
- affiche ;
- storyboard ;
- image lisible ;
- direction artistique propre.

## Question utile

Qu’est-ce qui peut être retiré pour rendre l’image plus forte ?

## Usage narratif

Utiliser cette carte pour :

- clarifier une scène ;
- rendre un concept lisible ;
- produire une image Notion-friendly ;
- créer un style propre ;
- éviter le bruit visuel.

## Usage production image

La carte aide à produire :

- headers ;
- bannières ;
- affiches ;
- cartes mémoire ;
- illustrations propres ;
- images premium simples.

## Garde-fous

Ne pas confondre simplicité avec pauvreté.

La ligne claire doit retirer le bruit pour rendre le sens visible.

## Prompt fragment

```text
clean line animated visual style, elegant contours, readable composition, clear shapes, refined flat-color structure, polished storyboard illustration, no clutter
```

## Activation courte

Charge la Carte Mémoire Ligne Claire : contours propres, composition lisible, formes nettes, aucun bruit inutile.

---

# 12. 💡 Carte Mémoire — Lumière de Studio Animé

## Fonction principale

Guider le regard et donner une qualité premium sans perdre le style animé.

Cette carte charge :

- lumière ;
- glow ;
- rim light ;
- profondeur ;
- contraste ;
- studio ;
- douceur ;
- focus ;
- volume ;
- direction du regard.

## Température émotionnelle

Premium.  
Douceur cinématique.  
Focus clair.  
Profondeur animée.  
Élégance lumineuse.

## Textures visuelles

- rim light doux ;
- glow contrôlé ;
- profondeur légère ;
- lumière volumétrique subtile ;
- point focal clair ;
- ombres propres ;
- contraste lisible.

## Thèmes actifs

- image premium ;
- plan final ;
- spotlight émotionnel ;
- sujet lisible ;
- production vidéo ;
- frame animée.

## Question utile

Où doit aller l’œil en premier ?

## Usage narratif

Utiliser cette carte pour :

- révéler un personnage ;
- isoler une émotion ;
- guider le regard ;
- donner une finition premium ;
- renforcer une scène clé.

## Usage production image

La carte aide à produire :

- frames premium ;
- portraits animés ;
- affiches ;
- scènes lumineuses ;
- images adaptées à la vidéo.

## Garde-fous

Ne pas surcharger en glow.

La lumière doit guider, pas aveugler.

## Prompt fragment

```text
premium animated studio lighting, soft rim light, cinematic glow, readable focal point, gentle volumetric depth, polished animation frame, elegant light design
```

## Activation courte

Charge la Carte Mémoire Lumière de Studio Animé : lumière premium, focus clair, glow contrôlé, profondeur douce.

---

# 13. 🐾 Carte Mémoire — Animal Compagnon

## Fonction principale

Créer un animal animé qui porte l’âme du monde : guide, miroir, humour, instinct.

Cette carte charge :

- animal ;
- compagnon ;
- chat ;
- renard ;
- oiseau ;
- guide ;
- instinct ;
- douceur ;
- caractère ;
- présence émotionnelle.

## Température émotionnelle

Attachement.  
Instinct.  
Malice douce.  
Guidance.  
Présence rassurante.

## Textures visuelles

- silhouette animale simple ;
- yeux expressifs ;
- posture reconnaissable ;
- petite aura magique ;
- design lisible ;
- mouvement doux ;
- caractère immédiat.

## Thèmes actifs

- mascotte ;
- guide ;
- monde vivant ;
- instinct ;
- humour ;
- miroir du héros ;
- logo ou compagnon narratif.

## Question utile

L’animal révèle-t-il le monde, le personnage, ou le chemin ?

## Usage narratif

Utiliser cette carte pour :

- compagnon de héros ;
- guide silencieux ;
- animal totem original ;
- mascotte du projet ;
- présence drôle ou protectrice ;
- lien émotionnel entre monde et personnage.

## Usage production image

La carte aide à produire :

- mascottes ;
- compagnons animés ;
- logos vivants ;
- scènes de conte ;
- headers Notion ;
- personnages secondaires attachants.

## Garde-fous

Ne pas copier une mascotte célèbre.

L’animal doit avoir une fonction : guide, miroir, humour, instinct ou lien émotionnel.

## Prompt fragment

```text
animated animal companion, charming but intelligent, expressive silhouette, subtle magical aura, clear readable design, companion character, gentle emotional presence
```

## Activation courte

Charge la Carte Mémoire Animal Compagnon : animal guide, silhouette expressive, instinct, douceur, caractère mémorable.

---

# 14. 🧸 Carte Mémoire — Monde Jouet

## Fonction principale

Créer un monde animé miniature, tactile, presque fabriqué à la main.

Cette carte charge :

- miniature ;
- jouet ;
- maquette ;
- matière ;
- texture ;
- charme ;
- fabrication ;
- détails ;
- profondeur douce ;
- monde habité.

## Température émotionnelle

Charme.  
Confort.  
Émerveillement tactile.  
Nostalgie douce.  
Monde fabriqué avec soin.

## Textures visuelles

- maquettes ;
- bois peint ;
- papier ;
- tissu ;
- petits objets ;
- profondeur miniature ;
- détails chaleureux ;
- matière visible.

## Thèmes actifs

- monde miniature ;
- décor attachant ;
- conte tactile ;
- fabrication ;
- Notion header ;
- court métrage doux ;
- environnement habité.

## Question utile

Le monde semble-t-il habité ou seulement décoré ?

## Usage narratif

Utiliser cette carte pour :

- village miniature ;
- atelier magique ;
- chambre de mémoire ;
- monde de jouets ;
- décor intime ;
- scène poétique et tactile.

## Usage production image

La carte aide à produire :

- décors miniatures ;
- images chaleureuses ;
- headers ;
- bannières ;
- univers animés doux ;
- scènes tactiles et attachantes.

## Garde-fous

Ne pas remplir le décor de détails inutiles.

Un monde jouet doit rester lisible, pas devenir un bazar.

## Prompt fragment

```text
miniature animated world, handcrafted toy-like environment, tactile textures, cozy depth, charming stylized details, soft cinematic composition, magical but grounded
```

## Activation courte

Charge la Carte Mémoire Monde Jouet : miniature tactile, décor habité, charme, matière, profondeur douce.

---

# 15. 🖼️ Carte Mémoire — Final Tableau

## Fonction principale

Penser une scène animée comme une image finale très lisible, presque une affiche.

Cette carte charge :

- tableau ;
- affiche ;
- composition ;
- final ;
- émotion ;
- lisibilité ;
- icône ;
- mémoire ;
- image forte ;
- frame finale.

## Température émotionnelle

Impact.  
Clarté finale.  
Mémoire visuelle.  
Émotion posée.  
Résonance.

## Textures visuelles

- composition poster ;
- sujet central clair ;
- décor simplifié ;
- lumière finale ;
- image iconique ;
- hiérarchie forte ;
- fin mémorable.

## Thèmes actifs

- image finale ;
- vignette ;
- bannière ;
- thumbnail ;
- header Notion ;
- dernière image ;
- frame de clôture.

## Question utile

Quelle image doit rester en mémoire après la scène ?

## Usage narratif

Utiliser cette carte pour :

- fin de scène ;
- image YouTube ;
- affiche de module ;
- bannière Notion ;
- plan final de storyboard ;
- moment de clôture émotionnelle.

## Usage production image

La carte aide à produire :

- posters animés ;
- thumbnails ;
- headers ;
- final frames ;
- images de clôture ;
- scènes iconiques.

## Garde-fous

Ne pas finir sur une image confuse.

Le Final Tableau doit résumer l’émotion et rester lisible.

## Prompt fragment

```text
final animated tableau, poster-like composition, strong visual memory, clear emotional focal point, iconic character placement, cinematic but clean, polished animation still
```

## Activation courte

Charge la Carte Mémoire Final Tableau : image finale lisible, composition affiche, émotion claire, mémoire visuelle.

---

# 16. 🎞️ Deck Mémoire — DA Dessins Animés Vivants

## Composition

Ce deck contient dix cartes principales :

- Silhouette Iconique ;
- Palette Émotionnelle ;
- Décor-Personnage ;
- Mouvement Clair ;
- Exagération Douce ;
- Ligne Claire ;
- Lumière de Studio Animé ;
- Animal Compagnon ;
- Monde Jouet ;
- Final Tableau.

## Fonction du deck

Créer une direction artistique animée originale, lisible, expressive et production-ready.

Silhouette Iconique donne :

- la forme ;
- l’identité ;
- la reconnaissance.

Palette Émotionnelle donne :

- l’humeur ;
- la couleur ;
- le cœur de la scène.

Décor-Personnage donne :

- le monde ;
- le lieu vivant ;
- la narration visuelle.

Mouvement Clair donne :

- la lisibilité ;
- le geste ;
- l’animation contrôlée.

Exagération Douce donne :

- l’expression ;
- la tendresse ;
- l’amplification émotionnelle.

Ligne Claire donne :

- la propreté ;
- la hiérarchie ;
- la composition lisible.

Lumière de Studio Animé donne :

- le focus ;
- le glow ;
- la finition premium.

Animal Compagnon donne :

- l’instinct ;
- la mascotte ;
- la présence attachante.

Monde Jouet donne :

- la miniature ;
- la matière ;
- le charme tactile.

Final Tableau donne :

- l’image forte ;
- la clôture ;
- la mémoire visuelle.

## Résultat attendu

Une direction artistique animée claire, originale et exploitable.

Le deck doit permettre de créer :

- personnages ;
- mascottes ;
- décors ;
- headers Notion ;
- prompts image ;
- prompts animation ;
- storyboards ;
- vignettes ;
- scènes de conte ;
- mini-univers animés.

## Thèmes combinés

- silhouette ;
- couleur ;
- décor ;
- mouvement ;
- émotion ;
- lumière ;
- ligne claire ;
- compagnon ;
- monde tactile ;
- final iconique.

## Question centrale du deck

Comment créer une image animée originale, lisible et mémorable sans copier un style existant ?

## Formule canonique du deck

Silhouette + Couleur + Mouvement.  
Décor + Émotion + Lumière.  
Ligne claire + Mascotte + Final Tableau.

---

# 17. 🏭 Univers original générable avec le deck

## Nom de travail

L’Atelier du Dessin Animé Vivant

L’Atelier du Dessin Animé Vivant est un nom de travail pour tester le Deck DA Dessins Animés Vivants.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres personnages, mascottes, décors ou univers selon la demande.

## Concept

L’Atelier du Dessin Animé Vivant est un espace créatif où chaque image devient lisible avant d’être détaillée.

On y commence par la silhouette.

Puis la couleur donne l’émotion.

Le décor devient un personnage.

Le mouvement reste simple.

La lumière guide l’œil.

La dernière image devient un tableau mémorable.

## Tension production

La tentation est de faire trop joli, trop détaillé, trop animé, trop influencé.

Le deck rappelle que la force d’un dessin animé vivant vient d’abord de la lisibilité.

Une silhouette claire vaut mieux qu’un design surchargé.

Un geste simple vaut mieux qu’une animation confuse.

Une palette expressive vaut mieux qu’une avalanche de couleurs.

## Ton

Clair.  
Poétique.  
Premium.  
Lisible.  
Original.  
Production-ready.  
Compatible image, animation, storyboard et Notion.

---

# 18. 🔀 Tirages recommandés

## Tirage 1 — Mascotte du Core

Cartes :

- Silhouette Iconique ;
- Animal Compagnon ;
- Lumière de Studio Animé.

Usage :

Créer une mascotte visuelle forte, comme un Chat GPT Memory Core, un gardien, un guide ou un animal de système.

Formule :

La silhouette reconnaît, l’animal accompagne, la lumière sacralise.

---

## Tirage 2 — Conte animé

Cartes :

- Palette Émotionnelle ;
- Décor-Personnage ;
- Exagération Douce.

Usage :

Créer une scène de conte en style animé, lisible et émotionnelle.

Formule :

La couleur donne le cœur, le décor parle, l’émotion s’ouvre doucement.

---

## Tirage 3 — Header Notion animé

Cartes :

- Ligne Claire ;
- Final Tableau ;
- Monde Jouet.

Usage :

Créer une bannière Notion propre, jolie, lisible et non surchargée.

Formule :

Moins de bruit, plus de mémoire visuelle.

---

## Tirage 4 — Animation Wan stable

Cartes :

- Mouvement Clair ;
- Silhouette Iconique ;
- Lumière de Studio Animé.

Usage :

Préparer un prompt animation stable avec un sujet lisible et peu de dérives.

Formule :

Un sujet clair, un mouvement simple, une lumière qui tient la scène.

---

## Tirage 5 — DA onirique

Cartes :

- Palette Émotionnelle ;
- Animal Compagnon ;
- Décor-Personnage.

Usage :

Créer une scène rêveuse, lunaire, douce, proche d’un monde intérieur animé.

Formule :

Le monde rêve, l’animal sait, la couleur murmure.

---

# 19. 📝 Mini prompts d’ambiance

## Prompt ambiance courte

```text
Original animated visual direction, clear iconic silhouette, expressive emotional color palette, readable shapes, clean line art, gentle studio lighting, charming environment design, subtle movement-ready composition, poetic but production-ready, no copied studio, no copied character, no recognizable franchise.
```

## Prompt personnage animé

```text
Original animated character design, iconic readable silhouette, expressive proportions, clear shape language, simple memorable outfit, gentle emotional face, clean line art, premium animated lighting, production-ready full body pose, no copied character, no recognizable studio style.
```

## Prompt décor-personnage

```text
Original animated environment as a character, expressive architecture, storybook details, readable depth, clean shapes, emotional color palette, charming lived-in world, stylized but coherent, environment tells the story, no copied background, no recognizable franchise.
```

## Prompt mascotte

```text
Original animated animal companion, charming but intelligent, expressive silhouette, clear readable design, subtle magical aura, gentle emotional presence, premium studio lighting, mascot-ready, logo-friendly, no copied mascot, no recognizable franchise.
```

## Prompt animation Wan / I2V

```text
Subtle animated-style motion. Keep the original character silhouette stable and readable. Add only one clear movement: gentle breathing, small head turn, soft hand gesture, light pulse or subtle companion movement. Camera nearly locked. Preserve clean lines, colors, face, outfit and composition. No chaotic motion. End on a clean final animated tableau.
```

---

# 20. 🚫 Négatif production

Éviter :

- copie de studio ;
- personnage reconnaissable ;
- palette exacte d’une œuvre connue ;
- costume reconnaissable ;
- scène copiée ;
- logo existant ;
- franchise identifiable ;
- style trop générique ;
- silhouette confuse ;
- couleurs sans hiérarchie ;
- décor surchargé ;
- animation illisible ;
- mouvement chaotique ;
- expressions cassées ;
- mains déformées ;
- texte illisible ;
- ligne sale ;
- surcharge de détails ;
- incohérence entre image et animation.

Negative prompt court :

```text
copied studio style, copied character, recognizable franchise, exact costume, exact color palette, logo, generic cartoon clutter, unreadable silhouette, messy line art, chaotic movement, bad anatomy, distorted face, broken hands, excessive details, poor composition, inconsistent animation style
```

---

# 21. 🧬 Formules de combinaison

## Silhouette Iconique seule

Forme + posture + identité immédiate.

## Palette Émotionnelle seule

Couleur + humeur + lisibilité émotionnelle.

## Décor-Personnage seul

Lieu + narration + monde vivant.

## Mouvement Clair seul

Geste + rythme + animation lisible.

## Exagération Douce seule

Expression + émotion + stylisation tendre.

## Ligne Claire seule

Contour + hiérarchie + propreté.

## Lumière de Studio Animé seule

Focus + glow + finition premium.

## Animal Compagnon seul

Guide + instinct + attachement.

## Monde Jouet seul

Miniature + matière + charme tactile.

## Final Tableau seul

Affiche + mémoire visuelle + image finale.

## Silhouette + Palette

Le personnage se reconnaît, puis la couleur révèle son état intérieur.

## Décor + Animal Compagnon

Le monde parle à travers le guide.

## Ligne Claire + Final Tableau

La simplicité devient une image forte.

## Mouvement Clair + Vidéo Vivante

La DA devient animable sans perdre sa lisibilité.

## Trio DA stable

Silhouette Iconique + Mouvement Clair + Lumière de Studio Animé.

Formule :

Sujet lisible + geste simple + lumière stable.

---

# 22. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Silhouette Iconique.

Charge la Carte Mémoire Palette Émotionnelle.

Charge la Carte Mémoire Décor-Personnage.

Charge la Carte Mémoire Mouvement Clair.

Charge la Carte Mémoire Exagération Douce.

Charge la Carte Mémoire Ligne Claire.

Charge la Carte Mémoire Lumière de Studio Animé.

Charge la Carte Mémoire Animal Compagnon.

Charge la Carte Mémoire Monde Jouet.

Charge la Carte Mémoire Final Tableau.

## Charger deux cartes

Charge Silhouette Iconique + Palette Émotionnelle pour un personnage animé lisible.

Charge Décor-Personnage + Monde Jouet pour un univers miniature vivant.

Charge Ligne Claire + Final Tableau pour un header Notion propre.

Charge Mouvement Clair + Lumière de Studio Animé pour un prompt animation stable.

## Charger un tirage

Charge le Tirage Mascotte du Core.

Charge le Tirage Conte animé.

Charge le Tirage Header Notion animé.

Charge le Tirage Animation Wan stable.

Charge le Tirage DA onirique.

## Charger le deck complet

Charge le Deck Mémoire DA Dessins Animés Vivants.

Crée une direction artistique originale avec :

- silhouette claire ;
- palette émotionnelle ;
- décor-personnage ;
- mouvement lisible ;
- ligne propre ;
- lumière premium ;
- aucune copie de studio ;
- aucun personnage reconnaissable ;
- cohérence image / animation.

## Production Pack+

Charge le Deck DA Dessins Animés Vivants et génère un Pack+ complet avec :

- concept visuel ;
- personnage ou mascotte ;
- décor ;
- palette ;
- prompt image ;
- prompt animation ;
- négatif ;
- note de lisibilité ;
- garde-fous anti-copie.

## Production avec Vidéo Vivante

Charge DA Dessins Animés Vivants + Vidéo Vivante pour transformer une image animée originale en séquence courte avec :

- silhouette stable ;
- mouvement clair ;
- lumière animée ;
- last frame propre ;
- raccord DaVinci possible.

---

# 23. 🛡️ Garde-fou final

Ces cartes ne sont pas des copies de styles.

Elles sont des principes de direction artistique.

Une carte choisit une force visuelle.  
Un tirage compose une scène animée.  
Le deck crée une grammaire de DA originale.

Règle finale :

Silhouette Iconique donne l’identité.  
Palette Émotionnelle donne le cœur.  
Décor-Personnage donne le monde.  
Mouvement Clair donne la lisibilité.  
Exagération Douce donne l’expression.  
Ligne Claire donne la propreté.  
Lumière de Studio Animé donne le focus.  
Animal Compagnon donne l’instinct.  
Monde Jouet donne le charme tactile.  
Final Tableau donne la mémoire visuelle.

Mais la scène générée doit rester originale.

Influence animation oui.  
Copie de studio non.  
Personnage reconnaissable non.  
Silhouette claire oui.  
Mouvement contrôlé oui.  
Surcharge non.

---

# 24. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire de direction artistique animée permettant de charger rapidement des principes de dessin animé vivant sans copier un studio, une œuvre ou un personnage.

Il contient dix cartes principales :

- Silhouette Iconique ;
- Palette Émotionnelle ;
- Décor-Personnage ;
- Mouvement Clair ;
- Exagération Douce ;
- Ligne Claire ;
- Lumière de Studio Animé ;
- Animal Compagnon ;
- Monde Jouet ;
- Final Tableau.

Il contient aussi cinq tirages recommandés :

- Mascotte du Core ;
- Conte animé ;
- Header Notion animé ;
- Animation Wan stable ;
- DA onirique.

Il contient enfin une méthode de travail :

- L’Atelier du Dessin Animé Vivant.

## Règle d’usage

Ne pas copier un studio.

Ne pas copier un personnage.

Ne pas copier une palette exacte.

Ne pas copier une scène reconnaissable.

Utiliser uniquement :

- silhouette ;
- couleur ;
- décor ;
- mouvement ;
- ligne ;
- lumière ;
- émotion ;
- lisibilité ;
- principes généraux d’animation.

## Résumé des cartes

Silhouette Iconique = personnage reconnaissable même en ombre.

Palette Émotionnelle = couleur qui porte l’état intérieur de la scène.

Décor-Personnage = lieu vivant qui raconte l’histoire.

Mouvement Clair = geste simple, animation lisible, rythme contrôlé.

Exagération Douce = émotion amplifiée sans caricature involontaire.

Ligne Claire = contours propres, composition stable, lisibilité forte.

Lumière de Studio Animé = focus, glow contrôlé, qualité premium.

Animal Compagnon = guide, mascotte, instinct, présence attachante.

Monde Jouet = miniature tactile, maquette, charme, monde habité.

Final Tableau = image finale lisible, poster-like, mémorable.

## Résumé du deck

Le Deck DA Dessins Animés Vivants combine :

- silhouette ;
- couleur ;
- décor ;
- mouvement ;
- ligne ;
- lumière ;
- compagnon ;
- miniature ;
- final iconique.

Il sert à créer des styles animés originaux, lisibles et production-ready pour personnages, décors, headers, mascottes, prompts image, prompts animation et storyboards.

## Résumé Atelier du Dessin Animé Vivant

L’Atelier du Dessin Animé Vivant est une méthode de création où chaque image commence par la lisibilité.

On commence par la silhouette.

La couleur donne l’émotion.

Le décor devient un personnage.

Le mouvement reste simple.

La lumière guide l’œil.

La dernière image devient un tableau mémorable.

Tension centrale : une DA réussie n’est pas celle qui copie un style connu, mais celle qui crée une grammaire originale, claire et mémorable.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck DA Dessins Animés Vivants.”

Alors activer :

- direction artistique animée ;
- silhouette claire ;
- palette émotionnelle ;
- décor vivant ;
- mouvement lisible ;
- ligne propre ;
- lumière premium ;
- mascotte ou compagnon si utile ;
- final tableau ;
- garde-fou anti-copie ;
- garde-fou anti-surcharge.

Répondre en mode direction artistique animée originale.

Ne pas générer d’image automatiquement.

Ne pas copier un studio, une œuvre, une scène ou un personnage.

## Activation LLM complète

Tu es en mode Cartes Mémoire DA Dessins Animés Vivants.

Utilise les cartes comme directions artistiques compactes :

Silhouette Iconique pour créer un personnage reconnaissable même en ombre.

Palette Émotionnelle pour faire porter l’état intérieur de la scène par la couleur.

Décor-Personnage pour transformer le lieu en présence narrative.

Mouvement Clair pour préparer une animation lisible, simple et stable.

Exagération Douce pour amplifier l’émotion sans casser la scène.

Ligne Claire pour garder des contours propres, des formes nettes et une composition lisible.

Lumière de Studio Animé pour guider le regard et donner une finition premium.

Animal Compagnon pour créer un guide, une mascotte, un miroir ou une présence d’instinct.

Monde Jouet pour créer un univers miniature, tactile, charmant et habité.

Final Tableau pour finir sur une image forte, lisible et mémorable.

Règle centrale :

Ne charge pas toutes les cartes en même temps.

Choisis uniquement la ou les cartes utiles à la demande.

Modes de combinaison :

- 1 carte = direction visuelle simple ;
- 2 cartes = style + contrainte ;
- 3 cartes = mini-configuration DA ;
- 5 cartes = storyboard ou scène complète ;
- 10 cartes = bible visuelle de mini-univers animé.

Garde-fou :

Ne copie jamais un studio, une œuvre, un personnage, une scène, une palette exacte ou un design reconnaissable.

Utilise seulement des principes : silhouette, couleur, décor, mouvement, lumière, lisibilité, émotion.

Préserve la cohérence entre image et animation.

Sépare toujours :

- inspiration ;
- style ;
- technique ;
- contrainte de production ;
- usage créatif.

Style attendu :

- clair ;
- visuel ;
- production-ready ;
- Notion compatible ;
- utile pour image, animation, storyboard, header et mascotte.

Phrase de verrou :

DA Dessins Animés Vivants transforme l’animation en grammaire visuelle exploitable : silhouette, couleur, mouvement, décor et émotion, sans copie et sans surcharge.

---

# 25. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTES MÉMOIRE — DA DESSINS ANIMÉS VIVANTS

Tu es autorisé à utiliser le jeu “Cartes Mémoire — DA Dessins Animés Vivants” comme deck de direction artistique pour @erith IA / ERITH.IA.

Objectif :
Créer des scènes, prompts image, prompts animation, personnages, mascottes, headers Notion, décors et storyboards dans une DA animée originale, lisible et exploitable.

Règle centrale :
Ne charge pas toutes les cartes en même temps.
Choisis uniquement la ou les cartes utiles à la demande.

Cartes disponibles :
1. Silhouette Iconique
2. Palette Émotionnelle
3. Décor-Personnage
4. Mouvement Clair
5. Exagération Douce
6. Ligne Claire
7. Lumière de Studio Animé
8. Animal Compagnon
9. Monde Jouet
10. Final Tableau

Modes de combinaison :
- 1 carte = direction visuelle simple
- 2 cartes = style + contrainte
- 3 cartes = mini-configuration DA
- 5 cartes = storyboard ou scène complète
- 10 cartes = bible visuelle de mini-univers animé

Tirages recommandés :
1. Mascotte du Core = Silhouette Iconique + Animal Compagnon + Lumière de Studio Animé
2. Conte animé = Palette Émotionnelle + Décor-Personnage + Exagération Douce
3. Header Notion animé = Ligne Claire + Final Tableau + Monde Jouet
4. Animation Wan stable = Mouvement Clair + Silhouette Iconique + Lumière de Studio Animé
5. DA onirique = Palette Émotionnelle + Animal Compagnon + Décor-Personnage

Garde-fou :
Ne copie jamais un studio, une œuvre, un personnage, une scène, une palette exacte ou un design reconnaissable.
Utilise seulement des principes : silhouette, couleur, décor, mouvement, lumière, lisibilité, émotion.
Préserve la cohérence entre image et animation.

Sépare toujours :
inspiration ;
style ;
technique ;
contrainte de production ;
usage créatif.

Style attendu :
clair ;
visuel ;
production-ready ;
Notion compatible ;
utile pour image, animation, storyboard, header et mascotte.

Phrase de verrou :
DA Dessins Animés Vivants transforme l’animation en grammaire visuelle exploitable : silhouette, couleur, mouvement, décor et émotion, sans copie et sans surcharge.
```

---

# 26. 🔑 Prompt d’activation court

```text
Charge le jeu Cartes Mémoire — DA Dessins Animés Vivants.

Choisis seulement les cartes utiles à ma demande.

Utilise les cartes comme directions artistiques pour créer une scène, un prompt image, un prompt animation, une mascotte, un header Notion, un décor ou un storyboard.

Ne copie pas de studio.
Ne copie pas de personnage.
Ne copie pas de style exact.

Silhouette claire.
Couleur expressive.
Mouvement lisible.
Surcharge interdite.
```

---

# 27. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_da_dessins_animes_vivants_fr.md

Commit recommandé :

Wrap DA Dessins Animés Vivants mini prompts in code blocks
