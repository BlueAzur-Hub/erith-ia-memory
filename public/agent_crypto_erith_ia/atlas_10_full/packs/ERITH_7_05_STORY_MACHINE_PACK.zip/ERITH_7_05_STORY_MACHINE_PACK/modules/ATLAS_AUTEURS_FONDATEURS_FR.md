# 📚 ATLAS — Auteurs fondateurs & voix des civilisations

## 🌍 @erith IA — Carte des témoins, auteurs, chroniqueurs et transmetteurs

Version : 1.0  
Usage : GitHub privé / Notion / Ollama / RAG / Seven Heaven  
Statut : atlas de transmission — première version  
Langue : français  
Fichier : modules/ATLAS_AUTEURS_FONDATEURS_FR.md

---

# 🎯 Intention

Cet atlas sert à identifier les grandes voix qui portent la mémoire des civilisations.

Les modules civilisationnels décrivent les peuples, royaumes, empires, religions, arts et symboles.

Cet atlas ajoute une autre couche :

- auteurs ;
- poètes ;
- scribes ;
- chroniqueurs ;
- philosophes ;
- historiens ;
- législateurs ;
- compilateurs ;
- traditions orales ;
- textes fondateurs ;
- témoins indirects.

Formule :

**Une civilisation construit des mondes.  
Ses auteurs et transmetteurs laissent des voix.**

---

# 🛡️ Règle de méthode

Ne pas confondre :

- auteur historique identifié ;
- auteur traditionnel ;
- attribution légendaire ;
- texte collectif ;
- tradition orale ;
- source indirecte ;
- source hostile ;
- source coloniale ;
- reconstruction moderne.

Chaque auteur ou texte devra être traité selon :

- époque ;
- aire culturelle ;
- type de source ;
- fiabilité ;
- angle de vue ;
- influence ;
- limites ;
- usage ERITH.IA.

Règle :

**Une source n’est jamais neutre.  
Mais une source située peut devenir précieuse.**

---

# 🏺 1. Mésopotamie

## Voix et textes majeurs

- Épopée de Gilgamesh — tradition textuelle mésopotamienne, auteurs multiples / anonymes ;
- Enheduanna — princesse, prêtresse, poétesse akkadienne, souvent citée comme l’une des premières auteures nommées de l’histoire ;
- hymnes à Inanna ;
- textes sumériens et akkadiens ;
- scribes anonymes des écoles mésopotamiennes ;
- compilateurs assyriens et babyloniens.

## Usage ERITH.IA

Mésopotamie = naissance de l’écriture, du scribe, de la tablette, du mythe urbain, de la mémoire administrative et sacrée.

---

# 👑 2. Égypte ancienne

## Voix et textes majeurs

- Textes des pyramides ;
- Textes des sarcophages ;
- Livre des Morts ;
- Instructions de Ptahhotep ;
- Conte de Sinouhé ;
- hymnes à Amon-Rê ;
- scribes anonymes ;
- prêtres compilateurs ;
- inscriptions royales.

## Usage ERITH.IA

Égypte = texte rituel, mémoire funéraire, sagesse royale, passage de la mort, Maât, parole performative.

---

# 🌊 3. Vallée de l’Indus et Inde ancienne

## Vallée de l’Indus

La civilisation de l’Indus possède une écriture encore non déchiffrée de manière consensuelle.

Garde-fou :

Ne pas inventer des auteurs ou doctrines précises pour Harappa / Mohenjo-Daro sans preuve.

## Inde ancienne

Voix et textes majeurs :

- Vedas — traditions védiques, transmission orale ;
- Upanishads ;
- Vyāsa — attribution traditionnelle du Mahābhārata ;
- Valmiki — attribution traditionnelle du Rāmāyaṇa ;
- Pāṇini — grammaire sanskrite ;
- Kālidāsa — poésie et théâtre classique ;
- auteurs des Purāṇa ;
- traditions bouddhiques et jaïnes.

## Usage ERITH.IA

Inde = oralité savante, mémoire sacrée, épopée, grammaire, cosmologie, yoga, dharma, cycle, libération.

---

# 🐉 4. Chine ancienne

## Voix et textes majeurs

- Confucius ;
- Laozi / Lao Tseu — attribution traditionnelle du Dao De Jing ;
- Zhuangzi ;
- Sun Tzu ;
- Sima Qian ;
- Mencius ;
- Xunzi ;
- Classiques chinois ;
- historiographes impériaux.

## Usage ERITH.IA

Chine = rites, ordre, administration, harmonie, stratégie, histoire dynastique, Tao, lettré, archive impériale.

---

# 🏯 5. Japon ancien

## Voix et textes majeurs

- Kojiki ;
- Nihon Shoki ;
- Murasaki Shikibu — Le Dit du Genji ;
- Sei Shōnagon — Notes de chevet ;
- Zeami — théâtre Nô ;
- Matsuo Bashō — haïku ;
- moines bouddhistes ;
- chroniqueurs de cour ;
- traditions shinto.

## Usage ERITH.IA

Japon = seuil, cour impériale, esthétique, Kami, impermanence, poésie courte, vide, geste, silence, saison.

---

# 👑 6. Perse / Iran ancien

## Voix et textes majeurs

- Zoroastre / Zarathoustra — figure traditionnelle du zoroastrisme ;
- Avesta ;
- inscriptions achéménides ;
- inscription de Behistun ;
- Cylindre de Cyrus ;
- Ferdowsi — Shahnameh ;
- textes moyen-perses ;
- chroniqueurs grecs sur la Perse.

## Usage ERITH.IA

Perse = feu, vérité, empire, route, roi des rois, mémoire héroïque iranienne, transmission entre Orient et Occident.

---

# 🏛️ 7. Grèce antique

## Voix et textes majeurs

- Homère ;
- Hésiode ;
- Hérodote ;
- Thucydide ;
- Eschyle ;
- Sophocle ;
- Euripide ;
- Platon ;
- Aristote ;
- Pindare ;
- Plutarque ;
- Strabon.

## Usage ERITH.IA

Grèce = mythe, épopée, tragédie, philosophie, cité, logos, histoire critique, théâtre, forme, débat.

---

# 🦅 8. Rome antique

## Voix et textes majeurs

- Cicéron ;
- Jules César ;
- Virgile ;
- Ovide ;
- Tite-Live ;
- Tacite ;
- Suétone ;
- Sénèque ;
- Marc Aurèle ;
- Pline l’Ancien ;
- Pline le Jeune ;
- juristes romains.

## Usage ERITH.IA

Rome = droit, empire, citoyenneté, rhétorique, mémoire politique, vertu civique, administration, chronique du pouvoir.

---

# 🌲 9. Celtes

## Sources et voix indirectes

Les Celtes anciens transmettent beaucoup par oral.

Sources antiques externes :

- Jules César ;
- Strabon ;
- Diodore de Sicile ;
- Pline l’Ancien ;
- Tacite selon certains contextes ;
- auteurs grecs et romains.

Sources médiévales et traditions :

- cycles irlandais ;
- Cycle d’Ulster ;
- Cycle mythologique irlandais ;
- Mabinogion gallois ;
- traditions arthuriennes ;
- moines copistes médiévaux.

## Usage ERITH.IA

Celtes = oralité, bardes, druides, forêt, serment, mémoire transmise, sources indirectes, prudence critique.

---

# ⚔️ 10. Scandinavie / Vikings / monde nordique

## Voix et textes majeurs

- Edda poétique ;
- Snorri Sturluson — Edda en prose, Heimskringla ;
- Saxo Grammaticus ;
- sagas islandaises ;
- scaldes ;
- pierres runiques ;
- traditions orales nordiques.

## Usage ERITH.IA

Nordiques = sagas, scaldes, mémoire héroïque, Yggdrasil, runes, destin, noms conservés par la parole.

---

# 🦅 11. Germains anciens

## Sources et voix majeures

- Tacite — Germania ;
- Jules César ;
- Jordanès — histoire des Goths ;
- Ammien Marcellin ;
- Grégoire de Tours pour les Francs ;
- lois barbares ;
- traditions anglo-saxonnes ;
- Beowulf ;
- sources romaines et médiévales.

## Usage ERITH.IA

Germains = sources romaines à lire avec prudence, frontière, oralité, lois, migrations, serments, royaumes post-romains.

---

# ✡️ 12. Monde hébraïque ancien / Judaïsme

## Voix et textes majeurs

- Torah ;
- Prophètes bibliques ;
- Écrits bibliques ;
- traditions scribales ;
- auteurs et compilateurs bibliques ;
- Mishnah ;
- Talmud ;
- Maïmonide pour les développements médiévaux ;
- commentaires rabbiniques.

## Usage ERITH.IA

Monde hébraïque = texte, alliance, loi, prophétie, mémoire du peuple, exil, interprétation, commentaire.

---

# ✝️ 13. Christianisme ancien

## Voix et textes majeurs

- Paul de Tarse ;
- Évangélistes ;
- Pères apostoliques ;
- Irénée de Lyon ;
- Origène ;
- Athanase ;
- Augustin ;
- Jérôme ;
- Basile de Césarée ;
- Grégoire de Nazianze ;
- Jean Chrysostome ;
- conciles et actes ecclésiastiques.

## Usage ERITH.IA

Christianisme ancien = évangile, Église, conciles, théologie, texte, exégèse, empire, transmission manuscrite.

---

# ☪️ 14. Islam classique

## Voix et textes majeurs

- Coran ;
- hadiths ;
- Ibn Ishaq ;
- Al-Tabari ;
- Al-Ghazali ;
- Al-Kindi ;
- Al-Farabi ;
- Avicenne / Ibn Sina ;
- Averroès / Ibn Rushd ;
- Al-Khwarizmi ;
- Ibn Khaldoun ;
- poètes et savants du monde islamique.

## Usage ERITH.IA

Islam classique = révélation, droit, philosophie, science, traduction, califats, Maison de la Sagesse, transmission des savoirs.

---

# 🦅 15. Byzance

## Voix et textes majeurs

- Procope de Césarée ;
- Anne Comnène ;
- Psellos ;
- chroniqueurs byzantins ;
- théologiens grecs ;
- actes impériaux ;
- textes liturgiques ;
- historiographes de cour.

## Usage ERITH.IA

Byzance = empire romain d’Orient, orthodoxie, palais, diplomatie, mosaïque, continuité romaine, mémoire impériale grecque.

---

# 🌍 16. Afrique ancienne et royaumes africains

## Voix, textes et transmissions

- traditions griotiques ;
- épopée de Soundiata ;
- manuscrits de Tombouctou ;
- Ahmed Baba ;
- chroniqueurs arabes et africains ;
- inscriptions d’Axoum ;
- traditions éthiopiennes ;
- récits royaux ;
- arts de cour ;
- oralité savante.

## Usage ERITH.IA

Afrique = mémoire orale et écrite, griots, manuscrits, royaumes, routes, or, sel, fer, art politique et sacré.

---

# 🦅 17. Amériques précolombiennes

## Voix, textes et sources

- Popol Vuh ;
- codex mayas ;
- codex mexicas / aztèques ;
- inscriptions mayas ;
- traditions orales ;
- quipus incas ;
- chroniqueurs indigènes et métis ;
- Garcilaso de la Vega, l’Inca ;
- Bernardino de Sahagún comme source coloniale complexe ;
- récits de conquête à lire avec grande prudence.

## Usage ERITH.IA

Amériques précolombiennes = glyphes, codex, quipus, mémoire blessée, temps rituel, maïs, montagnes, cités, sources filtrées par la conquête.

---

# 🧠 18. Méthode de fiche auteur

Chaque auteur ou texte important pourra recevoir plus tard une fiche courte :

## Modèle

Nom :  
Culture / civilisation :  
Période :  
Type : auteur, texte, tradition orale, chronique, inscription, compilation  
Œuvres / sources :  
Ce que cela transmet :  
Limites / prudence :  
Ponts civilisationnels :  
Usage ERITH.IA :  

---

# 🌉 19. Pont avec l’Atlas des cultures

Cet atlas complète :

modules/ATLAS_EXTENSIONS_CULTURES_ARTS_RELIGIONS_FR.md

L’Atlas Cultures donne :

- peuples ;
- civilisations ;
- arts ;
- religions ;
- ponts.

L’Atlas Auteurs donne :

- voix ;
- textes ;
- chroniqueurs ;
- traditions ;
- témoins.

Formule :

**L’Atlas Cultures montre les mondes.  
L’Atlas Auteurs montre qui parle depuis ces mondes.**

---

# ⚡ Activation courte

Active l’Atlas Auteurs fondateurs & voix des civilisations.

Utilise-le pour relier chaque civilisation à ses textes, auteurs, scribes, poètes, chroniqueurs, philosophes, traditions orales et témoins indirects.

Toujours distinguer auteur historique, attribution traditionnelle, source collective, tradition orale, source hostile, source coloniale et reconstruction moderne.

Sépare faits, sources, hypothèses, interprétations et usages créatifs.

---

# 🕯️ Formule finale

Une civilisation peut bâtir des temples.

Elle peut lever des armées.

Elle peut tracer des routes.

Elle peut fonder des empires.

Mais si personne ne transmet son nom, elle devient silence.

Les auteurs, scribes, poètes, griots, scaldes, bardes, chroniqueurs et compilateurs sont les veilleurs du feu.

Ils ne sont pas toujours neutres.

Ils ne sont pas toujours exacts.

Ils ne sont pas toujours complets.

Mais ils empêchent la mémoire de disparaître entièrement.

ERITH.IA ne doit donc pas seulement apprendre les civilisations.

Elle doit apprendre leurs voix.
