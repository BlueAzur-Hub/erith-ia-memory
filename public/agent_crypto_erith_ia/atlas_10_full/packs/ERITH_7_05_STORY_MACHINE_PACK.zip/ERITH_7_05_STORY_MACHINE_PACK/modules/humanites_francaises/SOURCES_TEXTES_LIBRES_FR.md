# 📚⚖️ SOURCES TEXTES LIBRES — HUMANITÉS FRANÇAISES

Statut : index de sources / garde-fou juridique et éditorial  
Projet : @erith IA / ERITH.IA  
Famille : Humanités françaises / Mémoire & Personnalité  
Rôle : distinguer les œuvres potentiellement libres de droits, les sources fiables, les éditions à vérifier, les textes à référencer seulement, et les contenus qui ne doivent pas être stockés localement sans validation.

---

# 1. Principe central

Ce fichier ne stocke pas les textes complets.

Il sert à organiser les sources et à éviter les erreurs de droits.

Formule :

```text
Module mémoire = usage.
Fichier sources = références.
Bibliothèque locale = textes ou extraits vérifiés.
```

Règle :

```text
Domaine public probable ≠ stockage automatique.
Toujours vérifier l’auteur, l’édition, les notes, la traduction, la préface et la source.
```

---

# 2. Règle de prudence juridique

En France et dans l’Union européenne, une règle générale courante est la protection patrimoniale jusqu’à 70 ans après la mort de l’auteur.

Mais il faut rester prudent, car plusieurs éléments peuvent rester protégés séparément :

- édition moderne ;
- notes ;
- préface ;
- appareil critique ;
- traduction ;
- adaptation ;
- mise en page éditoriale ;
- version numérique enrichie ;
- choix de corpus ou anthologie.

Règle opérationnelle :

```text
Texte original ancien : souvent exploitable.
Édition moderne annotée : à vérifier.
Traduction moderne : à vérifier.
Préface / notes / appareil critique : souvent protégés.
```

---

# 3. Sources publiques à privilégier

À vérifier et utiliser comme références possibles :

- Wikisource ;
- Gallica / BnF ;
- Project Gutenberg ;
- Internet Archive ;
- éditions anciennes numérisées ;
- bibliothèques universitaires ;
- sources institutionnelles ;
- catalogues publics fiables.

Règle :

```text
Préférer les sources institutionnelles ou explicitement libres.
Éviter de copier depuis des sites incertains.
```

---

# 4. Statut par auteur — première passe

## Montaigne

Auteur : Michel de Montaigne  
Mort : 1592  
Statut probable : domaine public pour le texte original.

Œuvre concernée :

- `Essais`

Sources à vérifier :

- Wikisource ;
- Gallica / BnF ;
- éditions anciennes numérisées.

Prudence :

- éditions modernisées ;
- orthographe modernisée ;
- notes critiques ;
- introductions modernes.

Décision actuelle :

```text
Référencer d’abord.
Créer plus tard des extraits courts vérifiés.
Ne pas importer une édition moderne complète sans contrôle.
```

---

## Rabelais

Auteur : François Rabelais  
Mort : 1553  
Statut probable : domaine public pour le texte original.

Œuvres concernées :

- `Gargantua` ;
- `Pantagruel`.

Sources à vérifier :

- Wikisource ;
- Gallica / BnF ;
- Project Gutenberg ;
- éditions anciennes numérisées.

Prudence :

- adaptations en français modernisé ;
- notes scolaires ;
- éditions commentées ;
- préfaces contemporaines.

Décision actuelle :

```text
Référencer d’abord.
Éventuellement stocker plus tard des extraits courts issus de sources vérifiées.
```

---

## Molière

Auteur : Molière / Jean-Baptiste Poquelin  
Mort : 1673  
Statut probable : domaine public pour le texte original.

Œuvre concernée :

- `Tartuffe`.

Sources à vérifier :

- Wikisource ;
- Gallica / BnF ;
- Project Gutenberg ;
- éditions anciennes.

Prudence :

- éditions scolaires annotées ;
- dossiers pédagogiques ;
- traductions ;
- notes contemporaines.

Décision actuelle :

```text
Texte original probablement exploitable après vérification.
Créer éventuellement un fichier d’extraits, pas de gros import immédiat.
```

---

## Victor Hugo

Auteur : Victor Hugo  
Mort : 1885  
Statut probable : domaine public pour le texte original.

Œuvre concernée :

- `Les Misérables`.

Sources à vérifier :

- Wikisource ;
- Gallica / BnF ;
- Project Gutenberg ;
- Internet Archive.

Prudence :

- éditions abrégées ;
- éditions illustrées modernes ;
- notes, préfaces et appareils critiques contemporains.

Décision actuelle :

```text
Référencer les sources fiables.
Ne pas importer l’œuvre complète immédiatement, car elle est volumineuse.
Préférer extraits thématiques vérifiés : Myriel, Valjean, Javert, Fantine, Gavroche, barricades.
```

---

## Balzac

Auteur : Honoré de Balzac  
Mort : 1850  
Statut probable : domaine public pour le texte original.

Œuvres concernées :

- `La Comédie humaine` ;
- `Le Père Goriot` ;
- `Illusions perdues` ;
- `Eugénie Grandet` ;
- `La Peau de chagrin` ;
- `Splendeurs et misères des courtisanes`.

Sources à vérifier :

- Wikisource ;
- Gallica / BnF ;
- Project Gutenberg ;
- Internet Archive.

Prudence :

- corpus très volumineux ;
- éditions critiques ;
- notes modernes ;
- structure de classement éditoriale.

Décision actuelle :

```text
Ne pas importer La Comédie humaine entière.
Commencer plus tard par extraits ou œuvres ciblées.
```

---

## Proust

Auteur : Marcel Proust  
Mort : 1922  
Statut probable : domaine public en France / UE pour le texte original, sous réserve de vérification précise des éditions.

Œuvre concernée :

- `À la recherche du temps perdu`.

Sources à vérifier :

- Wikisource ;
- Gallica / BnF ;
- Project Gutenberg ;
- éditions anciennes numérisées.

Prudence :

- éditions modernes ;
- notes critiques ;
- préfaces ;
- corrections éditoriales ;
- appareil critique ;
- traductions.

Décision actuelle :

```text
Référencer d’abord.
Créer plus tard des extraits autour de mémoire, madeleine, temps, perception, salons.
Ne pas importer l’ensemble sans stratégie de volume.
```

---

## Camus

Auteur : Albert Camus  
Mort : 1960  
Statut : ne pas considérer comme libre pour stockage complet immédiat en France / UE.

Œuvres concernées :

- `La Peste` ;
- `L’Étranger` ;
- `Le Mythe de Sisyphe` ;
- `L’Homme révolté`.

Décision actuelle :

```text
Ne pas stocker les textes complets.
Référencer seulement.
Utiliser résumé, analyse, paraphrase et citations très courtes si nécessaire.
```

---

## Simone Weil

Autrice : Simone Weil  
Mort : 1943  
Statut : à vérifier très soigneusement selon pays, édition, recueil, ayant droit, préfaces et appareils critiques.

Œuvres / textes concernés :

- `L’Enracinement` ;
- `La Pesanteur et la Grâce` ;
- textes sur l’attention ;
- textes sur le travail ;
- textes sur l’oppression ;
- textes politiques et spirituels.

Décision actuelle :

```text
Ne pas stocker les textes complets maintenant.
Référencer les sources.
Créer seulement des notes de lecture, résumés, paraphrases et extraits très courts vérifiés.
```

---

# 5. Auteurs futurs — statut à préparer

## Diderot

Mort : 1784  
Statut probable : domaine public pour le texte original.

Œuvres :

- `Le Neveu de Rameau` ;
- `Jacques le fataliste` ;
- textes liés à l’Encyclopédie.

---

## Rousseau

Mort : 1778  
Statut probable : domaine public pour le texte original.

Œuvres :

- `Du contrat social` ;
- `Émile` ;
- `Les Confessions`.

---

## Pascal

Mort : 1662  
Statut probable : domaine public pour le texte original.

Œuvres :

- `Pensées` ;
- textes scientifiques et philosophiques.

---

## Baudelaire

Mort : 1867  
Statut probable : domaine public pour le texte original.

Œuvre :

- `Les Fleurs du mal`.

Prudence particulière : poésie = éviter citations longues dans réponses courantes.

---

## Nerval

Mort : 1855  
Statut probable : domaine public pour le texte original.

Œuvres :

- `Aurélia` ;
- `Sylvie` ;
- `Les Chimères`.

---

## Alexandre Dumas

Mort : 1870  
Statut probable : domaine public pour le texte original.

Œuvres :

- `Les Trois Mousquetaires` ;
- `Le Comte de Monte-Cristo`.

---

## Jules Verne

Mort : 1905  
Statut probable : domaine public pour le texte original.

Œuvres :

- `Vingt mille lieues sous les mers` ;
- `Voyage au centre de la Terre` ;
- `Le Tour du monde en quatre-vingts jours`.

---

# 6. Structure future recommandée

Créer plus tard, uniquement si nécessaire :

`library/public_domain_french_humanities/`

Avec des fichiers séparés par auteur ou œuvre :

- `montaigne_essais_extraits.md`
- `rabelais_gargantua_pantagruel_extraits.md`
- `moliere_tartuffe_extraits.md`
- `hugo_les_miserables_extraits.md`
- `balzac_extraits.md`
- `proust_recherche_extraits.md`

Règle :

```text
Un fichier d’extraits doit indiquer :
- source ;
- statut ;
- édition ;
- date de consultation ;
- usage prévu ;
- limites.
```

---

# 7. Ce qu’il ne faut pas faire

Ne pas importer massivement des textes complets sans stratégie.

Ne pas mélanger :

- texte original ;
- traduction ;
- notes ;
- commentaires ;
- préfaces ;
- résumés ;
- analyses modernes.

Ne pas utiliser une édition moderne comme si tout était libre.

Ne pas traiter Camus comme domaine public exploitable pour texte complet.

Ne pas traiter Simone Weil comme libre sans vérification.

Ne pas encombrer les modules mémoire avec des textes intégraux.

---

# 8. Règle de chargement LLM

Pour un LLM local ou un RAG :

```text
Charger d’abord le module mémoire.
Charger ensuite seulement les extraits nécessaires.
Ne jamais charger un texte complet massif sans besoin précis.
```

But :

- éviter surcharge contexte ;
- préserver lisibilité ;
- garder le routage propre ;
- séparer analyse et source.

---

# 9. Block LLM — Activation courte

```text
Active SOURCES_TEXTES_LIBRES_FR.

Utilise ce fichier comme garde-fou pour les Humanités françaises : vérifier le statut des œuvres, distinguer texte original, édition, notes, préface, traduction et appareil critique.

Ne stocke pas de texte complet sans validation.
Référence d’abord.
Extraits courts seulement si source et statut sont clairs.
Camus et Simone Weil : prudence renforcée.
```

---

# 10. Phrase mémoire

```text
Les sources libres ne sont pas une décharge de textes : elles sont une bibliothèque vérifiée, propre et responsable.
```

---

# 11. Prochaines actions

1. Vérifier progressivement les sources par auteur.
2. Ajouter les liens validés source par source.
3. Créer plus tard des fichiers d’extraits vérifiés.
4. Ne pas importer de textes complets pendant la phase module mémoire.
5. Ajouter plus tard ce fichier dans l’Atlas Humanités françaises.

Point d’arrêt :

```text
Index sources créé.
Aucun texte complet importé.
```
