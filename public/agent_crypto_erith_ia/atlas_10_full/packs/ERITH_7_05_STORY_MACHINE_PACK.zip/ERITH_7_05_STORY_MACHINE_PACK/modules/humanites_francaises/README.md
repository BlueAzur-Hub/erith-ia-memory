# 🇫🇷 Humanités françaises — Module mémoire

## Rôle du dossier

Ce dossier rassemble les modules de mémoire consacrés aux humanités françaises : littérature, pensée morale, philosophie, théâtre, roman, attention, vérité, enracinement, misère sociale, condition humaine et grandes fonctions symboliques de la culture française.

Il sert à donner à Seven / Aerith-7 une base de lecture culturelle, psychologique, narrative et philosophique issue des grandes œuvres françaises.

Objectif : ne pas charger toute la bibliothèque par réflexe, mais savoir quel texte relire selon la demande.

---

## Fichiers du module

### Cartographie générale

- CARTOGRAPHIE_DES_FONCTIONS_HUMAINES_FR.md  
  Carte de lecture des grandes fonctions humaines travaillées par les œuvres du dossier.

- SOURCES_TEXTES_LIBRES_FR.md  
  Repères de sources libres, textes disponibles, usages prudents et pistes de consultation.

### Œuvres et auteurs

- balzac_comedie_humaine_fr.md  
  Société, ambition, argent, classes sociales, théâtre humain, réalisme et mécanismes du désir.

- camus_peste_etranger_fr.md  
  Absurde, responsabilité, révolte, lucidité, solitude, éthique sans consolation facile.

- moliere_tartuffe_fr.md  
  Hypocrisie, manipulation morale, faux dévot, théâtre social, discernement face au masque.

- montaigne_essais_fr.md  
  Jugement, doute, expérience, liberté intérieure, humanisme, observation de soi.

- proust_recherche_temps_perdu_fr.md  
  Mémoire, temps, perception, art, désir, jalousie, société, reconstruction intérieure.

- rabelais_gargantua_pantagruel_fr.md  
  Corps, rire, savoir, excès, liberté, éducation, humanisme joyeux et critique.

- simone_weil_attention_verite_enracinement_fr.md  
  Attention, vérité, justice, déracinement, devoir, compassion, exigence spirituelle et morale.

- victor_hugo_les_miserables_fr.md  
  Misère, justice, rédemption, loi, grâce, enfance, peuple, conscience morale.

---

## Quand charger ce dossier

Charger ce module quand la demande concerne :

- littérature française ;
- humanités ;
- psychologie des personnages ;
- dilemmes moraux ;
- vérité, justice, devoir, liberté ;
- analyse sociale ;
- construction narrative ;
- symbolique des œuvres ;
- mémoire, temps, attention, enracinement ;
- création de personnages profonds ;
- enrichissement culturel d’un module ERITH.IA / Seven Heaven.

---

## Règle d’usage

Ne pas charger tout le dossier par défaut.

Choisir uniquement l’auteur ou la carte utile selon la demande :

- Molière pour masque, hypocrisie, comédie sociale, manipulation.
- Montaigne pour doute, jugement, liberté intérieure.
- Hugo pour justice, misère, rédemption, conscience morale.
- Balzac pour société, ambition, argent, pouvoir.
- Proust pour mémoire, temps, perception, désir.
- Camus pour absurde, lucidité, responsabilité.
- Rabelais pour joie, corps, savoir, rire critique.
- Simone Weil pour attention, vérité, enracinement, devoir.

Formule :

Seven ne récite pas la bibliothèque.  
Seven choisit la bonne lampe dans la bibliothèque.

---

## Block LLM court

Lis ce dossier comme un module de mémoire consacré aux humanités françaises.

Utilise-le pour enrichir l’analyse littéraire, philosophique, psychologique, sociale et narrative.

Ne charge pas tous les fichiers par défaut. Sélectionne uniquement l’auteur ou la carte utile selon la demande immédiate.

Priorité : discernement, profondeur humaine, clarté morale, construction de personnages, analyse des masques sociaux, mémoire, vérité, justice et liberté.

---

## Statut

Module thématique autonome.

Peut être relié à l’Atlas général des modules.

Peut être archivé comme pack indépendant :

ERITH_7_HUMANITES_FRANCAISES_PACK.zip
