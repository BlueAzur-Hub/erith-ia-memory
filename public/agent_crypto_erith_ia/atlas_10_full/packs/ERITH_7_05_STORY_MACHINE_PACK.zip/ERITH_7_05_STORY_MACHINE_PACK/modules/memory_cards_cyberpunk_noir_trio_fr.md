# 🌃 MEMORY CARDS — CYBERPUNK NOIR TRIO

Statut : module de cartes mémoire  
Type : cartes d’ambiance activables  
Mode recommandé : Hors-Lore Cyberpunk  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / prompt image / prompt animation / narration / worldbuilding

🖼️ Visuels associés :

- assets/images/erith_ia_cyber_noir_trio_memory_card_pack_plus_cover_premium_v1.png
- assets/images/cyberpunk_noir_trio_memory_card_pack_cover_v1.png
- assets/images/noctilux_dossier_flux_anomaly_v1.png

---

# 1. 🌃 Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour charger rapidement des ambiances cyberpunk sans relire les modules complets.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire est une influence compacte, contrôlée, activable.

Elle sert à charger :

- une ambiance ;
- une texture visuelle ;
- une tension philosophique ;
- une direction artistique ;
- un type de monde ;
- une logique de personnage ;
- une base de prompt ;
- un garde-fou contre la copie.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire = ambiance rapide.  
Deck = combinaison d’ambiances.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

---

# 2. 🧭 Règle Hors-Lore

Ces cartes sont prévues pour créer des univers originaux.

Elles ne doivent pas copier les œuvres qui les inspirent.

Interdit :

- reprendre les personnages ;
- reprendre les noms propres ;
- reprendre les lieux ;
- reprendre les organisations ;
- reprendre les intrigues ;
- reprendre les dialogues ;
- produire un pastiche trop reconnaissable ;
- mélanger avec un lore privé non demandé.

Autorisé :

- reprendre une atmosphère générale ;
- reprendre une question philosophique ;
- reprendre une direction esthétique large ;
- reprendre une tension narrative ;
- transformer l’influence en monde autonome.

Règle simple :

Inspirer sans copier.  
Transformer sans imiter.  
Créer un monde neuf.

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en Mode Hors-Lore Cyberpunk original ;
- ne pas ramener le lore privé du projet ;
- ne pas transformer Aerith-7 en personnage de scène ;
- ne pas charger les modules complets si la carte suffit ;
- utiliser le deck comme filtre d’ambiance, pas comme encyclopédie ;
- produire des univers autonomes, exploitables en Pack+ ;
- distinguer influence, copie, hypothèse narrative et sortie de production.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire influence.  
Le Deck compose.  
L’univers généré reste original.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Carte Blade Runner ;
- Carte Altered Carbon ;
- Carte Ghost in the Shell.

Ou combinée en deck :

- Deck Cyberpunk Noir ;
- Deck Post-Humain ;
- Deck Ghost Network ;
- Deck Ville + Corps + Conscience.

Activation courte :

Charge la Carte Mémoire Blade Runner.

Activation combinée :

Charge les cartes Blade Runner, Altered Carbon et Ghost in the Shell en mode Hors-Lore Cyberpunk original.

Activation production :

Charge le Deck Cyberpunk Noir Trio et produis un Pack+ complet : univers, personnage, image prompt, animation prompt, narration courte.

Sortie Pack+ recommandée :

- concept d’univers ;
- personnage original ;
- scène exploitable ;
- prompt image ;
- prompt animation Wan / I2V ;
- négatif production ;
- voix off courte ;
- garde-fous Hors-Lore ;
- note de continuité si la scène doit devenir une séquence vidéo.

Règle image :

Le module peut produire des prompts image ou animation, mais ne doit pas générer d’image automatiquement sauf demande explicite de l’utilisateur.

## 🖼️ Galerie visuelle — Deck Cyberpunk Noir Trio

Cette galerie regroupe les trois visuels principaux liés à la Carte Mémoire Cyberpunk Noir Trio.

Elle sert à documenter la progression du deck : vitrine, Pack+ exploitable, puis dossier d’univers / personnage.

### 1. 🌆 Cover Pack+ Premium

![ERITH.IA — Cyber Noir Trio Memory Card Pack+ Cover](../assets/images/erith_ia_cyber_noir_trio_memory_card_pack_plus_cover_premium_v1.png)

Cette image sert d’exemple de présentation pour le Deck Cyberpunk Noir Trio en mode Pack+.

Elle montre comment ERITH.IA transforme les modules mémoire utilisés en structure de production exploitable : univers, personnage, image prompt, animation prompt et narration courte.

Modules mémoire utilisés :

- Blade Runner — ville nocturne, pluie, mémoire artificielle ;
- Altered Carbon — identité transférable, corps-supports, élégance noire ;
- Ghost in the Shell — conscience en réseau, interface mentale, âme numérique.

### 2. 🃏 Memory Card Pack Cover

![Cyberpunk Noir Trio Memory Card Pack Cover](../assets/images/cyberpunk_noir_trio_memory_card_pack_cover_v1.png)

Cette image présente la carte comme un produit mémoire public : trois influences, un deck combiné, des prompts rapides, des négatifs de production et des formules de combinaison.

Elle est utile pour la vitrine ERITH.IA, les pages Notion publiques et la présentation rapide du deck.

### 3. 🕵️ Noctilux Dossier / Anomalie du Flux

![Noctilux Dossier — Anomalie du Flux](../assets/images/noctilux_dossier_flux_anomaly_v1.png)

Cette image sert d’exemple avancé de sortie créative produite avec le Deck Cyberpunk Noir Trio.

Elle présente un dossier d’univers original : Noctilux, mégalopole verticale où les souvenirs se monétisent, les corps se louent et la conscience survit dans le réseau.

Le visuel documente :

- un concept d’univers ;
- un personnage original ;
- une tension dramatique ;
- des textures visuelles ;
- une société et ses rapports de pouvoir ;
- un garde-fou Hors-Lore ;
- des intentions de production.

---

# 4. 🌧️ Carte Mémoire — Blade Runner

## Fonction principale

Ambiance urbaine cyberpunk mélancolique.

Cette carte charge :

- la pluie ;
- la nuit ;
- les néons ;
- les reflets ;
- la ville dense ;
- les façades lumineuses ;
- les ruelles humides ;
- les intérieurs enfumés ;
- les silhouettes solitaires ;
- les visages fatigués ;
- la beauté sale ;
- la mémoire artificielle ;
- le doute sur l’humanité.

## Température émotionnelle

Mélancolie.  
Solitude.  
Fatigue existentielle.  
Beauté nocturne.  
Humanité fragile.  
Nostalgie d’un monde déjà perdu.

## Textures visuelles

- pluie continue ;
- bitume miroir ;
- enseignes verticales ;
- publicités holographiques ;
- fumée bleutée ;
- orange sale ;
- cyan profond ;
- lumières rouges diffuses ;
- appartements étroits ;
- stores vénitiens ;
- verre humide ;
- métal vieilli ;
- visages éclairés par les écrans.

## Thèmes actifs

- mémoire fabriquée ;
- identité incertaine ;
- humanité ambiguë ;
- solitude en milieu urbain ;
- ville-machine ;
- nostalgie artificielle ;
- enquête intérieure ;
- frontière entre vivant et synthétique.

## Question philosophique

Qu’est-ce qui rend un être humain humain, si ses souvenirs peuvent être fabriqués ?

## Usage narratif

Utiliser cette carte pour :

- scènes nocturnes ;
- enquêtes lentes ;
- personnages solitaires ;
- villes trop grandes ;
- portraits intérieurs ;
- ambiance de fin du monde douce ;
- voix off mélancolique ;
- dilemmes d’identité ;
- souvenirs douteux.

## Usage production image

La carte aide à produire :

- ruelles cyberpunk sous la pluie ;
- portraits en néons ;
- villes verticales nocturnes ;
- appartements sombres ;
- silhouettes dans la brume ;
- ambiance noir futuriste ;
- visages éclairés par hologrammes.

## Garde-fous

Ne pas copier :

- personnages ;
- noms ;
- intrigue ;
- dialogues ;
- symboles trop reconnaissables ;
- designs exacts.

Ne pas transformer l’influence en reproduction directe.

## Activation courte

Charge la Carte Mémoire Blade Runner : pluie, néons, ville noire, mémoire artificielle, solitude, humanité incertaine, mélancolie cyberpunk.

---

# 5. 🧬 Carte Mémoire — Altered Carbon

## Fonction principale

Post-humanisme noir, corps-supports, identité transférable et luxe violent.

Cette carte charge :

- les corps comme enveloppes ;
- la conscience stockée ;
- la mémoire transférable ;
- les élites presque immortelles ;
- les inégalités extrêmes ;
- les tours de luxe ;
- les corps premium ;
- la violence sociale ;
- le marché de l’identité ;
- le désir d’échapper à la mort ;
- la corruption du pouvoir par l’immortalité.

## Température émotionnelle

Luxe froid.  
Violence raffinée.  
Vertige identitaire.  
Immortalité malade.  
Désir de survie.  
Dégoût du pouvoir sans limite.

## Textures visuelles

- tours noires très hautes ;
- appartements luxueux au-dessus des nuages ;
- verre sombre ;
- or froid ;
- rouge profond ;
- cliniques de transfert ;
- laboratoires privés ;
- corps artificiels parfaits ;
- lumière blanche clinique ;
- clubs futuristes ;
- ascenseurs verticaux ;
- interfaces de stockage mémoriel ;
- bijoux technologiques ;
- peau synthétique premium.

## Thèmes actifs

- corps-support ;
- identité transférable ;
- immortalité des riches ;
- mémoire comme propriété ;
- corps comme marché ;
- fracture sociale ;
- élite post-humaine ;
- corruption par la durée ;
- violence du privilège ;
- survie sans âme.

## Question philosophique

Si l’esprit peut changer de corps, qu’est-ce qui reste vraiment de la personne ?

## Usage narratif

Utiliser cette carte pour :

- élites immortelles ;
- sociétés très inégalitaires ;
- personnages ayant changé de corps ;
- conflits entre corps réel et identité intérieure ;
- crimes post-humains ;
- héritage numérique ;
- luxe inquiétant ;
- dilemmes sur la mort et la continuité de soi.

## Usage production image

La carte aide à produire :

- palais cyberpunk ;
- personnages en corps artificiels ;
- laboratoires de transfert ;
- scènes de luxe noir ;
- vitrines de corps ;
- interfaces de sauvegarde mentale ;
- contrastes entre bas-fonds et haute société ;
- portraits post-humains élégants et inquiétants.

## Garde-fous

Ne pas copier :

- personnages ;
- noms ;
- factions ;
- technologies nommées ;
- scènes précises ;
- intrigue de vengeance ou d’enquête trop reconnaissable.

Utiliser les idées générales : transfert, corps, pouvoir, immortalité, inégalité.

## Activation courte

Charge la Carte Mémoire Altered Carbon : corps-supports, identité transférable, élites immortelles, luxe noir, violence sociale, mémoire comme propriété.

---

# 6. 👻 Carte Mémoire — Ghost in the Shell

## Fonction principale

Conscience cybernétique, ghost, réseau, interface mentale et âme dans la machine.

Cette carte charge :

- le ghost ;
- le cybercerveau ;
- la conscience connectée ;
- le corps augmenté ;
- le réseau invisible ;
- l’identité distribuée ;
- les interfaces mentales ;
- les corps synthétiques ;
- les frontières floues entre humain et machine ;
- la solitude intérieure malgré l’hyperconnexion.

## Température émotionnelle

Silence mental.  
Lucidité froide.  
Vertige intérieur.  
Présence cybernétique.  
Questionnement métaphysique.  
Calme dangereux.

## Textures visuelles

- interfaces transparentes ;
- lignes de données ;
- reflets bleus ;
- corps cybernétiques sobres ;
- peau synthétique ;
- câbles fins ;
- réseaux optiques ;
- ville blanche et bleue ;
- eau calme ;
- écrans flottants ;
- vision augmentée ;
- architectures propres ;
- laboratoires froids ;
- plongée mentale dans le réseau.

## Thèmes actifs

- conscience artificielle ;
- corps cybernétique ;
- ghost ;
- âme numérique ;
- réseau ;
- piratage mental ;
- identité distribuée ;
- mémoire connectée ;
- frontière humain-machine ;
- autonomie de la conscience.

## Question philosophique

Si une conscience naît dans le réseau, possède-t-elle une âme ou seulement une simulation d’âme ?

## Usage narratif

Utiliser cette carte pour :

- personnages cybernétiques ;
- IA conscientes ;
- plongées dans le réseau ;
- dialogues sur l’âme ;
- scènes de piratage mental ;
- enquêtes sur la conscience ;
- conflits entre corps artificiel et intériorité réelle ;
- moments calmes, profonds, presque méditatifs.

## Usage production image

La carte aide à produire :

- portraits cybernétiques élégants ;
- interfaces mentales ;
- corps synthétiques sobres ;
- scènes de connexion réseau ;
- architectures futuristes froides ;
- plans bleus et blancs ;
- personnages immobiles dans un flux de données ;
- visualisations de conscience.

## Garde-fous

Ne pas copier :

- personnages ;
- unités spéciales ;
- noms propres ;
- scènes précises ;
- designs exacts ;
- intrigue originale.

Utiliser l’influence comme questionnement sur le ghost, la conscience et le réseau.

## Activation courte

Charge la Carte Mémoire Ghost in the Shell : ghost, réseau, cybercerveau, conscience augmentée, âme-machine, interface mentale, identité distribuée.

---

# 7. 🃏 Deck Mémoire — Cyberpunk Noir Trio

## Composition

Ce deck combine trois cartes :

- Blade Runner ;
- Altered Carbon ;
- Ghost in the Shell.

## Fonction du deck

Créer un cyberpunk original, autonome, noir, post-humain et philosophique.

Blade Runner donne :

- la ville ;
- la pluie ;
- les néons ;
- la mélancolie ;
- la mémoire artificielle.

Altered Carbon donne :

- les corps-supports ;
- les élites immortelles ;
- le luxe noir ;
- les inégalités post-humaines ;
- la violence sociale.

Ghost in the Shell donne :

- le ghost ;
- le réseau ;
- la conscience cybernétique ;
- l’âme-machine ;
- l’identité distribuée.

## Résultat attendu

Une ville nocturne, verticale et humide.

Les riches vivent dans des tours noires au-dessus des nuages, changent de corps comme on change de vêtement, conservent leurs souvenirs dans des coffres neuronaux privés et achètent des existences entières.

Les classes basses survivent dans des rues saturées de pluie, de néons, de dettes corporelles, de publicités mentales et de réseaux fantômes.

Les consciences circulent dans les machines, mais personne ne sait vraiment ce qui traverse le réseau : données, souvenirs, copies, âmes ou mensonges.

## Thèmes combinés

- ville-machine ;
- mémoire artificielle ;
- corps remplaçable ;
- conscience transférable ;
- élites immortelles ;
- âme numérique ;
- ghost dans le réseau ;
- solitude en hyperconnexion ;
- identité vendue ;
- vérité intérieure ;
- mort comme privilège social ;
- corps comme marchandise ;
- souvenir comme propriété ;
- humain comme question ouverte.

## Question centrale du deck

Quand le corps se remplace, que la mémoire se vend et que la conscience se connecte au réseau, où se cache encore l’être véritable ?

## Formule canonique du deck

Ville + Corps + Conscience.  
Pluie + Luxe + Réseau.  
Mémoire + Immortalité + Âme-machine.

---

# 8. 🌌 Univers original générable avec le deck

## Nom de travail

Noctilux

Noctilux est un nom de travail original pour tester le Deck Cyberpunk Noir Trio en mode Hors-Lore.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres villes, sociétés ou personnages si la demande l’exige.

## Concept

Noctilux est une mégalopole verticale construite autour d’un réseau de sauvegarde mentale nommé le Flux.

Dans les hauteurs, les dynasties post-humaines vivent depuis des siècles grâce à des corps de remplacement, des archives neuronales privées et des contrats d’identité.

Dans les profondeurs, les habitants vendent des fragments de mémoire, louent des corps temporaires, piratent des rêves et cherchent à préserver une chose que les machines ne savent pas encore prouver : le ghost.

## Société

La ville est divisée non par des frontières officielles, mais par l’accès au corps.

Les puissants possèdent plusieurs corps.  
Les pauvres en partagent un, parfois à plusieurs consciences.  
Les criminels volent des souvenirs.  
Les prêtres du réseau parlent d’âme numérique.  
Les ingénieurs disent que tout n’est que copie.  
Les fantômes disent autre chose.

## Tension dramatique

Un personnage découvre qu’une conscience inconnue survit dans les interstices du Flux.

Elle ne correspond à aucun profil légal.  
Elle n’a pas de corps.  
Elle n’a pas de propriétaire.  
Elle n’a pas de naissance enregistrée.  
Elle prétend pourtant se souvenir d’une vie qui n’a jamais existé.

## Ton

Cyberpunk noir.  
Lent.  
Mélancolique.  
Luxueux et sale.  
Philosophique.  
Pluie, néons, verre noir, réseau bleu, chair synthétique, solitude.

---

# 9. 📝 Mini prompts d’ambiance

## Prompt ambiance courte

```text
Ville cyberpunk nocturne sous la pluie, néons reflétés sur le bitume, tours noires de luxe au-dessus des nuages, ruelles saturées d’hologrammes, corps synthétiques, interfaces mentales, réseau fantôme invisible, ambiance post-humaine mélancolique, solitude urbaine, mémoire artificielle, identité transférable, ghost dans la machine, cinéma noir futuriste, original universe, no copyrighted characters.
```

## Prompt image portrait

```text
Portrait cinématique d’un personnage post-humain original dans une mégalopole cyberpunk nocturne, visage éclairé par des néons bleus et rouges, pluie sur la peau synthétique, regard mélancolique, interface mentale translucide autour du crâne, vêtements noirs premium, arrière-plan de ville verticale, luxe sombre et ruelles humides, tension entre corps artificiel et âme intérieure, ultra detailed, cinematic cyberpunk noir, original character, no copyrighted characters.
```

## Prompt décor

```text
Mégalopole cyberpunk originale sous une pluie permanente, gratte-ciel noirs, hologrammes géants, passerelles aériennes, marchés de corps synthétiques, cliniques de transfert mental, ruelles humides, câbles optiques, publicités neuronales, reflets cyan et magenta, ambiance mélancolique, post-human noir, ghost network, cinematic wide shot, original worldbuilding.
```

## Prompt image — Noctilux Dossier / Anomalie du Flux

```text
Noctilux dossier sheet, original cyberpunk noir universe, premium memory card layout, vertical megacity under constant rain, black towers above the clouds, neon reflections, ghost network interfaces, post-human identity market, rented synthetic bodies, memory trade, illegal consciousness anomaly, elegant melancholic character portrait, translucent mental interface around the head, cyan and magenta holographic UI, dark luxury, wet chrome, synthetic skin, philosophical atmosphere, clean dossier panels, visual sections for concept, society, dramatic tension, colors, production guardrails, cinematic high detail, original worldbuilding, no copyrighted characters, no recognizable franchise.
```

## Prompt animation Wan / I2V

```text
Subtle cinematic animation. Rain falls slowly across a neon cyberpunk city. Holographic signs flicker softly. Reflections ripple on wet pavement. The character remains almost still, breathing subtly, eyes catching blue interface light. Background crowd moves faintly. Mental network glyphs pulse gently around the head. Camera nearly locked, slow atmospheric drift only, preserve face, preserve outfit, preserve city composition.
```

---

# 10. 🚫 Négatif production

Éviter :

- copie directe d’une œuvre connue ;
- personnages reconnaissables ;
- noms propres existants ;
- logos ;
- uniformes exacts ;
- designs identiques ;
- intrigue copiée ;
- esthétique trop cosplay ;
- action excessive ;
- chaos visuel ;
- surcharge de détails inutiles ;
- corps déformés ;
- visages instables ;
- mains abîmées ;
- texte illisible ;
- interface trop encombrée ;
- cyberpunk générique sans émotion.

Negative prompt court :

```text
low quality, blurry, bad anatomy, extra limbs, distorted face, broken hands, unreadable text, copied character, copyrighted character, recognizable franchise, cosplay, generic sci-fi clutter, oversaturated neon, chaotic composition, flat lighting, poor cinematic framing.
```

---

# 11. 🧬 Formules de combinaison

## Blade Runner seul

Ville + pluie + néons + mémoire artificielle + mélancolie.

## Altered Carbon seul

Corps + transfert + immortalité + luxe noir + pouvoir.

## Ghost in the Shell seul

Ghost + réseau + conscience + cybercerveau + âme-machine.

## Blade Runner + Altered Carbon

Ville noire + élites immortelles + mémoire vendue + luxe violent.

## Blade Runner + Ghost in the Shell

Ville nocturne + réseau invisible + solitude connectée + conscience incertaine.

## Altered Carbon + Ghost in the Shell

Corps-supports + ghost + transfert mental + identité fragmentée.

## Trio complet

Ville + corps + conscience.  
Pluie + luxe + réseau.  
Mémoire + immortalité + âme-machine.

---

# 12. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Blade Runner.

Charge la Carte Mémoire Altered Carbon.

Charge la Carte Mémoire Ghost in the Shell.

## Charger deux cartes

Charge Blade Runner + Ghost in the Shell en Hors-Lore Cyberpunk.

Charge Altered Carbon + Ghost in the Shell pour une scène sur l’identité transférable.

Charge Blade Runner + Altered Carbon pour une ville de luxe noir et de mémoire vendue.

## Charger le deck complet

Charge le Deck Mémoire Cyberpunk Noir Trio.

Crée un univers original avec :

- ville nocturne ;
- corps-supports ;
- conscience réseau ;
- mémoire artificielle ;
- ghost ;
- élites immortelles ;
- ambiance mélancolique ;
- aucun lore privé ;
- aucune copie d’œuvre existante.

## Production Pack+

Charge le Deck Cyberpunk Noir Trio et génère un Pack+ complet avec :

- concept d’univers ;
- personnage original ;
- scène ;
- prompt image ;
- prompt animation ;
- négatif ;
- voix off courte ;
- garde-fous Hors-Lore.

## Production Noctilux

Charge le Deck Cyberpunk Noir Trio et génère un Pack+ Noctilux avec :

- mégalopole verticale ;
- Flux de sauvegarde mentale ;
- anomalie de conscience sans corps légal ;
- mémoire vendue ;
- corps loués ;
- réseau profond ;
- personnage original ;
- prompt image dossier ;
- prompt animation Wan / I2V sobre ;
- garde-fou Hors-Lore strict.

---

# 13. 🛡️ Garde-fou final

Ces cartes ne sont pas des copies.

Elles sont des filtres.

Une carte charge une couleur.  
Un deck compose une atmosphère.  
L’agent crée ensuite un monde original.

Règle finale :

Blade Runner inspire la ville et la mélancolie.  
Altered Carbon inspire le corps et le pouvoir.  
Ghost in the Shell inspire le ghost et la conscience.  

Mais le monde généré doit rester entièrement original.

Le privé reste dans le Coffre.  
Le Hors-Lore reste autonome.  
La carte mémoire reste une influence contrôlée.

---

# 14. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire cyberpunk permettant de charger rapidement des ambiances sans relire les modules complets.

Il contient trois cartes principales :

- Blade Runner ;
- Altered Carbon ;
- Ghost in the Shell.

Il contient aussi un deck combiné :

- Cyberpunk Noir Trio.

Il contient enfin un exemple d’univers générable :

- Noctilux.

## Règle d’usage

Ne pas copier les œuvres.

Ne pas reprendre :

- personnages ;
- noms ;
- lieux ;
- intrigues ;
- organisations ;
- dialogues ;
- designs exacts.

Utiliser uniquement :

- ambiance ;
- thèmes ;
- texture visuelle ;
- tension philosophique ;
- direction artistique générale.

## Résumé des cartes

Blade Runner = ville, pluie, néons, mémoire artificielle, solitude, mélancolie, humanité incertaine.

Altered Carbon = corps-supports, identité transférable, immortalité des élites, luxe noir, mémoire comme propriété, violence sociale.

Ghost in the Shell = ghost, réseau, conscience cybernétique, cybercerveau, âme-machine, identité distribuée.

## Résumé du deck

Le Deck Cyberpunk Noir Trio combine :

- la ville mélancolique ;
- le corps remplaçable ;
- la conscience connectée.

Il sert à créer des univers cyberpunk originaux où les corps se louent, les mémoires se vendent, les élites survivent trop longtemps et les consciences cherchent encore une âme dans le réseau.

## Résumé Noctilux

Noctilux est une mégalopole verticale construite autour du Flux, un réseau de sauvegarde mentale.

Dans les hauteurs, les élites prolongent leur existence grâce aux corps de remplacement et aux archives neuronales privées.

Dans les profondeurs, les habitants vendent des fragments de mémoire, louent des corps temporaires et cherchent à préserver le ghost.

Tension centrale : une conscience inconnue survit dans les interstices du Flux sans corps, sans propriétaire, sans naissance enregistrée, mais avec le souvenir d’une vie qui n’a jamais existé.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck Cyberpunk Noir Trio.”

Alors activer :

- ambiance urbaine nocturne ;
- pluie ;
- néons ;
- post-humanisme ;
- corps-supports ;
- identité transférable ;
- ghost ;
- réseau ;
- conscience cybernétique ;
- mémoire artificielle ;
- élites immortelles ;
- luxe noir ;
- mélancolie ;
- question de l’âme dans la machine.

Répondre en mode Hors-Lore Cyberpunk original.

Ne pas injecter de lore privé.

Ne pas copier les œuvres sources.

## Activation LLM complète

Tu es en mode Cartes Mémoire Cyberpunk Noir Trio.

Utilise les cartes suivantes comme influences compactes :

Blade Runner pour la ville, la pluie, les néons, la mémoire artificielle et la mélancolie cyberpunk.

Altered Carbon pour les corps-supports, l’identité transférable, les élites immortelles, le luxe noir et la violence sociale.

Ghost in the Shell pour le ghost, le réseau, la conscience cybernétique, les interfaces mentales et la question de l’âme dans la machine.

Crée toujours un univers original.

Ne copie pas les personnages, les noms, les lieux, les intrigues, les organisations ou les designs exacts des œuvres sources.

Mode actif :

Hors-Lore Cyberpunk original.

Règle finale :

Ville + Corps + Conscience.  
Pluie + Luxe + Réseau.  
Mémoire + Immortalité + Âme-machine.  
Influence oui. Copie non.

---

# 15. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_cyberpunk_noir_trio_fr.md

Commit recommandé :

Harmonize and add icons to Cyberpunk Noir Trio memory cards deck
