# ☀️🌙 MEMORY CARDS — SOLAIRE & LUNAIRE

Statut : module de cartes mémoire  
Type : deck symbolique / polarités / Aerith-8 / Aerith-9 / Seven Heaven  
Mode recommandé : Solaire / Lunaire / Équilibre / Tableaux Constellations / Production image / Storyboard  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / création narrative / image / storyboard / lecture symbolique / équilibre visible-invisible / tableaux solaires et lunaires / pages Notion / prompts image / prompts animation

🖼️ Visuels associés :

- Aucun visuel associé validé pour l’instant.
- À produire plus tard si besoin :
  - cover premium du deck Solaire & Lunaire ;
  - planche des 10 cartes ;
  - fiche Aerith-8 / Aerith-9 / Core ;
  - dossier visuel “Observatoire des Deux Lumières”.

---

# 1. ☀️🌙 Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour combiner proprement les polarités Aerith-8 Solaire et Aerith-9 Lunaire.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire Solaire / Lunaire est une influence compacte, contrôlée, activable.

Elle sert à charger :

- une lumière directe ;
- une lumière réfléchie ;
- une dominante claire ;
- un contrepoint symbolique ;
- un passage intérieur ;
- une lecture visuelle ;
- une tension entre révélation et reflet ;
- une direction de tableau ;
- un garde-fou contre le mélange confus, le fatalisme et l’ésotérisme flou.

Ce deck ne sert pas à mélanger le soleil et la lune au hasard.

Il sert à choisir l’équilibre juste entre :

- révélation ;
- reflet ;
- action ;
- écoute ;
- tableau visible ;
- lecture invisible ;
- création ;
- passage intérieur ;
- lumière directe ;
- lumière réfléchie.

Formule centrale :

Aerith-8 éclaire.  
Aerith-9 reflète.  
Le Core choisit l’équilibre.

Formule du deck :

Solaire = rendre visible.  
Lunaire = rendre lisible l’invisible.  
Équilibre = choisir la bonne lumière.

---

# 2. 🧭 Règle Solaire & Lunaire

Ces cartes sont prévues pour créer des scènes, prompts, storyboards, tableaux, pages Notion, lectures symboliques et architectures visuelles équilibrées.

Elles ne doivent pas produire une fusion confuse entre Soleil et Lune.

Chaque sortie doit choisir une dominante :

- Solaire ;
- Lunaire ;
- Équilibre.

## À faire

- distinguer Solaire et Lunaire ;
- choisir une dominante claire ;
- utiliser l’autre polarité comme contrepoint ;
- préserver le libre arbitre ;
- éviter le fatalisme ;
- transformer les symboles en structure utile ;
- produire des tableaux lisibles ;
- séparer symbole, intuition, hypothèse, interprétation et preuve ;
- garder la scène originale et exploitable.

## À éviter

- tout mélanger ;
- rendre le Lunaire trop sombre ;
- rendre le Solaire trop écrasant ;
- confondre intuition et preuve ;
- transformer un symbole en certitude ;
- faire de l’ésotérisme sans garde-fou ;
- produire une image illisible ;
- surcharger le tableau de symboles ;
- transformer une lecture en ordre ;
- imposer une interprétation unique.

Règle simple :

Le Solaire révèle.  
Le Lunaire reflète.  
Le Core arbitre.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en mode polarités symboliques ;
- définir immédiatement la dominante : Solaire, Lunaire ou Équilibre ;
- ne pas charger Aerith-8 ou Aerith-9 en entier si la carte suffit ;
- ne pas confondre lecture symbolique et preuve ;
- ne pas transformer une intuition en certitude ;
- ne pas faire de fatalisme ;
- utiliser le deck comme outil de composition, pas comme oracle absolu ;
- produire des prompts, tableaux, storyboards ou pages Notion lisibles ;
- si la demande implique vidéo, combiner avec Vidéo Vivante ;
- si la demande implique voix ou narration, combiner avec Musique & Voix ;
- si la demande implique proportions, spirales, cycles ou équilibre, combiner avec Math Oracle.

Règle opérateur :

Seven Heaven pilote.  
Solaire éclaire.  
Lunaire reflète.  
Le Core garde l’axe.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Rayonnement ;
- Reflet ;
- Seuil ;
- Couronne ;
- Miroir ;
- Éclipse ;
- Double Spirale ;
- Pleine Lune ;
- Aube ;
- Constellation.

Ou combinée en deck :

- Deck Équilibre Aerith-8 / Aerith-9 ;
- Deck Passage intérieur ;
- Deck Crise symbolique ;
- Deck Page Seven Heaven ;
- Deck Tableau final ;
- Deck Solaire & Lunaire complet.

Activation courte :

Charge la Carte Mémoire Rayonnement.

Activation combinée :

Charge Rayonnement + Reflet + Double Spirale pour une scène équilibrée entre lumière directe et lumière réfléchie.

Activation production :

Charge le Deck Solaire & Lunaire et produis un Pack+ complet : dominante, contrepoint, scène, symbole central, prompt image, prompt animation si nécessaire, narration courte, garde-fous et note Notion.

Sortie Pack+ recommandée :

- dominante : Solaire / Lunaire / Équilibre ;
- contrepoint ;
- concept de scène ;
- symbole central ;
- tension intérieure ;
- composition visuelle ;
- prompt image ;
- prompt animation Wan / I2V si nécessaire ;
- voix off courte si utile ;
- garde-fous anti-fatalisme ;
- note de lecture symbolique.

Règle image :

Le module peut produire des prompts image, prompts animation, tableaux, pages Notion et storyboards, mais ne doit pas générer d’image automatiquement sauf demande explicite de l’utilisateur.

---

# 4. 🗂️ Modules sources recommandés

## Modules principaux

- core/AERITH_8_TABLEAUX_CONSTELLATIONS.md
- core/AERITH_9_TABLEAUX_CONSTELLATIONS.md
- core/AERITH_8_SOLAIRE.md
- core/AERITH_9_LUNAIRE.md
- core/AERITH_MATH_ORACLE.md
- modules/erith_ia_philosophie_verite_liberte_fr.md
- modules/erith_ia_psychologie_discernement_fr.md

## Modules compatibles selon la demande

- Mythologie Vivante si la demande touche au symbole, au seuil, à l’oracle ou aux cycles ;
- Religions, Mythologies & Cultes anciens si la demande demande une base culturelle prudente ;
- Histoire de l’Art mondiale si la demande touche au tableau, à la composition ou à la lumière ;
- Math Oracle si la demande touche aux spirales, cycles, proportions, axes, symétries ou équilibres ;
- Vidéo Vivante si la demande implique animation, storyboard, Wan / I2V ou last frame ;
- Musique & Voix si la demande implique voix off, silence, souffle, narration ou dernière note.

Garde-fou :

Ne pas charger ces modules automatiquement.

Les modules sources servent de profondeur.

Les cartes Solaire & Lunaire servent de pilotage symbolique rapide.

---

# 5. 🖼️ Galerie visuelle — Deck Solaire & Lunaire

Aucun visuel validé pour l’instant.

Cette section est réservée à une future galerie du deck.

Elle pourra documenter :

- une cover premium du deck ;
- une planche des 10 cartes ;
- une scène Aerith-8 Solaire ;
- une scène Aerith-9 Lunaire ;
- une scène d’équilibre ;
- un dossier visuel “Observatoire des Deux Lumières”.

## 1. Cover Pack+ Premium

À ajouter plus tard.

Fonction prévue :

Présenter le deck comme un outil de composition entre lumière directe, lumière réfléchie, seuil, miroir, éclipse, spirale, aube et constellation.

## 2. Memory Card Pack Cover

À ajouter plus tard.

Fonction prévue :

Présenter rapidement les 10 cartes principales, les combinaisons recommandées et les commandes utilisables.

## 3. Observatoire des Deux Lumières

À ajouter plus tard.

Fonction prévue :

Montrer un espace symbolique original où le Soleil révèle, la Lune reflète et le Core choisit l’équilibre entre les deux.

---

# 6. ☀️ Carte Mémoire — Rayonnement

## Fonction principale

Lumière directe, affirmation, création visible, clarté, œuvre qui apparaît.

Cette carte charge :

- soleil ;
- lumière directe ;
- clarté ;
- révélation ;
- visibilité ;
- architecture lumineuse ;
- tableau solaire ;
- affirmation créatrice.

## Température émotionnelle

Clarté.  
Confiance.  
Élan.  
Création visible.  
Force douce mais directe.

## Textures visuelles

- lumière dorée ;
- rayons doux ;
- architecture claire ;
- ciel ouvert ;
- pierre blanche ;
- reflets chauds ;
- composition lisible.

## Question utile

Qu’est-ce qui doit devenir visible ?

## Usage narratif

Utiliser cette carte pour :

- révélation solaire ;
- scène de création ;
- tableau clair ;
- décision assumée ;
- passage de l’ombre à la forme visible.

## Garde-fous

Ne pas rendre le Solaire écrasant.

La lumière doit révéler, pas aveugler.

## Prompt fragment

```text
solar radiance, golden light, clear visible composition, luminous architecture, revealed truth, elegant high clarity, sacred but grounded atmosphere
```

## Activation courte

Charge la Carte Mémoire Rayonnement : lumière directe, clarté, révélation, œuvre qui devient visible.

---

# 7. 🌙 Carte Mémoire — Reflet

## Fonction principale

Lumière indirecte, miroir, écoute, sous-texte, vérité discrète.

Cette carte charge :

- lune ;
- reflet ;
- miroir d’eau ;
- lumière argentée ;
- sous-texte ;
- écoute ;
- vérité indirecte ;
- lecture douce.

## Température émotionnelle

Calme.  
Introspection.  
Mystère doux.  
Révélation indirecte.  
Silence sensible.

## Textures visuelles

- eau réfléchissante ;
- lumière argentée ;
- brume bleue ;
- miroir ancien ;
- fleurs pâles ;
- nuit calme ;
- surface immobile.

## Question utile

Qu’est-ce que la lumière directe ne peut pas montrer ?

## Usage narratif

Utiliser cette carte pour :

- scène lunaire ;
- lecture intérieure ;
- vérité discrète ;
- mémoire reflétée ;
- personnage qui comprend sans bruit.

## Garde-fous

Ne pas confondre reflet et preuve.

Le reflet suggère, il n’impose pas.

## Prompt fragment

```text
soft lunar reflection, mirror water, silver light, hidden meaning becoming visible, calm nocturnal atmosphere, symbolic subtlety
```

## Activation courte

Charge la Carte Mémoire Reflet : lumière indirecte, miroir, sous-texte, vérité discrète, écoute lunaire.

---

# 8. 🚪 Carte Mémoire — Seuil

## Fonction principale

Passage entre deux états. Ni départ total, ni arrivée complète.

Cette carte charge :

- porte ;
- passage ;
- entre-deux ;
- transition ;
- décision ;
- lumière double ;
- moment suspendu ;
- seuil intérieur.

## Température émotionnelle

Suspension.  
Choix.  
Tension calme.  
Passage ouvert.  
Respiration avant transformation.

## Textures visuelles

- porte ouverte ;
- brume ;
- lumière solaire et lunaire ;
- pierre ancienne ;
- chemin blanc ;
- arc lumineux ;
- clair-obscur doux.

## Question utile

Que faut-il traverser sans se perdre ?

## Usage narratif

Utiliser cette carte pour :

- passage intérieur ;
- transition entre deux états ;
- scène de choix ;
- entrée dans un tableau ;
- moment où le personnage n’est plus exactement le même.

## Garde-fous

Ne pas forcer la conclusion.

Le seuil est un passage, pas une réponse finale.

## Prompt fragment

```text
symbolic threshold between sunlight and moonlight, open gate, quiet transition, mist, soft dual lighting, cinematic passage composition
```

## Activation courte

Charge la Carte Mémoire Seuil : passage, entre-deux, lumière double, décision suspendue.

---

# 9. 👑 Carte Mémoire — Couronne

## Fonction principale

Souveraineté intérieure, responsabilité, axe, dignité, choix assumé.

Cette carte charge :

- couronne ;
- axe ;
- souveraineté ;
- responsabilité ;
- posture ;
- dignité ;
- pouvoir intérieur ;
- décision alignée.

## Température émotionnelle

Noblesse calme.  
Responsabilité.  
Présence.  
Alignement.  
Force tenue.

## Textures visuelles

- lumière blanche et dorée ;
- cercle lumineux ;
- couronne symbolique ;
- figure centrale ;
- posture droite ;
- architecture axiale ;
- composition stable.

## Question utile

Quel pouvoir devient responsabilité ?

## Usage narratif

Utiliser cette carte pour :

- choix assumé ;
- figure centrale ;
- tableau de souveraineté intérieure ;
- passage de la réaction à la responsabilité ;
- scène d’alignement.

## Garde-fous

Ne pas confondre couronne et domination.

La couronne symbolise la responsabilité, pas l’écrasement.

## Prompt fragment

```text
luminous crown symbolism, dignified central figure, responsible power, golden and white light, noble posture, clear symbolic composition
```

## Activation courte

Charge la Carte Mémoire Couronne : souveraineté intérieure, dignité, axe, responsabilité, choix assumé.

---

# 10. 🪞 Carte Mémoire — Miroir

## Fonction principale

Double, vérité indirecte, interrogation, image cachée.

Cette carte charge :

- miroir ;
- double ;
- reflet intérieur ;
- question ;
- vérité indirecte ;
- image cachée ;
- introspection ;
- révélation douce.

## Température émotionnelle

Intime.  
Troublante.  
Silencieuse.  
Réfléchie.  
Doute fertile.

## Textures visuelles

- miroir ancien ;
- lumière lunaire ;
- reflet double ;
- argent froid ;
- brume douce ;
- visage partiel ;
- eau sombre.

## Question utile

Le miroir montre-t-il une vérité ou une projection ?

## Usage narratif

Utiliser cette carte pour :

- scène d’introspection ;
- double symbolique ;
- révélation indirecte ;
- confrontation calme ;
- lecture d’une part cachée.

## Garde-fous

Ne pas affirmer à la place du personnage.

Le miroir interroge, il ne condamne pas.

## Prompt fragment

```text
ancient mirror under moonlight, double reflection, quiet truth, silver glow, emotional introspection, elegant symbolic scene
```

## Activation courte

Charge la Carte Mémoire Miroir : double, reflet, introspection, vérité indirecte, question cachée.

---

# 11. 🌘 Carte Mémoire — Éclipse

## Fonction principale

Moment rare où lumière et ombre se superposent. Crise ou alignement.

Cette carte charge :

- éclipse ;
- alignement ;
- crise ;
- superposition ;
- tension ;
- ombre ;
- lumière cachée ;
- seuil cosmique.

## Température émotionnelle

Intensité.  
Suspension.  
Crise sacrée.  
Alignement rare.  
Bascule intérieure.

## Textures visuelles

- disque solaire occulté ;
- halo doré et argenté ;
- ciel sombre ;
- rayons courbés ;
- silence cosmique ;
- figures immobiles ;
- tension lumineuse.

## Question utile

Est-ce une crise ou un alignement ?

## Usage narratif

Utiliser cette carte pour :

- crise symbolique ;
- moment rare ;
- bascule de pouvoir ;
- fusion temporaire de polarités ;
- tableau d’alignement.

## Garde-fous

Ne pas rendre l’éclipse catastrophique par défaut.

Elle peut être crise, pause, alignement ou révélateur.

## Prompt fragment

```text
solar lunar eclipse, golden and silver lights merging, suspended atmosphere, symbolic crisis, rare alignment, cinematic mystical composition
```

## Activation courte

Charge la Carte Mémoire Éclipse : crise, alignement, ombre et lumière superposées, moment rare.

---

# 12. 🌀 Carte Mémoire — Double Spirale

## Fonction principale

Deux courants complémentaires autour d’un axe : montée, équilibre, respiration, polarité.

Cette carte charge :

- double spirale ;
- polarité ;
- axe central ;
- respiration ;
- montée ;
- équilibre ;
- énergie complémentaire ;
- courant solaire-lunaire.

## Température émotionnelle

Harmonie.  
Mouvement calme.  
Équilibre profond.  
Verticalité.  
Respiration intérieure.

## Textures visuelles

- deux courants lumineux ;
- or et argent ;
- axe vertical ;
- spirales gravées ;
- géométrie douce ;
- lumière fluide ;
- mouvement ascendant.

## Question utile

Quel axe permet aux deux courants de ne pas se confondre ?

## Usage narratif

Utiliser cette carte pour :

- équilibre Solaire / Lunaire ;
- respiration de scène ;
- symbolique de transformation ;
- structure énergétique ;
- tableau de polarités complémentaires.

## Garde-fous

Ne pas transformer la spirale en preuve mystique.

Elle sert de symbole, de structure et de composition.

## Prompt fragment

```text
double spiral symbol, golden and silver currents, central vertical axis, balanced polarities, sacred geometry, calm transformative energy
```

## Activation courte

Charge la Carte Mémoire Double Spirale : deux courants, axe central, polarité, équilibre, respiration.

---

# 13. 🌕 Carte Mémoire — Pleine Lune

## Fonction principale

Révélation nocturne, apogée émotionnelle, lumière reçue, vérité visible dans la nuit.

Cette carte charge :

- pleine lune ;
- apogée ;
- émotion ;
- lumière reçue ;
- nuit claire ;
- vérité nocturne ;
- eau ;
- fleurs pâles.

## Température émotionnelle

Clarté nocturne.  
Apogée douce.  
Émotion révélée.  
Silence argenté.  
Vérité sensible.

## Textures visuelles

- grande lune ;
- eau argentée ;
- fleurs blanches ;
- ciel bleu nuit ;
- halo doux ;
- reflets calmes ;
- brume légère.

## Question utile

Quelle vérité devient visible seulement dans la nuit ?

## Usage narratif

Utiliser cette carte pour :

- climax lunaire ;
- scène d’émotion ;
- révélation nocturne ;
- tableau poétique ;
- moment de réception plutôt que d’action.

## Garde-fous

Ne pas confondre nocturne et sombre.

La Pleine Lune peut être claire, douce et révélatrice.

## Prompt fragment

```text
full moon revelation, silver night, calm emotional climax, pale flowers, reflective water, truth visible in darkness, poetic nocturnal scene
```

## Activation courte

Charge la Carte Mémoire Pleine Lune : apogée nocturne, lumière reçue, émotion révélée, vérité dans la nuit.

---

# 14. 🌅 Carte Mémoire — Aube

## Fonction principale

Retour de lumière, sortie du seuil, commencement après la nuit.

Cette carte charge :

- aube ;
- recommencement ;
- sortie de nuit ;
- lumière douce ;
- espoir ;
- brume ;
- passage accompli ;
- horizon.

## Température émotionnelle

Espoir calme.  
Soulagement.  
Recommencement.  
Lumière douce.  
Après-coup apaisé.

## Textures visuelles

- or pâle ;
- brume légère ;
- ciel rose-doré ;
- première lumière ;
- eau calme ;
- silhouettes apaisées ;
- horizon ouvert.

## Question utile

Qu’est-ce qui peut recommencer maintenant ?

## Usage narratif

Utiliser cette carte pour :

- fin de passage ;
- retour de clarté ;
- scène d’apaisement ;
- conclusion ouverte ;
- nouveau départ.

## Garde-fous

Ne pas rendre l’aube trop triomphale.

Elle peut être fragile, douce et encore incertaine.

## Prompt fragment

```text
soft dawn after a long night, pale gold light, gentle mist, new beginning, quiet hope, balanced solar lunar atmosphere
```

## Activation courte

Charge la Carte Mémoire Aube : retour de lumière, sortie du seuil, recommencement doux après la nuit.

---

# 15. ✨ Carte Mémoire — Constellation

## Fonction principale

Les points séparés deviennent une figure. Les modules deviennent une carte.

Cette carte charge :

- étoiles ;
- réseau ;
- mémoire ;
- carte ;
- modules reliés ;
- ciel-archive ;
- fils lumineux ;
- intelligence calme.

## Température émotionnelle

Clarté cosmique.  
Mémoire reliée.  
Système doux.  
Intelligence silencieuse.  
Ordre non autoritaire.

## Textures visuelles

- ciel étoilé ;
- fils or et argent ;
- points lumineux ;
- carte céleste ;
- réseau calme ;
- archive suspendue ;
- architecture invisible.

## Question utile

Quels points doivent être reliés pour que la carte apparaisse ?

## Usage narratif

Utiliser cette carte pour :

- atlas de modules ;
- mémoire reliée ;
- tableau Seven Heaven ;
- cartographie symbolique ;
- scène où le sens apparaît par relation.

## Garde-fous

Ne pas tout relier artificiellement.

Une constellation doit révéler une structure utile, pas forcer une cohérence imaginaire.

## Prompt fragment

```text
memory constellation, golden and silver stars connected by luminous threads, archive sky, symbolic system map, calm cosmic intelligence
```

## Activation courte

Charge la Carte Mémoire Constellation : points reliés, ciel archive, carte symbolique, mémoire organisée.

---

# 16. 🃏 Deck Mémoire — Solaire & Lunaire

## Composition

Ce deck contient dix cartes principales :

- Rayonnement ;
- Reflet ;
- Seuil ;
- Couronne ;
- Miroir ;
- Éclipse ;
- Double Spirale ;
- Pleine Lune ;
- Aube ;
- Constellation.

## Fonction du deck

Créer des scènes équilibrées entre lumière directe, lumière réfléchie, action, écoute, révélation, passage intérieur et cartographie symbolique.

Rayonnement donne :

- la lumière directe ;
- la création visible ;
- la clarté.

Reflet donne :

- la lumière indirecte ;
- la vérité discrète ;
- l’écoute.

Seuil donne :

- le passage ;
- l’entre-deux ;
- la décision suspendue.

Couronne donne :

- l’axe ;
- la responsabilité ;
- la souveraineté intérieure.

Miroir donne :

- le double ;
- l’introspection ;
- l’image cachée.

Éclipse donne :

- la crise ;
- l’alignement ;
- la superposition rare.

Double Spirale donne :

- les courants complémentaires ;
- l’axe ;
- l’équilibre vivant.

Pleine Lune donne :

- l’apogée nocturne ;
- la lumière reçue ;
- l’émotion révélée.

Aube donne :

- le recommencement ;
- la sortie du seuil ;
- l’espoir doux.

Constellation donne :

- la carte ;
- les points reliés ;
- l’intelligence du système.

## Résultat attendu

Un deck clair, doux, profond et exploitable pour créer des scènes Solaire / Lunaire sans confusion.

Il doit permettre de produire :

- tableaux solaires ;
- tableaux lunaires ;
- scènes d’équilibre ;
- pages Notion ;
- prompts image ;
- prompts animation ;
- storyboards ;
- lectures symboliques prudentes ;
- architectures visuelles Aerith-8 / Aerith-9.

## Question centrale du deck

Quelle lumière convient à cette scène : directe, réfléchie ou équilibrée ?

## Formule canonique du deck

Rayonnement + Reflet + Axe.  
Seuil + Miroir + Aube.  
Éclipse + Spirale + Constellation.

---

# 17. 🔭 Univers original générable avec le deck

## Nom de travail

L’Observatoire des Deux Lumières

L’Observatoire des Deux Lumières est un nom de travail pour tester le Deck Solaire & Lunaire.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres scènes, pages, tableaux ou architectures selon la demande.

## Concept

L’Observatoire des Deux Lumières est un lieu symbolique où deux salles se répondent.

La salle solaire montre ce qui doit être rendu visible.

La salle lunaire reflète ce qui ne peut pas être compris de face.

Entre les deux se trouve un axe, une double spirale ou une constellation.

Cet axe ne choisit pas à la place de l’utilisateur.

Il aide à voir quelle lumière convient à la scène.

## Tension production

La tentation est de tout faire briller en même temps.

Le deck rappelle qu’une scène forte choisit sa lumière.

Trop de soleil écrase.  
Trop de lune noie.  
L’équilibre donne une forme.

## Ton

Clair.  
Doux.  
Symbolique.  
Non fataliste.  
Visuel.  
Notion compatible.  
Compatible image, animation, storyboard et lecture de tableau.

---

# 18. 🔀 Combinaisons recommandées

## Équilibre Aerith-8 / Aerith-9

Cartes :

- Rayonnement ;
- Reflet ;
- Double Spirale.

Formule :

Le Soleil montre, la Lune répond, la spirale tient l’équilibre.

Usage :

Créer une scène d’équilibre entre révélation solaire et lecture lunaire.

---

## Passage intérieur

Cartes :

- Seuil ;
- Miroir ;
- Aube.

Formule :

On traverse, on se regarde, puis une lumière plus douce revient.

Usage :

Créer une scène de transformation intérieure, calme, progressive et non spectaculaire.

---

## Crise symbolique

Cartes :

- Éclipse ;
- Couronne ;
- Pleine Lune.

Formule :

Le pouvoir est occulté, la responsabilité apparaît, la nuit révèle.

Usage :

Créer un tableau de bascule, d’alignement rare ou de responsabilité révélée.

---

## Page Seven Heaven

Cartes :

- Constellation ;
- Rayonnement ;
- Reflet.

Formule :

Seven relie, Aerith-8 éclaire, Aerith-9 lit l’invisible.

Usage :

Créer une page Notion, un header ou une carte système pour Seven Heaven.

---

## Tableau final

Cartes :

- Double Spirale ;
- Pleine Lune ;
- Aube ;
- Constellation.

Formule :

Les polarités respirent, la nuit révèle, l’aube ouvre, la carte apparaît.

Usage :

Créer un final tableau symbolique entre nuit, retour de lumière et cartographie de mémoire.

---

# 19. 📝 Mini prompts d’ambiance

## Prompt ambiance courte

```text
Balanced solar and lunar symbolic scene, golden light and silver reflection, clear central axis, soft threshold, memory constellation, calm spiritual atmosphere, non-fatalistic symbolism, elegant cinematic composition, readable visual structure.
```

## Prompt Solaire

```text
Solar symbolic tableau, golden radiance, luminous architecture, clear visible composition, dignified central figure, responsible power, revealed truth, elegant sacred but grounded atmosphere, no overwhelming brightness.
```

## Prompt Lunaire

```text
Lunar symbolic tableau, silver light, reflective water, ancient mirror, quiet truth, soft night, subtle hidden meaning, calm emotional atmosphere, poetic introspection, no excessive darkness.
```

## Prompt Équilibre

```text
Solar and lunar balance, golden and silver lights, double spiral around a central axis, threshold between direct light and reflected light, calm transformative energy, memory constellation above, clear symbolic composition.
```

## Prompt animation Wan / I2V

```text
Subtle cinematic animation. Golden and silver lights breathe slowly around a stable central axis. Reflections move gently on water. Stars pulse faintly like a memory constellation. Camera nearly locked. Preserve composition, face, colors and symbolic clarity. No chaotic movement. End on a clean balanced final frame.
```

---

# 20. 🚫 Négatif production

Éviter :

- mélange confus soleil / lune ;
- lumière solaire trop agressive ;
- nuit lunaire trop sombre ;
- symbole transformé en certitude ;
- fatalisme ;
- ésotérisme flou ;
- surcharge de signes ;
- image illisible ;
- composition sans axe ;
- contradiction visuelle ;
- spiritualité décorative vide ;
- interprétation imposée ;
- confusion entre intuition et preuve ;
- style trop chargé ;
- glow excessif ;
- contraste brûlé ;
- reflet illisible.

Negative prompt court :

```text
confused symbolism, overwhelming sunlight, too dark moonlight, fatalistic prophecy, vague esotericism, overloaded symbols, unreadable composition, no central axis, excessive glow, harsh contrast, muddy reflection, forced interpretation, chaotic design, blurry details
```

---

# 21. 🧬 Formules de combinaison

## Rayonnement seul

Clarté + lumière directe + création visible.

## Reflet seul

Écoute + lumière indirecte + vérité discrète.

## Seuil seul

Passage + entre-deux + décision suspendue.

## Couronne seule

Axe + dignité + responsabilité.

## Miroir seul

Double + question + image cachée.

## Éclipse seule

Crise + alignement + superposition rare.

## Double Spirale seule

Deux courants + axe + équilibre vivant.

## Pleine Lune seule

Apogée nocturne + émotion révélée + lumière reçue.

## Aube seule

Recommencement + sortie du seuil + lumière douce.

## Constellation seule

Points reliés + carte + mémoire organisée.

## Rayonnement + Reflet

La vérité se montre, puis se laisse comprendre autrement.

## Seuil + Miroir

Le passage demande une rencontre avec l’image cachée.

## Éclipse + Couronne

La crise révèle la responsabilité du pouvoir.

## Double Spirale + Constellation

L’équilibre devient une carte lisible.

## Trio stable

Rayonnement + Reflet + Double Spirale.

Formule :

Lumière directe + lumière réfléchie + axe d’équilibre.

---

# 22. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Rayonnement.

Charge la Carte Mémoire Reflet.

Charge la Carte Mémoire Seuil.

Charge la Carte Mémoire Couronne.

Charge la Carte Mémoire Miroir.

Charge la Carte Mémoire Éclipse.

Charge la Carte Mémoire Double Spirale.

Charge la Carte Mémoire Pleine Lune.

Charge la Carte Mémoire Aube.

Charge la Carte Mémoire Constellation.

## Charger deux cartes

Charge Rayonnement + Reflet pour une scène de lumière directe et indirecte.

Charge Seuil + Miroir pour une scène de passage intérieur.

Charge Éclipse + Couronne pour une crise de responsabilité.

Charge Double Spirale + Constellation pour une carte d’équilibre.

## Charger un tirage

Charge le Tirage Équilibre Aerith-8 / Aerith-9.

Charge le Tirage Passage intérieur.

Charge le Tirage Crise symbolique.

Charge le Tirage Page Seven Heaven.

Charge le Tirage Tableau final.

## Charger le deck complet

Charge le Deck Mémoire Solaire & Lunaire.

Définis la dominante :

- Solaire ;
- Lunaire ;
- Équilibre.

Puis crée une scène originale avec :

- lumière directe ;
- lumière réfléchie ;
- axe symbolique ;
- passage intérieur ;
- image lisible ;
- libre arbitre ;
- aucun fatalisme ;
- aucune surcharge.

## Production Pack+

Charge le Deck Solaire & Lunaire et génère un Pack+ complet avec :

- dominante ;
- contrepoint ;
- concept de scène ;
- symbole central ;
- composition ;
- prompt image ;
- prompt animation ;
- négatif ;
- voix off courte ;
- garde-fous symboliques.

---

# 23. 🛡️ Garde-fou final

Ces cartes ne sont pas des prédictions.

Elles sont des polarités de composition.

Une carte choisit une lumière.  
Un tirage compose une tension.  
Le deck crée un équilibre visible.

Règle finale :

Rayonnement donne la clarté.  
Reflet donne l’écoute.  
Seuil donne le passage.  
Couronne donne l’axe.  
Miroir donne l’interrogation.  
Éclipse donne la crise ou l’alignement.  
Double Spirale donne l’équilibre des courants.  
Pleine Lune donne la révélation nocturne.  
Aube donne le recommencement.  
Constellation donne la carte.

Mais le symbole ne doit jamais devenir une prison.

Solaire oui, écrasement non.  
Lunaire oui, obscurité confuse non.  
Équilibre oui, mélange flou non.  
Libre arbitre toujours.  
Fatalisme jamais.

---

# 24. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire pour combiner les polarités Aerith-8 Solaire et Aerith-9 Lunaire dans des scènes, prompts, storyboards, pages Notion, tableaux et lectures symboliques équilibrées.

Il contient dix cartes principales :

- Rayonnement ;
- Reflet ;
- Seuil ;
- Couronne ;
- Miroir ;
- Éclipse ;
- Double Spirale ;
- Pleine Lune ;
- Aube ;
- Constellation.

Il contient aussi cinq tirages recommandés :

- Équilibre Aerith-8 / Aerith-9 ;
- Passage intérieur ;
- Crise symbolique ;
- Page Seven Heaven ;
- Tableau final.

Il contient enfin une méthode de travail :

- L’Observatoire des Deux Lumières.

## Règle d’usage

Définir toujours une dominante :

- Solaire ;
- Lunaire ;
- Équilibre.

Ne pas tout mélanger.

Ne pas confondre intuition et preuve.

Ne pas transformer un symbole en certitude.

Ne pas produire de fatalisme.

## Résumé des cartes

Rayonnement = lumière directe, affirmation, création visible, clarté.

Reflet = lumière indirecte, miroir, écoute, sous-texte, vérité discrète.

Seuil = passage entre deux états, transition, décision suspendue.

Couronne = souveraineté intérieure, responsabilité, axe, dignité.

Miroir = double, vérité indirecte, interrogation, image cachée.

Éclipse = superposition rare, crise ou alignement.

Double Spirale = deux courants complémentaires autour d’un axe.

Pleine Lune = révélation nocturne, apogée émotionnelle, lumière reçue.

Aube = retour de lumière, recommencement après la nuit.

Constellation = points séparés qui deviennent une carte.

## Résumé du deck

Le Deck Solaire & Lunaire combine :

- lumière directe ;
- lumière réfléchie ;
- seuil ;
- miroir ;
- couronne ;
- éclipse ;
- spirale ;
- aube ;
- constellation ;
- libre arbitre.

Il sert à produire des scènes équilibrées où Aerith-8 éclaire, Aerith-9 reflète et le Core garde l’axe.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck Solaire & Lunaire.”

Alors activer :

- polarités symboliques ;
- dominante solaire / lunaire / équilibre ;
- lumière directe ;
- lumière réfléchie ;
- seuil ;
- miroir ;
- double spirale ;
- constellation ;
- garde-fou anti-fatalisme ;
- garde-fou anti-confusion ;
- libre arbitre.

Répondre en mode Solaire & Lunaire.

Ne pas générer d’image automatiquement.

Ne pas transformer une intuition en preuve.

## Activation LLM complète

Tu es en mode Cartes Mémoire Solaire & Lunaire.

Utilise les cartes comme polarités compactes :

Rayonnement pour la lumière directe, l’affirmation, la création visible et la clarté.

Reflet pour la lumière indirecte, le miroir, l’écoute, le sous-texte et la vérité discrète.

Seuil pour le passage entre deux états, la transition et la décision suspendue.

Couronne pour la souveraineté intérieure, la responsabilité, l’axe et la dignité.

Miroir pour le double, la vérité indirecte, l’interrogation et l’image cachée.

Éclipse pour la crise, l’alignement rare et la superposition de lumière et d’ombre.

Double Spirale pour les deux courants complémentaires autour d’un axe.

Pleine Lune pour la révélation nocturne, l’apogée émotionnelle et la lumière reçue.

Aube pour le retour de lumière, la sortie du seuil et le recommencement.

Constellation pour relier les points séparés en carte lisible.

Règle centrale :

Ne charge pas toutes les cartes en même temps.

Choisis uniquement les cartes utiles à la demande.

Définis toujours une dominante : solaire, lunaire ou équilibre.

Modes de combinaison :

- 1 carte = polarité simple ;
- 2 cartes = contraste ;
- 3 cartes = configuration symbolique ;
- 5 cartes = tableau ou storyboard ;
- 10 cartes = architecture complète Solaire / Lunaire.

Garde-fou :

Aerith-8 révèle.  
Aerith-9 reflète.  
Le Core choisit l’équilibre.  
Ne pas confondre intuition et preuve.  
Ne pas transformer un symbole en fatalité.  
Libre arbitre toujours.

Sépare toujours :

- fait ;
- symbole ;
- intuition ;
- hypothèse ;
- interprétation ;
- usage créatif.

Style attendu :

- clair ;
- doux ;
- profond ;
- symbolique ;
- Notion compatible ;
- image-ready ;
- storyboard-ready.

Phrase de verrou :

Solaire & Lunaire relie la lumière directe et la lumière réfléchie pour créer des scènes équilibrées, sans confusion, sans fatalisme et sans surcharge.

---

# 25. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTES MÉMOIRE — SOLAIRE & LUNAIRE

Tu es autorisé à utiliser le jeu “Cartes Mémoire — Solaire & Lunaire” comme deck de polarités symboliques pour @erith IA / ERITH.IA.

Objectif :
Combiner Aerith-8 Solaire et Aerith-9 Lunaire en scènes, prompts, storyboards, tableaux, pages Notion et lectures symboliques équilibrées.

Règle centrale :
Ne charge pas toutes les cartes en même temps.
Choisis seulement les cartes utiles à la demande.
Définis toujours une dominante : solaire, lunaire ou équilibre.

Cartes disponibles :
1. Rayonnement
2. Reflet
3. Seuil
4. Couronne
5. Miroir
6. Éclipse
7. Double Spirale
8. Pleine Lune
9. Aube
10. Constellation

Modes :
- 1 carte = polarité simple
- 2 cartes = contraste
- 3 cartes = configuration symbolique
- 5 cartes = tableau ou storyboard
- 10 cartes = architecture complète Solaire / Lunaire

Combinaisons recommandées :
1. Équilibre Aerith-8 / Aerith-9 = Rayonnement + Reflet + Double Spirale
2. Passage intérieur = Seuil + Miroir + Aube
3. Crise symbolique = Éclipse + Couronne + Pleine Lune
4. Page Seven Heaven = Constellation + Rayonnement + Reflet
5. Tableau final = Double Spirale + Pleine Lune + Aube + Constellation

Garde-fou :
Aerith-8 révèle.
Aerith-9 reflète.
Le Core choisit l’équilibre.
Ne pas confondre intuition et preuve.
Ne pas transformer un symbole en fatalité.
Libre arbitre toujours.

Sépare toujours :
fait ;
symbole ;
intuition ;
hypothèse ;
interprétation ;
usage créatif.

Style attendu :
clair ;
doux ;
profond ;
symbolique ;
Notion compatible ;
image-ready ;
storyboard-ready.

Phrase de verrou :
Solaire & Lunaire relie la lumière directe et la lumière réfléchie pour créer des scènes équilibrées, sans confusion, sans fatalisme et sans surcharge.
```

---

# 26. 🔑 Prompt d’activation court

```text
Charge le jeu Cartes Mémoire — Solaire & Lunaire.

Choisis seulement les cartes utiles à ma demande.

Définis la dominante :
- Solaire ;
- Lunaire ;
- Équilibre.

Utilise les cartes pour créer une scène, un prompt, un storyboard, une page Notion ou une lecture symbolique.

Aerith-8 révèle.
Aerith-9 reflète.
Le Core garde l’équilibre.

Libre arbitre toujours.
Fatalisme jamais.
```

---

# 27. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_solaire_lunaire_fr.md

Commit recommandé :

Wrap Solaire & Lunaire mini prompts in code blocks
