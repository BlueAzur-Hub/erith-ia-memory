# 📖 ATLAS_OEUVRES_FONDATRICES_FR

## 🎯 Mission

Cartographier les grandes œuvres qui ont façonné les civilisations humaines.

Cet atlas complète :

- ATLAS_EXTENSIONS_CULTURES_ARTS_RELIGIONS_FR.md
- ATLAS_AUTEURS_FONDATEURS_FR.md

Il répond à la question :

Quels sont les textes, récits, épopées, chroniques et œuvres qui ont traversé les siècles et influencé durablement les cultures humaines ?

---

# 🏺 Mésopotamie

## Épopée de Gilgamesh

- Type : épopée
- Statut module : ⏳ À créer
- Importance : l'une des plus anciennes grandes œuvres littéraires connues.

---

# 🌊 Inde

## Mahabharata

- Auteur traditionnel : Vyāsa
- Statut module : ✅ Existant

## Ramayana

- Auteur traditionnel : Valmiki
- Statut module : ✅ Existant

---

# 👑 Perse

## Shahnameh

- Auteur : Ferdowsi
- Statut module : ⏳ À créer

---

# 🏛️ Grèce

## Iliade

- Auteur traditionnel : Homère
- Statut module : ⏳ À créer

## Odyssée

- Auteur traditionnel : Homère
- Statut module : ⏳ À créer

## Théogonie

- Auteur : Hésiode
- Statut module : ⏳ À créer

---

# 🦅 Rome

## Énéide

- Auteur : Virgile
- Statut module : ⏳ À créer

---

# 🌲 Monde celtique

## Táin Bó Cúailnge

- Statut module : ⏳ À créer

## Mabinogion

- Statut module : ⏳ À créer

---

# ⚔️ Monde nordique

## Edda poétique

- Statut module : ⏳ À créer

## Edda en prose

- Auteur : Snorri Sturluson
- Statut module : ⏳ À créer

## Saga des Volsung

- Statut module : ⏳ À créer

## Beowulf

- Statut module : ⏳ À créer

---

# 🐉 Chine

## Tao Te King

- Auteur traditionnel : Lao Tseu
- Statut module : ⏳ À créer

## Zhuangzi

- Statut module : ⏳ À créer

## Art de la Guerre

- Auteur : Sun Tzu
- Statut module : ✅ Existant

## Yi Jing

- Statut module : ⏳ À créer

---

# 🏯 Japon

## Kojiki

- Statut module : ⏳ À créer

## Nihon Shoki

- Statut module : ⏳ À créer

## Dit du Genji

- Auteur : Murasaki Shikibu
- Statut module : ⏳ À créer

---

# 🌍 Afrique

## Épopée de Soundiata

- Statut module : ⏳ À créer

---

# 🦅 Amériques

## Popol Vuh

- Statut module : ⏳ À créer

---

# 🌉 Usage ERITH.IA

Cet atlas sert de carte de navigation pour identifier les œuvres déjà couvertes, celles à approfondir et les futurs modules mémoire.

Formule :

Les civilisations bâtissent.
Les auteurs transmettent.
Les œuvres traversent le temps.
