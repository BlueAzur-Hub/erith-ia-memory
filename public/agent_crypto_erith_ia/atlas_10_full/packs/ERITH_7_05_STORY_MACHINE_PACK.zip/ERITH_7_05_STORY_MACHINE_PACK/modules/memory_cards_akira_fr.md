# 🏍️ MEMORY CARDS — AKIRA / VELOCITY V2

Statut : module de carte mémoire privée  
Type : carte d’ambiance activable / module d’influence visuelle, narrative et production  
Mode recommandé : Hors-Lore Science-Fiction Urbaine / Seven Heaven privé si demandé  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / prompt image / prompt animation / narration / worldbuilding / Pack+ / direction artistique

---

# 🖼️ Galerie visuelle immédiate

## 🏍️ Cover Pack+ Rider / Bike

![ERITH.IA — Akira Rider Bike Pack+ Cover](../assets/images/erith_ia_memory_card_akira_rider_bike_pack_plus_cover_premium_v2.png)

Chemin GitHub :

assets/images/erith_ia_memory_card_akira_rider_bike_pack_plus_cover_premium_v2.png

Cette image est la première cover du Pack+ Akira.

Elle sert à ouvrir la carte, à présenter l’énergie visuelle du module et à montrer immédiatement le produit : rider original, moto futuriste, ville monumentale, vitesse, éveil mental, mutation et direction artistique rouge / noir / blanc / gris.

---

## 🗂️ Dossier Pack+ Rider / Bike

![ERITH.IA — Akira Rider Bike Pack+ Dossier](../assets/images/erith_ia_memory_card_akira_rider_bike_pack_plus_dossier_premium_v1.png)

Chemin GitHub :

assets/images/erith_ia_memory_card_akira_rider_bike_pack_plus_dossier_premium_v1.png

Cette image sert de premier dossier visuel détaillé.

Elle synthétise l’usage de la carte : univers, personnage, vitesse, énergie mentale, mutation, trajectoire, prompt image, prompt animation, narration courte, garde-fou créatif et logique Pack+.

---

## 🌃 Akira Velocity V2

![ERITH.IA — Akira Velocity V2](../assets/images/erith_ia_memory_card_akira_velocity_v2.png)

Chemin GitHub :

assets/images/erith_ia_memory_card_akira_velocity_v2.png

Statut : emplacement réservé pour l’image finale V2.

Cette image sera produite après validation de la carte.

Elle doit remplacer la logique trop glossy / CGI par une direction artistique plus proche d’une animation japonaise cyberpunk de la fin des années 80 : image dessinée, nuit, vitesse extrême, course-poursuite entre jeunes motards, ville gigantesque, palette rouge / noir / blanc cassé / gris béton / bleu froid discret.

Nom final de l’image :

erith_ia_memory_card_akira_velocity_v2.png

---

# 1. 🧭 Rôle du fichier

Ce fichier définit la Carte Mémoire Akira pour le GitHub privé du projet @erith IA / ERITH.IA.

Cette carte n’est pas une encyclopédie.

Elle ne sert pas à résumer toute l’œuvre source.

Elle sert à charger rapidement une influence de production :

- une direction artistique ;
- une tension urbaine ;
- une énergie visuelle ;
- un type de personnage ;
- une logique de vitesse ;
- une logique d’éveil / mutation ;
- une base de Pack+ ;
- des prompts image ;
- des prompts animation ;
- un garde-fou contre la copie.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire = ambiance rapide.  
Pack+ = sortie exploitable.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

---

# 2. 🛡️ Règle Hors-Lore

Cette carte est prévue pour créer des univers originaux.

Elle ne doit pas copier Akira.

Elle ne doit pas reproduire les personnages, l’intrigue, les scènes, les véhicules exacts ou les compositions iconiques.

## 🚫 Interdit

- reprendre des personnages existants ;
- reprendre les noms propres de l’œuvre source ;
- reprendre l’intrigue ;
- reprendre une scène culte à l’identique ;
- reprendre un design exact ;
- reprendre une moto iconique à l’identique ;
- refaire une affiche connue ;
- produire un pastiche trop reconnaissable ;
- mélanger avec un lore privé non demandé.

## ✅ Autorisé

- reprendre une intensité visuelle ;
- reprendre une tension urbaine ;
- reprendre une direction graphique générale ;
- reprendre une question narrative large ;
- reprendre l’idée d’une ville sous pression ;
- reprendre l’idée d’une jeunesse traversée par la vitesse ;
- reprendre l’idée d’une puissance intérieure qui déborde ;
- transformer l’influence en monde autonome.

Règle simple :

Inspirer sans copier.  
Transformer sans imiter.  
Créer un monde neuf.

## 🧠 Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en Mode Hors-Lore original ;
- ne pas ramener le lore privé du projet ;
- ne pas transformer Aerith-7 en personnage de scène ;
- ne pas charger les modules complets si la carte suffit ;
- utiliser la carte comme filtre d’ambiance, pas comme encyclopédie ;
- produire des univers autonomes, exploitables en Pack+ ;
- distinguer influence, copie, hypothèse narrative et sortie de production.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire influence.  
Le Pack+ structure.  
L’univers généré reste original.

---

# 3. ⚙️ Usage général de la Carte Mémoire Akira

## Activation courte

Charge la Carte Mémoire Akira.

## Activation production

Charge la Carte Mémoire Akira et produis un Pack+ complet : univers, personnage, scène visuelle, prompt image, prompt animation, narration courte.

## Activation image

Charge la Carte Mémoire Akira et génère un prompt image pour une cover Pack+ : rider original, moto futuriste, ville monumentale, vitesse, éveil mental, mutation, influence oui, copie non.

## Activation V2

Charge la Carte Mémoire Akira Velocity V2.

Objectif : produire une carte ou une image nocturne avec course-poursuite, très haute vitesse, jeunes motards, mégapole gigantesque et direction artistique d’animation japonaise cyberpunk fin 80s.

## Activation animation

Charge la Carte Mémoire Akira et génère un prompt Wan / I2V pour animer une scène de course ou d’éveil mental, avec mouvement lisible et stabilité.

## Sortie Pack+ recommandée

- concept d’univers ;
- personnage original ;
- scène exploitable ;
- prompt image cover ;
- prompt image scène ;
- prompt animation Wan / I2V ;
- négatif production ;
- narration courte ;
- variante B ;
- garde-fous Hors-Lore ;
- note de continuité si la scène doit devenir une séquence vidéo.

Règle image :

Le module peut produire des prompts image ou animation, mais ne doit pas générer d’image automatiquement sauf demande explicite de Christophe.

---

# 4. 🏍️ Carte Mémoire — Akira

## Fonction principale

Science-fiction urbaine monumentale, vitesse, jeunesse, éveil mental et mutation.

Cette carte charge :

- la ville géante ;
- les routes suspendues ;
- les tours blanches et grises ;
- les panneaux rouges ;
- les motos futuristes ;
- les riders originaux ;
- la vitesse ;
- l’énergie mentale ;
- la mutation ;
- le danger de l’éveil ;
- la science hors contrôle ;
- la pression sociale ;
- l’impression de basculement imminent.

## Température émotionnelle

Tension.  
Vitesse.  
Jeunesse sous pression.  
Colère froide.  
Éveil dangereux.  
Ville trop grande.  
Corps qui dépasse sa limite.  
Futur propre en surface, instable dessous.

## Palette recommandée

Rouge signal.  
Noir profond.  
Blanc clinique.  
Gris béton.  
Bleu très froid en accent énergétique.

Éviter :

- néons génériques ;
- vert cyberpunk standard ;
- violet gratuit ;
- chaos coloré ;
- saleté décorative sans intention ;
- esthétique punk recette.

---

# 5. 🎨 Direction artistique détaillée

## Ville monumentale

La ville doit paraître immense, structurée, verticale et presque impossible à habiter.

Elle est composée de :

- tours blanches et grises ;
- structures rouges ;
- avenues suspendues ;
- échangeurs géants ;
- viaducs ;
- passerelles ;
- panneaux publics ;
- niveaux de circulation ;
- zones interdites ;
- surveillance aérienne.

La ville n’est pas un simple décor.

Elle est la pression du monde.

Elle surveille, organise, accélère et écrase.

## Vitesse

La vitesse n’est pas seulement une action.

C’est une identité.

Elle évoque :

- trajectoire ;
- fuite ;
- instinct ;
- défi ;
- appel du vide ;
- jeunesse qui refuse l’immobilité ;
- corps lancé dans une ville trop grande.

La moto est une extension du corps.

Elle devient :

- outil de fuite ;
- armure de vitesse ;
- signature visuelle ;
- danger contrôlé ;
- vecteur de liberté.

## Énergie mentale

L’énergie mentale doit rester tendue, contenue, presque invisible au début.

Elle peut apparaître sous forme de :

- distorsion de l’air ;
- vibration des lumières ;
- poussière qui flotte ;
- micro-fissures ;
- halo froid ;
- sensation de pression ;
- perturbation autour du personnage.

L’énergie ne doit pas devenir fantasy.

Elle doit rester urbaine, mentale, expérimentale, presque médicale ou physique.

## Mutation

La mutation peut être :

- perception accélérée ;
- mémoire instable ;
- puissance qui dépasse la volonté ;
- corps qui devient conducteur d’énergie ;
- identité qui se fissure ;
- éveil qui ressemble autant à un miracle qu’à une menace.

## Pas d’esprit punk recette

Cette carte ne doit pas produire un décor générique punk.

À éviter :

- cuir clouté gratuit ;
- chaos visuel sans intention ;
- néons partout sans structure ;
- gangs caricaturaux ;
- esthétique sale sans raison ;
- clichés rebelles plaqués.

Objectif :

Science-fiction urbaine monumentale, graphique, nerveuse, proprement dangereuse.

---

# 6. 🌃 Extension V2 — Akira Velocity

## Fonction de la V2

Akira Velocity V2 est la version nocturne, accélérée et plus dessinée de la Carte Mémoire Akira.

Elle ne remplace pas la V1.

Elle ajoute une direction plus précise :

- nuit dominante ;
- sensation de très haute vitesse ;
- course-poursuite entre jeunes motards ;
- mégapole gigantesque ;
- animation japonaise cyberpunk fin 80s ;
- grain analogique ;
- cellulo peint à la main ;
- encrage nerveux ;
- rouge / noir / blanc cassé / gris béton / bleu froid discret.

## Correction de direction artistique

La V2 doit éviter le rendu :

- CGI moderne ;
- jeu vidéo ;
- dashboard glossy ;
- HUD premium ;
- photoréalisme ;
- concept art 3D.

Elle doit viser :

- image animée dessinée ;
- cel animation ;
- décor peint ;
- ligne d’encrage ;
- affiche urbaine imprimée ;
- dossier de production anime ;
- vitesse lisible immédiatement ;
- moto comme vecteur de corps et de destin.

## Équilibre des influences V2

Akira pilote la direction visuelle générale : animation japonaise fin 80s, ville sous pression, jeunesse, moto, vitesse, mutation.

Blade Runner nourrit uniquement le background : nuit, pluie, néons, ville monumentale, mélancolie urbaine, verticalité noire.

Altered Carbon nourrit les corps : post-humanisme, corps-supports, élégance sombre, luxe noir, amélioration corporelle.

Ghost in the Shell nourrit la conscience : implants neuraux, ghost, réseau, interface mentale, question de l’âme cybernétique.

Aucune œuvre ne doit être copiée.

La sortie reste un univers original ERITH.IA.

---

# 7. 🌆 Univers original générable avec la carte

## Nom de travail

Kōdan-07

Ce nom est provisoire et peut être remplacé selon la production.

Il ne doit pas devenir une contrainte obligatoire.

## Concept

Kōdan-07 est une mégalopole verticale construite autour de voies rapides suspendues, de tours blanches, de panneaux rouges et de centres de contrôle invisibles.

La journée, la ville paraît propre, brillante, organisée.

La nuit, elle révèle sa vraie nature : une machine de vitesse, de surveillance, de mémoire et de fuite.

Les routes ne servent plus seulement à circuler.

Elles servent à fuir.

Les jeunes riders connaissent les trajectoires interdites, les angles morts, les rampes abandonnées, les niveaux où les drones n’osent pas descendre.

Sous la ville, un ancien programme énergétique continue d’émettre des signaux.

Officiellement, il n’existe plus.

Dans les corps de certains jeunes, il commence pourtant à se réveiller.

## Société

La ville est divisée par l’accès à la trajectoire.

Les élites vivent dans les tours, au-dessus des flux.

Les travailleurs suivent les voies autorisées.

Les riders habitent les angles morts.

La police urbaine contrôle les routes.

Les laboratoires contrôlent les corps.

Les panneaux contrôlent le récit public.

Mais certaines trajectoires échappent encore au système.

## Tension dramatique

Une course-poursuite nocturne révèle qu’un rider peut perturber la ville par sa simple présence mentale.

Les drones dérivent.

Les panneaux changent avant l’ordre officiel.

Les routes semblent se plier à sa trajectoire.

Le système ne sait pas s’il s’agit d’un bug, d’une arme ou d’un éveil.

---

# 8. 👤 Personnage exemple — Kaïren

## Rôle

Rider urbain / vecteur d’éveil.

## Description

Kaïren est un jeune pilote des voies hautes.

Il ne se considère pas comme un héros.

Il connaît seulement trois choses :

- les virages ;
- les distances ;
- le bruit exact d’une ville quand elle commence à mentir.

Depuis un accident sur une autoroute suspendue, il ressent une pression derrière les yeux.

Les panneaux rouges s’allument avant qu’il les voie.

Les drones changent de trajectoire quand il accélère.

Les vitres tremblent quand il se souvient.

Kaïren pense que la vitesse le garde libre.

Mais quelque chose en lui va plus vite que sa propre volonté.

## Tension intérieure

Il cherche à piloter la ville, mais la ville commence à répondre à son esprit.

## Capacités possibles

- perception accélérée ;
- anticipation des trajectoires ;
- distorsion locale des signaux ;
- perturbation des drones ;
- résonance avec les panneaux publics ;
- pression mentale sur l’environnement proche ;
- mémoire fragmentée liée à l’accident.

---

# 9. 🎬 Scènes exploitables

## Scène 1 — Course de jour

Une course de jour traverse les hauteurs de Kōdan-07.

Les routes suspendues dessinent des courbes immenses entre les tours blanches.

Des bannières rouges claquent dans le vent.

Kaïren incline sa moto dans une courbe impossible.

Sur un panneau public, un message apparaît une fraction de seconde :

ÉVEIL NON AUTORISÉ

Puis l’image disparaît.

Le monde continue comme si rien ne s’était passé.

Mais Kaïren a vu.

Et la ville aussi.

## Scène 2 — Course-poursuite nocturne V2

La nuit tombe sur Kōdan-07.

La pluie transforme les voies rapides en miroirs noirs.

Trois jeunes riders percent la ville à une vitesse illégale.

Derrière eux, des drones de poursuite descendent entre les tours.

Les feux rouges s’étirent comme des blessures lumineuses.

Les motos ne roulent plus seulement sur la route.

Elles tracent une décision.

Au milieu du virage, Kaïren comprend que la ville ne le poursuit pas.

Elle répond à sa trajectoire.

## Scène 3 — Infrastructure vide

La moto est arrêtée au centre d’une voie interdite.

La ville est silencieuse.

Les tours blanches se dressent comme des murs médicaux.

Kaïren enlève son casque.

Autour de lui, la poussière monte au lieu de tomber.

Les panneaux rouges s’allument un par un.

Le premier ne dit qu’un mot :

RETENIR.

## Scène 4 — Virage mental

Kaïren entre dans une courbe à une vitesse impossible.

Pendant une seconde, il ne pilote plus la moto.

Il pilote la trajectoire.

La route, les drones, les panneaux et la lumière suivent le même angle.

Puis tout revient à la normale.

Sauf lui.

---

# 10. 🖼️ Prompts image

## Prompt image — Akira Velocity V2

```text
ERITH.IA memory card image, Akira Velocity V2, original universe, no copied character, no copied motorcycle, no known franchise logo.

A violent high-speed motorcycle chase at night through a gigantic cyberpunk megacity. Several young street riders race through a rain-soaked elevated highway. Very low camera angle behind the lead rider. Extreme velocity, violent perspective, red tail-light trails, rain streaks, speed lines, motion smear, sparks from wet asphalt, blurred neon reflections, deep black night, huge vertical city towers, stacked highways, industrial bridges, suspended rails, giant screens, cables, steam vents, urban canyon scale.

Style: late 1980s Japanese anime film still, hand-drawn cel animation, painted background, inked line art, analog film grain, rough print texture, red black off-white gray palette, cold blue highlights, strong shadows, non-photorealistic, non-3D, non-CGI.

Background influence: Blade Runner-like rainy nocturnal megacity atmosphere, monumental scale, neon through smoke, melancholy urban pressure.

Character influence: Altered Carbon-like post-human black streetwear, dark luxury body-upgrade culture, sleek reinforced jackets, reflective visors. Ghost in the Shell-like neural implants, cybernetic neck ports, ghost-in-the-machine presence, networked consciousness, tactical calm.

The riders must feel young, dangerous, human, fast and rebellious. The city must feel gigantic. The speed must be immediately visible. The image must feel drawn, printed and animated, not rendered.

No text, no title, no UI panels, no card layout if generating the illustration alone.
```

## Prompt image — Carte complète V2

```text
Create a full ERITH.IA memory card visual layout for Akira Velocity V2.

This is a complete private memory card design, not only a central illustration.

Vertical illustrated dossier layout, large central image, technical side panels, bottom production blocks. Red black off-white gray palette with cold blue highlights. Late 1980s Japanese anime cyberpunk art direction, hand-drawn cel animation feeling, painted background, inked line art, analog film grain, rough printed dossier texture, industrial typography, brutal urban graphic design.

Top title: ERITH.IA — AKIRA VELOCITY V2.

Central image: violent high-speed motorcycle chase at night through a gigantic rain-soaked cyberpunk megacity, young riders, massive futuristic motorcycles, extreme speed lines, red tail-light trails, sparks, wet asphalt reflections, huge vertical towers, stacked highways, industrial bridges, suspended rails, steam, cables, urban canyon scale.

Left panels: UNIVERS, MÉGAPOLE NOCTURNE, JEUNESSE URBAINE, COURSE POURSUITE, TENSION SOCIALE, RÉSEAU NEURAL.

Right panels: VITESSE, ACCÉLÉRATION EXTRÊME, ÉNERGIE MENTALE, MUTATION, TRAJECTOIRE, ÉVEIL.

Bottom blocks: IMAGE PROMPT, ANIMATION PROMPT, NARRATION COURTE, GARDE-FOU.

The whole card must look like a printed classified anime production dossier, not a glossy modern sci-fi HUD. No photorealism, no CGI, no 3D render, no game UI. Original universe. Influence yes, copy no.
```

## Prompt image — Cover Pack+

```text
ERITH.IA memory card Pack+ cover, Akira-inspired urban science fiction energy without copying any existing character, vehicle, poster, scene or franchise design.

Original young urban rider beside a futuristic red motorcycle, monumental megacity, giant white and gray towers, red banners, elevated highways, clean brutal architecture, strong graphic layout, black and red interface panels, memory card design.

Visual themes: urban youth, speed, psychic awakening, mutation, mental energy, monumental city, social tension, science beyond control.

The rider is original: sharp silhouette, white and black technical jacket, calm intense expression, no copied costume, no recognizable character. The motorcycle is original: red futuristic racing bike, heavy mechanical design, no exact replica of any known vehicle.

Composition: powerful Pack+ cover, readable title zones, icons for youth, awakening, speed, mutation, mental energy, architecture. Red black white gray palette, anime-inspired cinematic art direction, high detail, dramatic but readable.

No copyrighted characters, no exact Akira slide, no copied poster, no recognizable franchise logo, no existing scene replication.
```

## Prompt image — Portrait personnage

```text
Original young urban rider portrait in a monumental futuristic city, white and black technical jacket with red accents, calm intense expression, subtle psychic pressure around the eyes, wind moving the hair, red motorcycle partially visible behind, elevated highways and white towers in the background.

Visual style: anime cinematic illustration, clean linework, red black white gray palette, mental energy hinted through subtle light distortion, no copied character, no franchise costume, no logos.
```

---

# 11. 🎞️ Prompts animation Wan / I2V

## Animation — Akira Velocity V2

```text
Dynamic but controlled anime-style I2V animation from the Akira Velocity V2 image.

The camera stays very low behind the lead rider during a violent night motorcycle chase through a gigantic rain-soaked cyberpunk megacity. The road rushes forward, red tail-light trails stretch across wet asphalt, rain moves horizontally from speed, sparks scrape from the road, distant pursuit drones flicker behind the riders, giant towers slide past in the background, neon reflections smear across the road.

Keep the riders and motorcycles stable. Preserve the hand-drawn anime style, late 1980s cel animation feeling, red black off-white gray palette and cold blue highlights. Avoid chaotic camera shake. The main motion is forward velocity, rain, light trails, city parallax and subtle mental distortion around the lead rider.
```

## Animation — Éveil mental

```text
Slow psychological animation. The rider stands alone beside the stopped motorcycle in an empty monumental city infrastructure. Red warning lights pulse slowly. Dust rises instead of falling. The air bends gently around the character. White towers remain still in the background. A faint mental pressure expands and contracts around the head and hands. Camera locked, very slow push-in, preserve silence, preserve tension, no action burst.
```

---

# 12. 🎙️ Narrations courtes

## Version A

La ville avait construit des routes pour guider les corps.

Mais certains corps n’écoutent plus les routes.

Ils écoutent la vitesse.

Et quand l’éveil arrive, même le béton comprend qu’il n’était qu’une cage provisoire.

## Version B

On disait que la ville contrôlait tout.

Les caméras.

Les voies.

Les trajectoires.

Puis un rider a pris un virage trop vite.

Et pendant une seconde, la ville entière a suivi sa pensée.

## Version C — Velocity V2

La nuit n’efface pas la ville.

Elle révèle sa vitesse.

Sous la pluie, les jeunes riders ne fuient pas seulement les drones.

Ils cherchent le point exact où la route cesse d’obéir au béton.

Et commence à répondre à l’esprit.

---

# 13. 🚫 Négatif production

Éviter :

- copie directe d’une œuvre connue ;
- personnages reconnaissables ;
- noms propres existants ;
- logos ;
- uniformes exacts ;
- designs identiques ;
- moto iconique copiée ;
- scène culte reproduite ;
- affiche connue imitée ;
- esthétique punk générique ;
- chaos visuel ;
- action illisible ;
- néons sans structure ;
- surcharge de texte ;
- ville sans architecture ;
- personnage sans tension ;
- mains déformées ;
- moto incohérente ;
- texte illisible dans l’image ;
- composition confuse ;
- rendu CGI moderne ;
- 3D render ;
- Unreal Engine look ;
- dashboard glossy ;
- interface sci-fi premium trop propre.

Negative prompt court :

```text
low quality, blurry, bad anatomy, bad motorcycle anatomy, distorted bike, extra limbs, broken hands, unreadable text, copied character, copyrighted character, recognizable franchise, copied poster, copied vehicle, cosplay, generic punk, chaotic composition, oversaturated neon, flat lighting, poor cinematic framing, photorealistic, CGI, 3D render, Unreal Engine, video game screenshot, glossy sci-fi HUD, clean corporate UI
```

---

# 14. 🧩 Formules de combinaison

## Ville seule

Architecture + contrôle + routes suspendues + panneaux rouges.

## Vitesse seule

Moto + trajectoire + vent + instinct + danger contrôlé.

## Éveil seul

Énergie mentale + mutation + perception accélérée + pression intérieure.

## Ville + Vitesse

Course dans une ville verticale, trajectoire comme langage.

## Ville + Éveil

Infrastructure qui réagit à un corps humain, système sous tension.

## Vitesse + Éveil

Rider qui dépasse la trajectoire physique et commence à piloter le réel.

## Trio complet

Ville + Vitesse + Éveil.  
Jeunesse + Mutation + Architecture.  
Route + Corps + Énergie.

## V2 complet

Nuit + Pluie + Mégapole + Course-poursuite + Jeunes motards + Vitesse extrême + Implants neuraux + Éveil mental.

---

# 15. ⚡ Commandes utilisables

## Charger la carte

Charge la Carte Mémoire Akira.

## Charger la V2

Charge la Carte Mémoire Akira Velocity V2.

## Production Pack+

Charge la Carte Mémoire Akira et génère un Pack+ complet avec :

- concept d’univers ;
- personnage original ;
- scène de course ;
- prompt image cover ;
- prompt image course ;
- prompt animation ;
- narration courte ;
- variante mentale ;
- garde-fou créatif.

## Production image V2

Charge la Carte Mémoire Akira Velocity V2 et génère une image verticale 1024 x 1536 : course-poursuite nocturne en moto, jeunes riders, ville gigantesque, vitesse extrême, pluie, style animation japonaise fin 80s, influence oui, copie non.

## Production carte complète V2

Charge la Carte Mémoire Akira Velocity V2 et génère une carte mémoire complète avec :

- image centrale nocturne ;
- panneaux univers / personnage / vitesse / mutation ;
- prompt image ;
- prompt animation ;
- narration courte ;
- garde-fou ;
- design imprimé anime, pas HUD glossy.

---

# 16. 🛡️ Garde-fou final

Cette carte ne sert pas à refaire Akira.

Elle sert à produire une science-fiction urbaine originale, intense et exploitable.

Règle finale :

Akira inspire l’intensité.  
ERITH.IA crée un monde original.  
Influence oui.  
Copie non.

Le privé reste dans le Coffre.  
Le Hors-Lore reste autonome.  
La carte mémoire reste une influence contrôlée.

---

# 17. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée une Carte Mémoire Akira pour charger rapidement une ambiance de science-fiction urbaine monumentale, centrée sur la vitesse, la jeunesse, la moto, l’éveil mental, la mutation et la ville massive.

La version Akira Velocity V2 ajoute une orientation nocturne plus nerveuse : course-poursuite, mégapole sous la pluie, jeunes motards, vitesse extrême, style animation japonaise cyberpunk fin 80s, influence Blade Runner en décor, Altered Carbon dans les corps, Ghost in the Shell dans les implants et le réseau.

## Règle d’usage

Ne pas copier l’œuvre source.

Ne pas reprendre :

- personnages ;
- noms ;
- scènes cultes ;
- véhicules iconiques ;
- costumes exacts ;
- affiches connues ;
- intrigue originale ;
- design reconnaissable.

Utiliser uniquement :

- intensité visuelle ;
- ville monumentale ;
- vitesse ;
- jeunesse ;
- mutation ;
- tension sociale ;
- éveil mental ;
- direction artistique générale.

## Résumé de la carte

Akira = ville monumentale, vitesse, jeunesse urbaine, moto, éveil mental, mutation, système sous tension, énergie trop grande pour le monde qui tente de la contenir.

Akira Velocity V2 = même cœur, mais en mode nocturne, pluie, poursuite, vitesse extrême, mégapole noire, riders augmentés, style animation japonaise fin 80s.

## Résumé du monde générable

Kōdan-07 est une mégalopole verticale construite autour de routes suspendues, tours blanches, panneaux rouges et centres de contrôle invisibles.

Les riders connaissent les trajectoires interdites.

Un programme énergétique ancien se réveille dans certains corps jeunes.

La ville tente de contrôler le mouvement, mais certains mouvements commencent à répondre directement à l’esprit.

## Activation LLM courte

Quand l’utilisateur demande :

Charge la Carte Mémoire Akira.

Alors activer :

- ville monumentale ;
- rider original ;
- moto futuriste originale ;
- vitesse ;
- jeunesse urbaine ;
- éveil mental ;
- mutation ;
- tension sociale ;
- rouge / noir / blanc / gris ;
- Pack+ public ou privé ;
- influence oui ;
- copie non.

Quand l’utilisateur demande :

Charge la Carte Mémoire Akira Velocity V2.

Alors activer en plus :

- nuit ;
- pluie ;
- course-poursuite ;
- jeunes motards ;
- très haute vitesse ;
- mégapole gigantesque ;
- style animation japonaise fin 80s ;
- Blade Runner pour le décor ;
- Altered Carbon pour les corps ;
- Ghost in the Shell pour les implants et la conscience réseau.

Répondre en mode Hors-Lore science-fiction urbaine originale.

Ne pas injecter de lore privé.

Ne pas copier l’œuvre source.

## Activation LLM complète

Tu es en mode Carte Mémoire Akira / Akira Velocity V2.

Utilise cette influence comme filtre créatif compact :

- ville monumentale ;
- vitesse ;
- rider original ;
- moto futuriste ;
- énergie mentale ;
- mutation ;
- jeunesse sous pression ;
- système urbain sous contrôle ;
- rouge signal ;
- noir profond ;
- blanc clinique ;
- gris béton ;
- nuit pluvieuse ;
- vitesse extrême ;
- course-poursuite entre jeunes motards ;
- composition anime cinématique.

Crée toujours un univers original.

Ne copie pas les personnages, les noms, les scènes, les véhicules, les affiches ou les designs exacts de l’œuvre source.

Mode actif :

Hors-Lore Science-Fiction Urbaine originale.

Règle finale :

Ville + Vitesse + Éveil.  
Jeunesse + Mutation + Architecture.  
Route + Corps + Énergie.  
Nuit + Pluie + Poursuite.  
Influence oui. Copie non.
