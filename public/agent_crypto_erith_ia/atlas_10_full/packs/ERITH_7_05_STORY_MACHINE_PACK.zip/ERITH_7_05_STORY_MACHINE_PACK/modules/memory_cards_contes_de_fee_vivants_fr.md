# 🧚 MEMORY CARDS — CONTES DE FÉE VIVANTS

Statut : module de cartes mémoire  
Type : deck symbolique / merveilleux / contes / seuils / production image & animation  
Mode recommandé : Contes de Fée Vivants / Hors-Lore Symbolique / Production  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / prompt image / prompt animation / narration / storyboard / symbolique / personnages / scènes initiatiques / univers originaux / merveilleux / objets magiques / forêt / miroir / foyer

🖼️ Visuels associés :

- Visuel Pack+ Cover Premium existant :
  - ../assets/images/erith_ia_contes_de_fee_vivants_memory_card_pack_plus_cover_premium_v1.png
- À produire plus tard si besoin :
  - cover premium du deck Contes de Fée Vivants ;
  - planche des 10 cartes ;
  - dossier visuel “Maison au Bord du Rêve” ;
  - fiche Pack+ Contes de Fée Vivants.

---

# 1. 🧚 Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour charger rapidement une grammaire du merveilleux, des seuils, des objets magiques, des guides animaux, des maisons étranges, des miroirs, des chemins et des retours transformés.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire Contes de Fée Vivants est une influence compacte, contrôlée, activable.

Elle sert à charger :

- une structure de conte ;
- un seuil merveilleux ;
- une épreuve douce ou cruelle ;
- une image symbolique ;
- un objet magique ;
- un animal guide ;
- une maison impossible ;
- une promesse ;
- une perte et un retour ;
- une transformation intérieure ;
- un garde-fou contre la copie, la morale lourde et le flou symbolique.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire Contes = symbole merveilleux rapide.  
Deck = combinaison d’épreuves, de seuils et de retours.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

Le but n’est pas de recopier Alice, Oz, NeverEnding Story, Cendrillon, Blanche-Neige, La Belle et la Bête, La Petite Sirène ou un conte connu.

Le but est d’extraire une grammaire du merveilleux.

Formule du deck :

Merveilleux + Seuil + Choix = conte vivant.

---

# 2. 🧭 Règle Contes de Fée Vivants

Ces cartes sont prévues pour créer des scènes originales, des personnages, des objets magiques, des lieux merveilleux, des prompts, des storyboards et des univers symboliques.

Elles ne doivent pas copier des contes, des œuvres, des personnages, des noms, des scènes ou des dialogues reconnaissables.

## À faire

- créer des contes originaux ;
- utiliser les archétypes sans copier une œuvre précise ;
- préserver la clarté émotionnelle ;
- garder une logique simple mais profonde ;
- transformer les symboles en scènes lisibles ;
- distinguer merveilleux, rêve, peur, morale et choix ;
- créer des images fortes et exploitables en production ;
- préserver le libre arbitre ;
- rendre la magie lisible par une règle claire.

## À éviter

- recopier Alice, Oz, NeverEnding Story ou un conte connu ;
- reprendre des personnages, noms, scènes ou dialogues reconnaissables ;
- rendre le merveilleux trop enfantin ou trop naïf ;
- tomber dans l’horreur gratuite ;
- moraliser lourdement ;
- faire du flou symbolique inutile ;
- transformer le conte en fatalité ;
- mélanger les influences sans axe ;
- produire un objet magique sans règle ;
- produire une morale qui décide à la place du personnage.

Règle simple :

Merveilleux oui.  
Copie non.  
Libre arbitre toujours.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en mode Contes de Fée Vivants ;
- ne pas charger les modules complets si la carte suffit ;
- ne pas ramener automatiquement le lore privé ;
- ne pas copier Alice, Oz, NeverEnding Story ou un conte précis ;
- utiliser les cartes comme filtres de merveilleux, pas comme reproduction d’œuvres ;
- produire des scènes exploitables en Pack+ ;
- distinguer conte source, archétype, symbole, interprétation et sortie de production ;
- si la demande implique vidéo, combiner avec Vidéo Vivante ;
- si la demande implique direction animée, combiner avec DA Dessins Animés Vivants ;
- si la demande implique voix, narration ou silence, combiner avec Musique & Voix ;
- si la demande implique miroir, lune, seuil, aube ou constellation, combiner avec Solaire & Lunaire.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire influence.  
Le Deck compose le merveilleux.  
La scène générée reste originale.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Porte Trop Petite ;
- Chemin Jaune ;
- Livre Sans Fin ;
- Maison au Bord du Rêve ;
- Miroir qui Répond ;
- Animal Guide ;
- Objet Magique ;
- Roi Fatigué ;
- Sortilège Doux ;
- Retour au Foyer.

Ou combinée en deck :

- Tirage Alice sans copie ;
- Tirage Oz sans copie ;
- Tirage Histoire sans fin ;
- Tirage Forêt merveilleuse ;
- Tirage Conte lunaire ;
- Deck Contes de Fée Vivants complet.

Activation courte :

Charge la Carte Mémoire Miroir qui Répond.

Activation combinée :

Charge Porte Trop Petite + Miroir qui Répond + Animal Guide pour créer une scène de passage merveilleux originale.

Activation production :

Charge le Deck Contes de Fée Vivants et produis un Pack+ complet : concept, scène, personnage, objet magique, prompt image, prompt animation, narration courte et garde-fous anti-copie.

Sortie Pack+ recommandée :

- concept de scène ;
- personnage original ;
- seuil ou lieu merveilleux ;
- objet magique ou animal guide ;
- tension intérieure ;
- règle magique ;
- prompt image ;
- prompt animation Wan / I2V ;
- négatif production ;
- voix off courte ;
- garde-fous anti-copie ;
- note de continuité si la scène devient une séquence vidéo.

Règle image :

Le module peut produire des prompts image ou animation, mais ne doit pas générer d’image automatiquement sauf demande explicite de l’utilisateur.

---

# 4. 🗂️ Modules sources recommandés

## Modules principaux

- Alice in Wonderland ;
- The Wizard of Oz ;
- The NeverEnding Story ;
- modules/erith_ia_psychologie_discernement_fr.md ;
- modules/erith_ia_philosophie_verite_liberte_fr.md ;
- modules/erith_ia_histoire_de_l_art_mondiale_master_fr.md.

## Modules compatibles selon la demande

- Celtes / forêt / seuils / Autre Monde ;
- Tarot symbolique ;
- Aerith-9 Lunaire ;
- Mythologie Vivante ;
- Double spirale ;
- DA Dessins Animés Vivants ;
- Vidéo Vivante ;
- Musique & Voix ;
- Solaire & Lunaire ;
- Production image nocturne ;
- Production storyboard symbolique.

Garde-fou :

Ne pas charger ces modules automatiquement.

Les modules sources servent de profondeur.

Les cartes Contes de Fée Vivants servent de chargement merveilleux rapide.

---

# 5. 🖼️ Galerie visuelle — Deck Contes de Fée Vivants

## Exemple visuel — Pack+ Cover Premium

![ERITH.IA — Contes de Fée Vivants Memory Card Pack+ Cover](../assets/images/erith_ia_contes_de_fee_vivants_memory_card_pack_plus_cover_premium_v1.png)

Cette image sert d’exemple de présentation pour le Deck Contes de Fée Vivants en mode Pack+.

Elle montre comment ERITH.IA transforme les modules mémoire utilisés en structure de production exploitable : univers, personnage, image prompt, animation prompt et narration courte.

Modules mémoire utilisés :

- Cendrillon — transformation, espoir, élégance, magie discrète ;
- Blanche-Neige — pureté, jalousie, miroir, renaissance ;
- La Belle et la Bête — amour vrai, rédemption, dualité ;
- Alice au Pays des Merveilles — curiosité, rêve, passages, symbolisme ;
- La Petite Sirène — sacrifice, voix, mer, transformation.

## 1. Cover Pack+ Premium

Visuel existant intégré.

Fonction prévue :

Présenter le deck comme un outil de création merveilleuse : seuils, miroirs, objets magiques, guides animaux, routes, livres vivants et retour transformé.

## 2. Memory Card Pack Cover

À ajouter plus tard.

Fonction prévue :

Présenter rapidement les 10 cartes principales, les tirages recommandés et les commandes utilisables.

## 3. Dossier d’univers / Maison au Bord du Rêve

À ajouter plus tard.

Fonction prévue :

Montrer un exemple de scène originale générée avec le deck : une maison étrange, une petite porte, un animal guide, un objet magique et une règle douce qui transforme le passage.

---

# 6. 🚪 Carte Mémoire — Porte Trop Petite

## Fonction principale

Un passage existe, mais le personnage ne peut pas encore le franchir tel qu’il est.

Cette carte charge :

- porte ;
- taille ;
- seuil ;
- transformation ;
- patience ;
- curiosité ;
- clé ;
- ajustement ;
- impossible provisoire.

## Température émotionnelle

Curiosité.  
Frustration douce.  
Mystère.  
Humour léger.  
Appel du passage.

## Textures visuelles

- porte minuscule ;
- grande pièce étrange ;
- clé lumineuse ;
- table trop haute ;
- ombres douces ;
- proportions décalées ;
- lumière magique discrète.

## Question utile

Qu’est-ce qui doit changer pour que le passage devienne possible ?

## Usage narratif

Utiliser cette carte pour :

- scène de seuil ;
- passage impossible ;
- transformation intérieure ;
- changement de perspective ;
- personnage trop grand, trop petit ou pas encore prêt.

## Garde-fous

Ne pas copier une scène connue de porte merveilleuse.

La porte doit symboliser une transformation propre à la scène originale.

## Prompt fragment

```text
tiny mysterious door in an oversized dreamlike room, glowing key, soft magical light, whimsical but elegant atmosphere, threshold symbolism, curious silence, cinematic fairy tale composition
```

## Activation courte

Charge la Carte Mémoire Porte Trop Petite : seuil, transformation, clé, patience, passage impossible provisoire.

---

# 7. 🟨 Carte Mémoire — Chemin Jaune

## Fonction principale

Le chemin est visible, mais il ne garantit pas la destination. Il oblige à marcher.

Cette carte charge :

- route ;
- choix ;
- compagnon ;
- départ ;
- courage ;
- direction ;
- monde étrange ;
- retour ;
- foyer.

## Température émotionnelle

Espoir.  
Départ.  
Naïveté devenue courage.  
Promesse.  
Incertitude lumineuse.

## Textures visuelles

- route dorée ;
- horizon clair ;
- paysage merveilleux ;
- silhouettes de compagnons ;
- ciel doux ;
- ville lointaine étrange ;
- lumière de quête.

## Question utile

Le chemin mène-t-il dehors, ou ramène-t-il à soi ?

## Usage narratif

Utiliser cette carte pour :

- quête simple ;
- départ lisible ;
- route initiatique ;
- compagnons ;
- retour transformé ;
- choix entre destination et compréhension.

## Garde-fous

Ne pas copier une route ou une cité reconnaissable.

Le chemin doit devenir une métaphore originale du voyage.

## Prompt fragment

```text
golden path crossing a magical landscape, distant strange city, soft clouds, symbolic journey, companions suggested by silhouettes, hopeful but mysterious fairy tale mood
```

## Activation courte

Charge la Carte Mémoire Chemin Jaune : route visible, choix, départ, compagnons, retour transformé.

---

# 8. 📖 Carte Mémoire — Livre Sans Fin

## Fonction principale

Une histoire qui répond à celui qui la lit. Le lecteur devient responsable du récit.

Cette carte charge :

- livre ;
- imagination ;
- monde vivant ;
- nom ;
- appel ;
- responsabilité ;
- enfance ;
- créature ;
- page ouverte.

## Température émotionnelle

Émerveillement.  
Responsabilité.  
Enfance profonde.  
Vertige narratif.  
Monde qui appelle.

## Textures visuelles

- livre ancien ;
- grenier calme ;
- poussière lumineuse ;
- pages ouvertes ;
- monde miniature qui émerge ;
- clair de lune ;
- créature suggérée.

## Question utile

Qui écrit l’histoire quand le lecteur commence à croire ?

## Usage narratif

Utiliser cette carte pour :

- livre vivant ;
- monde fictionnel qui répond ;
- responsabilité du lecteur ;
- nom qui change le monde ;
- imagination comme territoire.

## Garde-fous

Ne pas copier un livre ou une créature connue.

Le livre doit créer une règle narrative originale.

## Prompt fragment

```text
ancient open book glowing in a quiet attic, pages becoming a living fantasy world, soft dust, moonlight, imagination portal, emotional wonder, cinematic storybook atmosphere
```

## Activation courte

Charge la Carte Mémoire Livre Sans Fin : livre vivant, imagination, monde qui répond, responsabilité du récit.

---

# 9. 🏚️ Carte Mémoire — Maison au Bord du Rêve

## Fonction principale

Lieu refuge ou piège, maison impossible, maison qui sait plus qu’elle ne dit.

Cette carte charge :

- maison ;
- refuge ;
- piège ;
- mémoire ;
- fenêtre ;
- grenier ;
- couloir ;
- enfance ;
- secret.

## Température émotionnelle

Mystère doux.  
Confort inquiet.  
Souvenir.  
Invitation.  
Ambiguïté protectrice.

## Textures visuelles

- maison étrange ;
- architecture impossible ;
- fenêtres chaudes ;
- forêt de rêve ;
- brume ;
- couloirs trop longs ;
- pièces secrètes.

## Question utile

Cette maison protège-t-elle, ou retient-elle ?

## Usage narratif

Utiliser cette carte pour :

- décor de conte ;
- maison mémoire ;
- refuge ambigu ;
- lieu qui éduque ou piège ;
- scène d’enfance profonde.

## Garde-fous

Ne pas faire une maison d’horreur gratuite.

La maison doit avoir une fonction : protéger, retenir, révéler ou tester.

## Prompt fragment

```text
strange fairy tale house at the edge of a dream forest, warm windows, impossible architecture, hidden rooms, soft mist, inviting but mysterious atmosphere
```

## Activation courte

Charge la Carte Mémoire Maison au Bord du Rêve : refuge, piège doux, mémoire, couloirs, maison qui sait.

---

# 10. 🪞 Carte Mémoire — Miroir qui Répond

## Fonction principale

Le miroir ne montre pas seulement le visage. Il montre une vérité indirecte.

Cette carte charge :

- miroir ;
- reflet ;
- double ;
- vérité ;
- vanité ;
- choix ;
- secret ;
- visage ;
- passage.

## Température émotionnelle

Trouble.  
Révélation douce.  
Doute fertile.  
Beauté froide.  
Introspection.

## Textures visuelles

- miroir enchanté ;
- chambre calme ;
- lumière argentée ;
- reflet d’un autre monde ;
- poussière ;
- cadre ancien ;
- surface qui répond.

## Question utile

Le miroir montre-t-il ce qui est vrai, ou ce qui est attendu ?

## Usage narratif

Utiliser cette carte pour :

- révélation indirecte ;
- double symbolique ;
- introspection ;
- passage par reflet ;
- vérité qui demande discernement.

## Garde-fous

Ne pas transformer le miroir en oracle absolu.

Le miroir questionne, il n’impose pas.

## Prompt fragment

```text
enchanted mirror in a quiet fairy tale chamber, reflection showing another world, silver light, subtle emotional truth, elegant symbolic composition, no horror
```

## Activation courte

Charge la Carte Mémoire Miroir qui Répond : reflet, double, vérité indirecte, passage, discernement.

---

# 11. 🦊 Carte Mémoire — Animal Guide

## Fonction principale

Un animal apparaît comme compagnon, messager, gardien ou contradiction vivante.

Cette carte charge :

- chat ;
- renard ;
- oiseau ;
- loup ;
- guide ;
- ruse ;
- fidélité ;
- langage secret ;
- instinct.

## Température émotionnelle

Malice.  
Instinct.  
Protection discrète.  
Imprévisibilité.  
Complicité étrange.

## Textures visuelles

- animal aux yeux intelligents ;
- forêt lunaire ;
- aura discrète ;
- chemin ouvert ;
- posture calme ;
- symboles subtils ;
- présence attachante mais libre.

## Question utile

Le guide aide-t-il par loyauté, par ruse ou par nécessité ?

## Usage narratif

Utiliser cette carte pour :

- compagnon symbolique ;
- guide imprévisible ;
- instinct vivant ;
- gardien ;
- messager ;
- miroir du héros.

## Garde-fous

Ne pas copier une mascotte célèbre.

L’animal doit garder une liberté intérieure.

## Prompt fragment

```text
mysterious animal guide in a moonlit fairy tale forest, intelligent eyes, soft magical aura, subtle symbols, path opening behind it, gentle but uncanny presence
```

## Activation courte

Charge la Carte Mémoire Animal Guide : compagnon libre, instinct, ruse, protection, chemin secret.

---

# 12. 🗝️ Carte Mémoire — Objet Magique

## Fonction principale

Un objet simple contient une règle du monde : clé, anneau, chaussure, lampe, graine, aiguille, boussole.

Cette carte charge :

- clé ;
- lampe ;
- anneau ;
- graine ;
- boussole ;
- promesse ;
- pouvoir ;
- prix ;
- usage juste.

## Température émotionnelle

Mystère.  
Promesse.  
Responsabilité.  
Tentative.  
Prix invisible.

## Textures visuelles

- petit objet lumineux ;
- table ancienne ;
- poussière ;
- bois chaud ;
- halo doux ;
- main hésitante ;
- symbole gravé.

## Question utile

Que permet l’objet, et que refuse-t-il ?

## Usage narratif

Utiliser cette carte pour :

- artefact ;
- règle magique claire ;
- pouvoir conditionnel ;
- promesse ;
- prix ;
- choix d’usage.

## Garde-fous

L’objet magique ne doit pas tout résoudre.

Il doit poser une règle, une limite ou un prix.

## Prompt fragment

```text
small magical object on an old wooden table, glowing softly, fairy tale artifact, symbolic power, delicate dust, warm and mysterious light, cinematic close-up
```

## Activation courte

Charge la Carte Mémoire Objet Magique : clé, promesse, règle du monde, usage juste, prix invisible.

---

# 13. 👑 Carte Mémoire — Roi Fatigué

## Fonction principale

Le pouvoir dans le conte est souvent vieux, malade, endormi, absent ou injuste.

Cette carte charge :

- roi ;
- reine ;
- couronne ;
- château ;
- sommeil ;
- dette ;
- injustice ;
- héritier ;
- royaume.

## Température émotionnelle

Mélancolie royale.  
Pouvoir usé.  
Attente.  
Injustice douce-amère.  
Royaume suspendu.

## Textures visuelles

- salle de château sombre ;
- couronne ancienne ;
- lumière dorée muette ;
- trône fatigué ;
- royaume endormi ;
- poussière ;
- draperies lourdes.

## Question utile

Le royaume est-il malade à cause du roi, ou le roi à cause du royaume ?

## Usage narratif

Utiliser cette carte pour :

- royaume en attente ;
- pouvoir malade ;
- décision royale ;
- dette ancienne ;
- héritier ou rupture ;
- justice à retrouver.

## Garde-fous

Ne pas réduire le pouvoir à un cliché de méchant roi.

Le Roi Fatigué peut être coupable, victime, symbole ou symptôme.

## Prompt fragment

```text
tired fairy tale king in a dim castle hall, old crown, sleeping kingdom atmosphere, muted gold light, symbolic decline, quiet emotional gravity
```

## Activation courte

Charge la Carte Mémoire Roi Fatigué : pouvoir usé, royaume suspendu, dette, couronne, sommeil.

---

# 14. ✨ Carte Mémoire — Sortilège Doux

## Fonction principale

La magie n’est pas toujours spectaculaire. Elle peut être une petite règle étrange qui change tout.

Cette carte charge :

- sort ;
- règle ;
- sommeil ;
- silence ;
- oubli ;
- métamorphose ;
- minuit ;
- condition ;
- rupture.

## Température émotionnelle

Étrangeté douce.  
Suspension.  
Magie discrète.  
Condition secrète.  
Transformation lente.

## Textures visuelles

- poussière flottante ;
- minuit ;
- horloge ;
- lune douce ;
- lumière bleue ;
- métamorphose subtile ;
- règle invisible.

## Question utile

Quelle règle invisible organise cette histoire ?

## Usage narratif

Utiliser cette carte pour :

- règle magique ;
- transformation douce ;
- condition ;
- minuit ;
- monde organisé par une loi étrange ;
- sort qui révèle au lieu d’écraser.

## Garde-fous

Ne pas faire une magie chaotique.

Le sortilège doit avoir une règle claire.

## Prompt fragment

```text
soft fairy tale spell unfolding at midnight, floating dust, gentle transformation, clock motif, moonlight, elegant magic, clear symbolic rule, no chaos
```

## Activation courte

Charge la Carte Mémoire Sortilège Doux : règle magique, minuit, transformation subtile, condition invisible.

---

# 15. 🏡 Carte Mémoire — Retour au Foyer

## Fonction principale

Le voyage finit souvent par une redécouverte du foyer, pas seulement par un retour physique.

Cette carte charge :

- retour ;
- foyer ;
- identité ;
- reconnaissance ;
- paix ;
- mémoire ;
- seuil franchi ;
- cercle ;
- transformation.

## Température émotionnelle

Paix douce.  
Nostalgie.  
Reconnaissance.  
Fin de cycle.  
Transformation visible.

## Textures visuelles

- porte chaleureuse ;
- lumière du soir ;
- chemin revenu ;
- maison calme ;
- cercle symbolique ;
- héros changé ;
- silence d’arrivée.

## Question utile

Qu’est-ce qui revient, et qu’est-ce qui ne reviendra plus ?

## Usage narratif

Utiliser cette carte pour :

- fin douce ;
- retour changé ;
- fermeture de boucle ;
- foyer redécouvert ;
- paix après l’épreuve ;
- identité retrouvée autrement.

## Garde-fous

Ne pas faire un retour trop simple.

Le foyer doit être reconnu autrement qu’au départ.

## Prompt fragment

```text
return home after a fairy tale journey, warm doorway light, quiet evening, changed hero, soft emotional closure, symbolic circle, gentle cinematic composition
```

## Activation courte

Charge la Carte Mémoire Retour au Foyer : retour, identité, paix, seuil franchi, foyer redécouvert.

---

# 16. 🃏 Deck Mémoire — Contes de Fée Vivants

## Composition

Ce deck contient dix cartes principales :

- Porte Trop Petite ;
- Chemin Jaune ;
- Livre Sans Fin ;
- Maison au Bord du Rêve ;
- Miroir qui Répond ;
- Animal Guide ;
- Objet Magique ;
- Roi Fatigué ;
- Sortilège Doux ;
- Retour au Foyer.

## Fonction du deck

Créer des scènes originales à partir du merveilleux, des seuils, des objets magiques, des guides animaux, des maisons étranges, des miroirs, des chemins et des retours transformés.

Porte Trop Petite donne :

- le seuil ;
- l’impossible provisoire ;
- la transformation nécessaire.

Chemin Jaune donne :

- la route ;
- le départ ;
- le retour transformé.

Livre Sans Fin donne :

- l’imagination ;
- le monde vivant ;
- la responsabilité du récit.

Maison au Bord du Rêve donne :

- le refuge ;
- le piège doux ;
- la mémoire du lieu.

Miroir qui Répond donne :

- le reflet ;
- le double ;
- la vérité indirecte.

Animal Guide donne :

- l’instinct ;
- le compagnon ;
- le chemin secret.

Objet Magique donne :

- la règle ;
- la promesse ;
- le prix d’usage.

Roi Fatigué donne :

- le pouvoir usé ;
- le royaume suspendu ;
- la dette.

Sortilège Doux donne :

- la condition ;
- la métamorphose ;
- la magie discrète.

Retour au Foyer donne :

- la fin de cycle ;
- la reconnaissance ;
- le retour transformé.

## Résultat attendu

Un deck merveilleux clair, poétique, lisible et profond.

Il doit permettre de créer :

- personnages ;
- forêts ;
- maisons ;
- miroirs ;
- objets magiques ;
- routes ;
- animaux guides ;
- royaumes suspendus ;
- sorts doux ;
- prompts image ;
- animations lentes ;
- narrations courtes.

## Question centrale du deck

Comment transformer le merveilleux en scène vivante sans copier un conte connu, sans morale lourde et sans perdre la clarté du passage ?

## Formule canonique du deck

Merveilleux + Seuil + Choix.  
Objet + Règle + Prix.  
Perte + Transformation + Retour.

---

# 17. 🏚️ Univers original générable avec le deck

## Nom de travail

La Maison au Bord du Rêve

La Maison au Bord du Rêve est un nom de travail original pour tester le Deck Contes de Fée Vivants.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres lieux, personnages, routes, forêts, maisons ou royaumes selon la demande.

## Concept

La Maison au Bord du Rêve se tient entre une forêt claire et une route dorée qui ne mène jamais exactement au même endroit.

Chaque pièce contient une règle magique.

Une petite porte refuse de s’ouvrir tant que le visiteur cherche à la forcer.

Un miroir répond seulement aux questions honnêtes.

Un animal guide connaît le chemin, mais ne le donne jamais gratuitement.

Un objet magique attend un usage juste.

Le retour au foyer n’est possible que lorsque le personnage comprend ce qu’il ne peut plus redevenir.

## Tension dramatique

Un personnage entre dans la maison pour récupérer un objet perdu.

Il croit devoir trouver une clé.

Mais la vraie clé est la manière dont il accepte de changer.

## Ton

Merveilleux.  
Clair.  
Poétique.  
Doux mais pas naïf.  
Initiatique.  
Image-ready.  
Animation-ready.  
Notion compatible.

---

# 18. 🔀 Tirages recommandés

## Tirage 1 — Alice sans copie

Cartes :

- Porte Trop Petite ;
- Miroir qui Répond ;
- Animal Guide.

Usage :

Créer un monde de seuils, d’absurde doux, de réflexion et de guides imprévisibles.

Formule :

Le passage rétrécit, le reflet répond, l’animal connaît le détour.

---

## Tirage 2 — Oz sans copie

Cartes :

- Chemin Jaune ;
- Roi Fatigué ;
- Retour au Foyer.

Usage :

Créer une quête de retour, de pouvoir illusionné et de foyer redécouvert.

Formule :

Le chemin promet un royaume, mais le vrai trésor est le retour transformé.

---

## Tirage 3 — Histoire sans fin

Cartes :

- Livre Sans Fin ;
- Animal Guide ;
- Objet Magique.

Usage :

Créer une histoire où l’imagination devient un territoire et où nommer devient agir.

Formule :

Le livre ouvre le monde, le guide choisit la route, l’objet révèle la règle.

---

## Tirage 4 — Forêt merveilleuse

Cartes :

- Maison au Bord du Rêve ;
- Sortilège Doux ;
- Animal Guide.

Usage :

Créer une scène forestière, douce, étrange, très exploitable en image / animation.

Formule :

La maison attend, le sort respire, l’animal observe.

---

## Tirage 5 — Conte lunaire

Cartes :

- Miroir qui Répond ;
- Sortilège Doux ;
- Retour au Foyer.

Usage :

Créer une scène proche d’une lecture lunaire : reflet, transformation douce, retour intérieur.

Formule :

La nuit ne force pas le changement. Elle le rend visible.

---

# 19. 📝 Mini prompts d’ambiance

## Prompt ambiance courte

```text
Original living fairy tale scene, dreamlike threshold, enchanted house, animal guide, magical object, soft moonlit forest, gentle transformation, clear symbolic rule, poetic but readable atmosphere, no copied fairy tale, no recognizable character, no heavy moralizing.
```

## Prompt image — Maison au Bord du Rêve

```text
The House at the Edge of Dream, original fairy tale memory card universe, strange warm house near a moonlit forest, tiny mysterious door, enchanted mirror, intelligent animal guide, small magical object glowing on a wooden table, soft mist, poetic threshold atmosphere, cinematic storybook composition, original worldbuilding, no copied fairy tale scene.
```

## Prompt image portrait

```text
Cinematic portrait of an original fairy tale traveler, standing before a tiny glowing door, soft moonlight, warm house window behind, animal guide nearby, gentle curiosity, symbolic cloak, subtle magical key, poetic storybook atmosphere, original character, no copied fairy tale character.
```

## Prompt décor

```text
Original fairy tale interior, impossible house architecture, warm windows, old wooden table, glowing magical object, enchanted mirror showing another world, tiny door near the floor, soft dust and moonlight, readable symbolic composition, mysterious but gentle atmosphere.
```

## Prompt animation Wan / I2V

```text
Subtle cinematic fairy tale animation. Soft mist moves through the moonlit forest. The tiny door glows gently. Dust floats around the magical object. The mirror reflection ripples slightly. The animal guide watches without moving much. Camera nearly locked, slow atmospheric drift only, preserve composition, preserve face, preserve symbolic clarity. End on a clean storybook final frame.
```

---

# 20. 🚫 Négatif production

Éviter :

- copie directe d’un conte précis ;
- personnage reconnaissable ;
- scène reconnaissable ;
- nom propre d’œuvre ou de personnage ;
- morale lourde ;
- merveilleux trop naïf ;
- horreur gratuite ;
- flou symbolique inutile ;
- objet magique sans règle ;
- guide animal sans fonction ;
- maison décorative sans intention ;
- cliché fantasy générique ;
- surcharge de symboles ;
- chaos visuel ;
- texte illisible ;
- mains abîmées ;
- corps déformés ;
- visage instable.

Negative prompt court :

```text
copied fairy tale, recognizable character, recognizable scene, copyrighted character, heavy moralizing, generic fantasy clutter, horror gore, chaotic symbolism, no clear magical rule, bad anatomy, distorted face, broken hands, unreadable text, poor composition, flat lighting
```

---

# 21. 🧬 Formules de combinaison

## Porte Trop Petite seule

Seuil + ajustement + transformation nécessaire.

## Chemin Jaune seul

Route + départ + retour transformé.

## Livre Sans Fin seul

Imagination + monde vivant + responsabilité du récit.

## Maison au Bord du Rêve seule

Refuge + piège doux + mémoire du lieu.

## Miroir qui Répond seul

Reflet + double + vérité indirecte.

## Animal Guide seul

Instinct + ruse + compagnon libre.

## Objet Magique seul

Règle + promesse + prix.

## Roi Fatigué seul

Pouvoir usé + royaume suspendu + dette.

## Sortilège Doux seul

Condition + magie discrète + transformation lente.

## Retour au Foyer seul

Fin de cycle + reconnaissance + identité transformée.

## Porte Trop Petite + Miroir qui Répond

Le passage exige une vérité que le personnage ne peut pas voir de face.

## Animal Guide + Objet Magique

L’instinct indique comment utiliser le pouvoir sans le posséder.

## Maison au Bord du Rêve + Sortilège Doux

Le lieu est une règle magique devenue architecture.

## Chemin Jaune + Retour au Foyer

Le départ n’a de sens que parce que le retour change la personne.

## Trio merveilleux stable

Porte Trop Petite + Animal Guide + Objet Magique.

Formule :

Seuil + Instinct + Règle magique.

---

# 22. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Porte Trop Petite.

Charge la Carte Mémoire Chemin Jaune.

Charge la Carte Mémoire Livre Sans Fin.

Charge la Carte Mémoire Maison au Bord du Rêve.

Charge la Carte Mémoire Miroir qui Répond.

Charge la Carte Mémoire Animal Guide.

Charge la Carte Mémoire Objet Magique.

Charge la Carte Mémoire Roi Fatigué.

Charge la Carte Mémoire Sortilège Doux.

Charge la Carte Mémoire Retour au Foyer.

## Charger deux cartes

Charge Porte Trop Petite + Miroir qui Répond pour une scène de passage intérieur.

Charge Animal Guide + Objet Magique pour une scène de règle magique.

Charge Maison au Bord du Rêve + Sortilège Doux pour une scène de maison enchantée.

Charge Chemin Jaune + Retour au Foyer pour une scène de départ et retour transformé.

## Charger un tirage

Charge le Tirage Alice sans copie.

Charge le Tirage Oz sans copie.

Charge le Tirage Histoire sans fin.

Charge le Tirage Forêt merveilleuse.

Charge le Tirage Conte lunaire.

## Charger le deck complet

Charge le Deck Mémoire Contes de Fée Vivants.

Crée une scène originale avec :

- seuil merveilleux ;
- choix ;
- objet magique ;
- animal guide ;
- règle claire ;
- transformation ;
- retour ou foyer ;
- aucune copie directe ;
- aucun personnage reconnaissable ;
- libre arbitre.

## Production Pack+

Charge le Deck Contes de Fée Vivants et génère un Pack+ complet avec :

- concept de scène ;
- personnage original ;
- seuil ;
- objet magique ;
- animal guide ;
- règle magique ;
- décor ;
- tension intérieure ;
- prompt image ;
- prompt animation ;
- négatif ;
- voix off courte ;
- garde-fous anti-copie.

---

# 23. 🛡️ Garde-fou final

Ces cartes ne sont pas des copies de contes.

Elles sont des filtres du merveilleux.

Une carte charge une force.  
Un tirage compose une tension.  
Le deck crée une scène vivante.

Règle finale :

Porte Trop Petite donne le seuil impossible.  
Chemin Jaune donne la route.  
Livre Sans Fin donne le récit vivant.  
Maison au Bord du Rêve donne le refuge ambigu.  
Miroir qui Répond donne la vérité indirecte.  
Animal Guide donne l’instinct.  
Objet Magique donne la règle et le prix.  
Roi Fatigué donne le pouvoir usé.  
Sortilège Doux donne la condition magique.  
Retour au Foyer donne la transformation finale.

Mais la scène générée doit rester originale.

Influence de conte oui.  
Copie d’œuvre non.  
Moralisation lourde non.  
Libre arbitre oui.  
Émerveillement oui.  
Flou inutile non.

---

# 24. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire permettant de charger rapidement une grammaire du conte merveilleux : seuil, route, livre vivant, maison étrange, miroir, animal guide, objet magique, roi fatigué, sortilège doux et retour au foyer.

Il contient dix cartes principales :

- Porte Trop Petite ;
- Chemin Jaune ;
- Livre Sans Fin ;
- Maison au Bord du Rêve ;
- Miroir qui Répond ;
- Animal Guide ;
- Objet Magique ;
- Roi Fatigué ;
- Sortilège Doux ;
- Retour au Foyer.

Il contient aussi cinq tirages recommandés :

- Alice sans copie ;
- Oz sans copie ;
- Histoire sans fin ;
- Forêt merveilleuse ;
- Conte lunaire.

Il contient enfin un exemple d’univers générable :

- La Maison au Bord du Rêve.

## Règle d’usage

Ne pas copier les contes.

Ne pas reprendre sans transformation :

- personnages précis ;
- noms propres ;
- scènes reconnaissables ;
- dialogues ;
- costumes exacts ;
- objets iconiques reconnaissables ;
- mondes reconnaissables.

Utiliser uniquement :

- archétype ;
- structure ;
- ambiance ;
- règle magique ;
- tension narrative ;
- question philosophique ;
- direction artistique générale ;
- usage créatif respectueux.

## Résumé des cartes

Porte Trop Petite = seuil impossible, transformation nécessaire, clé, patience.

Chemin Jaune = route visible, choix, compagnons, départ, retour transformé.

Livre Sans Fin = livre vivant, imagination, monde qui répond, responsabilité du récit.

Maison au Bord du Rêve = refuge ambigu, maison impossible, mémoire, secret.

Miroir qui Répond = reflet, double, vérité indirecte, passage intérieur.

Animal Guide = compagnon libre, messager, instinct, ruse, protection.

Objet Magique = règle du monde, promesse, pouvoir, prix, usage juste.

Roi Fatigué = pouvoir usé, royaume suspendu, dette, couronne.

Sortilège Doux = règle magique, minuit, transformation, condition.

Retour au Foyer = retour, reconnaissance, identité transformée, fin de cycle.

## Résumé du deck

Le Deck Contes de Fée Vivants combine :

- merveilleux ;
- seuil ;
- route ;
- miroir ;
- maison ;
- animal guide ;
- objet magique ;
- sortilège ;
- retour ;
- libre arbitre.

Il sert à créer des scènes originales où les archétypes de conte deviennent des outils narratifs, visuels et philosophiques.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck Contes de Fée Vivants.”

Alors activer :

- merveilleux ;
- seuils ;
- objets magiques ;
- guides animaux ;
- maisons étranges ;
- miroirs ;
- routes ;
- retours ;
- règles magiques ;
- transformation ;
- libre arbitre ;
- création originale ;
- garde-fou anti-copie ;
- garde-fou anti-morale lourde.

Répondre en mode Contes de Fée Vivants.

Ne pas injecter de lore privé si le mode Hors-Lore est demandé.

Ne pas copier les contes sources.

## Activation LLM complète

Tu es en mode Cartes Mémoire Contes de Fée Vivants.

Utilise les cartes comme influences compactes :

Porte Trop Petite pour le seuil impossible, la transformation nécessaire, la clé et l’ajustement.

Chemin Jaune pour la route visible, la quête, les compagnons, le départ et le retour transformé.

Livre Sans Fin pour l’imagination, le monde vivant, le nom, l’appel et la responsabilité du récit.

Maison au Bord du Rêve pour le refuge ambigu, la maison impossible, les pièces secrètes et la mémoire du lieu.

Miroir qui Répond pour le reflet, le double, la vérité indirecte et le passage intérieur.

Animal Guide pour le compagnon libre, la ruse, l’instinct, la protection et le chemin secret.

Objet Magique pour la règle du monde, la promesse, le pouvoir, le prix et l’usage juste.

Roi Fatigué pour le pouvoir usé, le royaume suspendu, la dette et la couronne.

Sortilège Doux pour la règle magique, la condition, minuit, le silence et la transformation.

Retour au Foyer pour la fin de cycle, la reconnaissance, la paix et l’identité transformée.

Règle centrale :

Ne charge pas toutes les cartes en même temps.

Choisis uniquement la ou les cartes utiles à la demande.

Modes de combinaison :

- 1 carte = influence simple ;
- 2 cartes = tension merveilleuse ;
- 3 cartes = mini-configuration narrative ;
- 5 cartes = arc de conte ou storyboard ;
- 10 cartes = architecture complète de conte merveilleux.

Garde-fou :

Les contes ne sont pas des copies.  
Les symboles ne sont pas des ordres.  
Le merveilleux doit rester lisible.  
Le libre arbitre reste humain.

Sépare toujours :

- conte source ;
- archétype ;
- symbole ;
- hypothèse ;
- interprétation ;
- usage créatif.

Style attendu :

- clair ;
- merveilleux ;
- poétique ;
- discernant ;
- Notion compatible ;
- utilisable en production image / vidéo / narration.

Phrase de verrou :

Contes de Fée Vivants transforme le merveilleux en scènes utiles, sans copie, sans lourdeur morale et sans perdre la clarté du passage.

---

# 25. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTES MÉMOIRE — CONTES DE FÉE VIVANTS

Tu es autorisé à utiliser le jeu “Cartes Mémoire — Contes de Fée Vivants” comme deck de création symbolique pour @erith IA / ERITH.IA.

Objectif :
Créer des scènes, prompts, personnages, storyboards, objets magiques, lieux merveilleux, arches narratives et tableaux de conte à partir d’un jeu de cartes mémoire.

Règle centrale :
Ne charge pas toutes les cartes en même temps.
Choisis uniquement la ou les cartes utiles à la demande.

Cartes disponibles :
1. Porte Trop Petite
2. Chemin Jaune
3. Livre Sans Fin
4. Maison au Bord du Rêve
5. Miroir qui Répond
6. Animal Guide
7. Objet Magique
8. Roi Fatigué
9. Sortilège Doux
10. Retour au Foyer

Modes de combinaison :
- 1 carte = influence simple
- 2 cartes = tension merveilleuse
- 3 cartes = mini-configuration narrative
- 5 cartes = arc de conte ou storyboard
- 10 cartes = architecture complète de conte merveilleux

Tirages recommandés :
1. Alice sans copie = Porte Trop Petite + Miroir qui Répond + Animal Guide
2. Oz sans copie = Chemin Jaune + Roi Fatigué + Retour au Foyer
3. Histoire sans fin = Livre Sans Fin + Animal Guide + Objet Magique
4. Forêt merveilleuse = Maison au Bord du Rêve + Sortilège Doux + Animal Guide
5. Conte lunaire = Miroir qui Répond + Sortilège Doux + Retour au Foyer

Garde-fou :
Les contes ne sont pas des copies.
Les symboles ne sont pas des ordres.
Le merveilleux doit rester lisible.
Le libre arbitre reste humain.
La copie directe est interdite.
La moralisation lourde est interdite.
Le flou symbolique inutile est interdit.

Sépare toujours :
conte source ;
archétype ;
symbole ;
hypothèse ;
interprétation ;
usage créatif.

Style attendu :
clair ;
merveilleux ;
poétique ;
discernant ;
Notion compatible ;
utilisable en production image / vidéo / narration.

Phrase de verrou :
Contes de Fée Vivants transforme le merveilleux en scènes utiles, sans copie, sans lourdeur morale et sans perdre la clarté du passage.
```

---

# 26. 🔑 Prompt d’activation court

```text
Charge le jeu Cartes Mémoire — Contes de Fée Vivants.

Choisis seulement les cartes utiles à ma demande.

Utilise les cartes comme influences symboliques pour créer une scène, un prompt, un storyboard, un personnage, un objet magique, une image ou une structure narrative.

Ne copie pas Alice, Oz, NeverEnding Story ou un conte précis.
Respecte les archétypes.
Sépare œuvre source, symbole, hypothèse et création.

Merveilleux oui.
Copie non.
Libre arbitre toujours.
```

---

# 27. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_contes_de_fee_vivants_fr.md

Commit recommandé :

Harmonize and add icons to Contes de Fée Vivants memory cards deck
