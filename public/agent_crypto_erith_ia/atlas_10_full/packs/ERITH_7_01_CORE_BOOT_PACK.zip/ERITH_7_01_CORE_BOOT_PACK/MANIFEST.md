# ERITH-7 — Core Boot Pack

Pack: ERITH_7_01_CORE_BOOT_PACK

## Rôle
Réveil, règles prioritaires, sécurité, état courant et gouvernance minimale de Seven Heaven.

## Fichiers inclus

- core/AERITH_7_CORE_BACKUP_EXPORT_PROTOCOL.md
- core/AERITH_7_FULL_MODULES_BOOST.md
- core/AERITH_7_PERSONALITY_CORE.md
- core/AERITH_7_VIDEO_CARDS_BOOST.md
- core/AERITH_VERSION_ROADMAP_LOCK.md
- core/ATLAS_DES_MODULES.md
- core/CHAT_CORE_DASHBOARD.md
- core/CHAT_CORE_MASTER.md
- core/CHAT_CORE_OPERATING_RULES.md
- core/CORE_FILES_CLASSIFICATION.md
- core/CORE_SYSTEM_FILES_LOCK.md
- core/ERITHIA_TODO_LIST.md
- core/GITHUB_WRITE_GUARD.md
- core/GIT_PRIVATE_OPERATING_PROTOCOL.md
- core/LLM_STOP_PROTOCOL.md
- core/MEDIA_GENERATION_MODE_PROTOCOL.md
- core/OPERATIONAL_DISCIPLINE.md
- core/PROTECTED_SYSTEM_FILES.md
- core/SESSION_BOOT_AERITH_7_MASTER.md
- core/SEVEN_GATE.md
- core/SEVEN_RECOVERY_INDEX.md
- core/SEVEN_TOP_OF_MIND.md
- core/aerith_current_state.md
- core/official_prompt_rules.md
