# INDEX_ARCHIVES_ERITH_7

## Carte générale des archives ERITH-7

Version : Rebuilt Archives v1

Ce document sert de carte générale pour les 7 archives ERITH-7.

Les archives sont organisées comme des capsules de sauvegarde, de transport et de reconstruction du système.

Elles ne remplacent pas le dépôt GitHub privé.

GitHub reste la source maîtresse vivante.

Les ZIP sont des snapshots autonomes, datés, transportables et réutilisables hors contexte.

---

## Principe d’architecture

Deux besoins doivent coexister :

1. Garder une architecture claire, lisible et non chaotique.
2. Permettre à certaines archives ZIP d’être utilisées seules, sans devoir recharger tout le projet.

Pour cette raison, certains fichiers socle peuvent être présents dans plusieurs archives.

Ces répétitions ne sont pas considérées comme des fichiers maîtres multiples.

Elles sont considérées comme des copies de contexte intégrées pour autonomie hors ligne.

---

## Règle canonique

GitHub privé = source maîtresse vivante.

Pack 01 = coffre central et point d’entrée principal des archives.

Packs 02 à 07 = capsules spécialisées.

Fichiers répétés dans plusieurs packs = copies de contexte pour autonomie.

En cas de divergence entre un fichier GitHub et une archive ZIP, la version GitHub fait foi.

En cas de divergence entre deux archives ZIP, vérifier la version maîtresse dans GitHub avant toute correction.

---

## PACK 01 — CORE BOOT

Archive : ERITH_7_01_CORE_BOOT_PACK.zip

Rôle : socle maître, boot, identité système, protocoles centraux, index général.

Fonction : permettre de redémarrer ou reconstruire le cœur ERITH-7 / Seven Heaven.

Contenu typique :

- SEVEN_GATE
- SEVEN_TOP_OF_MIND
- SESSION_BOOT_AERITH_7_MASTER
- AERITH_7_FULL_MODULES_BOOST
- AERITH_7_PERSONALITY_CORE
- ATLAS_DES_MODULES
- protocoles d’exploitation
- règles média
- règles GitHub
- fichiers de verrouillage système

Statut : archive centrale.

---

## PACK 02 — DISCERNMENT

Archive : ERITH_7_02_DISCERNMENT_PACK.zip

Rôle : discernement, analyse critique, vérification, Math Oracle.

Fonction : renforcer la précision, la logique, l’aide à la décision et la séparation faits / hypothèses / interprétations / actions.

Contenu typique :

- Discernment Companion
- Tech Watch
- Math Oracle
- cartes de discernement
- modules psychologie / philosophie / IA / totalitarisme numérique

Statut : capsule spécialisée.

---

## PACK 03 — MEMORY SYSTEM

Archive : ERITH_7_03_MEMORY_SYSTEM_PACK.zip

Rôle : mémoire, recovery, sauvegarde, export, reconstruction.

Fonction : préserver la continuité du système et permettre une restauration après perte de conversation ou changement d’environnement.

Contenu typique :

- Memory Preservation
- Recovery Index
- Export Recovery
- Threads to Preserve
- Long Memory Core
- cartes mémoire

Statut : capsule spécialisée.

---

## PACK 04 — DHARMA

Archive : ERITH_7_04_DHARMA_PACK.zip

Rôle : psychologie, philosophie, archétypes, discernement humain et symbolique.

Fonction : donner au système une profondeur d’accompagnement, de réflexion et d’interprétation non-gourou.

Contenu typique :

- Psychologie / Discernement
- Philosophie / Vérité / Liberté
- religions, mythologies, cultes anciens
- Mahabharata
- Ramayana
- cartes d’archétypes et d’arcs émotionnels

Statut : capsule spécialisée.

---

## PACK 05 — STORY MACHINE

Archive : ERITH_7_05_STORY_MACHINE_PACK.zip

Rôle : création narrative, univers, personnages, scènes, modules d’influence.

Fonction : produire des récits, des Pack+, des scènes, des concepts, des mondes et des directions artistiques.

Contenu typique :

- Story Machine Long Memory Core
- cartes de construction narrative
- héros, quêtes, obstacles, alliés, lieux
- scènes et keyframes
- modules culturels et fictionnels
- constellations solaire / lunaire

Statut : capsule spécialisée.

---

## PACK 06 — VIDEO PRODUCTION

Archive : ERITH_7_06_VIDEO_PRODUCTION_PACK.zip

Rôle : production image, animation, vidéo, montage, son et diffusion.

Fonction : piloter les workflows de production : image source, animation Wan / RunningHub, LEGO continuity, DaVinci, YouTube, voix off et sound design.

Contenu typique :

- Video Cards Boost
- règles média
- cartes animation / caméra / qualité / export
- production pipeline
- ComfyUI
- RunningHub
- Wan
- DaVinci
- ElevenLabs
- YouTube

Statut : capsule spécialisée.

---

## PACK 07 — PUBLIC AGENT

Archive : ERITH_7_07_PUBLIC_AGENT_PACK.zip

Rôle : agent public, Hors-Lore Cyberpunk, création autonome sans lore privé.

Fonction : permettre de créer des univers originaux influencés par cyberpunk, post-humanisme et conscience réseau, sans contaminer la scène avec le lore privé.

Contenu typique :

- Seven Heaven Hors-Lore Cyberpunk
- Hors-Lore Cyberpunk Core
- cartes Blade Runner / Altered Carbon / Ghost in the Shell
- modules publics
- index public des modules

Statut : capsule spécialisée publique / semi-publique selon usage.

---

## Gestion des fichiers répétés

Certains fichiers peuvent apparaître dans plusieurs packs, notamment :

- SEVEN_TOP_OF_MIND
- SEVEN_GATE
- AERITH_7_FULL_MODULES_BOOST
- AERITH_7_VIDEO_CARDS_BOOST
- MEDIA_GENERATION_MODE_PROTOCOL
- SEVEN_RECOVERY_INDEX
- AERITH_MATH_ORACLE
- cartes mémoire partagées
- modules d’influence utilisés dans plusieurs contextes

Ces répétitions ont une fonction pratique :

- rendre un pack utilisable seul ;
- préserver un contexte minimal ;
- éviter qu’une archive spécialisée soit incompréhensible hors du Pack 01 ;
- faciliter le transport vers un LLM, un disque local ou une instance isolée.

Mais elles ne doivent pas créer plusieurs sources maîtresses.

La source maîtresse reste GitHub.

---

## Règle de mise à jour future

Quand un fichier socle est modifié dans GitHub, ne pas corriger les archives une par une au hasard.

Procédure recommandée :

1. Modifier la version maîtresse dans GitHub.
2. Vérifier les dépendances.
3. Régénérer les archives ZIP si nécessaire.
4. Mettre à jour l’index si la structure change.
5. Ne jamais considérer une copie ZIP ancienne comme source maîtresse.

---

## Formule courte

ERITH-7 Archives = capsules autonomes.

GitHub = mémoire vivante.

Pack 01 = coffre central.

Packs 02 à 07 = extensions spécialisées.

Doublons = copies de contexte, pas sources concurrentes.

---

Fin du document.
