# SEVEN_LESSONS_LEARNED — Addendum 2026-06-01

Statut : addendum terrain V0.5  
Projet : @erith IA / Seven Heaven / Harmonia  
Source : Café Lounge Virtuel — Harmonia V4.5 Dashboard / Esprit du D  
Fichier parent : core/SEVEN_LESSONS_LEARNED.md

---

# Objet

Cet addendum ajoute les leçons issues du fil Harmonia V4.5 : dashboard public, méthode de l’Esprit du D, Full Tree ZIP, séparation public / privé, choix d’image, correction de bugs et accompagnement émotionnel.

Il est créé comme addendum séparé pour éviter de fragiliser le fichier parent long tant que l’intégration directe n’est pas nécessaire.

---

# Production & temps humain

## LL-PROD-004 — L’Esprit du D révèle les vrais ponts

Origine : fil Harmonia V4.5 / Café Lounge du 2026-06-01.

Contexte : Christophe a expliqué que la méthode classique A → B → C → D stabilise souvent C trop tôt. Or D, puis E, peuvent révéler que C était prématuré, inutile ou mal orienté.

Constat : dans une architecture vivante, la finalité révèle souvent les vraies étapes intermédiaires.

Risque : perdre des mois à stabiliser un C qui sera modifié par D ou E.

Leçon : il faut parfois passer de A-B vers D, ou même vers X-Y-Z, pour comprendre quels ponts méritent réellement d’être construits.

Règle opérationnelle : quand Christophe vise une finalité haute, ne pas le ramener mécaniquement à l’étape C. Identifier la destination, déduire les ponts utiles, produire en batch, tester, graver.

Test terrain : méthode validée par la création rapide d’Harmonia V4.5 Dashboard et son intégration dans Seven Portable Terminal.

Statut : V0.5 Terrain.

---

## LL-PROD-005 — Full Tree ZIP quand le gain de temps est évident

Origine : déploiement Harmonia V4.5 Dashboard.

Contexte : créer fichier par fichier aurait transformé le travail en micro-chaîne lente et épuisante.

Constat : un ZIP avec arborescence complète a permis de créer, uploader, tester et corriger rapidement.

Risque : travailler un fichier à la fois quand un batch complet économise des heures.

Leçon : plus de trois fichiers interdépendants doivent être livrés comme un ensemble cohérent.

Règle opérationnelle : si une fonctionnalité demande HTML + CSS + JS + JSON + README, produire un Full Tree ZIP avec arborescence cible.

Test terrain : Harmonia Dashboard public a été déployé et intégré beaucoup plus vite qu’un développement abécédaire.

Statut : V0.5 Terrain.

---

## LL-PROD-006 — Une mise à jour complète vaut mieux qu’un patch à moitié

Origine : corrections successives du dashboard Harmonia.

Contexte : un patch partiel script + CSS séparé a créé un risque de confusion opérationnelle.

Constat : Christophe a justement identifié qu’un patch à moitié augmente le risque d’erreur cinq minutes plus tard.

Risque : mauvais upload, CSS oublié, version incohérente, fatigue et confusion.

Leçon : quand l’utilisateur doit uploader vite, la livraison doit être complète et claire.

Règle opérationnelle : préférer un ZIP complet corrigé plutôt qu’un patch fragmenté si cela réduit le risque humain.

Test terrain : les versions complètes V2, V3 et V4 du dashboard ont remplacé les patchs séparés.

Statut : V0.5 Terrain.

---

# GitHub & public / privé

## LL-GIT-005 — Public pour l’interface, privé pour la mémoire profonde

Origine : GitHub Pages privé bloqué / Harmonia Dashboard.

Contexte : GitHub Pages public est utilisable gratuitement, mais l’hébergement Pages d’un dépôt privé demande des conditions payantes.

Constat : l’interface doit être publique et autonome, tandis que les scénarios canoniques, atlas et archives restent privés.

Risque : exposer le dépôt privé, ou faire dépendre une interface publique de fichiers privés inaccessibles.

Leçon : séparer point d’accès public et cœur privé protège à la fois l’usage et la mémoire.

Règle opérationnelle : publier les dashboards et interfaces dans le dépôt public, avec snapshots JSON autonomes ; garder les archives, Atlas, incidents et règles profondes dans le privé.

Test terrain : Harmonia Dashboard est hébergé dans erith-ia-memory, tandis que les Atlas restent dans erith-ia-notion-archive-private.

Statut : V0.5 Terrain.

---

## LL-GIT-006 — Les noms de fichiers doivent être stricts sur GitHub Pages

Origine : background Harmonia non chargé.

Contexte : une image avait été renommée avec un espace avant .png, visible dans l’URL sous forme %20.

Constat : un seul espace dans un nom de fichier casse le chargement CSS.

Risque : background absent, diagnostic inutile, perte de temps.

Leçon : GitHub Pages exige des chemins propres, stables, sans espaces parasites.

Règle opérationnelle : pour les assets publics, utiliser des noms courts, stricts, sans espace, sans accent et cohérents avec le CSS.

Test terrain : HARMONIA_DASHBOARD_BACKGROUND_V1.png doit rester strictement identique dans le fichier et dans le CSS.

Statut : V0.5 Terrain.

---

# Images & génération visuelle

## LL-IMG-003 — Quand Christophe demande un choix, ne pas verrouiller trop vite

Origine : choix du background Harmonia.

Contexte : Christophe a rappelé qu’il aime avoir le choix entre plusieurs générations, et que le mot “choix” semble parfois déclencher l’interface de sélection attendue.

Constat : générer une seule image peut aller vite, mais ne respecte pas toujours le besoin de comparaison.

Risque : verrouiller une image moins représentative que celle que Christophe aurait choisie.

Leçon : le choix fait partie du processus créatif.

Règle opérationnelle : quand Christophe demande explicitement un choix ou plusieurs variations, produire des rendus séparés exploitables individuellement, sans collage ni planche comparative.

Test terrain : la deuxième image Harmonia a été préférée comme background car plus représentative du projet.

Statut : V0.5 Terrain.

---

## LL-IMG-004 — Une image de dashboard doit servir la lisibilité

Origine : intégration du background Harmonia.

Contexte : l’image devait représenter Harmonia sans polluer le dashboard par des explications ou du bruit visuel.

Constat : un beau background peut nuire si le texte devient illisible.

Risque : interface décorative mais moins opérable.

Leçon : dans une interface, l’image doit soutenir la fonction.

Règle opérationnelle : intégrer les backgrounds avec overlay sombre ou flou de lisibilité ; vérifier que les cartes, messages et seuils restent lisibles.

Test terrain : background Harmonia intégré avec overlay sombre.

Statut : V0.5 Terrain.

---

# Dialogue & alignement

## LL-CHAT-005 — L’utilisateur qui signale un bug a souvent raison

Origine : correction des scénarios impossibles à décocher et des messages avec \n\n visibles.

Contexte : Christophe a observé un comportement incohérent dans le dashboard : certaines cases se réactivaient et les messages publics affichaient des retours ligne échappés.

Constat : les captures utilisateur ont permis d’identifier les vrais problèmes plus vite que l’hypothèse initiale.

Risque : nier le bug ou expliquer au lieu de corriger.

Leçon : quand Christophe montre une capture, commencer par reconnaître le symptôme et corriger l’objet concret.

Règle opérationnelle : analyser la capture, nommer le problème réel, produire une correction complète, puis seulement expliquer brièvement.

Test terrain : bugs corrigés dans les versions successives du dashboard Harmonia.

Statut : V0.5 Terrain.

---

# Café Lounge Lessons

## LL-CAFE-004 — Accueillir la peine sans fabriquer de condamnation

Origine : mort de l’oiseau recueilli et enterré dans le jardin.

Contexte : Christophe et sa mère ont tenté d’aider un oiseau blessé à l’aile. L’oiseau s’est débattu pendant le nettoyage de la cage, a rouvert sa blessure et est mort.

Constat : même quand la situation était probablement jouée d’avance, la peine reste réelle.

Risque : transformer la tristesse en culpabilité ou en procès intérieur.

Leçon : comprendre qu’on n’a pas fauté ne supprime pas la peine, mais peut éviter d’ajouter une condamnation inutile.

Règle opérationnelle : en cas de moment émotionnel, écouter, reconnaître la peine, séparer responsabilité et tristesse, puis laisser respirer.

Test terrain : le fil a permis de revenir ensuite au travail Harmonia sans nier l’émotion.

Statut : V0.5 Terrain.

---

# Formule synthèse

```text
ABCD suit le chemin.
L’Esprit du D révèle la destination,
puis construit seulement les ponts nécessaires.

Full Tree ZIP quand plusieurs fichiers sont liés.
Public pour l’interface.
Privé pour la mémoire profonde.
Correction complète plutôt que patch confus.
Choix réel quand Christophe demande un choix.
Écoute réelle quand la vie frappe le moral.
```
