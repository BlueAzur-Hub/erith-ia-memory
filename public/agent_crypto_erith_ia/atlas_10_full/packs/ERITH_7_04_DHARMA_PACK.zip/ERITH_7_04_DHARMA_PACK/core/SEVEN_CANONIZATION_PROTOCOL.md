# SEVEN_CANONIZATION_PROTOCOL.md

Version : V0

# Objet

Définir comment une idée devient canonique.

---

Idée
↓
Observation
↓
Lesson Learned
↓
Golden Rule
↓
Principe Fondateur
↓
Canonisation

---

# Conditions

- survivre au terrain ;
- être utile ;
- être relue ;
- ne pas entrer en contradiction avec les fondations ;
- avoir démontré sa valeur.

---

# Règle

Rien n’est canonique immédiatement.

Le terrain décide.