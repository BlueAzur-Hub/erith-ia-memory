# ERITH.IA — Œuvre fondatrice — Nihon Shoki

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Japon ancien  
Œuvre : Nihon Shoki  
Fonction : apporter à ERITH.IA une base historique, mythologique et politique sur les chroniques anciennes du Japon.

Le Nihon Shoki, achevé au VIIIe siècle, est une chronique majeure du Japon ancien. Il organise les récits mythiques, les lignées impériales, les événements politiques et la mémoire officielle dans une forme plus historiographique que le Kojiki.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire de chronique ancienne ;
- une lecture du Japon par dynastie, légitimité, lignage, ordre et État ;
- une compréhension du lien entre mythe, pouvoir et écriture historique ;
- une esthétique de cour ancienne, archives, rouleaux, sceaux, sanctuaires et cérémonies ;
- une base pour scènes de mémoire impériale, légitimation, transmission et chronique.

## Axes principaux

Chronique officielle  
Généalogie impériale  
Kami et souveraineté  
Écriture de l’histoire  
Influence chinoise dans la forme historiographique  
Mémoire d’État  
Mythe organisé en chronologie

## Figures et motifs majeurs

- Amaterasu : souveraineté solaire, origine sacrée.
- Ninigi : descente céleste, transmission des trésors.
- Jimmu : figure fondatrice impériale.
- Les souverains anciens : lignage, continuité, mémoire.
- Les trois trésors sacrés : miroir, sabre, joyau.
- La chronique : ordre du temps, légitimité, archive.
- Le palais : pouvoir, rituel, continuité politique.
- Le sanctuaire : lien entre visible, sacré et souveraineté.

## Thèmes profonds

Mémoire officielle  
Mythe et légitimité politique  
Chronologie et pouvoir  
Transmission des lignées  
Sacré et gouvernement  
Écriture comme stabilisation du monde  
Comparaison entre récit poétique et récit chroniqué  
Construction d’une identité ancienne

## Garde-fous

Ne pas lire le Nihon Shoki comme une histoire moderne au sens scientifique strict.

Ne pas le confondre avec le Kojiki : le Kojiki est plus narratif et mythique ; le Nihon Shoki est plus chroniqué, officiel et historiographique.

Ne pas transformer la chronique en propagande simpliste : elle doit être traitée comme un document ancien où mythe, pouvoir, mémoire et écriture s’entrelacent.

Séparer :

- récit mythologique ;
- chronique officielle ;
- histoire politique ;
- usage culturel ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : rouleaux, encre, sceaux, bois sombre, soie, papier, or discret, miroir rituel.  
Lumière : lumière de palais, bougie, aube cérémonielle, reflets dorés très sobres.  
Architecture : cour ancienne, palais, sanctuaire, salle d’archives, jardin rituel.  
Ambiance : officielle, grave, ordonnée, rituelle, ancienne.

## Prompt image — base

Une salle de chronique japonaise ancienne, rouleaux ouverts, calligraphie non lisible, sceaux, miroir rituel, lumière dorée sobre, silhouettes de scribes et de dignitaires dans une cour ancienne, atmosphère de mémoire impériale et de récit sacré, peinture historique cinématographique, sans texte lisible, sans franchise moderne.

## Prompt animation — base

Caméra lente sur des rouleaux anciens dans une salle de palais japonais archaïque, bougie vacillante, encre sombre, sceau rituel, silhouettes immobiles, lumière dorée discrète, ambiance solennelle et archivistique, mouvement minimal, continuité stable.

## Prompt négatif

anime moderne, manga, samouraï cliché, ninja, ordinateur, bibliothèque moderne, texte lisible, logo, jeu vidéo identifiable, fantasy générique, couleurs criardes, anachronisme.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter le Nihon Shoki comme une chronique ancienne où mythe, souveraineté, mémoire officielle, lignage et écriture historique s’entrelacent. Le module doit aider à créer des scènes de chronique, de palais, de sanctuaire, de transmission et de mémoire impériale, en distinguant clairement mythe, histoire, politique ancienne et usage créatif.

## Formule courte

Nihon Shoki = chronique ancienne + lignage + souveraineté + mémoire officielle du Japon.
