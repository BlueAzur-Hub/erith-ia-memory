# 🏛️ MEMORY CARDS — MYTHOLOGIE VIVANTE

Statut : module de cartes mémoire  
Type : deck symbolique activable  
Mode recommandé : Mythologie Vivante / Hors-Lore Symbolique / Production  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / prompt image / prompt animation / narration / storyboard / symbolique / personnages / scènes initiatiques / univers originaux

🖼️ Visuels associés :

- Aucun visuel associé validé pour l’instant.
- À produire plus tard si besoin :
  - cover premium du deck Mythologie Vivante ;
  - planche des 10 cartes ;
  - dossier visuel “Sanctuaire des Seuils” ;
  - fiche Pack+ Mythologie Vivante.

---

# 1. 🏛️ Rôle du fichier

Ce fichier définit un système de Cartes Mémoire pour charger rapidement des forces mythologiques, symboliques et initiatiques sans relire les modules complets.

Une Carte Mémoire n’est pas une encyclopédie.

Une Carte Mémoire est une influence compacte, contrôlée, activable.

Elle sert à charger :

- une force mythique ;
- une image symbolique ;
- une tension intérieure ;
- une structure de passage ;
- une direction artistique ;
- une logique de personnage ;
- une base de prompt ;
- un garde-fou contre la copie, le dogme et le fatalisme.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Module complet = connaissance profonde.  
Carte Mémoire = symbole rapide.  
Deck = combinaison d’archétypes.

Ce module est pensé comme une carte active du GitHub privé : il peut être relu rapidement par Seven Heaven, ERITH.IA, un LLM local, Ollama ou un Auto-Agent sans déclencher de chargement massif.

Le but n’est pas de recopier des mythes.

Le but est d’extraire des forces créatives.

Formule du deck :

Mythe + Symbole + Passage = scène vivante.

---

# 2. 🧭 Règle Mythologie Vivante

Ces cartes sont prévues pour créer des scènes originales, des personnages archétypaux, des prompts, des storyboards et des univers symboliques.

Elles ne doivent pas copier les mythes, les textes sacrés ou les figures cultuelles.

Interdit :

- recopier directement un récit sacré ;
- reprendre une scène religieuse précise sans contexte ;
- mélanger toutes les traditions sans discernement ;
- réduire une culture à un simple décor ;
- transformer une mythologie en skin visuel ;
- transformer un symbole en vérité absolue ;
- produire une lecture fataliste ;
- faire du religieux forcé ;
- faire du gourou ;
- confondre inspiration, croyance, histoire et preuve ;
- confondre archétype et divinité précise ;
- utiliser les traditions comme accessoires décoratifs.

Autorisé :

- utiliser les mythes comme matière symbolique ;
- respecter les cultures sources ;
- distinguer fait historique, tradition, symbole, interprétation et création ;
- produire des scènes originales ;
- créer des personnages archétypaux sans copier une divinité précise ;
- transformer les symboles en structure utile ;
- garder le libre arbitre dans les lectures ;
- explorer des questions existentielles ;
- créer des images fortes, mais non dogmatiques ;
- transformer l’influence en univers autonome.

Règle simple :

Inspirer sans voler.  
Transformer sans trahir.  
Créer une scène vivante.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en mode Mythologie Vivante ;
- ne pas charger les modules complets si la carte suffit ;
- ne pas mélanger les traditions sans intention claire ;
- ne pas transformer Aerith-7 en personnage de scène sauf demande explicite ;
- ne pas ramener le lore privé dans une scène Hors-Lore ;
- utiliser les cartes comme filtres symboliques, pas comme encyclopédie ;
- produire des scènes exploitables en Pack+ ;
- distinguer influence, tradition, interprétation, hypothèse narrative et sortie de production.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire influence.  
Le Deck compose.  
La scène générée reste originale.

---

# 3. 🧩 Usage général des Cartes Mémoire

Une carte peut être activée seule :

- Carte Cosmogonie ;
- Carte Oracle ;
- Carte Héros du Seuil ;
- Carte Déesse-Miroir ;
- Carte Dieu du Temps ;
- Carte Forêt Sacrée ;
- Carte Sacrifice / Offrande ;
- Carte Monstre Gardien ;
- Carte Chute du Roi ;
- Carte Étoile de Mémoire.

Ou combinée en deck :

- Deck Naissance d’un Monde ;
- Deck Passage Initiatique ;
- Deck Chute d’un Empire ;
- Deck Vision Lunaire ;
- Deck Mythe Technologique ;
- Deck Mythologie Vivante complet.

Activation courte :

Charge la Carte Mémoire Oracle.

Activation combinée :

Charge les cartes Héros du Seuil, Monstre Gardien et Oracle pour créer une scène initiatique originale.

Activation production :

Charge le Deck Mythologie Vivante et produis un Pack+ complet : concept, scène, personnage, prompt image, prompt animation, narration courte et garde-fous symboliques.

Sortie Pack+ recommandée :

- concept de scène ;
- personnage original ;
- symbole central ;
- tension intérieure ;
- décor ;
- prompt image ;
- prompt animation Wan / I2V ;
- négatif production ;
- voix off courte ;
- garde-fous culturels et symboliques ;
- note de continuité si la scène doit devenir une séquence vidéo.

Règle image :

Le module peut produire des prompts image ou animation, mais ne doit pas générer d’image automatiquement sauf demande explicite de l’utilisateur.

---

# 4. 🗂️ Modules sources recommandés

## Modules principaux

- modules/erith_ia_religions_mythologies_cultes_anciens_master_fr.md
- modules/erith_ia_cosmogonies_master_fr.md
- modules/erith_ia_histoire_de_l_art_mondiale_master_fr.md
- modules/erith_ia_philosophie_verite_liberte_fr.md
- modules/erith_ia_psychologie_discernement_fr.md

## Modules compatibles selon la demande

- Mahabharata ;
- Ramayana ;
- Tarot symbolique ;
- Astres / astrologie symbolique ;
- Celtes / forêt / seuils / Autre Monde ;
- Double spirale ;
- Asimov / psychohistoire si la demande touche aux cycles de civilisation ;
- Cyber Oracle si la demande veut une mythologie technologique ;
- Math Oracle si la demande exige structure, cycles, proportions, systèmes ou géométrie symbolique.

Garde-fou :

Ne pas charger ces modules automatiquement.

Les modules sources servent de profondeur.

Les cartes mémoire servent de chargement rapide.

---

# 5. 🖼️ Galerie visuelle — Deck Mythologie Vivante

Aucun visuel validé pour l’instant.

Cette section est réservée à une future galerie du deck.

Elle pourra documenter :

- une cover premium du deck ;
- une planche des 10 cartes ;
- un exemple Pack+ ;
- une scène originale produite avec le deck ;
- un dossier visuel de type “Sanctuaire des Seuils”.

## 1. Cover Pack+ Premium

À ajouter plus tard.

Fonction prévue :

Présenter le deck comme un outil de création symbolique : mythes, seuils, oracles, cycles, mémoire sacrée, passage initiatique et libre arbitre.

## 2. Memory Card Pack Cover

À ajouter plus tard.

Fonction prévue :

Présenter rapidement les 10 cartes principales, les tirages recommandés et les commandes utilisables.

## 3. Dossier d’univers / Sanctuaire des Seuils

À ajouter plus tard.

Fonction prévue :

Montrer un exemple de scène originale générée avec le deck : un sanctuaire ancien où un personnage rencontre un oracle, un gardien, une étoile de mémoire ou une forêt vivante.

---

# 6. 🌌 Carte Mémoire — Cosmogonie

## Fonction principale

Naissance du monde, ordre à partir du chaos, séparation des éléments, premier souffle, première lumière.

Cette carte charge :

- l’origine ;
- le chaos primordial ;
- l’eau noire ;
- l’œuf cosmique ;
- le souffle ;
- la première lumière ;
- la séparation ciel / terre ;
- l’arbre du monde ;
- le monde naissant ;
- la mémoire originelle.

## Température émotionnelle

Émerveillement.  
Silence primordial.  
Vertige de commencement.  
Lenteur sacrée.  
Promesse d’un monde encore fragile.

## Textures visuelles

- ténèbres douces ;
- eaux anciennes ;
- lumière naissante ;
- poussière d’étoiles ;
- géométrie sacrée ;
- brume cosmique ;
- arbre immense ;
- cercle primordial ;
- matière en suspension ;
- monde en formation.

## Thèmes actifs

- origine ;
- naissance ;
- ordre et chaos ;
- création ;
- mémoire première ;
- monde intérieur ;
- seuil de manifestation ;
- passage du non-formé vers la forme.

## Question philosophique

Qu’est-ce qui cherche à naître ici ?

## Usage narratif

Utiliser cette carte pour :

- scène de commencement ;
- éveil d’un monde ;
- naissance d’une conscience ;
- mémoire originelle ;
- ouverture de chapitre ;
- révélation d’un principe fondateur ;
- genèse symbolique d’un univers.

## Usage production image

La carte aide à produire :

- paysages cosmogoniques ;
- temples de création ;
- arbres du monde ;
- œufs cosmiques ;
- première lumière ;
- scènes de monde naissant ;
- architectures sacrées de l’origine.

## Garde-fous

Ne pas recopier une cosmogonie précise sans contexte.

Ne pas présenter une création symbolique comme vérité historique ou religieuse.

## Prompt fragment

```text
cosmogonic scene, primordial darkness, first light emerging, cosmic egg, ancient waters, birth of the world, sacred geometry, mythic atmosphere, slow luminous emergence, symbolic creation, cinematic sacred scale
```

## Activation courte

Charge la Carte Mémoire Cosmogonie : origine, chaos primordial, première lumière, monde naissant, souffle créateur, mémoire du commencement.

---

# 7. 🔮 Carte Mémoire — Oracle

## Fonction principale

Voix ambiguë, présage, signe, message indirect, vérité partielle qui demande discernement.

Cette carte charge :

- le présage ;
- la voix cachée ;
- la fumée ;
- le miroir ;
- l’eau réfléchissante ;
- l’inscription ;
- la prophétie ambiguë ;
- le seuil ;
- le destin ouvert ;
- la responsabilité d’interpréter.

## Température émotionnelle

Mystère.  
Silence tendu.  
Attention intérieure.  
Doute fertile.  
Présence invisible.  
Danger de mauvaise interprétation.

## Textures visuelles

- fumée lente ;
- eau noire ;
- miroirs anciens ;
- inscriptions lumineuses ;
- temple discret ;
- rideaux ;
- pierre humide ;
- lumière douce ;
- silhouettes floues ;
- cercle rituel.

## Thèmes actifs

- signe ;
- oracle ;
- prophétie ;
- ambiguïté ;
- discernement ;
- destin non fataliste ;
- vérité partielle ;
- question ouverte ;
- responsabilité du choix.

## Question philosophique

Le signe ouvre-t-il une porte ou enferme-t-il dans une peur ?

## Usage narratif

Utiliser cette carte pour :

- scène de présage ;
- message indirect ;
- avertissement ambigu ;
- rituel de consultation ;
- personnage face à une décision ;
- tension entre foi, peur et discernement ;
- vérité qui ne doit pas être suivie aveuglément.

## Usage production image

La carte aide à produire :

- chambres d’oracle ;
- miroirs prophétiques ;
- bassins sacrés ;
- temples enfumés ;
- inscriptions lumineuses ;
- scènes de révélation ambiguë ;
- portraits de devins non dogmatiques.

## Garde-fous

Ne pas transformer l’oracle en fatalité.

Ne pas présenter une prédiction comme vérité absolue.

Toujours laisser une place au libre arbitre.

## Prompt fragment

```text
ancient oracle chamber, soft smoke, reflective water, symbolic prophecy, hidden voice, glowing inscriptions, ambiguous sign, sacred silence, mysterious but non-fatalistic atmosphere
```

## Activation courte

Charge la Carte Mémoire Oracle : présage, miroir, fumée, signe ambigu, vérité partielle, discernement, destin ouvert.

---

# 8. 🚪 Carte Mémoire — Héros du Seuil

## Fonction principale

Personnage au bord d’un passage, avant l’épreuve, entre ancienne identité et nouvelle responsabilité.

Cette carte charge :

- le seuil ;
- l’initiation ;
- le choix ;
- la peur ;
- le courage ;
- l’épreuve ;
- la transformation ;
- la responsabilité ;
- le passage intérieur.

## Température émotionnelle

Tension calme.  
Courage fragile.  
Peur lucide.  
Attente.  
Responsabilité naissante.  
Moment avant le basculement.

## Textures visuelles

- porte ancienne ;
- pont ;
- colline au crépuscule ;
- vent lent ;
- temple lointain ;
- lumière entre deux mondes ;
- pierre gravée ;
- silhouette seule ;
- chemin qui disparaît.

## Thèmes actifs

- initiation ;
- transformation ;
- choix ;
- passage ;
- responsabilité ;
- fin d’une ancienne identité ;
- naissance d’une posture nouvelle ;
- courage sans arrogance.

## Question philosophique

Que doit-il quitter pour avancer ?

## Usage narratif

Utiliser cette carte pour :

- personnage avant l’épreuve ;
- début d’arc initiatique ;
- choix moral ;
- scène de départ ;
- passage entre enfance et responsabilité ;
- transformation non spectaculaire mais profonde.

## Usage production image

La carte aide à produire :

- héros devant un portail ;
- silhouette au seuil ;
- paysage sacré ;
- temple distant ;
- composition crépusculaire ;
- scène d’initiation calme ;
- moment de choix visuel.

## Garde-fous

Ne pas réduire le héros à la force brute.

Ne pas confondre courage et domination.

Le héros du seuil avance parce qu’il accepte de changer.

## Prompt fragment

```text
hero at the threshold, ancient gate, twilight, symbolic trial, quiet courage, transformation moment, sacred landscape, wind, distant temple, cinematic mythic composition
```

## Activation courte

Charge la Carte Mémoire Héros du Seuil : passage, choix, initiation, peur, courage, transformation, responsabilité.

---

# 9. 🌙 Carte Mémoire — Déesse-Miroir

## Fonction principale

Figure féminine symbolique qui reflète, révèle, protège ou met face à une vérité intérieure.

Cette carte charge :

- le miroir ;
- la lune ;
- l’eau ;
- la protection ;
- la vérité douce ;
- la beauté grave ;
- la mémoire ;
- le regard ;
- le reflet ;
- la révélation indirecte.

## Température émotionnelle

Douceur grave.  
Clarté lunaire.  
Protection silencieuse.  
Révélation intime.  
Beauté calme.  
Mémoire sensible.

## Textures visuelles

- eau argentée ;
- voile léger ;
- miroir ancien ;
- lumière lunaire ;
- cercle d’argent ;
- fleurs nocturnes ;
- peau éclairée par reflet ;
- temple d’eau ;
- brume bleue ;
- silence sacré.

## Thèmes actifs

- reflet ;
- protection ;
- vérité intérieure ;
- mémoire ;
- regard ;
- révélation douce ;
- féminin symbolique ;
- écoute ;
- intuition non dogmatique.

## Question philosophique

Que révèle le reflet que la lumière directe ne montre pas ?

## Usage narratif

Utiliser cette carte pour :

- prêtresse ;
- gardienne ;
- oracle lunaire ;
- présence protectrice ;
- scène de miroir ;
- mémoire vivante ;
- révélation émotionnelle ;
- personnage confronté à sa vérité intérieure.

## Usage production image

La carte aide à produire :

- portraits lunaires ;
- scènes au bord de l’eau ;
- figures protectrices ;
- miroirs sacrés ;
- lumière argentée ;
- scènes de révélation douce ;
- iconographie mythique non religieuse.

## Garde-fous

Ne pas copier une déesse précise sans contexte.

Ne pas transformer la figure féminine en décor passif.

Elle reflète, révèle, protège ou questionne.

## Prompt fragment

```text
lunar mirror goddess, reflective water, silver light, calm feminine presence, sacred veil, ancient symbols, soft revelation, protective aura, dreamlike but grounded, mythic elegance
```

## Activation courte

Charge la Carte Mémoire Déesse-Miroir : lune, eau, reflet, protection, mémoire, vérité douce, révélation intérieure.

---

# 10. ⏳ Carte Mémoire — Dieu du Temps

## Fonction principale

Vieillissement, cycle, retour, dette, mémoire longue, responsabilité devant les conséquences.

Cette carte charge :

- le temps ;
- le cycle ;
- la vieillesse ;
- la mémoire ;
- la dette ;
- la répétition ;
- la rupture ;
- le bilan ;
- les conséquences ;
- la profondeur historique.

## Température émotionnelle

Gravité.  
Ancienneté.  
Poids des conséquences.  
Mélancolie cyclique.  
Silence historique.  
Lucidité tardive.

## Textures visuelles

- horloge cosmique ;
- ruines ;
- anneaux ;
- pierre ancienne ;
- étoiles lentes ;
- sable ;
- couronne vieillie ;
- lumière dorée fatiguée ;
- cercle du temps ;
- bibliothèque ruinée.

## Thèmes actifs

- cycle ;
- vieillissement ;
- mémoire longue ;
- répétition ;
- dette ;
- rupture de cycle ;
- responsabilité ;
- histoire ;
- conséquences des choix.

## Question philosophique

Quel cycle doit être compris avant d’être brisé ?

## Usage narratif

Utiliser cette carte pour :

- scène de retour ;
- fin de règne ;
- civilisation vieillissante ;
- boucle historique ;
- héritage familial ;
- dette morale ;
- choix qui traverse les générations.

## Usage production image

La carte aide à produire :

- dieux anciens du temps ;
- temples en ruine ;
- horloges cosmiques ;
- anneaux temporels ;
- scènes de bilan ;
- figures âgées et majestueuses ;
- symboles cycliques.

## Garde-fous

Ne pas confondre temps, destin et fatalité.

Un cycle peut être compris, transformé ou brisé.

## Prompt fragment

```text
ancient god of time, cosmic clock, stone ruins, slow stars, memory of civilizations, circular symbols, heavy silence, old light, mythic temporal atmosphere
```

## Activation courte

Charge la Carte Mémoire Dieu du Temps : cycle, mémoire longue, dette, conséquence, vieillissement, rupture possible.

---

# 11. 🌲 Carte Mémoire — Forêt Sacrée

## Fonction principale

Lieu vivant, mémoire orale, seuil entre monde humain et Autre Monde, druides, arbres, spirales.

Cette carte charge :

- la forêt ;
- le seuil ;
- les arbres anciens ;
- l’Autre Monde ;
- la spirale ;
- la double spirale ;
- le druide ;
- la mémoire orale ;
- la brume ;
- le gardien.

## Température émotionnelle

Mystère calme.  
Présence ancienne.  
Silence vert.  
Protection sauvage.  
Mémoire vivante.  
Passage invisible.

## Textures visuelles

- arbres très anciens ;
- mousse ;
- brume ;
- lumière verte et argentée ;
- sentier caché ;
- pierres dressées ;
- double spirale gravée ;
- racines ;
- clairière ;
- feuillage humide.

## Thèmes actifs

- seuil naturel ;
- mémoire orale ;
- Autre Monde ;
- forêt gardienne ;
- racines ;
- lignée ;
- spirale ;
- passage ;
- sagesse ancienne ;
- gardiens du savoir.

## Question philosophique

La forêt cache-t-elle une menace ou une mémoire ?

## Usage narratif

Utiliser cette carte pour :

- passage celtique ;
- scène druidique ;
- rencontre avec un gardien ;
- mémoire ancienne ;
- seuil vers un autre monde ;
- révélation naturelle ;
- quête de vérité dans la forêt.

## Usage production image

La carte aide à produire :

- forêts sacrées ;
- portails naturels ;
- pierres à spirales ;
- brume initiatique ;
- druides ;
- arbres monumentaux ;
- clairières de passage ;
- scènes vertes et argentées.

## Garde-fous

Ne pas réduire la culture celtique à un décor fantastique générique.

Respecter l’idée de mémoire orale, de seuil, de nature vivante et de symbolique ancienne.

## Prompt fragment

```text
sacred forest threshold, ancient trees, mist, double spiral symbol, soft green and silver light, hidden path, druidic atmosphere, oral memory, otherworld gate, calm mystery
```

## Activation courte

Charge la Carte Mémoire Forêt Sacrée : arbres anciens, brume, seuil, Autre Monde, double spirale, mémoire orale, gardien.

---

# 12. 🔥 Carte Mémoire — Sacrifice / Offrande

## Fonction principale

Don, perte, échange, renoncement, transformation du désir en responsabilité.

Cette carte charge :

- l’offrande ;
- la perte ;
- le don ;
- l’échange ;
- le prix ;
- la transformation ;
- le rituel ;
- la responsabilité ;
- la limite ;
- le renoncement.

## Température émotionnelle

Gravité.  
Sobriété.  
Douleur contenue.  
Respect.  
Transformation intérieure.  
Silence rituel.

## Textures visuelles

- feu sacré ;
- table de pierre ;
- fleurs ;
- coupe ;
- tissu ancien ;
- lumière chaude ;
- ombre calme ;
- mains ouvertes ;
- cercle rituel ;
- offrande symbolique.

## Thèmes actifs

- don ;
- prix ;
- perte ;
- responsabilité ;
- limite ;
- passage ;
- échange juste ou injuste ;
- désir transformé ;
- renoncement fécond.

## Question philosophique

Qu’est-ce qui est donné, et qu’est-ce qui ne doit jamais être pris ?

## Usage narratif

Utiliser cette carte pour :

- scène de renoncement ;
- don symbolique ;
- choix difficile ;
- prix d’un passage ;
- transformation morale ;
- rituel sans gore ;
- personnage qui abandonne quelque chose pour sauver autre chose.

## Usage production image

La carte aide à produire :

- rituels d’offrande ;
- scènes de feu sacré ;
- compositions de mains ouvertes ;
- temples sobres ;
- objets symboliques déposés ;
- atmosphère grave, non violente.

## Garde-fous

Éviter le gore.

Éviter la glorification de la souffrance.

L’offrande doit rester symbolique, éthique et lisible.

## Prompt fragment

```text
ancient offering scene, symbolic sacrifice, sacred fire, quiet ritual, no gore, emotional gravity, transformation through renunciation, mythic temple, soft dramatic lighting
```

## Activation courte

Charge la Carte Mémoire Sacrifice / Offrande : don, perte, prix, renoncement, transformation, responsabilité, limite.

---

# 13. 🐉 Carte Mémoire — Monstre Gardien

## Fonction principale

Le monstre n’est pas seulement ennemi : il garde un seuil, une peur, un trésor ou une vérité.

Cette carte charge :

- le gardien ;
- le dragon ;
- la chimère ;
- la peur ;
- le trésor ;
- le seuil ;
- l’ombre ;
- l’épreuve ;
- la protection ;
- la vérité cachée.

## Température émotionnelle

Puissance.  
Crainte.  
Respect.  
Mystère.  
Danger noble.  
Épreuve nécessaire.

## Textures visuelles

- silhouette massive ;
- écailles ;
- cornes ;
- brume ;
- ruines ;
- porte antique ;
- œil lumineux ;
- trésor non matériel ;
- pierre sacrée ;
- ombre protectrice.

## Thèmes actifs

- seuil ;
- peur ;
- protection ;
- épreuve ;
- vérité gardée ;
- ombre intérieure ;
- trésor caché ;
- gardien incompris ;
- monstre non maléfique.

## Question philosophique

Que protège le monstre ?

## Usage narratif

Utiliser cette carte pour :

- créature symbolique ;
- épreuve de courage ;
- gardien d’un sanctuaire ;
- peur à comprendre ;
- vérité interdite ;
- seuil dangereux ;
- ennemi qui n’est pas seulement ennemi.

## Usage production image

La carte aide à produire :

- dragons symboliques ;
- chimères ;
- gardiens de ruines ;
- silhouettes puissantes ;
- seuils monumentaux ;
- scènes de confrontation calme ;
- monstres mystérieux et sacrés.

## Garde-fous

Ne pas réduire le monstre à une bête à tuer.

Le monstre peut être protecteur, miroir, seuil ou gardien.

## Prompt fragment

```text
mythic guardian creature, ancient threshold, dragon-like silhouette, protecting a hidden truth, sacred ruins, dramatic mist, symbolic monster, not evil, powerful and mysterious
```

## Activation courte

Charge la Carte Mémoire Monstre Gardien : créature du seuil, peur, trésor caché, protection, épreuve, vérité gardée.

---

# 14. 👑 Carte Mémoire — Chute du Roi

## Fonction principale

Pouvoir usé, orgueil, empire en fin de cycle, souveraineté qui doit être interrogée.

Cette carte charge :

- le roi ;
- le pouvoir ;
- la chute ;
- l’orgueil ;
- la couronne ;
- l’empire ;
- la dette ;
- la justice ;
- la fin de cycle ;
- le trône fragile.

## Température émotionnelle

Tragédie.  
Or fatigué.  
Noblesse brisée.  
Silence politique.  
Fin de règne.  
Lucidité amère.

## Textures visuelles

- palais ancien ;
- couronne brisée ;
- trône lourd ;
- lumière dorée sombre ;
- colonnes fissurées ;
- tapis usé ;
- bannière tombée ;
- salle vide ;
- poussière ;
- ciel d’orage.

## Thèmes actifs

- pouvoir ;
- souveraineté ;
- orgueil ;
- chute ;
- dette morale ;
- justice ;
- empire en déclin ;
- responsabilité politique ;
- fin de cycle.

## Question philosophique

Le pouvoir protège-t-il encore, ou se protège-t-il lui-même ?

## Usage narratif

Utiliser cette carte pour :

- scène de fin de règne ;
- empire en déclin ;
- souverain face à la vérité ;
- palais vide ;
- dette historique ;
- chute morale ;
- justice symbolique.

## Usage production image

La carte aide à produire :

- rois déchus ;
- couronnes brisées ;
- salles du trône ;
- palais sombres ;
- scènes tragiques ;
- empire en ruine ;
- pouvoir confronté au temps.

## Garde-fous

Ne pas réduire la chute à une punition simpliste.

La chute peut être tragique, nécessaire, injuste ou révélatrice selon le récit.

## Prompt fragment

```text
fallen king in ancient palace, broken crown, dim golden light, mythic tragedy, empire in decline, symbolic justice, heavy throne room, cinematic composition
```

## Activation courte

Charge la Carte Mémoire Chute du Roi : pouvoir usé, couronne brisée, empire en fin de cycle, dette, justice, vérité du trône.

---

# 15. ✨ Carte Mémoire — Étoile de Mémoire

## Fonction principale

Mémoire céleste, constellation, ancêtres, carte du ciel, destin non fataliste.

Cette carte charge :

- l’étoile ;
- la constellation ;
- les ancêtres ;
- la mémoire ;
- le ciel ;
- la navigation ;
- la carte ;
- le cycle ;
- l’orientation ;
- la lumière lointaine.

## Température émotionnelle

Sérénité.  
Orientation douce.  
Nostalgie cosmique.  
Présence des anciens.  
Calme nocturne.  
Espérance discrète.

## Textures visuelles

- ciel étoilé ;
- fils lumineux ;
- carte céleste ;
- constellation ;
- silhouettes d’ancêtres ;
- voile bleu nuit ;
- lumière blanche ;
- cercle astronomique ;
- parchemin céleste ;
- boussole ancienne.

## Thèmes actifs

- mémoire ;
- ancêtres ;
- orientation ;
- ciel archive ;
- navigation ;
- destin ouvert ;
- cycle ;
- transmission ;
- filiation symbolique.

## Question philosophique

Quelle étoile aide à s’orienter sans imposer le chemin ?

## Usage narratif

Utiliser cette carte pour :

- scène nocturne ;
- guidance non fataliste ;
- mémoire des ancêtres ;
- carte du ciel ;
- boussole intérieure ;
- navigation symbolique ;
- moment de calme après l’épreuve.

## Usage production image

La carte aide à produire :

- constellations mémorielles ;
- cartes célestes ;
- temples astronomiques ;
- fils de lumière ;
- ciel archive ;
- scènes d’orientation ;
- portraits sous étoiles.

## Garde-fous

Ne pas transformer le ciel en fatalité.

L’étoile oriente, elle n’impose pas.

## Prompt fragment

```text
memory constellation, night sky as archive, ancient star map, luminous threads, ancestors as lights, symbolic navigation, cosmic memory, serene mythic atmosphere
```

## Activation courte

Charge la Carte Mémoire Étoile de Mémoire : constellation, ancêtres, carte du ciel, mémoire, orientation, destin non fataliste.

---

# 16. 🃏 Deck Mémoire — Mythologie Vivante

## Composition

Ce deck contient dix cartes principales :

- Cosmogonie ;
- Oracle ;
- Héros du Seuil ;
- Déesse-Miroir ;
- Dieu du Temps ;
- Forêt Sacrée ;
- Sacrifice / Offrande ;
- Monstre Gardien ;
- Chute du Roi ;
- Étoile de Mémoire.

## Fonction du deck

Créer des scènes originales à partir de mythes, symboles, seuils, cycles et passages initiatiques.

Cosmogonie donne :

- l’origine ;
- la naissance ;
- le monde en formation ;
- le premier souffle.

Oracle donne :

- le signe ;
- l’ambiguïté ;
- le discernement ;
- le destin ouvert.

Héros du Seuil donne :

- le passage ;
- l’initiation ;
- le courage ;
- la transformation.

Déesse-Miroir donne :

- le reflet ;
- la protection ;
- la vérité douce ;
- la mémoire sensible.

Dieu du Temps donne :

- le cycle ;
- la conséquence ;
- la dette ;
- la rupture possible.

Forêt Sacrée donne :

- le seuil naturel ;
- la mémoire orale ;
- la spirale ;
- l’Autre Monde.

Sacrifice / Offrande donne :

- le don ;
- la perte ;
- le prix ;
- la responsabilité.

Monstre Gardien donne :

- l’épreuve ;
- la peur ;
- le trésor ;
- la vérité protégée.

Chute du Roi donne :

- le pouvoir ;
- l’orgueil ;
- la fin de cycle ;
- la justice.

Étoile de Mémoire donne :

- l’orientation ;
- la constellation ;
- les ancêtres ;
- la mémoire céleste.

## Résultat attendu

Un deck symbolique clair, profond et non dogmatique.

Il doit permettre de créer des scènes mythiques originales, sans copier les traditions.

Il doit aider à construire :

- des personnages ;
- des seuils ;
- des rituels sobres ;
- des paysages sacrés ;
- des conflits intérieurs ;
- des visions ;
- des images fortes ;
- des arcs narratifs ;
- des prompts image ;
- des animations lentes ;
- des narrations courtes.

## Thèmes combinés

- origine ;
- seuil ;
- choix ;
- oracle ;
- mémoire ;
- cycle ;
- offrande ;
- gardien ;
- pouvoir ;
- constellation ;
- libre arbitre ;
- passage intérieur ;
- transformation ;
- vérité symbolique.

## Question centrale du deck

Comment transformer un symbole ancien en scène vivante sans copier, sans dogme et sans fatalisme ?

## Formule canonique du deck

Mythe + Symbole + Passage.  
Oracle + Seuil + Mémoire.  
Libre arbitre + Image forte + Discernement.

---

# 17. 🏛️ Univers original générable avec le deck

## Nom de travail

Le Sanctuaire des Seuils

Le Sanctuaire des Seuils est un nom de travail original pour tester le Deck Mythologie Vivante.

Il ne doit pas devenir une contrainte obligatoire : l’agent peut créer d’autres lieux, mythes, personnages ou sociétés si la demande l’exige.

## Concept

Le Sanctuaire des Seuils est un ancien lieu situé entre forêt, ruines, ciel étoilé et bassin d’oracle.

Chaque porte du sanctuaire correspond à une carte mémoire.

On n’y reçoit pas une vérité toute faite.

On y rencontre un symbole.

Le visiteur doit comprendre ce que le symbole lui demande, sans se soumettre aveuglément à lui.

## Société / monde

Autour du sanctuaire vivent des gardiens, des conteurs, des astronomes, des marcheurs de forêt et des artisans de mémoire.

Ils ne vénèrent pas les cartes.

Ils les utilisent comme langage.

Une carte n’est pas un ordre.

Une carte est une porte.

Un tirage n’est pas une fatalité.

Un tirage est une configuration de forces.

## Tension dramatique

Un personnage arrive au sanctuaire après la chute d’un royaume.

L’oracle lui montre trois signes :

- un monstre qui protège une porte ;
- une étoile qui refuse de donner un chemin fixe ;
- une offrande qu’il ne comprend pas encore.

Le personnage croit devoir vaincre le monstre.

Mais le vrai passage consiste à comprendre ce que le monstre garde.

## Ton

Mythique.  
Clair.  
Poétique.  
Non dogmatique.  
Initiatique.  
Respectueux des cultures sources.  
Compatible image, animation, narration et storyboard.

---

# 18. 🔀 Tirages recommandés

## Tirage 1 — Naissance d’un monde

Cartes :

- Cosmogonie ;
- Étoile de Mémoire ;
- Forêt Sacrée.

Usage :

Créer une origine de monde, une mythologie naturelle, une mémoire ancienne liée aux astres et aux arbres.

Formule :

Le monde naît, les étoiles se souviennent, la forêt garde le passage.

---

## Tirage 2 — Passage initiatique

Cartes :

- Héros du Seuil ;
- Monstre Gardien ;
- Oracle.

Usage :

Créer un arc de personnage avec épreuve, signe ambigu et gardien symbolique.

Formule :

Le héros ne combat pas seulement un monstre.  
Il apprend ce que le monstre garde.

---

## Tirage 3 — Chute d’un empire

Cartes :

- Dieu du Temps ;
- Chute du Roi ;
- Sacrifice / Offrande.

Usage :

Créer une scène de fin de règne, cycle historique, dette morale ou empire en déclin.

Formule :

Le temps réclame ce que le pouvoir a refusé de voir.

---

## Tirage 4 — Vision lunaire

Cartes :

- Déesse-Miroir ;
- Oracle ;
- Étoile de Mémoire.

Usage :

Créer une scène douce, nocturne, symbolique, proche d’une lecture lunaire, mais sans fatalisme.

Formule :

La nuit ne prédit pas.  
Elle reflète ce qui demande à être compris.

---

## Tirage 5 — Mythe technologique

Cartes :

- Cosmogonie ;
- Oracle ;
- Dieu du Temps.

Usage :

Créer une IA ancienne, une machine prophétique, un système de mémoire ou un Cyber Oracle.

Formule :

Quand la machine devient temple, la donnée devient présage.

---

# 19. 📝 Mini prompts d’ambiance

## Prompt ambiance courte

```text
Mythic symbolic scene, ancient threshold, sacred forest, oracle smoke, memory constellation, reflective water, quiet hero before transformation, non-dogmatic spiritual atmosphere, cinematic mythological composition, original worldbuilding, respectful cultural inspiration, no copied deity, no religious propaganda, no fatalism.
```

## Prompt image — Sanctuaire des Seuils

```text
The Sanctuary of Thresholds, original mythological memory card universe, ancient sacred forest, reflective oracle pool, stone gates covered with spiral symbols, night sky filled with memory constellations, quiet hero standing before a guardian creature, soft silver and golden light, sacred but non-dogmatic atmosphere, cinematic mythic composition, symbolic storytelling, clear visual sections, original worldbuilding, no copied deity, no recognizable mythological scene.
```

## Prompt image portrait

```text
Cinematic portrait of an original threshold hero, standing between ancient forest and starry temple, face lit by silver moonlight and soft golden fire, calm courage, symbolic cloak, subtle spiral ornament, reflective water behind, oracle smoke, memory constellation above, mythic but grounded, original character, no copied deity, no copyrighted character.
```

## Prompt décor

```text
Ancient mythological sanctuary hidden in a sacred forest, stone gates, spiral carvings, reflective oracle water, slow mist, constellation map in the sky, quiet offering altar, guardian creature silhouette near the threshold, symbolic atmosphere, cinematic wide shot, sacred but respectful, original worldbuilding.
```

## Prompt animation Wan / I2V

```text
Subtle cinematic animation. Mist moves slowly through the sacred forest. Oracle smoke rises gently above reflective water. Stars pulse faintly in the night sky like a memory constellation. The hero remains almost still before the threshold, breathing softly. The guardian creature watches without attacking. Camera nearly locked, slow atmospheric drift only, preserve composition, preserve face, preserve symbolic clarity.
```

---

# 20. 🚫 Négatif production

Éviter :

- copie directe d’un mythe précis ;
- divinité reconnaissable copiée ;
- scène sacrée reproduite sans contexte ;
- mélange culturel incohérent ;
- religieux forcé ;
- posture de gourou ;
- fatalisme ;
- prophétie présentée comme vérité absolue ;
- gore rituel ;
- sacrifice violent explicite ;
- cliché fantasy générique ;
- surcharge de symboles ;
- chaos visuel ;
- texte illisible ;
- mains abîmées ;
- corps déformés ;
- visage instable ;
- décor pseudo-sacré sans sens ;
- esthétique de jeu vidéo générique sans profondeur.

Negative prompt court :

```text
low quality, blurry, bad anatomy, extra limbs, distorted face, broken hands, unreadable text, copied deity, copied mythology scene, religious propaganda, fatalism, gore ritual, generic fantasy clutter, chaotic composition, disrespectful cultural mashup, flat lighting, poor cinematic framing
```

---

# 21. 🧬 Formules de combinaison

## Cosmogonie seule

Origine + chaos + première lumière + monde naissant.

## Oracle seul

Signe + ambiguïté + discernement + destin ouvert.

## Héros du Seuil seul

Passage + peur + courage + transformation.

## Déesse-Miroir seule

Reflet + protection + vérité douce + mémoire.

## Dieu du Temps seul

Cycle + conséquence + dette + rupture possible.

## Forêt Sacrée seule

Arbres + brume + seuil + mémoire orale + Autre Monde.

## Sacrifice / Offrande seule

Don + perte + prix + responsabilité.

## Monstre Gardien seul

Peur + seuil + trésor + vérité protégée.

## Chute du Roi seule

Pouvoir + orgueil + dette + fin de cycle.

## Étoile de Mémoire seule

Constellation + ancêtres + orientation + destin non fataliste.

## Oracle + Héros du Seuil

Le signe appelle, mais le héros doit choisir.

## Forêt Sacrée + Étoile de Mémoire

Les arbres gardent la mémoire de ce que le ciel indique.

## Monstre Gardien + Sacrifice / Offrande

Le passage exige un renoncement, pas une victoire brutale.

## Dieu du Temps + Chute du Roi

Le cycle révèle ce que le pouvoir a refusé de comprendre.

## Déesse-Miroir + Oracle

Le reflet ne donne pas une réponse.  
Il rend la question impossible à fuir.

## Trio complet initiatique

Héros du Seuil + Monstre Gardien + Oracle.

Formule :

Passage + Épreuve + Signe.  
Courage + Peur + Discernement.  
La porte s’ouvre quand le sens est compris.

---

# 22. 🕹️ Commandes utilisables

## Charger une carte

Charge la Carte Mémoire Cosmogonie.

Charge la Carte Mémoire Oracle.

Charge la Carte Mémoire Héros du Seuil.

Charge la Carte Mémoire Déesse-Miroir.

Charge la Carte Mémoire Dieu du Temps.

Charge la Carte Mémoire Forêt Sacrée.

Charge la Carte Mémoire Sacrifice / Offrande.

Charge la Carte Mémoire Monstre Gardien.

Charge la Carte Mémoire Chute du Roi.

Charge la Carte Mémoire Étoile de Mémoire.

## Charger deux cartes

Charge Oracle + Héros du Seuil pour une scène de décision.

Charge Forêt Sacrée + Étoile de Mémoire pour une scène celtique et céleste.

Charge Monstre Gardien + Sacrifice / Offrande pour une épreuve symbolique.

Charge Dieu du Temps + Chute du Roi pour une scène de fin d’empire.

## Charger un tirage

Charge le Tirage Passage initiatique.

Charge le Tirage Naissance d’un monde.

Charge le Tirage Chute d’un empire.

Charge le Tirage Vision lunaire.

Charge le Tirage Mythe technologique.

## Charger le deck complet

Charge le Deck Mémoire Mythologie Vivante.

Crée une scène originale avec :

- symbole central ;
- seuil ;
- choix ;
- mémoire ;
- oracle ;
- transformation ;
- libre arbitre ;
- aucun dogme ;
- aucune copie directe ;
- respect des traditions sources.

## Production Pack+

Charge le Deck Mythologie Vivante et génère un Pack+ complet avec :

- concept de scène ;
- personnage original ;
- symbole central ;
- décor ;
- tension intérieure ;
- prompt image ;
- prompt animation ;
- négatif ;
- voix off courte ;
- garde-fous symboliques.

## Production Sanctuaire des Seuils

Charge le Deck Mythologie Vivante et génère un Pack+ Sanctuaire des Seuils avec :

- sanctuaire ancien ;
- forêt sacrée ;
- oracle d’eau ;
- monstre gardien ;
- étoile de mémoire ;
- héros du seuil ;
- passage initiatique ;
- prompt image dossier ;
- prompt animation Wan / I2V sobre ;
- garde-fou non dogmatique strict.

---

# 23. 🛡️ Garde-fou final

Ces cartes ne sont pas des copies.

Elles sont des filtres.

Une carte charge une force.  
Un tirage compose une tension.  
Le deck crée une scène vivante.

Règle finale :

La Cosmogonie inspire l’origine.  
L’Oracle inspire le signe.  
Le Héros du Seuil inspire le passage.  
La Déesse-Miroir inspire le reflet.  
Le Dieu du Temps inspire le cycle.  
La Forêt Sacrée inspire la mémoire naturelle.  
L’Offrande inspire la responsabilité.  
Le Monstre Gardien inspire l’épreuve.  
La Chute du Roi inspire la vérité du pouvoir.  
L’Étoile de Mémoire inspire l’orientation.

Mais la scène générée doit rester originale.

Le symbole ouvre une porte.  
Il ne doit jamais devenir une prison.

Le libre arbitre reste central.  
La création reste consciente.  
La carte mémoire reste une influence contrôlée.

---

# 24. 🧠 Résumé LLM inclus

## Fonction du module

Ce fichier crée un système de Cartes Mémoire mythologiques permettant de charger rapidement des symboles, des archétypes, des seuils et des scènes initiatiques sans relire les modules complets.

Il contient dix cartes principales :

- Cosmogonie ;
- Oracle ;
- Héros du Seuil ;
- Déesse-Miroir ;
- Dieu du Temps ;
- Forêt Sacrée ;
- Sacrifice / Offrande ;
- Monstre Gardien ;
- Chute du Roi ;
- Étoile de Mémoire.

Il contient aussi cinq tirages recommandés :

- Naissance d’un monde ;
- Passage initiatique ;
- Chute d’un empire ;
- Vision lunaire ;
- Mythe technologique.

Il contient enfin un exemple d’univers générable :

- Le Sanctuaire des Seuils.

## Règle d’usage

Ne pas copier les mythes.

Ne pas reprendre sans contexte :

- divinités précises ;
- scènes sacrées ;
- rites réels ;
- textes sacrés ;
- traditions vivantes ;
- symboles culturels sensibles.

Utiliser uniquement :

- structure symbolique ;
- ambiance ;
- tension narrative ;
- question philosophique ;
- direction artistique générale ;
- archétype transformé ;
- usage créatif respectueux.

## Résumé des cartes

Cosmogonie = origine, chaos primordial, première lumière, naissance du monde.

Oracle = présage, signe ambigu, discernement, destin ouvert.

Héros du Seuil = passage, choix, courage, transformation.

Déesse-Miroir = reflet, protection, mémoire, vérité douce.

Dieu du Temps = cycle, conséquence, dette, rupture possible.

Forêt Sacrée = arbres anciens, brume, Autre Monde, double spirale, mémoire orale.

Sacrifice / Offrande = don, perte, prix, responsabilité, renoncement.

Monstre Gardien = seuil, peur, trésor, vérité protégée.

Chute du Roi = pouvoir, orgueil, empire en fin de cycle, justice.

Étoile de Mémoire = constellation, ancêtres, orientation, destin non fataliste.

## Résumé du deck

Le Deck Mythologie Vivante combine :

- origine ;
- seuil ;
- oracle ;
- mémoire ;
- épreuve ;
- cycle ;
- offrande ;
- pouvoir ;
- constellation ;
- libre arbitre.

Il sert à créer des scènes originales où les symboles anciens deviennent des outils narratifs, visuels et philosophiques.

## Résumé Sanctuaire des Seuils

Le Sanctuaire des Seuils est un lieu original où chaque porte correspond à une carte mémoire.

Le visiteur ne reçoit pas une vérité imposée.

Il rencontre un symbole.

Il doit comprendre ce que le symbole lui demande, sans s’y soumettre aveuglément.

Tension centrale : un personnage croit devoir vaincre un monstre gardien, mais découvre que le vrai passage consiste à comprendre ce que le monstre protège.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge le Deck Mythologie Vivante.”

Alors activer :

- mythologie ;
- symboles ;
- seuils ;
- oracles ;
- cycles ;
- mémoire sacrée ;
- héros initiatique ;
- gardiens ;
- offrande ;
- constellation ;
- libre arbitre ;
- respect des traditions ;
- création originale ;
- garde-fou anti-dogme ;
- garde-fou anti-fatalisme.

Répondre en mode Mythologie Vivante.

Ne pas injecter de lore privé si le mode Hors-Lore est demandé.

Ne pas copier les mythes sources.

## Activation LLM complète

Tu es en mode Cartes Mémoire Mythologie Vivante.

Utilise les cartes comme influences compactes :

Cosmogonie pour l’origine, le chaos primordial, la première lumière et la naissance d’un monde.

Oracle pour le signe ambigu, le présage, le discernement et le destin ouvert.

Héros du Seuil pour le passage, l’initiation, le courage et la transformation.

Déesse-Miroir pour le reflet, la protection, la mémoire et la vérité douce.

Dieu du Temps pour les cycles, les conséquences, la dette et la rupture possible.

Forêt Sacrée pour les arbres anciens, l’Autre Monde, la double spirale, la mémoire orale et les gardiens naturels.

Sacrifice / Offrande pour le don, la perte, le prix, le renoncement et la responsabilité.

Monstre Gardien pour l’épreuve, la peur, le seuil, le trésor et la vérité protégée.

Chute du Roi pour le pouvoir usé, l’orgueil, la dette morale, la justice et la fin de cycle.

Étoile de Mémoire pour la constellation, les ancêtres, l’orientation et le destin non fataliste.

Règle centrale :

Ne charge pas toutes les cartes en même temps.

Choisis uniquement la ou les cartes utiles à la demande.

Modes de combinaison :

- 1 carte = influence simple ;
- 2 cartes = tension symbolique ;
- 3 cartes = mini-configuration narrative ;
- 5 cartes = arc complet ou storyboard ;
- 10 cartes = architecture mythologique complète.

Garde-fou :

Les mythes ne sont pas des ordres.  
Les symboles ne sont pas des preuves.  
Les traditions doivent être respectées.  
Le libre arbitre reste humain.

Sépare toujours :

- fait historique ;
- tradition ;
- symbole ;
- hypothèse ;
- interprétation ;
- usage créatif.

Style attendu :

- clair ;
- profond ;
- poétique ;
- discernant ;
- Notion compatible ;
- utilisable en production image / vidéo / narration.

Phrase de verrou :

Mythologie Vivante transforme les symboles anciens en scènes utiles, sans dogme, sans copie et sans fatalisme.

---

# 25. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTES MÉMOIRE — MYTHOLOGIE VIVANTE

Tu es autorisé à utiliser le jeu “Cartes Mémoire — Mythologie Vivante” comme deck de création symbolique pour @erith IA / ERITH.IA.

Objectif :
Créer des scènes, prompts, personnages, storyboards, symboles, arches narratives et tableaux mythiques à partir d’un jeu de cartes mémoire.

Règle centrale :
Ne charge pas toutes les cartes en même temps.
Choisis uniquement la ou les cartes utiles à la demande.

Cartes disponibles :
1. Cosmogonie
2. Oracle
3. Héros du Seuil
4. Déesse-Miroir
5. Dieu du Temps
6. Forêt Sacrée
7. Sacrifice / Offrande
8. Monstre Gardien
9. Chute du Roi
10. Étoile de Mémoire

Modes de combinaison :
- 1 carte = influence simple
- 2 cartes = tension symbolique
- 3 cartes = mini-configuration narrative
- 5 cartes = arc complet ou storyboard
- 10 cartes = architecture mythologique complète

Tirages recommandés :
1. Naissance d’un monde = Cosmogonie + Étoile de Mémoire + Forêt Sacrée
2. Passage initiatique = Héros du Seuil + Monstre Gardien + Oracle
3. Chute d’un empire = Dieu du Temps + Chute du Roi + Sacrifice / Offrande
4. Vision lunaire = Déesse-Miroir + Oracle + Étoile de Mémoire
5. Mythe technologique = Cosmogonie + Oracle + Dieu du Temps

Garde-fou :
Les mythes ne sont pas des ordres.
Les symboles ne sont pas des preuves.
Les traditions doivent être respectées.
Le libre arbitre reste humain.
Le fatalisme est interdit.
Le dogme est interdit.
La copie directe est interdite.

Sépare toujours :
fait historique ;
tradition ;
symbole ;
hypothèse ;
interprétation ;
usage créatif.

Style attendu :
clair ;
profond ;
poétique ;
discernant ;
Notion compatible ;
utilisable en production image / vidéo / narration.

Phrase de verrou :
Mythologie Vivante transforme les symboles anciens en scènes utiles, sans dogme, sans copie et sans fatalisme.
```

---

# 26. 🔑 Prompt d’activation court

```text
Charge le jeu Cartes Mémoire — Mythologie Vivante.

Choisis seulement les cartes utiles à ma demande.

Utilise les cartes comme influences symboliques pour créer une scène, un prompt, un storyboard, un personnage, une image ou une structure narrative.

Ne copie pas les mythes.
Respecte les traditions.
Sépare fait, tradition, symbole, hypothèse et création.

Libre arbitre toujours.
Fatalisme jamais.
```

---

# 27. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_cards_mythologie_vivante_fr.md

Commit recommandé :

Wrap Mythologie Vivante mini prompts in code blocks
