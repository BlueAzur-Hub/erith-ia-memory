# ERITH.IA — Œuvre fondatrice — Épopée de Soundiata

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Afrique de l’Ouest / Mandé / empire du Mali  
Œuvre : Épopée de Soundiata  
Fonction : apporter à ERITH.IA une base héroïque, politique, orale et initiatique autour de Soundiata Keïta, de la fondation de l’empire du Mali, de la parole des griots, de la souveraineté et du destin.

L’Épopée de Soundiata transmet une mémoire fondatrice du monde mandingue. Elle relie naissance difficile, faiblesse apparente, accomplissement du destin, parole des griots, exil, retour, guerre, fondation politique et justice royale.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire épique ouest-africaine ;
- une compréhension de la parole orale comme archive vivante ;
- une lecture de la royauté comme responsabilité, réparation et fondation ;
- une esthétique de savane, kora, forge, poussière, soleil, arbre à palabres et assemblée ;
- une matière narrative liée au destin, à l’exil, au retour et à la souveraineté.

## Figures et motifs majeurs

- Soundiata Keïta : héros fondateur, enfant fragile, exilé, roi restaurateur.
- Sogolon : mère, marginalité, protection, lignée.
- Soumaoro Kanté : roi-sorcier, pouvoir oppressif, adversaire mythique.
- Balla Fasséké : griot, mémoire, parole, transmission.
- Les griots : gardiens de l’histoire, de la généalogie, de la parole et de la mémoire.
- L’exil : formation, maturation, distance nécessaire.
- Le retour : accomplissement du destin.
- La bataille de Kirina : bascule politique et symbolique.
- La Charte du Mandé : horizon de justice, ordre social, mémoire politique.

## Thèmes profonds

Parole orale et mémoire vivante  
Destin annoncé et accomplissement  
Faiblesse apparente devenue puissance  
Exil, apprentissage et retour  
Souveraineté juste  
Fondation d’un empire  
Griots comme archives humaines  
Justice, réparation et ordre du monde

## Garde-fous

Ne pas réduire l’Épopée de Soundiata à une simple histoire de conquête.

Ne pas exotiser l’Afrique de l’Ouest.

Ne pas effacer le rôle central de l’oralité et des griots.

Ne pas présenter une version unique comme définitive : l’épopée existe par traditions orales, variantes, transmissions et performances.

Séparer :

- tradition orale mandingue ;
- versions transcrites ;
- histoire de l’empire du Mali ;
- interprétation symbolique ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : poussière dorée, cuir, bois, métal forgé, corde, tissu indigo, terre rouge, calebasse.  
Lumière : soleil bas, feu de veillée, ombre d’un baobab, lumière chaude de savane.  
Architecture : cour royale, place d’assemblée, arbre à palabres, forge, horizon de savane.  
Ambiance : orale, royale, fondatrice, grave, solaire, communautaire.

## Prompt image — base

Une scène épique ouest-africaine ancienne inspirée de l’Épopée de Soundiata, griot jouant de la kora sous un grand baobab, jeune roi fondateur au centre d’une assemblée, savane dorée, poussière lumineuse, tissus indigo, forge lointaine, atmosphère de mémoire orale et de souveraineté, peinture cinématographique noble, sans texte, sans cliché exotisant.

## Prompt animation — base

Caméra lente autour d’un griot sous un baobab, cordes de kora vibrant doucement, poussière dorée dans la lumière du soir, assemblée silencieuse, étoffes bougeant au vent, atmosphère de parole fondatrice, rythme lent, continuité stable.

## Prompt négatif

cliché colonial, exotisme décoratif, fantasy générique, armure européenne, logo, texte, cartoon, sursexualisation, violence gratuite, décor africain générique sans respect culturel, anachronisme moderne.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter l’Épopée de Soundiata comme une source orale mandingue fondatrice, liée aux griots, à la souveraineté, à l’exil, au retour, à la justice et à la fondation de l’empire du Mali. Le module doit produire des scènes respectueuses, solaires, graves et communautaires, sans exotisation ni réduction à une simple conquête.

## Formule courte

Épopée de Soundiata = griot + parole vivante + exil + retour + souveraineté fondatrice.
