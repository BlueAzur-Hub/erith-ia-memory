# ERITH.IA — Œuvre fondatrice — Mabinogion

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Pays de Galles médiéval / monde brittonique / tradition celtique  
Fonction : apporter à ERITH.IA une base poétique, merveilleuse et souveraine issue des récits gallois regroupés sous le nom de Mabinogion.

Le Mabinogion rassemble des récits où se croisent souveraineté, métamorphose, magie, amour, honneur, animaux symboliques, Autre Monde, lignées royales et épreuves initiatiques.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire celtique galloise ;
- une esthétique de forêt, brume, château, seuil, lac, animal sacré et Autre Monde ;
- une logique narrative plus merveilleuse que strictement guerrière ;
- des thèmes de souveraineté, d’alliance, de transformation et de réparation ;
- une lecture symbolique des animaux, des noms, des dons et des malédictions ;
- une matière utile pour récits initiatiques, modules féeriques, seuils et royaumes cachés.

## Figures et motifs majeurs

- Pwyll : souveraineté, échange de places, lien avec l’Autre Monde.
- Rhiannon : reine, cheval blanc, injustice, endurance, dignité.
- Bran le Béni : roi géant, sacrifice, tête prophétique, mémoire.
- Branwen : alliance brisée, guerre, douleur, médiation impossible.
- Math : magie, souveraineté, règles sacrées.
- Gwydion : ruse, magie, transformation.
- Blodeuwedd : femme-fleur, création magique, trahison, métamorphose.
- Pryderi : filiation, perte, retour, passage.
- L’Autre Monde : seuil, inversion, royaume invisible, promesse et danger.

## Thèmes profonds

Souveraineté et justice  
Métamorphose et identité  
Autre Monde et seuils  
Animaux symboliques  
Femme-fleur et création magique  
Parole, nom et destin  
Alliance entre royaumes  
Sacrifice royal et mémoire  
Réparation après rupture

## Garde-fous

Ne pas réduire le Mabinogion à de la fantasy féerique douce.

Ne pas confondre traditions galloises, irlandaises et fantasy moderne.

Ne pas lisser les récits : ils contiennent aussi violence, injustice, perte, guerre et tragédie.

Séparer :

- textes médiévaux gallois ;
- traditions brittoniques ;
- cycles arthuriens associés ;
- interprétations modernes ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : brume, mousse, pierre humide, bois ancien, fleurs pâles, eau sombre, tissus royaux, or faible.  
Lumière : matin gris, clairière enchantée, lune, feu discret, lumière blanche d’un seuil.  
Architecture : châteaux gallois anciens, salles de pierre, forêts, lacs, collines, portes cachées.  
Ambiance : merveilleuse, grave, royale, initiatique, brumeuse, mélancolique.

## Prompt image — base

Une scène galloise ancienne inspirée du Mabinogion, reine mystérieuse sur un cheval blanc traversant une clairière brumeuse, pierres anciennes, forêt humide, château lointain, lumière pâle, atmosphère merveilleuse et mélancolique, peinture épique poétique, détails celtiques discrets, sans franchise moderne, sans texte.

## Prompt animation — base

Caméra lente dans une clairière galloise brumeuse, cheval blanc avançant doucement au loin, feuilles humides, lumière lunaire pâle, pierres anciennes couvertes de mousse, sensation de seuil vers l’Autre Monde, mouvement minimal, rythme contemplatif, continuité stable.

## Prompt négatif

fantasy moderne générique, fée cartoon, château Disney, logo, texte, personnage identifiable, armure brillante, sursexualisation, couleurs trop saturées, anachronisme, magie explosive.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter le Mabinogion comme une source celtique galloise de souveraineté, de métamorphose, d’Autre Monde, de justice, de lignées et de merveilleux grave. Le module doit aider à créer des scènes de seuil, de forêt, de royaume caché, de cheval blanc, de femme-fleur, de roi sacrifié et de mémoire poétique, sans réduire la matière à une fantasy générique.

## Formule courte

Mabinogion = souveraineté galloise + Autre Monde + métamorphose + merveilleux grave.
