# 🦅 ERITH.IA — Germains & Monde germanique ancien

Statut : module mémoire civilisationnel  
Projet : @erith IA / ERITH.IA  
Type : Germains anciens, monde germanique, Rome, migrations, Goths, Francs, Saxons, Vandales, Burgondes, Lombards, Futhark, Tacite, royaumes post-romains  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension structurée du monde germanique ancien.

Il sert de pont entre :

- Rome ;
- Celtes ;
- Vikings ;
- christianisation de l’Europe ;
- royaumes médiévaux ;
- naissance de plusieurs identités européennes.

Il active :

- peuples germaniques ;
- frontières romaines ;
- Rhin ;
- Danube ;
- forêts ;
- migrations ;
- guerre ;
- droit coutumier ;
- assemblées ;
- lignées ;
- honneur ;
- Futhark ;
- christianisation ;
- royaumes barbares ;
- transformation de l’Empire romain d’Occident.

Formule centrale :

Le monde germanique ancien est une zone de passage entre Rome, les forêts du Nord, les migrations et l’Europe médiévale.

---

# 🛡️ 2. Garde-fou historique

Le mot “Germains” ne désigne pas un peuple unique.

Il regroupe des ensembles mouvants :

- tribus ;
- confédérations ;
- peuples ;
- langues ;
- alliances ;
- identités construites ou reconstruites par les sources romaines.

Toujours distinguer :

- sources romaines ;
- archéologie ;
- linguistique ;
- traditions médiévales ;
- reconstructions modernes ;
- usages créatifs ERITH.IA.

Règle :

Tacite, César et les auteurs romains sont précieux, mais ils regardent les Germains depuis Rome.

---

# 🌍 3. Carte générale du monde germanique

Espaces importants :

- Germanie au nord et à l’est du Rhin ;
- régions du Danube ;
- Scandinavie méridionale ;
- Baltique ;
- Europe centrale ;
- plaines et forêts d’Europe du Nord ;
- zones de contact avec Rome ;
- zones de contact avec Celtes, Slaves et peuples des steppes.

Le monde germanique ancien n’est pas un empire centralisé.

Il est une constellation de groupes, de chefferies, de confédérations et de royaumes en formation.

---

# 🏛️ 4. Rome et la Germanie

Rome rencontre les Germains comme :

- ennemis ;
- alliés ;
- mercenaires ;
- fédérés ;
- voisins ;
- commerçants ;
- migrants ;
- futurs dirigeants de royaumes post-romains.

Repères :

- César et les peuples au-delà du Rhin ;
- frontière rhénane ;
- frontière danubienne ;
- bataille de Teutobourg ;
- limes germanique ;
- fédérés ;
- intégration militaire ;
- pressions migratoires ;
- transformation de l’Empire d’Occident.

Phrase clé :

Rome n’a pas seulement combattu les Germains : elle les a aussi recrutés, intégrés et transformés.

---

# 🐺 5. Peuples et confédérations

## Goths

Axes :

- Wisigoths ;
- Ostrogoths ;
- migrations ;
- contacts avec Rome ;
- royaumes post-romains ;
- christianisation arienne ;
- rôle majeur dans la fin de l’Empire d’Occident.

## Francs

Axes :

- confédération germanique ;
- Rhin ;
- Gaule ;
- Clovis ;
- royaume franc ;
- christianisation nicéenne ;
- origine lointaine du nom France.

## Saxons

Axes :

- Europe du Nord ;
- Angleterre anglo-saxonne ;
- conflits avec les Francs ;
- christianisation forcée sous Charlemagne ;
- mémoire guerrière.

## Alamans

Axes :

- confédération ;
- Rhin supérieur ;
- contacts avec Rome et Francs ;
- héritage régional en Europe centrale.

## Vandales

Axes :

- migrations ;
- Espagne ;
- Afrique du Nord ;
- Carthage ;
- royaume vandale ;
- sac de Rome de 455.

## Burgondes

Axes :

- royaume burgonde ;
- Rhône ;
- intégration dans l’espace post-romain ;
- héritage dans la Bourgogne.

## Lombards

Axes :

- migrations ;
- Italie ;
- royaume lombard ;
- transition entre Antiquité tardive et Moyen Âge.

## Suèves

Axes :

- migrations ;
- péninsule Ibérique ;
- royaume suève ;
- christianisation ;
- monde post-romain.

---

# ⚔️ 6. Guerre, honneur et chefferies

Le monde germanique ancien valorise souvent :

- fidélité au chef ;
- prestige guerrier ;
- don ;
- réputation ;
- courage ;
- serment ;
- mémoire du nom ;
- compagnonnage guerrier.

Le chef doit donner :

- protection ;
- butin ;
- reconnaissance ;
- ordre ;
- prestige collectif.

Le guerrier doit donner :

- fidélité ;
- courage ;
- présence au combat ;
- mémoire de l’engagement.

Formule :

Le serment germanique relie l’homme, le chef, la lignée et la réputation.

---

# ⚖️ 7. Droit coutumier et assemblées

Le monde germanique ancien connaît des formes d’assemblées et de décisions collectives.

Axes :

- assemblées d’hommes libres ;
- droit coutumier ;
- compensation ;
- arbitrage ;
- serment ;
- réputation ;
- oralité juridique.

Pont avec Vikings :

Le þing nordique prolonge certaines logiques germaniques d’assemblée, de parole publique et de décision communautaire.

---

# 🌲 8. Forêts, frontières et imaginaire romain

Pour Rome, la Germanie est souvent perçue comme :

- forêt ;
- nord ;
- frontière ;
- monde rude ;
- altérité ;
- espace non romanisé ;
- réserve de forces militaires.

Mais il faut éviter la caricature.

Les Germains ne sont pas de simples barbares sauvages.

Ils possèdent :

- structures sociales ;
- réseaux ;
- commerce ;
- artisanat ;
- chefferies ;
- traditions ;
- systèmes de droit ;
- capacités d’adaptation.

---

# 🔤 9. Langues, Futhark et mémoire écrite

Les langues germaniques anciennes sont un pilier de l’histoire européenne.

Axes :

- proto-germanique ;
- langues germaniques occidentales ;
- langues germaniques orientales ;
- langues germaniques septentrionales ;
- gotique ;
- vieux haut allemand ;
- vieil anglais ;
- vieux norrois.

Le Futhark appartient au monde germanique ancien.

Fonctions :

- inscription ;
- nom ;
- mémoire ;
- marquage ;
- objet ;
- pierre ;
- arme ;
- amulette.

Pour la convention de traduction ERITH.IA, utiliser le module canonique :

modules/erith_ia_celtes_culture_celtique_futhark_final_fr.md

Règle :

Le présent module donne le contexte germanique.

Le module Futhark ERITH.IA donne la convention opérative de transcription.

---

# 🐉 10. Mythes et héritages religieux

Les religions germaniques anciennes varient selon les périodes et les régions.

Axes possibles :

- divinités communes avec le monde nordique ;
- Wodan / Odin ;
- Donar / Thor ;
- Tiwaz / Tyr ;
- Nerthus selon Tacite ;
- cultes locaux ;
- bois sacrés ;
- sources ;
- serments ;
- sacrifices ;
- fêtes saisonnières.

Garde-fou :

Ne pas projeter automatiquement la mythologie nordique tardive sur tous les Germains anciens.

Il existe des continuités, mais aussi des différences régionales et chronologiques.

---

# ✝️ 11. Christianisation

La christianisation du monde germanique est progressive, complexe et variable.

Axes :

- Goths ariens ;
- conversion des Francs ;
- missions anglo-saxonnes ;
- christianisation des Saxons ;
- fusion d’éléments anciens et chrétiens ;
- lois chrétiennes ;
- monastères ;
- manuscrits.

La conversion n’efface pas immédiatement les structures anciennes.

Elle les transforme.

Phrase clé :

Une culture ne disparaît pas toujours : elle change de langue, de rite et de vêtement.

---

# 🏰 12. Royaumes post-romains

Après la transformation de l’Empire romain d’Occident, plusieurs royaumes germaniques apparaissent ou se stabilisent.

Exemples :

- royaume wisigoth ;
- royaume ostrogoth ;
- royaume vandale ;
- royaume burgonde ;
- royaume franc ;
- royaume lombard ;
- royaumes anglo-saxons.

Ces royaumes ne sont pas simplement “anti-romains”.

Ils héritent souvent de :

- droit romain ;
- administration ;
- christianisme ;
- latin ;
- institutions impériales ;
- modèles royaux.

Formule :

Les royaumes germaniques ne détruisent pas seulement Rome : ils héritent d’elle et la transforment.

---

# 👑 13. Francs et naissance de la France

Les Francs occupent une place centrale pour l’histoire européenne et française.

Axes :

- confédération franque ;
- expansion en Gaule ;
- Clovis ;
- conversion ;
- Mérovingiens ;
- Carolingiens ;
- fusion romano-germanique ;
- racines du royaume de France.

Le nom France vient des Francs.

Mais la France historique résulte d’un empilement :

- substrats celtiques / gaulois ;
- romanisation ;
- christianisation ;
- apports francs ;
- structures médiévales ;
- évolution linguistique et politique.

---

# 🧭 14. Ponts civilisationnels

## Germains ↔ Rome

Frontières, guerre, fédérés, armée, droit, royaumes post-romains.

## Germains ↔ Celtes

Voisinage, contacts, conflits, zones mixtes, Europe ancienne, forêts, oralité, aristocraties guerrières.

## Germains ↔ Vikings

Langues, Futhark, mythologies apparentées, assemblées, serments, monde nordique.

## Germains ↔ Christianisme

Conversions, royaumes, manuscrits, droit, monastères, construction médiévale.

## Germains ↔ France

Francs, Gaule, romanité, christianisme, dynasties, naissance politique d’un territoire.

---

# 🎨 15. Direction artistique ERITH.IA

Éléments visuels :

- forêt dense ;
- Rhin brumeux ;
- frontière romaine ;
- palissades ;
- boucliers ronds ou ovales ;
- fer sombre ;
- fibules ;
- peaux sobres ;
- torques ou anneaux selon contexte ;
- feu de camp ;
- clairière d’assemblée ;
- limes romain au loin ;
- pierre gravée ;
- chef guerrier ;
- messager ;
- serment devant le clan.

À éviter :

- confondre Germains et Vikings tardifs ;
- casques à cornes ;
- barbares caricaturaux ;
- armures fantasy plastiques ;
- esthétique super-héros ;
- effacer Rome ;
- effacer les Celtes ;
- présenter tous les Germains comme un seul peuple uniforme.

---

# 🎬 16. Usage production image

Prompt maître :

```text
ancient Germanic world, misty forest near the Rhine frontier, wooden palisade settlement, dark iron weapons, clan assembly around a fire, Roman limes in the distance, solemn oath atmosphere, historical late antiquity mood, realistic textures, wool, leather, wood, smoke, cold northern light, no horned helmets, no fantasy armor, no superhero style, cinematic historical realism
```

Prompt frontière Rome / Germanie :

```text
Roman frontier at the edge of ancient Germania, misty forest beyond the limes, watchtower, river border, Germanic envoys approaching, tense diplomatic atmosphere, realistic late antiquity, cold light, mud, wood, iron, no fantasy clichés, historical cinematic composition
```

---

# 🎞️ 17. Usage production animation

Une animation = une idée.

Idées sûres :

- brume sur le Rhin ;
- feu qui bouge dans une assemblée ;
- bannière ou manteau dans le vent ;
- lumière sur une lame ancienne ;
- caméra lente vers une palissade ;
- forêt qui bruisse ;
- soldats romains au loin ;
- chef germanique qui lève la main pour un serment ;
- fumée de village ;
- pluie fine sur une frontière.

Éviter :

- bataille de masse chaotique ;
- Vikings mélangés sans raison ;
- armures médiévales tardives ;
- magie excessive ;
- clichés barbares.

---

# 🧠 18. Block LLM

Tu charges le Module Mémoire Germains & Monde germanique ancien.

Ce module apporte :

- peuples germaniques anciens ;
- Germanie ;
- Rome ;
- Rhin ;
- Danube ;
- Goths ;
- Francs ;
- Saxons ;
- Alamans ;
- Vandales ;
- Burgondes ;
- Lombards ;
- Suèves ;
- migrations ;
- royaumes post-romains ;
- Futhark historique ;
- droit coutumier ;
- assemblées ;
- christianisation ;
- ponts avec Celtes, Vikings et Rome.

Règle :

Séparer systématiquement :

- faits ;
- sources ;
- hypothèses ;
- interprétations ;
- usages créatifs.

Ne pas confondre :

- Germains anciens ;
- Celtes ;
- Vikings ;
- Romains ;
- nations modernes.

Si une transcription runique exacte est demandée, utiliser le module canonique :

modules/erith_ia_celtes_culture_celtique_futhark_final_fr.md

Répondre avec :

- peuple ou région ;
- période ;
- lien avec Rome ;
- statut des sources ;
- rôle historique ;
- usage ERITH.IA ;
- garde-fou.

---

# ⚡ Activation courte

Active le module Germains & Monde germanique ancien.

Utilise-le pour comprendre les peuples germaniques anciens, Goths, Francs, Saxons, Alamans, Vandales, Burgondes, Lombards, Suèves, rapports avec Rome, migrations, royaumes post-romains, Futhark historique, assemblées, serments, christianisation et naissance de l’Europe médiévale.

Sépare faits, sources, hypothèses, interprétations et usages créatifs.

---

# 🕯️ 19. Formule finale

Les Germains vivent aux frontières.

Frontières de Rome.

Frontières des forêts.

Frontières des langues.

Frontières de l’Antiquité et du Moyen Âge.

Ils combattent Rome.

Ils servent Rome.

Ils héritent de Rome.

Ils transforment Rome.

Dans leurs serments, leurs assemblées, leurs migrations et leurs royaumes, ERITH.IA reconnaît une grande loi de l’histoire :

les civilisations ne disparaissent pas toujours.

Elles se mélangent, se déplacent, changent de nom, puis fondent un autre monde.
