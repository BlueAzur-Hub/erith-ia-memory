# ERITH.IA — Œuvre fondatrice — Táin Bó Cúailnge

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Irlande ancienne / cycle d’Ulster / monde celtique  
Fonction : apporter à ERITH.IA une base héroïque, guerrière et symbolique issue de la grande épopée irlandaise.

La Táin Bó Cúailnge, souvent appelée “Razzia des vaches de Cooley”, appartient au cycle d’Ulster. Elle met en scène une guerre déclenchée autour d’un taureau prestigieux, mais son intérêt dépasse largement le motif de la razzia : elle parle de souveraineté, de prestige, de désir, de guerre, de jeunesse héroïque, de furie sacrée et de destin.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire celtique irlandaise ancienne ;
- une lecture de l’héroïsme comme puissance dangereuse ;
- la figure du jeune champion face à une armée ;
- les tensions entre souveraineté, richesse, rivalité et honneur ;
- une esthétique de brume, de collines, de gués, de chars, de fer et de parole rituelle ;
- une compréhension du héros comme force liminale entre humain, animal, guerrier et sacré.

## Figures et motifs majeurs

- Cú Chulainn : jeune héros, défenseur d’Ulster, furie guerrière, transformation au combat.
- Medb : reine de Connacht, souveraineté, désir de puissance, stratégie.
- Ailill : roi, rivalité conjugale, prestige.
- Fergus : ancien lien avec Ulster, mémoire, loyauté divisée.
- Le taureau brun de Cooley : richesse, pouvoir, symbole de prestige et de conflit.
- Le gué : seuil, duel, passage, lieu de décision.
- Le char : vitesse, guerre aristocratique, mobilité héroïque.
- La furie guerrière : transformation, excès, puissance incontrôlable.

## Thèmes profonds

Héroïsme et excès  
Souveraineté et possession  
Jeunesse sacrifiée à la guerre  
Parole, serment et honneur  
Duel comme jugement  
Animalité et puissance royale  
Mémoire orale et amplification épique  
Guerre comme déséquilibre du monde

## Garde-fous

Ne pas réduire la Táin à une simple histoire de vol de bétail.

Ne pas transformer Cú Chulainn en super-héros moderne.

Ne pas confondre l’épopée irlandaise ancienne avec une fantasy celtique générique.

Séparer :

- source médiévale irlandaise ;
- cycle d’Ulster ;
- interprétation mythologique ;
- réemploi moderne ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : herbe humide, boue, fer, cuir, bois de char, brume, sang discret, pierre ancienne.  
Lumière : ciel bas, aube grise, feu de camp, éclat métallique sur un gué.  
Architecture : forts de terre, collines, chemins anciens, gués, pierres dressées.  
Ambiance : héroïque, sauvage, tragique, verte, brumeuse, archaïque.

## Prompt image — base

Un jeune champion celtique ancien se tenant seul sur un gué brumeux face à une armée lointaine, char de guerre derrière lui, collines vertes, ciel gris, pierres dressées, atmosphère héroïque et tragique, peinture épique ancienne, lumière froide, détails de fer, cuir et bois, sans franchise moderne, sans texte, sans cliché fantasy.

## Prompt animation — base

Caméra lente au ras d’un gué irlandais ancien, brume basse, eau sombre, herbes humides, silhouettes d’une armée au loin, char immobile, cape agitée par le vent, tension avant duel, mouvement minimal, rythme grave, continuité stable.

## Prompt négatif

fantasy moderne générique, super-héros, armure brillante exagérée, cornes décoratives, jeu vidéo identifiable, logo, texte, cartoon, sursexualisation, bataille massive confuse, anachronisme.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter la Táin Bó Cúailnge comme une source héroïque celtique irlandaise liée au cycle d’Ulster. Le module doit aider à créer des scènes de gué, de duel, de souveraineté, de furie guerrière, de chars, de brume et de destin, en distinguant toujours source ancienne, interprétation et usage créatif.

## Formule courte

Táin Bó Cúailnge = héros au gué + souveraineté + furie guerrière + Irlande ancienne.
