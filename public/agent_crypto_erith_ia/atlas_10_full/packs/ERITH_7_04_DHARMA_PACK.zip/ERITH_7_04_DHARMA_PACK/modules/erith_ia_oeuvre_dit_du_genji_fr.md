# ERITH.IA — Œuvre fondatrice — Le Dit du Genji

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Japon de Heian  
Œuvre : Le Dit du Genji  
Autrice : Murasaki Shikibu  
Fonction : apporter à ERITH.IA une base littéraire, psychologique et esthétique sur la cour de Heian, la mélancolie, le raffinement, le désir, le passage du temps et l’impermanence.

Le Dit du Genji est une œuvre majeure de la littérature japonaise classique. Il ne sert pas seulement à comprendre une intrigue de cour : il donne accès à une sensibilité du monde, faite de nuances, de relations, de mémoire, de beauté fragile et de perte.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire de cour japonaise raffinée ;
- une lecture psychologique des relations, désirs, regrets et silences ;
- une esthétique de paravent, soie, jardin, pluie fine, lune, lettres et parfums ;
- une compréhension de l’impermanence comme structure émotionnelle ;
- une matière utile pour scènes lentes, intimes, élégantes, mélancoliques et symboliques.

## Figures et motifs majeurs

- Hikaru Genji : beauté, désir, prestige, instabilité, mélancolie.
- Murasaki : formation, affection, complexité relationnelle, fragilité.
- La cour de Heian : codes, hiérarchie, raffinement, contraintes.
- Les lettres : désir indirect, distance, style, mémoire.
- Les parfums : présence invisible, identité, trace.
- Les jardins : saisons, passage du temps, émotion projetée dans le paysage.
- La lune : distance, solitude, beauté froide.
- Les manches mouillées : signe poétique de larmes et d’émotion.

## Thèmes profonds

Impermanence  
Mélancolie  
Beauté fragile  
Désir et conséquence  
Mémoire affective  
Raffinement et contrainte sociale  
Saisons comme langage émotionnel  
Silence, non-dit et distance  
Psychologie fine des relations

## Garde-fous

Ne pas réduire Le Dit du Genji à une romance de cour.

Ne pas l’utiliser comme simple décor “japon ancien élégant”.

Ne pas romantiser sans nuance les rapports de pouvoir et les contraintes sociales.

Séparer :

- valeur littéraire ;
- contexte de cour Heian ;
- psychologie des personnages ;
- esthétique japonaise classique ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : soie, papier, encre, paravent peint, bois poli, rideaux de cour, fleurs de saison.  
Lumière : lune, lampe à huile, pluie fine, lumière filtrée par les cloisons.  
Architecture : palais Heian, couloirs, jardins, pavillons, écrans peints.  
Ambiance : intime, raffinée, mélancolique, lente, psychologique, saisonnière.

## Prompt image — base

Une scène de cour japonaise de l’époque Heian, pavillon silencieux, paravents peints, soie légère, lettre posée près d’une lampe à huile, jardin humide sous la lune, pluie fine, atmosphère mélancolique et raffinée, peinture cinématographique poétique, beauté fragile, sans texte lisible, sans franchise moderne.

## Prompt animation — base

Caméra lente dans un pavillon Heian silencieux, rideaux de soie bougeant doucement, pluie fine dans le jardin, lampe à huile vacillante, lettre posée sur le tatami, lumière lunaire, atmosphère intime et mélancolique, mouvement minimal, continuité stable.

## Prompt négatif

anime moderne, manga, geisha cliché, samouraï cliché, ninja, logo, texte lisible, jeu vidéo identifiable, romance kitsch, couleurs criardes, fantasy générique, anachronisme.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter Le Dit du Genji comme une source littéraire japonaise classique liée à la psychologie, à la cour de Heian, à l’impermanence, aux saisons, à la beauté fragile, aux relations complexes et aux non-dits. Le module doit produire des scènes lentes, raffinées, mélancoliques et sensibles, sans réduire l’œuvre à une romance ou à un décor japonisant.

## Formule courte

Dit du Genji = cour de Heian + beauté fragile + désir + mémoire + impermanence.
