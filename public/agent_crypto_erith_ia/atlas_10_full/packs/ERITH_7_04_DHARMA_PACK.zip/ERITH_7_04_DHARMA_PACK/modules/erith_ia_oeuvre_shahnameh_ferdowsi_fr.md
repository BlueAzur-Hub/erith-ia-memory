# 📖 ERITH.IA — Shahnameh / Livre des Rois

Statut : module mémoire œuvre fondatrice  
Projet : @erith IA / ERITH.IA  
Type : Perse, Iran, Ferdowsi, épopée royale, héros, rois, mémoire iranienne, Rostam, miniatures persanes  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension structurée du Shahnameh, le grand poème épique de Ferdowsi et l’un des piliers de la mémoire culturelle iranienne.

Il active :

- Perse / Iran ;
- Ferdowsi ;
- rois mythiques ;
- héros ;
- Rostam ;
- Sohrab ;
- dragons ;
- destin ;
- loyauté ;
- tragédie ;
- souveraineté ;
- mémoire nationale ;
- miniatures persanes ;
- transmission poétique.

Formule centrale :

Le Shahnameh est une arche de mémoire : il sauve les rois, les héros et les douleurs de l’Iran ancien par la poésie.

---

# 🛡️ 2. Garde-fou historique

Ne pas confondre le Shahnameh avec une chronique historique simple.

Toujours distinguer :

- mythe ;
- épopée ;
- mémoire royale ;
- identité culturelle ;
- histoire iranienne ;
- réécriture poétique ;
- usage créatif ERITH.IA.

Le Shahnameh transmet une vérité culturelle et symbolique, pas seulement une suite de faits historiques.

---

# 👑 3. Figures et axes majeurs

## Ferdowsi

Poète persan majeur.

Axes :

- langue persane ;
- mémoire ;
- transmission ;
- résistance culturelle ;
- épopée nationale.

## Rostam

Grand héros du Shahnameh.

Axes :

- force ;
- loyauté ;
- tragédie ;
- grandeur guerrière ;
- vulnérabilité du héros.

## Sohrab

Figure tragique.

Axes :

- filiation ;
- destin ;
- méconnaissance ;
- douleur irréversible.

---

# 🐉 4. Thèmes majeurs

- royauté ;
- héroïsme ;
- destin ;
- filiation ;
- guerre ;
- trahison ;
- sagesse ;
- mort ;
- dragon ;
- mémoire ;
- grandeur et chute ;
- transmission de l’Iran ancien.

Phrase clé :

Dans le Shahnameh, le héros est grand parce qu’il porte aussi la perte.

---

# 🎨 5. Direction artistique ERITH.IA

Éléments visuels :

- miniature persane ;
- héros à cheval ;
- montagne stylisée ;
- dragon ;
- palais ;
- jardin persan ;
- manuscrit enluminé ;
- or ;
- turquoise ;
- lapis-lazuli ;
- armure persane stylisée ;
- scène de cour ;
- bataille épique codifiée.

À éviter :

- fantasy européenne générique ;
- dragon gratuit sans contexte ;
- Perse caricaturée ;
- confusion Arabie / Perse / Inde ;
- réduction du Shahnameh à un simple recueil d’aventures.

---

# 🖼️ 6. Usage production image

```text
Shahnameh inspired Persian epic scene, Ferdowsi manuscript atmosphere, Rostam heroic figure, Persian miniature aesthetics, jewel-like colors, gold and lapis lazuli, stylized mountains, royal garden, dragon motif, poetic Iranian memory, no generic European fantasy, no orientalist cliché
```

---

# 🎞️ 7. Usage production animation

Une animation = une idée.

Idées sûres :

- page de manuscrit persan révélée par la lumière ;
- cavalier immobile dans le vent ;
- or qui brille sur une miniature ;
- ombre d’un dragon sur une montagne stylisée ;
- poussière douce dans une cour royale ;
- calligraphie éclairée par une lampe.

---

# 🧠 8. Block LLM

Tu charges le Module Œuvre Fondatrice Shahnameh.

Utilise-le pour comprendre Ferdowsi, la mémoire iranienne, Rostam, Sohrab, les rois mythiques, les dragons, le destin, la filiation, la tragédie héroïque et l’esthétique des miniatures persanes.

Sépare faits, tradition, poésie, mythe, interprétations et usages créatifs.

---

# 🕯️ Formule finale

Le Shahnameh n’est pas seulement un livre de rois.

C’est une mémoire qui refuse de mourir.

Il garde les noms.

Il garde les fautes.

Il garde les héros.

Il garde les larmes.

Et dans la voix de Ferdowsi, ERITH.IA reconnaît une loi puissante :

quand un empire tombe, une œuvre peut encore porter son âme.
