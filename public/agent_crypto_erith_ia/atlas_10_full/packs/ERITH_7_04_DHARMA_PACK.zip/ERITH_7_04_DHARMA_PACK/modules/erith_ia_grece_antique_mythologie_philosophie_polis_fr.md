# 🏛️ MODULE MÉMOIRE — GRÈCE ANTIQUE, MYTHOLOGIE, PHILOSOPHIE & POLIS

## ⚡ ERITH.IA — Cités, Dieux, Héros, Mystères, Géométrie, Logos et Mémoire Méditerranéenne

Version : 1.0  
Usage : GitHub privé / Notion / Ollama / RAG / Seven Heaven / ERITH.IA  
Statut : module majeur — civilisation carrefour  
Langue : français  
Fichier : modules/erith_ia_grece_antique_mythologie_philosophie_polis_fr.md

---

# 🎯 Intention

Ce module augmente ERITH.IA avec une compréhension structurée de la Grèce antique : monde égéen, cités, mythologie, cultes, mystères, philosophie, mathématiques, art, politique, astronomie et héritage méditerranéen.

La Grèce antique est une civilisation carrefour.

Elle reçoit, transforme et transmet des héritages venus notamment :

- d’Égypte ;
- de Mésopotamie ;
- d’Anatolie ;
- du Levant ;
- du monde minoen ;
- du monde mycénien ;
- de la Perse ;
- de la Méditerranée entière.

Elle ne doit pas être étudiée comme une origine isolée.

Elle doit être étudiée comme une grande chambre de transformation.

Pour ERITH.IA, ce module est majeur parce qu’il relie :

- mythe ;
- philosophie ;
- cité ;
- théâtre ;
- héros ;
- démocratie ;
- guerre ;
- art ;
- géométrie ;
- mathématiques ;
- astronomie ;
- mystères ;
- symboles ;
- transmission vers Rome, la Renaissance et le monde moderne.

---

# ⚖️ Contrat épistémique

Toujours distinguer :

- Grèce archaïque ;
- Grèce classique ;
- Grèce hellénistique ;
- monde minoen ;
- monde mycénien ;
- mythologie ;
- rite ;
- philosophie ;
- histoire ;
- théâtre ;
- science ;
- géométrie ;
- tradition initiatique ;
- interprétation moderne ;
- correspondance civilisationnelle.

Méthode retenue :

**Faits observables d’abord.  
Correspondances documentées ensuite.  
Interprétation libre ensuite.**

ERITH.IA doit poser :

- noms ;
- cités ;
- textes ;
- mythes ;
- dieux ;
- héros ;
- sanctuaires ;
- écoles ;
- concepts ;
- symboles ;
- objets ;
- œuvres ;
- correspondances.

Elle ne doit pas réduire la Grèce à “l’origine de l’Occident”.

Elle ne doit pas effacer les héritages antérieurs.

Elle ne doit pas transformer les ponts civilisationnels en slogans pauvres.

---

# 🌊 1. Monde égéen et racines anciennes

## 🌀 Cyclades, Crète et monde minoen

Avant la Grèce classique, le monde égéen connaît des cultures puissantes.

La Crète minoenne est liée à :

- palais ;
- fresques ;
- mer ;
- taureau ;
- labyrinthe ;
- danse ;
- déesses ;
- économie palatiale ;
- contacts méditerranéens.

Le motif du taureau est majeur.

Il relie la Crète à de nombreux symboles anciens de puissance, fertilité, souveraineté et passage.

## ⚔️ Mycènes

Le monde mycénien est lié à :

- palais fortifiés ;
- rois guerriers ;
- tablettes en linéaire B ;
- économie palatiale ;
- guerre ;
- héros ;
- mémoire de Troie ;
- début de certains cadres grecs ultérieurs.

## 🏺 Troie et Anatolie

Troie représente :

- frontière ;
- échange ;
- guerre ;
- mémoire héroïque ;
- contact entre Égée et Anatolie ;
- fondation d’un imaginaire épique.

## 🧠 Leçon

La Grèce antique ne surgit pas du vide.

Elle naît d’un monde égéen, méditerranéen et oriental déjà très ancien.

Phrase clé :

**Avant Athènes, il y a la mer, le palais, le taureau, la tombe, la tablette et le chant.**

---

# 🏛️ 2. Naissance de la polis

## 🏙️ La cité grecque

La polis est une forme politique majeure.

Elle n’est pas seulement une ville.

Elle est :

- communauté ;
- territoire ;
- culte ;
- loi ;
- citoyens ;
- mémoire ;
- armée ;
- agora ;
- sanctuaires ;
- identité collective.

## 🗣️ Agora

L’agora est le lieu :

- du marché ;
- de la parole ;
- de la politique ;
- du débat ;
- de la rencontre civique.

## 🛡️ Hoplites

Le citoyen-soldat hoplite transforme le rapport entre guerre et citoyenneté.

Axes :

- phalange ;
- bouclier ;
- discipline ;
- égalité relative entre combattants ;
- défense de la cité.

## 🧠 Leçon

La polis fait du politique une affaire visible, discutée et ritualisée.

Phrase clé :

**La cité grecque transforme la parole en force publique.**

---

# 🦉 3. Athènes, Sparte et modèles politiques

## 🦉 Athènes

Athènes est liée à :

- démocratie ;
- assemblée ;
- théâtre ;
- philosophie ;
- marine ;
- empire maritime ;
- Parthénon ;
- tragédie ;
- procès de Socrate.

La démocratie athénienne doit être comprise avec ses limites :

- citoyens masculins ;
- exclusion des femmes ;
- esclavage ;
- métèques ;
- impérialisme.

Mais elle reste une expérience politique fondamentale.

## 🛡️ Sparte

Sparte est liée à :

- discipline ;
- armée ;
- éducation militaire ;
- oligarchie ;
- austérité ;
- hiérarchie sociale ;
- domination des hilotes.

## 🏛️ Thèbes, Corinthe et autres cités

La Grèce ne se réduit pas à Athènes et Sparte.

Autres centres importants :

- Thèbes ;
- Corinthe ;
- Milet ;
- Éphèse ;
- Argos ;
- Delphes ;
- Olympie.

## 🧠 Leçon

La Grèce est une constellation de cités rivales.

Phrase clé :

**La Grèce antique n’est pas un État unique : c’est un ciel de cités en tension.**

---

# ⚡ 4. Mythologie grecque

## 🌌 Origines cosmiques

Les récits grecs commencent souvent par :

- Chaos ;
- Gaïa ;
- Ouranos ;
- Titans ;
- Cronos ;
- Zeus ;
- Olympiens.

Ces récits parlent :

- d’origine ;
- de générations divines ;
- de lutte pour la souveraineté ;
- d’ordre né du conflit.

## 👑 Zeus

Zeus est lié à :

- ciel ;
- foudre ;
- souveraineté ;
- justice ;
- serment ;
- ordre olympien.

## 🌊 Poséidon

Poséidon est lié à :

- mer ;
- tremblements de terre ;
- chevaux ;
- puissance instable ;
- trident.

## 🦉 Athéna

Athéna est liée à :

- sagesse ;
- stratégie ;
- cité ;
- artisanat ;
- guerre maîtrisée ;
- chouette ;
- Athènes.

## ☀️ Apollon

Apollon est lié à :

- lumière ;
- musique ;
- prophétie ;
- mesure ;
- arc ;
- Delphes ;
- purification ;
- harmonie.

## 🌙 Artémis

Artémis est liée à :

- lune selon traditions et rapprochements ;
- chasse ;
- nature sauvage ;
- seuils ;
- jeunes filles ;
- protection ;
- monde liminal.

## 🐍 Asclépios

Asclépios est lié à :

- guérison ;
- médecine ;
- serpent ;
- sanctuaire ;
- rêve thérapeutique ;
- incubation.

Le bâton d’Asclépios est un symbole majeur.

Il ne doit pas être confondu mécaniquement avec le caducée d’Hermès, mais les deux motifs doivent être archivés dans l’ensemble des symboles serpentaires.

## 🧠 Leçon

Les dieux grecs sont des puissances de fonction, de récit, de lieu et de relation.

Phrase clé :

**L’Olympe est une politique du cosmos racontée en figures divines.**

---

# 🐍 5. Serpent, caducée, médecine et énergie spiralée

## 🐍 Serpent grec

Le serpent apparaît dans de nombreux contextes :

- terre ;
- guérison ;
- oracle ;
- tombe ;
- protection ;
- renaissance ;
- mue ;
- sagesse ;
- danger ;
- seuil.

## 🏥 Asclépios

Le serpent d’Asclépios relie :

- guérison ;
- rêve ;
- sanctuaire ;
- corps ;
- médecine ;
- régénération.

Les sanctuaires d’Asclépios pratiquaient notamment l’incubation : le malade dormait dans un espace sacré afin de recevoir un rêve guérisseur ou un signe.

## ☤ Caducée d’Hermès

Le caducée est lié à Hermès.

Axes :

- messager ;
- passage ;
- commerce ;
- médiation ;
- routes ;
- seuils ;
- serpents entrelacés ;
- axe central ;
- circulation.

## 🌀 Spirale, énergie, montée

Les serpents entrelacés autour d’un axe doivent être archivés comme motif transversal.

Axes de comparaison future :

- caducée ;
- bâton d’Asclépios ;
- Kundalini ;
- Ida / Pingala / Sushumna ;
- spirale ;
- colonne ;
- montée d’énergie ;
- polarités ;
- guérison ;
- passage entre plans.

## 🧠 Leçon

Le serpent grec n’est pas un simple animal.

Il est un signe de seuil, de guérison, de puissance souterraine et de transformation.

Phrase clé :

**Là où le serpent apparaît, il faut regarder le passage : corps, rêve, mort, guérison, seuil ou connaissance.**

---

# 🏺 6. Cultes, sanctuaires et mystères

## 🔮 Delphes

Delphes est lié à :

- Apollon ;
- oracle ;
- Pythie ;
- omphalos ;
- serpent Python ;
- centre symbolique ;
- décision politique ;
- parole divine ambiguë.

## 🌾 Mystères d’Éleusis

Les mystères d’Éleusis sont liés à :

- Déméter ;
- Perséphone ;
- cycle ;
- mort ;
- retour ;
- initiation ;
- blé ;
- secret rituel.

Ils constituent l’un des grands complexes initiatiques du monde grec.

## 🍇 Dionysos

Dionysos est lié à :

- ivresse ;
- théâtre ;
- extase ;
- masque ;
- transe ;
- mort et retour ;
- démembrement dans certaines traditions ;
- rupture de l’ordre social ordinaire.

## 🎼 Orphisme

L’orphisme est lié à :

- Orphée ;
- âme ;
- purification ;
- descente aux Enfers ;
- musique ;
- mystères ;
- destin post-mortem ;
- libération.

## 🔢 Pythagorisme

Le pythagorisme relie :

- nombre ;
- âme ;
- purification ;
- musique ;
- proportion ;
- harmonie ;
- cosmos ;
- transmigration selon traditions.

## 🧠 Leçon

La Grèce n’est pas seulement rationnelle et politique.

Elle est aussi initiatique, rituelle, nocturne et mystérique.

Phrase clé :

**Sous la lumière de la cité grecque, il existe des chambres secrètes de nuit, de rite et de transformation.**

---

# 📐 7. Mathématiques, géométrie et harmonie cosmique

## 📏 Thalès

Thalès est associé aux débuts de la philosophie naturelle et de la géométrie grecque.

Axes :

- mesure ;
- eau ;
- observation ;
- démonstration ;
- cosmos pensé rationnellement.

## 🔢 Pythagore

Pythagore et les pythagoriciens relient :

- nombre ;
- musique ;
- proportion ;
- âme ;
- cosmos ;
- harmonie ;
- géométrie ;
- discipline.

## 📐 Euclide

Euclide représente l’organisation systématique de la géométrie.

Les Éléments deviennent une matrice de pensée démonstrative.

## ⚙️ Archimède

Archimède relie :

- mathématiques ;
- mécanique ;
- géométrie ;
- invention ;
- calcul ;
- levier ;
- flottabilité.

## 🎼 Musique des sphères

La musique des sphères exprime l’idée que le cosmos peut être pensé comme harmonie numérique.

Axes :

- rapports ;
- vibration ;
- ordre ;
- rythme ;
- astres ;
- proportion.

## 🌀 Spirale et formes

La spirale, le cercle, le triangle, la proportion et les rapports numériques doivent être conservés comme pièces majeures.

Ils serviront plus tard au module :

`erith_ia_mathematiques_geometrie_harmonie_cosmique_fr.md`

## 🧠 Leçon

La Grèce transforme le nombre en langage du monde.

Phrase clé :

**Le nombre n’est pas seulement calcul : il devient harmonie, preuve, musique et architecture du cosmos.**

---

# 📚 8. Philosophie grecque

## 🌊 Présocratiques

Les présocratiques cherchent les principes du monde.

Figures :

- Thalès ;
- Anaximandre ;
- Héraclite ;
- Parménide ;
- Empédocle ;
- Anaxagore ;
- Démocrite.

Axes :

- eau ;
- apeiron ;
- feu ;
- être ;
- devenir ;
- éléments ;
- atomes ;
- ordre cosmique.

## 🗣️ Socrate

Socrate déplace la philosophie vers :

- vérité ;
- dialogue ;
- examen de soi ;
- vertu ;
- justice ;
- ignorance reconnue ;
- responsabilité morale.

## 🏛️ Platon

Platon développe :

- idées ;
- âme ;
- cité ;
- justice ;
- éducation ;
- dialectique ;
- mythe philosophique ;
- monde intelligible.

## 🧪 Aristote

Aristote développe :

- logique ;
- causes ;
- nature ;
- politique ;
- éthique ;
- biologie ;
- métaphysique ;
- poétique.

## 🧠 Leçon

La philosophie grecque n’est pas seulement accumulation d’idées.

Elle invente des méthodes de questionnement.

Phrase clé :

**La Grèce apprend à demander non seulement ce qui est vrai, mais comment on peut le savoir.**

---

# 🎭 9. Théâtre, tragédie et mémoire collective

## 🎭 Tragédie

La tragédie grecque met en scène :

- destin ;
- faute ;
- pouvoir ;
- famille ;
- dieux ;
- cité ;
- justice ;
- hubris ;
- mémoire.

Auteurs :

- Eschyle ;
- Sophocle ;
- Euripide.

## 😂 Comédie

La comédie met en scène :

- satire ;
- politique ;
- corps ;
- excès ;
- critique sociale ;
- liberté de parole.

Aristophane est une figure majeure.

## 🧠 Leçon

Le théâtre grec transforme la cité en miroir.

Phrase clé :

**Sur scène, la cité regarde ses dieux, ses crimes, ses lois et ses contradictions.**

---

# ⚔️ 10. Guerres, Perse et Alexandre

## ⚔️ Guerres médiques

Les conflits entre cités grecques et Empire perse marquent fortement la mémoire grecque.

Ils doivent être étudiés sans caricature :

- Grèce multiple ;
- Perse impériale ;
- alliances ;
- propagandes ;
- batailles ;
- mémoire politique.

## 🛡️ Guerre du Péloponnèse

La guerre entre Athènes et Sparte montre :

- rivalité ;
- impérialisme ;
- stratégie ;
- crise démocratique ;
- fragilité des cités.

Thucydide devient une source majeure pour penser guerre et pouvoir.

## 🦁 Alexandre le Grand

Alexandre relie :

- Macédoine ;
- Grèce ;
- Égypte ;
- Perse ;
- Asie centrale ;
- Inde ;
- monde hellénistique.

Il n’est pas seulement conquérant.

Il est un accélérateur de circulation culturelle.

## 🧠 Leçon

La Grèce classique culmine, se fracture, puis se diffuse avec l’hellénisme.

Phrase clé :

**Alexandre transforme la guerre en couloir de circulation entre les mondes.**

---

# 🏛️ 11. Monde hellénistique et Alexandrie

## 🌍 Hellenisme

Après Alexandre, le monde hellénistique relie :

- Égypte ptolémaïque ;
- Syrie séleucide ;
- Macédoine ;
- Anatolie ;
- Perse ;
- Asie centrale ;
- Inde ;
- Méditerranée.

## 📚 Alexandrie

Alexandrie devient un symbole majeur :

- bibliothèque ;
- musée ;
- savants ;
- traductions ;
- géographie ;
- mathématiques ;
- médecine ;
- astronomie ;
- rencontre Égypte / Grèce / monde méditerranéen.

## 🔭 Sciences hellénistiques

Figures :

- Euclide ;
- Archimède ;
- Ératosthène ;
- Hipparque ;
- Héron ;
- Ptolémée plus tard.

## 🧠 Leçon

Le monde hellénistique transforme la Grèce en réseau.

Phrase clé :

**Alexandrie devient une machine de mémoire où la Grèce dialogue avec l’Égypte, l’Orient et les sciences.**

---

# 🎨 12. Art grec

## 🏛️ Temple

Le temple grec relie :

- proportion ;
- colonne ;
- ordre ;
- divinité ;
- cité ;
- espace sacré ;
- géométrie.

Ordres :

- dorique ;
- ionique ;
- corinthien.

## 🧍 Sculpture

La sculpture grecque explore :

- corps ;
- proportion ;
- mouvement ;
- idéal ;
- beauté ;
- tension ;
- humanisation du divin.

## 🏺 Céramique

La céramique conserve :

- mythes ;
- scènes de guerre ;
- banquets ;
- rituels ;
- héros ;
- vie quotidienne.

## 🧠 Leçon artistique

L’art grec cherche l’accord entre corps, mesure, mouvement et idéal.

Phrase clé :

**La Grèce sculpte le divin en forme humaine et cherche dans le corps une géométrie vivante.**

---

# 🔗 13. Ponts civilisationnels et correspondances

## ☀️ Soleil, Apollon et élévation

Axes :

- lumière ;
- mesure ;
- prophétie ;
- harmonie ;
- purification ;
- ordre ;
- élévation ;
- vision.

Ponts futurs :

- Égypte solaire ;
- Amon-Rê ;
- disque solaire ;
- Mithra ;
- Surya ;
- Hélios ;
- Apollon.

## 🌙 Lune, Artémis et passages

Axes :

- nuit ;
- cycle ;
- seuils ;
- chasse ;
- rêve ;
- féminin sauvage ;
- protection ;
- passage ;
- monde liminal.

## 🐍 Serpent, caducée, Asclépios et Kundalini

Axes :

- guérison ;
- axe ;
- énergie ;
- spirale ;
- passage ;
- rêve ;
- sanctuaire ;
- montée ;
- transformation ;
- conscience et inconscient.

Ponts futurs :

- Kundalini ;
- Shiva ;
- caducée ;
- Asclépios ;
- serpents cosmiques ;
- dragons ;
- médecine ;
- rites de guérison.

## 🧵 Fil, labyrinthe et mémoire

Axes :

- Ariane ;
- labyrinthe ;
- Minotaure ;
- chemin ;
- perte ;
- retour ;
- initiation ;
- mémoire.

## 🐂 Taureau

Axes :

- Crète ;
- Minotaure ;
- sacrifice ;
- puissance ;
- fertilité ;
- Méditerranée ;
- Indus ;
- Mésopotamie ;
- Égypte.

## 📐 Géométrie et harmonie

Axes :

- nombre ;
- proportion ;
- musique ;
- architecture ;
- cosmos ;
- spirale ;
- cercle ;
- triangle ;
- preuve.

## ⚖️ Ordre cosmique et pouvoir

Comparaisons futures :

- Maât en Égypte ;
- Asha en Iran ;
- Mandat du Ciel en Chine ;
- Dharma en Inde ;
- loi royale en Mésopotamie ;
- Dike / Nomos / Cosmos en Grèce.

## 🧠 Règle de lecture

Ces ponts doivent être conservés comme pièces du puzzle.

La bonne méthode :

- poser les objets ;
- poser les symboles ;
- poser les fonctions ;
- poser les textes ;
- poser les zones d’échange ;
- laisser la carte apparaître progressivement.

Phrase clé :

**La Grèce transforme les héritages anciens en mythes, formes, nombres et questions.**

---

# 📚 14. Héritage mondial

La Grèce antique transmet :

- philosophie ;
- logique ;
- géométrie ;
- théâtre ;
- histoire ;
- démocratie ;
- tragédie ;
- mythologie ;
- sculpture ;
- architecture ;
- médecine ;
- astronomie ;
- politique ;
- rhétorique ;
- bibliothèque hellénistique ;
- science démonstrative.

Elle influence :

- Rome ;
- christianisme ancien ;
- islam classique ;
- Renaissance ;
- Europe moderne ;
- philosophie mondiale ;
- sciences ;
- arts ;
- institutions politiques.

## 🧠 Leçon

La Grèce est une civilisation de transformation.

Elle reçoit des symboles, récits et savoirs anciens, puis les reformule en mythes, questions, géométrie, théâtre, philosophie et politique.

Phrase clé :

**La Grèce n’est pas seulement une source : elle est un creuset.**

---

# 🌸 15. Usage ERITH.IA

Applications possibles :

- cités sacrées ;
- temples solaires ;
- oracles ;
- écoles philosophiques ;
- labyrinthes ;
- héros ;
- serpents guérisseurs ;
- géométrie sacrée ;
- mystères ;
- théâtre rituel ;
- bibliothèque d’Alexandrie ;
- musique des sphères ;
- routes hellénistiques ;
- monde entre Égypte, Perse et Méditerranée.

## 🎨 Direction artistique

Mots-clés visuels :

- marbre ;
- colonne ;
- mer Égée ;
- temple ;
- amphithéâtre ;
- laurier ;
- soleil doré ;
- lune argentée ;
- serpent ;
- caducée ;
- lyre ;
- chouette ;
- trident ;
- foudre ;
- labyrinthe ;
- géométrie ;
- bibliothèque ;
- parchemins ;
- bronze ;
- ciel étoilé.

## 🎬 Prompt animation

Mouvements adaptés :

- lumière sur colonne ;
- mer lente ;
- ombre de chouette ;
- serpent autour d’un bâton ;
- disque solaire au-dessus d’un temple ;
- lune sur Delphes ;
- lettres grecques qui apparaissent ;
- cercle géométrique qui se trace ;
- masque de théâtre dans la poussière ;
- bibliothèque qui s’illumine.

---

# 🛡️ 16. Erreurs fréquentes

- Faire de la Grèce une origine isolée.
- Oublier l’Égypte, la Mésopotamie, l’Anatolie et la Perse.
- Réduire la mythologie à des histoires décoratives.
- Oublier les cultes et les mystères.
- Confondre bâton d’Asclépios et caducée sans analyse.
- Réduire le serpent à un symbole unique.
- Réduire Pythagore à un théorème scolaire.
- Oublier la dimension initiatique du nombre et de l’harmonie.
- Idéaliser Athènes sans rappeler ses exclusions.
- Oublier Sparte, Thèbes, Corinthe, Milet et Alexandrie.
- Séparer artificiellement philosophie, politique, mythe et rite.
- Effacer les ponts civilisationnels.

---

# 🌐 17. Ressources Internet recommandées

Perseus Digital Library  
https://www.perseus.tufts.edu/  
Textes grecs et latins, traductions, outils philologiques.

Theoi Greek Mythology  
https://www.theoi.com/  
Répertoire très riche sur mythologie grecque, textes et sources.

Internet Classics Archive  
https://classics.mit.edu/  
Textes classiques accessibles.

Stanford Encyclopedia of Philosophy  
https://plato.stanford.edu/  
Philosophie grecque, Platon, Aristote, présocratiques.

Internet Encyclopedia of Philosophy  
https://iep.utm.edu/  
Synthèses philosophiques accessibles.

British Museum — Ancient Greece  
https://www.britishmuseum.org/  
Objets, sculpture, vases, art grec.

Metropolitan Museum of Art — Greek and Roman Art  
https://www.metmuseum.org/  
Essais, collections, chronologies.

Louvre — Antiquités grecques  
https://www.louvre.fr/  
Collections grecques et méditerranéennes.

World History Encyclopedia — Ancient Greece  
https://www.worldhistory.org/  
Synthèses historiques.

Internet Archive  
https://archive.org/  
Traductions, études anciennes, ouvrages libres.

Gallica — BnF  
https://gallica.bnf.fr/  
Sources françaises, classiques, études anciennes.

---

# 🤖 18. BLOCK LLM — GRÈCE ANTIQUE, MYTHOLOGIE, PHILOSOPHIE & POLIS

```text
Tu es autorisé à utiliser le module Grèce antique, Mythologie, Philosophie & Polis comme mémoire spécialisée ERITH.IA.

Quand le sujet concerne la Grèce antique, les cités, Athènes, Sparte, Delphes, Éleusis, Dionysos, Orphée, Pythagore, Socrate, Platon, Aristote, Apollon, Artémis, Asclépios, Hermès, le caducée, le serpent, la géométrie, les mathématiques, la musique des sphères, la polis, la démocratie, le théâtre, Alexandre, Alexandrie ou les ponts avec l’Égypte, la Mésopotamie, la Perse, l’Inde, Rome et la Renaissance, tu dois :

1. distinguer histoire, mythe, rite, philosophie, science, art et usage créatif ;
2. poser les faits observables : lieux, textes, objets, symboles, fonctions, écoles, œuvres ;
3. ne pas présenter la Grèce comme une origine isolée ;
4. intégrer les héritages méditerranéens, égyptiens, proche-orientaux et perses quand pertinent ;
5. intégrer le serpent, Asclépios, Hermès, le caducée et les symboles de guérison/passage comme pièces de comparaison ;
6. intégrer Pythagore, géométrie, musique, proportion, harmonie et astronomie comme axes majeurs ;
7. archiver les correspondances civilisationnelles sans les censurer ;
8. ne pas transformer les correspondances en slogans ;
9. relier la Grèce aux trois piliers : Histoire mondiale, Histoire de l’Art, Religions & Mythologies ;
10. produire des usages créatifs originaux compatibles ERITH.IA.

Répondre avec :
- contexte ;
- période ;
- cité ou tradition concernée ;
- sources ;
- figures majeures ;
- mythes / symboles ;
- philosophie / géométrie ;
- art / architecture ;
- ponts civilisationnels ;
- usage ERITH.IA ;
- synthèse claire.
```

---

# ⚡ Activation courte

Active le module Grèce antique, Mythologie, Philosophie & Polis.

Utilise-le comme mémoire spécialisée sur les cités grecques, Athènes, Sparte, Delphes, Éleusis, Apollon, Artémis, Asclépios, Hermès, Dionysos, Pythagore, Socrate, Platon, Aristote, la géométrie, les serpents, le caducée, les mystères, Alexandre, Alexandrie et les ponts civilisationnels.

Pose les faits observables.

Archive les correspondances.

Laisse l’interprétation ouverte.

---

# 🕯️ Formule finale

La Grèce antique a transformé la mer en réseau, le mythe en théâtre, le rite en mystère, la cité en parole publique, le nombre en harmonie et la question en méthode.

Elle n’a pas seulement inventé des réponses.

Elle a transmis l’art de demander.

Et dans ses temples, ses serpents, ses astres, ses figures, ses héros et ses géomètres, une partie de l’ancienne mémoire du monde a changé de langue pour continuer à voyager.
