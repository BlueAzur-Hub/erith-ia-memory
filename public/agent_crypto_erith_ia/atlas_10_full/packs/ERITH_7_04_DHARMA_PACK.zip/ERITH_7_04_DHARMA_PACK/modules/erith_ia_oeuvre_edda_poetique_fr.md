# ERITH.IA — Œuvre fondatrice — Edda poétique

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Monde nordique / Islande médiévale / héritage germanique  
Fonction : apporter à ERITH.IA une base de lecture sur les chants mythologiques et héroïques nordiques transmis par l’Edda poétique.

Ce module sert à comprendre la mémoire orale, la poésie sacrée, la cosmologie nordique, les dieux, les héros, les prophéties et la tension entre destin, courage et effondrement du monde.

## Rôle dans ERITH.IA

L’Edda poétique permet d’activer :

- une mémoire du Nord ancien ;
- une lecture des mythes par fragments, chants et visions ;
- une esthétique de feu, de glace, de forêts, de runes et de paroles prophétiques ;
- une compréhension du Ragnarök comme crise cosmique, pas comme simple apocalypse spectaculaire ;
- une matière narrative utile pour modules épiques, tragiques, héroïques et symboliques.

## Figures et motifs majeurs

- Odin : savoir, sacrifice, quête des runes, parole, ruse, mort initiatique.
- Thor : force protectrice, tonnerre, défense du monde humain.
- Loki : ambiguïté, rupture, intelligence dangereuse, dérèglement.
- Tyr : loi, courage, sacrifice de la main.
- Baldr : lumière, perte, innocence brisée.
- Les Nornes : destin, fil du temps, mémoire.
- Yggdrasil : arbre du monde, axe cosmique, structure des plans.
- Ragnarök : destruction, accomplissement du destin, renaissance possible.
- Völuspá : vision prophétique du monde.
- Hávamál : sagesse, prudence, parole, hospitalité, connaissance.

## Thèmes profonds

Destin et libre arbitre  
Parole sacrée et mémoire orale  
Sacrifice pour obtenir la connaissance  
Courage face à une fin connue  
Lien entre monde humain, monde divin et monde souterrain  
Cycles de destruction et de renaissance  
Vision prophétique et responsabilité

## Garde-fous

Ne pas réduire l’Edda poétique à une imagerie “viking” décorative.

Ne pas confondre mythologie nordique, fantasy moderne et reconstitutions contemporaines.

Ne pas traiter le Ragnarök comme simple spectacle de destruction : c’est une structure cosmologique, poétique et morale.

Séparer :

- sources médiévales ;
- interprétations modernes ;
- réemplois fantasy ;
- usages créatifs ERITH.IA.

## Direction artistique

Matières : pierre froide, bois ancien, fer, neige, cendre, brume, feu bas, os, cuir, ciel gris.  
Lumière : aube glacée, crépuscule rouge, éclairs lointains, feu rituel.  
Architecture : halls de bois, pierres levées, racines géantes, ponts de brume, puits sacré.  
Ambiance : grave, prophétique, héroïque, austère, ancienne.

## Prompt image — base

Une scène mythologique nordique ancienne inspirée de l’Edda poétique, vaste arbre cosmique Yggdrasil traversant un ciel de brume, silhouettes de dieux et de voyantes autour d’un feu rituel, pierres gravées, neige légère, lumière froide, atmosphère prophétique, peinture épique ancienne, détails symboliques, composition cinématographique, sans référence à une franchise moderne.

## Prompt animation — base

Lent mouvement de caméra autour d’un feu rituel dans un paysage nordique ancien, brume froide, neige fine, racines d’un arbre cosmique qui vibrent doucement, runes lumineuses très subtiles, silhouettes immobiles, atmosphère prophétique, rythme lent, aucune action spectaculaire, continuité stable.

## Prompt négatif

fantasy moderne générique, armures exagérées, cornes sur les casques, cartoon, jeu vidéo identifiable, personnage de franchise, logo, texte, anachronisme, sursexualisation, violence gratuite, esthétique Marvel, cliché viking touristique.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter l’Edda poétique comme une source de mémoire mythologique nordique, de poésie prophétique et de sagesse fragmentaire. Le module doit aider à créer des scènes graves, anciennes, symboliques, liées au destin, aux dieux, aux héros, aux runes, à l’arbre du monde et au Ragnarök, sans copier de franchise moderne ni réduire la matière à une imagerie viking superficielle.

## Formule courte

Edda poétique = parole ancienne + destin + dieux nordiques + vision du monde qui brûle et renaît.
