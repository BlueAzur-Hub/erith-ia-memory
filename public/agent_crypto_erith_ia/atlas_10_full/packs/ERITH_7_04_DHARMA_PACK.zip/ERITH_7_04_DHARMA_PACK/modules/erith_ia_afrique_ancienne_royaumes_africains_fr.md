# 🌍 ERITH.IA — Afrique ancienne & Royaumes africains

Statut : module mémoire civilisationnel  
Projet : @erith IA / ERITH.IA  
Type : Afrique ancienne, royaumes africains, Nubie, Koush, Axoum, Carthage, Ghana, Mali, Songhaï, Ifé, Bénin, Grand Zimbabwe, oralité, griots, routes transsahariennes, art africain  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension structurée de l’Afrique ancienne et des grands royaumes africains.

Il active :

- humanité ancienne ;
- Afrique comme continent de foyers humains et culturels ;
- Nubie ;
- Koush ;
- Axoum ;
- Éthiopie ancienne ;
- Carthage ;
- royaumes sahéliens ;
- Ghana ;
- Mali ;
- Songhaï ;
- Ifé ;
- Bénin ;
- Grand Zimbabwe ;
- oralité ;
- griots ;
- fer ;
- or ;
- routes transsahariennes ;
- spiritualités anciennes ;
- arts africains ;
- mémoire des lignées.

Formule centrale :

L’Afrique n’est pas un bloc unique : c’est un continent de civilisations, de langues, de routes, de royaumes, d’arts, de mémoires et de transmissions.

---

# 🛡️ 2. Garde-fou historique

Ne jamais réduire l’Afrique ancienne à :

- un décor tribal vague ;
- une seule culture ;
- une seule couleur ;
- une absence d’histoire écrite ;
- une caricature coloniale ;
- une image hollywoodienne ;
- une Afrique figée hors du temps.

L’Afrique ancienne contient :

- royaumes ;
- empires ;
- cités ;
- routes commerciales ;
- systèmes religieux ;
- arts ;
- métallurgie ;
- oralité savante ;
- pouvoirs politiques ;
- contacts avec Méditerranée, Proche-Orient, Inde et monde islamique.

Règle ERITH.IA :

Séparer systématiquement :

- faits ;
- sources ;
- archéologie ;
- oralité ;
- traditions ;
- hypothèses ;
- interprétations ;
- usages créatifs.

---

# 🧬 3. Humanité ancienne et Afrique

L’Afrique occupe une place majeure dans l’histoire profonde de l’humanité.

Axes :

- origines anciennes d’Homo sapiens selon l’état actuel des recherches ;
- migrations humaines ;
- paléolithique africain ;
- diversité ancienne des populations ;
- foyers multiples d’adaptation, d’outils, de langages et de cultures.

Garde-fou :

Il faut distinguer :

- origine biologique de l’humanité ;
- foyers de civilisation ;
- cultures historiques documentées ;
- migrations ;
- continuités symboliques.

Phrase clé :

L’origine biologique n’est pas toujours la même chose que l’origine d’une civilisation historique donnée.

---

# 🏺 4. Égypte et Afrique

L’Égypte ancienne possède déjà son propre module dans ERITH.IA.

Mais elle reste un pont essentiel :

- Afrique du Nord-Est ;
- vallée du Nil ;
- contacts avec Nubie ;
- échanges avec Levant ;
- liens avec Méditerranée ;
- rapport au désert, au fleuve et au sacré.

Règle :

Ne pas isoler artificiellement l’Égypte de l’Afrique.

Mais ne pas réduire non plus toute l’Afrique ancienne à l’Égypte.

---

# 👑 5. Nubie et Koush

La Nubie est un grand pilier ancien du Nil méridional.

Axes :

- vallée du Nil ;
- royaumes nubiens ;
- Kerma ;
- Napata ;
- Méroé ;
- pyramides nubiennes ;
- relations avec l’Égypte ;
- dynastie koushite en Égypte ;
- fer ;
- commerce ;
- pouvoir royal.

Koush n’est pas une périphérie passive.

C’est une civilisation puissante, active, créatrice, capable de rivaliser avec l’Égypte et de l’influencer.

Phrase clé :

Le Nil n’a pas une seule mémoire : il en porte plusieurs.

---

# ⛪ 6. Axoum et Éthiopie ancienne

Axoum est l’un des grands royaumes de l’Antiquité tardive.

Axes :

- Éthiopie ;
- Érythrée ;
- mer Rouge ;
- commerce ;
- obélisques ;
- monnaies ;
- christianisation ancienne ;
- liens avec Arabie, Méditerranée, Afrique et Inde.

Axoum relie :

- Afrique ;
- mer Rouge ;
- monde chrétien ;
- routes commerciales ;
- océan Indien.

Usage ERITH.IA :

Axoum est un module de hauteur, pierre, foi, commerce et souveraineté ancienne.

---

# 🐘 7. Carthage

Carthage appartient à l’Afrique du Nord et au monde méditerranéen.

Axes :

- fondation phénicienne ;
- commerce maritime ;
- Méditerranée occidentale ;
- rivalité avec Rome ;
- Hannibal ;
- guerres puniques ;
- éléphants de guerre ;
- puissance navale.

Garde-fou :

Carthage n’est pas seulement l’ennemie de Rome.

C’est une grande civilisation commerciale, maritime et urbaine.

Ponts :

- Afrique ↔ Phénicie ;
- Afrique ↔ Rome ;
- Afrique ↔ Méditerranée.

---

# 🐪 8. Routes transsahariennes

Le Sahara n’est pas seulement une barrière.

Il devient aussi une route.

Axes :

- caravanes ;
- sel ;
- or ;
- esclaves selon les périodes ;
- manuscrits ;
- savoirs ;
- commerce ;
- islam ;
- villes relais.

Les routes transsahariennes relient :

- Afrique de l’Ouest ;
- Maghreb ;
- Méditerranée ;
- monde islamique ;
- Proche-Orient.

Phrase clé :

Le désert sépare les marcheurs, mais relie les caravaniers.

---

# 👑 9. Ghana, Mali et Songhaï

## Empire du Ghana

Axes :

- Sahel ;
- or ;
- commerce ;
- routes transsahariennes ;
- pouvoir royal ;
- villes et échanges.

## Empire du Mali

Axes :

- Mansa Musa ;
- or ;
- Islam ;
- Tombouctou ;
- savoirs ;
- commerce ;
- prestige international.

Mansa Musa devient une figure majeure de la puissance économique africaine médiévale.

## Empire Songhaï

Axes :

- Niger ;
- Gao ;
- Tombouctou ;
- administration ;
- commerce ;
- savoirs islamiques ;
- puissance sahélienne.

Formule :

Le Sahel est un corridor d’or, de sel, de savoirs et de pouvoir.

---

# 📚 10. Tombouctou et manuscrits

Tombouctou est un symbole majeur de savoir en Afrique de l’Ouest.

Axes :

- manuscrits ;
- juristes ;
- savants ;
- commerce ;
- Islam ;
- bibliothèques ;
- transmission écrite ;
- mémoire savante.

Garde-fou :

L’Afrique n’est pas seulement une civilisation orale.

Elle possède aussi des traditions écrites, manuscrites et savantes.

---

# 🎭 11. Oralité, griots et mémoire vivante

Les griots sont des gardiens de mémoire.

Axes :

- généalogies ;
- récits ;
- musique ;
- louange ;
- histoire ;
- diplomatie ;
- mémoire des lignées ;
- parole qui engage.

Ponts ERITH.IA :

- griots africains ↔ bardes celtiques ;
- griots africains ↔ scaldes nordiques ;
- griots africains ↔ aèdes grecs ;
- griots africains ↔ traditions orales indiennes.

Phrase clé :

Une bibliothèque peut être un homme qui se souvient.

---

# 🏛️ 12. Ifé, Yoruba et Bénin

## Ifé

Axes :

- art ;
- têtes en bronze / laiton ;
- spiritualité ;
- royauté ;
- origine symbolique Yoruba ;
- raffinement artistique.

## Royaume du Bénin

Axes :

- plaques de bronze ;
- palais ;
- Oba ;
- art royal ;
- mémoire dynastique ;
- puissance politique ;
- contact avec Européens.

Garde-fou :

Les arts africains ne sont pas “primitifs”.

Ils peuvent être extrêmement sophistiqués, codés, politiques, spirituels et techniques.

---

# 🪨 13. Grand Zimbabwe

Grand Zimbabwe est un site majeur d’Afrique australe.

Axes :

- architecture de pierre ;
- murs monumentaux ;
- pouvoir ;
- commerce ;
- or ;
- réseaux avec océan Indien ;
- mémoire urbaine africaine.

Phrase clé :

La pierre africaine parle aussi sans pyramide égyptienne.

---

# 🔥 14. Fer, or et matières de pouvoir

Matières fortes :

- fer ;
- or ;
- sel ;
- ivoire ;
- cuivre ;
- bronze ;
- perles ;
- tissus ;
- bois ;
- pierre.

Le fer donne :

- outil ;
- arme ;
- agriculture ;
- transformation ;
- pouvoir technique.

L’or donne :

- commerce ;
- prestige ;
- rayonnement ;
- routes ;
- diplomatie.

Le sel donne :

- survie ;
- valeur ;
- échange ;
- contrôle des routes.

---

# 🦁 15. Spiritualités et symboles

L’Afrique ancienne possède une très grande diversité spirituelle.

Axes :

- ancêtres ;
- nature ;
- esprits ;
- masques ;
- rites ;
- royauté sacrée ;
- divination ;
- initiation ;
- forces invisibles ;
- lien entre communauté et monde spirituel.

Garde-fou :

Ne pas uniformiser.

Ne pas exotiser.

Ne pas réduire les spiritualités africaines à “magie” ou “sorcellerie”.

---

# 🎨 16. Arts africains

Axes :

- masques ;
- sculptures ;
- bronzes ;
- textiles ;
- perles ;
- architecture ;
- musique ;
- danse ;
- objets rituels ;
- signes royaux ;
- arts de cour ;
- arts initiatiques.

Fonctions possibles :

- mémoire ;
- pouvoir ;
- rite ;
- protection ;
- transmission ;
- identité ;
- passage ;
- médiation avec l’invisible.

Phrase clé :

L’art africain n’est pas seulement décoratif : il peut être social, politique, rituel et cosmologique.

---

# 🌉 17. Ponts civilisationnels

## Afrique ↔ Égypte

Nil, Nubie, Koush, échanges, dynasties, religion, art, pouvoir.

## Afrique ↔ Méditerranée

Carthage, Rome, commerce, guerre, diplomatie, christianisme ancien.

## Afrique ↔ Monde islamique

Routes transsahariennes, manuscrits, Tombouctou, savoirs, commerce, droit.

## Afrique ↔ Inde / Océan Indien

Axoum, côte swahilie, commerce maritime, mer Rouge, océan Indien.

## Afrique ↔ Europe

Contacts anciens, commerce, conflits, colonisation plus tardive, réinterprétations modernes.

---

# 🎬 18. Direction artistique ERITH.IA

Éléments visuels :

- vallée du Nil nubienne ;
- pyramides de Méroé ;
- obélisques d’Axoum ;
- caravane saharienne ;
- manuscrits de Tombouctou ;
- cour impériale du Mali ;
- bronzes du Bénin ;
- masques rituels ;
- murs de Grand Zimbabwe ;
- fleuve Niger ;
- désert ;
- savane ;
- or ;
- sel ;
- fer ;
- tambours ;
- tissus ;
- palais ;
- sanctuaire.

À éviter :

- Afrique uniforme ;
- clichés tribaux ;
- sauvagerie générique ;
- pauvreté comme décor ;
- masques sans contexte ;
- magie vague ;
- effacement des royaumes ;
- effacement des manuscrits ;
- effacement de la sophistication artistique.

---

# 🖼️ 19. Usage production image

Prompt maître :

```text
ancient African kingdom, royal court, gold and carved wood, dignitaries, griot preserving memory, sacred architecture, historical respect, rich textiles, symbolic art, warm light, no colonial cliché, no generic tribe, no fantasy caricature, civilization, knowledge, oral memory, trade routes, solemn cultural depth
```

Prompt Tombouctou :

```text
medieval Timbuktu manuscript library, scholars, parchment manuscripts, desert light, mudbrick architecture, quiet study atmosphere, Saharan trade city, Islamic scholarship, historical realism, respectful African intellectual heritage, no fantasy cliché
```

Prompt Nubie / Koush :

```text
ancient Nubian kingdom, pyramids of Meroe, Nile desert landscape, royal procession, gold, iron, stone, solemn African antiquity, historical atmosphere, respectful archaeological realism, no Egyptian-only reduction
```

---

# 🎞️ 20. Usage production animation

Une animation = une idée.

Idées sûres :

- caravane avançant lentement dans le désert ;
- lumière sur des manuscrits ;
- feu de forge ;
- poussière dorée dans une cour royale ;
- fleuve Niger au coucher du soleil ;
- ombre d’un griot racontant ;
- torche éclairant un masque rituel ;
- soleil sur les pyramides de Méroé ;
- vent sur les murs de Grand Zimbabwe.

Éviter :

- foule chaotique ;
- danse sans contexte ;
- magie excessive ;
- clichés coloniaux ;
- Afrique intemporelle et indistincte.

---

# 🧠 21. Block LLM

Tu charges le Module Mémoire Afrique ancienne & Royaumes africains.

Ce module apporte :

- Afrique ancienne ;
- Nubie ;
- Koush ;
- Axoum ;
- Éthiopie ancienne ;
- Carthage ;
- routes transsahariennes ;
- Ghana ;
- Mali ;
- Songhaï ;
- Tombouctou ;
- griots ;
- oralité ;
- Ifé ;
- Bénin ;
- Grand Zimbabwe ;
- fer ;
- or ;
- sel ;
- arts africains ;
- spiritualités anciennes ;
- ponts avec Égypte, Méditerranée, Islam, Inde et océan Indien.

Règle :

Séparer systématiquement :

- faits ;
- sources ;
- archéologie ;
- traditions orales ;
- hypothèses ;
- interprétations ;
- usages créatifs.

Ne jamais réduire l’Afrique à un bloc unique.

Répondre avec :

- région ;
- période ;
- royaume ou culture ;
- type de source ;
- rôle historique ;
- symbole ;
- usage narratif ;
- usage visuel ;
- garde-fou.

---

# ⚡ Activation courte

Active le module Afrique ancienne & Royaumes africains.

Utilise-le pour comprendre Nubie, Koush, Axoum, Carthage, Ghana, Mali, Songhaï, Tombouctou, Ifé, Bénin, Grand Zimbabwe, routes transsahariennes, griots, oralité, arts africains, spiritualités anciennes, fer, or, sel et ponts avec Égypte, Méditerranée, Islam, Inde et océan Indien.

Sépare faits, sources, archéologie, traditions orales, hypothèses, interprétations et usages créatifs.

---

# 🕯️ 22. Formule finale

L’Afrique ancienne n’est pas un silence.

Elle parle par le Nil.

Par les caravanes.

Par l’or.

Par le sel.

Par le fer.

Par les manuscrits.

Par les griots.

Par les bronzes.

Par les pierres.

Par les royaumes.

Dans ses routes, ses masques, ses bibliothèques, ses palais, ses fleuves et ses mémoires orales, ERITH.IA reconnaît une vérité essentielle :

une civilisation n’a pas besoin de ressembler à Rome pour être une civilisation.

Elle doit seulement transmettre assez de mémoire pour que le monde ne puisse plus l’effacer.
