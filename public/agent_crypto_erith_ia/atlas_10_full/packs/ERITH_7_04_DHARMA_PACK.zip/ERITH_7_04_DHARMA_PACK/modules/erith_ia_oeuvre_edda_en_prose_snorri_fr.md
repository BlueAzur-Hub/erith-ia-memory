# ERITH.IA — Œuvre fondatrice — Edda en prose / Snorri

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Islande médiévale / monde nordique  
Auteur associé : Snorri Sturluson  
Fonction : fournir à ERITH.IA une base structurante sur la mise en forme médiévale des mythes nordiques.

L’Edda en prose est essentielle pour comprendre comment une partie majeure de la mythologie nordique a été organisée, expliquée et transmise par écrit.

## Rôle dans ERITH.IA

Ce module sert à :

- structurer la cosmologie nordique ;
- comprendre les récits des dieux dans une forme plus explicative ;
- relier poésie, mythologie et transmission savante ;
- distinguer source médiévale, pédagogie poétique et réinterprétation moderne ;
- donner à ERITH.IA un outil clair pour organiser les mythes du Nord.

## Axes principaux

Snorri Sturluson  
Gylfaginning  
Skáldskaparmál  
Háttatal  
Yggdrasil  
Ases et Vanes  
Jötunns  
Ragnarök  
kennings  
poésie scaldique  
transmission médiévale islandaise

## Figures et motifs majeurs

- Odin : souveraineté, savoir, poésie, mort, ruse.
- Thor : protection, force, affrontement contre les géants.
- Loki : désordre, ambiguïté, rupture de l’équilibre.
- Freyja : beauté, désir, guerre, magie.
- Freyr : fertilité, prospérité, souveraineté.
- Heimdall : seuil, vigilance, son de la fin.
- Yggdrasil : arbre cosmique, carte du monde.
- Les géants : altérité, forces primordiales, opposition et origine.
- Les kennings : métaphores poétiques codées, mémoire de la langue.

## Thèmes profonds

Transmission du mythe  
Organisation du chaos oral  
Mémoire écrite après la mémoire chantée  
Poésie comme technologie culturelle  
Langage codé et images mentales  
Cosmologie comme architecture narrative  
Survie des anciennes histoires dans un monde transformé

## Garde-fous

Ne pas traiter l’Edda en prose comme une photographie pure et directe des croyances anciennes.

Rappeler que le texte est médiéval, structurant, savant, et transmis dans un contexte chrétien islandais.

Ne pas confondre l’Edda en prose avec l’Edda poétique.

Ne pas transformer Snorri en simple “auteur fantasy” : son rôle est celui d’un passeur, organisateur, compilateur et théoricien de la poésie.

## Direction artistique

Ambiance : scriptorium nordique, manuscrits, encre, bois sombre, lumière froide, cartes cosmologiques, runes discrètes.  
Matières : parchemin, encre brune, bois noirci, fer ancien, laine, pierre.  
Lumière : chandelle, ciel d’hiver, bleu nocturne, reflets d’or faible.  
Style : érudit, ancien, structuré, presque architectural.

## Prompt image — base

Un scriptorium islandais médiéval, un manuscrit ouvert décrivant la cosmologie nordique, diagramme d’Yggdrasil tracé à l’encre, bougies faibles, bois sombre, neige visible par une fenêtre, atmosphère savante et mystique, détails de parchemin, style peinture historique cinématographique, sans texte lisible, sans référence moderne.

## Prompt animation — base

Caméra lente au-dessus d’un manuscrit ancien, lumière de bougie vacillante, traits d’encre formant subtilement un arbre cosmique, poussière dans l’air, neige silencieuse derrière la fenêtre, ambiance calme, savante, mystérieuse, mouvement minimal, continuité stable.

## Prompt négatif

fantasy générique, bibliothèque moderne, ordinateur, texte lisible, logo, franchise identifiable, style jeu vidéo, casques à cornes, surdramatisation, magie explosive, anachronisme.

## Block LLM

Quand ce module est activé, ERITH.IA doit utiliser l’Edda en prose comme une matrice d’organisation des mythes nordiques. Le module doit aider à clarifier les dieux, les récits, les structures cosmologiques, les kennings et la transmission médiévale, tout en distinguant source, interprétation et usage créatif.

## Formule courte

Edda en prose = la mythologie nordique organisée en architecture de langage, de poésie et de monde.
