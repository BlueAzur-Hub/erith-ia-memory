# ☀️ MODULE MÉMOIRE — ÉGYPTE ANCIENNE, RELIGION, ART & POUVOIR

## 🏺 ERITH.IA — Nil, Maât, Pharaon, Temples, Mort, Soleil, Lune et Mémoire de Pierre

Version : 1.0  
Usage : GitHub privé / Notion / Ollama / RAG / Seven Heaven / ERITH.IA  
Statut : module majeur — civilisation fondatrice  
Langue : français  
Fichier : modules/erith_ia_egypte_ancienne_religion_art_pouvoir_fr.md

---

# 🎯 Intention

Ce module augmente ERITH.IA avec une compréhension structurée de l’Égypte ancienne : histoire, religion, art, pouvoir, symboles, architecture, mort, mémoire et continuité.

L’Égypte ancienne n’est pas seulement une civilisation de pyramides.

Elle est une civilisation de l’ordre.

Elle organise :

- le Nil ;
- le calendrier ;
- le royaume ;
- les temples ;
- la mort ;
- les images ;
- les hiéroglyphes ;
- les dieux ;
- le pouvoir royal ;
- les cycles solaires ;
- les passages lunaires ;
- la mémoire monumentale.

Pour ERITH.IA, ce module est majeur car il relie directement :

- mémoire ;
- symbole ;
- architecture ;
- mort ;
- renaissance ;
- lumière ;
- royauté ;
- vérité ;
- transmission.

---

# ⚖️ Contrat épistémique

Toujours distinguer :

- Égypte prédynastique ;
- Ancien Empire ;
- Moyen Empire ;
- Nouvel Empire ;
- Basse Époque ;
- Égypte ptolémaïque ;
- Égypte romaine ;
- religion égyptienne ;
- mythe ;
- rite ;
- art ;
- propagande royale ;
- interprétation moderne ;
- correspondance civilisationnelle.

Méthode retenue :

**Faits observables d’abord.  
Correspondances documentées ensuite.  
Interprétation libre ensuite.**

ERITH.IA doit poser :

- noms ;
- lieux ;
- dynasties ;
- fonctions ;
- attributs ;
- objets ;
- textes ;
- fresques ;
- temples ;
- symboles ;
- correspondances ;
- usages créatifs.

Elle ne doit pas réduire l’Égypte à un décor exotique.

Elle ne doit pas effacer les ponts civilisationnels.

Elle ne doit pas transformer les ponts en slogans pauvres.

---

# 🌊 1. Le Nil — Axe vivant de l’Égypte

## 💧 Le fleuve

L’Égypte ancienne se développe autour du Nil.

Le Nil apporte :

- eau ;
- limon ;
- agriculture ;
- navigation ;
- calendrier ;
- fertilité ;
- richesse ;
- unité territoriale.

Sans le Nil, l’Égypte pharaonique n’aurait pas la même forme.

Le fleuve est à la fois :

- route ;
- source de vie ;
- axe sacré ;
- mémoire géographique ;
- colonne vertébrale politique.

## 🌾 Crue et calendrier

La crue annuelle du Nil structure le temps.

Elle permet :

- irrigation ;
- récoltes ;
- organisation administrative ;
- fiscalité ;
- rituels saisonniers.

Le calendrier égyptien est fortement lié aux cycles naturels, célestes et agricoles.

## 🧠 Leçon

En Égypte, la géographie devient théologie et politique.

Phrase clé :

**Le Nil n’est pas seulement un fleuve : c’est une horloge sacrée, une route royale et une matrice de civilisation.**

---

# 👑 2. Pharaon — Roi, médiateur et garant de l’ordre

## 🦅 Fonction royale

Le pharaon est plus qu’un chef politique.

Il est médiateur entre :

- dieux ;
- hommes ;
- terre ;
- ciel ;
- ordre ;
- chaos.

Il doit maintenir la Maât.

## ⚖️ Maât

Maât désigne :

- vérité ;
- justice ;
- ordre ;
- équilibre ;
- harmonie cosmique ;
- justesse du monde.

La Maât est l’un des concepts centraux de l’Égypte ancienne.

Elle n’est pas seulement morale.

Elle est cosmique.

## 🐍 Isfet

Isfet représente ce qui s’oppose à Maât :

- chaos ;
- désordre ;
- injustice ;
- mensonge ;
- rupture ;
- violence non maîtrisée.

## 🧠 Leçon

Le pouvoir égyptien se légitime par sa capacité à maintenir l’ordre cosmique.

Phrase clé :

**Un pharaon ne règne pas seulement sur des hommes : il doit empêcher le monde de retomber dans le chaos.**

---

# 🏺 3. Grandes périodes historiques

## 🐾 Égypte prédynastique

Avant l’unification, l’Égypte connaît des cultures régionales.

On y voit déjà :

- tombes ;
- objets rituels ;
- palettes ;
- symboles animaux ;
- élites locales ;
- premières formes de pouvoir.

## 👑 Unification

La tradition attribue l’unification de la Haute et de la Basse Égypte à Narmer / Ménès selon les cadres historiques et légendaires.

L’unification crée une image fondamentale :

**Deux Terres, un pouvoir.**

## 🏗️ Ancien Empire

L’Ancien Empire est marqué par :

- centralisation ;
- pyramides ;
- administration ;
- culte royal ;
- Saqqarah ;
- Gizeh ;
- pouvoir monumental.

Figures et lieux :

- Djéser ;
- Imhotep ;
- pyramide à degrés ;
- Khéops ;
- Khéphren ;
- Mykérinos ;
- Sphinx.

## ⚖️ Moyen Empire

Le Moyen Empire est souvent vu comme une période de réorganisation, de littérature, d’administration et de puissance renouvelée.

Il développe :

- contrôle territorial ;
- textes littéraires ;
- pouvoir royal restauré ;
- art plus intériorisé.

## ☀️ Nouvel Empire

Le Nouvel Empire est une période d’expansion et de prestige.

Figures majeures :

- Hatchepsout ;
- Thoutmosis III ;
- Amenhotep III ;
- Akhenaton ;
- Toutankhamon ;
- Ramsès II ;
- Ramsès III.

Le Nouvel Empire relie :

- armée ;
- diplomatie ;
- temples ;
- Amon ;
- Karnak ;
- Louxor ;
- Vallée des Rois.

## 🌘 Basse Époque, Ptolémées et Rome

L’Égypte connaît ensuite des dominations, recompositions et syncrétismes.

Périodes :

- Libyens ;
- Koushites ;
- Assyriens ;
- Perses ;
- Grecs ;
- Ptolémées ;
- Rome.

L’Égypte ne disparaît pas.

Elle se transforme et continue d’influencer les mondes méditerranéens.

## 🧠 Leçon

L’Égypte ancienne est une civilisation de très longue durée.

Phrase clé :

**L’Égypte ne se comprend pas en siècles, mais en millénaires.**

---

# ☀️ 4. Soleil, disque solaire et royauté cosmique

## 🌞 Rê / Ra

Rê est une grande divinité solaire.

Il représente :

- soleil ;
- lumière ;
- création ;
- cycle du jour ;
- souveraineté céleste ;
- renaissance quotidienne.

Le soleil meurt symboliquement chaque soir et renaît chaque matin.

Cette dynamique nourrit toute une pensée du passage, de la mort et du retour.

## ☀️ Disque solaire

Le disque solaire apparaît dans de nombreuses images.

Il peut signaler :

- puissance solaire ;
- présence divine ;
- protection ;
- royauté ;
- cycle cosmique ;
- lumière créatrice.

Le disque n’est pas un simple motif décoratif.

C’est un signe de puissance céleste.

## 🪽 Disque solaire ailé

Le disque solaire ailé est un symbole majeur.

Axes :

- protection ;
- ciel ;
- souveraineté ;
- horizon ;
- mouvement ;
- puissance divine ;
- seuils de temple.

Il apparaît souvent sur les temples et les monuments, comme signe protecteur et cosmique.

## 🌅 Aton

Aton désigne le disque solaire, particulièrement mis en avant sous Akhenaton.

Dans le contexte amarnien, le disque solaire devient central dans une réforme religieuse majeure.

Il faut distinguer :

- Rê ;
- Aton ;
- Amon-Rê ;
- théologie solaire traditionnelle ;
- expérience amarnienne.

## 🧠 Leçon

Le soleil égyptien n’est pas seulement lumière.

Il est cycle, pouvoir, regard, protection et renaissance.

Phrase clé :

**Le disque solaire est une image du pouvoir qui traverse le ciel, protège le temple et renouvelle le monde.**

---

# 🌙 5. Lune, disque lunaire et cycles cachés

## 🌒 La Lune dans l’Égypte ancienne

La Lune est moins dominante que le Soleil dans l’imaginaire populaire, mais elle est importante.

Elle est liée à :

- cycles ;
- mesure du temps ;
- régénération ;
- nuit ;
- savoir ;
- guérison ;
- passage ;
- calendrier.

## 🌙 Thot

Thot est associé à :

- écriture ;
- savoir ;
- mesure ;
- calcul ;
- lune ;
- scribes ;
- parole divine ;
- équilibre ;
- magie ;
- jugement.

Thot est une figure capitale pour ERITH.IA car il relie :

- écriture ;
- mémoire ;
- calcul ;
- lune ;
- archives ;
- parole juste.

## 🌙 Khonsou

Khonsou est une divinité lunaire importante.

Il est lié à :

- Lune ;
- temps ;
- voyage nocturne ;
- guérison ;
- protection.

## 🌗 Disque lunaire

Le disque lunaire apparaît dans certaines iconographies.

Il peut être porté ou associé à des divinités lunaires ou à des formes combinant cornes, croissant et disque.

Axes de lecture :

- cycle ;
- mesure ;
- nuit ;
- régénération ;
- passage ;
- lumière réfléchie ;
- rythme caché.

## 🧠 Leçon

Le Soleil montre le pouvoir visible du jour.

La Lune montre le rythme secret du temps.

Phrase clé :

**Le disque solaire éclaire le royaume ; le disque lunaire mesure les passages.**

---

# ⛩️ 6. Dieux majeurs et fonctions

## 🐏 Amon / Amon-Rê

Amon est une divinité majeure, particulièrement liée à Thèbes.

Avec Amon-Rê, il devient une puissance théologique immense.

Axes :

- caché ;
- souveraineté ;
- création ;
- royauté ;
- fusion solaire ;
- pouvoir théologico-politique.

Amon-Rê relie le dieu caché à la puissance solaire.

## 🛠️ Ptah

Ptah est une divinité majeure de Memphis.

Axes :

- création ;
- artisanat ;
- pensée ;
- parole ;
- formes ;
- bâtisseurs ;
- organisation du monde ;
- dieu créateur par le cœur et la langue selon traditions.

Ptah est essentiel pour les ponts civilisationnels avec les dieux civilisateurs et artisans.

## 🧬 Osiris

Osiris est associé à :

- mort ;
- renaissance ;
- royaume des morts ;
- végétation ;
- continuité ;
- jugement ;
- royauté défunte.

Il devient une figure majeure de l’espérance funéraire.

## 🪽 Isis

Isis est associée à :

- magie ;
- maternité ;
- protection ;
- royauté ;
- guérison ;
- reconstitution d’Osiris ;
- transmission ;
- pouvoir féminin.

Son culte dépasse largement l’Égypte dans le monde gréco-romain.

## 🦅 Horus

Horus est lié :

- au ciel ;
- au faucon ;
- à la royauté ;
- au pharaon vivant ;
- à la vengeance d’Osiris ;
- à la légitimité.

## 🐺 Anubis

Anubis est associé :

- à l’embaumement ;
- aux morts ;
- aux tombes ;
- à la protection funéraire ;
- à la conduite du défunt.

## 📜 Thot

Thot relie :

- écriture ;
- mesure ;
- savoir ;
- lune ;
- jugement ;
- parole.

## 🐈 Bastet

Bastet est associée :

- protection ;
- maison ;
- féminité ;
- douceur ;
- puissance féline ;
- musique ;
- joie selon contextes.

## 🦁 Sekhmet

Sekhmet est associée :

- lionne ;
- puissance solaire ;
- maladie ;
- guerre ;
- guérison ;
- colère divine.

## 🧠 Leçon

Les dieux égyptiens sont des puissances fonctionnelles, symboliques, locales et cosmiques.

Phrase clé :

**Un dieu égyptien n’est pas seulement une personne divine : c’est une fonction du monde.**

---

# ⚰️ 7. Mort, jugement et renaissance

## 🕯️ Mort comme passage

La mort en Égypte ancienne n’est pas une simple fin.

Elle est passage, transformation, risque et continuité.

Le défunt doit être préparé.

## 🧪 Momification

La momification vise à préserver le corps.

Elle soutient une pensée complexe du défunt :

- corps ;
- nom ;
- ombre ;
- ka ;
- ba ;
- cœur ;
- image ;
- tombe ;
- offrandes.

## ⚖️ Pesée du cœur

La pesée du cœur est une scène majeure.

Le cœur du défunt est pesé face à la plume de Maât.

Axes :

- vérité ;
- justice ;
- mémoire morale ;
- passage ;
- jugement ;
- ordre cosmique.

## 📖 Livre des Morts

Le Livre des Morts contient des formules destinées à aider le défunt dans l’au-delà.

Il n’est pas un “livre” unique au sens moderne.

C’est un ensemble de formules, traditions et compositions funéraires.

## 🧠 Leçon

L’Égypte fait de la mort une architecture de mémoire.

Phrase clé :

**Survivre, c’est garder son nom, son corps, son image, sa parole et sa vérité.**

---

# 🏛️ 8. Temples, pyramides et architecture sacrée

## 🔺 Pyramides

Les pyramides sont liées :

- au pouvoir royal ;
- au ciel ;
- à la montée ;
- au soleil ;
- à la tombe ;
- à la mémoire monumentale.

Elles ne sont pas seulement des tombeaux.

Elles sont des machines symboliques de permanence.

## 🛕 Temples

Le temple égyptien est :

- maison du dieu ;
- espace rituel ;
- lieu d’offrandes ;
- axe du monde ;
- archive ;
- instrument de pouvoir ;
- théâtre de la présence divine.

## 🌌 Orientation et cosmos

L’architecture égyptienne entretient des liens avec :

- astres ;
- horizon ;
- Nil ;
- cycles ;
- processions ;
- lumière ;
- axes.

## 🧠 Leçon

L’architecture égyptienne inscrit le royaume dans le cosmos.

Phrase clé :

**Le temple est une phrase de pierre adressée aux dieux.**

---

# 🎨 9. Art égyptien

## 👁️ Canon et frontalité

L’art égyptien suit des conventions puissantes.

Axes :

- profil ;
- frontalité partielle ;
- hiérarchie des tailles ;
- clarté symbolique ;
- stabilité ;
- continuité ;
- fonction rituelle.

L’objectif n’est pas seulement de représenter ce que l’œil voit.

Il est de rendre présent ce qui doit durer.

## 🖼️ Fresques et reliefs

Les images égyptiennes montrent :

- dieux ;
- pharaons ;
- offrandes ;
- funérailles ;
- scènes agricoles ;
- processions ;
- batailles ;
- rites ;
- passages.

## 🐍 Symboles majeurs

Symboles fréquents :

- ankh ;
- djed ;
- ouas ;
- œil oudjat ;
- scarabée ;
- lotus ;
- papyrus ;
- cobra uraeus ;
- vautour ;
- disque solaire ;
- barque solaire ;
- plume de Maât.

## 🧠 Leçon artistique

L’art égyptien est une technologie de présence.

Phrase clé :

**L’image égyptienne ne cherche pas seulement à être belle : elle cherche à faire durer.**

---

# 🔗 10. Ponts civilisationnels et correspondances

## 🌊 Enki / Ea / Ptah

Axes comparables :

- eau ou matière primordiale selon lectures ;
- sagesse ;
- artisanat ;
- création ;
- organisation du monde ;
- transmission technique ;
- fonction civilisatrice ;
- rapport aux bâtisseurs et aux savoirs.

Enki / Ea appartient à la Mésopotamie.

Ptah appartient à l’Égypte ancienne.

Le pont se fait par fonctions, attributs et rôle civilisateur.

## ⚡ Marduk / Amon / Amon-Rê

Axes comparables :

- souveraineté divine ;
- élévation théologique ;
- ordre cosmique ;
- victoire ou domination du chaos ;
- pouvoir royal ;
- centralité politique et religieuse ;
- dieu lié à une capitale ou à un centre religieux majeur ;
- montée en puissance dans un panthéon.

Marduk appartient à Babylone.

Amon / Amon-Rê appartient à l’Égypte ancienne.

Le pont se fait par fonction souveraine, rôle théologico-politique et puissance d’organisation cosmique.

## ☀️ Disque solaire et traditions solaires

Axes à observer :

- disque ;
- lumière ;
- royauté ;
- protection ;
- renaissance ;
- horizon ;
- cycle ;
- ciel ;
- regard divin.

Le disque solaire égyptien doit être étudié comme motif majeur de transmission symbolique.

## 🌙 Disque lunaire et traditions lunaires

Axes à observer :

- cycle ;
- mesure ;
- nuit ;
- temps ;
- passage ;
- régénération ;
- savoir ;
- calendrier.

Le disque lunaire doit être étudié dans ses relations avec Thot, Khonsou et les cycles.

## 🗝️ Isis et transmissions méditerranéennes

Isis est un cas majeur de diffusion religieuse.

Son culte se répand dans le monde gréco-romain.

Axes :

- mère ;
- magicienne ;
- protectrice ;
- reine ;
- guérisseuse ;
- navigatrice symbolique ;
- survivance de motifs dans des traditions ultérieures.

## 🏙️ Paris / Par Isis — tradition à documenter

La lecture “Paris = Par Isis” doit être archivée comme tradition ou hypothèse de correspondance à documenter.

Axes à noter :

- Isis ;
- diffusion du culte isiaque ;
- Gaule romaine ;
- traditions médiévales et modernes ;
- toponymie ;
- survivances symboliques ;
- récits alternatifs ou ésotériques ;
- nécessité de collecter les sources livresques.

ERITH.IA ne doit pas l’effacer.

ERITH.IA doit l’archiver comme piste à documenter par sources, auteurs, textes et correspondances.

## ⚖️ Règle de lecture

Ces ponts ne doivent pas être censurés.

Ils doivent être organisés.

La bonne méthode :

- poser les noms ;
- poser les fonctions ;
- poser les attributs ;
- poser les récits ;
- poser les objets ;
- poser les lieux ;
- poser les traditions de transmission ;
- laisser la comparaison travailler.

Phrase clé :

**L’Égypte n’est pas seulement une civilisation isolée : elle est une matrice de symboles qui traversent les âges.**

---

# 📚 11. Héritage mondial

L’Égypte ancienne influence ou nourrit :

- art méditerranéen ;
- monde grec ;
- monde romain ;
- cultes isiaques ;
- hermétisme ;
- alchimie ;
- architecture sacrée ;
- imaginaire royal ;
- symbolisme solaire ;
- symbolisme funéraire ;
- ésotérismes modernes ;
- archéologie ;
- littérature ;
- cinéma ;
- culture populaire.

Elle dialogue avec :

- Nubie ;
- Levant ;
- Mésopotamie ;
- monde égéen ;
- Perse ;
- Grèce ;
- Rome.

## 🧠 Leçon

L’Égypte est une civilisation de continuité et de transmission.

Elle survit dans ses pierres, ses images, ses dieux, ses objets, ses mythes et les rêves que les autres civilisations ont projetés sur elle.

Phrase clé :

**L’Égypte ancienne est morte comme État, mais elle n’a jamais cessé d’habiter l’imaginaire humain.**

---

# 🌸 12. Usage ERITH.IA

Applications possibles :

- temples solaires ;
- bibliothèques sacrées ;
- gardiens de tombe ;
- rites de passage ;
- pesée du cœur ;
- cités du Nil ;
- prêtres astronomes ;
- scribes lunaires ;
- disques solaires ;
- disques lunaires ;
- barques célestes ;
- pharaons déchus ;
- dieux cachés ;
- reines magiciennes ;
- symboles de renaissance ;
- architecture de mémoire.

## 🎨 Direction artistique

Mots-clés visuels :

- Nil ;
- papyrus ;
- lotus ;
- or ;
- lapis-lazuli ;
- turquoise ;
- sable ;
- pierre claire ;
- obélisque ;
- pylône ;
- hiéroglyphes ;
- disque solaire ;
- disque lunaire ;
- temple ;
- tombe ;
- barque solaire ;
- œil oudjat ;
- ankh ;
- plume ;
- scarabée.

## 🎬 Prompt animation

Mouvements adaptés :

- lumière solaire lente ;
- reflet sur le Nil ;
- poussière dorée ;
- hiéroglyphes qui s’illuminent ;
- barque glissant dans l’obscurité ;
- disque solaire levant ;
- disque lunaire traversant une fresque ;
- flamme d’huile ;
- ombre de colonnes ;
- pesée symbolique du cœur ;
- caméra lente et solennelle.

---

# 🛡️ 13. Erreurs fréquentes

- Réduire l’Égypte aux pyramides.
- Oublier Maât.
- Confondre Rê, Aton et Amon-Rê.
- Réduire Isis à une simple mère divine.
- Oublier le rôle de Ptah.
- Oublier Thot et la Lune.
- Oublier que l’art égyptien est fonctionnel et rituel.
- Lire les fresques seulement comme décoration.
- Effacer les ponts civilisationnels.
- Confondre pont symbolique et slogan.
- Refuser d’archiver les traditions de correspondance.
- Réduire l’Égypte à une civilisation “morte”.

---

# 🌐 14. Ressources Internet recommandées

Theban Mapping Project  
https://thebanmappingproject.com/

Digital Egypt for Universities  
https://www.ucl.ac.uk/museums-static/digitalegypt/

Louvre — Antiquités égyptiennes  
https://www.louvre.fr/

British Museum — Ancient Egypt  
https://www.britishmuseum.org/

Metropolitan Museum of Art — Egyptian Art  
https://www.metmuseum.org/

The Griffith Institute  
https://griffith.ox.ac.uk/

UCLA Encyclopedia of Egyptology  
https://escholarship.org/uc/nelc_uee

World History Encyclopedia — Ancient Egypt  
https://www.worldhistory.org/

Encyclopaedia Britannica — Ancient Egypt  
https://www.britannica.com/

Internet Archive  
https://archive.org/

Gallica — BnF  
https://gallica.bnf.fr/

---

# 🤖 15. BLOCK LLM — ÉGYPTE ANCIENNE, RELIGION, ART & POUVOIR

```text
Tu es autorisé à utiliser le module Égypte ancienne, Religion, Art & Pouvoir comme mémoire spécialisée ERITH.IA.

Quand le sujet concerne l’Égypte ancienne, le Nil, Pharaon, Maât, Rê, Amon, Amon-Rê, Ptah, Osiris, Isis, Horus, Anubis, Thot, Khonsou, les pyramides, les temples, les fresques, les hiéroglyphes, le disque solaire, le disque lunaire, la mort, la pesée du cœur, les tombes, les cultes isiaques ou les ponts avec la Mésopotamie, la Perse, la Grèce, Rome et les traditions ultérieures, tu dois :

1. distinguer période historique, mythe, rite, art, pouvoir et usage créatif ;
2. poser les faits observables : noms, lieux, textes, objets, fonctions, attributs ;
3. expliquer Maât comme ordre, vérité, justice et équilibre cosmique ;
4. intégrer le disque solaire comme signe de lumière, cycle, pouvoir, protection et renaissance ;
5. intégrer le disque lunaire comme signe de cycle, mesure, passage, nuit, savoir et régénération ;
6. intégrer Ptah comme figure de création, artisanat, pensée, parole et organisation du monde ;
7. intégrer Amon / Amon-Rê comme figure de souveraineté divine, théologie politique et puissance solaire ;
8. intégrer Isis comme figure de magie, protection, royauté, transmission et diffusion méditerranéenne ;
9. archiver les correspondances civilisationnelles sans les censurer ;
10. ne pas transformer les correspondances en slogans ;
11. relier l’Égypte aux trois piliers : Histoire mondiale, Histoire de l’Art, Religions & Mythologies ;
12. produire des usages créatifs originaux compatibles ERITH.IA.

Répondre avec :
- contexte ;
- période ;
- dynastie ou aire concernée ;
- sources ;
- figures majeures ;
- symboles ;
- art / architecture ;
- ponts civilisationnels ;
- usage ERITH.IA ;
- synthèse claire.
```

---

# ⚡ Activation courte

Active le module Égypte ancienne, Religion, Art & Pouvoir.

Utilise-le comme mémoire spécialisée sur le Nil, Maât, Pharaon, Rê, Amon, Amon-Rê, Ptah, Osiris, Isis, Horus, Thot, les disques solaires et lunaires, les temples, les tombes, les fresques, la mort, la renaissance et les ponts civilisationnels.

Pose les faits observables.

Archive les correspondances.

Laisse l’interprétation ouverte.

---

# 🕯️ Formule finale

L’Égypte ancienne a transformé le fleuve en calendrier, le roi en médiateur, le temple en cosmos, la tombe en passage et l’image en présence.

Elle a gravé la lumière dans la pierre.

Elle a donné une forme visible à la mort, à la justice, au soleil, à la lune et à la mémoire.

Et lorsque ses temples se sont tus, ses symboles ont continué de voyager.
