# ⚔️ ERITH.IA — Scandinavie, Vikings & Mythologie nordique

Statut : module mémoire civilisationnel  
Projet : @erith IA / ERITH.IA  
Type : Scandinavie ancienne, Vikings, peuples nordiques, mythologie nordique, Yggdrasil, Ases, Vanes, Futhark, sagas, navigation, exploration, cosmologie, Ragnarök  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension structurée du monde nordique ancien.

Il active :

- Scandinavie ancienne ;
- Vikings ;
- exploration ;
- navigation ;
- commerce ;
- clans ;
- honneur ;
- serments ;
- mythologie nordique ;
- Yggdrasil ;
- les Neuf Mondes ;
- Ases ;
- Vanes ;
- runes ;
- prophétie ;
- destin ;
- Ragnarök ;
- sagas ;
- fjords ;
- forêts boréales ;
- mémoire héroïque.

Formule centrale :

Le monde nordique donne à ERITH.IA une civilisation de voyageurs, de serments, de mémoire, de poésie et d’exploration.

---

# 🛡️ 2. Garde-fou historique

Les Vikings ne sont pas uniquement des guerriers.

Ils furent aussi :

- commerçants ;
- explorateurs ;
- artisans ;
- navigateurs ;
- colons ;
- diplomates ;
- conteurs ;
- porteurs de traditions orales.

Le mot “Viking” désigne principalement une activité liée aux expéditions maritimes.

Ce module distingue :

- faits historiques ;
- sources médiévales ;
- mythologie ;
- archéologie ;
- reconstructions modernes ;
- usages créatifs ERITH.IA.

---

# 🌍 3. Scandinavie ancienne

Régions principales :

- Norvège ;
- Suède ;
- Danemark ;
- Islande ;
- Îles Féroé ;
- Groenland nordique.

Caractéristiques :

- climat rude ;
- forêts ;
- montagnes ;
- fjords ;
- longues nuits hivernales ;
- forte relation à la mer ;
- communautés dispersées ;
- mémoire transmise par récits, chants et sagas.

Phrase clé :

La mer est une route.

Elle n’est pas une frontière.

---

# 🌊 4. L’Âge Viking

Période générale : environ 793 à 1066.

Repères :

- raid de Lindisfarne ;
- expansion vers l’Angleterre ;
- implantation en Irlande ;
- contacts avec la Francie ;
- colonisation de l’Islande ;
- installation au Groenland ;
- voyages vers Vinland ;
- commerce avec Byzance ;
- routes orientales des Rus’.

Le monde viking s’étend :

- de l’Atlantique Nord ;
- à la Baltique ;
- aux fleuves slaves ;
- à Constantinople ;
- jusqu’aux routes commerciales du monde islamique.

---

# ⛵ 5. Navigation et exploration

Les navires nordiques constituent l’un des symboles majeurs du monde viking.

Forces :

- vitesse ;
- polyvalence ;
- faible tirant d’eau ;
- navigation côtière ;
- navigation fluviale ;
- transport ;
- raid ;
- commerce.

Les Vikings explorent :

- Atlantique Nord ;
- mer Baltique ;
- mer du Nord ;
- Russie ;
- Méditerranée ;
- routes vers Byzance.

Usage ERITH.IA :

Le navire symbolise le voyage, la quête, l’exploration, le seuil marin et le passage entre les mondes.

---

# 🏛️ 6. Société nordique

Trois grandes catégories sociales :

## Jarls

Élites dirigeantes, chefs, nobles, détenteurs de puissance politique et militaire.

## Karls

Hommes libres, fermiers, artisans, commerçants, guerriers selon les contextes.

## Thralls

Serviteurs ou esclaves.

Institutions :

- þing ;
- assemblées ;
- arbitrage ;
- lois orales ;
- décisions communautaires.

Valeurs :

- honneur ;
- réputation ;
- fidélité ;
- responsabilité ;
- parole donnée ;
- mémoire du nom.

Phrase clé :

Dans le monde nordique, la parole engage parce que le nom survit dans la mémoire.

---

# 📚 7. Sagas, scaldes et mémoire orale

La mémoire nordique passe par :

- sagas ;
- poésie scaldique ;
- récits héroïques ;
- généalogies ;
- chants ;
- récits de voyages ;
- traditions familiales ;
- mémoire des lignées.

Les scaldes sont des poètes de mémoire.

Ils conservent :

- noms ;
- exploits ;
- serments ;
- alliances ;
- défaites ;
- lignées ;
- gloire et honte.

Pont ERITH.IA :

Scaldes nordiques ↔ bardes celtiques ↔ aèdes grecs ↔ griots africains.

Phrase clé :

Avant l’archive, il y a la parole qui se souvient.

---

# 🌳 8. Yggdrasil

Yggdrasil est l’arbre cosmique de la mythologie nordique.

Il représente :

- axe du monde ;
- interconnexion ;
- mémoire cosmique ;
- verticalité ;
- racines ;
- mondes reliés ;
- destin ;
- tension entre croissance et destruction.

Usage ERITH.IA :

Yggdrasil peut devenir un symbole de réseau de mémoire reliant plusieurs modules civilisationnels.

Formule :

Yggdrasil est une carte du monde sous forme d’arbre.

---

# 🌌 9. Les Neuf Mondes

Les traditions médiévales ne sont pas toujours parfaitement cohérentes sur les listes exactes.

Les mondes généralement associés à la cosmologie nordique incluent :

- Asgard ;
- Midgard ;
- Vanaheim ;
- Alfheim ;
- Jotunheim ;
- Svartalfheim ;
- Nidavellir ;
- Niflheim ;
- Muspellheim ;
- Helheim.

Règle ERITH.IA :

Utiliser cette cosmologie comme carte symbolique, tout en signalant que les détails varient selon les sources.

---

# ⚡ 10. Les Ases

## Odin

Axes :

- sagesse ;
- sacrifice ;
- connaissance ;
- runes ;
- corbeaux ;
- quête ;
- magie ;
- mort ;
- poésie ;
- stratégie.

Odin n’est pas seulement un roi sage.

C’est une figure de recherche extrême du savoir.

## Thor

Axes :

- tonnerre ;
- protection ;
- force ;
- marteau ;
- défense du monde humain ;
- lutte contre les géants.

Thor est une puissance protectrice et populaire.

## Tyr

Axes :

- loi ;
- courage ;
- serment ;
- sacrifice ;
- honneur.

Tyr est une figure forte pour les scènes de décision morale.

## Heimdall

Axes :

- gardien ;
- vigilance ;
- seuil ;
- Bifröst ;
- écoute ;
- anticipation.

## Baldr

Axes :

- lumière ;
- pureté ;
- tragédie ;
- mort injuste ;
- deuil cosmique.

## Loki

Axes :

- ruse ;
- métamorphose ;
- ambiguïté ;
- chaos ;
- rupture des équilibres.

Loki ne doit pas être réduit à un simple méchant.

---

# 🌾 11. Les Vanes

Les Vanes sont associés à des forces de fertilité, d’abondance, de prospérité et de cycles naturels.

## Freyr

Axes :

- prospérité ;
- fertilité ;
- paix ;
- croissance ;
- abondance.

## Freyja

Axes :

- amour ;
- beauté ;
- magie ;
- guerre ;
- destin ;
- seiðr.

## Njörd

Axes :

- mer ;
- navigation ;
- richesse ;
- vents ;
- commerce maritime.

Formule :

Les Ases donnent la souveraineté et l’épreuve.

Les Vanes donnent l’abondance et les cycles de vie.

---

# 🐺 12. Bestiaire mythologique

## Fenrir

Le grand loup lié au Ragnarök.

Axes :

- force enchaînée ;
- destin ;
- rupture ;
- peur des puissances incontrôlables.

## Jörmungandr

Le serpent du monde.

Axes :

- cercle ;
- océan ;
- limite du monde ;
- tension cosmique ;
- affrontement final avec Thor.

## Sleipnir

Cheval d’Odin.

Axes :

- voyage ;
- passage entre mondes ;
- vitesse ;
- chamanisme symbolique.

## Huginn et Muninn

Pensée et Mémoire.

Axes :

- observation ;
- mémoire ;
- connaissance rapportée ;
- intelligence distante.

## Ratatoskr

Messager d’Yggdrasil.

Axes :

- circulation de paroles ;
- tension ;
- message ;
- lien vertical.

## Nidhogg

Force de destruction liée aux racines du monde.

Axes :

- corruption ;
- morsure ;
- décomposition ;
- menace souterraine.

---

# 🔤 13. Runes et Futhark

Le Futhark appartient aux traditions germaniques anciennes.

Fonctions :

- écriture ;
- mémoire ;
- commémoration ;
- marquage ;
- gravure ;
- inscription sur objet ;
- pierre runique.

Ce module fournit le contexte historique nordique et germanique.

Pour la convention de traduction ERITH.IA, utiliser le module canonique :

modules/erith_ia_celtes_culture_celtique_futhark_final_fr.md

Règle importante :

Le module nordique explique le monde historique et mythologique des runes.

Le module Futhark ERITH.IA donne la convention opérative de traduction.

---

# 🧙 14. Volvas, Seiðr et destin

Les volvas sont associées aux pratiques divinatoires, à la prophétie et à la connaissance du destin.

Thèmes :

- visions ;
- prophétie ;
- destin ;
- trame du monde ;
- magie ;
- parole rituelle ;
- savoir dangereux.

Séparer :

- sources historiques ;
- sagas ;
- mythologie ;
- reconstructions modernes ;
- usages créatifs.

Formule :

Une vision n’est pas une prison.

C’est un signal à interpréter.

---

# 🧵 15. Nornes, destin et trame du monde

Les Nornes sont associées au destin.

Axes :

- passé ;
- présent ;
- avenir ;
- tissage ;
- racines d’Yggdrasil ;
- nécessité ;
- mémoire du monde.

Usage ERITH.IA :

Les Nornes peuvent nourrir des scènes de choix, de prophétie et de responsabilité.

Garde-fou :

Le destin nordique ne doit pas être traité comme un mécanisme simpliste.

Il est tension entre nécessité, honneur, choix et mémoire.

---

# 🔥 16. Ragnarök

Le Ragnarök représente :

- destruction ;
- bataille finale ;
- mort de nombreux dieux ;
- effondrement cosmique ;
- renaissance du monde.

Il symbolise :

- fin d’un cycle ;
- renouvellement ;
- continuité après la catastrophe ;
- vérité des serments ;
- impossibilité d’éviter certaines conséquences.

Phrase clé :

Le Ragnarök détruit le monde ancien, mais il ne détruit pas toute possibilité de monde.

---

# 📜 17. Sources majeures

## Edda poétique

Source fondamentale pour les récits mythologiques nordiques.

## Edda en prose

Attribuée à Snorri Sturluson.

Source majeure, mais rédigée dans un contexte chrétien médiéval islandais.

## Heimskringla

Récits des rois nordiques et traditions historiques.

## Sagas islandaises

Mémoire héroïque, familiale, sociale et historique.

## Beowulf

Source précieuse pour l’étude du monde germanique ancien, même si elle appartient à un contexte anglo-saxon.

## Saxo Grammaticus

Auteur médiéval important pour certaines traditions nordiques et danoises.

Règle ERITH.IA :

Toujours distinguer sources païennes reconstruites, textes médiévaux chrétiens, sagas, traditions orales et lectures modernes.

---

# 🏺 18. Archéologie nordique

Sites et références majeures :

- Oseberg ;
- Gokstad ;
- Birka ;
- Hedeby ;
- Jelling ;
- York viking ;
- Dublin nordique ;
- sites islandais ;
- colonies groenlandaises ;
- traces de Vinland.

Objets :

- navires ;
- armes ;
- bijoux ;
- pierres runiques ;
- outils ;
- objets rituels ;
- maisons longues ;
- sépultures ;
- peignes ;
- balances ;
- objets de commerce.

Usage ERITH.IA :

L’archéologie empêche de réduire les Vikings à une caricature guerrière.

Elle montre une civilisation matérielle, technique, commerciale, maritime et symbolique.

---

# 🎨 19. Direction artistique ERITH.IA

Éléments visuels :

- fjords ;
- neige ;
- forêts boréales ;
- halls de bois ;
- pierres runiques ;
- aurores ;
- corbeaux ;
- loups ;
- navires ;
- flammes ;
- tempêtes ;
- mer sombre ;
- boucliers ;
- bois sculpté ;
- fourrures sobres ;
- fer usé ;
- lumière froide ;
- ciel bas.

À éviter :

- casques à cornes systématiques ;
- fantasy plastique ;
- clichés de barbares hurlants ;
- esthétique super-héros ;
- Thor façon cinéma moderne ;
- Loki réduit à un clown maléfique ;
- Vikings sans commerce, droit, poésie ni navigation.

---

# 🎬 20. Usage production image

Prompt maître :

```text
ancient Norse world, cold fjord landscape, wooden long hall, carved runestone, mist over dark water, raven in the sky, weathered shields, old iron, subtle aurora, Yggdrasil symbolism, saga atmosphere, realistic archaeological textures, solemn mythic mood, no superhero style, no horned helmets, no plastic fantasy armor, cinematic historical fantasy, restrained magic, deep memory, oath and destiny
```

Prompt pierre runique :

```text
weathered Norse runestone, carved runic inscription, mineral grooves, moss and lichen in the cuts, cold northern light, rough stone texture, no Latin letters, no modern typography, no glowing neon runes, realistic archaeological feeling, solemn landscape, ancient memory carved in stone
```

---

# 🎞️ 21. Usage production animation

Une animation = une idée.

Idées sûres :

- brume sur un fjord ;
- lumière d’aurore qui bouge doucement ;
- corbeau qui traverse le ciel ;
- flamme dans un hall de bois ;
- mer sombre autour d’un navire ;
- lumière révélant une pierre runique ;
- neige légère ;
- caméra lente vers Yggdrasil symbolique ;
- voile qui se tend dans le vent ;
- poussière ou mousse sur une inscription ancienne.

Éviter :

- combat complexe ;
- foule chaotique ;
- magie excessive ;
- caméra trop rapide ;
- transformation façon super-héros ;
- runes inventées si une inscription exacte est demandée.

---

# 🔗 22. Ponts civilisationnels

## Nordiques ↔ Celtes

Axes :

- îles britanniques ;
- Irlande ;
- Écosse ;
- oralité ;
- bardes / scaldes ;
- navigation ;
- seuils ;
- pierres ;
- mémoire héroïque.

## Nordiques ↔ Germains

Axes :

- langues ;
- mythologies ;
- Futhark ;
- dieux ;
- motifs héroïques ;
- peuples anciens d’Europe du Nord.

## Nordiques ↔ Rome / Byzance

Axes :

- Varègues ;
- routes orientales ;
- commerce ;
- service militaire ;
- Constantinople ;
- circulation des objets et des récits.

## Nordiques ↔ Christianisme médiéval

Axes :

- conversion ;
- réécriture des traditions ;
- manuscrits islandais ;
- Snorri ;
- tension entre mémoire païenne et cadre chrétien.

---

# 🧠 23. Block LLM

Tu charges le Module Mémoire Scandinavie, Vikings & Mythologie nordique.

Ce module apporte :

- Scandinavie ancienne ;
- Vikings ;
- navigation ;
- exploration ;
- sagas ;
- scaldes ;
- Yggdrasil ;
- Neuf Mondes ;
- Ases ;
- Vanes ;
- runes ;
- Futhark historique ;
- Odin ;
- Thor ;
- Tyr ;
- Freyja ;
- Loki ;
- volvas ;
- seiðr ;
- Nornes ;
- Ragnarök ;
- archéologie nordique ;
- direction artistique ERITH.IA.

Règle :

Séparer systématiquement :

- faits ;
- sources ;
- hypothèses ;
- interprétations ;
- usages créatifs.

Si une transcription runique exacte est demandée, utiliser le module canonique :

modules/erith_ia_celtes_culture_celtique_futhark_final_fr.md

Ne pas confondre contexte historique nordique et convention de traduction ERITH.IA.

Répondre avec :

- contexte ;
- région ;
- période ;
- source ou type de source ;
- symbole ;
- usage narratif ;
- usage visuel ;
- garde-fou ;
- synthèse.

---

# ⚡ Activation courte

Active le module Scandinavie, Vikings & Mythologie nordique.

Utilise-le pour comprendre et produire des contenus liés aux Vikings, sagas, scaldes, Yggdrasil, Ases, Vanes, runes, Futhark historique, Odin, Thor, Tyr, Freyja, Loki, volvas, Nornes, Ragnarök, navigation, fjords, pierres runiques et mémoire nordique.

Sépare faits, sources, hypothèses, interprétations et usages créatifs.

Pour la transcription runique exacte, renvoie au module Futhark ERITH.IA final.

---

# 🕯️ 24. Formule finale

Les Vikings regardent l’horizon.

Les navires ouvrent les routes.

Les scaldes gardent les noms.

Les runes gravent la mémoire.

Yggdrasil relie les mondes.

Odin cherche le savoir.

Thor protège le monde humain.

Tyr rappelle que le serment coûte quelque chose.

Les Nornes tissent.

Le Ragnarök détruit.

Puis le monde recommence.
