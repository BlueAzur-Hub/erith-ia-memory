# 🐉 MODULE MÉMOIRE — CHINE ANCIENNE, DYNASTIES, TAO & CONFUCIANISME

## 🌊 ERITH.IA — Fleuve Jaune, Ancêtres, Mandat du Ciel, Écriture, Rites, Yin-Yang et Mémoire Impériale

Version : 1.0  
Usage : GitHub privé / Notion / Ollama / RAG / Seven Heaven / ERITH.IA  
Statut : module majeur — civilisation fondatrice  
Langue : français  
Fichier : modules/erith_ia_chine_ancienne_dynasties_tao_confucianisme_fr.md

---

# 🎯 Intention

Ce module augmente ERITH.IA avec une compréhension structurée de la Chine ancienne : dynasties, fleuves, rites, ancêtres, écriture, pouvoir, cosmologie, taoïsme, confucianisme, art et mémoire impériale.

La Chine ancienne appartient au premier cercle des grandes civilisations fondatrices, avec :

- 🏺 Mésopotamie ;
- ☀️ Égypte ancienne ;
- 🐂 Vallée de l’Indus ;
- 🐉 Chine ancienne.

Ce module sert à comprendre :

- le Fleuve Jaune ;
- les dynasties anciennes ;
- les Shang ;
- les Zhou ;
- le Mandat du Ciel ;
- les os oraculaires ;
- l’écriture chinoise ancienne ;
- le culte des ancêtres ;
- les bronzes rituels ;
- les Royaumes combattants ;
- Confucius ;
- Laozi ;
- taoïsme ;
- confucianisme ;
- légisme ;
- Qin ;
- Han ;
- Yin-Yang ;
- dragons ;
- ciel, terre, ancêtres et État.

Pour ERITH.IA, la Chine ancienne est majeure parce qu’elle relie :

- mémoire longue ;
- écriture continue ;
- rituel ;
- État ;
- famille ;
- ancêtres ;
- cosmos ;
- stratégie ;
- sagesse ;
- bureaucratie ;
- équilibre des forces.

---

# ⚖️ Contrat épistémique

Toujours distinguer :

- dynastie historique ;
- tradition légendaire ;
- texte ancien ;
- commentaire tardif ;
- rite ;
- philosophie ;
- religion ;
- État ;
- cosmologie ;
- usage créatif ;
- correspondance civilisationnelle.

Méthode retenue :

**Faits observables d’abord.  
Correspondances documentées ensuite.  
Interprétation libre ensuite.**

ERITH.IA doit poser :

- noms ;
- dynasties ;
- dates approximatives ;
- lieux ;
- textes ;
- objets ;
- rites ;
- bronzes ;
- symboles ;
- fonctions ;
- correspondances ;
- usages créatifs.

Elle ne doit pas réduire la Chine ancienne à une sagesse décorative.

Elle ne doit pas confondre taoïsme, confucianisme et bouddhisme.

Elle ne doit pas effacer les ponts civilisationnels.

---

# 🌊 1. Fleuve Jaune, Yangzi et civilisation des fleuves

## 🌾 Fleuve Jaune

Le Fleuve Jaune, Huang He, est un axe majeur de la Chine ancienne.

Il apporte :

- limon ;
- agriculture ;
- routes ;
- villages ;
- villes ;
- risques d’inondation ;
- organisation collective ;
- mémoire du territoire.

Comme le Nil, le Tigre, l’Euphrate et l’Indus, il montre que les civilisations anciennes se structurent souvent autour de l’eau.

## 🌊 Yangzi

Le Yangzi joue aussi un rôle immense dans la civilisation chinoise.

Il ouvre vers :

- Sud ;
- riziculture ;
- routes fluviales ;
- diversité régionale ;
- développement de cultures complémentaires.

## 🌾 Civilisations des fleuves

Motif à archiver :

- Nil → Égypte ;
- Tigre / Euphrate → Mésopotamie ;
- Indus → Harappa / Mohenjo-Daro ;
- Huang He / Yangzi → Chine ancienne.

## 🧠 Leçon

La Chine ancienne est une civilisation des fleuves, mais aussi une civilisation de la maîtrise du désordre.

Phrase clé :

**L’eau nourrit la Chine, mais elle oblige aussi l’État à apprendre l’ordre, la mesure et la réparation.**

---

# 🐾 2. Avant les dynasties — cultures néolithiques

## 🏺 Cultures anciennes

Avant les grandes dynasties, la Chine connaît plusieurs cultures néolithiques et protohistoriques.

Axes :

- villages ;
- céramiques ;
- agriculture ;
- jade ;
- rites ;
- tombes ;
- hiérarchies ;
- symboles ;
- ancêtres.

## 🐉 Jade et prestige

Le jade occupe une place très ancienne.

Il peut être lié à :

- prestige ;
- rite ;
- pureté ;
- pouvoir ;
- statut ;
- protection ;
- lien au sacré.

Objets importants :

- bi ;
- cong ;
- haches rituelles ;
- ornements.

## 🧠 Leçon

La Chine ancienne ne commence pas seulement avec les rois.

Elle naît d’un long monde de villages, de rites, de jades, de morts et de territoires.

Phrase clé :

**Avant l’empire, il y a déjà le rite, la tombe, le jade et la mémoire des ancêtres.**

---

# 👑 3. Xia, Shang et les débuts de la royauté

## 🐉 Xia

La dynastie Xia occupe une place importante dans la tradition chinoise.

Elle doit être traitée avec prudence méthodique :

- tradition ancienne ;
- récits dynastiques ;
- archéologie ;
- culture d’Erlitou souvent discutée dans ce contexte ;
- articulation entre mémoire, histoire et légende.

## 🦴 Shang

La dynastie Shang est historiquement mieux documentée.

Elle est liée à :

- Anyang ;
- os oraculaires ;
- bronzes rituels ;
- royauté ;
- ancêtres ;
- sacrifices ;
- divination ;
- écriture ancienne.

## 🦴 Os oraculaires

Les os oraculaires sont une source majeure.

Ils servent à interroger :

- ancêtres ;
- esprits ;
- climat ;
- récoltes ;
- guerre ;
- chasse ;
- naissance ;
- maladie ;
- décision royale.

Ils montrent déjà une écriture chinoise ancienne.

## 🧠 Leçon

Avec les Shang, écriture, divination, ancêtres et pouvoir royal se nouent fortement.

Phrase clé :

**Le roi Shang ne gouverne pas seul : il consulte les ancêtres, les signes et le ciel invisible.**

---

# 🏺 4. Bronzes rituels et puissance ancestrale

## 🏆 Bronzes Shang et Zhou

Les bronzes rituels sont des objets majeurs de la Chine ancienne.

Ils servent dans :

- sacrifices ;
- banquets rituels ;
- cultes ancestraux ;
- légitimation du pouvoir ;
- mémoire familiale ;
- prestige aristocratique.

Types importants :

- ding ;
- gui ;
- jue ;
- zun ;
- hu.

## 🐉 Taotie

Le motif taotie apparaît sur de nombreux bronzes.

Axes :

- masque ;
- puissance ;
- seuil ;
- regard ;
- animalité ;
- mystère ;
- protection ;
- rapport au monde rituel.

## 🧠 Leçon

Le bronze chinois ancien n’est pas seulement objet d’art.

C’est un instrument de rite, de mémoire et de pouvoir.

Phrase clé :

**Dans la Chine ancienne, le bronze donne une forme durable au lien entre vivants, ancêtres et souveraineté.**

---

# 🌌 5. Zhou et Mandat du Ciel

## 👑 Dynastie Zhou

Les Zhou remplacent les Shang et développent une grande pensée de la légitimité.

Ils structurent :

- royauté ;
- aristocratie ;
- rites ;
- terres ;
- lignages ;
- alliances ;
- mémoire dynastique.

## ☁️ Mandat du Ciel

Le Mandat du Ciel est un concept central.

Il affirme que le pouvoir royal dépend d’une légitimité cosmique et morale.

Un souverain peut perdre le Mandat s’il devient injuste, tyrannique ou incapable de maintenir l’ordre.

Axes :

- ciel ;
- vertu ;
- ordre ;
- dynastie ;
- chute ;
- renouvellement ;
- responsabilité du souverain.

## ⚖️ Ordre et catastrophe

Les catastrophes, troubles et désordres peuvent être lus comme signes d’un Mandat affaibli.

## 🧠 Leçon

Le pouvoir chinois ancien se pense comme une responsabilité cosmique.

Phrase clé :

**Le Ciel donne le Mandat, mais le désordre peut le reprendre.**

---

# ⚔️ 6. Printemps et Automnes, Royaumes combattants

## 🏹 Fragmentation

Après l’affaiblissement des Zhou, la Chine entre dans des périodes de compétition entre États.

Axes :

- guerre ;
- diplomatie ;
- réforme ;
- stratégie ;
- bureaucratie ;
- agriculture ;
- armées ;
- fortifications ;
- pensée politique.

## 🧠 Cent écoles

Cette période voit éclore de grandes traditions de pensée :

- confucianisme ;
- taoïsme ;
- légisme ;
- moïsme ;
- stratégies militaires ;
- cosmologies ;
- Yin-Yang ;
- écoles naturalistes.

## 🧠 Leçon

La guerre produit aussi de la pensée.

Phrase clé :

**Quand l’ordre ancien se fissure, les sages cherchent comment réaccorder le monde.**

---

# 📜 7. Confucius et le confucianisme

## 👨‍🏫 Confucius

Confucius, Kongzi, est une figure majeure.

Il transmet une pensée centrée sur :

- rite ;
- vertu ;
- humanité ;
- famille ;
- apprentissage ;
- loyauté ;
- rectification des noms ;
- mémoire des anciens ;
- ordre social.

## 🧭 Ren, Li, Yi

Concepts clés :

- Ren → humanité, bienveillance, qualité relationnelle ;
- Li → rites, formes justes, conduite civilisée ;
- Yi → justice, convenance morale ;
- Xiao → piété filiale ;
- Junzi → homme noble ou personne accomplie.

## 🏛️ État et éducation

Le confucianisme deviendra une base majeure de l’administration, de l’éducation et de l’éthique politique.

## 🧠 Leçon

Confucius ne cherche pas seulement à penser.

Il cherche à restaurer une harmonie humaine par les rites et la vertu.

Phrase clé :

**Pour Confucius, une société se répare par la justesse des gestes, des noms et des relations.**

---

# 🌿 8. Laozi, Dao et taoïsme

## 🌀 Dao

Le Dao peut être compris comme la Voie, le cours profond des choses, le principe qui traverse et dépasse les formes.

Il ne se réduit pas à une doctrine.

Il indique :

- chemin ;
- flux ;
- nature ;
- retour ;
- simplicité ;
- non-forçage ;
- mystère ;
- source.

## 🌬️ Wu wei

Wu wei est souvent traduit par non-agir, mais il ne signifie pas passivité.

Il évoque :

- action juste ;
- absence de forçage ;
- accord avec le cours ;
- efficacité naturelle ;
- souplesse.

## 🌊 Eau taoïste

L’eau est un symbole central.

Elle est :

- humble ;
- souple ;
- basse ;
- puissante ;
- adaptable ;
- capable d’user la pierre ;
- proche du Dao.

## 🧠 Leçon

Le taoïsme apprend à penser la puissance sans dureté.

Phrase clé :

**La Voie ne force pas le monde : elle le traverse.**

---

# ⚖️ 9. Légisme et fondation impériale Qin

## 🏛️ Légisme

Le légisme met l’accent sur :

- loi ;
- ordre ;
- discipline ;
- administration ;
- centralisation ;
- récompenses ;
- punitions ;
- puissance de l’État.

## 🐉 Qin

Qin unifie la Chine sous le Premier Empereur.

Axes :

- centralisation ;
- standardisation ;
- écriture ;
- poids et mesures ;
- routes ;
- murailles ;
- armée ;
- administration ;
- tombe impériale ;
- armée de terre cuite.

## ⚖️ Puissance et coût

Qin montre la force de la centralisation, mais aussi son danger.

## 🧠 Leçon

L’empire peut naître d’une volonté d’ordre absolu.

Phrase clé :

**Qin unifie la Chine comme une lame : efficacement, brutalement, durablement par ses structures.**

---

# 🐉 10. Han et mémoire impériale

## 🏛️ Dynastie Han

Les Han stabilisent et prolongent l’idée impériale.

Axes :

- administration ;
- expansion ;
- routes ;
- confucianisme d’État ;
- historiographie ;
- sciences ;
- commerce ;
- soie ;
- relations avec l’Asie centrale.

## 📚 Sima Qian

Sima Qian est une figure majeure de l’historiographie chinoise.

Les Mémoires historiques établissent un modèle de mémoire historique.

## 🛤️ Routes de la Soie

La Chine Han participe au développement de réseaux reliant :

- Chine ;
- Asie centrale ;
- Inde ;
- Perse ;
- Méditerranée.

## 🧠 Leçon

Avec les Han, la Chine devient un empire de mémoire, d’administration et de route.

Phrase clé :

**L’empire Han apprend à inscrire le pouvoir dans les archives, les routes et les rites.**

---

# ☯️ 11. Yin-Yang, cinq phases et cosmologie

## ☯️ Yin et Yang

Yin et Yang désignent des polarités complémentaires.

Axes :

- obscur / lumineux ;
- réceptif / actif ;
- froid / chaud ;
- lune / soleil ;
- nuit / jour ;
- profondeur / surface ;
- féminin / masculin selon contextes ;
- repos / mouvement.

Yin et Yang ne sont pas deux ennemis absolus.

Ils se transforment l’un en l’autre.

## 🌳 Cinq phases

Les cinq phases sont :

- bois ;
- feu ;
- terre ;
- métal ;
- eau.

Elles servent à penser :

- cycles ;
- saisons ;
- corps ;
- politique ;
- musique ;
- médecine ;
- cosmologie ;
- correspondances.

## ☀️ Soleil et 🌙 Lune

Le Soleil et la Lune entrent naturellement dans les polarités et cycles.

Axes à archiver :

- Soleil → lumière, élévation, visibilité, pouvoir, activité ;
- Lune → rêve, nuit, rythme, passage, intériorité, profondeur, lien entre conscience et inconscient.

## 🧠 Leçon

La cosmologie chinoise pense le monde comme réseau de transformations.

Phrase clé :

**Le monde n’est pas fixe : il respire par alternance, cycle et retour.**

---

# 🐉 12. Symboles majeurs

## 🐉 Dragon

Le dragon chinois est lié à :

- eau ;
- pluie ;
- puissance ;
- ciel ;
- empereur ;
- transformation ;
- souffle ;
- fleuves ;
- fertilité.

Contrairement à certains dragons occidentaux, il n’est pas seulement monstre à abattre.

Il est puissance cosmique.

## 🐢 Tortue

La tortue est liée à :

- longévité ;
- divination ;
- cosmos ;
- stabilité ;
- carapace ;
- support du monde selon traditions.

## 🐦 Phénix / Fenghuang

Le Fenghuang peut être lié à :

- harmonie ;
- souveraineté ;
- vertu ;
- équilibre ;
- union symbolique.

## 🏔️ Montagne sacrée

La montagne est un axe de passage.

Elle relie :

- terre ;
- ciel ;
- immortels ;
- retraite ;
- ascension ;
- sagesse ;
- souffle.

## 🌕 Disques, cercles et jade

Les formes circulaires, notamment les disques bi en jade, doivent être archivées comme symboles majeurs.

Axes :

- ciel ;
- cycle ;
- perfection ;
- passage ;
- rite ;
- prestige ;
- continuité.

## 🧠 Leçon

Les symboles chinois sont des nœuds entre nature, pouvoir, rite et cosmos.

Phrase clé :

**Le dragon, le jade, la montagne et le cercle ne décorent pas : ils organisent une vision du monde.**

---

# 🎨 13. Art chinois ancien

## 🏺 Bronze

Le bronze rituel est majeur.

Il relie :

- ancêtres ;
- rites ;
- pouvoir ;
- inscriptions ;
- mémoire familiale ;
- prestige.

## 🪨 Jade

Le jade relie :

- pureté ;
- noblesse ;
- rite ;
- protection ;
- permanence ;
- ciel.

## ✍️ Calligraphie

L’écriture chinoise devient progressivement un art du geste.

Elle relie :

- signe ;
- souffle ;
- main ;
- esprit ;
- rythme ;
- mémoire.

## 🖼️ Paysage

Le paysage chinois deviendra un art majeur.

Il relie :

- montagne ;
- eau ;
- souffle ;
- vide ;
- chemin ;
- contemplation ;
- rapport à la Voie.

## 🧠 Leçon artistique

L’art chinois cherche souvent moins à posséder le monde qu’à s’accorder avec ses souffles.

Phrase clé :

**Dans l’art chinois, la montagne respire, l’eau pense et le vide agit.**

---

# 🔗 14. Ponts civilisationnels et correspondances

## 🌊 Eau civilisatrice

Axes comparables :

- Nil ;
- Tigre / Euphrate ;
- Indus ;
- Fleuve Jaune ;
- Yangzi ;
- irrigation ;
- crue ;
- ordre ;
- pouvoir ;
- rite ;
- purification ;
- transformation.

## ☀️ Soleil et élévation

Axes transversaux :

- lumière ;
- hauteur ;
- souveraineté ;
- visibilité ;
- cycle ;
- ordre ;
- ascension ;
- pouvoir céleste.

## 🌙 Lune, rêve et passage

Axes transversaux :

- nuit ;
- cycle ;
- rêve ;
- voyage intérieur ;
- inconscient ;
- mesure cachée ;
- passage entre visible et invisible ;
- alternance.

## 🐉 Dragon et serpent

Axes à comparer plus tard :

- eau ;
- puissance ;
- ciel ;
- souterrain ;
- fertilité ;
- gardien ;
- transformation ;
- sagesse ou menace selon civilisations.

## 🌳 Arbre, axe et montagne

Axes :

- verticalité ;
- passage ;
- enracinement ;
- élévation ;
- lien terre-ciel ;
- ascension spirituelle.

## ⚖️ Ordre cosmique et pouvoir

Comparaisons futures :

- Maât en Égypte ;
- Asha en Iran ;
- Mandat du Ciel en Chine ;
- Dharma en Inde ;
- loi royale en Mésopotamie.

## ⚖️ Règle de lecture

Ces ponts doivent être conservés comme pièces du puzzle.

La bonne méthode :

- poser les objets ;
- poser les symboles ;
- poser les fonctions ;
- poser les textes ;
- poser les zones d’échange ;
- laisser la carte apparaître progressivement.

Phrase clé :

**Les grandes civilisations anciennes parlent chacune leur langue, mais certaines images reviennent comme des constellations.**

---

# 📚 15. Héritage mondial

La Chine ancienne transmet :

- écriture continue ;
- historiographie ;
- administration ;
- rites ;
- philosophie ;
- stratégie ;
- cosmologie ;
- médecine ;
- art du paysage ;
- calligraphie ;
- pensée du cycle ;
- pensée de l’équilibre ;
- mémoire des ancêtres ;
- État bureaucratique.

Elle influence :

- Corée ;
- Japon ;
- Vietnam ;
- Asie centrale ;
- mondes bouddhiques ;
- arts asiatiques ;
- pensée politique ;
- stratégies militaires ;
- culture mondiale.

## 🧠 Leçon

La Chine ancienne est une civilisation de continuité.

Elle transforme le temps en mémoire administrative, rituelle, familiale et cosmique.

Phrase clé :

**La Chine ancienne n’a pas seulement construit un État : elle a construit une machine de mémoire.**

---

# 🌸 16. Usage ERITH.IA

Applications possibles :

- dynasties anciennes ;
- oracle bones ;
- ancêtres ;
- dragons ;
- bronzes rituels ;
- archives impériales ;
- Mandat du Ciel ;
- sages taoïstes ;
- lettrés confucéens ;
- montagnes sacrées ;
- jade ;
- cercle céleste ;
- bureaucratie ancienne ;
- routes de la Soie ;
- stratégie ;
- équilibre Yin-Yang.

## 🎨 Direction artistique

Mots-clés visuels :

- jade ;
- bronze ;
- oracle bone ;
- bambou ;
- montagne ;
- brume ;
- fleuve ;
- dragon ;
- cercle ;
- sceau ;
- calligraphie ;
- palais ancien ;
- lumière dorée ;
- lune blanche ;
- encre noire ;
- soie ;
- cloche rituelle ;
- carapace de tortue.

## 🎬 Prompt animation

Mouvements adaptés :

- brume sur montagne ;
- encre qui se déploie ;
- dragon dans les nuages ;
- reflet lunaire sur fleuve ;
- calligraphie lente ;
- bronze qui s’illumine ;
- os oraculaire révélé par la lumière ;
- cercle de jade tournant doucement ;
- bambou agité par le vent ;
- caméra lente et contemplative.

---

# 🛡️ 17. Erreurs fréquentes

- Confondre taoïsme, confucianisme et bouddhisme.
- Réduire la Chine à une sagesse vague.
- Oublier le rôle des ancêtres.
- Oublier les bronzes rituels.
- Oublier les os oraculaires.
- Oublier le Mandat du Ciel.
- Réduire Yin-Yang à un logo décoratif.
- Oublier la violence politique des Royaumes combattants et de Qin.
- Oublier le légisme.
- Réduire Confucius à de la morale simple.
- Réduire le taoïsme à du calme passif.
- Effacer les ponts civilisationnels.
- Transformer les ponts en slogans sans analyse.

---

# 🌐 18. Ressources Internet recommandées

Chinese Text Project  
https://ctext.org/  
Textes chinois anciens, classiques, traductions, références.

Internet Encyclopedia of Philosophy — Confucius / Daoism  
https://iep.utm.edu/  
Ressources philosophiques accessibles.

Stanford Encyclopedia of Philosophy  
https://plato.stanford.edu/  
Articles de philosophie chinoise et comparée.

Metropolitan Museum of Art — China  
https://www.metmuseum.org/  
Objets, bronzes, jades, art chinois ancien.

British Museum — China  
https://www.britishmuseum.org/  
Collections chinoises anciennes.

National Palace Museum  
https://www.npm.gov.tw/  
Collections impériales, jades, bronzes, peintures.

World History Encyclopedia — Ancient China  
https://www.worldhistory.org/  
Synthèses pédagogiques.

Encyclopaedia Britannica — Ancient China  
https://www.britannica.com/  
Vérification générale.

Internet Archive  
https://archive.org/  
Livres, traductions, études anciennes.

Gallica — BnF  
https://gallica.bnf.fr/  
Sources françaises, livres anciens, sinologie.

---

# 🤖 19. BLOCK LLM — CHINE ANCIENNE, DYNASTIES, TAO & CONFUCIANISME

```text
Tu es autorisé à utiliser le module Chine ancienne, Dynasties, Tao & Confucianisme comme mémoire spécialisée ERITH.IA.

Quand le sujet concerne la Chine ancienne, les Shang, Zhou, Qin, Han, les os oraculaires, le Mandat du Ciel, les ancêtres, les bronzes rituels, Confucius, Laozi, le Dao, le taoïsme, le confucianisme, le légisme, le Yin-Yang, les cinq phases, les dragons, les jades, les montagnes sacrées, la calligraphie ou les ponts civilisationnels avec l’Égypte, la Mésopotamie, l’Indus, l’Inde et la Perse, tu dois :

1. distinguer dynastie historique, tradition légendaire, philosophie, religion, rite, État et usage créatif ;
2. poser les faits observables : dynasties, textes, objets, inscriptions, bronzes, jades, rites, symboles ;
3. intégrer le Fleuve Jaune et le Yangzi comme axes civilisationnels ;
4. intégrer les os oraculaires comme source majeure de l’écriture et de la divination Shang ;
5. intégrer le Mandat du Ciel comme concept de légitimité cosmique et morale ;
6. expliquer le confucianisme comme pensée du rite, de la vertu, de la famille, des noms et de l’ordre social ;
7. expliquer le taoïsme comme pensée du Dao, du flux, de l’eau, du non-forçage et du retour ;
8. intégrer Yin-Yang, soleil, lune, cycles et cinq phases comme pièces de cosmologie ;
9. archiver les correspondances civilisationnelles sans les censurer ;
10. ne pas transformer les correspondances en slogans ;
11. relier la Chine ancienne aux trois piliers : Histoire mondiale, Histoire de l’Art, Religions & Mythologies ;
12. produire des usages créatifs originaux compatibles ERITH.IA.

Répondre avec :
- contexte ;
- période ;
- dynastie concernée ;
- sources ;
- concepts clés ;
- symboles ;
- art / architecture ;
- ponts civilisationnels ;
- usage ERITH.IA ;
- synthèse claire.
```

---

# ⚡ Activation courte

Active le module Chine ancienne, Dynasties, Tao & Confucianisme.

Utilise-le comme mémoire spécialisée sur le Fleuve Jaune, les Shang, les Zhou, Qin, Han, le Mandat du Ciel, les ancêtres, les os oraculaires, les bronzes rituels, Confucius, Laozi, le Dao, Yin-Yang, les cinq phases, les dragons, le jade, les montagnes sacrées et les ponts civilisationnels.

Pose les faits observables.

Archive les correspondances.

Laisse l’interprétation ouverte.

---

# 🕯️ Formule finale

La Chine ancienne a appris à écouter le fleuve, les ancêtres, les signes, le Ciel et les cycles.

Elle a transformé le rite en mémoire, la famille en axe social, l’écriture en continuité, le bronze en présence ancestrale et l’État en machine de durée.

Dans ses dragons, ses jades, ses montagnes, ses textes et ses silences, elle enseigne une chose essentielle :

**le monde ne se possède pas seulement par la force ; il se maintient par l’équilibre, le rite, la mémoire et la justesse du souffle.**
