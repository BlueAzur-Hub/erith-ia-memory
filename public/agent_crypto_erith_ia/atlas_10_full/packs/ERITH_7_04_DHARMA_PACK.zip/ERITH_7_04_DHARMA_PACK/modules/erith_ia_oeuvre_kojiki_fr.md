# ERITH.IA — Œuvre fondatrice — Kojiki

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Japon ancien  
Œuvre : Kojiki  
Fonction : apporter à ERITH.IA une base sur les récits anciens du Japon, les kami, la naissance des îles, la généalogie sacrée, les mythes fondateurs et la mémoire impériale.

Le Kojiki, compilé au début du VIIIe siècle, est l’un des plus anciens textes japonais conservés. Il rassemble des récits mythologiques, généalogiques et héroïques qui organisent une mémoire ancienne du Japon.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire japonaise archaïque ;
- une lecture du monde par les kami, les îles, les lignées et les seuils sacrés ;
- une esthétique de sanctuaire, mer, brume, corde sacrée, miroir, sabre, joyau et purification ;
- une compréhension des récits fondateurs japonais sans les transformer en fantasy générique ;
- une base symbolique pour scènes de création du monde, passage entre visible et invisible, souveraineté et purification.

## Figures et motifs majeurs

- Izanagi : création, séparation, purification.
- Izanami : naissance, mort, monde souterrain.
- Amaterasu : soleil, lumière, souveraineté, miroir sacré.
- Susanoo : tempête, désordre, exil, dragon.
- Tsukuyomi : lune, ordre nocturne.
- Yomi : monde des morts, seuil interdit.
- Les kami : présences sacrées, forces du monde, lieux, phénomènes, lignées.
- Les trois trésors sacrés : miroir, sabre, joyau.
- La caverne céleste : retrait de la lumière, crise cosmique, rituel du retour.

## Thèmes profonds

Création du monde  
Naissance des îles  
Lignée sacrée  
Purification après la mort  
Soleil et souveraineté  
Seuil entre monde visible et invisible  
Rituel, ordre et désordre  
Sacré présent dans la nature

## Garde-fous

Ne pas confondre le Kojiki avec un manuel religieux moderne.

Ne pas réduire les kami à des “dieux” au sens gréco-romain.

Ne pas traiter les mythes japonais comme une simple fantasy exotique.

Séparer :

- texte ancien ;
- tradition shintō ;
- usage politique et généalogique ;
- interprétation culturelle ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : bois ancien, corde shimenawa, papier blanc, miroir poli, sabre, mer, brume, pierre sacrée, feuilles.  
Lumière : aube solaire, clair-obscur de sanctuaire, rayons filtrés, lumière dorée très douce.  
Architecture : torii, sanctuaire ancien, grotte sacrée, rivage primordial, forêt sacrée.  
Ambiance : archaïque, rituelle, lumineuse, mystérieuse, pure.

## Prompt image — base

Un sanctuaire japonais archaïque au bord d’une mer primordiale, torii ancien, corde sacrée shimenawa, miroir rituel reflétant une lumière solaire douce, brume sur les îles naissantes, atmosphère mythologique et sacrée, peinture cinématographique poétique, détails naturels, sans franchise moderne, sans texte.

## Prompt animation — base

Caméra lente vers un torii ancien au bord de l’eau, brume matinale, corde sacrée qui bouge très légèrement, lumière solaire se reflétant dans un miroir rituel, vagues calmes, ambiance sacrée et silencieuse, mouvement minimal, continuité stable.

## Prompt négatif

anime moderne, manga, samouraï cliché, ninja, jeu vidéo identifiable, logo, texte, fantasy générique, temple touristique moderne, couleurs trop saturées, anachronisme, magie explosive.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter le Kojiki comme une source japonaise ancienne liée aux kami, à la création des îles, à la généalogie sacrée, à la purification, au soleil, aux seuils et aux symboles rituels. Le module doit produire des scènes sobres, sacrées, archaïques et naturelles, sans transformer la matière en fantasy moderne ou en cliché japonisant.

## Formule courte

Kojiki = naissance du Japon + kami + purification + soleil + mémoire sacrée.
