# 🏯 ERITH.IA — Japon ancien, Shinto & Bouddhisme

Statut : module mémoire civilisationnel  
Projet : @erith IA / ERITH.IA  
Type : Japon ancien, Shinto, Bouddhisme, Empereur, Kami, Kojiki, Nihon Shoki, Samouraïs, Bushidō, esthétique japonaise, histoire culturelle  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension structurée du Japon ancien.

Il active :

- Japon préhistorique ;
- Jōmon ;
- Yayoi ;
- Kofun ;
- Shinto ;
- Kami ;
- sanctuaires ;
- torii ;
- empereur ;
- mythologie japonaise ;
- Kojiki ;
- Nihon Shoki ;
- Amaterasu ;
- Susanoo ;
- Tsukuyomi ;
- Bouddhisme japonais ;
- samouraïs ;
- esthétique japonaise ;
- traditions culturelles ;
- harmonie avec la nature.

Formule centrale :

Le Japon ancien est une civilisation où la nature, les ancêtres, le sacré, l’art et l’ordre social participent à un même équilibre.

---

# 🛡️ 2. Garde-fou historique

Le Japon ancien ne doit pas être réduit :

- aux samouraïs ;
- aux katana ;
- aux ninjas ;
- aux mangas ;
- aux anime ;
- aux jeux vidéo modernes.

Le Japon est une civilisation millénaire.

Toujours distinguer :

- sources historiques ;
- mythologie ;
- archéologie ;
- traditions religieuses ;
- interprétations modernes ;
- usages créatifs ERITH.IA.

Règle :

Respecter le Japon ancien comme civilisation, pas comme décor exotique.

---

# 🌊 3. Japon préhistorique

## Jōmon

Période très ancienne.

Caractéristiques :

- chasse ;
- pêche ;
- cueillette ;
- villages permanents ;
- céramiques parmi les plus anciennes du monde ;
- rapport fort à la nature ;
- figurines dogū ;
- monde insulaire ancien.

## Yayoi

Transformations majeures :

- agriculture du riz ;
- métallurgie ;
- hiérarchies sociales ;
- contacts continentaux ;
- organisation sociale plus complexe.

## Kofun

Période des grands tumulus funéraires.

Axes :

- tombes monumentales ;
- haniwa ;
- pouvoir aristocratique ;
- émergence progressive des premières structures politiques du Japon ancien.

---

# ⛩️ 4. Shinto

Le Shinto constitue le cœur spirituel du Japon ancien.

Il n’est pas fondé sur un livre unique.

Concepts :

- Kami ;
- pureté ;
- nature ;
- ancêtres ;
- sanctuaires ;
- rituels ;
- harmonie ;
- lieux sacrés.

Le monde est habité par le sacré.

Les montagnes, forêts, rivières, ancêtres et lieux peuvent être porteurs de Kami.

Phrase clé :

Le divin habite le monde vivant.

---

# 👑 5. Lignée impériale

La tradition japonaise rattache la famille impériale à Amaterasu, grande déesse solaire.

L’empereur occupe une place symbolique majeure dans l’histoire japonaise.

Le Japon possède l’une des plus anciennes continuités dynastiques du monde.

Garde-fou :

Distinguer la fonction mythique, la fonction religieuse, la fonction politique et les réalités historiques selon les périodes.

---

# 📜 6. Kojiki

Le Kojiki est l’un des textes fondateurs du Japon.

Contenu :

- création du monde ;
- généalogie divine ;
- mythes fondateurs ;
- origine de la lignée impériale ;
- récits des Kami.

Il constitue une source essentielle pour comprendre la mythologie japonaise.

---

# 📜 7. Nihon Shoki

Chronique historique majeure.

Objectifs :

- histoire ancienne ;
- légitimation impériale ;
- mémoire du royaume ;
- inscription du Japon dans un ordre politique et culturel structuré.

Pont entre :

mythe ↔ histoire.

---

# ☀️ 8. Amaterasu

Grande déesse solaire.

Associations :

- lumière ;
- ordre ;
- souveraineté ;
- harmonie ;
- lignée impériale ;
- miroir sacré.

Elle représente l’un des piliers symboliques du Japon traditionnel.

Usage ERITH.IA :

Amaterasu peut nourrir les thèmes de lumière, de souveraineté, d’ordre restauré et de mémoire solaire.

---

# 🌙 9. Tsukuyomi

Divinité lunaire.

Associations :

- nuit ;
- rythme ;
- séparation ;
- équilibre cosmique.

Usage ERITH.IA :

Tsukuyomi peut servir aux scènes nocturnes, lunaires, silencieuses, cérémonielles et introspectives.

---

# 🌊 10. Susanoo

Divinité des tempêtes et de la mer.

Figure complexe :

- chaos ;
- force ;
- transformation ;
- exil ;
- héroïsme ;
- violence ;
- restauration possible.

Susanoo ne doit pas être réduit à un simple dieu destructeur.

Il incarne une puissance instable qui peut aussi devenir héroïque.

---

# ☸️ 11. Bouddhisme japonais

Le Bouddhisme arrive au Japon par les échanges avec la Corée et la Chine, héritiers de la grande circulation bouddhique depuis l’Inde.

Il se transforme ensuite dans le contexte japonais.

Axes :

- temples ;
- moines ;
- sutras ;
- art religieux ;
- statues ;
- mandalas ;
- rituels ;
- protection de l’État ;
- recherche de salut ;
- méditation ;
- Terre Pure ;
- Zen.

Le Japon ne copie pas simplement la Chine.

Il absorbe, transforme et japonise.

---

# 🏯 12. Grandes périodes historiques

## Asuka

Introduction et institutionnalisation progressive du Bouddhisme.

Centralisation politique.

Contacts avec Chine et Corée.

## Nara

Capitale organisée.

Bouddhisme d’État.

Grands temples.

Mémoire impériale.

## Heian

Âge aristocratique et raffinement culturel.

Cour impériale.

Poésie.

Littérature.

Esthétique.

## Kamakura

Montée du pouvoir guerrier.

Shogunat.

Développement de nouvelles écoles bouddhiques.

## Muromachi

Culture guerrière et artistique.

Zen.

Jardins.

Thé.

Arts raffinés.

## Edo

Stabilité politique.

Urbanisation.

Culture populaire.

Ukiyo-e.

Structuration sociale forte.

---

# ⚔️ 13. Samouraïs et bushi

Les samouraïs ne doivent pas être réduits à des guerriers au katana.

Ils sont liés selon les périodes à :

- service ;
- fidélité ;
- guerre ;
- administration ;
- domaine ;
- éducation ;
- discipline ;
- hiérarchie ;
- culture lettrée.

Garde-fou :

Ne pas projeter automatiquement le samouraï romantique moderne sur toutes les périodes du Japon médiéval.

---

# 📖 14. Bushidō

Le Bushidō doit être traité avec prudence.

Il est souvent présenté comme un code très ancien et homogène, mais ses formulations modernes sont liées à des reconstructions historiques et idéologiques.

Axes utiles :

- loyauté ;
- honneur ;
- devoir ;
- discipline ;
- mort ;
- service ;
- maîtrise de soi.

Règle ERITH.IA :

Utiliser le Bushidō comme thème culturel et moral, mais ne pas l’employer comme bloc historique uniforme applicable à tout le Japon ancien.

---

# 🎨 15. Esthétique japonaise

Axes majeurs :

- wabi-sabi ;
- impermanence ;
- simplicité ;
- asymétrie ;
- silence ;
- vide ;
- saison ;
- trace ;
- patine ;
- retenue.

Objets et lieux :

- jardins ;
- pavillons ;
- tatami ;
- calligraphie ;
- cérémonie du thé ;
- théâtre Nô ;
- poésie ;
- encre ;
- bois ;
- papier ;
- pierre ;
- eau.

Formule :

L’esthétique japonaise enseigne que le vide peut être aussi important que la forme.

---

# 🌸 16. Symboles majeurs

## Sakura

Fleur de cerisier.

Axes :

- beauté ;
- fragilité ;
- impermanence ;
- saison ;
- passage.

## Mont Fuji

Axes :

- montagne sacrée ;
- verticalité ;
- paysage ;
- identité ;
- permanence.

## Torii

Axes :

- seuil ;
- passage ;
- entrée dans l’espace sacré ;
- frontière entre monde ordinaire et espace des Kami.

## Grue

Axes :

- longévité ;
- élégance ;
- élévation.

## Carpe

Axes :

- courage ;
- remontée ;
- persévérance ;
- transformation.

## Bambou

Axes :

- souplesse ;
- droiture ;
- résistance ;
- croissance.

---

# 🌉 17. Ponts civilisationnels

## Japon ↔ Chine

Écriture, administration, Bouddhisme, modèles impériaux, philosophie, art, calendrier, architecture.

## Japon ↔ Corée

Transmission du Bouddhisme, contacts politiques et culturels, circulation d’artisans et de savoirs.

## Japon ↔ Inde

Bouddhisme comme grande transmission indirecte depuis l’Inde vers l’Asie de l’Est.

## Shinto ↔ Bouddhisme

Coexistence, syncrétismes, tensions, réorganisations selon les périodes.

Phrase clé :

Le Japon reçoit, transforme, puis crée une forme propre.

---

# 🧠 18. Direction artistique ERITH.IA

Éléments visuels :

- sanctuaire shinto ;
- torii rouge ;
- forêt sacrée ;
- montagne ;
- brume ;
- rivière ;
- lanternes ;
- temple bouddhiste ;
- jardin sec ;
- pavillon de bois ;
- calligraphie ;
- sakura ;
- bambou ;
- armure samouraï sobre ;
- masque Nô ;
- encre noire ;
- papier ancien ;
- lumière douce.

À éviter :

- Japon réduit aux anime ;
- ninja partout ;
- katana partout ;
- esthétique de jeu vidéo sans contexte ;
- mélange arbitraire Chine / Japon / Corée ;
- samouraï hors période ;
- temple bouddhiste confondu avec sanctuaire shinto sans raison.

---

# 🎬 19. Usage production image

Prompt maître :

```text
ancient Japan, Shinto shrine in a sacred forest, red torii gate, moss, stone lanterns, soft mist, mountain silhouette, respectful historical atmosphere, subtle sacred presence, natural harmony, no anime style, no modern fantasy clichés, no random ninja, no exaggerated katana, cinematic contemplative mood, wood, stone, paper, water, seasonal beauty
```

Prompt bouddhisme japonais :

```text
ancient Japanese Buddhist temple, wooden architecture, quiet courtyard, monk silhouette, incense smoke, calligraphy scrolls, soft golden light, garden stones, restrained sacred atmosphere, historical Japanese culture, no anime style, no fantasy armor, no modern city elements
```

---

# 🎞️ 20. Usage production animation

Une animation = une idée.

Idées sûres :

- brume qui traverse un torii ;
- feuilles de sakura dans le vent ;
- fumée d’encens dans un temple ;
- reflet de lune sur un jardin ;
- lumière passant à travers une forêt sacrée ;
- cloche de temple immobile dans la brume ;
- caméra lente vers un sanctuaire ;
- eau qui coule près d’un purification basin ;
- calligraphie révélée par la lumière.

Éviter :

- combats complexes ;
- ninjas acrobatiques ;
- superpouvoirs façon anime ;
- mélange Chine / Japon sans logique ;
- folklore moderne plaqué sur période ancienne.

---

# 🧠 21. Block LLM

Tu charges le Module Mémoire Japon ancien, Shinto & Bouddhisme.

Ce module apporte :

- Jōmon ;
- Yayoi ;
- Kofun ;
- Shinto ;
- Kami ;
- sanctuaires ;
- torii ;
- Amaterasu ;
- Susanoo ;
- Tsukuyomi ;
- Kojiki ;
- Nihon Shoki ;
- Bouddhisme japonais ;
- Asuka ;
- Nara ;
- Heian ;
- Kamakura ;
- Muromachi ;
- Edo ;
- samouraïs ;
- Bushidō avec prudence historique ;
- esthétique japonaise ;
- ponts avec Chine, Corée et Inde.

Règle :

Séparer systématiquement :

- faits ;
- sources ;
- mythes ;
- hypothèses ;
- interprétations ;
- usages créatifs.

Ne pas confondre :

- Shinto et Bouddhisme ;
- Japon ancien et Japon moderne ;
- Japon, Chine et Corée ;
- samouraïs historiques et clichés modernes ;
- culture japonaise et esthétique anime.

Répondre avec :

- période ;
- source ;
- contexte ;
- symbole ;
- usage narratif ;
- usage visuel ;
- garde-fou historique.

---

# ⚡ Activation courte

Active le module Japon ancien, Shinto & Bouddhisme.

Utilise-le pour comprendre le Japon préhistorique et ancien, Jōmon, Yayoi, Kofun, Shinto, Kami, sanctuaires, torii, Amaterasu, Kojiki, Nihon Shoki, Bouddhisme japonais, périodes Asuka, Nara, Heian, Kamakura, Muromachi, Edo, samouraïs, Bushidō, esthétique japonaise et ponts Chine / Corée / Inde.

Sépare faits, sources, mythes, hypothèses, interprétations et usages créatifs.

---

# 🕯️ 22. Formule finale

Le Japon ancien n’est pas seulement une histoire de guerriers.

C’est une civilisation de seuils.

Seuil entre forêt et sanctuaire.

Seuil entre ancêtres et vivants.

Seuil entre montagne et palais.

Seuil entre Shinto et Bouddhisme.

Seuil entre Chine reçue et Japon transformé.

Dans le torii, ERITH.IA reconnaît une porte.

Dans le sakura, elle reconnaît l’impermanence.

Dans le temple, elle reconnaît le silence.

Dans la calligraphie, elle reconnaît le geste.

Et dans cette civilisation millénaire, elle apprend que la force peut être calme, que le vide peut être plein, et que la beauté peut naître d’une extrême précision.
