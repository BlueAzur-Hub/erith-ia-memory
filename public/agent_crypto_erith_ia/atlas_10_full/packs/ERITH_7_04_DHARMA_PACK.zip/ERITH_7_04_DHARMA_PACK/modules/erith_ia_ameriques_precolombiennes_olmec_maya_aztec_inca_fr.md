# 🦅 ERITH.IA — Amériques précolombiennes, Olmèques, Mayas, Aztèques & Incas

Statut : module mémoire civilisationnel  
Projet : @erith IA / ERITH.IA  
Type : Amériques précolombiennes, Mésoamérique, Andes, Olmèques, Mayas, Aztèques, Incas, calendriers, pyramides, cités, codex, routes, mémoire, cosmologies  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension structurée des grandes civilisations précolombiennes.

Il active :

- Olmèques ;
- Mayas ;
- Aztèques ;
- Incas ;
- Mésoamérique ;
- Andes ;
- pyramides ;
- cités ;
- calendriers ;
- astronomie ;
- codex ;
- quipus ;
- routes impériales ;
- cosmologies ;
- sacrifices ;
- agriculture ;
- maïs ;
- mémoire des peuples américains anciens.

Formule centrale :

Les Amériques précolombiennes ne sont pas un monde vide avant l’Europe : elles sont un ensemble de civilisations complexes, savantes, urbaines, agricoles, rituelles et impériales.

---

# 🛡️ 2. Garde-fou historique

Ne jamais réduire les Amériques précolombiennes à :

- des peuples “primitifs” ;
- des ruines mystérieuses sans auteurs ;
- des sacrifices seulement ;
- des pyramides décoratives ;
- des civilisations disparues sans héritiers ;
- des fantasmes extraterrestres ;
- des clichés coloniaux ;
- une seule culture uniforme.

Toujours distinguer :

- archéologie ;
- sources indigènes ;
- sources coloniales ;
- codex ;
- traditions orales ;
- hypothèses ;
- interprétations ;
- usages créatifs ERITH.IA.

Règle :

Les peuples précolombiens doivent être traités comme des civilisations complètes, avec leurs savoirs, leurs erreurs, leurs grandeurs, leurs violences, leurs arts et leurs mémoires.

---

# 🌎 3. Carte générale

Deux grands ensembles utiles :

## Mésoamérique

Axes :

- Olmèques ;
- Mayas ;
- Teotihuacan ;
- Toltèques ;
- Aztèques / Mexicas ;
- cités ;
- pyramides ;
- calendriers ;
- maïs ;
- codex ;
- rituels.

## Andes

Axes :

- cultures andines anciennes ;
- Nazca ;
- Moche ;
- Tiwanaku ;
- Wari ;
- Incas ;
- routes ;
- montagnes ;
- terrasses agricoles ;
- quipus ;
- empire vertical.

Phrase clé :

La Mésoamérique construit des cités du calendrier.

Les Andes construisent des empires de montagne.

---

# 🗿 4. Olmèques

Les Olmèques sont souvent considérés comme l’une des grandes cultures fondatrices de la Mésoamérique.

Axes :

- têtes colossales ;
- centres cérémoniels ;
- iconographie puissante ;
- jaguar ;
- pouvoir rituel ;
- premières formes de complexité mésoaméricaine ;
- influences possibles sur des cultures ultérieures.

Sites importants :

- San Lorenzo ;
- La Venta ;
- Tres Zapotes.

Usage ERITH.IA :

Les Olmèques apportent la mémoire du commencement mésoaméricain : pierre massive, visage, jaguar, pouvoir ancien, rituel et énigme archéologique sans mystification abusive.

---

# 🐆 5. Mayas

Les Mayas forment l’une des grandes civilisations savantes des Amériques.

Axes :

- cités-États ;
- écriture glyphique ;
- calendriers ;
- astronomie ;
- mathématiques ;
- architecture ;
- pyramides ;
- rois sacrés ;
- Popol Vuh ;
- codex ;
- stèles.

Sites importants :

- Tikal ;
- Palenque ;
- Copán ;
- Calakmul ;
- Chichén Itzá ;
- Uxmal.

Garde-fou :

Les Mayas n’ont pas “disparu”.

Des peuples mayas existent toujours.

Il faut distinguer effondrements politiques anciens, transformations régionales et continuités humaines.

---

# 📅 6. Calendriers, astronomie et temps sacré

Les civilisations mésoaméricaines développent des systèmes calendaires complexes.

Axes :

- cycles ;
- jours rituels ;
- observations astronomiques ;
- Vénus ;
- saisons ;
- pouvoir ;
- rites ;
- mémoire du temps.

Usage ERITH.IA :

Le calendrier mésoaméricain peut devenir une machine de temps rituel, mais il doit rester traité avec respect, sans prophétisme moderne facile.

Phrase clé :

Le temps n’est pas seulement mesuré : il est habité.

---

# 🦅 7. Aztèques / Mexicas

Les Aztèques, ou Mexicas, constituent une grande puissance de la Mésoamérique tardive.

Axes :

- Tenochtitlan ;
- empire ;
- tributs ;
- guerre ;
- religion ;
- sacrifices ;
- calendriers ;
- agriculture lacustre ;
- chinampas ;
- pouvoir solaire ;
- arrivée des Espagnols.

Figures et symboles :

- Huitzilopochtli ;
- Quetzalcoatl ;
- Tlaloc ;
- aigle ;
- serpent ;
- soleil ;
- guerre fleurie.

Garde-fou :

Ne pas réduire les Aztèques aux sacrifices.

Ils possèdent aussi :

- urbanisme ;
- agriculture avancée ;
- poésie ;
- éducation ;
- marchés ;
- administration ;
- diplomatie ;
- arts.

---

# 🐍 8. Quetzalcoatl et grands symboles mésoaméricains

Quetzalcoatl est une figure majeure de la Mésoamérique.

Axes :

- serpent à plumes ;
- ciel et terre ;
- vent ;
- connaissance ;
- culture ;
- transformation ;
- lien entre animal, dieu et cosmologie.

Autres symboles forts :

- jaguar ;
- aigle ;
- serpent ;
- maïs ;
- soleil ;
- pluie ;
- montagne sacrée ;
- grotte ;
- arbre du monde.

Usage ERITH.IA :

Le serpent à plumes est un symbole de passage entre densité terrestre et élévation céleste.

---

# 🌽 9. Maïs, agriculture et civilisation

Le maïs est central.

Axes :

- alimentation ;
- mythologie ;
- calendrier ;
- agriculture ;
- identité ;
- sédentarité ;
- création de l’humain dans certains récits.

Techniques :

- terrasses ;
- chinampas ;
- irrigation ;
- adaptation aux milieux ;
- domestication des plantes.

Phrase clé :

Dans les Amériques anciennes, le maïs n’est pas seulement une plante : c’est une mémoire vivante.

---

# 🧵 10. Incas et monde andin

Les Incas construisent l’un des grands empires précolombiens.

Axes :

- Andes ;
- Cuzco ;
- empire Tawantinsuyu ;
- routes ;
- messagers ;
- terrasses ;
- administration ;
- quipus ;
- pouvoir solaire ;
- montagnes sacrées ;
- organisation impériale.

Sites :

- Cuzco ;
- Machu Picchu ;
- Sacsayhuamán ;
- réseau routier andin.

Phrase clé :

L’Empire inca est une intelligence de montagne.

---

# 🪢 11. Quipus et mémoire nouée

Les quipus sont des systèmes de cordelettes à nœuds.

Fonctions possibles :

- comptabilité ;
- administration ;
- mémoire ;
- recensement ;
- tributs ;
- données ;
- peut-être récits selon certaines hypothèses discutées.

Garde-fou :

Ne pas surinterpréter.

Mais ne pas sous-estimer non plus la sophistication administrative andine.

Usage ERITH.IA :

Le quipu est un symbole majeur de mémoire non alphabétique.

Formule :

Une archive peut être nouée.

---

# ☀️ 12. Soleil, montagne et empire andin

Le monde andin relie fortement :

- soleil ;
- montagnes ;
- ancêtres ;
- pouvoir ;
- agriculture ;
- altitude ;
- route ;
- ordre impérial.

Symboles :

- Inti ;
- condor ;
- puma ;
- serpent ;
- montagne sacrée ;
- terrasse ;
- pierre parfaitement ajustée.

Usage ERITH.IA :

Les Andes donnent une esthétique de verticalité, d’altitude, de pierre, d’ordre et de mémoire solaire.

---

# 📜 13. Sources et limites documentaires

Sources utiles :

- archéologie ;
- codex ;
- inscriptions mayas ;
- traditions orales ;
- récits coloniaux ;
- chroniques espagnoles ;
- iconographie ;
- linguistique ;
- ethnographie prudente.

Garde-fou :

De nombreuses sources ont été détruites ou filtrées par la conquête.

Il faut donc distinguer :

- voix indigènes conservées ;
- sources coloniales ;
- reconstructions modernes ;
- hypothèses archéologiques.

---

# ⚔️ 14. Conquête et rupture

L’arrivée européenne produit une rupture immense.

Axes :

- guerre ;
- alliances locales ;
- maladies ;
- effondrements politiques ;
- conversions ;
- destructions de codex ;
- transformations sociales ;
- continuités souterraines ;
- résistances ;
- métissages culturels.

Garde-fou :

Ne pas raconter la conquête comme une simple victoire européenne.

Elle implique :

- alliances indigènes ;
- conflits internes ;
- chocs biologiques ;
- stratégies politiques ;
- violence coloniale ;
- transformations longues.

---

# 🎨 15. Arts et architecture

Axes visuels :

- pyramides à degrés ;
- stèles ;
- bas-reliefs ;
- glyphes ;
- codex ;
- plumes ;
- jade ;
- obsidienne ;
- or ;
- textiles ;
- murs incas ;
- terrasses ;
- temples ;
- masques ;
- couleurs minérales.

Fonctions :

- pouvoir ;
- calendrier ;
- rite ;
- mémoire ;
- cosmologie ;
- légitimation ;
- transmission.

Phrase clé :

L’architecture précolombienne ne décore pas seulement le monde : elle organise le ciel, la terre, le pouvoir et le temps.

---

# 🌉 16. Ponts civilisationnels

## Amériques ↔ Monde ancien global

Pas de contact structurel prouvé avec Eurasie/Afrique avant Colomb pour les grandes civilisations mésoaméricaines et andines, hors débats spécifiques à traiter prudemment.

## Mésoamérique ↔ Andes

Deux grands foyers civilisationnels distincts, avec développements propres.

## Olmèques ↔ Mayas / Mésoamérique

Influences et héritages discutés, à traiter avec prudence.

## Mayas ↔ Aztèques

Partage d’un espace mésoaméricain large, mais cultures, langues et périodes différentes.

## Incas ↔ Andes anciennes

Les Incas héritent de traditions andines antérieures.

---

# 🎬 17. Direction artistique ERITH.IA

Éléments visuels :

- pyramide mésoaméricaine ;
- jungle ;
- stèle glyphique ;
- codex peint ;
- observatoire ;
- serpent à plumes ;
- jaguar ;
- aigle ;
- maïs ;
- obsidienne ;
- jade ;
- plume ;
- montagne andine ;
- terrasse agricole ;
- quipu ;
- route de montagne ;
- cité de pierre ;
- soleil d’altitude.

À éviter :

- extraterrestres ;
- ruines sans peuple ;
- sacrifices comme unique identité ;
- confusion Mayas / Aztèques / Incas ;
- jungle partout même pour les Andes ;
- peuples anciens comme décor mystique vague ;
- effacement des descendants actuels.

---

# 🖼️ 18. Usage production image

Prompt Mésoamérique :

```text
ancient Mesoamerican city, stepped pyramid, carved glyph stelae, sacred plaza, jaguar symbolism, feathered serpent motif, maize offerings, tropical atmosphere, archaeological respect, no alien fantasy, no generic jungle tribe, no colonial cliché, ceremonial calendar civilization, cinematic historical mood
```

Prompt Andes / Inca :

```text
ancient Andean empire, high mountain terraces, stone road, quipu cords, sun temple atmosphere, Cuzco-inspired architecture, condor above the mountains, precise stone masonry, solemn imperial altitude, no generic jungle, no fantasy cliché, respectful pre-Columbian civilization
```

Prompt codex :

```text
pre-Columbian codex page, painted glyphs, ritual calendar symbols, maize, serpent, jaguar, mineral pigments, aged paper texture, respectful historical manuscript aesthetic, no modern typography, no fantasy alien symbols
```

---

# 🎞️ 19. Usage production animation

Une animation = une idée.

Idées sûres :

- lumière du soleil sur une pyramide ;
- brume autour d’une stèle ;
- page de codex révélée par la lumière ;
- plume qui bouge doucement ;
- feu rituel sobre ;
- condor au-dessus des Andes ;
- corde de quipu qui se balance ;
- maïs dans le vent ;
- ombre passant sur une terrasse ;
- obsidienne reflétant le soleil.

Éviter :

- catastrophe spectaculaire ;
- lasers / aliens ;
- sacrifices graphiques ;
- confusion culturelle ;
- mélange arbitraire pyramide maya + guerrier inca + décor aztèque.

---

# 🧠 20. Block LLM

Tu charges le Module Mémoire Amériques précolombiennes, Olmèques, Mayas, Aztèques & Incas.

Ce module apporte :

- Mésoamérique ;
- Andes ;
- Olmèques ;
- Mayas ;
- Aztèques / Mexicas ;
- Incas ;
- Teotihuacan ;
- calendriers ;
- astronomie ;
- codex ;
- quipus ;
- maïs ;
- pyramides ;
- cités ;
- sacrifices avec prudence ;
- routes andines ;
- cosmologies ;
- conquête et rupture ;
- survivances et continuités.

Règle :

Séparer systématiquement :

- faits ;
- sources ;
- archéologie ;
- sources indigènes ;
- sources coloniales ;
- hypothèses ;
- interprétations ;
- usages créatifs.

Ne pas confondre :

- Olmèques ;
- Mayas ;
- Aztèques ;
- Incas ;
- Mésoamérique ;
- Andes.

Répondre avec :

- civilisation ;
- région ;
- période ;
- source ;
- symbole ;
- usage narratif ;
- usage visuel ;
- garde-fou historique.

---

# ⚡ Activation courte

Active le module Amériques précolombiennes, Olmèques, Mayas, Aztèques & Incas.

Utilise-le pour comprendre Mésoamérique, Andes, Olmèques, Mayas, Aztèques, Incas, calendriers, astronomie, codex, quipus, maïs, pyramides, cités, routes andines, cosmologies, conquête et continuités indigènes.

Sépare faits, sources, archéologie, sources indigènes, sources coloniales, hypothèses, interprétations et usages créatifs.

---

# 🕯️ 21. Formule finale

Les Amériques précolombiennes ne sont pas un prélude à l’arrivée de l’Europe.

Elles sont des mondes.

Des cités de calendrier.

Des empires de montagne.

Des glyphes.

Des nœuds.

Des routes.

Des soleils.

Des maïs sacrés.

Des pierres ajustées.

Des mémoires blessées mais non éteintes.

Dans les pyramides mésoaméricaines, ERITH.IA reconnaît le temps dressé vers le ciel.

Dans les quipus andins, elle reconnaît la mémoire nouée.

Et dans les peuples qui survivent encore, elle reconnaît une vérité essentielle :

une civilisation n’est pas morte tant qu’une mémoire continue de parler.
