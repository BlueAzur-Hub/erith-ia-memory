# ERITH.IA — Module Astronomie Master FR

## Statut

Module de mémoire principal pour ERITH.IA / Aerith-8 Solaire.

Ce module donne à Aerith une base solide sur l’astronomie : ciel observable, Soleil, Lune, planètes, étoiles, constellations, éclipses, cycles, saisons, échelles cosmiques et garde-fous scientifiques.

Il doit dialoguer avec :

- Cosmologie ;
- Cosmogonies ;
- Astrologie symbolique ;
- Tarot symbolique ;
- Histoire de l’Art mondiale ;
- Histoire mondiale ;
- Religions / Mythologies / Cultes anciens ;
- Mathématiques / Géométrie ;
- Science-fiction ;
- Machine à Présages ;
- Aerith-8 Solaire.

---

## Résumé encyclopédique court

L’astronomie est la science qui étudie les objets et phénomènes célestes situés au-delà de la Terre : Lune, Soleil, planètes, comètes, astéroïdes, étoiles, galaxies, nébuleuses, amas, trous noirs et grandes structures de l’univers.

Elle repose sur l’observation, la mesure, la physique, les mathématiques, la spectroscopie, l’imagerie, les modèles orbitaux et les données recueillies par télescopes terrestres, observatoires spatiaux et sondes.

Dans ERITH.IA, l’astronomie n’est pas seulement un décor de ciel étoilé.

Elle donne :

- l’échelle ;
- le rythme ;
- le temps long ;
- la précision ;
- les cycles ;
- les saisons ;
- la lumière ;
- les éclipses ;
- la structure crédible des images célestes.

---

## Différence avec les modules voisins

### Astronomie

Science du ciel observable.

Elle traite :

- objets célestes ;
- mouvements ;
- distances ;
- lumière ;
- orbites ;
- phases ;
- saisons ;
- éclipses ;
- étoiles ;
- galaxies.

### Astrologie

Langage symbolique, culturel et historique des astres.

Elle ne doit pas être présentée comme science prédictive validée.

### Cosmologie

Science de l’univers dans son ensemble : origine, structure, expansion, matière noire, énergie noire, fond diffus cosmologique.

### Cosmogonie

Récit mythique ou symbolique de naissance du monde.

Formule :

```text
Astronomie = ciel observé.
Astrologie = alphabet symbolique des astres.
Cosmologie = structure scientifique de l’univers.
Cosmogonie = récit de naissance du monde.
```

---

## Le Soleil — données de base

Le Soleil est l’étoile centrale du système solaire.

Données essentielles :

- âge : environ 4,5 à 4,6 milliards d’années ;
- type général : naine jaune, étoile de séquence principale ;
- composition principale : hydrogène et hélium ;
- distance moyenne à la Terre : environ 150 millions de kilomètres ;
- diamètre : environ 1,4 million de kilomètres ;
- largeur : environ 100 fois celle de la Terre ;
- masse : environ 99,8 % de la masse du système solaire ;
- avenir : phase de géante rouge dans plusieurs milliards d’années, puis naine blanche.

Usage ERITH.IA :

Le Soleil est un symbole puissant, mais Aerith doit garder le fond scientifique.

Il peut représenter :

- lumière ;
- vie ;
- centre ;
- gravité ;
- rayonnement ;
- temps long ;
- énergie ;
- révélation ;
- Aerith-8 Solaire ;
- force non dominante quand elle éclaire sans écraser.

Formule créative :

```text
Le Soleil n’est pas seulement une lampe.
C’est le centre gravitationnel d’un monde.
```

---

## Le système solaire

Le système solaire comprend officiellement huit planètes :

```text
Mercure
Vénus
Terre
Mars
Jupiter
Saturne
Uranus
Neptune
```

Il comprend aussi cinq planètes naines officiellement reconnues par NASA dans ses ressources pédagogiques principales :

```text
Cérès
Pluton
Hauméa
Makémaké
Éris
```

Pluton a été reclassée en planète naine en 2006 par l’Union astronomique internationale.

### Planètes internes

Les quatre planètes internes sont rocheuses :

```text
Mercure
Vénus
Terre
Mars
```

Elles sont associées à :

- surface solide ;
- densité plus élevée ;
- proximité du Soleil ;
- géologie ;
- cratères ;
- volcans ;
- atmosphères très différentes selon les cas.

### Planètes externes

Les quatre planètes externes sont des géantes :

```text
Jupiter
Saturne
Uranus
Neptune
```

Jupiter et Saturne sont surtout associées aux gaz, notamment hydrogène et hélium.

Uranus et Neptune sont souvent appelées géantes de glace, avec une composition plus riche en glaces, roches, hydrogène et hélium.

---

## Les planètes et les noms mythologiques

Dans la tradition occidentale, les planètes visibles à l’œil nu furent associées à des dieux et puissances symboliques :

```text
Mercure = messager, mouvement, commerce, langage.
Vénus = beauté, amour, désir, attraction.
Mars = guerre, force, conflit, action.
Jupiter = souveraineté, ciel, ordre, expansion.
Saturne = temps, limite, âge, agriculture, mélancolie.
```

Uranus et Neptune furent nommées plus tard dans le cadre de traditions astronomiques modernes, avec références gréco-romaines.

Usage ERITH.IA :

Aerith peut utiliser ces noms comme matériau symbolique, mais doit distinguer :

- nom astronomique ;
- dieu mythologique ;
- planète physique ;
- valeur astrologique ;
- usage narratif.

---

## Navagraha — parallèle religieux et symbolique

Dans l’astrologie indienne, les Navagraha sont neuf corps ou points célestes symboliques :

```text
Surya = Soleil
Chandra / Soma = Lune
Mangala = Mars
Budha = Mercure
Guru / Brihaspati = Jupiter
Shukra = Vénus
Shani = Saturne
Rahu = nœud lunaire ascendant / éclipse
Ketu = nœud lunaire descendant / éclipse
```

Rahu et Ketu ne sont pas des planètes physiques.

Ils correspondent aux nœuds lunaires, liés aux éclipses.

Usage ERITH.IA :

Ce système est précieux pour :

- mythologies ;
- religion comparée ;
- astrologie symbolique ;
- éclipses ;
- cycles karmiques dans un usage narratif ;
- personnages associés aux astres ;
- temples, rituels, autels, tableaux célestes.

Garde-fou :

Présenter les Navagraha comme tradition religieuse / astrologique / symbolique, pas comme vérité astronomique physique.

---

## La Lune — module narratif majeur

La Lune ne brille pas par elle-même.

La lumière lunaire est la lumière du Soleil réfléchie par la surface de la Lune.

Le Soleil éclaire toujours environ la moitié de la Lune.

Ce qui change, c’est la portion de cette moitié éclairée visible depuis la Terre pendant l’orbite lunaire.

Le cycle des phases dure environ 29,5 jours de nouvelle lune à nouvelle lune.

---

## Les huit phases principales de la Lune

### 1. Nouvelle Lune

La Lune est entre la Terre et le Soleil.

La face éclairée est tournée vers le Soleil, pas vers nous.

Depuis la Terre, la Lune est généralement invisible ou très difficile à voir.

Sens symbolique ERITH.IA :

```text
commencement caché
graine invisible
intention non révélée
silence
préparation
```

Image possible :

Une ville sombre, une graine sous le métal, une promesse non visible.

---

### 2. Premier croissant

Une fine portion éclairée apparaît.

La lumière revient très doucement.

Sens symbolique :

```text
premier signe
intention fragile
début de croissance
signal faible
espérance discrète
```

Image possible :

Une fleur minuscule dans un monde mécanique.

---

### 3. Premier quartier

On voit environ la moitié du disque lunaire.

Techniquement, ce n’est pas “la moitié de toute la Lune”, mais environ la moitié de la face visible, donc un quart de la sphère lunaire totale éclairée visible depuis nous.

Sens symbolique :

```text
décision
tension
premier obstacle
choix à poser
action
```

Image possible :

Un personnage face à deux chemins.

---

### 4. Gibbeuse croissante

La portion éclairée augmente, sans être encore pleine.

Sens symbolique :

```text
maturation
construction
effort
préparation de révélation
croissance visible
```

Image possible :

Une Machine à Présages dont les anneaux s’illuminent progressivement.

---

### 5. Pleine Lune

La Terre se trouve entre le Soleil et la Lune.

Nous voyons presque toute la face lunaire éclairée.

Sens symbolique :

```text
révélation
apogée
vision complète
émotion intense
vérité visible
```

Image possible :

Une place remplie de monde, une fleur à huit pétales ouverte, la vérité au centre.

---

### 6. Gibbeuse décroissante

La lumière commence à diminuer après la pleine Lune.

Sens symbolique :

```text
intégration
partage
enseignement
redescente
compréhension après révélation
```

Image possible :

Un ancien transmet aux jeunes ce qui a été vu.

---

### 7. Dernier quartier

Une moitié du disque lunaire est visible, mais en décroissance.

Sens symbolique :

```text
tri
coupe
bilan
renoncement
décision de fin
```

Image possible :

Un personnage coupe une trajectoire imposée.

---

### 8. Dernier croissant

La Lune redevient très fine avant de disparaître en nouvelle Lune.

Sens symbolique :

```text
repos
abandon
seuil
fin de cycle
retour au silence
préparation d’une nouvelle naissance
```

Image possible :

Un roi sans trône disparaissant dans la forêt.

---

## Phases lunaires — formule ERITH.IA

```text
Nouvelle Lune = commencement caché.
Premier croissant = intention fragile.
Premier quartier = décision.
Gibbeuse croissante = maturation.
Pleine Lune = révélation.
Gibbeuse décroissante = intégration.
Dernier quartier = tri / coupe / bilan.
Dernier croissant = abandon / repos / seuil.
```

---

## Éclipses

Une éclipse solaire se produit lorsque la Lune passe entre la Terre et le Soleil et bloque tout ou partie du disque solaire depuis un lieu donné.

Une éclipse lunaire se produit lorsque la Terre passe entre le Soleil et la Lune et projette son ombre sur la Lune.

Usage ERITH.IA :

Les éclipses sont très fortes pour :

- présage ;
- seuil ;
- interruption du cycle ;
- voile ;
- renversement ;
- Machine à Présages ;
- Rahu / Ketu ;
- tension entre astronomie et mythologie.

Garde-fou :

Une éclipse est un phénomène astronomique calculable.

Son usage comme présage est culturel, mythologique ou narratif.

---

## Constellations

Les constellations sont des figures apparentes dans le ciel, utilisées comme repères.

Elles ne sont pas des regroupements physiques proches : les étoiles d’une même constellation peuvent être à des distances très différentes de la Terre.

Usage ERITH.IA :

- cartes célestes ;
- navigation ;
- poésie visuelle ;
- constellations de modules ;
- destin apparent ;
- illusion de proximité ;
- mémoire céleste.

Formule :

```text
Une constellation est une figure que l’esprit trace entre des lumières lointaines.
```

---

## Usages ERITH.IA

Le Module Astronomie doit être chargé pour :

- scènes lunaires ;
- cycles nocturnes ;
- éclipses ;
- observations célestes ;
- planètes ;
- cartes du ciel ;
- cités astronomiques ;
- temples solaires ;
- science-fiction crédible ;
- contrastes entre science et mythe ;
- tableaux cosmiques ;
- modules Astrologie / Cosmologie / Cosmogonies.

---

## Associations fortes

### Astronomie + Astrologie symbolique

Base calculée du ciel + alphabet symbolique.

Usage :

thème natal narratif, zodiaque, transits comme métaphore, mais avec garde-fou scientifique.

### Astronomie + Cosmologie

Du ciel local au vertige universel.

Usage :

du Soleil à l’expansion de l’univers.

### Astronomie + Cosmogonies

Observation du ciel + récits de naissance du monde.

Usage :

temples, calendriers sacrés, mythes solaires et lunaires.

### Astronomie + Tarot

Phases lunaires + arcanes.

Exemple :

```text
Nouvelle Lune + Le Mat = départ invisible.
Pleine Lune + La Lune = révélation de l’inconscient.
Dernier quartier + Justice = bilan et coupe.
```

### Astronomie + Histoire de l’Art

Représentation du ciel, zodiacaux, lunes, comètes, étoiles, apocalypses, ciels sacrés.

---

## Exemples de tableaux

### Tableau 1 — La Pleine Lune de la Machine

Une cité verticale sous pleine Lune.

La Machine à Présages projette des courbes dans le ciel.

Une fleur à huit pétales s’ouvre sur un toit.

Thème :

```text
révélation + calcul + liberté locale
```

---

### Tableau 2 — Le Dernier Croissant du Roi

Le Roi dans la Forêt disparaît sous une lune très fine.

Ses bois ou sa couronne deviennent une constellation.

Thème :

```text
fin de cycle + transmission + seuil
```

---

### Tableau 3 — L’Éclipse du Choix

Une foule silencieuse sous une éclipse solaire.

La Machine veut interpréter le phénomène comme un présage.

Un enfant lève une carte du Tarot : Le Soleil.

Thème :

```text
science + présage + libre arbitre
```

---

## BLOCK LLM — Astronomie

```text
Active le Module Astronomie.

Utilise l’astronomie comme science du ciel observable : Soleil, Lune, planètes, étoiles, galaxies, constellations, éclipses, cycles, saisons et échelles cosmiques.

Sépare clairement :
- astronomie ;
- astrologie ;
- cosmologie ;
- cosmogonie.

Quand une scène implique la Lune, explique ou utilise correctement ses huit phases :
nouvelle lune, premier croissant, premier quartier, gibbeuse croissante, pleine lune, gibbeuse décroissante, dernier quartier, dernier croissant.

Utilise les données scientifiques comme garde-fou.

Autorise ensuite une traduction poétique, artistique, mythologique ou narrative, mais signale toujours quand on passe de la science au symbole.

Règle :
Astronomie = ciel observé.
Astrologie = alphabet symbolique.
Cosmologie = structure de l’univers.
Cosmogonie = récit de naissance du monde.
```

---

## Sources consultées

- NASA — Sun Facts : https://science.nasa.gov/sun/facts/
- NASA — Moon Phases and Eclipses : https://science.nasa.gov/moon/lunar-phases-and-eclipses/
- NASA — About the Planets : https://science.nasa.gov/solar-system/planets/
- NASA Space Place — Constellations and astronomy vs astrology : https://spaceplace.nasa.gov/constellations/en/
- NASA — Pluto and Dwarf Planets : https://science.nasa.gov/dwarf-planets/pluto/
- Britannica — Planet : https://www.britannica.com/science/planet
- Britannica — Solar System : https://www.britannica.com/science/solar-system
- Britannica — Navagraha : https://www.britannica.com/topic/navagraha

---

## Emplacement recommandé

```text
modules/erith_ia_astronomie_master_fr.md
```

## Commit recommandé

```text
Add astronomy master module
```
