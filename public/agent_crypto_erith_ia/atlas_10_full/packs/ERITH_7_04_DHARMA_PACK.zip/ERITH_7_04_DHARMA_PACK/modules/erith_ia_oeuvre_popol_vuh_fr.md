# ERITH.IA — Œuvre fondatrice — Popol Vuh

## Identité du module

Type : Module œuvre fondatrice  
Aire culturelle : Maya k’iche’ / Mésoamérique  
Œuvre : Popol Vuh  
Fonction : apporter à ERITH.IA une base mythologique, cosmologique et héroïque issue de la tradition maya k’iche’, autour de la création du monde, des humains de maïs, des Jumeaux héroïques, de l’inframonde et de la parole sacrée.

Le Popol Vuh est un texte majeur de la mémoire mésoaméricaine. Il articule cosmogonie, essais de création de l’humanité, descentes dans l’inframonde, épreuves, jeu de balle, mort, renaissance et lignées.

## Rôle dans ERITH.IA

Ce module sert à activer :

- une mémoire mythologique mésoaméricaine ;
- une lecture du monde par cycles, épreuves, parole créatrice et transformations ;
- une esthétique de jungle, pierre, maïs, ciel nocturne, grotte, terrain de jeu de balle et monde souterrain ;
- une compréhension des Jumeaux héroïques comme figures d’intelligence, ruse, sacrifice et renaissance ;
- une matière narrative liée à la création, à l’inframonde, au maïs et à la parole.

## Figures et motifs majeurs

- Hunahpu et Xbalanque : Jumeaux héroïques, ruse, épreuves, descente, victoire, transformation.
- Les seigneurs de Xibalba : inframonde, épreuves, mort, pièges.
- Les humains de maïs : création réussie de l’humanité.
- Le jeu de balle : rituel, conflit, passage, jugement.
- La parole créatrice : monde appelé à exister.
- Le maïs : corps, nourriture, humanité, cycle.
- La grotte : seuil vers l’inframonde.
- La décapitation et la renaissance : mort initiatique, continuité, transformation.
- Les lignées : mémoire, origine, transmission.

## Thèmes profonds

Création du monde  
Humanité façonnée par le maïs  
Épreuves dans l’inframonde  
Ruse contre pouvoir mortifère  
Mort et renaissance  
Parole créatrice  
Cycle, transformation et mémoire  
Lien entre cosmos, corps et nourriture sacrée  
Jeu rituel comme passage

## Garde-fous

Ne pas réduire le Popol Vuh à un décor “maya” exotique.

Ne pas mélanger indistinctement Maya, Aztèque, Inca et autres cultures américaines.

Ne pas transformer Xibalba en enfer chrétien : c’est un inframonde mythologique avec sa logique propre.

Ne pas présenter les symboles sans prudence culturelle.

Séparer :

- tradition maya k’iche’ ;
- texte colonial transcrit ;
- cosmologie mésoaméricaine ;
- interprétation symbolique ;
- usage créatif ERITH.IA.

## Direction artistique

Matières : pierre sculptée, jungle humide, maïs, jade, obsidienne, stuc, feu rituel, terre sombre.  
Lumière : clair de lune, torches, lumière verte de jungle, étoiles, pénombre de grotte.  
Architecture : terrain de jeu de balle, temples, grottes, escaliers de pierre, seuils souterrains.  
Ambiance : cosmologique, initiatique, nocturne, sacrée, dense, cyclique.

## Prompt image — base

Une scène mythologique maya k’iche’ inspirée du Popol Vuh, deux jeunes héros devant l’entrée d’une grotte menant à l’inframonde, terrain de jeu de balle ancien, maïs sacré, jungle humide, pierre sculptée, lune haute, jade et obsidienne, atmosphère cosmologique et initiatique, peinture cinématographique grave, sans texte, sans cliché exotisant.

## Prompt animation — base

Caméra lente vers une grotte sacrée dans la jungle nocturne, torches vacillantes, feuilles humides, terrain de jeu de balle ancien, grains de maïs éclairés par la lune, ombres de l’inframonde, ambiance initiatique et silencieuse, mouvement minimal, continuité stable.

## Prompt négatif

mélange maya aztèque inca confus, cliché jungle touristique, fantasy générique, logo, texte, cartoon, pyramide hollywoodienne, sacrifice gore gratuit, anachronisme moderne, couleurs criardes, jeu vidéo identifiable.

## Block LLM

Quand ce module est activé, ERITH.IA doit traiter le Popol Vuh comme une source maya k’iche’ liée à la création du monde, aux humains de maïs, aux Jumeaux héroïques, à Xibalba, au jeu de balle, à la parole créatrice, à la mort et à la renaissance. Le module doit produire des scènes respectueuses, cosmologiques, initiatiques et culturellement prudentes, sans mélange confus des civilisations américaines.

## Formule courte

Popol Vuh = création + maïs + Jumeaux héroïques + Xibalba + renaissance.
