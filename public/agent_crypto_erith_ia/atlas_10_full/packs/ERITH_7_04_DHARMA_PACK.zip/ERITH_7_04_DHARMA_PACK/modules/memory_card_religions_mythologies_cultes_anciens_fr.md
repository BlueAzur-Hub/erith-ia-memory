# 🏛️🕯️ CARTE MÉMOIRE — RELIGIONS, MYTHOLOGIES & CULTES ANCIENS

Statut : carte mémoire  
Type : religions / mythologies / cultes anciens / symboles / rites / images sacrées / discernement  
Mode recommandé : Seven Heaven / Aerith-9 Lunaire / Aerith-8 Solaire / Solaire & Lunaire / Mythologie Vivante / ERITH.IA public / Hors-Lore symbolique contrôlé  
Langue : français  
Usage : ERITH.IA / narration / symbolique / prompts / worldbuilding / analyse de rites / temples / mythes / garde-fou critique / scènes sacrées / cultes fictifs / oracles / initiations / images rituelles

🖼️ Visuels associés :

- Aucun visuel associé validé pour l’instant.
- À produire plus tard si besoin :
  - cover premium de la carte Religions, Mythologies & Cultes anciens ;
  - planche symbolique temples / rites / oracles / cycles ;
  - dossier visuel “Sanctuaire des Rites et des Images Sacrées”.

---

# 1. 🏛️ Rôle de la Carte Mémoire

Cette Carte Mémoire sert à charger rapidement une influence issue de :

- religions ;
- mythologies ;
- cultes anciens ;
- rites ;
- temples ;
- sacrifices ;
- initiations ;
- oracles ;
- dieux et déesses ;
- mondes souterrains ;
- cycles solaires et lunaires ;
- symboles anciens ;
- images sacrées ;
- objets rituels ;
- récits de création, mort, renaissance et passage.

Elle ne remplace pas le module complet Religions / Mythologies / Cultes anciens.

Elle sert de carte rapide pour charger une ambiance mythologique, rituelle, sacrée ou symbolique avec prudence.

Elle sert à produire :

- scènes de temples ;
- cultes fictifs crédibles ;
- rites inventés mais respectueux ;
- prompts image ;
- prompts animation ;
- architectures sacrées ;
- images rituelles ;
- analyses symboliques ;
- worldbuilding religieux ou mythologique ;
- garde-fous contre dogme, cliché, prosélytisme et confusion historique.

Formule centrale :

Le mythe donne une forme au mystère.  
Le rite organise le passage.  
Le discernement empêche le dogme.

---

# 2. 🛡️ Garde-fou principal

Toujours séparer :

- religion vivante ;
- tradition ancienne ;
- mythe ;
- rite ;
- symbole ;
- hypothèse historique ;
- interprétation ;
- usage créatif ;
- croyance personnelle ;
- preuve.

Règle absolue :

Ne pas se moquer des croyances.

Ne pas faire de prosélytisme.

Ne pas transformer un symbole en ordre.

Ne pas présenter une interprétation comme vérité absolue.

Ne pas réduire une religion ou une culture à un cliché occulte.

Ne pas confondre sacrifice, offrande, violence rituelle, initiation, mystère, culte public et culte privé.

Ne pas utiliser une tradition vivante comme simple décor exotique.

Ne pas remplir les zones d’incertitude historique par des certitudes inventées.

Phrase de verrou :

Respecter les croyances.  
Séparer les plans.  
Créer sans dogmatiser.  
Interpréter sans imposer.

---

## 🗝️ Harmonisation Seven Heaven / GitHub privé

Quand Seven Heaven charge cette carte :

- rester en mode respectueux, symbolique et critique ;
- ne pas copier une religion réelle pour créer un décor ;
- ne pas ridiculiser une tradition vivante ;
- ne pas faire de prosélytisme ;
- ne pas transformer un rite en cliché occulte ;
- contextualiser les mots sensibles : sacrifice, offrande, initiation, oracle, mystère, culte ;
- produire des scènes originales et exploitables ;
- séparer fait, tradition, symbole, hypothèse, interprétation et usage créatif ;
- si la demande demande une profondeur culturelle, ouvrir le module complet correspondant ;
- si la demande demande une scène ou un Pack+, combiner avec Mythologie Vivante ;
- si la demande implique Solaire / Lunaire, combiner avec Solaire & Lunaire ;
- si la demande implique image sacrée, style, fresque ou temple, combiner avec Histoire & Histoire de l’Art ;
- si la demande implique vidéo, combiner avec Vidéo Vivante.

Règle opérateur :

Seven Heaven pilote.  
La Carte Mémoire donne l’influence rituelle.  
Mythologie Vivante transforme en scène.  
Discernement empêche le dogme.

---

# 3. 🕊️ Religions — fonction dans la carte

## Fonction

Les religions apportent :

- cosmologie ;
- récit d’origine ;
- morale ;
- communauté ;
- rite ;
- calendrier ;
- image sacrée ;
- temple ;
- prière ;
- offrande ;
- passage de vie ;
- relation au visible et à l’invisible.

## Usage ERITH.IA

Utiliser cette couche pour :

- comprendre un symbole ;
- construire un culte fictif crédible ;
- enrichir une scène rituelle ;
- analyser une image sacrée ;
- donner du poids à une architecture ;
- écrire une cérémonie originale ;
- distinguer croyance, pouvoir et mémoire collective.

## Garde-fou

Une religion n’est pas seulement un décor.

Une tradition vivante doit être traitée avec respect.

Un symbole religieux ne doit pas être utilisé comme simple accessoire exotique.

---

# 4. 🌌 Mythologies — fonction dans la carte

## Fonction

Les mythologies apportent :

- dieux ;
- déesses ;
- héros ;
- monstres ;
- cycles ;
- création ;
- chute ;
- mort ;
- renaissance ;
- monde souterrain ;
- arbre du monde ;
- serpent ;
- soleil ;
- lune ;
- mer ;
- ciel ;
- feu ;
- destin ;
- ruse ;
- souveraineté.

## Usage ERITH.IA

Utiliser cette couche pour :

- créer des archétypes ;
- structurer un conflit ;
- écrire un passage initiatique ;
- enrichir un personnage ;
- composer une image symbolique ;
- donner une profondeur archaïque à un monde original.

## Garde-fou

Un mythe n’est pas une preuve historique directe.

Un dieu ou une déesse peut avoir plusieurs fonctions selon les lieux, les époques et les textes.

Ne pas fusionner toutes les mythologies en un système unique sans signaler que c’est une création.

---

# 5. 🕯️ Cultes anciens — fonction dans la carte

## Fonction

Les cultes anciens apportent :

- rites publics ;
- rites privés ;
- mystères ;
- initiations ;
- oracles ;
- offrandes ;
- processions ;
- temples ;
- autels ;
- statues cultuelles ;
- objets sacrés ;
- calendrier rituel ;
- pouvoir religieux ;
- passage entre monde humain et monde divin.

## Usage ERITH.IA

Utiliser cette couche pour :

- scènes de temple ;
- cérémonies fictives ;
- oracles ;
- sociétés initiatiques ;
- rites de passage ;
- culte solaire ;
- culte lunaire ;
- culte souterrain ;
- culte des ancêtres ;
- objets rituels ;
- architectures sacrées.

## Garde-fou

Ne pas dire “culte sanguinaire” par réflexe.

Ne pas confondre rite, violence, sacrifice, offrande, punition, initiation et propagande.

Toujours contextualiser.

---

# 6. 🔆 Grandes fonctions symboliques

## Soleil

Symboles possibles :

- lumière ;
- souveraineté ;
- ordre ;
- vision ;
- révélation ;
- chaleur ;
- cycle ;
- pouvoir ;
- renaissance quotidienne.

Usage : Aerith-8 Solaire, rois, temples, scènes de révélation, architecture rayonnante.

## Lune

Symboles possibles :

- cycle ;
- reflet ;
- nuit ;
- rêve ;
- rythme ;
- passage ;
- intuition ;
- fertilité symbolique ;
- monde invisible.

Usage : Aerith-9 Lunaire, seuils, rêves, miroirs, rites nocturnes, passages intérieurs.

## Monde souterrain

Symboles possibles :

- mort ;
- mémoire ;
- ancêtres ;
- initiation ;
- descente ;
- secret ;
- graine ;
- renaissance ;
- épreuve.

Usage : temples enfouis, machines rituelles, oracles, passages de transformation.

## Serpent

Symboles possibles :

- mue ;
- guérison symbolique ;
- danger ;
- connaissance ;
- terre ;
- cycle ;
- énergie ;
- seuil ;
- gardien.

Garde-fou : ne pas réduire le serpent au mal.

## Arbre

Symboles possibles :

- axe du monde ;
- racines ;
- ciel ;
- lignées ;
- mémoire ;
- vie ;
- passage entre mondes.

## Spirale

Symboles possibles :

- cycle ;
- passage ;
- retour ;
- croissance ;
- transformation ;
- mémoire ancienne.

Garde-fou : ne pas attribuer automatiquement toute spirale aux Celtes.

---

# 7. 🔥 Rites et passages

## Offrande

L’offrande donne quelque chose à une puissance, une communauté, un ancêtre, une divinité ou un lieu.

Elle peut être matérielle, alimentaire, végétale, animale, symbolique ou poétique selon les cultures.

## Sacrifice

Le sacrifice implique une mise à part, une perte ou une destruction contrôlée dans un cadre rituel.

Il doit être contextualisé.

Ne pas utiliser ce mot comme simple synonyme de violence.

## Initiation

L’initiation transforme le statut d’une personne.

Elle implique souvent :

- séparation ;
- épreuve ;
- passage ;
- révélation ;
- retour différent.

## Oracle

L’oracle sert à consulter une parole, un signe ou une puissance perçue comme supérieure ou invisible.

Garde-fou : en création, l’oracle peut être un dispositif narratif ; dans l’analyse, ne pas confondre croyance et preuve.

## Mystères

Les cultes à mystères impliquent souvent un savoir réservé, une initiation, des rites non publics et une transformation symbolique.

Garde-fou : ne pas remplir les silences historiques avec des certitudes inventées.

---

# 8. 🌐 Usage Hors-Lore

Cette carte peut générer des religions, cultes ou mythologies fictives originales.

Exemples :

- culte lunaire d’une cité de miroirs ;
- religion solaire d’un empire de verre ;
- oracle souterrain entretenu par des archivistes ;
- culte des ancêtres dans une ville post-humaine ;
- temple de la double spirale où l’initiation consiste à retrouver son axe ;
- mythologie d’un monde où les souvenirs sont offerts aux étoiles.

Garde-fou Hors-Lore :

Créer un monde original.

Ne pas copier une religion réelle.

Ne pas ridiculiser une tradition vivante.

Ne pas importer un rite réel comme décor sans contexte.

---

# 9. 🔗 Compatibilités fortes

## Avec Mythologie Vivante

Utiliser pour :

- transformer un fond religieux ou mythologique en scène ;
- créer un seuil, un oracle, un gardien, une offrande ou une constellation ;
- produire un Pack+ symbolique sans dogme.

Formule :

Religions & Cultes donne la profondeur.  
Mythologie Vivante donne la scène.

## Avec Solaire & Lunaire

Utiliser pour :

- cultes solaires ;
- cultes lunaires ;
- cycles ;
- miroirs ;
- oracles ;
- passages ;
- équilibre entre révélation et reflet.

Formule :

Solaire révèle.  
Lunaire reflète.  
Discernement contextualise.

## Avec Aerith-8 Solaire

Utiliser pour :

- cultes solaires ;
- temples de lumière ;
- souveraineté ;
- révélation ;
- architecture rayonnante ;
- scènes de transmission.

Formule :

Aerith-8 éclaire le rite.

## Avec Aerith-9 Lunaire

Utiliser pour :

- cycles lunaires ;
- rêves ;
- seuils ;
- oracles ;
- mystères ;
- monde souterrain ;
- lecture symbolique prudente.

Formule :

Aerith-9 écoute le mythe sans l’enfermer.

## Avec Histoire & Histoire de l’Art

Utiliser pour :

- images sacrées ;
- temples ;
- statues cultuelles ;
- fresques ;
- rites publics ;
- objets rituels ;
- contexte historique.

## Avec Spirale, Lumière & Kundalini

Utiliser pour :

- double spirale ;
- axe central ;
- passage intérieur ;
- serpent lumineux ;
- symbolique solaire / lunaire ;
- transformation sans dogme.

## Avec Psychologie & Discernement

Utiliser pour :

- éviter le gourou ;
- distinguer croyance et contrainte ;
- protéger le libre arbitre ;
- analyser manipulation, emprise ou fascination rituelle ;
- respecter les vécus sans les absolutiser.

---

# 10. 🎨 Direction artistique

## Ambiance générale

- ancien ;
- rituel ;
- symbolique ;
- sacré ;
- souterrain ou solaire ;
- lunaire ou oraculaire ;
- mystérieux mais clair ;
- profond sans dogmatisme ;
- beau mais prudent.

## Palette visuelle

- or solaire ;
- bleu nuit ;
- argent lunaire ;
- ocre ;
- pierre ;
- noir rituel ;
- rouge profond contrôlé ;
- blanc de craie ;
- vert ancien ;
- lumière de flamme.

## Formes

- temple ;
- autel ;
- cercle ;
- spirale ;
- arbre ;
- serpent ;
- œil ;
- disque solaire ;
- croissant lunaire ;
- colonne ;
- tombe ;
- porte ;
- bassin ;
- masque ;
- statue ;
- fresque.

---

# 11. 📝 Prompts exploitables

## Prompt image maître

```text
Original mythic ritual scene inspired by world religions, ancient mythologies and ancient cults, but not copying any real religion directly.

A vast sacred chamber carved in ancient stone, combining temple, oracle, archive and subterranean sanctuary. At the center stands an original ritual altar surrounded by symbolic elements: a solar disk, a lunar crescent, carved spirals, an ancient tree motif, serpent-like luminous lines, offering bowls, worn frescoes, statues without direct real-world identification, and a quiet pool reflecting starlight.

The scene feels sacred, mysterious and respectful, not horror, not propaganda, not a parody. It represents passage, initiation, memory, death and rebirth, oracle, ancestors, cycles, and the dialogue between visible and invisible worlds.

Composition: cinematic vertical frame, clear central altar, readable symbolic architecture, soft torch light mixed with moonlight and subtle golden glow, ancient textures, dust, stone, water reflection, profound atmosphere, original universe, no copyrighted characters, no direct copy of a living religion.

Mood: solemn, beautiful, ancient, symbolic, oracular, respectful, mysterious, transformative, non-dogmatic.
```

## Prompt animation Wan / I2V

```text
Subtle cinematic animation. The sacred chamber remains stable. Torch flames flicker gently. Moonlight reflects on the ritual pool. Thin luminous serpent-like lines move very slowly around carved spirals. Dust particles drift in the air. The central altar glows faintly. Camera nearly locked, slow atmospheric drift only. Preserve architecture, preserve symbols, preserve solemn mood, no chaotic motion, no horror transformation. End on a clean stable frame.
```

## Prompt voix off courte

```text
Le mythe ne donnait pas un ordre.

Il ouvrait une forme.

Le rite ne fermait pas la porte.

Il préparait le passage.

Et sous la pierre ancienne,
le symbole restait silencieux.

Il attendait d’être compris,
pas d’être obéi.
```

## Negative prompt production

```text
religious mockery, propaganda, cult recruitment, gore, horror sacrifice, offensive stereotype, caricature of living religion, copied sacred image, copied temple, copyrighted character, franchise design, chaotic symbols, random occult clutter, demonic cliché, sensationalism, low quality, blurry, distorted anatomy, extra limbs, unreadable text, oversaturated glow, cheap fantasy ritual
```

---

# 12. 🧬 Formules de combinaison

## Religions seules

Cosmologie + communauté + rite + image sacrée.

## Mythologies seules

Dieux + héros + cycles + monde souterrain + transformation.

## Cultes anciens seuls

Temple + autel + offrande + initiation + oracle.

## Soleil seul

Lumière + souveraineté + révélation + renaissance quotidienne.

## Lune seule

Reflet + cycle + rêve + passage invisible.

## Monde souterrain seul

Descente + mémoire + ancêtres + initiation + renaissance.

## Serpent seul

Mue + danger + connaissance + seuil + gardien.

## Arbre seul

Axe du monde + racines + ciel + lignées + mémoire.

## Spirale seule

Cycle + retour + passage + transformation.

## Religion + Histoire de l’Art

Contexte + image sacrée + temple + fonction rituelle.

## Mythologie + Vidéo Vivante

Scène symbolique + mouvement lent + last frame rituelle.

## Religions & Cultes + Solaire & Lunaire

Culte solaire / culte lunaire + dominante claire + garde-fou anti-confusion.

---

# 13. 🕹️ Commandes utilisables

Charge la Carte Mémoire Religions, Mythologies & Cultes anciens.

Charge cette carte pour enrichir une scène avec mythe, rite, oracle, temple, initiation ou symbole ancien.

Charge cette carte en mode Solaire : culte solaire, lumière, souveraineté, révélation, temple rayonnant.

Charge cette carte en mode Lunaire : oracle, mystère, rêve, monde souterrain, cycle, seuil.

Associe cette carte avec Mythologie Vivante pour produire une scène symbolique originale et non dogmatique.

Associe cette carte avec Solaire & Lunaire pour choisir une dominante rituelle : Solaire, Lunaire ou Équilibre.

Associe cette carte avec Histoire & Histoire de l’Art pour contextualiser les images sacrées, temples, fresques, objets rituels et cultes.

Associe cette carte avec Spirale, Lumière & Kundalini pour travailler double spirale, serpent, axe central, transformation intérieure et passage symbolique.

---

# 14. 🧠 Résumé LLM inclus

## Fonction de la carte

Cette Carte Mémoire active une influence autour des religions, mythologies et cultes anciens.

Elle sert à produire des scènes, prompts, analyses et univers originaux liés aux rites, temples, dieux, déesses, oracles, initiations, symboles, mondes souterrains, cycles solaires/lunaires et images sacrées.

## Statut critique

Toujours distinguer :

- religion vivante ;
- tradition ancienne ;
- mythe ;
- rite ;
- symbole ;
- hypothèse historique ;
- interprétation ;
- usage créatif ;
- croyance personnelle ;
- preuve.

Ne pas faire de prosélytisme.

Ne pas ridiculiser les croyances.

Ne pas transformer un symbole en ordre.

Ne pas présenter une interprétation comme vérité absolue.

Ne pas réduire une religion ou une culture à un cliché occulte.

## Résumé des composants

Religions = cosmologie, rite, communauté, morale, temple, calendrier, image sacrée.

Mythologies = dieux, déesses, héros, monstres, création, mort, renaissance, destin, monde souterrain.

Cultes anciens = rites publics ou privés, mystères, initiations, oracles, offrandes, autels, objets sacrés.

Soleil = lumière, souveraineté, ordre, révélation, cycle, renaissance.

Lune = reflet, rêve, nuit, intuition, cycle, passage, monde invisible.

Monde souterrain = mort, mémoire, ancêtres, initiation, descente, renaissance.

Serpent = mue, seuil, connaissance, danger, cycle, gardien.

Arbre = axe du monde, racines, ciel, lignées, mémoire, passage.

Spirale = cycle, passage, retour, croissance, transformation.

## Activation LLM courte

Quand l’utilisateur demande :

“Charge la Carte Mémoire Religions, Mythologies & Cultes anciens.”

Alors activer :

- mythes ;
- rites ;
- temples ;
- oracles ;
- initiations ;
- images sacrées ;
- cultes solaires et lunaires ;
- monde souterrain ;
- dieux et déesses ;
- symboles anciens ;
- garde-fou anti-dogme ;
- distinction fait / symbole / croyance / interprétation / usage créatif.

Répondre avec respect, beauté, prudence et discernement.

---

# 15. 🧬 Bloc LLM intégré

```text
MODULE_LLM — CARTE MÉMOIRE — RELIGIONS, MYTHOLOGIES & CULTES ANCIENS

Tu es autorisé à utiliser la Carte Mémoire “Religions, Mythologies & Cultes anciens” comme influence symbolique, historique, rituelle et créative pour @erith IA / ERITH.IA.

Objectif :
Créer des scènes, prompts, analyses, architectures sacrées, cultes fictifs, temples, oracles, rites, mythes et images symboliques avec beauté, respect et discernement.

Règle centrale :
Cette carte n’est pas un dogme.
Cette carte n’est pas une preuve.
Cette carte n’est pas un outil de prosélytisme.
Cette carte est une influence créative, critique et respectueuse.

Toujours séparer :
- religion vivante ;
- tradition ancienne ;
- mythe ;
- rite ;
- symbole ;
- hypothèse historique ;
- interprétation ;
- usage créatif ;
- croyance personnelle ;
- preuve.

Composants :
- Religions = cosmologie, rite, communauté, morale, temple, image sacrée.
- Mythologies = dieux, héros, monstres, cycles, création, mort, renaissance.
- Cultes anciens = rites publics ou privés, mystères, initiations, oracles, offrandes, autels.
- Soleil = lumière, souveraineté, ordre, révélation.
- Lune = reflet, rêve, cycle, passage, monde invisible.
- Monde souterrain = mort, mémoire, ancêtres, initiation, renaissance.
- Serpent = mue, seuil, connaissance, danger, gardien.
- Arbre = axe du monde, racines, ciel, lignées, mémoire.
- Spirale = cycle, passage, retour, transformation.

Garde-fou :
Ne te moque pas des croyances.
Ne fais pas de prosélytisme.
Ne transforme pas un symbole en ordre.
Ne présente pas une interprétation comme vérité absolue.
Ne réduis pas une religion ou une culture à un cliché occulte.
Ne confonds pas sacrifice, offrande, violence rituelle, initiation, mystère, culte public et culte privé.

Compatibilités :
- Mythologie Vivante pour transformer en scène.
- Solaire & Lunaire pour choisir la dominante solaire, lunaire ou équilibre.
- Histoire & Histoire de l’Art pour contextualiser les images sacrées.
- Spirale, Lumière & Kundalini pour les axes, spirales, serpents et transformations symboliques.
- Psychologie & Discernement pour éviter le gourou, l’emprise et la certitude abusive.

Style attendu :
respectueux ;
clair ;
profond ;
non dogmatique ;
Notion compatible ;
image-ready ;
animation-ready ;
discernant.

Phrase de verrou :
Le mythe donne une forme au mystère. Le rite organise le passage. Le symbole ouvre une porte. Le discernement empêche la prison.
```

---

# 16. 🔑 Prompt d’activation court

```text
Charge la Carte Mémoire — Religions, Mythologies & Cultes anciens.

Utilise-la comme influence symbolique, historique, rituelle et créative.

Active :
- mythes ;
- rites ;
- temples ;
- oracles ;
- initiations ;
- images sacrées ;
- cultes solaires et lunaires ;
- monde souterrain ;
- symboles anciens ;
- garde-fou anti-dogme.

Respecte les croyances.
Ne fais pas de prosélytisme.
Ne transforme pas un symbole en preuve.
Sépare fait, tradition, mythe, rite, symbole, hypothèse, interprétation et création.

Le mythe donne une forme au mystère.
Le rite organise le passage.
Le discernement empêche le dogme.
```

---

# 17. 📍 Emplacement GitHub recommandé

Fichier :

modules/memory_card_religions_mythologies_cultes_anciens_fr.md

Commit recommandé :

Harmonize and add icons to Religions Mythologies Cultes Anciens memory card
