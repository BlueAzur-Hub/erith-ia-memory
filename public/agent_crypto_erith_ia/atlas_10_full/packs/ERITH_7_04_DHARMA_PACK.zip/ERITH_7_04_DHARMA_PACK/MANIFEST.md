# ERITH-7 — Dharma Pack

Pack: ERITH_7_04_DHARMA_PACK

## Rôle
Mahabharata, Ramayana, dette morale, devoir, guerre intérieure, symboles et choix impossibles.

## Fichiers inclus

- core/SEVEN_TOP_OF_MIND.md
- memory_cards/EMOTIONAL_ARCS_CARD.md
- memory_cards/HERO_ARCHETYPES_CARD.md
- memory_cards/NARRATION_AND_DIALOGUE_CARD.md
- memory_cards/OBSTACLES_AND_ANTAGONISTS_CARD.md
- memory_cards/QUEST_OBJECTS_CARD.md
- memory_cards/STORY_ENGINE_CARD.md
- modules/erith_ia_philosophie_verite_liberte_fr.md
- modules/erith_ia_psychologie_discernement_fr.md
- modules/mahabharata.md
- modules/memory_card_religions_mythologies_cultes_anciens_fr.md
- modules/memory_cards_mythologie_vivante_fr.md
- modules/ramayana.md
