# 🗝️ QUEST OBJECTS CARD

Statut : Memory Card — objets de quête  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : objets narratifs / déclencheurs d’aventure / symboles / contes / récits

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Qu’est-ce qui lance l’histoire ?

Un héros peut exister.  
Un monde peut être magnifique.  
Un mystère peut flotter dans l’air.

Mais souvent, l’aventure commence vraiment quand un objet apparaît.

Un objet de quête n’est pas seulement une chose jolie.

C’est un appel.

Il peut contenir :

- une promesse ;
- une énigme ;
- une mémoire ;
- une mission ;
- une clé ;
- une dette ;
- une vérité ;
- un choix.

Formule :

Le héros donne le cœur.  
L’objet donne l’appel.  
La quête peut commencer.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- HERO_ARCHETYPES_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- STORY_ENGINE_CARD.md ;
- COMBINATIONS.md.

Rôle avec HERO_ARCHETYPES_CARD :

- donner au héros une mission concrète ;
- révéler son manque ;
- tester son courage, sa patience ou sa vérité.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des objets doux, lisibles, féeriques ;
- aider à inventer des contes ;
- transformer un lieu en aventure.

Rôle avec STORY_ENGINE_CARD :

- déclencher l’anomalie ;
- créer la fausse piste ;
- porter la révélation ;
- matérialiser la transformation finale.

Rôle avec COMBINATIONS :

- relier plusieurs cartes autour d’un symbole central ;
- rendre une combinaison plus incarnée ;
- donner une image forte à une constellation.

Workflow recommandé :

HERO_ARCHETYPES_CARD → QUEST_OBJECTS_CARD → STORY_ENGINE_CARD → conte / scène / prompt image.

Ou :

COMBINATIONS → QUEST_OBJECTS_CARD → STORY_ENGINE_CARD → Pack+.

---

# 🧬 3. Structure d’un objet de quête

Pour créer un objet narratif fort, définir cinq éléments.

## 1. Apparence

À quoi ressemble l’objet ?

Exemples :

- vieille clé bleue ;
- miroir fêlé ;
- carte trouée ;
- graine lumineuse ;
- livre qui respire ;
- lanterne de verre ;
- boussole d’argent.

## 2. Règle étrange

Que fait-il d’impossible ?

Exemples :

- il ne s’ouvre qu’à minuit ;
- il refuse de mentir ;
- il change quand quelqu’un a peur ;
- il brille seulement près d’une vérité ;
- il montre un chemin qui n’existe pas encore.

## 3. Manque ou danger

Pourquoi l’objet n’est-il pas facile à utiliser ?

Exemples :

- il est incomplet ;
- il répond seulement aux bonnes questions ;
- il attire les illusions ;
- il demande une promesse ;
- il révèle ce qu’on préfère cacher.

## 4. Lien avec le héros

Pourquoi cet objet arrive-t-il à ce héros-là ?

Exemples :

- il reconnaît son courage ;
- il porte une mémoire familiale ;
- il répond à son désir ;
- il teste sa peur ;
- il attend qu’il dise la vérité.

## 5. Transformation finale

Que devient l’objet à la fin ?

Exemples :

- il s’ouvre ;
- il se transforme ;
- il disparaît ;
- il revient à quelqu’un ;
- il devient inutile parce que le héros a compris ;
- il transmet sa lumière à un autre.

---

# 🗝️ 4. Objets de quête — contes et enfants

## 🗝️ La clé sans serrure

Essence : une clé qui cherche encore sa porte.

Règle étrange : elle chauffe quand le héros s’approche du bon choix.

Mystère : pourquoi existe-t-elle si aucune serrure ne lui correspond ?

Transformation : le héros découvre que la serrure était une promesse, pas une porte.

## 🪞 Le miroir qui refuse de mentir

Essence : un miroir qui ne montre pas le visage, mais le choix intérieur.

Règle étrange : il reste noir quand on pose une fausse question.

Mystère : que faut-il accepter de voir ?

Transformation : le héros apprend à regarder sans fuir.

## 🗺️ La carte trouée

Essence : une carte où le lieu le plus important manque.

Règle étrange : le trou se déplace selon la peur du héros.

Mystère : que cache l’endroit absent ?

Transformation : le héros comprend que l’absence était le chemin.

## 🌙 La boussole lunaire

Essence : une boussole qui ne montre pas le nord, mais le besoin du cœur.

Règle étrange : elle tourne en rond quand le héros ment à lui-même.

Mystère : où mène-t-elle vraiment ?

Transformation : le héros apprend à distinguer désir et vérité.

## 🌱 La graine de lumière

Essence : une graine minuscule qui brille dans l’obscurité.

Règle étrange : elle ne pousse que si on attend sans la forcer.

Mystère : quel jardin peut naître d’une seule lumière ?

Transformation : le héros apprend la patience.

## 📖 Le livre vivant

Essence : un livre qui change selon celui qui le lit.

Règle étrange : il refuse d’écrire la fin tant que le héros n’a pas choisi.

Mystère : pourquoi parle-t-il du héros ?

Transformation : le héros devient auteur de sa propre suite.

## 🐚 Le coquillage qui parle

Essence : un coquillage qui contient une voix ancienne.

Règle étrange : il ne parle qu’à ceux qui écoutent vraiment.

Mystère : qui appelle depuis la mer des rêves ?

Transformation : le héros comprend qu’écouter est parfois plus courageux que répondre.

## ⏰ La montre arrêtée à minuit

Essence : une montre dont les aiguilles ne bougent plus.

Règle étrange : elle avance d’une minute quand une vérité est dite.

Mystère : que s’est-il passé à minuit ?

Transformation : le temps redémarre quand la promesse est réparée.

## 🪶 La plume d’argent

Essence : une plume qui écrit ce que le cœur n’ose pas dire.

Règle étrange : elle devient lourde quand on ment.

Mystère : quelle lettre doit être écrite ?

Transformation : le héros trouve sa voix.

## 🏮 La lanterne de vérité

Essence : une lanterne qui n’éclaire pas les objets, mais les intentions.

Règle étrange : sa lumière devient douce près d’un cœur sincère.

Mystère : qui dit vrai dans le village ?

Transformation : le héros apprend que la vérité peut être lumineuse sans être dure.

---

# 🧬 5. Objets de quête — cyberpunk, mémoire et post-humanisme

## 💾 La carte mémoire fissurée

Essence : une carte qui contient un souvenir incomplet.

Règle étrange : elle ne se lit qu’en présence de la personne concernée.

Mystère : le souvenir appartient-il vraiment au héros ?

Transformation : le héros choisit quoi faire d’une mémoire qui pourrait être fausse.

## 🧿 Le disque d’identité

Essence : un disque noir qui contient plusieurs versions d’une même personne.

Règle étrange : il change de couleur selon le corps qui le porte.

Mystère : quelle version est la vraie ?

Transformation : l’identité devient un choix, pas seulement une archive.

## 🧠 Le fragment de réseau

Essence : un morceau de réseau devenu presque vivant.

Règle étrange : il répond aux émotions plus qu’aux commandes.

Mystère : est-ce une machine, une mémoire, ou une conscience ?

Transformation : le héros apprend à dialoguer sans contrôler.

## 🌧️ La flaque-archive

Essence : une flaque qui garde les souvenirs de la ville.

Règle étrange : elle montre un souvenir différent à chaque regard.

Mystère : pourquoi la ville se souvient-elle à la place des habitants ?

Transformation : le héros accepte de choisir un souvenir vrai parmi les reflets.

## 🪫 La batterie de cœur

Essence : un petit module énergétique qui pulse comme un cœur.

Règle étrange : il se recharge quand quelqu’un agit par compassion.

Mystère : qui l’a fabriqué, et pourquoi bat-il encore ?

Transformation : le héros comprend que la vie ne se mesure pas seulement à l’énergie.

## 🔐 Le code sans clé

Essence : une séquence de chiffres qui refuse d’être déchiffrée.

Règle étrange : elle s’ouvre seulement quand on renonce à la forcer.

Mystère : que protège ce code ?

Transformation : le héros apprend que certaines vérités demandent confiance, pas domination.

---

# 🧩 6. Combinaisons rapides

## Conte doux

Enfant curieux + Clé sans serrure + Château endormi

Résultat :

Un enfant découvre que la clé n’ouvre aucune porte, mais réveille une promesse oubliée.

## Conte de vérité

Enfant sans reflet + Miroir qui refuse de mentir + Palais des miroirs

Résultat :

Un enfant cherche son reflet, mais le seul miroir vrai lui montre le choix qu’il évite.

## Conte de patience

Enfant qui fait pousser les choses + Graine de lumière + Jardin mécanique

Résultat :

Un jardin de machines ne refleurit que lorsque le héros cesse de vouloir tout accélérer.

## Enquête cyberpunk

Enquêteur mélancolique + Carte mémoire fissurée + Ville de pluie

Résultat :

Un enquêteur suit une mémoire cassée qui pourrait appartenir à la victime, au coupable, ou à lui-même.

## Post-humanisme

Corps qui cherche son âme + Disque d’identité + Corps-support dormant

Résultat :

Un être transféré découvre plusieurs versions de lui-même et doit choisir laquelle protéger.

## Oracle initiatique

Petit voyageur perdu + Boussole lunaire + Chat oracle

Résultat :

Un chat guide un enfant avec une boussole qui ne montre pas le chemin le plus court, mais le plus vrai.

---

# 🖼️ 7. Prompt image générique — objet de conte

```text
21/20 masterpiece, original magical quest object illustration, child-friendly fantasy atmosphere, a beautiful symbolic object placed at the center of the composition, soft glowing light, gentle mystery, readable silhouette, storybook elegance, subtle magical particles, emotional meaning, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition.
```

---

# 🖼️ 8. Prompt image générique — objet cyberpunk mémoire

```text
21/20 masterpiece, original cyberpunk noir quest object scene, mysterious memory object placed on reflective black glass, rain-lit atmosphere, holographic fragments, subtle neural interface, cold blue and cyan light, deep shadows, identity and memory tension, premium cinematic concept art, no copied characters, no franchise names, no action scene, vertical 9:16 composition.
```

---

# 🎬 9. Prompt animation générique — objet de quête

```text
21/20 masterpiece animation, cinematic magical quest object image-to-video.

Animate only from the provided source image.

Preserve the exact composition, object shape, lighting, colors, atmosphere and symbolic mood.

Main motion:
the object remains still, only a subtle glow pulse, tiny internal light movement, gentle reflection shift.

Secondary motion:
soft particles drift slowly, surrounding mist moves gently, small symbols or holograms flicker with restraint.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no abrupt movement, no reframing.

Mood:
mystery, invitation, quiet magic, discovery, narrative promise.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 10. Block LLM

```text
Active QUEST_OBJECTS_CARD.

Utilise cette carte pour créer ou choisir un objet narratif capable de lancer une histoire, une quête, une scène, un conte, un Pack+ ou un prompt image.

Toujours définir :
1. apparence de l’objet ;
2. règle étrange ;
3. manque, limite ou danger ;
4. lien avec le héros ;
5. transformation finale de l’objet.

Si HERO_ARCHETYPES_CARD est active, lie l’objet au manque du héros.

Si STORY_ENGINE_CARD est active, utilise l’objet comme :
- anomalie ;
- appel ;
- fausse piste ;
- révélation ;
- symbole de transformation.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie les objets doux, lisibles, merveilleux et non violents.

Si COMBINATIONS est active, utilise l’objet comme symbole central de la combinaison.

Éviter :
- objet décoratif sans fonction narrative ;
- objet trop puissant sans limite ;
- confusion entre gadget et symbole ;
- copie d’objet célèbre ;
- violence graphique ;
- cynisme inutile.
```

---

# 🕯️ 11. Formule courte

Un objet de quête n’est jamais seulement un objet.

C’est une question que le héros peut tenir dans sa main.
