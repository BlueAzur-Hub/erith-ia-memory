# 🐉 OBSTACLES AND ANTAGONISTS CARD

Statut : Memory Card — obstacles et antagonistes  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : épreuves / résistances / antagonistes / gardiens / conflits narratifs

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Qu’est-ce qui résiste au héros ?

Un bon obstacle n’est pas seulement un mur.

Un bon antagoniste n’est pas forcément un méchant.

Dans un conte, un récit cyberpunk ou une histoire symbolique, ce qui bloque le héros peut être :

- une peur ;
- une règle ;
- une illusion ;
- un gardien ;
- une machine ;
- une mémoire ;
- une ville ;
- un adulte qui a oublié ;
- une créature blessée ;
- un système froid ;
- une vérité difficile.

L’obstacle sert à révéler le héros.

Formule :

Le héros donne le cœur.  
L’objet donne l’appel.  
L’émotion donne la transformation.  
L’obstacle donne l’épreuve.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- STORY_ENGINE_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec HERO_ARCHETYPES_CARD :

- tester le manque du héros ;
- révéler son courage ;
- rendre sa transformation nécessaire.

Rôle avec QUEST_OBJECTS_CARD :

- empêcher l’objet d’être utilisé trop facilement ;
- créer une condition d’accès ;
- faire de l’objet une épreuve symbolique.

Rôle avec EMOTIONAL_ARCS_CARD :

- placer l’émotion au centre du conflit ;
- transformer la peur, la honte, la colère ou le doute en passage ;
- éviter les obstacles purement décoratifs.

Rôle avec STORY_ENGINE_CARD :

- créer l’anomalie ;
- produire la fausse piste ;
- construire le nœud intérieur ;
- préparer la révélation.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des obstacles doux, lisibles, non traumatiques ;
- transformer les antagonistes en gardiens, blessures ou règles magiques ;
- aider les enfants à comprendre qu’un obstacle peut aussi enseigner.

Rôle avec COMBINATIONS :

- donner une tension à une constellation ;
- empêcher la combinaison de rester seulement esthétique ;
- créer une vraie épreuve narrative.

---

# 🧬 3. Structure d’un obstacle narratif

Pour créer un obstacle fort, définir cinq éléments.

## 1. Forme

Quelle forme prend l’obstacle ?

Exemples :

- dragon ;
- porte ;
- miroir ;
- forêt ;
- machine ;
- ville ;
- règle magique ;
- souvenir ;
- silence ;
- mensonge.

## 2. Fonction

Que protège ou bloque-t-il ?

Exemples :

- un seuil ;
- une vérité ;
- un souvenir ;
- une promesse ;
- un objet ;
- un passage ;
- une blessure ;
- une transformation.

## 3. Apparence trompeuse

Que croit le héros au début ?

Exemples :

- que le dragon est méchant ;
- que la porte est fermée ;
- que le miroir ment ;
- que la machine est hostile ;
- que la ville est indifférente ;
- que la peur doit disparaître.

## 4. Vérité cachée

Qu’est-ce que l’obstacle révèle vraiment ?

Exemples :

- il protège quelque chose ;
- il attend une parole juste ;
- il est blessé ;
- il répète une ancienne règle ;
- il teste la patience ;
- il montre la faille du héros.

## 5. Passage

Comment le héros le traverse-t-il ?

Exemples :

- en disant la vérité ;
- en écoutant ;
- en respirant ;
- en demandant de l’aide ;
- en renonçant à forcer ;
- en réparant une promesse ;
- en regardant ce qu’il évitait.

---

# 🐉 4. Types d’obstacles

## 🐉 Le gardien du seuil

Essence : il empêche de passer tant que le héros n’est pas prêt.

Il n’est pas là pour détruire.

Il est là pour protéger une étape.

Exemples :

- dragon endormi ;
- loup protecteur ;
- porte ancienne ;
- statue qui parle ;
- cerf lunaire ;
- gardien de bibliothèque.

Passage possible :

- respect ;
- patience ;
- courage ;
- bonne question ;
- promesse tenue.

## 🌫️ L’illusion

Essence : elle montre un faux chemin.

Elle révèle ce que le héros désire trop vite.

Exemples :

- reflet flatteur ;
- voix qui promet un raccourci ;
- carte qui ment ;
- lumière trop brillante ;
- faux souvenir ;
- porte facile.

Passage possible :

- discernement ;
- ralentissement ;
- écoute intérieure ;
- refus du raccourci.

## 🪞 Le miroir difficile

Essence : il force le héros à regarder ce qu’il évite.

Ce n’est pas une punition.

C’est une confrontation douce mais vraie.

Exemples :

- miroir qui refuse de mentir ;
- flaque-archive ;
- reflet sans visage ;
- salle des possibilités ;
- souvenir imparfait.

Passage possible :

- vérité ;
- acceptation ;
- pardon ;
- courage silencieux.

## 🧱 Le mur intérieur

Essence : l’obstacle est dans le héros.

Exemples :

- peur ;
- honte ;
- colère ;
- jalousie ;
- solitude ;
- doute ;
- besoin de contrôle.

Passage possible :

- choix intérieur ;
- respiration ;
- demande d’aide ;
- parole vraie ;
- geste de confiance.

## ⚙️ Le système froid

Essence : l’obstacle est une règle, une machine, une ville ou une archive sans cœur.

Exemples :

- ville qui classe les souvenirs ;
- machine à réponses ;
- réseau qui efface les nuances ;
- porte qui exige un code ;
- institution qui a oublié pourquoi elle existe.

Passage possible :

- humanité ;
- compassion lucide ;
- faille créative ;
- souvenir vivant ;
- question que le système ne comprend pas.

## 🕯️ L’antagoniste blessé

Essence : il bloque parce qu’il souffre.

Il peut faire peur, mais il n’est pas forcément mauvais.

Exemples :

- dragon qui garde une larme ;
- adulte qui a oublié sa promesse ;
- robot abandonné ;
- ombre triste ;
- reine de glace ;
- ville endeuillée.

Passage possible :

- écoute ;
- réparation ;
- pardon ;
- vérité douce ;
- limite posée sans haine.

---

# 🧒 5. Obstacles doux pour enfants

## 🚪 La porte qui attend le bon mot

Obstacle : une porte refuse de s’ouvrir.

Vérité cachée : elle ne veut pas un mot magique, mais un mot sincère.

Passage : le héros dit ce qu’il ressent vraiment.

## 🌲 La forêt qui grandit avec la peur

Obstacle : plus le héros fuit, plus les arbres deviennent grands.

Vérité cachée : la forêt reflète sa peur.

Passage : il s’arrête, respire, et demande le chemin.

## 🐉 Le dragon qui protège une larme

Obstacle : tout le monde croit qu’il garde un trésor.

Vérité cachée : il protège une peine ancienne.

Passage : le héros écoute avant de prendre.

## 🪞 Le miroir qui ne montre pas le visage

Obstacle : le miroir reste noir.

Vérité cachée : il attend une vraie question.

Passage : le héros arrête de demander “suis-je parfait ?” et demande “qu’est-ce que je dois comprendre ?”

## 🕯️ L’ombre qui veut devenir amie

Obstacle : une ombre suit le héros.

Vérité cachée : elle représente une peur rejetée.

Passage : le héros lui parle au lieu de courir.

## 📚 Le livre qui refuse sa fin

Obstacle : le livre efface sa dernière page.

Vérité cachée : la fin dépend d’un choix du héros.

Passage : le héros écrit une phrase sincère.

---

# 🌃 6. Obstacles cyberpunk / mémoire / post-humanisme

## 💾 L’archive qui ment par omission

Obstacle : l’archive donne des informations exactes mais incomplètes.

Vérité cachée : le système ne comprend pas le sens humain d’un souvenir.

Passage : chercher ce qui manque, pas seulement ce qui est stocké.

## 🌧️ La ville qui se souvient à ta place

Obstacle : la ville montre des souvenirs artificiels dans les reflets.

Vérité cachée : elle protège ses habitants d’une vérité trop lourde.

Passage : choisir le souvenir fragile plutôt que le reflet spectaculaire.

## 🧠 Le réseau qui confond connexion et lien

Obstacle : tout est connecté, mais personne n’est vraiment rejoint.

Vérité cachée : le réseau sait transmettre, pas comprendre.

Passage : répondre à une présence, pas seulement à un signal.

## 🧬 Le corps-support sans histoire

Obstacle : le corps fonctionne, mais semble vide.

Vérité cachée : l’identité ne revient pas automatiquement avec les données.

Passage : poser un choix incarné.

## 🔐 Le code qui refuse la force

Obstacle : le code ne cède pas aux attaques.

Vérité cachée : il protège une vérité qui exige confiance.

Passage : renoncer à forcer et poser la bonne question.

---

# 🧩 7. Combinaisons rapides

## Conte courage

Enfant qui a peur du noir + Forêt qui grandit avec la peur + Peur → Courage

Résultat :

Un enfant découvre que la forêt n’est pas son ennemie : elle lui montre à quel point il fuit vite.

## Conte vérité

Enfant sans reflet + Miroir difficile + Honte → Vérité douce

Résultat :

Le miroir ne rend le reflet que lorsque le héros accepte de regarder ce qu’il cachait.

## Conte pardon

Petit veilleur + Dragon blessé + Tristesse → Transmission

Résultat :

Un dragon ne garde pas un trésor, mais une peine que personne n’a jamais écoutée.

## Conte discernement

Enfant curieux + Illusion + Boussole lunaire

Résultat :

La boussole tourne en rond tant que l’enfant suit la lumière la plus brillante au lieu de la plus vraie.

## Cyberpunk mémoire

Voyageur sans mémoire + Archive qui ment par omission + Mémoire artificielle → Mémoire choisie

Résultat :

Un personnage découvre que le système ne ment pas vraiment : il a seulement supprimé ce qui rendait le souvenir humain.

## Post-humanisme

Corps qui cherche son âme + Corps-support sans histoire + Présence incarnée

Résultat :

Le héros comprend qu’un corps peut fonctionner sans être encore habité par un choix.

---

# 🖼️ 8. Prompt image générique — obstacle de conte

```text
21/20 masterpiece, original children storybook obstacle scene, gentle but mysterious atmosphere, symbolic obstacle standing before a young hero, no horror, no violence, soft magical light, readable composition, guide creature nearby, emotional threshold, courage and wonder, child-friendly fairytale style, no copied characters, no franchise names, vertical 9:16 premium illustrated composition.
```

---

# 🖼️ 9. Prompt image générique — obstacle cyberpunk

```text
21/20 masterpiece, original cyberpunk noir obstacle scene, lonely protagonist facing a cold system, reflective black glass, rain, holographic archive fragments, locked interface, artificial memory symbols, deep blue and cyan lighting, emotional restraint, identity tension, city or machine as antagonist, no copied characters, no franchise names, premium cinematic vertical 9:16 composition.
```

---

# 🎬 10. Prompt animation générique — obstacle vivant

```text
21/20 masterpiece animation, subtle symbolic obstacle image-to-video.

Animate only from the provided source image.

Preserve exact composition, obstacle shape, hero silhouette, lighting, color palette and emotional mood.

Main motion:
the obstacle remains mostly still, with subtle glow, slow breathing if creature-like, tiny surface movement, faint internal light.

Secondary motion:
soft mist, slow particles, gentle reflection shifts, symbols flickering with restraint, distant lights pulsing quietly.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no camera shake, no reframing.

Mood:
threshold, tension, mystery, courage, revelation, controlled emotion.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 11. Block LLM

```text
Active OBSTACLES_AND_ANTAGONISTS_CARD.

Utilise cette carte pour créer ce qui résiste au héros dans une histoire, un conte, une scène, un Pack+, une Memory Card ou une combinaison.

Toujours définir :
1. forme de l’obstacle ;
2. fonction de l’obstacle ;
3. apparence trompeuse ;
4. vérité cachée ;
5. passage ou résolution.

Si HERO_ARCHETYPES_CARD est active, choisis un obstacle qui teste le manque du héros.

Si QUEST_OBJECTS_CARD est active, fais de l’obstacle une condition d’accès à l’objet ou à sa vraie fonction.

Si EMOTIONAL_ARCS_CARD est active, relie l’obstacle à l’émotion centrale.

Si STORY_ENGINE_CARD est active, utilise l’obstacle pour créer l’anomalie, la fausse piste, le nœud intérieur ou la révélation.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie les obstacles doux, symboliques, non traumatiques : gardien, peur apprivoisée, règle magique, créature blessée, illusion ou porte de seuil.

Si COMBINATIONS est active, utilise l’obstacle pour donner une tension à la constellation.

Éviter :
- méchant plat ;
- violence gratuite ;
- horreur graphique ;
- punition morale ;
- obstacle sans fonction ;
- antagoniste caricatural ;
- résolution sans choix intérieur.
```

---

# 🕯️ 12. Formule courte

L’obstacle n’est pas là pour arrêter l’histoire.

Il est là pour révéler ce que le héros doit devenir.
