# 🧒🛡️ HERO ARCHETYPES CARD

Statut : Memory Card — archétypes de héros  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : personnages / héros / contes / récits / moteur narratif

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Qui vit l’histoire ?

Une histoire peut avoir un monde magnifique, un mystère fort et une bonne structure.

Mais sans héros lisible, elle reste froide.

Le héros donne un cœur au récit.

Il n’a pas besoin d’être parfait.

Au contraire : il devient intéressant parce qu’il lui manque quelque chose au début.

Formule :

Le thème ouvre le monde.  
La combinaison crée la tension.  
Le Story Engine trace le chemin.  
Le héros donne le cœur.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- COMBINATIONS.md ;
- STORY_ENGINE_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md.

Rôle avec COMBINATIONS :

- choisir un héros adapté à une combinaison de cartes ;
- éviter les personnages génériques ;
- créer une tension entre le héros et le monde.

Rôle avec STORY_ENGINE_CARD :

- donner au récit un point de départ émotionnel ;
- définir ce que le héros doit apprendre ;
- rendre la transformation finale lisible.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des héros simples, doux et adaptés aux contes ;
- aider les enfants à inventer facilement un personnage ;
- rendre l’histoire plus incarnée.

Workflow recommandé :

HERO_ARCHETYPES_CARD → CHILDREN_STORY_THEMES_CARD → STORY_ENGINE_CARD → conte / scène / prompt image / animation.

Ou :

COMBINATIONS → HERO_ARCHETYPES_CARD → STORY_ENGINE_CARD → Pack+.

---

# 🧬 3. Structure d’un héros simple

Pour créer un héros efficace, définir cinq éléments.

## 1. Désir

Que veut-il ?

Exemples :

- rentrer chez lui ;
- retrouver un souvenir ;
- comprendre un mystère ;
- protéger quelqu’un ;
- prouver qu’il est capable.

## 2. Manque

Qu’est-ce qui lui manque au début ?

Exemples :

- courage ;
- confiance ;
- patience ;
- vérité ;
- amitié ;
- mémoire ;
- discernement.

## 3. Peur

Qu’est-ce qu’il évite ?

Exemples :

- être seul ;
- se tromper ;
- perdre quelqu’un ;
- regarder la vérité ;
- demander de l’aide.

## 4. Guide ou miroir

Qui l’aide à se voir autrement ?

Exemples :

- chat oracle ;
- ami ;
- parent absent ;
- créature-guide ;
- objet magique ;
- reflet ;
- voix intérieure.

## 5. Transformation

Qu’est-ce qui change à la fin ?

Exemples :

- il ose ;
- il pardonne ;
- il fait confiance ;
- il comprend ;
- il accepte une perte ;
- il protège sans contrôler ;
- il trouve sa propre voix.

---

# 🧒 4. Archétypes doux pour contes et enfants

## 🌟 L’enfant curieux

Essence : il pose trop de questions, et c’est justement sa force.

Désir : comprendre ce que les adultes ne voient plus.

Manque : patience ou prudence.

Transformation : apprendre à écouter autant qu’à chercher.

Idéal pour : bibliothèque infinie, forêt interdite, carte mystérieuse, porte secrète.

## 🌙 L’enfant qui a peur du noir

Essence : il croit que l’obscurité cache seulement des dangers.

Désir : traverser la nuit.

Manque : confiance.

Transformation : découvrir que la nuit peut aussi protéger, guider et révéler.

Idéal pour : lune, forêt, loup protecteur, train nocturne, chambre des rêves.

## 🧭 Le petit voyageur perdu

Essence : il ne sait plus comment rentrer, mais découvre un monde intérieur.

Désir : retrouver le chemin de la maison.

Manque : courage ou mémoire.

Transformation : comprendre que rentrer chez soi signifie parfois grandir.

Idéal pour : ville de pluie, île oubliée, mer de nuages, train nocturne.

## 🔧 L’apprenti inventeur

Essence : il veut réparer le monde avec ses mains.

Désir : construire, réparer, comprendre.

Manque : accepter que tout ne se répare pas comme une machine.

Transformation : apprendre la douceur, la patience et l’écoute.

Idéal pour : jardin mécanique, robot ami, horloge cassée, machine ancienne.

## 🐾 L’ami des créatures

Essence : il comprend les animaux, les monstres doux et les êtres oubliés.

Désir : protéger une créature incomprise.

Manque : savoir poser des limites.

Transformation : comprendre qu’aimer, ce n’est pas posséder.

Idéal pour : dragon endormi, chat oracle, loup protecteur, baleine des rêves.

## 🪞 L’enfant sans reflet

Essence : son reflet a disparu ou ne lui ressemble plus.

Désir : retrouver son identité.

Manque : vérité sur lui-même.

Transformation : accepter toutes les parties de soi, même les fragiles.

Idéal pour : palais des miroirs, ville de pluie, mémoire perdue, seuil lunaire.

## 📚 Le gardien d’un secret

Essence : il sait quelque chose qu’il ne comprend pas encore.

Désir : protéger une promesse.

Manque : discernement.

Transformation : apprendre quand garder le silence et quand parler.

Idéal pour : château endormi, corbeau des secrets, bibliothèque infinie, promesse ancienne.

## ⭐ L’enfant qui entend les étoiles

Essence : il perçoit des signes que personne ne croit.

Désir : suivre un appel venu d’ailleurs.

Manque : confiance en sa perception.

Transformation : apprendre à vérifier sans éteindre son intuition.

Idéal pour : désert d’étoiles, étoile tombée, village suspendu, carte céleste.

## 🕯️ Le petit veilleur

Essence : il garde une lumière quand tout semble s’éteindre.

Désir : protéger l’espoir.

Manque : croire qu’il doit tout porter seul.

Transformation : accepter l’aide et partager la lumière.

Idéal pour : phare endormi, nuit longue, village sans rêve, lanternes magiques.

## 🌱 L’enfant qui fait pousser les choses

Essence : il a un lien avec la croissance, les graines et la patience.

Désir : rendre la vie à un lieu triste.

Manque : impatience.

Transformation : comprendre que grandir demande du temps.

Idéal pour : jardin mécanique, forêt blessée, graine de lumière, printemps perdu.

---

# 🧑‍🚀 5. Archétypes pour récits plus larges

## 🧥 Le voyageur sans mémoire

Essence : il avance avec un passé fragmenté.

Désir : comprendre qui il était.

Manque : identité stable.

Transformation : choisir qui il devient plutôt que seulement retrouver qui il était.

Idéal pour : cyberpunk, post-humanisme, mémoire artificielle, enquête.

## 🛡️ Le gardien silencieux

Essence : il protège plus qu’il ne parle.

Désir : tenir une promesse.

Manque : exprimer ses émotions.

Transformation : comprendre que protéger ne veut pas dire s’effacer.

Idéal pour : monde en ruine, cité nocturne, enfant à protéger, ancien serment.

## 🧬 Le corps qui cherche son âme

Essence : il doute de ce qu’il est.

Désir : savoir s’il est vraiment vivant.

Manque : certitude intérieure.

Transformation : découvrir que l’âme se prouve par les choix, pas seulement par l’origine.

Idéal pour : Altered Carbon, Ghost in the Shell, conscience distribuée, corps-supports.

## 🌧️ L’enquêteur mélancolique

Essence : il cherche la vérité dans une ville qui ment.

Désir : comprendre un crime, un souvenir ou une disparition.

Manque : espoir.

Transformation : retrouver une part d’humanité sans devenir naïf.

Idéal pour : Blade Runner City Melancholy, ville de pluie, mémoire artificielle.

## 🐈‍⬛ Le guide ambigu

Essence : il aide, mais ne donne jamais toute la réponse.

Désir : pousser l’autre à choisir.

Manque : compassion directe.

Transformation : apprendre à guider sans manipuler.

Idéal pour : Alice Oracle Cat, seuils, rêves, miroirs, récits initiatiques.

---

# 🧩 6. Combinaisons rapides

## Conte enfant

Enfant curieux + Bibliothèque infinie + Chouette mémoire

Résultat :

Un enfant cherche la dernière page d’un livre qui raconte sa propre peur.

## Conte émotionnel

Enfant qui a peur du noir + Loup protecteur + Forêt interdite

Résultat :

La forêt grandit quand l’enfant fuit, mais rétrécit quand il respire calmement.

## Cyberpunk mélancolique

Enquêteur mélancolique + Ville de pluie + Mémoire artificielle

Résultat :

Un enquêteur suit des reflets qui contiennent des souvenirs vendus à d’autres vies.

## Post-humanisme

Corps qui cherche son âme + Réseau mental + Corps-support dormant

Résultat :

Un être transféré doit prouver qu’il n’est pas seulement une copie.

## Oracle initiatique

Petit voyageur perdu + Chat oracle + Palais des miroirs

Résultat :

Un enfant doit choisir le seul reflet qui ne le flatte pas.

---

# 🖼️ 7. Prompt image générique — héros de conte

```text
21/20 masterpiece, original children storybook hero portrait, gentle magical atmosphere, expressive young protagonist, clear emotional identity, symbolic environment, soft cinematic light, readable silhouette, companion or guide creature nearby, sense of wonder, courage and transformation, no copied characters, no franchise names, no horror, no violence, premium illustrated fairytale style, vertical 9:16 composition.
```

---

# 🖼️ 8. Prompt image générique — héros cyberpunk / mémoire

```text
21/20 masterpiece, original cyberpunk noir character scene, lonely protagonist seen from behind or three-quarter view, rain, reflective surfaces, artificial memory symbols, subtle holographic interface, emotional restraint, identity tension, city as character, premium cinematic lighting, no copied characters, no franchise names, no action pose, vertical 9:16 composition, deep melancholy and mystery.
```

---

# 🧬 9. Block LLM

```text
Active HERO_ARCHETYPES_CARD.

Utilise cette carte pour créer ou choisir un héros adapté à une Memory Card, une combinaison ou une structure du STORY_ENGINE_CARD.

Toujours définir :
1. désir ;
2. manque ;
3. peur ;
4. guide ou miroir ;
5. transformation finale.

Pour un conte enfant, privilégier :
- héros lisible ;
- émotion simple ;
- peur douce ;
- courage ;
- curiosité ;
- amitié ;
- transformation claire.

Pour un récit cyberpunk ou post-humain, privilégier :
- identité ;
- mémoire ;
- solitude ;
- choix moral ;
- rapport au corps ;
- vérité intérieure.

Ne pas créer un héros parfait.

Le héros doit avoir un manque, une peur ou une question.

La fin doit montrer une transformation.
```

---

# 🕯️ 10. Formule courte

Le monde donne le décor.  
Le mystère donne l’appel.  
Le guide donne le seuil.  
Mais le héros donne le cœur.
