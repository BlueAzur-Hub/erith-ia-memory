# 🧭 STORY ENGINE CARD

Statut : Memory Card — moteur narratif transversal  
Projet : @erith IA / ERITH.IA  
Version : V2 — Notion Génie  
Type : structure de récit / moteur narratif / atelier d’écriture / production créative

---

# 🌟 1. Principe central

Cette carte transforme des Memory Cards, thèmes ou influences en récit structuré.

Elle ne sert pas seulement aux contes pour enfants.

Elle sert à toutes les cartes qui ont besoin de devenir :

- une scène ;
- une histoire ;
- un arc narratif ;
- un Pack+ ;
- une séquence vidéo ;
- une quête ;
- une narration courte ;
- un prompt image plus incarné ;
- un prompt animation avec intention.

Formule :

Une carte donne une couleur.  
Une combinaison donne une direction.  
Le Story Engine donne un chemin.

---

# 🔗 2. Cartes liées

Le Story Engine peut servir de moteur narratif pour toutes les Memory Cards.

## Carte source spéciale

CHILDREN_STORY_THEMES_CARD.md

Rôle : réservoir de thèmes doux, lieux, guides, émotions, mystères et contes pour enfants.

## Carte centrale de combinaison

COMBINATIONS.md

Rôle : organiser les dialogues entre plusieurs cartes mémoire.

## Rôle du Story Engine

- transformer les ingrédients en progression ;
- clarifier le début, le milieu et la fin ;
- faire émerger une transformation ;
- choisir le bon moment pour une image ;
- choisir le bon mouvement pour une animation ;
- éviter les scènes jolies mais vides.

Workflow général :

Memory Card → COMBINATIONS → STORY_ENGINE_CARD → Pack+ / scène / conte / image / animation.

Workflow enfant :

CHILDREN_STORY_THEMES_CARD → STORY_ENGINE_CARD → conte doux → prompt image → prompt animation.

---

# 🧱 3. Structure narrative en 10 étapes

## 1. Situation initiale

Le monde existe avant l’événement.

Question :

Où sommes-nous, qui est présent, et qu’est-ce qui manque ?

## 2. Anomalie

Quelque chose ne fonctionne pas comme prévu.

Question :

Quel détail fait basculer la réalité ?

## 3. Appel

Le personnage ou le monde doit réagir.

Question :

Pourquoi l’histoire ne peut-elle plus rester immobile ?

## 4. Guide ou signal

Une aide, un indice, un symbole ou une voix apparaît.

Question :

Qu’est-ce qui montre le chemin sans tout expliquer ?

## 5. Première tentative

Le personnage agit, mais comprend mal une partie du problème.

Question :

Quelle erreur utile fait avancer l’histoire ?

## 6. Fausse piste

La première interprétation est incomplète.

Question :

Quelle apparence trompe le personnage ?

## 7. Nœud intérieur

L’enjeu réel apparaît.

Question :

Quelle peur, vérité, mémoire ou contradiction doit être regardée ?

## 8. Choix

Le personnage agit autrement qu’au début.

Question :

Quel acte prouve qu’il y a eu évolution ?

## 9. Révélation

Le mystère prend sens.

Question :

Quelle vérité devient visible ?

## 10. Transformation

Le monde, le personnage ou le regard a changé.

Question :

Qu’est-ce qui ne sera plus pareil ?

---

# 🧒 4. Sous-mode enfant — version très simple

Pour les enfants, simplifier en cinq étapes.

## 1. Il était une fois...

Présenter le lieu et le héros.

## 2. Un mystère apparaît...

Quelque chose d’étrange arrive.

## 3. Un guide arrive...

Le héros reçoit une aide.

## 4. Le héros ose...

Il affronte une peur ou fait un choix.

## 5. À la fin...

Quelque chose change dans le monde et dans le cœur du héros.

---

# 🎬 5. Sous-mode production — image et vidéo

Le Story Engine peut aussi servir à produire une scène visuelle.

## Pour une image

Choisir un seul moment fort :

- apparition du guide ;
- découverte de l’anomalie ;
- seuil magique ;
- choix décisif ;
- révélation ;
- retour transformé.

Règle :

Une image ne doit pas raconter toute l’histoire.  
Elle doit incarner son cœur.

## Pour une animation

Choisir un seul mouvement magique ou narratif :

- un reflet change ;
- une porte apparaît ;
- une interface s’allume ;
- un guide cligne des yeux ;
- une étoile pulse ;
- un hologramme révèle une mémoire ;
- une silhouette respire dans la lumière ;
- une pluie devient souvenir.

Règle :

Une animation = un moment vivant.  
Pas tout le récit en une seule vidéo.

---

# 🧩 6. Formules narratives rapides

## Formule conte doux

Lieu + Héros + Guide + Mystère + Courage = Conte d’aventure douce

## Formule cyberpunk

Ville + Anomalie + Mémoire + Enquête + Révélation = Scène noire futuriste

## Formule post-humaine

Corps + Mémoire + Réseau + Doute + Identité = Récit existentiel

## Formule oracle

Guide + Seuil + Symbole + Question + Choix = Conte initiatique

## Formule production vidéo

Image forte + micro-mouvement + ambiance + révélation subtile = animation stable

---

# 🧬 7. Exemple transversal

Combinaison source : Blade Runner City Melancholy + Ghost in the Shell + Aerith-9 Lunaire

## Résumé

Une ville nocturne sous la pluie commence à refléter les pensées de ses habitants dans les flaques.

Une silhouette solitaire découvre que certains reflets ne montrent pas le passé, mais une conscience distribuée qui cherche à se souvenir d’elle-même.

La lune devient le seul repère stable dans un réseau saturé d’images et de faux souvenirs.

À la fin, le personnage comprend que la mémoire n’est pas seulement ce qui est stocké, mais ce qui est choisi, reconnu et porté.

## Structure

Situation initiale : ville cyberpunk nocturne, pluie, solitude.

Anomalie : les flaques reflètent des pensées qui ne sont pas visibles.

Signal : une lumière lunaire revient dans chaque reflet vrai.

Première tentative : le personnage suit les reflets les plus lumineux.

Fausse piste : les reflets spectaculaires sont des leurres publicitaires.

Nœud intérieur : il doit regarder un souvenir faible, presque effacé.

Choix : il ralentit, écoute, accepte l’image fragile.

Révélation : le réseau cherchait une mémoire humaine pour ne pas devenir vide.

Transformation : la ville reste froide, mais le regard du personnage a changé.

---

# 🧬 8. Block LLM

```text
Active STORY_ENGINE_CARD.

Utilise cette carte comme moteur narratif transversal pour transformer des Memory Cards, thèmes, combinaisons ou influences en récit structuré.

Cette carte peut servir :
- aux contes pour enfants ;
- aux scènes cyberpunk ;
- aux Pack+ ;
- aux prompts image ;
- aux prompts animation ;
- aux univers Hors-Lore ;
- aux personnages-guides ;
- aux séquences vidéo ;
- aux récits courts ;
- aux ateliers d’écriture.

Méthode générale :
1. identifier la carte ou combinaison source ;
2. définir la situation initiale ;
3. introduire une anomalie ;
4. faire apparaître un guide, un signal ou un symbole ;
5. créer une première tentative ;
6. révéler une fausse piste ;
7. identifier le nœud intérieur ;
8. formuler le choix ;
9. produire la révélation ;
10. montrer la transformation.

Si CHILDREN_STORY_THEMES_CARD est active, utilise-la comme réservoir d’ingrédients doux :
- lieux ;
- héros ;
- créatures-guides ;
- mystères ;
- émotions ;
- transformations.

Pour les enfants, simplifie en cinq étapes :
1. Il était une fois ;
2. Un mystère apparaît ;
3. Un guide arrive ;
4. Le héros ose ;
5. À la fin.

Pour une image, choisis un seul moment fort.

Pour une animation, choisis un seul mouvement vivant.

Toujours éviter :
- collage de références ;
- intrigue confuse ;
- accumulation de symboles sans cœur ;
- scène jolie mais vide ;
- violence graphique ;
- copie directe d’œuvre existante.
```

---

# 🕯️ 9. Formule courte

Les cartes donnent la matière.  
Les combinaisons donnent la tension.  
Le Story Engine donne le chemin.  
Le récit naît quand quelque chose change.
