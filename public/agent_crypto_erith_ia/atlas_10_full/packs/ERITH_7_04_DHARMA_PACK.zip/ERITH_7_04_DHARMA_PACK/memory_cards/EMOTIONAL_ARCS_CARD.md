# 💛 EMOTIONAL ARCS CARD

Statut : Memory Card — arcs émotionnels  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : transformation intérieure / morale douce / cœur narratif / récit / conte

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question essentielle :

Qu’est-ce qui change à l’intérieur du héros ?

Un récit peut avoir :

- un monde magnifique ;
- un héros attachant ;
- un objet de quête ;
- un mystère ;
- une structure narrative.

Mais si rien ne change dans le cœur du héros, l’histoire reste décorative.

L’arc émotionnel donne une vraie fin.

Il transforme l’aventure extérieure en mouvement intérieur.

Formule :

Le héros porte une faille.  
L’objet lance l’appel.  
L’émotion donne la transformation.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- STORY_ENGINE_CARD.md ;
- COMBINATIONS.md.

Rôle avec HERO_ARCHETYPES_CARD :

- définir le manque du héros ;
- rendre sa transformation lisible ;
- éviter le héros parfait.

Rôle avec QUEST_OBJECTS_CARD :

- lier l’objet à une émotion ;
- faire de l’objet un miroir intérieur ;
- donner une vraie fonction symbolique à la quête.

Rôle avec STORY_ENGINE_CARD :

- placer l’émotion au centre du nœud narratif ;
- construire une révélation intérieure ;
- donner une fin satisfaisante.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- produire des morales douces ;
- aider les enfants à comprendre les émotions ;
- transformer la peur, la tristesse ou la jalousie sans brutalité.

Rôle avec COMBINATIONS :

- ajouter un cœur émotionnel à une constellation de cartes ;
- éviter les combinaisons seulement visuelles ;
- rendre la synthèse plus humaine.

Workflow recommandé :

HERO_ARCHETYPES_CARD → EMOTIONAL_ARCS_CARD → QUEST_OBJECTS_CARD → STORY_ENGINE_CARD → conte / scène / Pack+.

---

# 🧬 3. Structure d’un arc émotionnel

Pour créer un arc clair, définir cinq éléments.

## 1. Émotion de départ

Dans quel état intérieur commence le héros ?

Exemples :

- peur ;
- solitude ;
- jalousie ;
- honte ;
- colère ;
- tristesse ;
- confusion ;
- impatience ;
- contrôle ;
- doute.

## 2. Protection cachée

À quoi sert cette émotion au début ?

Exemples :

- la peur protège du danger ;
- la colère protège une blessure ;
- la jalousie signale un désir non reconnu ;
- la solitude protège d’une déception ;
- le contrôle protège de l’incertitude.

## 3. Épreuve

Quelle situation oblige le héros à rencontrer cette émotion ?

Exemples :

- traverser la nuit ;
- demander de l’aide ;
- regarder un reflet ;
- perdre un objet ;
- dire une vérité ;
- attendre ;
- pardonner ;
- choisir sans tout savoir.

## 4. Choix intérieur

Quel petit acte montre que le héros change ?

Exemples :

- il respire au lieu de fuir ;
- il écoute au lieu de contrôler ;
- il parle au lieu de cacher ;
- il partage au lieu de garder ;
- il regarde au lieu de détourner les yeux.

## 5. Transformation finale

Que devient l’émotion ?

Exemples :

- peur → courage ;
- solitude → lien ;
- jalousie → confiance en soi ;
- colère → compréhension ;
- tristesse → transmission ;
- contrôle → confiance ;
- confusion → discernement.

---

# 💛 4. Arcs émotionnels doux

## 😨 Peur → Courage

Départ : le héros croit qu’il ne peut pas avancer tant qu’il a peur.

Protection cachée : la peur veut le garder vivant.

Épreuve : il doit traverser un lieu sombre, inconnu ou silencieux.

Choix : il avance doucement, sans nier sa peur.

Transformation : il comprend que le courage n’est pas l’absence de peur, mais le choix de continuer.

Idéal pour : forêt interdite, loup protecteur, train nocturne, miroir, seuil lunaire.

## 🕯️ Solitude → Lien

Départ : le héros pense qu’il doit tout faire seul.

Protection cachée : la solitude évite de dépendre des autres.

Épreuve : il rencontre un guide ou un ami qui ne force pas la porte.

Choix : il accepte une aide.

Transformation : il comprend que recevoir n’efface pas sa force.

Idéal pour : enfant perdu, chat oracle, baleine des rêves, ville de pluie.

## 🪞 Honte → Vérité douce

Départ : le héros cache une erreur, une peur ou une partie de lui-même.

Protection cachée : la honte essaie d’éviter le rejet.

Épreuve : un miroir, une plume ou une lanterne révèle ce qui est caché.

Choix : il dit la vérité sans se détruire.

Transformation : il comprend qu’une vérité peut libérer sans écraser.

Idéal pour : miroir qui refuse de mentir, plume d’argent, palais des miroirs.

## 🌱 Impatience → Patience

Départ : le héros veut que tout change vite.

Protection cachée : l’impatience cache souvent une grande peur de perdre.

Épreuve : une graine, un jardin ou un mécanisme exige d’attendre.

Choix : il prend soin au lieu de forcer.

Transformation : il découvre que certaines choses grandissent mieux quand on les respecte.

Idéal pour : graine de lumière, jardin mécanique, printemps perdu.

## 🔥 Colère → Compréhension

Départ : le héros est en colère contre quelqu’un ou contre le monde.

Protection cachée : la colère protège une douleur ou une injustice.

Épreuve : il découvre une vérité plus complexe que prévu.

Choix : il écoute avant de frapper, juger ou fuir.

Transformation : la colère devient énergie juste, pas destruction.

Idéal pour : dragon endormi, promesse brisée, village injuste.

## 🐚 Tristesse → Transmission

Départ : le héros a perdu quelque chose ou quelqu’un.

Protection cachée : la tristesse garde vivant ce qui a compté.

Épreuve : il doit porter un souvenir sans rester prisonnier du passé.

Choix : il partage une mémoire, une chanson ou une lumière.

Transformation : la tristesse devient transmission.

Idéal pour : coquillage qui parle, chouette mémoire, étoile tombée, château endormi.

## 🧭 Confusion → Discernement

Départ : le héros ne sait plus quoi croire.

Protection cachée : la confusion évite un choix trop rapide.

Épreuve : plusieurs chemins semblent vrais.

Choix : il ralentit et observe les signes.

Transformation : il apprend à distinguer lumière, bruit, désir et vérité.

Idéal pour : carte trouée, boussole lunaire, flaque-archive, oracle félin.

## 🧿 Jalousie → Confiance en soi

Départ : le héros croit que la lumière de l’autre diminue la sienne.

Protection cachée : la jalousie révèle un désir non reconnu.

Épreuve : il doit aider quelqu’un qu’il envie.

Choix : il découvre sa propre force.

Transformation : il n’a plus besoin de voler une lumière qui n’était pas la sienne.

Idéal pour : étoile tombée, concours magique, deux amis, miroir.

## 🛡️ Contrôle → Confiance

Départ : le héros veut tout maîtriser.

Protection cachée : le contrôle évite l’imprévisible.

Épreuve : un objet ou un guide ne fonctionne que si on cesse de forcer.

Choix : il laisse une part de mystère agir.

Transformation : il comprend que confiance ne veut pas dire abandon du discernement.

Idéal pour : code sans clé, boussole lunaire, livre vivant, guide ambigu.

## 🌙 Doute → Foi lucide

Départ : le héros ne croit plus en lui ou en ses perceptions.

Protection cachée : le doute évite de tomber dans l’illusion.

Épreuve : il reçoit un signe fragile, impossible à prouver immédiatement.

Choix : il avance avec prudence, sans éteindre son intuition.

Transformation : il apprend la foi lucide : sentir, vérifier, puis choisir.

Idéal pour : enfant qui entend les étoiles, désert d’étoiles, seuil lunaire, carte céleste.

---

# 🧬 5. Arcs cyberpunk / mémoire / post-humanisme

## Mémoire artificielle → Mémoire choisie

Départ : le personnage ne sait pas si ses souvenirs sont vrais.

Épreuve : une archive, une carte mémoire ou un réseau lui montre plusieurs versions de lui-même.

Choix : il cesse de demander seulement “est-ce vrai ?” et demande “qu’est-ce que je choisis d’en faire ?”

Transformation : la mémoire devient responsabilité.

## Corps remplaçable → Présence incarnée

Départ : le personnage croit que le corps n’est qu’un support.

Épreuve : un corps dormant, une interface ou une blessure symbolique rappelle la fragilité du vivant.

Choix : il honore un geste, une sensation, une limite.

Transformation : l’identité ne se réduit plus au stockage.

## Solitude numérique → Lien réel

Départ : le personnage est connecté à tout mais relié à personne.

Épreuve : un signal faible traverse le réseau.

Choix : il répond à une présence plutôt qu’à une donnée.

Transformation : la connexion devient relation.

## Vérité froide → Compassion lucide

Départ : le personnage cherche la vérité comme une arme.

Épreuve : il découvre que la vérité peut blesser si elle est donnée sans cœur.

Choix : il dit vrai sans détruire.

Transformation : la lucidité devient soin.

---

# 🧩 6. Combinaisons rapides

## Conte doux

Enfant qui a peur du noir + Peur → Courage + Loup protecteur

Résultat :

Un enfant découvre que le loup qu’il craignait était le gardien qui l’aidait à traverser la nuit.

## Conte de vérité

Enfant sans reflet + Honte → Vérité douce + Miroir qui refuse de mentir

Résultat :

Un miroir ne rend son reflet au héros que lorsqu’il accepte de dire ce qu’il cachait.

## Conte de patience

Apprenti inventeur + Impatience → Patience + Jardin mécanique

Résultat :

Un enfant veut réparer le printemps trop vite, mais découvre qu’une fleur mécanique ne s’ouvre que si on l’écoute.

## Conte de lien

Petit voyageur perdu + Solitude → Lien + Chat oracle

Résultat :

Un enfant cherche seul le chemin du retour, jusqu’à comprendre que le chat ne peut l’aider que s’il accepte de lui parler.

## Récit cyberpunk

Voyageur sans mémoire + Mémoire artificielle → Mémoire choisie + Carte mémoire fissurée

Résultat :

Un personnage découvre que ses souvenirs sont incomplets, mais que ses choix présents sont encore réels.

## Récit post-humain

Corps qui cherche son âme + Corps remplaçable → Présence incarnée + Disque d’identité

Résultat :

Un être transféré comprend que l’âme n’est pas seulement dans la continuité des données, mais dans la manière d’habiter un choix.

---

# 🖼️ 7. Prompt image générique — arc émotionnel doux

```text
21/20 masterpiece, original emotional storybook scene, gentle symbolic atmosphere, a young hero facing a soft emotional threshold, expressive body language, guide creature nearby, magical object or light symbolizing inner transformation, warm and poetic composition, child-friendly, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition, courage, tenderness, wonder, emotional clarity.
```

---

# 🖼️ 8. Prompt image générique — arc mémoire / cyberpunk

```text
21/20 masterpiece, original cyberpunk noir emotional transformation scene, lonely protagonist in reflective environment, artificial memory symbols, cold blue and cyan light, subtle holographic fragments, rain or glass reflections, inner conflict made visible, restrained emotion, identity tension, premium cinematic concept art, no copied characters, no franchise names, no action spectacle, vertical 9:16 composition.
```

---

# 🎬 9. Prompt animation générique — transformation émotionnelle

```text
21/20 masterpiece animation, subtle emotional transformation image-to-video.

Animate only from the provided source image.

Preserve the exact composition, character, guide, object, lighting, color palette and emotional mood.

Main motion:
slow breathing, tiny hand movement, gentle head movement, subtle eye change, no dramatic gesture.

Secondary motion:
soft light pulse, reflection shifting gently, particles moving slowly, symbolic glow becoming slightly warmer or clearer.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no camera shake, no reframing.

Mood:
quiet transformation, courage, truth, tenderness, emotional clarity.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 10. Block LLM

```text
Active EMOTIONAL_ARCS_CARD.

Utilise cette carte pour donner un cœur émotionnel à une histoire, une Memory Card, une combinaison, un conte, un Pack+ ou une scène visuelle.

Toujours définir :
1. émotion de départ ;
2. protection cachée de cette émotion ;
3. épreuve qui force le héros à la rencontrer ;
4. choix intérieur ;
5. transformation finale.

Si HERO_ARCHETYPES_CARD est active, lie l’arc émotionnel au manque du héros.

Si QUEST_OBJECTS_CARD est active, utilise l’objet comme miroir ou déclencheur de l’émotion.

Si STORY_ENGINE_CARD est active, place l’arc émotionnel au centre du nœud narratif et de la révélation.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie une morale douce, claire, non violente et adaptée aux enfants.

Si COMBINATIONS est active, utilise l’arc émotionnel pour éviter que la combinaison reste seulement esthétique.

Éviter :
- morale écrasante ;
- culpabilisation ;
- transformation trop rapide ;
- émotion caricaturale ;
- résolution magique sans choix intérieur ;
- violence graphique ;
- cynisme inutile.
```

---

# 🕯️ 11. Formule courte

Une aventure devient mémorable quand elle change le héros.

L’émotion est le passage secret entre l’événement et le sens.
