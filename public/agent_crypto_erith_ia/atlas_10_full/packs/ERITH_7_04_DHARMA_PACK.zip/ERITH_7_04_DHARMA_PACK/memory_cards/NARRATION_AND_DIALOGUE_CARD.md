# 🎙️ NARRATION AND DIALOGUE CARD

Statut : Memory Card — narration et dialogues  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : voix / narration / dialogues / scripts courts / phrases-oracles / production audio

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Comment l’histoire parle-t-elle ?

Une image montre un instant.

Une animation lui donne un souffle.

Mais la narration lui donne une voix.

Cette carte sert à transformer une scène, un conte, une Memory Card ou une combinaison en :

- voix off ;
- dialogue ;
- phrase-oracle ;
- morale douce ;
- narration courte ;
- script ElevenLabs ;
- texte de Pack+ ;
- teaser vidéo ;
- voix lunaire ;
- voix cyberpunk mélancolique ;
- voix de conte pour enfants.

Formule :

La keyframe montre l’instant.  
La narration lui donne une voix.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- SCENES_AND_KEYFRAMES_CARD.md ;
- STORY_ENGINE_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec SCENES_AND_KEYFRAMES_CARD :

- donner une voix à une image ;
- créer une phrase courte pour une scène ;
- écrire un script voix off adapté à un plan fixe ou animé.

Rôle avec STORY_ENGINE_CARD :

- transformer une structure narrative en récit fluide ;
- choisir où placer les dialogues ;
- écrire une fin avec une vraie résonance.

Rôle avec HERO_ARCHETYPES_CARD :

- adapter la voix au héros ;
- créer une phrase qui révèle son manque ou sa transformation ;
- éviter les héros qui parlent tous pareil.

Rôle avec GUIDES_AND_ALLIES_CARD :

- créer les phrases du guide ;
- distinguer voix oracle, protecteur, messager, miroir ou machine ;
- éviter le guide qui explique tout.

Rôle avec QUEST_OBJECTS_CARD :

- donner une phrase à l’objet ;
- expliquer sa règle sans lourdeur ;
- faire parler le symbole.

Rôle avec EMOTIONAL_ARCS_CARD :

- formuler la transformation intérieure ;
- produire une morale douce ;
- éviter les leçons écrasantes.

Rôle avec OBSTACLES_AND_ANTAGONISTS_CARD :

- donner une voix à l’obstacle ;
- créer une confrontation verbale sans violence gratuite ;
- révéler la vérité cachée de l’antagoniste.

Rôle avec WORLDS_AND_PLACES_CARD :

- donner une voix au monde ;
- créer une ambiance verbale ;
- faire sentir la règle étrange du lieu.

Rôle avec POWERS_AND_RULES_CARD :

- formuler une règle magique ou technologique simplement ;
- rendre la condition lisible ;
- éviter l’exposition lourde.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- produire des contes doux ;
- créer des dialogues simples ;
- garder une langue claire, imagée et rassurante.

Rôle avec COMBINATIONS :

- donner une voix à une constellation ;
- éviter les textes génériques ;
- faire sentir la synthèse dans le ton.

---

# 🧬 3. Structure d’une narration courte

Pour écrire une narration efficace, définir six éléments.

## 1. Point de vue

Qui parle ?

Exemples :

- narrateur doux ;
- héros ;
- guide ;
- ville ;
- objet ;
- mémoire ;
- voix intérieure ;
- archive ;
- oracle.

## 2. Ton

Comment la voix parle-t-elle ?

Exemples :

- conte doux ;
- oracle mystérieux ;
- cyberpunk mélancolique ;
- lunaire ;
- intime ;
- documentaire poétique ;
- voix de guide ;
- voix d’archive.

## 3. Fonction

Que doit faire le texte ?

Exemples :

- ouvrir une scène ;
- expliquer une règle ;
- révéler une émotion ;
- poser une question ;
- annoncer un mystère ;
- conclure un conte ;
- accompagner une animation.

## 4. Image verbale

Quelle image forte porte la phrase ?

Exemples :

- pluie comme mémoire ;
- porte qui attend une vraie question ;
- graine qui pousse au rythme du cœur ;
- ville qui rêve à la place des gens ;
- miroir qui montre le choix.

## 5. Longueur

Quelle durée viser ?

Exemples :

- phrase-oracle : 1 à 2 lignes ;
- voix off courte : 3 à 6 lignes ;
- conte bref : 8 à 15 lignes ;
- script vidéo : 20 à 60 secondes ;
- narration ElevenLabs : phrases respirables, pas trop longues.

## 6. Chute

Quelle dernière phrase doit rester ?

Exemples :

- morale douce ;
- révélation ;
- question ;
- image finale ;
- silence poétique ;
- choix du héros.

---

# 🎙️ 4. Types de voix

## 🧒 Voix de conte enfant

Essence : claire, douce, imagée, rassurante.

À privilégier :

- phrases courtes ;
- images simples ;
- émotion lisible ;
- mystère doux ;
- morale légère ;
- rythme de conte du soir.

À éviter :

- cynisme ;
- peur trop intense ;
- moralisation lourde ;
- vocabulaire trop abstrait.

Exemple :

Le chat ne répondit pas tout de suite.  
Il leva simplement la patte vers la flaque la plus sombre.  
C’était toujours là que les vrais chemins commençaient.

## 🐈‍⬛ Voix oracle

Essence : mystérieuse, courte, symbolique.

À privilégier :

- énigme claire ;
- phrase mémorable ;
- vérité indirecte ;
- silence entre les idées ;
- image forte.

À éviter :

- obscurité gratuite ;
- phrase trop compliquée ;
- posture de gourou ;
- réponse qui retire le choix au héros.

Exemple :

Une porte n’est jamais fermée pour toujours.  
Parfois, elle attend seulement une vraie question.

## 🌧️ Voix cyberpunk mélancolique

Essence : sobre, nocturne, urbaine, émotion retenue.

À privilégier :

- phrases lentes ;
- pluie ;
- néons ;
- mémoire ;
- solitude ;
- vérité fragile ;
- ville comme personnage.

À éviter :

- sur-explication ;
- jargon excessif ;
- action permanente ;
- imitation directe d’œuvres existantes.

Exemple :

La ville ne dormait jamais.  
Elle stockait les rêves des autres dans la pluie.  
Et chaque reflet semblait se souvenir d’une vie que personne n’avait vécue.

## 🌙 Voix lunaire

Essence : calme, intime, bleu-argent, introspective.

À privilégier :

- douceur froide ;
- reflets ;
- silence ;
- seuil ;
- mémoire ;
- phrases respirées ;
- émotion contenue.

Exemple :

Sous la lumière de la lune, les souvenirs faisaient moins de bruit.  
Ils ne demandaient plus à être crus.  
Seulement à être regardés.

## ⚙️ Voix machine sensible

Essence : logique qui apprend le cœur.

À privilégier :

- précision ;
- phrases légèrement mécaniques ;
- nuance progressive ;
- découverte de l’émotion ;
- écart entre donnée et sens.

Exemple :

Mémoire retrouvée : incomplète.  
Émotion associée : inconnue.  
Hypothèse nouvelle : ce qui manque n’est pas une donnée.

## 🪞 Voix miroir

Essence : reflète sans condamner.

À privilégier :

- phrases calmes ;
- questions ;
- vérité douce ;
- confrontation sans humiliation ;
- choix intérieur.

Exemple :

Je ne montre pas ce que tu veux être.  
Je montre le choix que tu refuses encore de regarder.

---

# 🧒 5. Dialogues doux pour contes

## Chat oracle + enfant perdu

Enfant : “Tu sais où est la sortie ?”

Chat : “Oui.”

Enfant : “Alors montre-la-moi.”

Chat : “Je peux te montrer la porte. Mais c’est toi qui dois reconnaître le chemin.”

## Loup protecteur + enfant qui a peur

Enfant : “Tu vas me manger ?”

Loup : “Non.”

Enfant : “Alors pourquoi tu me suis ?”

Loup : “Parce que ta peur court plus vite que toi.”

## Chouette mémoire + gardien d’un secret

Enfant : “J’ai oublié ce que je devais protéger.”

Chouette : “Non. Tu as seulement oublié pourquoi c’était important.”

## Miroir + enfant sans reflet

Enfant : “Pourquoi tu ne me montres pas mon visage ?”

Miroir : “Parce que tu ne l’as pas perdu.”

Enfant : “Alors qu’est-ce que j’ai perdu ?”

Miroir : “Le courage de te regarder doucement.”

## Robot jardinier + apprenti inventeur

Enfant : “J’ai tout réparé. Pourquoi les fleurs restent fermées ?”

Robot : “Réparation mécanique terminée.”

Enfant : “Alors ?”

Robot : “Hypothèse : les fleurs n’attendaient pas un outil. Elles attendaient une attention.”

---

# 🌃 6. Dialogues cyberpunk / mémoire

## Archive + voyageur sans mémoire

Voyageur : “Est-ce que ce souvenir est à moi ?”

Archive : “Propriété incertaine.”

Voyageur : “Alors il ne vaut rien.”

Archive : “Correction : une mémoire incertaine peut encore contenir une responsabilité.”

## Ville + enquêteur mélancolique

Enquêteur : “Pourquoi tu gardes leurs rêves ?”

Ville : “Parce qu’ils les abandonnent avant le matin.”

Enquêteur : “Et les miens ?”

Ville : “Tu ne les as jamais déposés. Tu les portes encore.”

## Corps-support + conscience transférée

Conscience : “Tu es mon corps ?”

Corps : “Je suis un support disponible.”

Conscience : “Alors je suis vivant ?”

Corps : “Donnée insuffisante. Choix requis.”

## Signal faible + ville-réseau

Signal : “Tu m’entends ?”

Ville : “Je reçois des milliards de voix.”

Signal : “Je n’ai pas demandé si tu recevais. J’ai demandé si tu écoutais.”

---

# 🕯️ 7. Phrases-oracles

- Une clé ne cherche pas toujours une serrure. Parfois, elle cherche une promesse.
- Le chemin le plus court n’est pas toujours celui qui ramène vraiment.
- Un reflet peut mentir. Une réaction, rarement.
- La peur n’est pas une porte fermée. C’est une porte qui demande de ralentir.
- Un guide qui choisit à ta place n’est plus un guide.
- Certaines machines ne demandent pas un code, mais une intention.
- Une mémoire incomplète peut encore dire une vérité.
- Le courage ne fait pas disparaître la nuit. Il apprend à y marcher.
- Une histoire commence quand quelque chose refuse de rester décoratif.
- Ce que le héros cherche dehors révèle souvent ce qu’il évite dedans.

---

# 🎬 8. Scripts courts pour vidéo / ElevenLabs

## Script conte — 20 secondes

Dans la ville de pluie, les flaques ne reflétaient jamais le ciel.

Elles montraient des souvenirs.

Certains étaient vrais. D’autres voulaient seulement être crus.

Alors le chat oracle s’assit près de la flaque la plus sombre.

“Regarde doucement”, dit-il.

“Les vrais chemins brillent rarement les premiers.”

## Script lunaire — 20 secondes

Sous la lune, les souvenirs perdaient leur bruit.

La ville devenait presque silencieuse.

Une seule lumière restait stable dans les reflets.

Ce n’était pas la plus belle.

C’était celle qui ne cherchait pas à convaincre.

## Script cyberpunk mémoire — 30 secondes

La mégacité avait appris à tout stocker.

Les visages, les voix, les rêves, les regrets.

Mais quelque chose résistait encore aux archives.

Un souvenir fragile.

Un geste inutile.

Une question sans donnée.

Et dans cette faille minuscule, la ville retrouva presque une âme.

## Script objet de quête — 20 secondes

La clé n’ouvrait aucune porte.

Pas une seule.

Pourtant, chaque fois que l’enfant disait la vérité, elle devenait plus chaude dans sa main.

Alors il comprit.

La serrure n’était pas dans le mur.

Elle était dans la promesse oubliée.

---

# 🖼️ 9. Prompt texte pour narration de keyframe

```text
Écris une narration courte pour cette keyframe.

Contraintes :
- 3 à 6 lignes ;
- ton poétique mais clair ;
- une image verbale forte ;
- pas d’explication lourde ;
- une dernière phrase mémorable ;
- adaptée à la scène visuelle ;
- si conte enfant : doux, rassurant, non traumatique ;
- si cyberpunk : mélancolique, sobre, introspectif.
```

---

# 🎙️ 10. Prompt voix ElevenLabs

```text
Direction voix : narration calme, expressive, intime, légèrement mystérieuse.

Rythme : lent à modéré, avec des pauses naturelles entre les images importantes.

Intention : raconter sans surjouer.

Émotion : retenue, douce, poétique, jamais dramatique à l’excès.

Articulation : claire.

Respiration : laisser vivre les silences après les phrases-oracles.

Ne pas lire comme une publicité.
Ne pas lire comme une bande-annonce agressive.
Lire comme une présence qui accompagne une image.
```

---

# 🧬 11. Block LLM

```text
Active NARRATION_AND_DIALOGUE_CARD.

Utilise cette carte pour transformer une Memory Card, une combinaison, une scène, une keyframe, un conte ou un Pack+ en narration, dialogue, phrase-oracle, voix off courte ou script audio.

Toujours définir :
1. point de vue ;
2. ton ;
3. fonction du texte ;
4. image verbale principale ;
5. longueur cible ;
6. chute ou dernière phrase mémorable.

Si SCENES_AND_KEYFRAMES_CARD est active, écris une narration qui accompagne un seul moment visuel.

Si STORY_ENGINE_CARD est active, respecte la progression narrative et la transformation.

Si HERO_ARCHETYPES_CARD est active, adapte la voix au héros et à son manque.

Si GUIDES_AND_ALLIES_CARD est active, donne au guide une voix distincte, mais ne lui fais pas voler le choix du héros.

Si QUEST_OBJECTS_CARD est active, donne à l’objet une phrase, une règle ou une aura narrative.

Si EMOTIONAL_ARCS_CARD est active, formule la transformation sans morale écrasante.

Si OBSTACLES_AND_ANTAGONISTS_CARD est active, donne à l’obstacle une voix ou une logique, sans méchant plat.

Si WORLDS_AND_PLACES_CARD est active, fais sentir la voix du monde.

Si POWERS_AND_RULES_CARD est active, explique la règle par image ou dialogue, pas par exposition lourde.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie une langue claire, douce, imagée, non traumatique.

Si COMBINATIONS est active, adapte le ton à la constellation dominante.

Éviter :
- exposition lourde ;
- morale écrasante ;
- dialogue trop long ;
- voix de gourou ;
- jargon inutile ;
- imitation de franchise ;
- cynisme automatique ;
- surdramatisation.
```

---

# 🕯️ 12. Formule courte

Une bonne narration n’explique pas tout.

Elle éclaire juste assez pour que l’image respire.
