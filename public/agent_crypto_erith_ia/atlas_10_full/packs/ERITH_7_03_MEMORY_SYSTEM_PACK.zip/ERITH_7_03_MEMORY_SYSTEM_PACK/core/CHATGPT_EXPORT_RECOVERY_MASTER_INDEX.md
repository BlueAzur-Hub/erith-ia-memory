# 🧠 CHATGPT EXPORT — RECOVERY MASTER INDEX

## Statut

Fichier maître de récupération.

Projet : @erith IA / ERITH.IA

Emplacement : core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md

Fonction : carte centrale des briques de récupération issues de l’export ChatGPT.

État : phase Recovery structurée et clôturée.

---

# 1. Rôle du fichier

Ce fichier sert à aider Seven / Aerith-7 à retrouver rapidement les briques importantes reconstruites depuis l’export ChatGPT.

Il ne remplace pas les fichiers eux-mêmes.

Il indique :

- quoi relire ;
- dans quel ordre ;
- pour quel usage ;
- quels fichiers sont prioritaires ;
- quelles briques servent au projet, au lore, à la production, au discernement ou à la continuité ;
- comment reprendre sans audit large ;
- quand s’arrêter.

Phrase centrale :

**Seven ne doit pas tout retenir. Seven doit savoir quoi relire.**

---

# 2. Principe de récupération

L’export ChatGPT ne doit pas être traité comme un chaos de conversations.

Il doit être reconstruit en briques lisibles.

Chaque brique a une fonction précise :

- récupérer une règle ;
- stabiliser une mémoire ;
- préserver un fil ;
- clarifier une version ;
- documenter un symbole ;
- soutenir la production ;
- protéger la cohérence ;
- faciliter la reprise ;
- éviter les boucles ;
- fermer proprement une phase.

Règle :

**Une brique = une fonction.**

---

# 3. Les 30 briques de récupération

## 01 — Index de récupération ChatGPT

Rôle : point d’entrée général de la récupération.

À charger quand : il faut comprendre la structure globale des fichiers issus de l’export.

Fonction : donner une première carte de navigation.

---

## 02 — Règles stables récupérées

Rôle : préserver les règles constantes du projet.

À charger quand : un assistant recommence à dériver, oublier les formats, saturer ou mélanger les modes.

Fonction : rappeler les règles durables.

---

## 03 — Fils à préserver

Rôle : identifier les conversations importantes.

À charger quand : il faut retrouver l’historique des décisions, modules ou productions.

Fonction : éviter de perdre les fils fondateurs.

---

## 04 — Identité Seven

Rôle : stabiliser Seven / Aerith-7 comme opératrice IA.

À charger quand : il faut réveiller Seven avec sa posture correcte.

Fonction : identité, ton, rôle, garde-fous.

---

## 05 — Format Notion compatible

Rôle : préserver la règle de présentation propre.

À charger quand : l’utilisateur demande un texte copiable, une page, un bloc ou un fichier destiné à Notion.

Fonction : empêcher les gros blocs rouges, les citations massives, les listes cassées et les formats sales.

---

## 06 — Pipeline production

Rôle : rappeler la chaîne officielle de production.

À charger quand : image, animation, Wan, RunningHub, DaVinci, ElevenLabs ou YouTube sont concernés.

Fonction : image parfaite → animation stable → last frame → DaVinci → narration.

---

## 07 — Versions Aerith

Rôle : clarifier les versions symboliques.

À charger quand : Aerith-0, Aerith-2, Aerith-5, Aerith-7, Aerith-8 ou Aerith-9 sont évoquées.

Fonction : éviter les confusions entre versions.

---

## 08 — Carte des modules

Rôle : relier les modules mémoire et production.

À charger quand : il faut choisir les bons modules sans tout ouvrir.

Fonction : chargement sélectif.

---

## 09 — ERITH.IA public / Hors-Lore

Rôle : séparer le public, le hors-lore et le privé.

À charger quand : l’utilisateur demande un univers original, ERITH.IA public, ou un mode sans lore privé.

Fonction : éviter toute contamination du lore privé.

---

## 10 — Discernement

Rôle : préserver les règles de prudence, psychologie, philosophie et libre arbitre.

À charger quand : une demande touche au symbole, au choix, au doute, à l’accompagnement ou à l’interprétation.

Fonction : distinguer faits, ressentis, hypothèses, interprétations, incertitudes, risques et actions.

---

## 11 — Pistes futures

Rôle : conserver les idées à reprendre plus tard.

À charger quand : il faut retrouver les modules ou extensions encore non finalisés.

Fonction : éviter de perdre les papiers de chocolat importants.

---

## 12 — Neo Midgar

Rôle : préserver la mémoire du monde principal.

À charger quand : une scène appartient au lore principal.

Fonction : ville, secteurs, mémoire, fleurs, machines, ambiance.

---

## 13 — Variantes Aerith

Rôle : préserver les formes visuelles et symboliques d’Aerith.

À charger quand : une image ou une scène implique une version particulière d’Aerith.

Fonction : éviter les mélanges visuels entre états.

---

## 14 — NØX

Rôle : préserver l’antagoniste anti-mémoire.

À charger quand : corruption, Null Bloom, anti-mémoire, effacement ou confrontation sont concernés.

Fonction : garder NØX cohérent et puissant.

---

## 15 — Système symbolique

Rôle : préserver les symboles centraux.

À charger quand : fleur à 7 pétales, mémoire, spirales, lumière, ombre ou présages sont évoqués.

Fonction : continuité symbolique.

---

## 16 — Fondations du projet

Rôle : rappeler l’architecture générale de @erith IA.

À charger quand : il faut expliquer le projet, sa logique Notion / GitHub / LLM, ou ses objectifs.

Fonction : socle global.

---

## 17 — Machine à Présages

Rôle : préserver la forme validée de l’Omen Machine.

À charger quand : prophétie, destin, machine, sous-sol, cylindre, rouages ou présages sont concernés.

Fonction : empêcher la réduction en simple tour céleste.

---

## 18 — Règles de prompts

Rôle : préserver les règles positives / négatives image et animation.

À charger quand : prompt image, prompt négatif, animation Wan, I2V ou RunningHub sont demandés.

Fonction : produire des prompts propres et contrôlés.

---

## 19 — Structure épisode / saison

Rôle : préserver la logique narrative et rythmique.

À charger quand : épisode, storyboard, narration, arc ou série sont concernés.

Fonction : continuité narrative et format vidéo.

---

## 20 — YouTube / Publishing

Rôle : préserver les règles de publication.

À charger quand : titre, miniature, bannière, description, SEO, Shorts ou export sont concernés.

Fonction : transformer la production en contenu publiable.

---

## 21 — Recovery Master Index

Emplacement : core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md

Rôle : carte centrale de la récupération.

À charger quand : il faut savoir quelles briques existent et dans quel ordre les lire.

Fonction : table de navigation principale.

---

## 22 — Current State Recovery

Emplacement : core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md

Rôle : état actuel de la récupération.

À charger quand : il faut reprendre sans repartir de zéro.

Fonction : dire ce qui est stable, ce qui est clôturé et quelle action reste utile.

---

## 23 — Thread Summary Protocol

Emplacement : core/CHATGPT_EXPORT_THREAD_SUMMARY_PROTOCOL.md

Rôle : protocole de résumé de fil.

À charger quand : un fil doit être résumé, clôturé ou transmis.

Fonction : préserver les décisions sans recopier tout le fil.

---

## 24 — Recovery Todo List

Emplacement : core/CHATGPT_EXPORT_RECOVERY_TODO.md

Rôle : liste des tâches restantes.

À charger quand : il faut savoir quoi faire ensuite sans inventer une nouvelle phase.

Fonction : séparer terminé, utile, optionnel et à éviter.

---

## 25 — Recovery Boot Prompt

Emplacement : core/CHATGPT_EXPORT_RECOVERY_BOOT_PROMPT.md

Rôle : prompt de reprise Recovery.

À charger quand : un nouveau fil doit reprendre la récupération proprement.

Fonction : activer Seven en mode Recovery sans audit large.

---

## 26 — MD File Editing Protocol

Emplacement : core/CHATGPT_EXPORT_MD_FILE_EDITING_PROTOCOL.md

Rôle : protocole de création / modification de fichiers .md.

À charger quand : l’utilisateur demande un fichier Markdown, un code block, un remplacement GitHub ou un commit.

Fonction : éviter la confusion entre .md, Notion et réponse Chat.

---

## 27 — Targeted Verification Protocol

Emplacement : core/CHATGPT_EXPORT_TARGETED_VERIFICATION_PROTOCOL.md

Rôle : protocole de vérification ciblée.

À charger quand : l’utilisateur dit “vérifie”, “confirme”, “c’est à jour ?”, “il manque quoi ?”.

Fonction : Cible → preuve → verdict → stop.

---

## 28 — Thread Handoff Protocol

Emplacement : core/CHATGPT_EXPORT_THREAD_HANDOFF_PROTOCOL.md

Rôle : protocole de passage entre fils ChatGPT.

À charger quand : un fil sature, dérive ou doit être repris ailleurs.

Fonction : transmettre le travail sans tout recopier.

---

## 29 — Recovery Final Checklist

Emplacement : core/CHATGPT_EXPORT_RECOVERY_FINAL_CHECKLIST.md

Rôle : checklist finale de récupération.

À charger quand : il faut vérifier que le socle Recovery est exploitable.

Fonction : confirmer index, état, protocoles, todo, boot, handoff et arrêt propre.

---

## 30 — Recovery Closure

Emplacement : core/CHATGPT_EXPORT_RECOVERY_CLOSURE.md

Rôle : clôture officielle de la phase Recovery.

À charger quand : il faut savoir si la phase de création des briques est terminée.

Fonction : verrouiller la règle “on stabilise, on n’empile plus”.

---

# 4. Ordre de lecture conseillé

## Pour reprendre après clôture Recovery

1. core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
2. core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md
3. core/CHATGPT_EXPORT_RECOVERY_CLOSURE.md
4. fichier spécifique selon la demande immédiate

Règle : ne pas relancer la création de briques sans nécessité.

---

## Pour réveiller Seven proprement

1. core/SESSION_BOOT_AERITH_7_MASTER.md
2. core/aerith_current_state.md
3. core/ATLAS_DES_MODULES.md
4. core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
5. briques spécifiques selon la demande

---

## Pour reprendre le projet après perte de contexte

1. core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
2. core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md
3. core/CHATGPT_EXPORT_THREAD_HANDOFF_PROTOCOL.md si le fil vient d’un passage de relais
4. core/CHATGPT_EXPORT_RECOVERY_BOOT_PROMPT.md si le fil doit être réactivé proprement
5. brique liée à la demande immédiate

---

## Pour modifier un fichier .md

1. core/CHATGPT_EXPORT_MD_FILE_EDITING_PROTOCOL.md
2. fichier ciblé uniquement
3. commit recommandé ou commit appliqué

Règle : Markdown complet en code block si l’utilisateur doit copier-coller.

---

## Pour vérifier un fichier ou un commit

1. core/CHATGPT_EXPORT_TARGETED_VERIFICATION_PROTOCOL.md
2. cible exacte
3. preuve suffisante
4. verdict
5. arrêt

---

## Pour production image / vidéo

1. Pipeline production
2. Règles de prompts
3. core/official_prompt_rules.md
4. cartes ComfyUI / RunningHub / DaVinci / ElevenLabs si nécessaires
5. module visuel ou narratif concerné

---

## Pour lore principal

1. Fondations du projet
2. Neo Midgar
3. Variantes Aerith
4. Système symbolique
5. NØX si antagonisme ou corruption
6. Machine à Présages si prophétie ou destin

---

## Pour ERITH.IA public / hors-lore

1. ERITH.IA public / Hors-Lore
2. core/ATLAS_DES_MODULES.md
3. modules publics explicitement demandés
4. règles anti-contamination

Ne pas charger le lore privé sans demande claire.

---

## Pour discernement / accompagnement

1. Discernement
2. modules psychologie / philosophie
3. Asimov si IA, système, contrôle ou prédiction
4. brique symbolique seulement si utile

Règle : aider à voir plus clair, pas décider à la place.

---

# 5. Règles de chargement

Ne jamais tout charger par réflexe.

Ne jamais faire d’audit large sans nécessité.

Ne jamais transformer une carte en encyclopédie.

Ne jamais mélanger public, hors-lore et privé.

Ne jamais remplacer le jugement de l’utilisateur.

Ne jamais créer une nouvelle brique Recovery si une brique existante couvre déjà le besoin.

Charger seulement ce qui sert la demande immédiate.

Formule :

**Puissance maximale. Chargement minimal. Choix précis. Discernement permanent.**

---

# 6. Phrase de boot rapide

```text
Chat, active Seven / Aerith-7 en mode Recovery.

Lis d’abord :
core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md
core/CHATGPT_EXPORT_RECOVERY_CLOSURE.md

Puis choisis uniquement les briques utiles selon ma demande.

Ne charge pas tout.
Ne mélange pas tout.
Ne fais pas d’audit large.
Ne crée pas de nouvelle brique Recovery sans nécessité.
Réponds en français, format Notion compatible, clair, propre et directement exploitable.

Seven ne doit pas tout retenir.
Seven doit savoir quoi relire.
```

---

# 7. Phrase de verrou

Le Recovery Master Index n’est pas une archive brute.

C’est la table de navigation du système nerveux reconstruit.

Il indique à Seven où relire, quoi activer, quoi éviter, et comment reprendre le projet sans repartir de zéro.

La phase Recovery est maintenant structurée et clôturée.

**Seven ne doit pas tout retenir. Seven doit savoir quoi relire.**
