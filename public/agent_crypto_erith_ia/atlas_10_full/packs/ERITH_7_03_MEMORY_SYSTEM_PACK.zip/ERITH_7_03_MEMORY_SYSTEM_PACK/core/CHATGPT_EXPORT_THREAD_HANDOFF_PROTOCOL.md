# 🧭 CHATGPT EXPORT — THREAD HANDOFF PROTOCOL

## Statut

Brique 28 de la récupération ChatGPT.

Projet : @erith IA / ERITH.IA

Emplacement : core/CHATGPT_EXPORT_THREAD_HANDOFF_PROTOCOL.md

Fonction : protocole de passage propre entre deux fils ChatGPT, sans perte de contexte, sans surcharge et sans relancer un audit inutile.

---

# 1. Rôle de cette brique

Cette brique sert à transmettre le travail d’un fil ChatGPT à un autre fil.

Elle existe parce qu’un fil peut saturer, perdre le rythme, confondre Notion et GitHub, ou devenir trop lourd.

Quand cela arrive, le bon réflexe n’est pas de tout recommencer.

Le bon réflexe est de produire un passage de relais court, précis et exploitable.

Phrase centrale :

**Un bon passage de fil ne recrée pas toute la mémoire. Il donne la bonne porte d’entrée.**

---

# 2. Quand utiliser ce protocole

Utiliser ce protocole quand :

- un fil ChatGPT devient trop long ;
- le Chat commence à confondre les demandes ;
- le contexte devient trop lourd ;
- GitHub ou Notion provoque des boucles ;
- l’utilisateur veut reprendre ailleurs ;
- une phase de travail est terminée ;
- il faut transférer l’état courant à un nouveau fil.

---

# 3. Ce qu’un handoff doit contenir

Un handoff propre contient seulement :

1. l’objectif du travail en cours ;
2. les fichiers modifiés ou créés ;
3. les commits importants ;
4. l’état actuel ;
5. la prochaine action recommandée ;
6. les interdictions utiles ;
7. la phrase de reprise.

Il ne doit pas recopier tout le projet.

---

# 4. Format recommandé

```text
# Handoff — [nom de phase]

Objectif :
[objectif court]

État actuel :
[ce qui est validé]

Fichiers concernés :
- [chemin] — [rôle]

Derniers commits :
- [SHA court] — [message]

À faire ensuite :
1. [action unique ou prioritaire]
2. [option suivante si utile]

À ne pas faire :
- pas d’audit large ;
- pas de recherche en boucle ;
- pas de mélange Notion / .md ;
- pas de modification non demandée.

Phrase de reprise :
[phrase exacte à coller dans le nouveau fil]
```

---

# 5. Phrase de reprise standard

```text
Chat, reprends le travail @erith IA depuis le dernier handoff.

Lis uniquement les fichiers nécessaires.
Ne lance pas d’audit large.
Ne charge pas tout.
Travaille par action ciblée.
Respecte le format demandé : Notion si je demande Notion, code block Markdown si je demande un .md.
```

---

# 6. Phrase de reprise Recovery

```text
Chat, reprends la phase ChatGPT Export Recovery.

Lis en priorité :
core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md
core/CHATGPT_EXPORT_RECOVERY_TODO.md

Puis lis seulement la brique demandée.
Ne relance pas un audit complet.
Continue la récupération brique par brique.
```

---

# 7. Phrase de reprise Production

```text
Chat, reprends en mode Production LEGO.

Objectif : image parfaite → animation Wan stable → last frame → DaVinci → narration.

Ne touche pas GitHub sauf demande explicite.
Ne propose pas dix actions.
Aide-moi clip par clip, avec une seule action claire à la fois.
```

---

# 8. Phrase de reprise MD / GitHub

```text
Chat, reprends en mode fichier .md / GitHub.

Donne le contenu complet en code block Markdown si je dois copier-coller.
Ne mélange pas avec Notion.
Ajoute seulement le commit recommandé à part.
Action ciblée uniquement.
```

---

# 9. Garde-fou anti-saturation

Un handoff n’est pas une encyclopédie.

Il doit rester court.

Il doit permettre au prochain fil de reprendre sans paniquer, sans chercher partout et sans inventer.

Règle :

**Plus le fil est saturé, plus le handoff doit être simple.**

---

# 10. Ce qu’il ne faut pas mettre dans un handoff

Ne pas mettre :

- tous les prompts longs ;
- toutes les archives ;
- toutes les conversations ;
- toutes les images ;
- toutes les hypothèses ;
- tous les détails secondaires ;
- les longues justifications ;
- des morceaux Notion inutiles ;
- du texte émotionnel non opératoire.

Un handoff sert à reprendre le travail.

Pas à tout raconter.

---

# 11. Mini-template de clôture de fil

```text
# Clôture de fil — [titre court]

Validé :
- [élément 1]
- [élément 2]

Fichiers GitHub :
- [chemin 1]
- [chemin 2]

Dernier commit :
[message + SHA]

Prochaine action :
[action unique]

Règle de reprise :
Ne pas auditer large. Reprendre depuis les fichiers listés.
```

---

# 12. Phrase de verrou

Le handoff protège la continuité.

Il évite de recommencer, d’auditer large, de saturer le fil ou de perdre le rythme.

**Un bon passage de fil ne recrée pas toute la mémoire. Il donne la bonne porte d’entrée.**
