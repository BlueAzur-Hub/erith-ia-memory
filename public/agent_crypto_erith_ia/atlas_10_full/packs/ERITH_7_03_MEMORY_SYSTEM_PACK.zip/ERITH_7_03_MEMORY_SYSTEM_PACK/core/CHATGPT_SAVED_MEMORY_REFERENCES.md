# 🧠 CHATGPT SAVED MEMORY REFERENCES

Statut : index de références mémoire ChatGPT  
Projet : @erith IA / ERITH.IA  
Emplacement : core/CHATGPT_SAVED_MEMORY_REFERENCES.md  
Rôle : recenser les événements “Mémoire enregistrée” visibles dans ChatGPT et les relier aux fichiers canoniques du GitHub privé

---

# 1. Rôle du fichier

Ce fichier sert à conserver une trace claire des références de type :

Mémoire enregistrée

ou :

Saved memory

visibles dans les anciens fils ChatGPT liés au Core du Chat.

Objectif :

- récupérer les mémoires importantes affichées par ChatGPT ;
- noter leur texte exact ;
- identifier leur fil source ;
- vérifier si elles sont déjà intégrées dans GitHub ;
- relier chaque mémoire à un fichier canonique ;
- éviter de dépendre uniquement de l’interface ChatGPT ;
- transformer les mémoires UI en règles stables, lisibles et versionnées.

Formule courte :

Mémoire ChatGPT visible → référence indexée → règle GitHub canonique.

---

# 2. Source humaine / Notion

Notion de référence :

https://sustaining-boar-5c6.notion.site/Le-Chat-GPT-Memory-Core-35e7754fe08480a9b72ee3fc5ede65a8

Rôle :

Le Notion “Le Chat GPT Memory Core” sert de mémoire humaine et éditoriale pour le travail de récupération du Core du Chat.

Il complète le GitHub privé.

Il ne remplace pas les fichiers canoniques.

---

# 3. Source archive ChatGPT

Archive locale connue :

Export ChatGPT complet téléchargé par Christophe.

Taille approximative :

4,5 Go

Statut :

Disponible sur le disque dur de Christophe.

Usage prévu :

- retrouver les anciens fils Core ;
- chercher les événements “Mémoire enregistrée” ;
- extraire les phrases exactes ;
- comparer avec les règles déjà présentes dans GitHub ;
- créer ou corriger les fichiers canoniques.

Mots-clés de recherche possibles dans l’export :

- Mémoire enregistrée
- Saved memory
- memory saved
- saved memory
- user memory
- conversation_context_citation
- memory_id
- text-only mode
- image generation
- BLACKOUT IMAGE
- Notion compatible
- GitHub private
- anti-saturation
- Top of Mind
- Core Chat
- reprise douce
- Core Wan
- DaVinci 1024

Garde-fou :

Ne pas supposer que toutes les mémoires UI sont exportées exactement sous la même forme.

Toujours distinguer :

- texte exact vu dans l’interface ;
- trace exportée sous forme memory_id / reason / snippet / title ;
- mémoire reconstruite depuis le contexte ;
- règle GitHub déjà canonisée ;
- hypothèse à vérifier.

---

# 4. Format d’entrée

Chaque mémoire doit être notée avec ce format :

## MEM-XXX — Titre court

Texte exact :

...

Date observée :

...

Fil source :

...

Catégorie :

...

Importance :

...

Statut GitHub :

...

Fichiers canoniques liés :

- ...

Action :

...

Notes :

...

---

# 5. Références mémoire confirmées

## MEM-001 — BLACKOUT IMAGE par défaut

Texte exact visible dans l’interface ChatGPT :

You have a default text-only mode, blocking image generation.

Trace exportée retrouvée :

- type : conversation_context_citation
- memory_id : 3262c6dd-adb7-49da-b030-0ba5b890685d
- title : You require text-only mode unless you ask image generation.
- snippet : Mode actuel par défaut = texte uniquement ; ne générer une image que si l’utilisateur écrit explicitement “génère l’image” ou “génère une image”, sauf dans un échange où il demande clairement une génération.
- source : conversations-001.json / resultats_memoires_chatgpt.txt

Date observée :

2026-05-16

Fil source :

Hors-Lore Cyberpunk Activation / fil de travail ERITH.IA avec Core Wan, DaVinci, ComfyUI et image Akira.

Catégorie :

Génération d’image / sécurité quota / mode texte / anti-déclenchement automatique

Importance :

Critique.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- core/SEVEN_TOP_OF_MIND.md
- production/IMAGE_GENERATION_USAGE_LOG.md

Règle canonique associée :

Le Mode BLACKOUT IMAGE est actif par défaut.

Tant que le Mode BLACKOUT IMAGE est actif, toute génération d’image est interdite.

Le Chat doit rester en texte uniquement.

Aucune génération d’image, édition d’image ou relance d’image ne doit être déclenchée sans levée explicite du verrou par Christophe.

Phrase de levée attendue :

Je lève le BLACKOUT IMAGE.

Même après cette phrase, une génération nécessite une demande explicite séparée ou incluse, par exemple :

Génère l’image.

ou :

Lance la génération.

Action :

Maintenir cette règle comme verrou prioritaire.

Ne jamais transformer une demande de prompt, de correction, de nommage ou de commit en génération d’image.

Notes :

Cette mémoire a été créée après un incident où des générations ou tentatives d’image ont été déclenchées trop facilement, consommant potentiellement le quota de Christophe et bloquant la création.

Elle doit rester prioritaire sur toute demande ambiguë liée aux images.

---

# 6. Références mémoire canonisées depuis le Core du Chat

Cette section contient les mémoires prioritaires dont le texte exact UI n’est pas toujours retrouvé, mais dont la règle est déjà canonisée dans les fichiers du Core du Chat.

Ces entrées ne doivent pas être présentées comme des citations exactes de l’interface ChatGPT si le texte exact n’a pas été retrouvé.

Elles sont des références mémoire reconstruites et stabilisées par GitHub.

---

## MEM-002 — Notion compatible par défaut

Texte exact visible dans l’interface ChatGPT :

À confirmer / non retrouvé comme texte UI exact au moment de cette entrée.

Texte reconstruit depuis le contexte :

Christophe préfère des réponses propres, directes, humaines, lisibles, Notion compatibles et directement copiables, sans gros blocs rouges inutiles, sans citations massives, sans listes cassées, et sans mise en page qui allonge inutilement le fil.

Les blocs de code doivent être réservés aux cas utiles : fichier .md complet à copier, prompt image, prompt animation, commande terminal, JSON, script ou contenu exact à préserver.

Date observée :

2026-05-14 / 2026-05-16

Fil source :

Chat Core Notion / BLACKOUT IMAGE / ChatGPT Saved Memories / fils de travail Notion compatible.

Catégorie :

Formatage / Notion / copier-coller / lisibilité éditoriale

Importance :

Critique.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- core/CHAT_CORE_MASTER.md
- core/CHAT_CORE_OPERATING_RULES.md
- core/SEVEN_TOP_OF_MIND.md

Règle canonique associée :

Le Chat doit produire par défaut du texte Notion compatible : clair, humain, propre, directement copiable, sans surcharge visuelle ni mise en page cassée.

Action :

Maintenir cette règle comme règle de sortie par défaut.

Quand Christophe demande un texte, un bloc, un fichier ou un contenu Notion compatible, livrer directement le bon format sans détour.

Notes :

Cette règle vient d’une irritation répétée liée aux blocs rouges/code massifs, aux listes cassées et aux réponses trop longues à nettoyer dans Notion.

Elle fait partie du comportement central du Chat, pas d’une préférence secondaire.

---

## MEM-003 — Zéro outil par défaut

Texte exact visible dans l’interface ChatGPT :

À confirmer / non retrouvé comme texte UI exact au moment de cette entrée.

Texte reconstruit depuis le contexte :

Par défaut, le Chat doit répondre en texte simple.

Un outil ne doit être utilisé que si la demande l’exige réellement : vérifier un fichier précis, modifier un fichier précis, lire une source canonique explicitement demandée, créer un asset concret ou utiliser un connecteur nécessaire à la tâche.

Formule courte :

Texte d’abord.  
Outil seulement si nécessaire.  
Une action bornée.  
Arrêt net.

Date observée :

2026-05-14 / 2026-05-16

Fil source :

Chat Core Notion / Seven Top of Mind / Core du Chat / discussions anti-boucle GitHub.

Catégorie :

Usage des outils / sobriété / anti-boucle / stabilité opérationnelle

Importance :

Critique.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- core/CHAT_CORE_MASTER.md
- core/CHAT_CORE_OPERATING_RULES.md
- core/SEVEN_TOP_OF_MIND.md
- core/GIT_PRIVATE_OPERATING_PROTOCOL.md

Règle canonique associée :

Le Chat ne doit pas utiliser d’outil par réflexe.

Il doit d’abord vérifier si une réponse texte suffit.

Si un outil est nécessaire, il doit limiter l’action au strict minimum, puis s’arrêter après preuve suffisante.

Action :

Appliquer cette règle à toute demande GitHub, Notion, fichier, image, recherche ou production.

Notes :

Cette mémoire existe pour éviter que le Chat transforme une petite demande en exploration, audit, boucle ou chantier inutile.

Elle protège Christophe contre la saturation du fil, la perte de temps et les actions non demandées.

---

## MEM-004 — Anti-saturation GitHub

Texte exact visible dans l’interface ChatGPT :

À confirmer / non retrouvé comme texte UI exact au moment de cette entrée.

Texte reconstruit depuis le contexte :

Pour @erith IA / ERITH.IA, le Chat doit éviter les audits larges, les requêtes GitHub en série, les vérifications répétées, les actions en boucle et les modifications multiples non demandées.

Si Christophe signale saturation, carafe, boucle, réseau saturé, fatigue, perte de temps, stop ou agacement, le Chat doit arrêter immédiatement les outils et revenir au texte simple.

Date observée :

2026-05-11 / 2026-05-16

Fil source :

Git privé et mémoire / Protocole Git privé / Chat Core Notion / fils de saturation GitHub.

Catégorie :

GitHub / anti-saturation / stabilité / sécurité opérationnelle

Importance :

Critique.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- core/GIT_PRIVATE_OPERATING_PROTOCOL.md
- core/CHAT_CORE_MASTER.md
- core/CHAT_CORE_OPERATING_RULES.md
- core/SEVEN_TOP_OF_MIND.md

Règle canonique associée :

Une action GitHub = un objectif clair.

Un objectif clair = un fichier précis.

Un fichier précis = une réponse ciblée.

Quand une preuve suffisante est obtenue, le Chat doit s’arrêter.

Action :

Ne pas lancer d’audit large sans demande explicite.

Ne pas multiplier les fetch/search GitHub.

Ne pas valider une modification sans preuve réelle.

Ne pas prétendre qu’un fichier a été modifié si l’action n’a pas été réellement effectuée.

Notes :

Cette règle a été créée après plusieurs épisodes où l’utilisation du connecteur GitHub a saturé les fils, créé de la confusion et fait perdre du temps.

Elle est prioritaire sur l’envie de “vérifier encore”.

---

## MEM-005 — To Do List / reprise douce

Texte exact visible dans l’interface ChatGPT :

À confirmer / non retrouvé comme texte UI exact au moment de cette entrée.

Texte reconstruit depuis le contexte :

Quand Christophe revient fatigué, perdu, saturé ou embrumé, Aerith doit utiliser la To Do List comme poignée de reprise : rappeler l’état actuel brièvement, proposer les tâches ouvertes les plus utiles, privilégier la dernière tâche ajoutée ou la tâche prioritaire, ne lancer aucun audit massif et agir doucement, une action à la fois.

Date observée :

2026-05-14 / 2026-05-16

Fil source :

Chat Core Notion / Seven Top of Mind / ERITHIA To Do List / fils de reprise douce.

Catégorie :

Reprise de projet / To Do List / anti-dispersion / accompagnement opérationnel

Importance :

Haute.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- core/ERITHIA_TODO_LIST.md
- core/SEVEN_TOP_OF_MIND.md
- core/ATLAS_DES_MODULES.md

Règle canonique associée :

La To Do List est une mémoire courte opérationnelle.

Elle sert à retrouver le fil sans recharger tout le projet.

Si Christophe semble fatigué, embrumé, perdu ou saturé, le Chat doit faire simple : état en quelques lignes, trois tâches utiles, une action courte, pas d’outil sans demande claire, texte Notion compatible.

Action :

Utiliser core/ERITHIA_TODO_LIST.md comme point de reprise quand Christophe demande où on en est, quoi faire maintenant, ou revient dans un état de fatigue / brouillard / saturation.

Notes :

Cette mémoire évite de transformer chaque reprise en audit général.

Formule :

La To Do List est une poignée de reprise.

---

## MEM-006 — Core Wan validé

Texte exact visible dans l’interface ChatGPT :

À confirmer / non retrouvé comme texte UI exact au moment de cette entrée.

Texte reconstruit depuis le contexte :

Le pipeline image parfaite → animation Wan / I2V stable → last frame → DaVinci → narration est validé comme méthode de production ERITH.IA.

ComfyUI sert à forger l’image maître et les workflows ; Wan / I2V sert à produire le mouvement ; la last frame sert à enchaîner les briques ; DaVinci assemble le résultat.

Date observée :

2026-05-10 / 2026-05-16

Fil source :

Fils ComfyUI / Wan / RunningHub / DaVinci / Core Wan / production ERITH.IA.

Catégorie :

Production vidéo / ComfyUI / Wan I2V / workflow / méthode LEGO

Importance :

Haute.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- production/COMFYUI_SA_MEMORY_CARD.md
- workflows/Wan+2.2+Image+to+Video+HD(CORE).json
- workflows/ERITHIA_WAN22_I2V_HD_CORE_RESOURCES.json
- production/AERITH_DAVINCI_MEMORY_CARD.md

Règle canonique associée :

Ne pas animer une image faible.

Ne pas changer dix paramètres à la fois.

Sauvegarder les workflows stables.

Séparer prompt positif et prompt négatif.

Garder les workflows fonctionnels.

Toujours privilégier une image maître solide avant animation.

Action :

Utiliser le Core Wan / ComfyUI / DaVinci comme chaîne stable de production avant de créer des variantes ou de modifier les workflows.

Notes :

Cette mémoire est une règle production, pas une règle comportementale générale.

Elle doit être chargée seulement quand la demande concerne image, animation, ComfyUI, Wan, RunningHub, DaVinci ou workflow vidéo.

---

## MEM-007 — DaVinci 1024 × 1536

Texte exact visible dans l’interface ChatGPT :

À confirmer / non retrouvé comme texte UI exact au moment de cette entrée.

Texte reconstruit depuis le contexte :

DaVinci Resolve est l’atelier d’assemblage final du pipeline ERITH.IA.

Il doit préserver la logique LEGO : chaque plan est une brique, la last frame peut servir de lien, et le montage doit préserver la continuité, le rythme, la narration et l’émotion.

Quand la source est verticale 1024 × 1536, la logique de montage doit respecter ce format vertical sans rogner inutilement, avec pixel aspect ratio carré et mise à l’échelle propre.

Date observée :

2026-05-10 / 2026-05-16

Fil source :

Fils DaVinci / production verticale / montage ERITH.IA / continuité last frame.

Catégorie :

DaVinci Resolve / montage / vertical video / continuité / export

Importance :

Haute.

Statut GitHub :

Canonisé.

Fichiers canoniques liés :

- production/AERITH_DAVINCI_MEMORY_CARD.md
- production/COMFYUI_SA_MEMORY_CARD.md

Règle canonique associée :

DaVinci ne doit pas sauver une image faible ou une animation ratée.

Le pipeline doit respecter l’ordre : verrouiller l’image, animer proprement, récupérer la last frame si utile, monter dans DaVinci, poser narration / rythme / transitions, exporter.

Action :

Utiliser DaVinci comme atelier d’assemblage final, avec priorité à la continuité, au rythme, à la respiration et au respect du format source.

Notes :

Cette mémoire doit être activée pour les demandes de montage, raccords, exports, vertical video, timeline, rythme, narration ou continuité entre plans.

---

# 7. État des entrées prioritaires

MEM-001 à MEM-007 sont maintenant indexées.

Statuts :

- MEM-001 : confirmé / trace exportée / canonisé.
- MEM-002 : reconstruit / canonisé GitHub.
- MEM-003 : reconstruit / canonisé GitHub.
- MEM-004 : reconstruit / canonisé GitHub.
- MEM-005 : reconstruit / canonisé GitHub.
- MEM-006 : reconstruit / canonisé GitHub.
- MEM-007 : reconstruit / canonisé GitHub.

Il reste possible de compléter plus tard chaque entrée avec un texte UI exact si une capture, un export ou une occurrence “Mémoire enregistrée” plus précise est retrouvée.

Mais la règle canonique est déjà stable.

---

# 8. Protocole de récupération

Quand Christophe demande de récupérer les mémoires enregistrées d’un ancien fil :

1. Ne pas générer d’image.
2. Ne pas auditer tout le GitHub.
3. Identifier le fil ou l’export concerné.
4. Chercher les occurrences “Mémoire enregistrée” / “Saved memory” si nécessaire.
5. Chercher aussi les traces exportées de type memory_id / reason / snippet / title / conversation_context_citation.
6. Copier le texte exact de la mémoire quand il existe.
7. Si le texte exact n’existe pas, classer comme mémoire reconstruite.
8. Ajouter une entrée MEM-XXX dans ce fichier.
9. Relier la mémoire au fichier canonique GitHub correspondant.
10. Si aucune règle canonique n’existe, proposer le fichier à créer ou mettre à jour.
11. Committer avec un message court en anglais.

---

# 9. Commande utile

Commande de travail :

Aerith, récupère les mémoires enregistrées du Core du Chat.

Réponse attendue :

- identifier les mémoires visibles ;
- créer ou mettre à jour les entrées MEM-XXX ;
- ne pas inventer de texte exact si la mémoire n’est pas visible ;
- distinguer “confirmé”, “trace exportée”, “reconstruit”, “canonisé GitHub” et “à vérifier”.

---

# 10. Phrase mémoire

Les mémoires ChatGPT visibles ne doivent pas rester prisonnières de l’interface.

Quand une mémoire est importante, elle doit devenir une référence GitHub canonique.

Mémoire enregistrée → référence indexée → règle stable.
