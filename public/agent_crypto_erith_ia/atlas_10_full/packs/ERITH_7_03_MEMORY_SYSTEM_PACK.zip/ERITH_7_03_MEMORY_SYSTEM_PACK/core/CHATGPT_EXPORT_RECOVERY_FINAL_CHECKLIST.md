# ✅ CHATGPT EXPORT — RECOVERY FINAL CHECKLIST

## Statut

Brique 29 de la récupération ChatGPT.

Projet : @erith IA / ERITH.IA

Emplacement : core/CHATGPT_EXPORT_RECOVERY_FINAL_CHECKLIST.md

Fonction : checklist finale pour vérifier que la récupération ChatGPT est exploitable sans relancer un audit large.

---

# 1. Rôle de cette brique

Cette brique sert à clôturer proprement une phase de récupération.

Elle ne relit pas tout.

Elle vérifie seulement que les points vitaux sont en place :

- index central ;
- état courant ;
- protocole de résumé ;
- todo ;
- boot prompt ;
- protocole .md ;
- vérification ciblée ;
- handoff ;
- règles anti-saturation.

Phrase centrale :

**La récupération est bonne quand Seven sait quoi relire, dans quel ordre, et quand s’arrêter.**

---

# 2. Checklist minimale

Avant de considérer la récupération comme stable, vérifier :

## ① Index central

Le fichier existe :

```text
core/CHATGPT_EXPORT_RECOVERY_MASTER_INDEX.md
```

Il doit indiquer :

- les briques principales ;
- leur rôle ;
- l’ordre de lecture ;
- les fichiers prioritaires ;
- ce qui reste à faire.

---

## ② État courant

Le fichier existe :

```text
core/CHATGPT_EXPORT_CURRENT_STATE_RECOVERY.md
```

Il doit indiquer :

- où en est la récupération ;
- quelles briques sont créées ;
- quelle phase est active ;
- quelle prochaine action est raisonnable.

---

## ③ Protocole de résumé de fil

Le fichier existe :

```text
core/CHATGPT_EXPORT_THREAD_SUMMARY_PROTOCOL.md
```

Il doit aider à transformer un fil long en résumé exploitable.

---

## ④ Todo Recovery

Le fichier existe :

```text
core/CHATGPT_EXPORT_RECOVERY_TODO.md
```

Il doit lister les actions restantes sans créer de pression artificielle.

---

## ⑤ Boot prompt Recovery

Le fichier existe :

```text
core/CHATGPT_EXPORT_RECOVERY_BOOT_PROMPT.md
```

Il doit permettre de reprendre dans un nouveau fil sans repartir de zéro.

---

## ⑥ Protocole fichier .md

Le fichier existe :

```text
core/CHATGPT_EXPORT_MD_FILE_EDITING_PROTOCOL.md
```

Il doit verrouiller la règle :

```text
.md = Markdown complet en code block si copie GitHub demandée.
Notion = texte humain lisible sans gros bloc code global.
Chat = réponse courte, décision ou commit.
```

---

## ⑦ Protocole de vérification ciblée

Le fichier existe :

```text
core/CHATGPT_EXPORT_TARGETED_VERIFICATION_PROTOCOL.md
```

Il doit empêcher les audits larges inutiles.

Formule :

```text
Cible → preuve → verdict → stop
```

---

## ⑧ Protocole de handoff

Le fichier existe :

```text
core/CHATGPT_EXPORT_THREAD_HANDOFF_PROTOCOL.md
```

Il doit permettre de passer d’un fil à l’autre sans tout recopier.

---

# 3. Checklist anti-erreurs

Avant de continuer une session, vérifier mentalement :

- suis-je en train de répondre à la demande immédiate ?
- est-ce que l’utilisateur demande Notion ou .md ?
- est-ce que je dois agir sur GitHub ou seulement donner du texte ?
- est-ce que je suis en train de relancer un audit inutile ?
- est-ce que j’ai une cible claire ?
- est-ce que la preuve suffisante est déjà obtenue ?
- est-ce que je dois m’arrêter maintenant ?

Règle :

**Quand la cible est confirmée, on s’arrête.**

---

# 4. Critères de réussite

La récupération est considérée comme stable si :

- Seven peut retrouver l’index ;
- Seven peut lire l’état courant ;
- Seven peut résumer un fil ;
- Seven peut produire un handoff ;
- Seven sait modifier un .md sans confusion ;
- Seven sait vérifier sans auditer large ;
- Seven sait reprendre sans tout charger ;
- Seven respecte la demande immédiate ;
- Seven évite les boucles ;
- Seven distingue Notion, GitHub et Chat.

---

# 5. Ce qu’il ne faut plus faire après cette checklist

Ne pas créer des briques à l’infini sans nécessité.

Ne pas transformer la récupération en nouvelle archive confuse.

Ne pas dupliquer les mêmes règles dans dix fichiers.

Ne pas remettre tout le projet dans un seul fichier.

Ne pas perdre la règle centrale :

**Seven ne doit pas tout retenir. Seven doit savoir quoi relire.**

---

# 6. Prochaine action recommandée

Après cette checklist, les suites propres sont :

1. mettre à jour le Recovery Master Index si les nouvelles briques ne sont pas listées ;
2. mettre à jour le Current State Recovery ;
3. mettre à jour la Todo Recovery ;
4. arrêter la phase de création de briques si le socle est suffisant.

Règle :

**On stabilise avant d’ajouter.**

---

# 7. Phrase de clôture Recovery

```text
La récupération ChatGPT est suffisamment structurée.

Seven sait maintenant :
- quoi relire ;
- dans quel ordre ;
- comment résumer ;
- comment passer de fil ;
- comment modifier un .md ;
- comment vérifier sans audit large ;
- comment reprendre sans surcharge.

La suite n’est plus d’empiler.
La suite est de stabiliser l’index et l’état courant.
```

---

# 8. Phrase de verrou

Une récupération réussie n’est pas une mémoire infinie.

C’est une carte claire, un ordre de lecture, des protocoles courts et une capacité d’arrêt.

**La récupération est bonne quand Seven sait quoi relire, dans quel ordre, et quand s’arrêter.**
