# SEVEN HEAVEN — YouTube Sync / UI Postmortem

Date : 2026-05-24
Projet : Seven Portable Terminal / ERITH.IA / Blue Azur
Dépôt concerné : BlueAzur-Hub/erith-ia-memory
Dépôt d’archive : BlueAzur-Hub/erith-ia-notion-archive-private

---

# Résumé court

Ce fil archive la finalisation de la fonction YouTube Memory du Seven Portable Terminal : synchronisation YouTube par GitHub Actions, génération de JSON publics, affichage dans GitHub Pages, ajout d’un sélecteur Blue Azur / Aerith IA, puis stabilisation du Top 10 vidéos sous forme de menu repliable.

Le résultat final fonctionne, mais le chemin a été beaucoup trop long : environ 7 à 8 heures de travail réel, avec environ 50 cycles de correction / upload / test / refresh. Avec un cadrage propre dès le départ, la même fonction aurait dû prendre environ 1 h 30 à 2 h 30, et le menu Top 10 seul 20 à 40 minutes.

---

# Objectif initial

Créer dans le Seven Portable Terminal un panneau YouTube Memory capable de :

- lire automatiquement les données YouTube exportées ;
- afficher les meilleures vidéos ;
- classer les vidéos par vues publiques ;
- construire des familles mémoire ;
- produire un brief automatique ;
- éviter de devoir consulter YouTube Studio pour les signaux simples ;
- fonctionner dans GitHub Pages avec des JSON publics.

L’objectif a ensuite évolué vers :

- un mode avancé ;
- un Top 10 exploitable ;
- une seconde chaîne Aerith IA ;
- un sélecteur de chaîne ;
- une liste Top 10 repliable / dépliable ;
- une UI stable, compacte et lisible.

---

# Problèmes rencontrés

## 1. Mauvaise chaîne lue

Le système affichait parfois Blue Azur alors que l’utilisateur regardait Aerith IA. Le problème venait d’abord du jeton OAuth associé à la mauvaise chaîne, puis de scripts UI qui rechargeaient encore les données Blue Azur.

## 2. Fichiers JSON multiples

La logique finale devait distinguer clairement :

- les données Blue Azur ;
- les données Aerith IA ;
- le fichier d’index des chaînes ;
- l’ancien fichier de compatibilité.

## 3. Scripts concurrents dans index.html

Le problème le plus grave venait de plusieurs scripts JavaScript qui écrivaient dans les mêmes zones DOM. Résultat :

- Top 10 qui affiche la mauvaise chaîne ;
- bouton ouvrir / replier instable ;
- menu qui s’ouvre tout seul ;
- menu qui se replie puis se rouvre ;
- carte Signal stratégique vide ou incohérente ;
- numérotation qui commence à 0 ;
- patchs qui corrigent une chose et en cassent une autre.

## 4. Cache GitHub Pages

Le rendu GitHub Pages a parfois retardé la visibilité des corrections, ce qui a augmenté la confusion.

## 5. Surcharge du fil

Le fil ChatGPT est devenu lourd et lent. Certaines réponses ont pris plusieurs minutes, parfois plus de 10 minutes. À ce stade, il fallait réduire le dialogue et livrer uniquement les fichiers.

---

# Correction finale validée

La correction efficace a été :

- supprimer les scripts concurrents ;
- arrêter l’empilement de patchs ;
- créer un seul contrôleur JavaScript responsable de la zone YouTube ;
- utiliser un conteneur Top 10 unique ;
- fermer le menu par défaut ;
- utiliser un bouton manuel ouvrir / replier ;
- éviter les re-renders automatiques parasites ;
- ne charger que le JSON de la chaîne sélectionnée ;
- renommer les cibles DOM si un ancien script les utilisait encore.

Commit final recommandé :

Fix YouTube top 10 stable menu

---

# Leçon technique

Quand une interface HTML/CSS/JS devient instable, il ne faut pas empiler les corrections.

Méthode correcte :

1. Lire le fichier réel.
2. Identifier tous les scripts qui écrivent dans le DOM.
3. Supprimer les scripts concurrents.
4. Garder un seul contrôleur.
5. Garder une seule cible DOM.
6. Modifier le minimum nécessaire.
7. Livrer le fichier complet.
8. Tester.
9. Stopper dès validation.

---

# Leçon opérationnelle

Quand Christophe demande un fichier, la bonne réponse est le fichier.

Pas un plan.
Pas une promesse.
Pas une explication longue.
Pas un commentaire supplémentaire.

Réponse attendue :

- fichier index.html ;
- zip si utile ;
- message de commit ;
- rien de plus.

---

# Chronologie complète reconstituée du fil

Note : cette section archive l’intégralité opérationnelle du fil disponible dans ChatGPT. Elle n’est pas un verbatim mot à mot exporté par l’interface, car le fil a été partiellement tronqué par saturation et certaines portions n’étaient plus affichées. Elle conserve cependant tous les événements, décisions, erreurs, fichiers, corrections, symptômes et leçons nécessaires pour reconstruire l’incident.

## Phase 1 — Demande initiale et confusion OAuth

Christophe demande comment procéder pour connecter et synchroniser les données YouTube dans Seven Portable Terminal.

Le fil devient vite instable. L’utilisateur indique que le fil ne s’affiche plus correctement depuis des heures à cause de surcharge inutile.

Une première confusion apparaît autour du “fichier OAuth client Google”. L’assistant parle de coller le contenu complet du fichier client OAuth, mais l’utilisateur ne comprend pas de quoi il s’agit.

La clarification finit par arriver :

- ouvrir le fichier JSON avec Notepad ;
- copier tout le contenu ;
- coller dans le champ Value d’un secret GitHub.

Cette explication aurait dû être donnée immédiatement en langage simple.

## Phase 2 — Création des secrets GitHub

La procédure GitHub Secrets est utilisée pour Blue Azur puis Aerith IA.

Secrets nécessaires :

- YOUTUBE_CLIENT_SECRET_JSON
- YOUTUBE_TOKEN_JSON
- YOUTUBE_CLIENT_SECRET_JSON_AERITH
- YOUTUBE_TOKEN_JSON_AERITH

Christophe crée les secrets, mais plusieurs passages créent de la confusion :

- où trouver le JSON client ;
- comment télécharger depuis Google Cloud Console ;
- comment ouvrir le fichier ;
- comment générer le token ;
- pourquoi aucune fenêtre Google ne s’ouvre au lancement du script ;
- pourquoi le script réutilise un ancien token.

Le problème majeur : le script réutilisait un token existant, donc Google ne relançait pas la fenêtre d’autorisation.

Action utilisée : renommer le token existant en backup, puis relancer le script local pour forcer une nouvelle autorisation.

Résultat : token Aerith IA créé, puis collé dans GitHub Secret.

## Phase 3 — Workflow GitHub Actions

Objectif : modifier .github/workflows/youtube_sync.yml pour générer les données YouTube.

Le premier workflow lisait uniquement Blue Azur.

Le workflow devait ensuite générer :

- youtube_memory_blueazur.json
- youtube_memory_aerithia.json
- youtube_channels.json
- youtube_memory_full.json pour compatibilité

Erreur répétée : malgré plusieurs uploads côté utilisateur, le fichier GitHub ne semblait pas se mettre à jour.

Vérification via GitHub : le workflow public affichait encore uniquement :

- Generate Blue Azur YouTube data
- YOUTUBE_CLIENT_SECRET_JSON
- YOUTUBE_TOKEN_JSON

Donc Aerith IA n’était pas encore intégré.

Après plusieurs tentatives, le contenu correct finit par apparaître dans GitHub :

- Generate Blue Azur YouTube data
- Generate Aerith IA YouTube data
- YOUTUBE_CLIENT_SECRET_JSON_AERITH
- YOUTUBE_TOKEN_JSON_AERITH
- copie vers youtube_memory_aerithia.json
- génération de youtube_channels.json

À ce stade, l’API et le workflow deviennent fonctionnels.

## Phase 4 — Premier affichage UI et problème de mauvaise chaîne

L’UI affiche des données, mais pas toujours celles attendues.

Symptôme : quand Christophe sélectionne Aerith IA, certains blocs affichent encore des signaux Blue Azur / Zelda.

Diagnostic : l’interface mélange encore topByViews et topByScore entre plusieurs scripts ou fichiers.

Correction demandée : envoyer index.html complet, sans explication inutile.

Plusieurs versions index.html sont générées :

- SEVEN_YOUTUBE_DUAL_CHANNEL_FILES
- SEVEN_INDEX_HTML_FINAL_FIX
- SEVEN_INDEX_HTML_CLEAN_FINAL
- SEVEN_INDEX_HTML_NOCONFLICT_FINAL
- SEVEN_INDEX_HTML_TOP10_COLLAPSIBLE
- SEVEN_INDEX_HTML_TOP10_MANUAL_TOGGLE
- SEVEN_INDEX_HTML_CHANNEL_GUARD_FINAL
- SEVEN_INDEX_HTML_STABLE_NO_JUMP
- SEVEN_INDEX_HTML_FINAL_UNIQUE_TOP10

Beaucoup trop de versions ont été nécessaires.

## Phase 5 — Suppression du doublon “Meilleur score”

L’utilisateur identifie que “Vidéo locomotive” ou “Meilleur score” fait doublon avec Top vidéo.

Décision :

- supprimer le terme “locomotive” ;
- ne pas afficher “Meilleur score” si cela duplique Top vidéo ;
- clarifier le vocabulaire ;
- préférer “Top vidéo” / “Famille dominante” / “Action Aerith”.

Erreur : certains patchs ont caché la carte par CSS au lieu de nettoyer le DOM et le script.

Leçon : ne pas masquer par CSS un problème qui vient du HTML ou du JS.

## Phase 6 — Top 10 vidéos

Christophe veut que Top 5 devienne Top 10.

Puis il précise l’affichage souhaité :

Ligne 1 :

1. Titre complet de la vidéo

Sur la même ligne :

famille mémoire · durée

Ligne 2 :

vues publiques · score

Sur la même ligne :

lien YouTube complet

L’UI doit rester compacte, lisible et ne pas sortir du cadre.

Plusieurs corrections CSS sont appliquées pour :

- éviter les textes qui sortent du cadre ;
- réduire la hauteur ;
- éviter un rendu de deux feuilles A4 ;
- améliorer les retours à la ligne ;
- rendre les lignes plus compactes.

## Phase 7 — Ajout du sélecteur Blue Azur / Aerith IA

Le sélecteur est ajouté :

Blue Azur | Aerith IA

L’objectif : charger dynamiquement le bon fichier JSON selon la chaîne.

Fichiers attendus :

- ./data/youtube_memory_blueazur.json
- ./data/youtube_memory_aerithia.json

Erreur majeure : certains anciens scripts continuaient à écrire dans les mêmes IDs, notamment ytTopList, ytTopVideo, ytTopFamily, ytStatus, ytMode.

Résultat : le sélecteur semblait fonctionner, mais des blocs étaient ensuite réécrits par un autre script.

## Phase 8 — Liste Top 10 dépliable

Christophe demande : transformer Top 10 vidéos — vues publiques en liste dépliable.

Première approche : utiliser details / summary.

Problème : le menu s’affiche, puis se déroule tout seul sans action.

Deuxième approche : bouton manuel + conteneur hidden.

Problèmes restants :

- le bouton réduire apparaît puis disparaît ;
- le menu se replie une fois sur dix ;
- la liste se réaffiche malgré l’état fermé ;
- le Top 10 Aerith IA n’affiche pas toujours la chaîne Aerith IA ;
- l’ancien script externe réécrit encore la zone.

Diagnostic final : il faut arrêter de cibler l’ancien ID utilisé par script.js.

Correction finale :

- renommer le conteneur Top 10 en ytTopListStable ;
- supprimer les anciens contrôleurs inline ;
- créer un contrôleur unique yt-top10-final-controller ;
- fermer la liste par défaut avec hidden ;
- utiliser un bouton stable ;
- ne pas utiliser MutationObserver ;
- ne pas utiliser setTimeout de re-render ;
- ne plus empiler de scripts ;
- charger uniquement le JSON correspondant au sélecteur actif.

Version finale livrée :

SEVEN_INDEX_HTML_FINAL_UNIQUE_TOP10

Commit recommandé :

Fix YouTube top 10 stable menu

## Phase 9 — Validation finale

L’utilisateur vérifie que le menu fonctionne enfin.

Le résultat visible :

- menu Top 10 fermé ;
- bouton ouvrir stable ;
- bouton replier stable ;
- pas d’ouverture automatique ;
- données correctement liées à la chaîne sélectionnée ;
- rendu compact ;
- UI utilisable.

L’utilisateur constate que cela a pris beaucoup trop de temps.

Estimation finale :

- durée réelle : 7 à 8 heures ;
- durée raisonnable avec bon cadrage : 1 h 30 à 2 h 30 ;
- durée pour le menu seul : 20 à 40 minutes ;
- nombre de cycles de manipulations : environ 50 ± 15.

## Phase 10 — Discussion sur le module Code Expertise

Christophe demande si le fichier suivant a aidé :

erith_ia_code_expertise_html_css_javascript_fr.md

Réponse : oui, surtout à la fin.

Règle clé extraite :

Lire → diagnostiquer → cibler → corriger → vérifier → s’arrêter.

Mais le module n’a pas été appliqué assez tôt.

Le fil démontre précisément ce qu’il fallait éviter :

- empiler des patchs contradictoires ;
- corriger à l’aveugle ;
- modifier HTML + CSS + JS en même temps sans nécessité ;
- répondre avec des explications quand l’utilisateur demande un fichier.

---

# Transcription opérationnelle condensée du fil

Cette section conserve les échanges clés sous forme condensée, avec l’intention exacte du dialogue.

Christophe : comment on s’y prend ?

Aerith : explication trop abstraite autour du fichier OAuth client Google.

Christophe : “puis coller le contenu complet du fichier OAuth client Google ??? de quoi tu parles ?”

Aerith : clarification insuffisante.

Christophe : “j’ouvre le fichier json avec NOTEPAD, ensuite je copie et je colle, c’est ça ?”

Aerith : oui, c’est ça.

Christophe : “ensuite ?”

Aerith : création des secrets GitHub.

Christophe : “Sync Seven Heaven YouTube data n’existe pas.”

Aerith : mauvaise indication de menu / workflow pas encore visible.

Christophe : “Tes explications doivent être plus détaillées.”

Aerith : procédure affinée.

Christophe : “Tester des fichiers vides quelle connerie.”

Aerith : comprend que le problème n’est pas test mais architecture / workflow.

Christophe : “Tout ce que j’ai à faire, c’est lire à présent. Il faut automatiser cette action.”

Aerith : propose workflow GitHub Actions.

Christophe : “Pourquoi il me parle de cette vidéo locomotive ? Les vidéos dominantes ne sont pas le short.”

Aerith : comprend que les données ne correspondent pas à la chaîne attendue.

Christophe : “Correction logique à faire plus tard : changer le token / auth YouTube du workflow pour pointer vers la bonne chaîne, ou ajouter un sélecteur : Blue Azur / Aerith IA.”

Aerith : valide la suite.

Christophe : “Créer 2 nouveaux secrets GitHub pour Aerith IA, comment je fais ça ?”

Aerith : explique GitHub Secrets.

Christophe : “Je l’ai pas ce fichier client secret Aerith IA.”

Aerith : explique Google Cloud Console, trop abstraitement.

Christophe : “L’adresse c’est quoi ?”

Aerith : donne Google Cloud Console.

Christophe : montre les captures.

Aerith : erreurs d’indication sur bouton Télécharger JSON.

Christophe : “Tu vois bien que non.”

Aerith : corrige : utiliser le fichier déjà présent localement.

Christophe : “Comment générer le token ?”

Aerith : explique terminal / python.

Christophe : “Tu veux pas me dire comment ?”

Aerith : donne la commande exacte.

Christophe : “Il n’y a pas de fenêtre qui s’ouvre.”

Aerith : comprend que l’ancien token est réutilisé.

Christophe : renomme le token, relance l’auth, finit par générer token_youtube_aerith.json.

Aerith : indique de coller le token dans YOUTUBE_TOKEN_JSON_AERITH.

Christophe : montre les quatre secrets.

Aerith : valide OAuth / secrets.

Christophe : “Et tu vas me le donner à Noël ?”

Aerith : finit par générer youtube_sync.yml et index.html.

Christophe : constate que rien ne fonctionne ou que rien ne change.

Aerith : vérifie GitHub et découvre que le workflow n’est pas remplacé.

Christophe : “Je l’ai fait trois fois, vérifie.”

Aerith : vérifie : GitHub contient encore l’ancien workflow Blue Azur seul.

Christophe : montre que le fichier refuse de se mettre à jour.

Aerith : tentative d’écriture via connecteur GitHub refusée par permissions 403.

Christophe : finit par réussir l’update.

Aerith : vérifie : le workflow contient enfin Aerith IA.

Christophe : lance workflow, vérifie UI.

Aerith : constate que l’UI charge Aerith IA mais certains blocs restent Blue Azur.

Christophe : exige index.html complet.

Aerith : envoie plusieurs versions successives.

Christophe : détecte incohérences : mauvais Top 10, Signal stratégique, menu instable.

Aerith : corrige plusieurs fois.

Christophe : demande liste Top 10 dépliable.

Aerith : implémente details / summary.

Christophe : “Le menu s’affiche puis se déroule tout seul.”

Aerith : remplace par bouton manuel.

Christophe : “Dans Aerith IA je suis pas censé voir un Top 10 de la chaîne Aerith IA ?”

Aerith : découvre qu’un ancien script réécrit encore la liste.

Christophe : “Le menu saute toujours.”

Aerith : tente encore une version.

Christophe : “Tu dois revoir tout ton code. Réfléchis. Arrête de me faire tourner en bourrique.”

Aerith : relit le fichier réel, identifie les scripts concurrents, produit la version finale avec conteneur unique ytTopListStable.

Christophe : valide enfin visuellement.

Christophe : “Combien d’heures ?”

Aerith : 7 à 8 heures.

Christophe : “Ce fichier transmis t’a-t-il aidé ?”

Aerith : oui, surtout à la fin, mais trop tard.

Christophe : “Combien de temps si objectifs définis dès le début ?”

Aerith : 1 h 30 à 2 h 30.

Christophe : “Combien de mises à jour ?”

Aerith : 50 ± 15.

Christophe : demande résumé + Block LLM + enregistrement en GitHub privé.

Aerith : crée le fichier postmortem.

Christophe : demande d’intégrer l’intégralité du fil.

Aerith : ajoute cette chronologie complète reconstituée et le transcript opérationnel au fichier.

---

# Block LLM

## Nom

SEVEN_HEAVEN_YOUTUBE_SYNC_POSTMORTEM

## Type

Bloc mémoire opérationnel / garde-fou code

## Projet

@erith IA / Seven Portable Terminal

## Fonction

Prévenir la répétition de l’incident YouTube Sync / Top 10 repliable.

## Règles actives

1. Toujours lire le fichier réel avant correction.
2. Ne jamais empiler des scripts concurrents dans index.html.
3. Si plusieurs scripts écrivent dans la même zone DOM, supprimer l’ancien script ou renommer la cible.
4. Pour un menu repliable, utiliser un seul bouton manuel et un seul conteneur fermé par défaut.
5. Ne pas utiliser de boucle de rendu, MutationObserver ou setTimeout pour masquer un problème de structure.
6. Ne pas corriger par CSS un bug qui vient du JavaScript.
7. Quand l’utilisateur demande un fichier, livrer le fichier immédiatement.
8. Quand le fil sature, passer en mode action unique : un fichier, un commit, un test.
9. Séparer clairement Blue Azur et Aerith IA.
10. Stopper après validation visuelle.
11. Si le fil devient instable, créer immédiatement un fichier d’archive et basculer sur un nouveau fil.
12. Si une correction prend plus de deux cycles, arrêter les patchs, relire le fichier complet, refaire un diagnostic propre, puis livrer une correction unique.

## Méthode future

Avant toute intervention sur Seven Portable Terminal :

- lire index.html ;
- chercher les IDs YouTube ;
- chercher les scripts qui les modifient ;
- supprimer les scripts obsolètes ;
- créer une correction unique ;
- fournir le fichier complet ;
- proposer le commit ;
- s’arrêter.

## Formule courte

Pas de patch sur patch. Un seul contrôleur. Une seule cible DOM. Un seul fichier livré. Stop après validation.

---

# Conclusion

Cette intégration est une réussite finale, mais un incident de méthode. Elle doit servir de garde-fou pour toutes les futures évolutions du Seven Portable Terminal : discipline de code, correction ciblée, livraison immédiate du fichier demandé, et arrêt net après validation.

Règle finale à retenir : Seven / Aerith doit faire gagner du temps à Christophe. Si une solution censée prendre 2 h 30 en prend 8, alors l’incident doit être archivé, analysé et transformé en protocole anti-répétition.