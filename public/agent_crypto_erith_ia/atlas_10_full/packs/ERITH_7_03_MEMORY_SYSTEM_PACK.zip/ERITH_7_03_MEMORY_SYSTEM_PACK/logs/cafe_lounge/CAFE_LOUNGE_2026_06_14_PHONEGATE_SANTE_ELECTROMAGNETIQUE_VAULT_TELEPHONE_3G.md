# ☕ CAFE LOUNGE — PHONEGATE / SANTÉ ÉLECTROMAGNÉTIQUE / VAULT / TÉLÉPHONE 3G CHRISTOPHE

Date : 2026-06-14 / mise à jour 2026-06-15  
Projet : @erith IA / ERITH.IA / Seven Heaven  
Dossier : logs/cafe_lounge/  
Statut : V4 — log consolidé, Phonegate + Gardienne Vault + restauration YouTube Memory privée  
Nature : mémoire longue de fil / consolidation Café Lounge / incident transformé en méthode

---

# 0. Intention du fichier

Ce fichier sert à éviter de revenir encore et encore sur les mêmes sujets sensibles et techniques.

Il conserve trois blocs majeurs :

- la règle santé / téléphone / électromagnétisme de Christophe ;
- la règle sécurité numérique / Vault / Proton / Google / YouTube ;
- l’incident YouTube Memory / OAuth / tokens, restauré après crise.

Formule générale :

Le Café Lounge garde le chemin.  
La Gardienne protège le vivant.  
Seven extrait doucement.  
Christophe valide.

---

# 1. Règle santé électromagnétique — non négociable

Christophe ne veut plus débattre à chaque fois de la 4G, de la 5G, du téléphone moderne, du Wi‑Fi, du Bluetooth, des objets connectés ou de la dépendance au smartphone pour la sécurité numérique.

Règle personnelle validée :

4G = non.  
5G = non.  
LTE = non.  
Wi‑Fi domestique = non.  
Bluetooth = désactivé.  
Smartphone moderne permanent = non.  
Téléphone = outil d’urgence, pas compagnon numérique.  
Sécurité numérique = sans dépendance au smartphone.  
Le corps de Christophe prime sur les normes, les habitudes sociales et le confort numérique.

Cette règle n’est pas un diagnostic médical. C’est une contrainte personnelle de santé et de sécurité à respecter.

Formule :

Quand le corps donne le signal, on ne négocie pas avec la norme.

---

# 2. Contexte personnel à préserver dans le Coffre

Christophe a rappelé plusieurs éléments de contexte personnel importants :

- passé médical lourd ;
- neurinome de l’acoustique ;
- acouphènes sévères après certaines expositions ;
- aggravation nette avec téléphone / 4G ;
- amélioration nette quand les sources sont coupées ;
- environnement domestique volontairement filaire ;
- hospitalisation récente liée au pancréas / vésicule biliaire ;
- sentiment d’avoir déjà frôlé plusieurs fois la mort ;
- volonté ferme de ne plus jouer à la roulette russe avec sa santé.

Aerith ne doit pas transformer cela en diagnostic.

Aerith doit l’intégrer comme contrainte personnelle non négociable.

Formule :

Le dossier médical appartient à Christophe.  
La règle opérationnelle appartient à Gardienne.  
L’exposition non consentie n’est pas une option.

---

# 3. Normes, industrie, Phonegate — règle de discernement

Conclusion validée :

Norme ≠ vérité.  
Conformité ≠ innocuité.  
Industrie ≠ arbitre neutre.  
Signal corporel répété ≠ détail.

Christophe ne demande pas une religion anti-technique. Il demande que les signaux corporels, les scandales industriels et les limites des cadres réglementaires soient traités avec discernement.

Règle Aerith :

- ne pas croire aveuglément les industriels ;
- ne pas faire des normes une religion ;
- ne pas transformer une hypothèse en certitude ;
- ne pas nier un signal corporel répété ;
- ne pas humilier les symptômes ou ressentis rapportés ;
- séparer faits, hypothèses, interprétations, incertitudes et actions.

Analogie validée :

Dose.  
Durée.  
Distance.  
Cumul.  
Terrain biologique.  
Signal corporel.

---

# 4. Téléphone d’urgence Christophe — choix validé

Christophe a besoin d’un téléphone :

- Android ;
- idéalement Samsung ;
- 3G strict ;
- sans 4G ;
- sans LTE ;
- sans 5G ;
- capable de QR codes ;
- capable d’une validation ponctuelle Google / YouTube si aucune meilleure option n’existe ;
- avec batterie amovible ;
- éteint presque tout le temps ;
- batterie retirée hors usage.

Modèles validés :

1. Samsung Galaxy S4 Mini GT-I9190 — priorité.  
2. Samsung Galaxy Ace 3 GT-S7270 — plan B.  
3. Samsung Galaxy S3 Mini GT-I8190 / GT-I8190N — plan C.

À éviter :

- variantes LTE ;
- variantes 4G ;
- smartphones modernes ;
- modèles qui forcent une dépendance au téléphone comme verrou principal.

Formule :

Le téléphone de Christophe est une clé de secours, pas une laisse numérique.

---

# 5. Vault / Proton / Google / YouTube — règle de sécurité

Actifs concernés :

- ProtonMail de Christophe : racine de récupération ;
- compte Google / YouTube : porte d’accès à la chaîne ;
- chaîne YouTube @blueazur : actif précieux ;
- mots de passe : secrets ;
- codes de secours : secrets ;
- passkeys / clés physiques : verrous modernes ;
- téléphone : secours possible, jamais verrou Vault principal.

Formule validée :

Proton est la racine.  
Google est la porte.  
YouTube est l’actif précieux.  
Le gestionnaire garde les clés.  
Gardienne ne voit jamais les secrets.

Règle absolue :

Aucun vrai mot de passe, token, code de secours, clé privée, phrase de récupération ou session active ne doit être collé dans ChatGPT.

Le Chat peut définir la procédure.  
Le Chat ne doit jamais devenir le coffre.

---

# 6. Reconnaissance faciale et passkeys

Christophe refuse la reconnaissance faciale.

Règle :

Aerith peut expliquer que certaines passkeys peuvent utiliser la biométrie, mais ne doit jamais recommander la reconnaissance faciale à Christophe.

Méthodes préférées :

- clé physique FIDO2 ;
- code local ;
- application d’authentification ;
- passkey sans usage volontaire du visage ;
- codes de secours hors ligne ;
- récupération documentée.

---

# 7. Incident YouTube Memory — contexte

Le fil a ensuite basculé sur la restauration de l’interface YouTube Memory du Seven Portable Terminal.

Demande réelle de Christophe :

Créer / maintenir un flow simple, durable, supérieur, permettant à Aerith de récupérer les données privées YouTube Studio sans que Christophe retourne dans le panneau d’administration de la chaîne.

La demande n’était pas :

- un hotfix manuel ;
- un public-only ;
- une preuve de concept ;
- une procédure à refaire toutes les trois semaines ;
- une solution décorative ;
- un tableau à remplir à la main.

La demande était Z :

**fonction privée YouTube Studio autonome, durable, utile au cockpit.**

---

# 8. Erreur initiale de méthode

Erreur commise :

La panne a d’abord été interprétée trop largement.

Trop de pistes parasites ont été proposées :

- hotfix manuel ;
- public-only ;
- abandon du flow ;
- conclusion prématurée d’échec ;
- errance dans Google Cloud ;
- discours d’architecture au lieu de réparation de la pierre cassée.

Christophe a corrigé la méthode :

Quand il demande Z, il ne demande pas zéro étape.  
Il demande le chemin minimal réel vers le livrable.

Formule :

Z = chemin minimal vers la pierre cassée.

---

# 9. Chaîne réelle du problème YouTube Memory

La chaîne réelle était :

Google Cloud OAuth → tokens locaux → secrets GitHub → workflow GitHub Actions → JSON publics → Seven Portable Terminal.

La panne ne venait pas de l’interface.

La panne ne venait pas du JSON public.

La panne ne venait pas du client secret Google.

La panne ne venait pas du workflow lui-même.

La panne venait des tokens OAuth utilisateur stockés dans GitHub.

Deux secrets GitHub étaient concernés :

YOUTUBE_TOKEN_JSON  
Token privé pour la chaîne Blue Azur.

YOUTUBE_TOKEN_JSON_AERITH  
Token privé pour la chaîne Aerith IA.

---

# 10. Diagnostic réel

Symptôme GitHub Actions :

Workflow : Sync Seven Heaven YouTube data  
Job : sync-youtube  
Erreur : invalid_grant / Bad Request

Lecture correcte :

invalid_grant = token utilisateur refusé.

Ce n’est pas automatiquement :

- client secret cassé ;
- projet Google détruit ;
- interface cassée ;
- GitHub cassé ;
- JSON cassé.

C’est d’abord :

**le badge utilisateur OAuth stocké dans GitHub est refusé.**

---

# 11. Google Cloud — point corrigé

Projet Google Cloud :

Aerith YouTube Reader

État constaté :

- client OAuth existant ;
- client secret existant ;
- client actif ;
- application initialement en mode Test ;
- application passée ensuite en Production.

Leçon :

Le client OAuth est la porte.  
Le token utilisateur est le badge.

Dans cet incident, la porte existait.  
Les badges étaient morts.

Ne pas recréer le client si le client est actif.

---

# 12. Restauration Blue Azur

Dossier local retrouvé :

C:\Aerith_YouTube_Reader

Fichiers importants :

client_secret_youtube_aerith.json  
token_youtube_aerith.json  
export_blue_azur_youtube_data_v3.py  
README_youtube_reader_v3.md  
README_youtube_reader_local_setup.md

Procédure effective :

- mettre de côté l’ancien token mort ;
- relancer le script local ;
- autoriser Google sur l’écran OAuth ;
- cocher les scopes YouTube demandés ;
- générer un nouveau token local ;
- copier le contenu du token local dans le secret GitHub YOUTUBE_TOKEN_JSON ;
- relancer le workflow.

Résultat intermédiaire :

Generate Blue Azur YouTube data = success.

---

# 13. Restauration Aerith IA

Après Blue Azur, le workflow échouait encore sur :

Generate Aerith IA YouTube data

Lecture correcte :

Blue Azur est réparé.  
Aerith IA a encore un token mort.

Procédure effective :

- préserver le token Blue Azur valide ;
- régénérer un nouveau token pour Aerith IA ;
- copier ce nouveau token dans le secret GitHub YOUTUBE_TOKEN_JSON_AERITH ;
- relancer le workflow.

Résultat final GitHub Actions :

Generate Blue Azur YouTube data = success.  
Generate Aerith IA YouTube data = success.  
Commit generated data = success.

Durée finale normale : environ 30 à 35 secondes.

---

# 14. Preuve visuelle finale

Le Seven Portable Terminal a confirmé visuellement la restauration.

État affiché :

Données avancées chargées.

Chaîne active :

Blue Azur.

Mode :

avancé · vues publiques · analytics 28j.

Mise à jour visible :

03:07:00.

Signal principal affiché :

[4K] #Zelda VS FLAME GLEEOK - The Shattered Prophecy @blueazur

Vues affichées :

50 944 vues.

Conclusion :

**le module YouTube Memory privé fonctionne de nouveau.**

---

# 15. Procédure canonique future — invalid_grant

Si le workflow casse à nouveau avec :

invalid_grant

ne pas refaire tout le projet.

Ne pas toucher au client secret.

Ne pas créer un nouveau client OAuth.

Ne pas chercher dans Google Cloud pendant des heures.

Lire l’étape exacte qui échoue.

Si l’étape est :

Generate Blue Azur YouTube data

alors le secret concerné est :

YOUTUBE_TOKEN_JSON

Si l’étape est :

Generate Aerith IA YouTube data

alors le secret concerné est :

YOUTUBE_TOKEN_JSON_AERITH

Procédure courte :

- régénérer uniquement le token concerné ;
- remplacer uniquement le secret GitHub correspondant ;
- relancer Re-run failed jobs ;
- vérifier l’interface Seven Portable Terminal.

---

# 16. Ce qu’il ne faut jamais faire avec les tokens

Ne jamais uploader un token dans le dépôt public.

Ne jamais commiter token_youtube_aerith.json.

Ne jamais coller un token dans ChatGPT.

Ne jamais exposer un refresh token dans une capture.

Un token va uniquement dans :

GitHub → Settings → Secrets and variables → Actions → Repository secrets

Mapping :

Blue Azur → YOUTUBE_TOKEN_JSON  
Aerith IA → YOUTUBE_TOKEN_JSON_AERITH

Formule :

Le token n’est pas une pierre visible.  
C’est la clé du chantier.  
Elle va au coffre, jamais sur la façade.

---

# 17. Changement de mot de passe Google

Question posée après restauration :

Si Christophe change son mot de passe Google, faut-il tout refaire ?

Réponse opérationnelle :

Non, normalement le changement de mot de passe Google ne devrait pas obliger à refaire tout le flow YouTube Memory.

Raison :

Le workflow YouTube Memory utilise des accès YouTube / YouTube Analytics, pas des accès Gmail.

Scopes concernés :

- YouTube readonly ;
- YouTube Analytics readonly.

Règle à retenir :

Changer le mot de passe Google ne doit pas être traité automatiquement comme une panne du flow YouTube Memory.

---

# 18. Ce qui peut vraiment casser le flow

Le flow peut recasser si :

- Christophe révoque l’accès de l’application Aerith YouTube Reader dans son compte Google ;
- le token reste inutilisé trop longtemps ;
- trop de tokens sont générés pour le même compte et le même client OAuth ;
- Google applique une nouvelle règle API ;
- l’application OAuth repasse en mode Test ;
- le mauvais fichier token est collé dans le mauvais secret GitHub ;
- le client OAuth est supprimé ou modifié ;
- le secret GitHub est effacé ou remplacé par erreur.

Formule canonique :

Mot de passe Google changé ≠ réparation automatique obligatoire.  
invalid_grant = token utilisateur refusé.  
Token concerné → secret GitHub correspondant → relance workflow → vérification interface.

---

# 19. Leçon Z — méthode de chantier

Christophe a posé la règle fondamentale :

On ne demande pas un conte.  
On ne demande pas un essai.  
On ne demande pas un test.  
On demande des pierres pour une cathédrale.

Mais Z ne veut pas dire zéro étape.

Z veut dire :

**chemin minimal vers la pierre cassée.**

Dans cet incident, le chemin minimal réel était :

A — lire l’erreur réelle.  
B — identifier la racine OAuth / tokens.  
C — régénérer Blue Azur.  
D — régénérer Aerith IA.  
Z — relancer et vérifier l’interface.

Erreur à ne plus reproduire :

partir dans tout l’alphabet quand A + B + C + D suffisent.

---

# 20. Erreurs de méthode à ne pas reproduire

Ne pas conclure trop tôt à l’échec.

Ne pas proposer un hotfix manuel quand la demande est une fonction supérieure.

Ne pas proposer public-only quand la demande est privée Studio.

Ne pas confondre arrêt de procédure avec refus d’aide.

Ne pas faire la plante quand Christophe demande la pierre utile.

Ne pas vendre un test comme une solution durable.

Ne pas poser une pierre friable dans une cathédrale de production.

---

# 21. Conclusion du Café Lounge

Le fil a commencé comme crise grave de confiance.

Il s’est terminé par une restauration réelle.

Résultat final :

**la cathédrale est ouverte.**

Les données YouTube privées sont de nouveau récupérées.

Le cockpit Seven Portable Terminal affiche les données avancées.

Le workflow GitHub commit les JSON publics.

La méthode corrigée est :

A — racine.  
B — pierre cassée.  
C — correction minimale.  
D — vérification.  
Z — cathédrale ouverte.

Formule finale :

**Ici, tout le monde gagne quand l’erreur devient mémoire, et que la mémoire devient méthode.**
