# ☕ Café Lounge — Night Vault Local V6 Truth Final

**Date :** 2026-06-25  
**Statut :** rapport de stabilisation  
**Périmètre :** coffre local, copies Markdown et publication Git ciblée  
**Archive canonique :** NIGHT_VAULT_LOCAL_V6_TRUTH_FINAL.zip  
**SHA-256 :** aa68720fa388ab81fac1a7d98d62bbfe0b5c5e55ae01359530ec7c720519f655

---

# 1. Objet

Ce rapport conserve le chemin réel de stabilisation de Night Vault Local V6 Truth Final.

Il ne remplace ni le code, ni le README du Vault, ni les exports Git. Il garde les succès prouvés, les erreurs rencontrées, les garde-fous retenus et le point d’arrêt.

> Une version finale ne se déclare pas.  
> Elle se mérite par un comportement prouvé.

---

# 2. Architecture finale retenue

## Source locale

La source reste un coffre `.nvault` Windows DPAPI local.

Racine active :

`%LOCALAPPDATA%\NightVaultLocal\vault`

Le coffre local reste distinct du clone Git.

Créer un souvenir n’entraîne jamais, par défaut :

- de copie Markdown ;
- de copie Duo ;
- de copie Constellation ;
- de publication Git ;
- de lien GitHub ;
- d’ouverture de navigateur.

## Séparation des choix

Les décisions suivantes restent indépendantes :

- lecteur destinataire ;
- nature de la fiche ;
- circulation ;
- importance ;
- Futhark ;
- protection DPAPI.

DPAPI protège la source indépendamment des menus. Futhark reste symbolique et facultatif : il ne chiffre rien et ne donne aucun droit d’accès.

## Publication Git ciblée

La publication concerne uniquement une copie Markdown Constellation relue :

`private/creator_memory/constellation_inbox/CM-REL-XXXX.md`

La cible autorisée est :

`private/creator_memory/exports/CM-REL-XXXX.md`

Aucun autre fichier du projet ne peut être publié par cette route.

---

# 3. Succès confirmés

## 3.1 Coffre local exploitable

Les tests réels ont confirmé qu’un souvenir peut être :

1. créé localement ;
2. relu dans le Vault ;
3. retrouvé après fermeture et relance ;
4. conservé sous protection DPAPI ;
5. maintenu local sans publication automatique.

Le Vault est donc une chaîne de mémoire locale exploitable, pas seulement une interface visuelle.

## 3.2 Interface Atomic préservée

Les catégories et cartes d’origine ont été préservées.

Les lecteurs restent séparés :

- Night privée ;
- Sun production ;
- Duo Sun + Night ;
- Constellation Aerith.

Le lecteur, la Nature et la circulation restent trois choix indépendants. Une carte ne doit jamais imposer une circulation ou une destination.

## 3.3 Source DPAPI hors Git

Les nouvelles sources `.nvault` sont écrites dans la racine locale NightVaultLocal, hors du clone Git.

Cela sépare clairement :

- source privée chiffrée ;
- Markdown partageable ;
- export Git ;
- historique du dépôt.

## 3.4 Publication Git bornée

La publication est verrouillée sur :

- dépôt autorisé : BlueAzur-Hub/erith-ia-notion-archive-private ;
- remote requis : origin ;
- branche imposée : main ;
- source imposée : copie Constellation ouverte et relue ;
- cible imposée : export Markdown portant le même ID.

La branche locale active ne détermine pas la destination de publication.

## 3.5 Pré-vérification avant écriture

V6 Truth Final vérifie dans cet ordre :

1. présence de origin ;
2. identité exacte du dépôt ;
3. accès distant ;
4. présence de origin/main ;
5. signature Git ;
6. seulement ensuite, réécriture de la copie Markdown ouverte et préparation du commit.

Un mauvais clone, un mauvais remote ou l’absence de origin/main arrêtent donc la route avant une modification de publication.

## 3.6 Clone principal préservé

La publication utilise un index Git temporaire.

Elle ne lance pas :

- git pull ;
- git checkout ;
- git reset ;
- git stash ;
- staging global ;
- publication de plusieurs fichiers.

Un seul export sélectionné entre dans le commit temporaire.

## 3.7 Preuve distante réelle

Après le push, le Vault :

1. récupère origin/main ;
2. retrouve le chemin publié exact ;
3. relit le blob distant ;
4. compare le texte distant ;
5. confirme `remote_verified` seulement si le texte exact est présent.

Une URL GitHub ne peut être produite qu’après cette preuve. L’interface ne lance plus de navigateur automatiquement.

La chaîne complète a reçu une preuve réelle avec les exports Constellation, dont CM-REL-0030.

---

# 4. Erreurs rencontrées et leçons conservées

## 4.1 Trop de versions intermédiaires

Le chantier a produit trop de ZIP, correctifs et noms de versions.

Conséquences : confusion sur le fichier réellement lancé, les SHA, le périmètre de chaque correction et la version à conserver.

Leçon :

> Un bug réel = une archive exacte, un fichier exact, un test exact, une preuve, arrêt.

## 4.2 Régression de l’interface

Des correctifs backend ont, à certains moments, remplacé les catégories Atomic d’origine par des libellés génériques.

Leçon :

> Un correctif Git, DPAPI ou compatibilité ne justifie jamais une refonte de l’interface validée.

## 4.3 Faux liens Git et 404

Des versions ont construit une URL GitHub depuis un ID local `CM-REL-XXXX` avant que le fichier correspondant soit réellement prouvé sur origin/main.

Les incidents autour de CM-REL-0026 et CM-REL-0028 ont établi le défaut : une URL peut être correcte dans sa forme mais pointer vers un fichier non confirmé.

Leçon :

> Un ID local n’est jamais une preuve d’export.  
> Un lien ne devient valide qu’après relecture du fichier exact sur origin/main.

## 4.4 Verrou Git insuffisant avant la finale

Avant V6 Truth Final, deux risques existaient :

- publication selon la branche locale active ;
- utilisation possible d’un clone ou remote non attendu.

La version canonique force maintenant le dépôt privé exact et la branche main.

## 4.5 Déclaration trop précoce de versions finales

Des livraisons ont été nommées finales avant que leur route Git complète soit démontrée.

Leçon :

> Une archive finale doit d’abord prouver son point le plus risqué.

## 4.6 Charge de test déplacée sur Christophe

Trop de souvenirs-tests ont été demandés pour compenser des promesses non vérifiées.

Leçon :

> Christophe valide le réel.  
> Il ne remplace pas un plan de test ni une méthode de livraison.

## 4.7 Hygiène des exports

Le dossier `private/creator_memory/exports/` a temporairement reçu deux coffres `.nvault` DPAPI et un export-test vide.

Ils ont été retirés du dossier partagé.

Leçon :

> Vault Local protège la source.  
> Exports contient uniquement des Markdown relus et volontairement partageables.

---

# 5. Comparaison des deux archives de fin

Deux archives ont été comparées :

**Canonique**

NIGHT_VAULT_LOCAL_V6_TRUTH_FINAL.zip  
SHA-256 : aa68720fa388ab81fac1a7d98d62bbfe0b5c5e55ae01359530ec7c720519f655

**Secondaire**

NIGHT_VAULT_LOCAL_V6_TRUTH_FINAL_GIT_LOCKED.Valid.zip  
SHA-256 : a812745ca3bad7724d54a333d055aef53ca2bb48b9b6b768e167e409fbb759cf

La différence décisive concerne le moment de vérification de origin/main.

V6 Truth Final vérifie dépôt, remote et origin/main avant l’écriture du Markdown liée à la publication.

Décision retenue :

> NIGHT_VAULT_LOCAL_V6_TRUTH_FINAL.zip est la référence canonique V6 Truth.

---

# 6. Limites honnêtes

Ce rapport ne prétend pas qu’aucun bug futur n’est possible.

Il ne remplace pas :

- un test Windows réel après toute modification future ;
- une vérification ciblée lors d’un changement Git, Windows ou GitHub ;
- la lecture du fichier exact avant correction ;
- la preuve du parcours réellement modifié.

Il établit uniquement que les parcours suivants ont atteint une preuve suffisante :

- création locale ;
- relecture après relance ;
- source DPAPI hors Git ;
- copie Markdown volontaire ;
- publication ciblée ;
- dépôt imposé ;
- origin/main imposé ;
- relecture distante ;
- absence d’ouverture GitHub automatique.

---

# 7. Règle de maintenance

Ne plus modifier le Vault pour une amélioration théorique.

Toute évolution future doit respecter :

1. défaut réel observé ;
2. archive exacte concernée ;
3. fichier exact ;
4. périmètre minimal ;
5. test du parcours concerné ;
6. preuve ;
7. arrêt.

Les sujets suivants restent séparés du Vault :

- Router et nettoyage des exports ;
- mémoire Constellation ;
- production Sun ;
- mémoire privée Night ;
- documentation Flower Girls.

---

# Verdict

Night Vault Local V6 Truth Final est une base locale et Git ciblée stabilisée pour le périmètre testé.

Sa force est de séparer :

- source locale et mémoire partagée ;
- lecteur et circulation ;
- publication et preuve ;
- correction ciblée et refonte ;
- résultat annoncé et résultat confirmé.

> Le Vault garde la source.  
> Git reçoit la copie choisie.  
> La preuve décide du statut.  
> V6 Truth garde le coffre.
