# ☕ Café Lounge — Night Vault Local V6 Truth Final

**Date :** 2026-06-25  
**Statut :** rapport de clôture technique et opérationnelle  
**Archive auditée :** NIGHT_VAULT_LOCAL_V6_TRUTH_FINAL(END.Valid).zip  
**SHA-256 :** aa68720fa388ab81fac1a7d98d62bbfe0b5c5e55ae01359530ec7c720519f655

---

## Intention du rapport

Ce document conserve le chemin réel du chantier V6 : ce qui a été réparé, ce qui est prouvé, les erreurs rencontrées, les limites restantes et le statut final utile.

Il ne remplace pas le Core.

Il ne remplace pas les exports Creator Memory.

Il ne donne pas accès aux coffres locaux.

Il fixe seulement le verdict de clôture sur la route Vault Local → copie Markdown choisie → GitHub privé.

---

# 1. Verdict

Night Vault Local V6 Truth Final est une version solide pour son périmètre annoncé :

- source locale chiffrée DPAPI ;
- menus Atomic d’origine conservés ;
- lecteurs et circulation séparés ;
- copies Duo et Constellation manuelles ;
- publication limitée à une copie Constellation relue ;
- publication verrouillée sur le dépôt privé canonique et sur `origin/main` ;
- preuve distante du fichier exact avant succès ;
- aucune ouverture automatique de GitHub après publication.

Le package doit être conservé comme référence de fermeture du chantier V6.

Aucun nouveau correctif Vault ne doit être lancé sans un défaut réel, reproduit, puis limité à un fichier et une route précise.

---

# 2. Preuves techniques vérifiées sur l’archive

## 2.1 Intégrité et syntaxe

- ZIP lisible ;
- Python compilable ;
- JavaScript syntaxiquement valide ;
- interface locale servie sur `127.0.0.1:8780` ;
- aucun `window.open()` dans `web/app.js` ;
- les seuls appels `webbrowser.open()` servent à ouvrir la page locale du Vault au démarrage.

## 2.2 Coffres DPAPI locaux hors clone Git

Les nouveaux coffres sont écrits dans :

`%LOCALAPPDATA%\NightVaultLocal\vault`

Le dossier historique dans le clone Git :

`private/creator_memory/vault`

reste une route de lecture de compatibilité pour les anciens coffres, pas une destination d’écriture courante.

Conséquence : créer ou modifier un coffre V6 n’ajoute pas de `.nvault` au working tree Git.

## 2.3 Compatibilité d’écriture Windows

Le correctif d’écriture utilise un écrivain UTF-8 dédié avec normalisation LF, au lieu de `Path.write_text(..., newline=...)`.

Il couvre les routes utiles :

- copie Duo ;
- copie Constellation ;
- export Markdown local ;
- sauvegarde d’un fichier ouvert ;
- sauvegarde de la copie Constellation juste avant publication Git.

## 2.4 Menus et indépendance des choix

Les catégories Atomic d’origine restent présentes, dont :

- mémoire privée ;
- souvenir personnel ;
- règle Night ;
- règle Sun ;
- note créative privée ;
- référence visuelle locale ;
- archive technique / test fonctionnel ;
- message Sun + Night ;
- guide système / mémoire de Constellation ;
- note intime privée.

Le système distingue :

- la nature éditoriale ;
- les lecteurs locaux : Night, Sun, Duo ou Constellation ;
- la circulation autorisée ;
- le Futhark ;
- l’importance.

DPAPI reste actif pour chaque coffre local et ne devient pas une destination narrative.

## 2.5 Publication Git verrouillée

La publication accepte uniquement :

source relue :

`private/creator_memory/constellation_inbox/CM-REL-XXXX.md`

cible calculée :

`private/creator_memory/exports/CM-REL-XXXX.md`

Le code impose :

- remote `origin` normalisé vers `BlueAzur-Hub/erith-ia-notion-archive-private` ;
- branche forcée sur `main`, indépendamment de la branche locale active ;
- `fetch origin main` avant toute réécriture du Markdown local ouvert ;
- refus si `origin/main` est absent ;
- index Git temporaire, sans `git add .`, pull, reset, checkout, stash ou modification du worktree principal ;
- relecture du fichier distant exact après push ;
- comparaison du texte distant avec le texte publié ;
- URL construite seulement lorsque la preuve distante est positive.

## 2.6 Simulation Git isolée effectuée

Les tests isolés sur cette archive ont confirmé :

- clone local placé sur `feature-proof` → export créé uniquement sur le remote `main` ;
- aucune branche `feature-proof` poussée ;
- mauvais remote → refus avant modification du Markdown local ;
- remote canonique mais `origin/main` absent → refus avant modification du Markdown local ;
- export réussi → réponse `remote_verified = true`, chemin exact, SHA distant et URL canonique sur `main`.

---

# 3. Succès opérationnels observés dans le chantier

Le flux réel a été exercé à plusieurs reprises :

- création de source locale ;
- relecture humaine ;
- validation de destination ;
- copie Duo Sun + Night ;
- copie Constellation ;
- ouverture de la copie Markdown dans Fichiers ;
- publication vers le GitHub privé ;
- relecture des exports présents dans `private/creator_memory/exports/`.

Les exports CM-REL publiés constituent une trace Git indépendante de la mémoire locale : un export existe parce qu’il a été créé et publié, non parce qu’un identifiant local a été inventé.

---

# 4. Erreurs rencontrées et résolution

## 4.1 Écriture incompatible sur certaines versions Python Windows

**Symptôme :** les routes de copie ou de sauvegarde pouvaient échouer avec l’usage de `write_text(..., newline=...)`.

**Résolution :** écrivain UTF-8 compatible centralisé.

**Statut :** corrigé dans le package final.

## 4.2 Coffres `.nvault` écrits dans le clone Git

**Symptôme :** une mémoire locale pouvait contaminer le working tree du dépôt privé.

**Résolution :** source DPAPI courante déplacée vers `%LOCALAPPDATA%\NightVaultLocal\vault` ; ancien chemin conservé uniquement en lecture de compatibilité.

**Statut :** corrigé dans le package final.

## 4.3 Formulaire qui mélangeait lecteurs, circulation, nature et protection technique

**Symptôme :** des choix comme Duo pouvaient imposer une circulation ou une catégorie qui ne correspondaient pas à la demande réelle.

**Résolution :** catégories Atomic conservées ; lecteurs, circulation, Futhark et importance traités comme informations distinctes.

**Statut :** corrigé dans le package final pour les quatre lecteurs V6 : Night, Sun, Duo et Constellation.

## 4.4 Faux lien GitHub et 404

**Symptôme :** l’interface pouvait construire ou ouvrir une URL à partir d’un ID local alors que le Markdown n’existait pas encore sur GitHub.

**Résolution :** aucune navigation GitHub automatique ; le succès dépend de la relecture du fichier exact sur `origin/main`.

**Statut :** corrigé dans le package final.

## 4.5 Publication possible sur une branche active incorrecte ou un mauvais remote

**Symptôme :** une validation mécanique sur un clone ou une branche non canonique n’aurait pas démontré le contrat réel.

**Résolution :** `origin` verrouillé sur le dépôt privé canonique ; branche forcée sur `main` ; preuve distante obligatoire avant statut publié.

**Statut :** corrigé dans le package final.

---

# 5. Réserves documentaires non bloquantes

Deux documents inclus dans l’archive sont historiques et ne décrivent pas parfaitement le contenu final :

- `VERIFICATION_V6_0_FUNCTIONAL.txt` affirme qu’aucun `.vbs` n’est emballé, alors que le ZIP contient bien `01_LANCER_NIGHT_VAULT_V6_1_2.vbs` ;
- `CHANGELOG_V6_TRUTH.md` décrit une canonisation sans changement Git, alors que le package final contient effectivement le verrou Git canonique.

Ces écarts sont documentaires. Ils ne modifient pas le comportement du code audité.

Le maintien de `APP_NAME = Night Vault Local V6.1.2 Atomic Selected Publish` est intentionnel : il préserve la compatibilité DPAPI avec les coffres existants, alors que l’interface affiche V6 Truth.

---

# 6. Limites à ne pas confondre avec des défauts

- La protection DPAPI dépend de Windows et du compte utilisateur de Christophe ; elle ne peut pas être entièrement reproduite dans un audit Linux isolé.
- L’archive ne remplace pas la configuration Git locale : identité Git et accès au dépôt privé restent nécessaires pour publier.
- Le Vault V6 gère explicitement Night, Sun, Duo et Constellation. Il n’est pas un gestionnaire générique de droits pour chaque Flower Girl individuelle.
- Les mémoires privées Night ne doivent pas être envoyées automatiquement vers GitHub ; la publication reste une décision explicite.

---

# 7. Règle de conservation

À partir de cette clôture :

1. garder l’archive V6 Truth Final et son SHA-256 ;
2. ne pas renommer une build comme finale sans preuve du comportement précis ;
3. ne pas créer de variantes pour une hypothèse ;
4. un défaut réel → un fichier exact → un correctif minimal → un test de la route touchée → arrêt ;
5. les futurs rapports de chantier vont dans `logs/cafe_lounge/`, pas dans le Core sans extraction courte et décision explicite.

---

# ✅ Conclusion

V6 Truth Final ferme le chantier essentiel :

**coffre local DPAPI → relecture humaine → copie choisie → publication canonique sur GitHub privé → preuve distante exacte.**

La finalité n’est pas déclarée par le nom du ZIP.

Elle est établie par la route réellement prouvée.
