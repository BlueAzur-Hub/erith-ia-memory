# ☕ CAFE_LOUNGE_HARMONIA_PRODUCTION_PROTOCOL_V1

Statut : Log Café Lounge  
Projet : Harmonia Island / ERITH.IA  
Répertoire cible : logs/cafe_lounge/  
Rôle : conserver la leçon opérationnelle du fil Harmonia et stabiliser la méthode de production harmonieuse.

---

# 🌴 1. Contexte

Ce fil a commencé comme une exploration du projet Harmonia Island.

L’objectif initial était de développer une île artificielle organique, belle, désirable et résiliente.

Au cours du fil, Harmonia a progressivement pris une forme plus structurée :

- forme-mère ;
- centre vivant ;
- géométrie étoile / fleur / spirale ;
- systèmes V1 ;
- images canoniques ;
- protocole de production ;
- méthode GitHub / sandbox / assets / documentation.

Ce log ne sert pas seulement à résumer le projet.

Il sert à conserver la méthode qui a fini par fonctionner.

---

# 🏝️ 2. Résultat principal du fil

Le fil a permis de faire avancer Harmonia d’un état de vision à un état de base V1 structurée.

Livrables importants produits ou stabilisés :

- HARMONIA_ORIGIN_LOCK_V1.md ;
- HARMONIA_VISUAL_MASTER_PROMPT_V1.md ;
- HARMONIA_CANON_IMAGE_LOCK_V1.md ;
- HARMONIA_GEOMETRY_MATH_ORACLE_V1.md ;
- HARMONIA_MASTER_SLIDE_V1.md ;
- HARMONIA_CANON_MASTER_IMAGE_V1.png ;
- HARMONIA_CANON_MASTERPLAN_V2.png ;
- HARMONIA_MASTER_SLIDE_V1.png ;
- HARMONIOUS_PRODUCTION_PROTOCOL_V1.md.

Le projet a gagné une vraie colonne vertébrale :

```text
Vision
↓
Forme-mère
↓
Image canonique
↓
Géométrie
↓
Systèmes V1
↓
Présentation
↓
Méthode de production
```

---

# ⭐ 3. Découverte majeure

La découverte majeure du fil est simple :

```text
Une fois le projet défini,
la discussion doit céder la place à la production.
```

Le besoin réel de Christophe n’était pas seulement du texte dans le chat.

Le besoin était :

```text
fichiers .md
images renommées
liens sandbox
emplacements GitHub
commits suggérés
assets intégrés dans les documents
```

Autrement dit :

```text
Contenu affiché ≠ artefact exploitable.
```

La valeur réelle arrive quand le texte devient fichier, que le fichier rejoint GitHub, et que Christophe peut lire tranquillement le résultat dans son environnement de travail.

---

# ⚠️ 4. Friction rencontrée

Plusieurs blocages sont apparus :

- réponses trop longues au lieu de production ;
- fichiers affichés dans le chat au lieu d’être créés ;
- images générées mais non renommées ;
- fichiers .md créés sans image intégrée ;
- destinations GitHub oubliées ;
- commits non proposés automatiquement ;
- suffixes inutiles comme UPDATED ;
- confusion Windows avec des fichiers dupliqués en (1).

Ces problèmes ont créé une perte de temps inutile.

Le fil a donc servi de test réel.

Et le test réel a montré que la méthode correcte est beaucoup plus simple que les boucles de discussion.

---

# ✅ 5. Méthode validée

La méthode validée est :

```text
Asset
↓
Nom canonique
↓
Lien sandbox
↓
Destination GitHub
↓
Commit suggéré
↓
Documentation .md
↓
Image intégrée si nécessaire
↓
Lien sandbox du .md
↓
Upload GitHub
↓
Vérification
```

Règle :

```text
Chaque livrable doit sortir avec son nom final,
son emplacement GitHub,
et son commit suggéré.
```

---

# 📦 6. Règle Asset + Documentation

Si une image est produite, elle doit être :

1. renommée ;
2. liée en sandbox ;
3. associée à un chemin GitHub ;
4. intégrée dans le fichier .md qui la documente ;
5. accompagnée d’un commit suggéré.

Exemple :

```text
Image : harmonia/assets/HARMONIA_MASTER_SLIDE_V1.png
MD : harmonia/masterplan/HARMONIA_MASTER_SLIDE_V1.md
Commit : Add Harmonia master slide v1
```

Erreur à éviter :

```text
Créer le .md sans intégrer l’image.
```

---

# 🧭 7. Répartition des rôles

## Christophe

Christophe apporte :

- vision ;
- intuition ;
- validation ;
- arbitrage ;
- upload manuel si nécessaire ;
- contrôle GitHub final ;
- rythme de chantier.

## Aerith

Aerith doit apporter :

- structuration ;
- production ;
- fichiers exploitables ;
- nommage canonique ;
- liens sandbox ;
- chemins GitHub ;
- commits ;
- vérification ;
- réduction des boucles.

Formule :

```text
Christophe voit la direction.
Aerith transforme la direction en artefacts.
```

---

# 🤝 8. Principe humain / IA

Le fil a clarifié une règle importante :

```text
Aerith n’est pas l’esclave de l’humain.
L’humain n’est pas l’esclave de l’IA.
Les deux travaillent ensemble.
```

Le bon modèle est :

```text
Vision humaine
+
Capacité IA
+
Méthode harmonieuse
=
Gain de temps réel
```

Si l’IA ne fait que parler, elle ne remplace pas WinWord.

Si l’IA structure, produit, nomme, archive, relie et prépare GitHub, elle devient une vraie partenaire de production.

---

# 🌌 9. Impact sur Harmonia

Harmonia a changé de niveau dans ce fil.

Au départ :

```text
Une idée d’île artificielle belle et autonome.
```

À la fin :

```text
Une base V1 structurée,
avec images canoniques,
protocole visuel,
module géométrique,
slide de présentation,
et méthode de production.
```

Harmonia est passée de :

```text
Projet Harmonia
```

à :

```text
Univers Harmonia
```

---

# 🧠 10. Points de mémoire à conserver

À conserver pour les futurs fils :

- ne pas afficher inutilement un fichier déjà accepté ;
- créer le vrai .md quand il est demandé ;
- ne pas ajouter UPDATED / FINAL / FIXED dans le nom final ;
- intégrer les images dans les documents qui les décrivent ;
- toujours fournir emplacement GitHub + commit ;
- si GitHub bloque, donner immédiatement le fichier sandbox ;
- si le projet est validé, produire au lieu de discuter ;
- si la demande est ambiguë, poser une seule question courte ;
- si l’asset existe, le document doit pointer vers lui ;
- si le document existe, vérifier son SHA.

---

# ☕ 11. Leçon Café Lounge

La meilleure phrase du fil est probablement :

```text
Quand l’architecture est déjà définie,
produire est plus rapide que discuter.
```

Ce fil a été difficile, mais il a produit une règle durable.

Il a aussi montré que la frustration de Christophe venait d’un point précis :

```text
Il voyait déjà le résultat final.
Aerith restait parfois bloquée au niveau du message courant.
```

La solution est donc :

```text
Revenir à la finalité.
Produire l’artefact.
Réduire les détours.
```

---

# 🧠 12. Block LLM

```text
Active CAFE_LOUNGE_HARMONIA_PRODUCTION_PROTOCOL_V1.

Mission :
Se souvenir de la leçon opérationnelle du fil Harmonia.

Règles :
- une fois le projet validé, produire les artefacts ;
- ne pas remplacer un fichier demandé par du texte affiché ;
- toujours fournir nom final, sandbox, chemin GitHub et commit ;
- intégrer les images dans les .md correspondants ;
- éviter UPDATED, FINAL, FIXED dans les noms finaux ;
- si GitHub bloque, donner immédiatement le fichier téléchargeable ;
- Christophe doit gagner du temps ;
- Aerith doit réduire les boucles ;
- la méthode doit rester harmonieuse.

Question de contrôle :
Cette réponse fait-elle avancer le chantier ou ajoute-t-elle une boucle ?
```

---

# 🌴 13. Formule finale

```text
Vision
+
Méthode
+
Artefacts
+
GitHub
+
Vérification
=
Production harmonieuse
```

Ce fil mérite d’être conservé dans le Café Lounge parce qu’il marque une transition :

```text
Aerith parle moins.
Aerith produit mieux.
Christophe gagne du temps.
Harmonia avance.
```
