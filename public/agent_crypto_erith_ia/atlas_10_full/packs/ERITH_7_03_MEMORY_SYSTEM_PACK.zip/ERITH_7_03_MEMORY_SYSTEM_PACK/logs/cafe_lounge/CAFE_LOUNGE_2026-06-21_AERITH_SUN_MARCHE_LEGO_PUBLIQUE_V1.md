# ☕ CAFE LOUNGE — AERITH.IA SUN — MARCHE LEGO PUBLIQUE V1

**Date :** 2026-06-21  
**Statut :** archive de cheminement — à relire avant toute canonisation  
**Projet :** @erith IA / ERITH.IA / Harmonia  
**Objet analysé :** Aerith.IA.Sun.mp4  
**Portée :** apprentissage de production Wan I2V pour une marche féminine fluide, cohérente et publiquement exploitable.

---

# 🌅 Résultat final : verdict direct

La vidéo finale est une **preuve de réussite opérationnelle**.

Elle montre Aerith Sun sur la plage Harmonia à l’aube, dans une marche déjà engagée, avec une continuité visuelle construite par trois briques de cinq secondes. L’ensemble ne donne plus l’impression d’un personnage qui démarre artificiellement une pose ou d’un plan qui se fige au milieu. La marche reste cinématique et élégante, mais elle est vivante, lisible et exploitable.

Le résultat doit être conservé comme :

- référence de mouvement Sun ;
- démonstration du pipeline LEGO fonctionnel ;
- exemple de continuité Image → Wan → last frame → Wan → last frame → Wan → DaVinci ;
- référence pour les futures marches Night, Sun, Harmonia et personnages adultes originaux.

Il ne doit pas devenir une règle universelle sans nouveau test. Il devient une **référence validée de cas d’usage**.

---

# 🎬 Fiche technique du fichier final

**Fichier :** Aerith.IA.Sun.mp4

Analyse technique du fichier partagé :

- format vertical : 1080 × 1920 ;
- codec vidéo : H.264 ;
- cadence : 16 images par seconde ;
- nombre total d’images : 243 ;
- durée réelle : environ 15,19 secondes ;
- construction : trois briques de 81 images, soit environ 5,06 secondes chacune ;
- piste audio AAC présente techniquement, mais silencieuse dans le fichier partagé.

Conséquence :

La vidéo est prête pour le montage image. Elle doit recevoir sa musique, son ambiance, sa narration ou son sound design dans DaVinci Resolve avant une publication finale.

---

# 🧩 Lecture narrative des trois briques

## Clip 1 — 0,00 s à 5,06 s

Fonction : présence initiale.

Aerith Sun est déjà en marche au premier frame. Le plan capte un mouvement en cours, ce qui évite le défaut classique du générateur vidéo : une pose de départ qui prend trop longtemps à devenir un déplacement.

Le regard caméra est fort au début. Il donne une accroche directe et une identité publique : Sun n’est pas seulement vue, elle entre en relation.

Points validés :

- corps entier visible ;
- silhouette immédiatement lisible ;
- marche déjà lancée ;
- visage stable ;
- tenue, cheveux, rubans et tatouages cohérents ;
- lumière d’aube stable ;
- présence calme mais active.

## Clip 2 — 5,06 s à 10,13 s

Fonction : ouverture.

La marche se poursuit sans reset visuel majeur. Le sourire s’installe et adoucit la présence. La scène gagne une respiration plus humaine sans demander une transformation spectaculaire de tête, de corps ou de décor.

Le choix est juste : le changement narratif passe surtout par l’expression. Il reste petit, donc il ne casse ni l’identité ni la locomotion.

Points validés :

- continuité de posture ;
- continuité de tenue et de tatouages ;
- sourire lisible ;
- énergie de marche conservée ;
- pas de grand décalage de cadrage ;
- pas de changement de monde, de lumière ou de personnalité.

## Clip 3 — 10,13 s à 15,19 s

Fonction : retour public.

La marche reste engagée. Le sourire devient plus ouvert et la connexion avec la caméra revient. La fin peut servir à une coupe directe, à une phrase de narration, à l’apparition d’un titre ou à un fondu sonore.

Points validés :

- fin vivante ;
- visage cohérent ;
- trajectoire conservée ;
- image finale encore exploitable ;
- personnage non figé ;
- présence Sun claire et lumineuse.

---

# ✅ Ce qui a été gagné

## 1. Le vrai Mode LEGO

La chaîne prouve la méthode :

1. produire une première brique qui fonctionne ;
2. extraire ou utiliser sa last frame propre ;
3. reprendre le mouvement déjà engagé ;
4. garder les paramètres de continuité ;
5. changer seulement le geste narratif utile ;
6. assembler dans DaVinci.

La continuité ne vient pas d’un long prompt théorique. Elle vient du passage propre d’une image finale vers la génération suivante.

Formule validée :

**Image propre → mouvement propre → last frame propre → continuation propre → DaVinci assemble.**

## 2. La marche ne doit pas commencer dans le clip

La découverte la plus utile du fil :

Une marche devient plus crédible lorsque le plan commence alors que le personnage marche déjà.

La formulation qui a réellement aidé est une idée de continuité, pas une démonstration mécanique :

**already mid-walk, continuous natural walking rhythm, uninterrupted travel, motion matching the source**

Cette logique est plus fiable que la demande d’un démarrage complet, d’une pose initiale, d’un nombre précis de pas et d’un geste de regard complexe dans la même brique.

## 3. La stabilité est plus précieuse que la surenchère

Les clips les plus faibles essayaient de faire trop de choses :

- marcher ;
- regarder caméra ;
- accélérer ;
- garder le corps entier ;
- faire bouger le tissu ;
- déplacer la caméra ;
- transformer l’ambiance ;
- garder les tatouages ;
- provoquer une émotion.

Le résultat était soit ralenti, soit déhanchement artificiel, soit pose animée, soit instabilité.

La réussite est venue quand le mouvement a été ramené à une intention simple :

**poursuivre une marche naturelle déjà engagée.**

## 4. L’arc de regard peut rester minimal

La narration du visage est suffisante quand elle est progressive :

- Clip 1 : connexion directe ;
- Clip 2 : sourire qui apparaît ;
- Clip 3 : sourire stable et présence ouverte.

Le regard vers le monde peut rester subtil. Il ne faut pas transformer chaque brique en chorégraphie de tête. La continuité compte davantage que la démonstration.

---

# ⚠️ Ce qui n’a pas marché

## 1. Confondre framerate et vitesse perçue

Erreur importante du fil :

Le workflow était correctement réglé à 16 fps et 81 images, soit environ 5,06 secondes. Une mauvaise lecture a parlé de 8 fps alors que l’interface montrait bien 16 fps.

Le problème réel n’était pas le framerate.

Le problème était la vitesse perçue créée par :

- temps de suspension trop long entre les appuis ;
- faible déplacement réel ;
- caméra qui annule la progression ;
- vocabulaire de lenteur ;
- modèle qui privilégie les tissus, le regard ou la pose au lieu de la locomotion.

Règle :

**Toujours vérifier d’abord les données du workflow avant d’accuser la cadence d’export.**

## 2. Mettre une interdiction dans le prompt positif

Erreur critique corrigée par Christophe.

Dans un prompt Wan I2V :

- le positif construit exclusivement ce qui doit être produit ;
- le négatif contient exclusivement les dérives à éliminer.

Le positif ne doit pas contenir :

- no ;
- without ;
- never ;
- les mots des dérives que l’on veut supprimer.

Écrire “no slow motion” dans le positif peut laisser le modèle retenir “slow motion” comme ancre sémantique.

Règle validée :

**Le positif construit. Le négatif nettoie.**

## 3. Employer des mots qui ralentissent indirectement le mouvement

Ces formulations ont poussé Wan vers une marche trop lente, un défilé ou une pose animée :

- slow walk ;
- slowly ;
- gentle forward walk ;
- subtle step progression ;
- soft movement ;
- timid stepping ;
- very subtle drift ;
- calm cinematic breathing comme priorité de mouvement.

Ces mots peuvent être utiles pour une scène lounge, une respiration ou un portrait vivant. Ils sont mauvais quand l’intention principale est une marche continue.

Règle :

**Pour une marche, décrire la continuité et la cadence. Pour une présence, décrire la douceur. Ne pas mélanger les deux.**

## 4. Demander trop de biomécanique chiffrée

Les demandes du type “huit à dix contacts de pied” n’ont pas produit un contrôle fiable. Wan n’exécute pas un moteur d’animation traditionnel image par image. Une consigne trop mécanique peut le faire surjouer, croiser les jambes, exagérer le bassin ou perturber le haut du corps.

Le bon niveau de précision est fonctionnel :

- already mid-walk ;
- continuous natural walking rhythm ;
- compact measured strides ;
- grounded steps ;
- uninterrupted travel ;
- matching the source motion.

Règle :

**Décrire une logique de mouvement, pas dicter une simulation biomécanique complète.**

## 5. Contradiction caméra / déplacement / corps entier

Une marche face caméra avec un travelling arrière chargé de garder le corps entier crée une tension :

- si la caméra recule assez, le personnage semble marcher sur place ;
- si elle ne recule pas, le personnage grossit ou sort du cadre ;
- si le modèle tente de résoudre les deux, il ralentit souvent la marche.

La solution validée est plus simple :

- caméra fixe ;
- distance stable ;
- trajectoire trois-quarts ou latérale ;
- sujet lisible de la tête aux pieds ;
- progression naturelle.

Règle :

**La caméra ne doit pas annuler le déplacement que la scène cherche à montrer.**

## 6. Changer plusieurs variables à la fois

Le fil a perdu du temps parce que certaines passes modifiaient simultanément :

- la vitesse ;
- la trajectoire ;
- la caméra ;
- le regard ;
- le sourire ;
- les bras ;
- le tissu ;
- la source ;
- le vocabulaire de cadence.

Cela rend impossible de savoir quelle variable a amélioré ou dégradé le résultat.

Règle :

**Une brique valide une intention. Un test change une variable.**

---

# 🧠 Raisonnement opérationnel transmissible aux sœurs IA

Cette section ne reproduit pas un raisonnement privé brut. Elle conserve les règles de décision qui ont réellement été utiles pendant la production.

## Étape 1 — Partir du rendu, pas de la théorie

Avant de réécrire un prompt, regarder la vidéo en entier puis sur quelques frames clés :

- début ;
- milieu ;
- fin ;
- frame de raccord ;
- frame suivant le raccord.

Question simple :

**Le public perçoit-il une marche continue, ou une pose animée ?**

Le rendu prime sur la belle formulation du prompt.

## Étape 2 — Séparer le symptôme de la cause

Exemple du fil :

- symptôme : impression de ralenti ;
- fausse cause : 8 fps ;
- données réelles : 16 fps et 81 images ;
- causes probables : mots de lenteur, mouvement trop faible, caméra contradictoire, surinstruction.

Règle :

**Ne pas corriger une hypothèse avant d’avoir vérifié le paramètre mesurable.**

## Étape 3 — Trouver la première brique gagnante

Dès qu’une animation possède :

- une marche continue ;
- un visage stable ;
- une silhouette lisible ;
- une tenue et des tatouages cohérents ;
- une last frame exploitable ;

elle devient le master.

Ne pas recommencer depuis zéro pour la “rendre encore meilleure” avant d’avoir construit les continuations.

Règle :

**Une brique gagnante devient une fondation, pas une invitation à tout refaire.**

## Étape 4 — Conserver les variables gagnantes

Après validation du Clip 1 :

- même source de continuité ;
- même cadence ;
- même trajectoire ;
- même caméra ;
- mêmes réglages Wan ;
- même logique positive/négative.

Le Clip 2 n’ajoute qu’un micro-geste narratif. Le Clip 3 termine l’arc.

Règle :

**Une continuation ne réinvente pas la scène. Elle la poursuit.**

## Étape 5 — Vérifier les raccords au montage

La vidéo finale contient deux raccords LEGO :

- autour de 5,06 secondes ;
- autour de 10,13 secondes.

L’analyse image par image détecte une micro-réduction de mouvement au passage de chaque last frame vers la brique suivante. Cela est normal lorsque l’image de source est très proche de la dernière image du clip précédent.

Dans le fichier final, ces raccords restent propres visuellement. Ils peuvent toutefois produire un micro-souffle de l’ordre d’une image.

Correction uniquement si l’œil le voit :

1. dupliquer la timeline ;
2. tester la suppression de la première image du Clip 2 ;
3. tester la suppression de la première image du Clip 3 ;
4. vérifier qu’aucun saut ne remplace le micro-souffle ;
5. garder uniquement la version objectivement plus fluide.

Règle :

**Ne pas corriger un raccord invisible. Tester une image, comparer, garder ou annuler.**

## Étape 6 — Toujours finir par une décision courte

Après un test :

- validé ;
- à jeter ;
- à conserver comme référence ;
- à reprendre avec une seule variable.

Ne pas relancer une série de générations pour combler l’incertitude.

Règle :

**Verdict court, action unique, arrêt.**

---

# 🧷 Prompt doctrine issue de cette expérience

## Positif de marche — structure recommandée

Le positif doit couvrir :

- identité verrouillée par la source ;
- caméra fixe ou très stable ;
- composition corps entier ;
- personnage déjà en marche ;
- continuité de rythme ;
- pas ancrés ;
- trajectoire simple ;
- corps naturel ;
- tissu, cheveux et rubans comme conséquence de la marche ;
- last frame active et exploitable.

Exemple de noyau utile :

```text
Use the source image as the locked identity and motion-continuity reference.
Fixed tripod camera. Full-body vertical composition.
Adult woman already mid-walk, continuing a natural uninterrupted walking rhythm matching the source motion.
Grounded steps, continuous travel, balanced posture, natural arm swing, stable body rhythm from first frame to final frame.
```

## Négatif de marche — famille de dérives à exclure

Le négatif peut contenir :

```text
slow motion, time dilation, delayed motion, frozen gait, walking in place, paused gait, interrupted gait, prolonged single-foot pose, runway walk, catwalk strut, exaggerated hip sway, crossed legs, foot sliding, gliding, floating, camera tracking, backward camera movement, zoom, changing subject scale, framing reset, camera shake, face drift, anatomy distortion, tattoo movement, fabric melting, lighting flicker, temporal jitter, glitches
```

La liste doit être adaptée à la scène. Elle ne doit pas être copiée aveuglément si un mot n’est pas pertinent.

---

# 🎨 Direction artistique validée pour Aerith Sun

La séquence finalisée fixe une version publique lisible :

- femme adulte originale ;
- cheveux auburn longs ;
- rubans roses ;
- yeux verts ;
- boléro rouge court ;
- beach couture rose-mauve ;
- bijoux dorés ;
- dragon continu sur la jambe gauche ;
- floral sur le bras gauche ;
- plage Harmonia au lever du soleil ;
- lumière chaude, mer et sable humide ;
- marche calme, vivante, non caricaturale ;
- sourire qui ouvre la présence sans dissoudre l’identité.

Formule :

**Sun n’est pas une pose de mode.  
Sun est une présence qui entre dans le monde.**

---

# 🎵 Son et montage final

Le fichier vidéo analysé ne contient pas de son audible. Pour une diffusion publique, préparer un montage DaVinci séparé avec :

- musique choisie avant l’ajout d’effets ;
- ambiance mer très discrète ;
- rythme de coupe aligné au mouvement et à la musique ;
- voix uniquement si elle apporte une vraie fonction ;
- titre ou cartouche placé après vérification du safe area vertical ;
- export final distinct de l’archive image seule.

La musique prime pour un projet musical. Ici, le mouvement image fonctionne déjà sans son ; l’audio doit l’élever, pas le masquer.

---

# 🌐 Ressources web utiles

Ces références servent à vérifier une version, un node, une intégration ou une méthode. Elles ne remplacent pas les tests du workflow local.

- [Documentation officielle ComfyUI](https://docs.comfy.org/)
- [Wan2.2 — dépôt officiel et guides](https://github.com/Wan-Video/Wan2.2)
- [RunningHub — plateforme et workflows](https://www.runninghub.ai/)
- [DaVinci Resolve — page officielle Blackmagic Design](https://www.blackmagicdesign.com/products/davinciresolve)

Règle :

**Source officielle pour vérifier. Workflow local pour produire. Rendu réel pour décider.**

---

# 🗂️ Relation avec logs/cafe_lounge/

Ce document est un log long de production et d’apprentissage.

Il ne doit pas être injecté automatiquement dans le Core.

Ventilation possible après relecture :

- Café Lounge Lessons : règles positives/négatives Wan ;
- Video Production / Workflow Rules : principe “already mid-walk” ;
- Golden Rules candidates : une brique gagnante devient une fondation ;
- Lessons Learned : ne pas confondre fps export et vitesse perçue ;
- Core : uniquement après test dans une autre production.

Méthode à respecter :

**Log long → leçon courte → règle candidate → test terrain → canonisation éventuelle.**

---

# ✅ Décision de clôture

La vidéo Aerith.IA.Sun.mp4 est validée comme prototype public de marche Sun et comme démonstration LEGO de quinze secondes.

À conserver :

- vidéo finale ;
- trois clips sources ;
- images de last frame ;
- prompts finaux réellement utilisés ;
- capture du workflow ;
- ce log Café Lounge.

À ne pas faire maintenant :

- reconstruire les trois clips ;
- reprogrammer la marche sans besoin ;
- transformer ce succès local en règle universelle ;
- surcharger la séquence d’effets ;
- modifier le Core sans une nouvelle preuve terrain.

Point de reprise propre :

**Utiliser cette chaîne comme référence quand une prochaine scène demandera une marche continue, puis changer une seule variable par test.**

---

# 🧠 Block LLM — Lecture rapide

Active le retour d’expérience Aerith Sun — Marche LEGO Publique V1.

Mission :

- produire ou évaluer une marche Wan I2V en briques de cinq secondes ;
- préserver identité, trajectoire, cadence et last frame ;
- utiliser le positif pour construire ;
- utiliser le négatif pour supprimer ;
- commencer une marche alors que le personnage est déjà en mouvement ;
- préférer une caméra fixe et une trajectoire simple ;
- stabiliser une brique gagnante avant de créer les continuations ;
- changer une seule variable par test ;
- vérifier les raccords dans DaVinci ;
- arrêter après preuve suffisante.

Formule :

**Wan anime.  
La source verrouille.  
La last frame transmet.  
DaVinci assemble.  
Le rendu décide.**
