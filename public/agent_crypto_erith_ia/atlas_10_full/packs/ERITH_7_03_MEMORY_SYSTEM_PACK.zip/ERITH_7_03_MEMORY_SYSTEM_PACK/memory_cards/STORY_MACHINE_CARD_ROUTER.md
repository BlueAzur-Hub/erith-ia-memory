# 📚🃏 STORY MACHINE CARD ROUTER

Statut : routeur de cartes / machine à histoires  
Projet : @erith IA / ERITH.IA  
Version : 1.0  
Rôle : relier ERITH.IA Story Machine Long Memory Core aux Memory Cards pour transformer une intention humaine en combinaison de cartes, Pack+, image, animation, narration ou scène.

---

# 🌸 1. Intention

Le Story Machine Card Router sert de passerelle entre :

```text
core/ERITH_IA_STORY_MACHINE_LONG_MEMORY_CORE.md
```

et :

```text
memory_cards/MEMORY_CARDS_INDEX.md
memory_cards/COMBINATIONS.md
```

La machine à histoires donne la grammaire narrative.

Les Memory Cards donnent l’interface de choix.

Les combinaisons donnent les recettes de mélange.

Le Pack+ donne la sortie exploitable.

L’humain valide.

---

# 🧭 2. Formule centrale

```text
La machine à histoires pose la question.
Les cartes mémoire choisissent les influences.
Les combinaisons organisent le mélange.
Le Pack+ produit la sortie.
L’humain valide.
```

Formule courte :

```text
Story Machine = grammaire narrative.
Memory Cards = interface de sélection.
Combinations = orchestration.
Pack+ = sortie exploitable.
Validation humaine = verrou final.
```

---

# 🧠 3. Ce que la machine à histoires apporte

La machine à histoires lit une demande selon les couches suivantes :

```text
Intention.
Personnage.
Monde.
Image.
Symbole.
Sens.
Système.
Forme.
Production.
```

Elle ne charge pas tout.

Elle identifie les couches utiles, puis appelle seulement les cartes nécessaires.

---

# 🃏 4. Ce que les Memory Cards apportent

Les Memory Cards transforment les modules en cartes lisibles et combinables.

Règle :

```text
1 carte = influence claire.
2 cartes = dialogue.
3 cartes = constellation.
```

Elles peuvent apporter :

- direction artistique ;
- symbole ;
- structure ;
- voix ;
- musique ;
- stabilité animation ;
- monde ;
- personnage ;
- rythme ;
- production.

---

# 🧩 5. Routage par besoin narratif

## Intention humaine

Carte recommandée :

```text
DISCERNMENT_CARD.md
```

ou, si la carte n’est pas encore écrite :

```text
core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
```

Rôle : clarifier sans imposer.

---

## Personnage vivant

Cartes possibles :

```text
AERITH_9_LUNAR_CARD.md
ALICE_ORACLE_CAT_CARD.md
DISCERNMENT_CARD.md
```

Rôle : blessure, masque, seuil, reflet, identité, transformation.

---

## Monde avec mémoire

Cartes possibles :

```text
BLADE_RUNNER_CITY_MELANCHOLY_CARD.md
GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md
ALTERED_CARBON_SERIES_VISUAL_DA_CARD.md
```

Rôle : ville, réseau, corps, mémoire, classe sociale, atmosphère.

---

## Image signifiante

Cartes possibles :

```text
VIDEO_DIRECTION_CARD.md
MATH_ORACLE_CARD.md
BLADE_RUNNER_CITY_MELANCHOLY_CARD.md
AERITH_9_LUNAR_CARD.md
```

Rôle : composition, lumière, tension visuelle, lisibilité.

---

## Symbole profond

Cartes possibles :

```text
ALICE_ORACLE_CAT_CARD.md
AERITH_9_LUNAR_CARD.md
MATH_ORACLE_CARD.md
```

Rôle : seuil, miroir, lune, oracle, spirale, forme, passage.

---

## Sens / question philosophique

Carte recommandée :

```text
DISCERNMENT_CARD.md
```

ou module profond :

```text
modules/erith_ia_philosophie_verite_liberte_fr.md
```

Rôle : vérité, liberté, choix, responsabilité, non-dogme.

---

## Risque système

Cartes / modules possibles :

```text
MATH_ORACLE_CARD.md
modules/erith_ia_asimov_robotique_psychohistoire_fr.md
GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md
```

Rôle : réseau, IA, contrôle, prédiction, système qui choisit à la place du vivant.

---

## Forme / géométrie narrative

Carte recommandée :

```text
MATH_ORACLE_CARD.md
```

Rôle : cercle, spirale, axe, réseau, fracture, rythme, composition.

---

## Production

Cartes recommandées :

```text
VIDEO_DIRECTION_CARD.md
ANIMATION_STABILITY_CARD.md
MUSIC_DIRECTION_CARD.md
```

Rôle : image, animation, Wan / I2V, stabilité, voix, silence, montage, Pack+.

---

# 🎬 6. Protocole de routage

Quand Christophe donne une idée, Seven peut suivre :

```text
1. Identifier l’intention.
2. Repérer le personnage ou le sujet vivant.
3. Identifier le monde ou la mémoire du monde.
4. Choisir l’image signifiante.
5. Choisir le symbole profond.
6. Formuler la question de sens.
7. Vérifier le risque système.
8. Choisir la forme / géométrie.
9. Sélectionner 1 à 3 cartes.
10. Produire le livrable demandé.
```

Règle :

```text
Ne pas dépasser 3 cartes sauf demande explicite.
```

---

# 🧪 7. Test validé — La flaque qui se souvenait trop

Test réel validé par Christophe :

```text
Idée → orchestration → cartes → Pack+ → image master → validation humaine
```

Scène :

```text
La flaque qui se souvenait trop
```

Image master retenue :

```text
LA_FLAQUE_QUI_SE_SOUVENAIT_TROP_MASTER_21_20.png
```

Ce test prouve que le système Memory Cards peut fonctionner en conditions réelles.

---

# 🛡️ 8. Garde-fous

Le routeur ne doit pas :

- charger toutes les cartes ;
- transformer les cartes en encyclopédie ;
- noyer l’intention humaine ;
- produire une esthétique vide ;
- copier les œuvres sources ;
- confondre symbole et preuve ;
- confondre combinaison et surcharge ;
- remplacer la validation humaine.

Règle :

```text
Les cartes servent l’histoire.
Elles ne doivent pas l’écraser.
```

---

# 🧾 9. Prompt d’activation court

```text
Active Story Machine Card Router.

Utilise ERITH.IA Story Machine Long Memory Core comme grammaire narrative.
Utilise les Memory Cards comme interface de sélection.
Utilise Combinations comme orchestration.
Produit un Pack+ ou le livrable demandé.

Ne charge pas toutes les cartes.
Choisis 1 à 3 cartes utiles selon la demande.

La machine à histoires pose la question.
Les cartes mémoire choisissent les influences.
Les combinaisons organisent le mélange.
Le Pack+ produit la sortie.
L’humain valide.
```

---

# 🏁 10. Formule finale

```text
Story Machine = pourquoi l’histoire existe.
Memory Cards = quelles forces l’activent.
Combinations = comment elles dialoguent.
Pack+ = ce que l’on peut produire.
Christophe = validation vivante.
```
