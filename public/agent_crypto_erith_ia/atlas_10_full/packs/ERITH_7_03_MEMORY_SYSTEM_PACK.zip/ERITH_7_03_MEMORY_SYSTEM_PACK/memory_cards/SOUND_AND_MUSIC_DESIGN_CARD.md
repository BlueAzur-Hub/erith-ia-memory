# 🎼 SOUND AND MUSIC DESIGN CARD

Statut : Memory Card — sound design et musique  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : ambiance sonore / musique / sound design / narration audio / production vidéo

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Comment le monde sonne-t-il ?

Une image montre.  
Une animation respire.  
Une narration parle.  
Mais le son fait exister l’espace autour.

Le sound design ne doit pas seulement décorer.

Il doit porter :

- le lieu ;
- l’émotion ;
- la tension ;
- la mémoire ;
- la règle du monde ;
- la présence du guide ;
- le mystère de l’objet ;
- la transformation finale.

Formule :

L’image montre.  
La narration parle.  
Le son fait respirer le monde.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- SCENES_AND_KEYFRAMES_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- STORY_ENGINE_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec SCENES_AND_KEYFRAMES_CARD :

- donner une ambiance sonore à un plan clé ;
- choisir les sons d’un moment précis ;
- éviter de mettre toute la musique du film dans une seule scène.

Rôle avec NARRATION_AND_DIALOGUE_CARD :

- accompagner la voix sans l’écraser ;
- définir le rythme des silences ;
- préparer une narration ElevenLabs plus respirable.

Rôle avec WORLDS_AND_PLACES_CARD :

- donner une signature sonore au monde ;
- faire entendre la loi étrange du lieu ;
- transformer un décor en espace vivant.

Rôle avec STORY_ENGINE_CARD :

- moduler le son selon les étapes du récit ;
- ouvrir, tendre, révéler, apaiser ;
- construire une progression émotionnelle.

Rôle avec HERO_ARCHETYPES_CARD :

- donner un motif sonore au héros ;
- accompagner sa transformation ;
- éviter les thèmes héroïques trop lourds.

Rôle avec GUIDES_AND_ALLIES_CARD :

- créer une signature sonore pour le guide ;
- distinguer oracle, protecteur, messager, miroir ou machine ;
- rendre l’apparition du guide immédiatement reconnaissable.

Rôle avec QUEST_OBJECTS_CARD :

- donner un son à l’objet de quête ;
- rendre son activation sensible ;
- signaler son mystère sans explication.

Rôle avec OBSTACLES_AND_ANTAGONISTS_CARD :

- créer une tension sans violence visuelle ;
- faire sentir un obstacle avant de le montrer ;
- donner une profondeur à l’antagoniste.

Rôle avec EMOTIONAL_ARCS_CARD :

- accompagner la transformation intérieure ;
- rendre la peur, le courage, la solitude ou la confiance audibles ;
- éviter le mélodrame.

Rôle avec POWERS_AND_RULES_CARD :

- créer le son d’une règle qui s’active ;
- rendre visible l’invisible par le son ;
- signaler la condition, le prix ou la conséquence.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des ambiances douces, rassurantes, non agressives ;
- accompagner les contes et ateliers enfants ;
- garder le mystère sans peur traumatique.

Rôle avec COMBINATIONS :

- créer une signature sonore pour une constellation de cartes ;
- éviter le collage musical ;
- produire une ambiance cohérente.

---

# 🧬 3. Structure d’un sound design narratif

Pour créer une ambiance sonore forte, définir sept éléments.

## 1. Lieu sonore

Où sommes-nous ?

Exemples :

- forêt lunaire ;
- ville de pluie ;
- bibliothèque infinie ;
- jardin mécanique ;
- archive souterraine ;
- réseau mental ;
- train nocturne ;
- palais des miroirs.

## 2. Texture principale

Quel son porte le monde ?

Exemples :

- pluie ;
- vent ;
- bois ;
- eau ;
- verre ;
- métal ;
- drones synthétiques ;
- pages ;
- clochettes ;
- battement sourd.

## 3. Motif émotionnel

Quelle émotion domine ?

Exemples :

- émerveillement ;
- mélancolie ;
- tension douce ;
- solitude ;
- curiosité ;
- courage ;
- mystère ;
- apaisement.

## 4. Motif du héros ou du guide

Quel petit son les accompagne ?

Exemples :

- trois notes de piano ;
- souffle doux ;
- clochette légère ;
- ronronnement discret ;
- pulse synthétique ;
- bruissement d’ailes ;
- note de violoncelle.

## 5. Son de l’objet ou de la règle

Comment l’objet, la magie ou la technologie s’active-t-il ?

Exemples :

- cristal qui vibre ;
- clé qui chauffe ;
- boussole qui tinte ;
- miroir qui résonne ;
- hologramme qui s’ouvre ;
- mémoire qui pulse ;
- code qui respire.

## 6. Silence

Où faut-il retirer le son ?

Exemples :

- avant la révélation ;
- quand le héros choisit ;
- quand le guide disparaît ;
- avant une phrase-oracle ;
- quand la vérité devient visible.

## 7. Transformation finale

Comment le son change-t-il à la fin ?

Exemples :

- la pluie devient plus douce ;
- le drone froid devient accord chaud ;
- les bruits mécaniques deviennent rythmiques ;
- la forêt cesse de gronder ;
- le silence devient apaisé.

---

# 🧒 4. Ambiances douces pour contes enfants

## 🌲 Forêt lunaire

Sons :

- vent très doux ;
- feuilles lentes ;
- clochettes lointaines ;
- hibou discret ;
- pas feutrés ;
- harpe légère.

Émotion : peur apprivoisée, émerveillement, calme.

À éviter : cris, grondements agressifs, tension horrifique.

## 📚 Bibliothèque infinie

Sons :

- pages qui tournent ;
- bois ancien ;
- poussière légère ;
- murmures très doux ;
- plume sur papier ;
- réverbération chaude.

Émotion : curiosité, mémoire, secret rassurant.

## 🌧️ Ville de pluie douce

Sons :

- pluie fine ;
- gouttes dans les flaques ;
- pas calmes ;
- néons doux ;
- petite mélodie de piano ;
- souffle de rue vide.

Émotion : mélancolie douce, solitude non triste, mystère.

## ⚙️ Jardin mécanique

Sons :

- petits engrenages ;
- cliquetis doux ;
- ailes de papillon métallique ;
- eau de fontaine ;
- musique de boîte à musique lente ;
- souffle végétal.

Émotion : patience, réparation, tendresse.

## 🚂 Train nocturne

Sons :

- roulement doux ;
- rails lointains ;
- cloche de gare ;
- vent nocturne ;
- murmure de rêves ;
- cordes très légères.

Émotion : aventure calme, conte du soir, retour.

## 🪞 Palais des miroirs

Sons :

- résonance de verre ;
- pas délicats ;
- tintement argenté ;
- souffle lunaire ;
- silence entre les reflets ;
- note cristalline.

Émotion : vérité douce, hésitation, clarté.

---

# 🌃 5. Ambiances cyberpunk / mémoire / post-humanisme

## 🌧️ Mégacité de pluie

Sons :

- pluie dense ;
- basses lentes ;
- néons électriques ;
- moteurs lointains ;
- vapeur ;
- annonces urbaines floues ;
- drone synthétique profond.

Émotion : solitude, mélancolie, enquête.

## 💾 Archive souterraine

Sons :

- ventilation grave ;
- serveurs ;
- impulsions basses ;
- données fragmentées ;
- bips très rares ;
- silence froid ;
- réverbération métallique.

Émotion : tension, mémoire, vérité incomplète.

## 🧠 Ville-réseau

Sons :

- pulses numériques ;
- voix filtrées lointaines ;
- glitch doux ;
- flux de données ;
- basse cardiaque ;
- signal faible ;
- silence numérique.

Émotion : connexion sans lien, conscience distribuée.

## 🧬 Corps-support dormant

Sons :

- respiration artificielle ;
- liquide ou verre ;
- cœur synthétique lent ;
- interface médicale froide ;
- note grave suspendue ;
- silence clinique.

Émotion : identité, malaise doux, présence fragile.

## 🌙 Réseau lunaire

Sons :

- nappes bleu-argent ;
- cristal doux ;
- chœur très lointain ;
- réverbération lente ;
- respiration calme ;
- bruit mental qui s’apaise.

Émotion : introspection, mémoire, clarté froide.

---

# 🎼 6. Types de musique

## Conte doux

Instruments possibles :

- piano simple ;
- harpe ;
- célesta ;
- flûte douce ;
- cordes légères ;
- petites percussions feutrées.

Rythme : lent, respiré, rassurant.

## Mystère oracle

Instruments possibles :

- bols résonants ;
- cloches ;
- textures cristallines ;
- notes espacées ;
- chœur très discret ;
- percussions très rares.

Rythme : suspendu, énigmatique, jamais agressif.

## Cyberpunk mélancolique

Instruments possibles :

- synthés analogiques ;
- basse lente ;
- drone profond ;
- piano noyé dans la réverbération ;
- textures électriques ;
- bruit de pluie intégré au rythme.

Rythme : lent à modéré, nocturne, retenu.

## Post-humanisme intime

Instruments possibles :

- nappes froides ;
- violoncelle grave ;
- pulse cardiaque synthétique ;
- voix filtrée ;
- micro-glitch ;
- piano minimal.

Rythme : lent, fragile, existentiel.

## Révélation finale

Instruments possibles :

- montée très douce ;
- accord clair ;
- chœur lointain ;
- lumière sonore ;
- basse qui se résout ;
- silence final.

Rythme : progressif, jamais grandiloquent.

---

# 🧩 7. Combinaisons rapides

## Conte courage

Forêt lunaire + Loup protecteur + Peur → Courage

Sound design : feuilles lentes, souffle de loup calme, harpe douce, silence avant le pas courageux.

## Conte vérité

Palais des miroirs + Miroir du choix + Honte → Vérité douce

Sound design : tintements de verre, note cristalline, silence, souffle doux au moment du reflet.

## Conte patience

Jardin mécanique + Graine de lumière + Impatience → Patience

Sound design : engrenages lents, gouttes d’eau, boîte à musique très douce, pulse lumineux de la graine.

## Cyberpunk mémoire

Mégacité de pluie + Carte mémoire fissurée + Enquêteur mélancolique

Sound design : pluie dense, drone synthétique, néons électriques, mémoire glitchée très discrète.

## Post-humanisme

Corps-support dormant + Disque d’identité + Présence incarnée

Sound design : respiration artificielle, pulse cardiaque synthétique, silence clinique, accord chaud final.

## Réseau conscience

Ville-réseau + Signal faible + Solitude numérique → Lien réel

Sound design : flux de données, voix filtrées, signal faible qui devient motif musical très simple.

---

# 🎙️ 8. Direction audio pour narration

Pour une narration, le sound design doit rester sous la voix.

Règles :

- ne pas couvrir les consonnes ;
- laisser respirer les silences ;
- ne pas surdramatiser ;
- baisser l’ambiance pendant les phrases-oracles ;
- garder une dynamique douce ;
- éviter les musiques trop chargées ;
- privilégier une texture stable sous la voix.

Structure conseillée :

1. ambiance seule très courte ;
2. entrée de la voix ;
3. micro-mouvement sonore sur un mot clé ;
4. silence ou retrait avant la phrase finale ;
5. résolution douce.

---

# 🖼️ 9. Prompt générique — ambiance sonore conte

```text
Create a gentle children storybook sound design and music direction for this scene.

Mood: wonder, tenderness, mystery, courage, child-friendly magic.

Sound palette: soft wind, light chimes, gentle piano or harp, subtle natural ambience, tiny magical particles, warm silence, no horror, no aggressive tension.

Music: simple, delicate, slow, breathable, emotionally clear.

The sound should support the image and narration without overwhelming them.
```

---

# 🌃 10. Prompt générique — ambiance sonore cyberpunk mémoire

```text
Create a cinematic cyberpunk noir sound design and music direction for this scene.

Mood: rain, memory, solitude, artificial consciousness, emotional restraint.

Sound palette: deep rain, distant city hum, analog synth drone, low bass pulse, subtle neon buzz, filtered voices, soft glitch fragments, reflective ambience.

Music: slow, nocturnal, melancholic, restrained, immersive.

The sound should make the city or archive feel alive without becoming action music.
```

---

# 🎬 11. Prompt générique — sound design pour keyframe animée

```text
Create sound design for a short vertical image-to-video scene.

Duration: 5 seconds.

The sound must support one living moment only.

Do not score an entire story.

Include:
- one environmental bed;
- one subtle emotional motif;
- one small sound linked to the main object, guide, rule or memory;
- one gentle resolution or suspended ending.

Avoid:
- loud impacts;
- trailer drums;
- horror stingers;
- cluttered music;
- aggressive transitions.
```

---

# 🧬 12. Block LLM

```text
Active SOUND_AND_MUSIC_DESIGN_CARD.

Utilise cette carte pour créer l’ambiance sonore, la musique, le sound design, la direction audio ou les instructions de production sonore d’une scène, d’une keyframe, d’une narration, d’un conte, d’un Pack+ ou d’une animation.

Toujours définir :
1. lieu sonore ;
2. texture principale ;
3. motif émotionnel ;
4. motif du héros ou du guide ;
5. son de l’objet, de la règle ou de la mémoire ;
6. usage du silence ;
7. transformation sonore finale.

Si SCENES_AND_KEYFRAMES_CARD est active, conçois le son pour un seul moment visuel.

Si NARRATION_AND_DIALOGUE_CARD est active, place la musique sous la voix et respecte les silences.

Si WORLDS_AND_PLACES_CARD est active, donne une signature sonore au lieu.

Si STORY_ENGINE_CARD est active, module le son selon l’étape narrative.

Si HERO_ARCHETYPES_CARD est active, crée un motif simple lié au héros.

Si GUIDES_AND_ALLIES_CARD est active, donne au guide une signature sonore discrète.

Si QUEST_OBJECTS_CARD est active, crée le son d’activation ou de mystère de l’objet.

Si OBSTACLES_AND_ANTAGONISTS_CARD est active, crée une tension lisible sans violence gratuite.

Si EMOTIONAL_ARCS_CARD est active, fais évoluer le son avec la transformation intérieure.

Si POWERS_AND_RULES_CARD est active, rends audible la condition ou la règle.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie une ambiance douce, rassurante, magique et non traumatique.

Si COMBINATIONS est active, crée une signature sonore cohérente pour la constellation de cartes.

Éviter :
- musique trop chargée ;
- trailer drums agressifs ;
- sound design horrifique ;
- sons trop forts sous la narration ;
- ambiance générique ;
- collage musical ;
- surdramatisation ;
- imitation directe d’une œuvre connue.
```

---

# 🕯️ 13. Formule courte

Le son ne remplit pas le silence.

Il révèle ce que l’image ne peut pas dire seule.
