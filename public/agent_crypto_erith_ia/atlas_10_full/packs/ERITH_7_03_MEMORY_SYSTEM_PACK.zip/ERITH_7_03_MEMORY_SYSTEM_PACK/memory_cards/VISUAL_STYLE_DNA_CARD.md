# 🎨 VISUAL STYLE DNA CARD

Statut : Memory Card — ADN visuel  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : direction artistique / palette / lumière / composition / textures / style image

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

À quoi cela ressemble exactement ?

Une histoire peut être claire.  
Une keyframe peut être bien choisie.  
Un Pack+ peut être complet.

Mais sans ADN visuel, l’image peut devenir générique.

Cette carte sert à définir la signature visuelle d’une scène, d’un conte, d’une Memory Card, d’un Pack+ ou d’un univers Hors-Lore.

Elle fixe :

- palette ;
- lumière ;
- textures ;
- composition ;
- cadrage ;
- niveau de détail ;
- style d’illustration ;
- atmosphère ;
- cohérence esthétique ;
- contraintes anti-surcharge ;
- style couverture Memory Card.

Formule :

Le récit donne le sens.  
La keyframe donne l’instant.  
Le style donne la signature.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- SCENES_AND_KEYFRAMES_CARD.md ;
- PACK_PLUS_BUILDER_CARD.md ;
- QUALITY_CONTROL_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- STORY_ENGINE_CARD.md ;
- COMBINATIONS.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md.

Rôle avec SCENES_AND_KEYFRAMES_CARD :

- donner une direction esthétique précise à la keyframe ;
- éviter les images génériques ;
- renforcer le symbole central.

Rôle avec PACK_PLUS_BUILDER_CARD :

- ajouter une section style cohérente au Pack+ ;
- harmoniser prompt image, animation, narration et sound design ;
- donner une identité visuelle exploitable.

Rôle avec QUALITY_CONTROL_CARD :

- vérifier que le style sert le récit ;
- repérer la surcharge ;
- contrôler palette, lisibilité, originalité et cohérence.

Rôle avec WORLDS_AND_PLACES_CARD :

- transformer un lieu en atmosphère visuelle ;
- définir les matières du monde ;
- donner une loi esthétique au décor.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des styles doux, lisibles, merveilleux et non traumatiques ;
- éviter les images trop sombres pour les enfants ;
- garder une clarté émotionnelle.

Rôle avec COMBINATIONS :

- harmoniser plusieurs influences ;
- définir une palette dominante ;
- éviter le collage visuel.

---

# 🧬 3. Structure d’un ADN visuel

Pour définir un style visuel fort, préciser neuf éléments.

## 1. Palette

Quelles couleurs dominent ?

Exemples :

- bleu nuit ;
- cyan électrique ;
- argent lunaire ;
- noir profond ;
- orange sodium ;
- violet doux ;
- vert mousse ;
- or pâle ;
- blanc laiteux ;
- rose néon.

## 2. Lumière

Comment la scène est-elle éclairée ?

Exemples :

- lune douce ;
- néons réfléchis ;
- lumière de conte ;
- lueur d’objet ;
- contre-jour ;
- lumière de fenêtre ;
- halo d’archive ;
- rayon filtré par la brume.

## 3. Textures

Quelles matières doivent être visibles ?

Exemples :

- verre mouillé ;
- métal noir ;
- papier ancien ;
- bois doux ;
- mousse ;
- pierre bleutée ;
- hologrammes ;
- poussière lumineuse ;
- tissu humide ;
- porcelaine froide.

## 4. Composition

Comment lire l’image ?

Exemples :

- sujet central ;
- guide en contrepoint ;
- objet au premier plan ;
- monde immense derrière ;
- reflet en bas ;
- seuil lumineux ;
- diagonale de chemin ;
- cercle protecteur ;
- carte ou artefact centré.

## 5. Cadrage

Quel format sert la production ?

Exemples :

- vertical 9:16 ;
- couverture Memory Card ;
- portrait personnage ;
- plan large monde ;
- gros plan objet ;
- keyframe I2V ;
- bannière ;
- thumbnail.

## 6. Niveau de détail

Quelle densité visuelle viser ?

Exemples :

- minimal symbolique ;
- conte illustré lisible ;
- premium cinematic ;
- cyberpunk dense mais contrôlé ;
- objet isolé sur fond transparent ;
- carte mémoire stylisée.

## 7. Atmosphère

Quelle impression générale ?

Exemples :

- merveilleux doux ;
- mystère rassurant ;
- mélancolie urbaine ;
- introspection lunaire ;
- sacré technologique ;
- archive froide ;
- rêve mécanique ;
- conte nocturne.

## 8. Signature

Quel détail rend l’image reconnaissable ?

Exemples :

- reflets impossibles ;
- pluie-mémoire ;
- sigil central ;
- flaque-archive ;
- lumière de lune ;
- objet de quête au centre ;
- guide animal discret ;
- interface douce ;
- bordure de carte.

## 9. Interdits visuels

Qu’est-ce qu’il faut éviter ?

Exemples :

- surcharge ;
- trop de personnages ;
- arrière-plan qui mange le sujet ;
- style générique ;
- copie de franchise ;
- logo ;
- watermark ;
- texte parasite ;
- violence graphique ;
- horreur si sortie enfant.

---

# 🧒 4. ADN visuel — conte enfant

## Palette

- bleu doux ;
- vert mousse ;
- or pâle ;
- violet léger ;
- rose chaud ;
- blanc laiteux ;
- argent lunaire.

## Lumière

- douce ;
- diffuse ;
- rassurante ;
- jamais agressive ;
- souvent liée à un objet, une lune, une lanterne ou une fenêtre.

## Textures

- papier illustré ;
- bois ;
- mousse ;
- tissu ;
- poussière lumineuse ;
- eau calme ;
- pierre douce ;
- fleurs ;
- livres anciens.

## Composition

- sujet lisible ;
- enfant bien identifiable ;
- guide proche mais non dominant ;
- obstacle doux ;
- symbole central clair ;
- chemin visuel évident.

## À éviter

- peur excessive ;
- dents, griffes ou ombres agressives ;
- hyperréalisme inquiétant ;
- scènes trop sombres ;
- composition confuse ;
- morale visuelle écrasante.

## Formule visuelle

Merveilleux clair + mystère doux + émotion lisible + symbole simple.

---

# 🌃 5. ADN visuel — cyberpunk mémoire

## Palette

- noir profond ;
- bleu nuit ;
- cyan électrique ;
- orange sodium ;
- rose néon ;
- gris mouillé ;
- argent froid.

## Lumière

- néons réfléchis ;
- pluie ;
- contre-jour ;
- hologrammes faibles ;
- lumière publicitaire ;
- lueur d’archive ;
- éclat lunaire dans les reflets.

## Textures

- verre mouillé ;
- béton sombre ;
- métal noir ;
- vapeur ;
- câbles ;
- hologrammes ;
- peau synthétique ;
- surfaces réfléchissantes ;
- cartes mémoire ;
- écrans fracturés.

## Composition

- silhouette petite face à une ville immense ;
- flaque ou reflet central ;
- objet mémoire au premier plan ;
- lignes verticales ;
- profondeur urbaine ;
- solitude lisible.

## À éviter

- pluie + néons sans question humaine ;
- action générique ;
- surcharge de panneaux ;
- personnage trop héroïque ;
- copie directe d’une scène célèbre ;
- cyberpunk décoratif sans mémoire.

## Formule visuelle

Ville immense + reflets + mémoire fragile + solitude humaine.

---

# 🌙 6. ADN visuel — lunaire / introspectif

## Palette

- bleu profond ;
- argent ;
- blanc froid ;
- cyan doux ;
- violet nuit ;
- noir calme ;
- transparence aquatique.

## Lumière

- lune diffuse ;
- reflets d’eau ;
- halo doux ;
- brume ;
- lumière intérieure ;
- contraste bas.

## Textures

- verre bleu ;
- eau miroir ;
- brume ;
- pierre froide ;
- métal argenté ;
- voiles translucides ;
- hologrammes doux.

## Composition

- silhouette de dos ;
- seuil ;
- miroir ou eau ;
- espace vide volontaire ;
- centre calme ;
- symétrie légère.

## À éviter

- action ;
- surcharge ;
- lumière trop agressive ;
- visage trop frontal si l’intention est introspective ;
- excès de texte ou de symboles.

## Formule visuelle

Silence + reflet + lune + seuil + mémoire calme.

---

# 🃏 7. ADN visuel — couverture Memory Card

Une couverture Memory Card doit être immédiatement identifiable comme objet-carte ou artefact visuel.

## Styles possibles

- carte oracle ;
- carte mémoire microSD stylisée ;
- artefact transparent ;
- couverture avec bordure ;
- sigil central ;
- objet isolé ;
- iconographie premium ;
- fond transparent ou fond très propre.

## Composition recommandée

- objet central ;
- silhouette claire ;
- bordure lisible ;
- peu ou pas de texte ;
- symbole central fort ;
- palette cohérente ;
- fond simple ;
- aucun logo parasite.

## Palette recommandée

- noir ;
- bleu nuit ;
- argent ;
- cyan ;
- violet doux ;
- or discret.

## À éviter

- fond gris non voulu ;
- pseudo-transparence ;
- damier imprimé ;
- texte illisible ;
- logo de marque ;
- style trop proche d’un produit existant ;
- trop de détails minuscules.

## Formule visuelle

Objet clair + symbole fort + fond propre + identité premium.

---

# 🎞️ 8. ADN visuel — image fixe master

Une image fixe master doit être pensée avant l’animation.

## Règles

- une idée principale ;
- un sujet lisible ;
- un symbole central ;
- une composition stable ;
- lumière cohérente ;
- pas de foule inutile ;
- pas d’action trop complexe ;
- profondeur claire ;
- format adapté.

## Pour Wan / I2V

Préférer :

- personnage presque immobile ;
- environnement animé doucement ;
- reflets ;
- pluie ;
- lumière qui pulse ;
- guide qui cligne des yeux ;
- objet qui s’active ;
- caméra fixe ou push-in lent.

Éviter :

- course ;
- combat ;
- mains complexes ;
- foule ;
- transformation massive ;
- mouvements contradictoires ;
- composition trop dense.

---

# 🧩 9. Combinaisons rapides

## Conte enfant

Forêt lunaire + Enfant qui a peur du noir + Loup protecteur

ADN visuel : bleu doux, lune diffuse, forêt lisible, loup protecteur non menaçant, lumière rassurante, chemin clair.

## Conte objet

Jardin mécanique + Graine de lumière + Apprenti inventeur

ADN visuel : cuivre doux, vert tendre, or pâle, engrenages lisibles, graine lumineuse au centre, atmosphère patiente.

## Mémoire cyberpunk

Mégacité de pluie + Carte mémoire fissurée + Enquêteur mélancolique

ADN visuel : noir profond, cyan, orange sodium, verre mouillé, silhouette de dos, carte mémoire comme seul point chaud.

## Lunaire introspectif

Réseau lunaire + Reflet + Mémoire calme

ADN visuel : bleu argent, brume, miroir d’eau, silhouette en retrait, halo doux, espace vide.

## Couverture Memory Card

COMBINATIONS + carte microSD stylisée + sigil central

ADN visuel : objet isolé, fond transparent, bordure premium, cyan argent, détails lisibles, pas de logo.

---

# 🖼️ 10. Prompt générique — ADN visuel

```text
Define a precise visual style DNA for this scene.

Include:
- dominant palette;
- lighting style;
- key textures;
- composition rules;
- framing;
- level of detail;
- atmosphere;
- visual signature;
- visual avoid list.

The style must support the story, remain original, avoid clutter, avoid copied franchise elements, and produce a clean master image suitable for generation and possible I2V animation.
```

---

# 🖼️ 11. Prompt image générique — style master

```text
21/20 masterpiece, original visual style master image, clear visual DNA, coherent palette, cinematic lighting, readable composition, strong central symbol, premium textures, emotional atmosphere, no clutter, no copied characters, no franchise names, no logo, no watermark, image designed as a polished master still, vertical 9:16 composition.
```

---

# 🎬 12. Prompt animation générique — style préservé

```text
21/20 masterpiece animation, preserve the visual style DNA of the source image.

Animate only from the provided source image.

Preserve exact palette, lighting, textures, composition, subject placement, visual signature and atmosphere.

Main motion:
minimal and elegant, one clear movement only.

Secondary motion:
soft particles, rain, mist, light pulse, reflection movement or subtle hologram, depending on the scene.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no zoom out, no reframing, no camera reset.

Do not alter the style.
Do not change the subject.
Do not add clutter.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 13. Block LLM

```text
Active VISUAL_STYLE_DNA_CARD.

Utilise cette carte pour définir l’ADN visuel d’une scène, Memory Card, Pack+, conte, keyframe, image master, couverture ou animation.

Toujours définir :
1. palette ;
2. lumière ;
3. textures ;
4. composition ;
5. cadrage ;
6. niveau de détail ;
7. atmosphère ;
8. signature visuelle ;
9. interdits visuels.

Si SCENES_AND_KEYFRAMES_CARD est active, applique l’ADN visuel à un seul instant fort.

Si PACK_PLUS_BUILDER_CARD est active, ajoute une section Style DNA au Pack+.

Si QUALITY_CONTROL_CARD est active, vérifie que le style sert le récit et ne surcharge pas la sortie.

Si WORLDS_AND_PLACES_CARD est active, transforme la loi du monde en atmosphère visuelle.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie un style doux, lisible, rassurant, non traumatique.

Si COMBINATIONS est active, harmonise les influences en une seule direction esthétique.

Pour une couverture Memory Card :
- objet clair ;
- symbole central ;
- fond propre ;
- identité premium ;
- pas de logo ;
- pas de texte illisible ;
- pas de damier imprimé.

Pour une image I2V :
- composition stable ;
- sujet lisible ;
- mouvement potentiel simple ;
- caméra calme ;
- style préservable.

Éviter :
- style générique ;
- surcharge ;
- collage visuel ;
- incohérence de palette ;
- copie de franchise ;
- texte parasite ;
- logos ;
- watermark ;
- fond non voulu.
```

---

# 🕯️ 14. Formule courte

Le style n’est pas une décoration.

C’est la mémoire visuelle d’une idée.
