# 🗂️ MEMORY CARDS INDEX

Statut : index principal  
Projet : @erith IA / ERITH.IA  
Version : V1.2  
Rôle : lister les cartes mémoire disponibles, leur statut et leurs combinaisons.

---

# 🧱 1. Cartes fondatrices

## 📚 Routeur machine à histoires

- ✅ STORY_MACHINE_CARD_ROUTER.md

Rôle : relier ERITH.IA Story Machine Long Memory Core aux Memory Cards, aux combinaisons et aux sorties Pack+.

Formule :

```text
Story Machine = grammaire narrative.
Memory Cards = interface de sélection.
Combinations = orchestration.
Pack+ = sortie exploitable.
Validation humaine = verrou final.
```

## 🌧️ Cartes DA / Science-fiction / Cyberpunk

- ✅ ALTERED_CARBON_SERIES_VISUAL_DA_CARD.md
- ✅ BLADE_RUNNER_CITY_MELANCHOLY_CARD.md
- ✅ GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md

## 🪞 Cartes conte / rêve / seuil

- ✅ ALICE_ORACLE_CAT_CARD.md
- ⏳ OZ_INITIATORY_ROAD_CARD.md
- ⏳ NEVERENDING_STORY_MEMORY_WORLD_CARD.md

## 🌙 Cartes opératrices

- ✅ AERITH_9_LUNAR_CARD.md
- ✅ MATH_ORACLE_CARD.md
- ⏳ DISCERNMENT_CARD.md

## 🎬 Cartes production

- ✅ VIDEO_DIRECTION_CARD.md
- ✅ MUSIC_DIRECTION_CARD.md
- ✅ ANIMATION_STABILITY_CARD.md

---

# 🌌 2. Combinaisons prioritaires

## 📚🃏 Story Machine + Memory Cards + Combinations

Usage :

- machine à histoires ;
- intention humaine ;
- personnage vivant ;
- monde avec mémoire ;
- image signifiante ;
- symbole profond ;
- Pack+ ;
- validation humaine.

Sorties possibles :

- scène ;
- Pack+ ;
- prompt image ;
- prompt animation ;
- narration courte ;
- fiche personnage ;
- fiche monde ;
- plan vidéo.

Règle :

```text
La machine à histoires pose la question.
Les cartes mémoire choisissent les influences.
Les combinaisons organisent le mélange.
Le Pack+ produit la sortie.
L’humain valide.
```

---

## 🃏🃏🃏 Altered Carbon + Alice Oracle Cat + Aerith-9 Lunaire

Usage :

- conte post-humain ;
- identité fragmentée ;
- chat-oracle ;
- reflets ;
- nocturne ;
- luxe noir ;
- corps-supports ;
- rêve cybernétique.

Sorties possibles :

- prompt image ;
- prompt animation ;
- ambiance musicale ;
- scène de seuil ;
- personnage-guide ;
- dashboard Memory Cards.

---

## 🃏🃏🃏 Blade Runner + Ghost in the Shell + Math Oracle

Usage :

- ville pluie néons ;
- réseau ;
- conscience ;
- structure ;
- cadrage ;
- géométrie visuelle ;
- composition futuriste.

Sorties possibles :

- direction artistique cyberpunk ;
- prompt image de ville-réseau ;
- prompt animation stable ;
- architecture visuelle ;
- scène de conscience connectée.

---

## 🃏🃏🃏 Video Direction + Animation Stability + Music Direction

Usage :

- production vidéo ;
- Wan / I2V ;
- continuité LEGO ;
- rythme de montage ;
- ambiance sonore ;
- vérification avant Hub ;
- prompt positif + négatif.

Sorties possibles :

- storyboard ;
- prompt animation ;
- checklist RunningHub ;
- plan de montage ;
- direction musicale.

---

## 🃏🃏🃏 Oz + Alice + Mythologie vivante

Usage :

- route initiatique ;
- seuil ;
- rêve ;
- miroir ;
- monde traversé ;
- symboles ;
- retour au réel.

Statut :

À approfondir quand les cartes Oz et NeverEnding Story seront écrites.

---

# ⚙️ 3. Règle d’usage

Ne pas activer toutes les cartes.

Choisir seulement :

- la ou les influences utiles ;
- les opérateurs utiles ;
- les capacités utiles ;
- la sortie attendue.

Règle courte :

- 🃏 1 carte = influence claire ;
- 🃏🃏 2 cartes = dialogue ;
- 🃏🃏🃏 3 cartes = constellation.

Pour la machine à histoires :

```text
Story Machine = pourquoi l’histoire existe.
Memory Cards = quelles forces l’activent.
Combinations = comment elles dialoguent.
Pack+ = ce que l’on peut produire.
Christophe = validation vivante.
```

---

# 📌 4. État V1.2

Cartes / routeurs écrits :

- ✅ STORY_MACHINE_CARD_ROUTER.md
- ✅ ALTERED_CARBON_SERIES_VISUAL_DA_CARD.md
- ✅ ALICE_ORACLE_CAT_CARD.md
- ✅ AERITH_9_LUNAR_CARD.md
- ✅ BLADE_RUNNER_CITY_MELANCHOLY_CARD.md
- ✅ GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md
- ✅ MATH_ORACLE_CARD.md
- ✅ VIDEO_DIRECTION_CARD.md
- ✅ MUSIC_DIRECTION_CARD.md
- ✅ ANIMATION_STABILITY_CARD.md

Cartes à écrire plus tard :

- ⏳ OZ_INITIATORY_ROAD_CARD.md
- ⏳ NEVERENDING_STORY_MEMORY_WORLD_CARD.md
- ⏳ DISCERNMENT_CARD.md

---

# 🧬 5. Block LLM index

```text
Lis l’index Memory Cards.

N’active pas toutes les cartes.

Choisis uniquement les cartes utiles selon la demande.

Si l’utilisateur demande une machine à histoires, une scène narrative, un Pack+ ou une transformation idée → histoire → production, charge STORY_MACHINE_CARD_ROUTER.md comme passerelle entre Story Machine Long Memory Core, Memory Cards, Combinations et Pack+.

Si l’utilisateur demande une image, une animation, une musique ou une direction artistique, sélectionne :
- une carte esthétique ;
- une carte symbolique ;
- éventuellement une carte opératrice ;
- éventuellement une carte production.

Produit ensuite :
1. synthèse courte des cartes actives ;
2. direction artistique ;
3. prompt image, prompt animation ou prompt musique si demandé ;
4. garde-fous ;
5. proposition de combinaison suivante.

Ne copie jamais les œuvres sources.
N’utilise pas leurs personnages, noms propres ou intrigues.
Transforme les cartes en direction originale exploitable.
```

---

# 🕯️ 6. Formule courte

Les cartes ne remplacent pas le Coffre.

Elles rendent le Coffre lisible.

Seven Heaven choisit les cartes utiles, les combine, puis produit une sortie claire.

La machine à histoires donne le sens.

Les cartes donnent le choix.

Les combinaisons donnent la méthode.

Le Pack+ donne le résultat.

Christophe donne la validation humaine.