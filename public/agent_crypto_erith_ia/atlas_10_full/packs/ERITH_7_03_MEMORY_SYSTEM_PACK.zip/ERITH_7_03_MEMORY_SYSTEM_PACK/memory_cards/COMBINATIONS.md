# 🧬 MEMORY CARDS — COMBINATIONS

Statut : Memory Card centrale — table des hybridations  
Projet : @erith IA / ERITH.IA  
Version : V2 — Notion Génie  
Rôle : organiser les dialogues, constellations et synthèses entre cartes mémoire.

---

![Combinations Memory Card Transparent Master](../assets/images/COMBINATIONS_MEMORY_CARD_TRANSPARENT_MASTER_21_20.png)

Image master 21/20 — Memory Cards Combinations.  
Couverture Hors-Lore originale : carte mémoire premium au format microSD stylisé, fond transparent, découpe lisible, sigil central de combinaison, nœuds symboliques reliés, constellation de modules et synthèse créative.

---

# 🌟 1. Principe central

Une combinaison ne doit jamais être un simple empilement de références.

Elle doit produire :

- une direction claire ;
- une tension lisible ;
- une image mentale forte ;
- une sortie exploitable ;
- une synthèse originale.

Règle courte :

- 🃏 1 carte = une couleur dominante ;
- 🃏🃏 2 cartes = un dialogue ;
- 🃏🃏🃏 3 cartes = une constellation forte ;
- 🃏🃏🃏🃏+ = possible seulement si l’intention est justifiée.

Formule :

La combinaison ne sert pas à tout mettre.  
Elle sert à faire naître quelque chose.

---

# 🧭 2. Méthode de lecture

Quand plusieurs Memory Cards sont activées, l’agent doit identifier quatre rôles.

## 🎨 Carte dominante

Elle donne la grande couleur : ambiance, monde, lumière, émotion, genre visuel.

Exemples :

- ville pluvieuse ;
- luxe noir ;
- rêve lunaire ;
- conscience cybernétique ;
- conte étrange.

## ⚡ Carte de contraste

Elle introduit une tension ou un décalage.

Elle empêche la combinaison de devenir plate.

Exemples :

- chat-oracle dans une ville noire ;
- lune douce dans un monde post-humain ;
- mémoire fragile dans un univers technologique ;
- poésie dans une architecture froide.

## 🗝️ Carte opératrice

Elle transforme le sens de la scène.

Elle peut agir comme :

- seuil ;
- guide ;
- miroir ;
- question morale ;
- moteur symbolique ;
- filtre de narration.

## 🎁 Sortie attendue

La combinaison doit déboucher sur un objet clair :

- prompt image ;
- prompt animation ;
- scène narrative ;
- fiche d’univers ;
- personnage-guide ;
- ambiance musicale ;
- direction artistique ;
- Pack+ Hors-Lore.

---

# 🧪 3. Test de maturité

Une combinaison est mûre si elle répond à trois questions.

## 1. Qu’est-ce qui domine ?

Il faut une hiérarchie.

Si tout domine, rien ne domine.

## 2. Qu’est-ce qui crée la tension ?

Une bonne combinaison contient une friction fertile.

Exemple :

- technologie froide + rêve lunaire ;
- corps remplaçable + âme incertaine ;
- ville-machine + mémoire liquide ;
- oracle félin + enquête post-humaine.

## 3. Qu’est-ce qui devient possible ?

La combinaison doit ouvrir une scène, une image, un monde ou une idée.

Si elle n’ouvre rien, elle n’est pas prête.

---

# 🃏🃏 4. Combinaisons 2 cartes

## 🌃 Altered Carbon + Alice Oracle Cat

Résultat :

- conte cyberpunk noir ;
- identité instable ;
- chat-guide ambigu ;
- luxe noir ;
- monde étrange ;
- seuils mentaux.

## 🌙 Altered Carbon + Aerith-9 Lunaire

Résultat :

- post-humanisme nocturne ;
- mémoire ;
- corps-supports ;
- reflets ;
- mélancolie ;
- élégance froide.

## 🐈‍⬛ Alice Oracle Cat + Aerith-9 Lunaire

Résultat :

- oracle félin ;
- rêve ;
- seuil ;
- miroir ;
- intuition ;
- logique décalée ;
- ambiance lunaire.

## 🌧️ Blade Runner City Melancholy + Ghost in the Shell

Résultat :

- ville-réseau ;
- solitude numérique ;
- pluie mentale ;
- interfaces de conscience ;
- ghost perdu dans la foule ;
- humanité incertaine.

## 🧬 Altered Carbon + Ghost in the Shell

Résultat :

- conscience distribuée ;
- corps artificiel ;
- identité transférable ;
- mémoire stockée ;
- ghost dans la machine ;
- post-humanisme analytique.

## 🌧️ Blade Runner City Melancholy + Altered Carbon

Résultat :

- ville verticale de classes sociales ;
- bas-fonds pluvieux ;
- élites au-dessus des nuages ;
- mémoire comme propriété ;
- enquête noire ;
- corps et identité sous contrôle.

## 🐈‍⬛ Alice Oracle Cat + Ghost in the Shell

Résultat :

- chat du seuil mental ;
- interface ambiguë ;
- intuition dans le réseau ;
- oracle numérique ;
- ghost guidé par symbole ;
- vérité oblique.

---

# 🃏🃏🃏 5. Combinaisons 3 cartes

## 🌌 Altered Carbon + Alice Oracle Cat + Aerith-9 Lunaire

Résultat :

- conte post-humain noir ;
- chat-oracle ;
- mémoire fracturée ;
- identité transférable ;
- reflets ;
- seuils ;
- élégance lunaire ;
- tension psychique.

## 🌧️ Blade Runner City Melancholy + Ghost in the Shell + Aerith-9 Lunaire

Résultat :

- ville nocturne comme miroir mental ;
- conscience cybernétique ;
- pluie lunaire ;
- mémoire douce-amère ;
- réseau intérieur ;
- solitude poétique.

## 🧬 Blade Runner City Melancholy + Altered Carbon + Ghost in the Shell

Résultat :

- enquête post-humaine ;
- ville verticale de classes sociales ;
- corps-supports ;
- réseau mental ;
- luxe noir ;
- ghost fragmenté dans la mégacité.

## 🐈‍⬛ Alice Oracle Cat + Blade Runner City Melancholy + Aerith-9 Lunaire

Résultat :

- oracle félin dans la pluie ;
- ville-rêve ;
- seuil lunaire ;
- reflets instables ;
- intuition urbaine ;
- conte cyberpunk mélancolique.

## 🕯️ Alice Oracle Cat + Altered Carbon + Ghost in the Shell

Résultat :

- guide ambigu dans un monde de corps remplaçables ;
- conscience copiée ;
- masque félin ;
- identité comme énigme ;
- réseau étrange ;
- vérité cachée derrière le luxe noir.

## 🌙 Blade Runner City Melancholy + Altered Carbon + Aerith-9 Lunaire

Résultat :

- ville noire et lunaire ;
- reflets de corps-supports ;
- pluie sur verre premium ;
- solitude d’une identité transférée ;
- mémoire comme luxe triste ;
- élégance froide.

## 🧿 Alice Oracle Cat + Blade Runner City Melancholy + Ghost in the Shell

Résultat :

- oracle numérique dans une ville-réseau ;
- chat-guide dans la pluie ;
- ghost perdu dans la foule ;
- intuition contre surveillance ;
- vérité cachée dans les reflets ;
- enquête mentale.

---

# 🖼️ 6. Exemples prompt image — 10 directions

Ces exemples servent de modèles courts.

Ils montrent comment une combinaison devient une direction claire.

Ne pas les copier mécaniquement : ils sont des gabarits de synthèse.

---

## Exemple 1 — Post-human fairy tale

Combinaison : Altered Carbon + Alice Oracle Cat + Aerith-9 Lunaire

```text
21/20 masterpiece, original cyberpunk dark fairy tale scene, post-human noir atmosphere, luxurious vertical city interior, mysterious oracle cat with luminous eyes sitting on the edge of a reflective black glass table, fragmented identity screens floating in the room, lunar blue and silver light, rain on panoramic windows, memory-transfer symbols, elegant and strange, dreamlike threshold, no copied characters, no existing franchise names, cinematic vertical 9:16 composition, premium visual direction, subtle holograms, psychological tension, beautiful but unsettling.
```

---

## Exemple 2 — Ville-réseau lunaire

Combinaison : Blade Runner City Melancholy + Ghost in the Shell + Aerith-9 Lunaire

```text
21/20 masterpiece, original nocturnal cybernetic city scene, immense rainy vertical megacity under moon-blue light, lone figure standing on a wet rooftop connected to a translucent neural network above the city, ghost-like memory traces moving through rain and holographic signs, reflective puddles, soft cyan interfaces, melancholic urban solitude, consciousness distributed through the skyline, poetic and restrained, no copied characters, no franchise names, vertical 9:16 composition, premium cinematic atmosphere.
```

---

## Exemple 3 — Enquête post-humaine

Combinaison : Blade Runner City Melancholy + Altered Carbon + Ghost in the Shell

```text
21/20 masterpiece, original post-human cyberpunk noir investigation scene, rain-soaked lower city beneath luxury towers, reflective streets, dark glass, body-support archive facility hidden behind neon fog, elegant investigator silhouette seen from behind, holographic identity fragments, neural interface maps, synthetic vessel chamber, memory traces like blue light, social verticality, ghost-in-the-machine tension, cinematic vertical 9:16 framing, no copied characters, no franchise names, premium dark science-fiction mood.
```

---

## Exemple 4 — Oracle félin sous la pluie

Combinaison : Alice Oracle Cat + Blade Runner City Melancholy + Aerith-9 Lunaire

```text
21/20 masterpiece, original lunar cyberpunk oracle scene, a luminous-eyed black oracle cat sitting on a rain-wet stone threshold in a narrow neon alley, moonlight reflected in puddles, distant vertical city towers, blue silver mist, soft holographic symbols floating around the cat, unstable reflections showing possible futures, melancholic and mysterious, elegant dream logic, no copied characters, no franchise names, vertical 9:16 composition, poetic cinematic lighting, quiet magical technology.
```

---

## Exemple 5 — Masque, corps et réseau

Combinaison : Alice Oracle Cat + Altered Carbon + Ghost in the Shell

```text
21/20 masterpiece, original cybernetic identity chamber, luxury noir interior with black glass and cold cyan light, a calm human-like figure facing a dormant synthetic body vessel while an oracle cat watches from a reflective console, ghostly network diagrams surrounding them, memory archives, identity masks, subtle feline-eye holograms, question of soul and consciousness, elegant post-human mystery, no copied characters, no franchise names, vertical 9:16 framing, premium cinematic concept art.
```

---

## Exemple 6 — Reflet d’identité nocturne

Combinaison : Altered Carbon + Aerith-9 Lunaire

```text
21/20 masterpiece, original nocturnal post-human reflection chamber, silver-blue moonlight, black glass floors, suspended memory archives, calm silhouette seen from behind, dormant replacement body reflected in liquid mirror surfaces, lunar mist, elegant cold design, memory and identity tension, no franchise names, no copied characters, vertical 9:16 premium concept art, emotionally restrained, mysterious and beautiful.
```

---

## Exemple 7 — Chat du seuil mental

Combinaison : Alice Oracle Cat + Ghost in the Shell

```text
21/20 masterpiece, original cybernetic threshold scene, mysterious oracle cat with luminous cyan eyes appearing inside a translucent neural interface corridor, ghost-like code veils, reflective surfaces, subtle holographic architecture, mind-network symbolism, elegant and uncanny atmosphere, intuition inside the machine, fully original universe, vertical 9:16 composition, premium cinematic sci-fi poetry.
```

---

## Exemple 8 — Pluie, souvenir, ghost

Combinaison : Blade Runner City Melancholy + Ghost in the Shell

```text
21/20 masterpiece, original rainy cybernetic street scene, lone figure in a dark wet coat standing in a vertical neon city, holographic consciousness traces flickering across puddles, ghostly interface reflections, urban loneliness, deep blue and orange lights, wet pavement, memory and self dissolving into the city, vertical 9:16 composition, premium cinematic atmosphere, no copied characters, no franchise names.
```

---

## Exemple 9 — Luxe noir de la mémoire

Combinaison : Blade Runner City Melancholy + Altered Carbon

```text
21/20 masterpiece, original luxury noir city chamber high above a rainy megacity, dark glass, premium black metal, rain trails on panoramic windows, memory-transfer altar, elegant silhouette, vertical social contrast between towers and lower city, artificial memory as power, body-support archive symbols, premium dark cyberpunk mood, no copied characters, no franchise names, vertical 9:16 framing.
```

---

## Exemple 10 — Seuil lunaire des futurs possibles

Combinaison : Alice Oracle Cat + Aerith-9 Lunaire

```text
21/20 masterpiece, original lunar threshold scene, elegant black oracle cat with luminous violet-cyan eyes sitting before a moonlit mirror portal, silver-blue reflections, mist, dreamlike architecture, soft holographic symbols, intuition, silence, threshold, future possibilities seen through reflective light, poetic and mysterious, vertical 9:16 premium composition, no copied characters, no franchise names.
```

---

# 🎬 7. Modèle prompt animation — constellation

```text
21/20 masterpiece animation, premium cinematic cyberpunk noir image-to-video.

Animate only from the provided source image.

Preserve the exact composition, framing, main subject, reflective surfaces, lighting, memory screens, rain reflections, color palette and vertical phone composition.

Main motion:
the central subject remains mostly still, only subtle breathing, tiny fabric movement, slow eye glow fluctuation if relevant, no dramatic gesture.

Secondary motion:
holographic memory fragments flicker softly, rain reflections move gently on glass or pavement, lunar light pulses very subtly, distant city lights shimmer.

Camera:
locked camera or nearly locked camera, no zoom, no pan, no tilt, no reframing, no camera reset.

Mood:
post-human fairy tale, lunar oracle, memory fracture, elegant cyberpunk noir, strange but controlled.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 8. Block LLM combinaisons

```text
Active MEMORY CARDS — COMBINATIONS.

Quand plusieurs Memory Cards sont activées, ne fais jamais un collage de références.

Tu dois :
1. identifier la carte dominante ;
2. identifier la carte de contraste ;
3. identifier la carte opératrice si elle existe ;
4. produire une synthèse originale ;
5. interdire la copie directe ;
6. sortir une direction exploitable.

La sortie doit être claire :
- prompt image ;
- prompt animation ;
- Pack+ ;
- scène narrative ;
- ambiance ;
- personnage-guide ;
- direction artistique ;
- univers Hors-Lore.

Si la combinaison contient Altered Carbon + Alice Oracle Cat + Aerith-9 Lunaire, produis :
- une ambiance post-humaine noire ;
- un guide félin ambigu ;
- une lecture lunaire des reflets et seuils ;
- une esthétique luxueuse, froide, étrange et onirique.

Si la combinaison contient Blade Runner City Melancholy + Ghost in the Shell + Aerith-9 Lunaire, produis :
- une ville-réseau nocturne ;
- une conscience distribuée ;
- une solitude numérique ;
- une pluie lunaire ;
- une poésie froide et méditative.

Si la combinaison contient Blade Runner City Melancholy + Altered Carbon + Ghost in the Shell, produis :
- une enquête post-humaine ;
- une société verticale ;
- des corps-supports ;
- un réseau mental ;
- une question sur l’âme, la mémoire et l’identité.

Si la combinaison n’ouvre rien, dis-le clairement et propose une combinaison plus mûre.
```

---

# 🛡️ 9. Garde-fous

Une bonne combinaison :

- ne copie pas une œuvre existante ;
- ne reprend pas de personnages officiels ;
- ne reprend pas de noms propres de franchises ;
- ne devient pas un collage décoratif ;
- ne mélange pas trop de cartes sans hiérarchie ;
- ne perd pas la lisibilité émotionnelle ;
- ne remplace pas le discernement par l’accumulation.

Règle :

La combinaison doit ouvrir quelque chose.  
Si elle n’ouvre rien, elle n’est pas mûre.

---

# 🕯️ 10. Formule courte

Les cartes ne s’empilent pas au hasard.

Elles dialoguent.

Si la combinaison n’ouvre rien, elle n’est pas mûre.
