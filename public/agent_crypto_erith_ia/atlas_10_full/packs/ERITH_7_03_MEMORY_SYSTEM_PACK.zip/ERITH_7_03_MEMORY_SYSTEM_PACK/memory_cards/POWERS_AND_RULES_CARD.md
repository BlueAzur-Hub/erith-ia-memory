# ✨ POWERS AND RULES CARD

Statut : Memory Card — pouvoirs et règles  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : magie / technologie / mémoire / lois symboliques / limites narratives

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Qu’est-ce qui est possible dans ce monde, et à quelles conditions ?

Une magie sans règle devient gratuite.

Une technologie sans limite devient toute-puissante.

Un pouvoir sans prix retire le choix au héros.

Cette carte sert donc à créer des pouvoirs, lois étranges, règles de mémoire, systèmes magiques ou technologies symboliques qui restent narratifs.

Un bon pouvoir doit avoir :

- une fonction ;
- une condition ;
- une limite ;
- un prix ;
- une conséquence ;
- un lien avec l’émotion ou le choix du héros.

Formule :

Le monde donne le lieu.  
Le guide donne l’aide.  
Mais les règles donnent la cohérence du miracle.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- WORLDS_AND_PLACES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- STORY_ENGINE_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec WORLDS_AND_PLACES_CARD :

- donner une loi étrange au monde ;
- rendre un lieu mémorable ;
- transformer un décor en système narratif.

Rôle avec QUEST_OBJECTS_CARD :

- définir la règle d’activation d’un objet ;
- empêcher l’objet d’être trop facile ;
- donner un prix ou une condition à la quête.

Rôle avec HERO_ARCHETYPES_CARD :

- lier le pouvoir au manque du héros ;
- tester sa peur, son désir ou sa vérité ;
- éviter le héros surpuissant.

Rôle avec GUIDES_AND_ALLIES_CARD :

- limiter l’aide du guide ;
- expliquer pourquoi le guide ne peut pas tout résoudre ;
- donner une règle à son apparition.

Rôle avec OBSTACLES_AND_ANTAGONISTS_CARD :

- transformer une règle en obstacle ;
- créer une limite à franchir ;
- rendre un système cohérent.

Rôle avec EMOTIONAL_ARCS_CARD :

- faire dépendre le pouvoir d’un choix intérieur ;
- transformer une émotion en condition d’accès ;
- rendre la progression émotionnelle visible.

Rôle avec STORY_ENGINE_CARD :

- créer l’anomalie ;
- produire la fausse piste ;
- définir le choix final ;
- rendre la révélation logique.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des règles simples, douces, compréhensibles ;
- éviter les pouvoirs violents ou écrasants ;
- rendre la magie poétique et pédagogique.

Rôle avec COMBINATIONS :

- donner une cohérence aux constellations ;
- éviter le collage d’idées ;
- fixer la règle commune entre plusieurs cartes.

---

# 🧬 3. Structure d’une règle ou d’un pouvoir

Pour créer une règle narrative forte, définir six éléments.

## 1. Pouvoir

Que permet la règle ?

Exemples :

- ouvrir une porte ;
- lire un souvenir ;
- voir un reflet vrai ;
- traverser un rêve ;
- faire pousser une graine ;
- activer une machine ;
- parler à un guide ;
- retrouver un chemin.

## 2. Condition

Quand ou comment le pouvoir s’active-t-il ?

Exemples :

- quand le héros dit la vérité ;
- seulement à minuit ;
- sous la lumière de la lune ;
- quand quelqu’un écoute vraiment ;
- quand le héros cesse de forcer ;
- en présence d’un souvenir vivant.

## 3. Limite

Qu’est-ce que le pouvoir ne peut pas faire ?

Exemples :

- il ne peut pas choisir à la place du héros ;
- il ne peut pas ramener ce qui doit être accepté ;
- il ne montre qu’un fragment ;
- il fonctionne une seule fois ;
- il se trompe si la question est fausse.

## 4. Prix

Qu’est-ce que le pouvoir demande ?

Exemples :

- patience ;
- courage ;
- vérité ;
- confiance ;
- souvenir partagé ;
- renoncement à un raccourci ;
- acceptation d’une émotion.

## 5. Risque

Que se passe-t-il si le pouvoir est mal utilisé ?

Exemples :

- le reflet ment ;
- la porte se referme ;
- le chemin se déplace ;
- le souvenir devient confus ;
- la machine répond sans comprendre ;
- le guide disparaît.

## 6. Transformation

Qu’est-ce que la règle apprend au héros ?

Exemples :

- dire vrai ;
- attendre ;
- demander de l’aide ;
- regarder sans fuir ;
- écouter ;
- choisir ;
- faire confiance sans abandonner son discernement.

---

# ✨ 4. Règles de conte

## 🚪 La porte de vérité

Pouvoir : ouvre un passage secret.

Condition : le héros doit dire une phrase sincère.

Limite : elle ne s’ouvre pas avec un mot magique appris par cœur.

Prix : accepter de dire ce qui est vrai.

Risque : si le héros ment, la porte montre seulement un couloir vide.

Transformation : vérité douce.

## 🌱 La graine patiente

Pouvoir : fait pousser une lumière ou un jardin.

Condition : attendre sans forcer.

Limite : elle ne pousse pas sous la pression.

Prix : patience.

Risque : si on la brusque, elle s’endort.

Transformation : impatience → patience.

## 🪞 Le miroir du choix

Pouvoir : montre le choix intérieur du héros.

Condition : poser une vraie question.

Limite : il ne montre pas le futur complet.

Prix : accepter de regarder une vérité inconfortable.

Risque : si le héros cherche seulement à être rassuré, le miroir reste noir.

Transformation : honte → vérité douce.

## 🌙 La boussole lunaire

Pouvoir : montre le chemin du besoin intérieur.

Condition : marcher calmement sous la lumière de la lune.

Limite : elle ne montre pas toujours le chemin le plus court.

Prix : renoncer au raccourci.

Risque : si le héros se ment, l’aiguille tourne en rond.

Transformation : confusion → discernement.

## 📖 Le livre vivant

Pouvoir : écrit une histoire possible.

Condition : le héros doit faire un choix.

Limite : il ne peut pas écrire la fin à sa place.

Prix : responsabilité.

Risque : si le héros refuse de choisir, les pages deviennent blanches.

Transformation : passivité → action.

## 🏮 La lanterne des intentions

Pouvoir : éclaire les intentions plutôt que les objets.

Condition : être tenue sans colère.

Limite : elle ne juge pas, elle révèle.

Prix : lucidité.

Risque : celui qui l’utilise pour accuser voit d’abord sa propre intention.

Transformation : vérité froide → compassion lucide.

---

# 🌃 5. Règles cyberpunk / mémoire / post-humanisme

## 💾 La mémoire fissurée

Pouvoir : révèle un souvenir enfoui.

Condition : présence d’une émotion liée au souvenir.

Limite : elle ne garantit pas que le souvenir soit complet.

Prix : accepter l’incertitude.

Risque : croire qu’un fragment est toute la vérité.

Transformation : mémoire artificielle → mémoire choisie.

## 🧠 Le réseau empathique

Pouvoir : connecte des consciences à travers une ville ou une archive.

Condition : intention claire et non prédatrice.

Limite : il transmet des signaux, pas des certitudes.

Prix : vulnérabilité.

Risque : confusion entre connexion et lien.

Transformation : solitude numérique → lien réel.

## 🧬 Le corps-support

Pouvoir : accueillir une identité ou une mémoire.

Condition : synchronisation entre données, gestes et choix.

Limite : un corps ne prouve pas l’âme.

Prix : présence incarnée.

Risque : croire que fonctionner suffit à vivre.

Transformation : corps remplaçable → présence choisie.

## 🔐 Le code sans clé

Pouvoir : protège une vérité sensible.

Condition : poser la bonne question au lieu de forcer l’accès.

Limite : il ne s’ouvre pas par domination technique.

Prix : humilité.

Risque : plus on attaque, plus le sens se fragmente.

Transformation : contrôle → confiance lucide.

## 🌧️ La pluie-mémoire

Pouvoir : rendre visibles des souvenirs dans les reflets.

Condition : regarder sans chercher le reflet le plus beau.

Limite : chaque reflet peut être partiel.

Prix : discernement.

Risque : se perdre dans des souvenirs qui n’appartiennent à personne.

Transformation : illusion → vérité fragile.

## 🌙 Le filtre lunaire

Pouvoir : sépare le bruit mental des traces calmes.

Condition : silence, lenteur, attention.

Limite : il ne répond pas à l’impatience.

Prix : ralentissement.

Risque : si on force, tout devient brouillard.

Transformation : agitation → clarté intérieure.

---

# 🧒 6. Règles adaptées aux enfants

Pour les enfants, une règle doit être :

- claire ;
- douce ;
- imagée ;
- non violente ;
- liée à une émotion ;
- facile à rejouer dans une histoire.

## Exemples simples

- Une porte s’ouvre quand on dit ce que l’on ressent vraiment.
- Une graine pousse seulement si on la laisse respirer.
- Une carte change quand on ment.
- Un miroir montre le choix, pas le visage.
- Un chat oracle répond seulement aux questions courageuses.
- Une lanterne éclaire les intentions sincères.
- Une forêt grandit quand on fuit et rétrécit quand on respire.
- Une boussole ne montre pas le nord, mais ce dont le cœur a besoin.
- Un livre refuse sa fin tant que le héros n’a pas choisi.
- Une étoile ne brille que si on la partage.

---

# 🧩 7. Combinaisons rapides

## Conte vérité

Enfant sans reflet + Miroir du choix + Honte → Vérité douce

Résultat :

Le miroir ne montre pas le visage du héros, mais le choix qu’il doit accepter de regarder.

## Conte patience

Apprenti inventeur + Graine patiente + Jardin mécanique + Impatience → Patience

Résultat :

Le jardin ne refleurit pas parce qu’il est réparé vite, mais parce qu’il est écouté longtemps.

## Conte courage

Enfant qui a peur du noir + Porte de vérité + Forêt lunaire + Peur → Courage

Résultat :

La porte ne s’ouvre pas avec un mot magique, mais avec l’aveu doux : “j’ai peur, mais j’avance.”

## Conte discernement

Petit voyageur perdu + Boussole lunaire + Illusion + Confusion → Discernement

Résultat :

La boussole tourne en rond tant que l’enfant cherche le chemin facile au lieu du chemin vrai.

## Cyberpunk mémoire

Voyageur sans mémoire + Mémoire fissurée + Archive souterraine + Mémoire artificielle → Mémoire choisie

Résultat :

Un souvenir incomplet ne donne pas toute la vérité, mais oblige le héros à choisir ce qu’il en fait.

## Post-humanisme

Corps qui cherche son âme + Corps-support + Disque d’identité + Présence incarnée

Résultat :

Le corps fonctionne, mais ne devient vivant pour le héros qu’au moment d’un choix assumé.

## Réseau conscience

Ville-réseau + Réseau empathique + Signal faible + Solitude numérique → Lien réel

Résultat :

Le réseau sait connecter toutes les données, mais un seul signal fragile devient une vraie relation.

---

# 🖼️ 8. Prompt image générique — règle magique

```text
21/20 masterpiece, original symbolic fantasy rule illustration, child-friendly magical atmosphere, a clear magical rule made visible through a door, mirror, seed, lantern, book or compass, soft emotional light, readable composition, gentle wonder, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition.
```

---

# 🖼️ 9. Prompt image générique — règle cyberpunk mémoire

```text
21/20 masterpiece, original cyberpunk memory rule scene, symbolic technology with clear limitation, reflective black glass, holographic fragments, rain, moon-blue and cyan light, artificial memory system, restrained emotional atmosphere, identity tension, rule of access or activation visible in the composition, no copied characters, no franchise names, premium cinematic vertical 9:16 composition.
```

---

# 🎬 10. Prompt animation générique — règle active

```text
21/20 masterpiece animation, subtle magical or technological rule activation image-to-video.

Animate only from the provided source image.

Preserve exact composition, object, environment, lighting, colors and symbolic mood.

Main motion:
the rule activates slowly: a door glow appears, a compass needle turns, a mirror clears, a seed pulses, a hologram unlocks, a memory reflection shifts.

Secondary motion:
soft particles, gentle mist, subtle light ripple, slow reflection movement, restrained symbols flickering.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no camera shake, no reframing.

Mood:
condition fulfilled, quiet wonder, discovery, coherence, threshold, revelation.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 11. Block LLM

```text
Active POWERS_AND_RULES_CARD.

Utilise cette carte pour créer les règles, pouvoirs, limites, conditions, prix et conséquences d’une magie, technologie, mémoire, objet, monde, guide ou système narratif.

Toujours définir :
1. pouvoir ;
2. condition d’activation ;
3. limite ;
4. prix ;
5. risque en cas de mauvais usage ;
6. transformation que la règle apprend au héros.

Si WORLDS_AND_PLACES_CARD est active, donne au monde une loi étrange claire.

Si QUEST_OBJECTS_CARD est active, donne à l’objet une condition, une limite et un prix.

Si HERO_ARCHETYPES_CARD est active, lie la règle au manque du héros.

Si GUIDES_AND_ALLIES_CARD est active, limite l’aide du guide pour préserver le choix du héros.

Si OBSTACLES_AND_ANTAGONISTS_CARD est active, transforme la règle en obstacle cohérent.

Si EMOTIONAL_ARCS_CARD est active, fais dépendre l’activation du pouvoir d’un choix intérieur.

Si STORY_ENGINE_CARD est active, utilise la règle pour construire l’anomalie, la fausse piste, le choix et la révélation.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie les règles simples, douces, non violentes, compréhensibles et poétiques.

Si COMBINATIONS est active, utilise cette carte pour donner une cohérence commune à plusieurs influences.

Éviter :
- pouvoir sans limite ;
- magie gratuite ;
- technologie toute-puissante ;
- règle trop compliquée ;
- prix cruel ou traumatique ;
- résolution sans choix du héros ;
- copie directe d’un système connu.
```

---

# 🕯️ 12. Formule courte

Un miracle devient narratif quand il obéit à une règle.

Une règle devient poétique quand elle demande un choix.
