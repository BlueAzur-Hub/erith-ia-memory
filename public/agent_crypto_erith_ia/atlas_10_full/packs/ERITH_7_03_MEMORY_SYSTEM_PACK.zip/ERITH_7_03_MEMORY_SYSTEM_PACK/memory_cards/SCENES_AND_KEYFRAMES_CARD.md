# 🎞️ SCENES AND KEYFRAMES CARD

Statut : Memory Card — scènes et keyframes  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : image / animation / plans clés / production visuelle / storyboard narratif

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Quel instant mérite de devenir une image ?

Une histoire complète peut contenir beaucoup de choses :

- un héros ;
- un monde ;
- un guide ;
- un objet ;
- un obstacle ;
- une émotion ;
- une règle ;
- une transformation.

Mais une image ne doit pas tout raconter.

Une image doit choisir.

Elle doit capturer le moment où l’histoire devient visible.

Cette carte sert donc à transformer une structure narrative en :

- image master ;
- keyframe ;
- scène de couverture ;
- prompt image ;
- prompt animation ;
- plan I2V ;
- séquence DaVinci ;
- moment 21/20.

Formule :

Le Story Engine construit l’histoire.  
La Keyframe Card choisit l’instant qui mérite de devenir image.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- STORY_ENGINE_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec STORY_ENGINE_CARD :

- choisir un moment précis dans la structure ;
- éviter de mettre tout le récit dans une seule image ;
- transformer une étape narrative en plan fort.

Rôle avec WORLDS_AND_PLACES_CARD :

- poser une image d’ouverture ;
- montrer le monde comme personnage ;
- rendre visible la loi étrange du lieu.

Rôle avec HERO_ARCHETYPES_CARD :

- choisir une posture claire du héros ;
- montrer son manque, son désir ou son choix ;
- éviter le portrait générique.

Rôle avec QUEST_OBJECTS_CARD :

- choisir le moment où l’objet apparaît, s’active ou se transforme ;
- rendre l’objet lisible dans l’image ;
- donner au symbole une fonction visuelle.

Rôle avec GUIDES_AND_ALLIES_CARD :

- choisir l’apparition du guide ;
- montrer la relation héros-guide ;
- éviter que le guide vole la scène au héros.

Rôle avec OBSTACLES_AND_ANTAGONISTS_CARD :

- créer un face-à-face visuel ;
- montrer la tension sans forcément montrer la violence ;
- rendre l’épreuve lisible.

Rôle avec EMOTIONAL_ARCS_CARD :

- choisir l’instant de bascule intérieure ;
- montrer une émotion par la lumière, le geste ou le décor ;
- éviter l’expression forcée.

Rôle avec POWERS_AND_RULES_CARD :

- montrer l’activation d’une règle ;
- rendre visible une condition remplie ;
- faire comprendre le miracle sans explication.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des images douces, lisibles, non traumatiques ;
- choisir des moments merveilleux et émotionnels ;
- faciliter les ateliers de conte.

Rôle avec COMBINATIONS :

- choisir l’image qui incarne le mieux la constellation ;
- éviter l’accumulation ;
- trouver le symbole central.

---

# 🧬 3. Structure d’une keyframe forte

Pour créer une image forte, définir sept éléments.

## 1. Étape narrative

Quel moment de l’histoire est choisi ?

Exemples :

- ouverture ;
- anomalie ;
- apparition du guide ;
- découverte de l’objet ;
- passage du seuil ;
- face-à-face avec l’obstacle ;
- choix intérieur ;
- révélation ;
- retour transformé.

## 2. Sujet principal

Qui ou quoi doit dominer l’image ?

Exemples :

- héros ;
- guide ;
- objet ;
- monde ;
- obstacle ;
- reflet ;
- porte ;
- mémoire ;
- lumière.

## 3. Symbole central

Quel élément rend l’image mémorable ?

Exemples :

- flaque-miroir ;
- porte lumineuse ;
- clé sans serrure ;
- chat oracle ;
- graine brillante ;
- boussole lunaire ;
- miroir noir ;
- carte mémoire fissurée.

## 4. Émotion visible

Quelle émotion doit être lisible ?

Exemples :

- peur douce ;
- émerveillement ;
- solitude ;
- courage ;
- curiosité ;
- vérité ;
- patience ;
- mélancolie.

## 5. Composition

Comment organiser la scène ?

Exemples :

- silhouette centrale ;
- guide en contrepoint ;
- objet au premier plan ;
- monde immense derrière ;
- seuil lumineux ;
- reflet en bas ;
- diagonale de chemin ;
- cercle protecteur.

## 6. Mouvement possible

Quel micro-mouvement peut devenir animation ?

Exemples :

- lumière qui pulse ;
- pluie qui tombe ;
- reflet qui change ;
- page qui tourne ;
- porte qui s’entrouvre ;
- guide qui cligne des yeux ;
- boussole qui tourne ;
- étoile qui scintille.

## 7. Sortie production

Quelle sortie veut-on ?

Exemples :

- image fixe master ;
- image de couverture ;
- prompt image ;
- prompt animation ;
- keyframe Wan I2V ;
- last frame pour enchaînement ;
- plan DaVinci.

---

# 🎞️ 4. Types de scènes clés

## 🌟 Image d’ouverture

Fonction : présenter le monde et l’ambiance.

À montrer :

- le lieu ;
- la loi étrange ;
- l’échelle ;
- la couleur émotionnelle.

À éviter :

- trop d’action ;
- trop de personnages ;
- tout le résumé de l’histoire.

Idéal pour : couverture, introduction vidéo, image de carte.

## ❓ Anomalie

Fonction : montrer que quelque chose ne va pas.

À montrer :

- une porte apparue ;
- un reflet impossible ;
- une lumière étrange ;
- un objet qui réagit ;
- un monde qui déraille doucement.

Idéal pour : hook visuel, teaser, première image narrative.

## 🐾 Apparition du guide

Fonction : créer la rencontre.

À montrer :

- héros surpris ;
- guide calme ;
- distance symbolique ;
- lumière douce ;
- seuil ou passage.

À éviter :

- guide trop dominant ;
- héros passif ou invisible.

## 🗝️ Découverte de l’objet

Fonction : lancer la quête.

À montrer :

- objet au centre ;
- main qui hésite ;
- lueur subtile ;
- décor qui réagit ;
- règle étrange suggérée.

Idéal pour : prompt image + animation courte.

## 🚪 Passage du seuil

Fonction : montrer le moment où le héros entre dans l’aventure.

À montrer :

- porte ;
- pont ;
- miroir ;
- forêt ;
- train ;
- lumière différente de l’autre côté.

Idéal pour : image 21/20, moment de bascule, plan fort.

## 🐉 Face-à-face avec l’obstacle

Fonction : montrer l’épreuve.

À montrer :

- tension ;
- distance ;
- obstacle lisible ;
- héros petit mais présent ;
- possibilité de résolution non violente.

À éviter :

- violence graphique ;
- combat gratuit ;
- antagoniste plat.

## 💛 Choix intérieur

Fonction : montrer ce qui change dans le héros.

À montrer :

- geste simple ;
- regard ;
- main tendue ;
- respiration ;
- objet reposé ;
- reflet accepté.

Idéal pour : image émotionnelle, scène poétique, fin de court récit.

## ✨ Révélation

Fonction : rendre visible la vérité.

À montrer :

- lumière nouvelle ;
- reflet clair ;
- objet transformé ;
- monde qui répond ;
- guide qui s’efface.

Idéal pour : image master, keyframe finale, last frame.

## 🌙 Retour transformé

Fonction : montrer que quelque chose a changé.

À montrer :

- même lieu, lumière différente ;
- héros plus calme ;
- objet devenu simple ;
- guide absent ou discret ;
- monde apaisé.

Idéal pour : image finale, montage DaVinci, fin de conte.

---

# 🧒 5. Keyframes douces pour contes enfants

## Le premier seuil

Image : un enfant devant une porte qui brille doucement.

Mouvement : la lumière de la porte pulse lentement.

Émotion : curiosité, petite peur, courage.

## La rencontre du guide

Image : un chat oracle assis sur un rebord, l’enfant en contrebas.

Mouvement : yeux du chat, pluie légère, queue presque immobile.

Émotion : mystère rassurant.

## L’objet qui appelle

Image : une clé, une graine ou une boussole au creux d’une main.

Mouvement : l’objet s’allume très doucement.

Émotion : invitation.

## La peur apprivoisée

Image : l’enfant et le loup dans une forêt bleue.

Mouvement : respiration, feuilles, lumière lunaire.

Émotion : courage doux.

## La vérité dans le miroir

Image : un miroir noir qui commence à révéler une lumière.

Mouvement : reflet qui se stabilise.

Émotion : vérité douce.

## Le retour apaisé

Image : le héros revient dans le même lieu, mais le monde est plus clair.

Mouvement : lumière chaude, particules lentes.

Émotion : transformation, paix.

---

# 🌃 6. Keyframes cyberpunk / mémoire / post-humanisme

## La ville comme personnage

Image : silhouette seule face à une mégacité pluvieuse.

Mouvement : pluie, néons, vapeur.

Émotion : mélancolie.

## La flaque-archive

Image : grande flaque centrale reflétant une mémoire impossible.

Mouvement : reflet qui change lentement.

Émotion : doute, vérité fragile.

## L’activation mémoire

Image : carte mémoire fissurée sur verre noir, hologrammes autour.

Mouvement : fragments qui s’alignent.

Émotion : tension, révélation.

## Le corps-support dormant

Image : silhouette devant un corps artificiel ou une capsule sombre.

Mouvement : lumière interne très lente.

Émotion : identité, présence, vertige.

## Le signal faible

Image : personnage dans un réseau immense, suivant une petite lumière.

Mouvement : signal qui pulse doucement.

Émotion : solitude numérique → lien réel.

## Le choix incarné

Image : main humaine posée sur une interface froide.

Mouvement : interface qui répond lentement à la chaleur ou au geste.

Émotion : compassion lucide.

---

# 🧩 7. Combinaisons rapides

## Conte ouverture

Forêt lunaire + Enfant qui a peur du noir + Loup protecteur

Keyframe : l’enfant aperçoit deux yeux doux entre les arbres bleus.

Animation : les feuilles bougent, les yeux clignent lentement, la lune pulse.

## Conte objet

Jardin mécanique + Graine de lumière + Apprenti inventeur

Keyframe : l’enfant tient la graine devant une fleur mécanique fermée.

Animation : la graine pulse, un engrenage tourne très lentement.

## Conte vérité

Palais des miroirs + Enfant sans reflet + Miroir du choix

Keyframe : l’enfant pose la main sur un miroir noir qui commence à s’éclaircir.

Animation : le reflet apparaît par vagues.

## Cyberpunk mémoire

Mégacité des reflets + Enquêteur mélancolique + Flaque-archive

Keyframe : silhouette de dos devant une flaque qui reflète une autre époque.

Animation : pluie, reflet instable, néons qui ondulent.

## Post-humanisme

Tour des corps-supports + Corps qui cherche son âme + Disque d’identité

Keyframe : personnage immobile devant plusieurs corps dormants, un disque noir à la main.

Animation : lumière froide, respiration subtile, disque qui change de couleur.

## Réseau conscience

Ville-réseau + Signal faible + Solitude numérique

Keyframe : minuscule silhouette dans une architecture de données immense.

Animation : flux de données lents, signal faible qui pulse.

---

# 🖼️ 8. Prompt image générique — keyframe narrative

```text
21/20 masterpiece, original narrative keyframe illustration, one clear story moment only, strong readable composition, central symbolic subject, emotional clarity, cinematic lighting, clear foreground midground background, no clutter, no copied characters, no franchise names, premium concept art, vertical 9:16 composition, designed as a master still image for animation.
```

---

# 🖼️ 9. Prompt image générique — conte enfant keyframe

```text
21/20 masterpiece, original children storybook keyframe, one magical story moment only, gentle emotional atmosphere, readable child-friendly composition, young hero, guide or symbolic object, soft light, wonder, courage, tenderness, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition.
```

---

# 🖼️ 10. Prompt image générique — cyberpunk keyframe

```text
21/20 masterpiece, original cyberpunk noir narrative keyframe, one precise story moment only, rain, reflective surfaces, artificial memory symbols, lonely silhouette, holographic fragments, deep blue and cyan light, emotional restraint, identity tension, city or archive as character, no copied characters, no franchise names, no action clutter, premium cinematic vertical 9:16 composition, designed as a master still for I2V animation.
```

---

# 🎬 11. Prompt animation générique — keyframe to video

```text
21/20 masterpiece animation, cinematic keyframe image-to-video.

Animate only from the provided source image.

Preserve the exact composition, subject placement, character design, object design, world geometry, lighting, color palette and emotional mood.

Main motion:
keep the main subject almost still, with only subtle breathing, tiny hand movement, slow eye glow, slight fabric or hair movement if relevant.

Secondary motion:
soft particles, rain, mist, reflections, gentle light pulses, holographic fragments, slow environmental movement.

Camera:
locked camera or extremely slow cinematic push-in only, no pan, no tilt, no zoom out, no camera shake, no reframing, no camera reset.

Rule:
one animation equals one living moment.
Do not try to animate the whole story.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 12. Block LLM

```text
Active SCENES_AND_KEYFRAMES_CARD.

Utilise cette carte pour transformer une histoire, une Memory Card, une combinaison ou un Story Engine en image forte, keyframe, prompt image ou prompt animation.

Toujours définir :
1. étape narrative choisie ;
2. sujet principal ;
3. symbole central ;
4. émotion visible ;
5. composition ;
6. mouvement possible ;
7. sortie production attendue.

Si STORY_ENGINE_CARD est active, choisis une seule étape narrative : ouverture, anomalie, apparition du guide, découverte de l’objet, passage du seuil, obstacle, choix intérieur, révélation ou retour transformé.

Si WORLDS_AND_PLACES_CARD est active, montre le monde comme personnage ou règle vivante.

Si HERO_ARCHETYPES_CARD est active, donne au héros une posture lisible qui montre son désir, sa peur ou son choix.

Si QUEST_OBJECTS_CARD est active, rends l’objet immédiatement lisible et narratif.

Si GUIDES_AND_ALLIES_CARD est active, montre la relation guide-héros sans voler le choix du héros.

Si OBSTACLES_AND_ANTAGONISTS_CARD est active, montre la tension sans violence gratuite.

Si EMOTIONAL_ARCS_CARD est active, choisis le moment où l’émotion bascule.

Si POWERS_AND_RULES_CARD est active, montre l’activation ou la conséquence d’une règle claire.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie les images douces, lisibles, merveilleuses, non traumatiques.

Si COMBINATIONS est active, choisis le symbole central qui incarne la constellation.

Règles production :
- une image = un moment ;
- une animation = un micro-mouvement ;
- ne pas raconter toute l’histoire dans une seule image ;
- verrouiller une image master avant animation ;
- préserver la composition en I2V ;
- privilégier caméra fixe ou push-in très lent.

Éviter :
- scène trop chargée ;
- trop de personnages ;
- action confuse ;
- tout le récit dans un seul plan ;
- animation trop ambitieuse ;
- caméra instable ;
- texte, logo, watermark ;
- personnages copiés ;
- franchise names.
```

---

# 🕯️ 13. Formule courte

Une histoire contient mille images possibles.

Une keyframe choisit celle qui garde le cœur du récit.
