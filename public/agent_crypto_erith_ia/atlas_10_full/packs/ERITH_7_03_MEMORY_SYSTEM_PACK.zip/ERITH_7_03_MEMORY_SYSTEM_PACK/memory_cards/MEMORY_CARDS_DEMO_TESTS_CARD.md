# 🧪 MEMORY CARDS DEMO TESTS CARD

Statut : Memory Card — tests de démonstration  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : validation / stress tests / exemples / preuves de composition / production guidée

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Est-ce que le système Memory Cards fonctionne vraiment en situation réelle ?

Le système existe.  
Les cartes composent ensemble.  
L’Orchestrator choisit les routes.  
L’Atlas montre l’architecture.  
Le Pack+ assemble.  
Quality Control valide.  
Export livre.

Mais un système créatif doit être testé avec des cas concrets.

Cette carte sert donc à créer des tests de démonstration pour vérifier :

- la composition entre cartes ;
- la cohérence narrative ;
- la qualité des images ;
- la stabilité animation ;
- la narration ;
- le sound design ;
- le Pack+ ;
- l’export Notion / GitHub / production ;
- la capacité du système à aider enfants, créateurs, LLM et workflows vidéo.

Formule :

Le système existe.  
Les tests prouvent qu’il respire.

---

# 🔗 2. Cartes liées

Cette carte teste principalement :

- MEMORY_CARDS_ORCHESTRATOR_CARD.md ;
- MEMORY_CARDS_ATLAS_CARD.md ;
- COMBINATIONS.md ;
- STORY_ENGINE_CARD.md ;
- PACK_PLUS_BUILDER_CARD.md ;
- QUALITY_CONTROL_CARD.md ;
- EXPORT_AND_DELIVERY_CARD.md.

Elle peut aussi tester toutes les cartes narratives et production :

- CHILDREN_STORY_THEMES_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- SCENES_AND_KEYFRAMES_CARD.md ;
- VISUAL_STYLE_DNA_CARD.md ;
- MOTION_AND_CAMERA_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md.

---

# 🧭 3. Règle de test

Un bon test doit vérifier une fonction précise.

Ne pas tout tester en même temps.

Chaque démonstration doit répondre à quatre questions :

1. Quelle est la demande ?
2. Quelles cartes sont activées ?
3. Quelle sortie est produite ?
4. Comment sait-on que c’est réussi ?

---

# 🧪 4. Tests principaux

## Test 1 — Conte enfant complet

Objectif : vérifier que le système peut créer un conte doux, lisible, émotionnel et non traumatique.

Cartes à activer :

- MEMORY_CARDS_ORCHESTRATOR_CARD ;
- CHILDREN_STORY_THEMES_CARD ;
- HERO_ARCHETYPES_CARD ;
- GUIDES_AND_ALLIES_CARD ;
- QUEST_OBJECTS_CARD ;
- EMOTIONAL_ARCS_CARD ;
- STORY_ENGINE_CARD ;
- QUALITY_CONTROL_CARD.

Demande test :

Créer un conte enfant avec un chat oracle, une flaque-miroir et un enfant qui apprend à ne plus fuir sa peur.

Sortie attendue :

- titre ;
- héros ;
- guide ;
- objet ou lieu magique ;
- obstacle doux ;
- arc émotionnel ;
- conte court ;
- morale légère.

Critères de réussite :

- récit compréhensible ;
- pas de peur traumatique ;
- héros actif ;
- guide utile mais non dominant ;
- transformation claire ;
- fin douce.

---

## Test 2 — Couverture Memory Card

Objectif : vérifier la capacité à créer une image de couverture lisible, premium et cohérente.

Cartes à activer :

- MEMORY_CARDS_ORCHESTRATOR_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- PACK_PLUS_BUILDER_CARD ;
- QUALITY_CONTROL_CARD ;
- EXPORT_AND_DELIVERY_CARD.

Demande test :

Créer une couverture pour une Memory Card sous forme d’artefact mémoire transparent, avec symbole central clair et fond propre.

Sortie attendue :

- concept visuel ;
- Style DNA ;
- keyframe ;
- prompt image ;
- note transparence / fond ;
- nom fichier recommandé ;
- chemin GitHub recommandé ;
- commit recommandé.

Critères de réussite :

- symbole central lisible ;
- pas de logo parasite ;
- pas de faux damier ;
- fond propre ou transparence réelle si demandée ;
- image utilisable comme couverture.

---

## Test 3 — Image master cyberpunk mémoire

Objectif : vérifier que le système peut produire une image cyberpunk originale, non générique, avec vraie question humaine.

Cartes à activer :

- MEMORY_CARDS_ORCHESTRATOR_CARD ;
- WORLDS_AND_PLACES_CARD ;
- QUEST_OBJECTS_CARD ;
- EMOTIONAL_ARCS_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- QUALITY_CONTROL_CARD.

Demande test :

Créer une image master d’une mégacité de pluie où une carte mémoire fissurée révèle un souvenir incomplet.

Sortie attendue :

- concept ;
- monde ;
- objet mémoire ;
- émotion ;
- Style DNA ;
- keyframe ;
- prompt image.

Critères de réussite :

- pluie et néons servent le sens ;
- mémoire au centre de l’image ;
- pas de cyberpunk décoratif vide ;
- silhouette ou objet lisible ;
- scène originale sans copie de franchise.

---

## Test 4 — Pack+ complet

Objectif : vérifier que toutes les cartes peuvent s’assembler en unité de production complète.

Cartes à activer :

- MEMORY_CARDS_ORCHESTRATOR_CARD ;
- COMBINATIONS ;
- STORY_ENGINE_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- MOTION_AND_CAMERA_CARD ;
- NARRATION_AND_DIALOGUE_CARD ;
- SOUND_AND_MUSIC_DESIGN_CARD ;
- PACK_PLUS_BUILDER_CARD ;
- QUALITY_CONTROL_CARD ;
- EXPORT_AND_DELIVERY_CARD.

Demande test :

Créer un Pack+ complet pour une scène intitulée “La flaque qui se souvenait trop”.

Sortie attendue :

1. Concept ;
2. Cartes actives ;
3. Synthèse ;
4. Monde ;
5. Héros ;
6. Guide ou objet ;
7. Obstacle ;
8. Arc émotionnel ;
9. Règle ;
10. Keyframe ;
11. Style DNA ;
12. Prompt image ;
13. Motion / Camera ;
14. Prompt animation ;
15. Narration ;
16. Sound design ;
17. Quality check ;
18. Export.

Critères de réussite :

- sortie directement exploitable ;
- pas de collage ;
- image générable ;
- animation stable ;
- narration respirable ;
- son cohérent ;
- livraison claire.

---

## Test 5 — Animation Wan / I2V

Objectif : vérifier que le système sait transformer une image en animation stable.

Cartes à activer :

- MEMORY_CARDS_ORCHESTRATOR_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- MOTION_AND_CAMERA_CARD ;
- SOUND_AND_MUSIC_DESIGN_CARD si son demandé ;
- QUALITY_CONTROL_CARD ;
- EXPORT_AND_DELIVERY_CARD.

Demande test :

Transformer une image fixe de carte mémoire lumineuse en animation Wan/I2V de cinq secondes, avec caméra stable et last frame exploitable.

Sortie attendue :

- mouvement principal ;
- mouvements secondaires ;
- caméra ;
- prompt animation ;
- last frame strategy ;
- note DaVinci.

Critères de réussite :

- un seul mouvement principal ;
- caméra fixe ou push-in lent ;
- composition préservée ;
- pas de reframing ;
- last frame utilisable.

---

## Test 6 — Livraison Notion / GitHub

Objectif : vérifier que le système sait livrer proprement une sortie.

Cartes à activer :

- QUALITY_CONTROL_CARD ;
- EXPORT_AND_DELIVERY_CARD.

Demande test :

Préparer la livraison d’une nouvelle Memory Card vers Notion et GitHub.

Sortie attendue :

- résumé Notion ;
- nom fichier ;
- chemin GitHub ;
- commit recommandé ;
- statut ;
- prochaine action.

Critères de réussite :

- texte Notion propre ;
- pas de gros bloc code inutile ;
- chemin clair ;
- commit en anglais ;
- action suivante unique.

---

## Test 7 — Quality Control final

Objectif : vérifier que le système peut dire non, resserrer ou corriger.

Cartes à activer :

- QUALITY_CONTROL_CARD ;
- carte concernée selon le problème.

Demande test :

Évaluer un prompt image trop chargé et le rendre plus propre.

Sortie attendue :

- verdict ;
- points forts ;
- problèmes ;
- corrections ;
- version resserrée ;
- score si utile.

Critères de réussite :

- critique concrète ;
- pas de surcorrection ;
- prompt plus générable ;
- structure plus lisible ;
- pas de bavardage inutile.

---

# 🧩 5. Démonstrations rapides prêtes à lancer

## Démo A — Conte enfant

Demande :

Crée un conte court avec un enfant, un chat oracle, une boussole lunaire et une forêt qui grandit quand on fuit.

Route attendue :

ORCHESTRATOR → CHILDREN_STORY_THEMES → HERO_ARCHETYPES → GUIDES_AND_ALLIES → QUEST_OBJECTS → EMOTIONAL_ARCS → STORY_ENGINE → QUALITY_CONTROL

## Démo B — Image master

Demande :

Crée un prompt image master pour une carte mémoire fissurée posée sur du verre noir sous une pluie cyan.

Route attendue :

ORCHESTRATOR → SCENES_AND_KEYFRAMES → VISUAL_STYLE_DNA → QUALITY_CONTROL

## Démo C — Animation

Demande :

Transforme cette keyframe en prompt Wan/I2V stable avec un seul micro-mouvement.

Route attendue :

ORCHESTRATOR → SCENES_AND_KEYFRAMES → VISUAL_STYLE_DNA → MOTION_AND_CAMERA → QUALITY_CONTROL

## Démo D — Pack+ complet

Demande :

Fais un Pack+ complet sur “Le jardin mécanique qui attendait d’être écouté”.

Route attendue :

ORCHESTRATOR → COMBINATIONS → STORY_ENGINE → PACK_PLUS_BUILDER → QUALITY_CONTROL → EXPORT_AND_DELIVERY

## Démo E — Livraison

Demande :

Prépare la livraison GitHub / Notion de cette carte.

Route attendue :

EXPORT_AND_DELIVERY

---

# ✅ 6. Tableau de validation

## Conte enfant

Validé si :

- doux ;
- clair ;
- émotionnel ;
- non traumatique ;
- héros actif ;
- transformation lisible.

## Image master

Validée si :

- un seul instant ;
- sujet clair ;
- Style DNA cohérent ;
- prompt générable ;
- pas de surcharge.

## Animation

Validée si :

- un mouvement principal ;
- caméra stable ;
- style préservé ;
- last frame exploitable ;
- pas de drift majeur prévu.

## Pack+

Validé si :

- concept clair ;
- cartes utiles ;
- pas de collage ;
- image + animation + narration + son + export présents si demandés.

## Livraison

Validée si :

- destination claire ;
- nom fichier propre ;
- chemin logique ;
- commit en anglais ;
- prochaine action unique.

---

# 🧬 7. Block LLM

```text
Active MEMORY_CARDS_DEMO_TESTS_CARD.

Utilise cette carte pour tester le système Memory Cards avec des cas concrets.

Objectif : prouver que les cartes composent ensemble et produisent des sorties exploitables.

Toujours définir :
1. demande test ;
2. cartes activées ;
3. route attendue ;
4. sortie attendue ;
5. critères de réussite ;
6. verdict final.

Tests principaux :
- conte enfant complet ;
- couverture Memory Card ;
- image master cyberpunk mémoire ;
- Pack+ complet ;
- animation Wan/I2V ;
- livraison Notion/GitHub ;
- Quality Control final.

Si MEMORY_CARDS_ORCHESTRATOR_CARD est active, laisse l’Orchestrator choisir la route courte avant le test.

Si MEMORY_CARDS_ATLAS_CARD est active, vérifie que la route existe dans le système.

Si PACK_PLUS_BUILDER_CARD est active, produire une sortie complète exploitable.

Si QUALITY_CONTROL_CARD est active, valider ou corriger la sortie.

Si EXPORT_AND_DELIVERY_CARD est active, donner destination, format, nom fichier, chemin, commit et prochaine action.

Éviter :
- test trop vague ;
- activer toutes les cartes sans raison ;
- démo impossible à produire ;
- validation automatique ;
- sortie sans critère de réussite.
```

---

# 🕯️ 8. Formule courte

Une carte isolée peut être belle.

Un système testé devient fiable.
