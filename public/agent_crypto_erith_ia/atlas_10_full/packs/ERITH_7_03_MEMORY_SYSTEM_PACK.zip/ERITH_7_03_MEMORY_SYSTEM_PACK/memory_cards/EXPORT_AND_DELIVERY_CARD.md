# 📤 EXPORT AND DELIVERY CARD

Statut : Memory Card — export et livraison  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : livraison / publication / Notion / GitHub / YouTube / Wan / DaVinci / archivage

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Où va le résultat final ?

Une idée peut être forte.  
Un Pack+ peut être complet.  
Une image peut être belle.  
Une animation peut être stable.

Mais tant que la sortie n’a pas de destination claire, elle reste en suspension.

Cette carte sert à transformer un résultat créatif en objet réellement livrable :

- page Notion ;
- fichier GitHub ;
- asset image ;
- Pack+ archivé ;
- prompt ComfyUI ;
- prompt Wan / I2V ;
- plan DaVinci ;
- voix ElevenLabs ;
- thumbnail ;
- short vertical ;
- publication YouTube ;
- note de production ;
- entrée d’archive projet.

Formule :

Créer, c’est former l’idée.  
Produire, c’est la rendre exploitable.  
Exporter, c’est lui donner une place.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- PACK_PLUS_BUILDER_CARD.md ;
- QUALITY_CONTROL_CARD.md ;
- SCENES_AND_KEYFRAMES_CARD.md ;
- VISUAL_STYLE_DNA_CARD.md ;
- MOTION_AND_CAMERA_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md ;
- MEMORY_CARDS_ATLAS_CARD.md ;
- COMBINATIONS.md.

Rôle avec PACK_PLUS_BUILDER_CARD :

- transformer le Pack+ en sortie prête à utiliser ;
- choisir les formats finaux ;
- séparer les blocs Notion, prompts, assets et production.

Rôle avec QUALITY_CONTROL_CARD :

- vérifier avant livraison ;
- éviter d’exporter une sortie confuse ;
- contrôler nommage, cohérence, lisibilité et destination.

Rôle avec SCENES_AND_KEYFRAMES_CARD :

- exporter la keyframe comme image master ;
- préparer l’image pour animation ou couverture ;
- choisir le bon format de livraison.

Rôle avec VISUAL_STYLE_DNA_CARD :

- préserver la cohérence visuelle dans les assets ;
- nommer correctement les images ;
- distinguer master, variant, thumbnail, transparent, cover.

Rôle avec MOTION_AND_CAMERA_CARD :

- préparer l’animation Wan/I2V ;
- indiquer last frame, raccords et usage DaVinci ;
- conserver la logique LEGO.

Rôle avec NARRATION_AND_DIALOGUE_CARD :

- exporter les textes voix off ;
- préparer script ElevenLabs ;
- garder les phrases respirables.

Rôle avec SOUND_AND_MUSIC_DESIGN_CARD :

- exporter les indications audio ;
- organiser musique, ambiance, effets, silences ;
- faciliter le montage.

---

# 🧬 3. Structure d’une livraison propre

Pour livrer une production, définir neuf éléments.

## 1. Destination

Où va la sortie ?

Exemples :

- Notion ;
- GitHub ;
- YouTube ;
- Shorts ;
- ComfyUI ;
- Wan / I2V ;
- DaVinci ;
- ElevenLabs ;
- archive projet ;
- démonstration publique.

## 2. Format

Quel format faut-il produire ?

Exemples :

- markdown Notion ;
- fichier .md ;
- image PNG ;
- image transparente ;
- prompt image ;
- prompt animation ;
- script voix ;
- note sound design ;
- description YouTube ;
- thumbnail ;
- short vertical.

## 3. Nom fichier

Comment nommer proprement l’asset ?

Exemples :

- HERO_ARCHETYPES_CARD_COVER_MASTER.png ;
- MEMORY_CITY_RAIN_KEYFRAME_V1.png ;
- CHILDREN_STORY_THEMES_PACK_PLUS_V1.md ;
- COMBINATIONS_MEMORY_CARD_TRANSPARENT_MASTER_21_20.png.

## 4. Chemin GitHub

Où placer le fichier ?

Exemples :

- memory_cards/ ;
- assets/images/ ;
- assets/videos/ ;
- production/prompts/ ;
- production/wan/ ;
- production/davinci/ ;
- public/ ;
- core/.

## 5. Bloc Notion

Quel texte humain doit être copié dans Notion ?

Règle :

Notion doit rester propre, lisible, sans gros bloc rouge inutile, sans citation massive, sans mise en page cassée.

## 6. Bloc LLM

Quel bloc machine doit être conservé ?

Règle :

Le Block LLM doit être clair, compact, activable, sans ambiguïté.

## 7. Commit

Quel commit résume l’action ?

Exemples :

- Add export and delivery memory card ;
- Update memory cards atlas with export workflow ;
- Add visual style cover image ;
- Update card with production-ready Pack+.

## 8. Statut

Quel est l’état de la sortie ?

Exemples :

- draft ;
- validated ;
- production-ready ;
- needs image ;
- needs animation ;
- archived ;
- public-ready ;
- private-only.

## 9. Prochaine action

Que faire ensuite ?

Exemples :

- générer image ;
- renommer asset ;
- uploader GitHub ;
- insérer image dans .md ;
- créer prompt animation ;
- extraire last frame ;
- monter dans DaVinci ;
- publier sur Notion ;
- mettre à jour Atlas.

---

# 📝 4. Livraison Notion

## Objectif

Produire un texte humain propre, immédiatement copiable.

## Format recommandé

- titre clair ;
- statut ;
- rôle ;
- résumé court ;
- sections aérées ;
- listes lisibles ;
- prompts en blocs dédiés seulement si nécessaire ;
- formule courte ;
- prochaine action.

## À éviter

- gros bloc code autour de toute la page ;
- citations massives ;
- texte rouge partout ;
- listes cassées ;
- paragraphes trop longs ;
- jargon inutile ;
- chemins GitHub en excès.

## Mini-template Notion

# Titre

Statut : production-ready  
Projet : @erith IA / ERITH.IA  
Rôle : expliquer la fonction de cette sortie.

## Résumé

Texte court, humain, clair.

## Ce que cette sortie contient

- point 1 ;
- point 2 ;
- point 3.

## Utilisation

Comment s’en servir concrètement.

## Prochaine action

Action unique, claire, sans boucle.

---

# 🧑‍💻 5. Livraison GitHub

## Objectif

Créer une mémoire machine propre, versionnée et retrouvable.

## Chemins recommandés

Memory Cards :

- memory_cards/NOM_DE_LA_CARTE.md

Images :

- assets/images/NOM_IMAGE.png

Vidéos :

- assets/videos/NOM_VIDEO.mp4

Prompts :

- production/prompts/NOM_PROMPT.md

Wan / I2V :

- production/wan/NOM_WAN_PROMPT.md

DaVinci :

- production/davinci/NOM_TIMELINE_NOTE.md

## Nommage recommandé

Utiliser :

- majuscules lisibles ;
- underscores ;
- suffixes MASTER, V1, V2, TRANSPARENT, COVER, KEYFRAME ;
- pas d’espaces ;
- pas de noms vagues.

Exemples :

- MEMORY_CARDS_ATLAS_CARD.md ;
- STORY_ENGINE_CARD_COVER_MASTER.png ;
- RAIN_CITY_MEMORY_KEYFRAME_V1.png ;
- ORACLE_CAT_ANIMATION_PROMPT_V1.md.

## Commits recommandés

Toujours en anglais.

Exemples :

- Add export and delivery memory card ;
- Update memory cards atlas with export workflow ;
- Add story engine cover image ;
- Update Pack Plus builder with delivery format.

---

# 🖼️ 6. Livraison image

## Objectif

Préparer une image utilisable comme master, couverture, thumbnail ou keyframe.

## Vérifier

- format ;
- orientation ;
- transparence réelle si demandée ;
- fond propre ;
- nom fichier ;
- usage final ;
- insertion dans .md ;
- compatibilité I2V si animation prévue.

## Formats utiles

Image master verticale :

- 9:16 ;
- 1024x1536 ;
- 1080x1920 ;
- ou format adapté au pipeline.

Thumbnail YouTube :

- 1280x720 ;
- sujet lisible ;
- contraste fort ;
- pas trop de détails.

Bannière / transparent :

- PNG RGBA réel ;
- alpha propre ;
- pas de damier imprimé ;
- pas de fond blanc involontaire ;
- pas de fond gris involontaire.

Couverture Memory Card :

- symbole central ;
- fond propre ;
- style premium ;
- pas de texte illisible ;
- nommage clair.

---

# 🎬 7. Livraison Wan / I2V

## Objectif

Transformer une image master en animation courte stable.

## Préparer

- image source verrouillée ;
- prompt animation ;
- mouvement principal unique ;
- caméra verrouillée ;
- style préservé ;
- note last frame ;
- durée courte ;
- format vertical si Shorts.

## Checklist rapide

- une animation = une idée ;
- ne pas tout animer ;
- pas de caméra complexe ;
- pas de changement de sujet ;
- pas de nouveaux personnages ;
- préserver composition ;
- finir sur une last frame stable.

## Sortie attendue

- clip court ;
- last frame extraite ;
- note de raccord ;
- éventuel prompt de continuation.

---

# 🎞️ 8. Livraison DaVinci

## Objectif

Préparer le montage.

## Notes à fournir

- ordre des clips ;
- durée approximative ;
- raccords visuels ;
- raccords audio ;
- narration ;
- ambiance sonore ;
- moments de silence ;
- transitions conseillées.

## Raccords utiles

- pluie → pluie ;
- reflet → reflet ;
- lumière → lumière ;
- regard → seuil ;
- objet allumé → objet allumé ;
- pulse sonore → pulse visuel ;
- narration → silence → révélation.

## À éviter

- transitions trop visibles ;
- clips trop longs ;
- voix trop serrée ;
- musique qui écrase ;
- absence de respiration ;
- changement brutal de style.

---

# 🎙️ 9. Livraison ElevenLabs / voix

## Objectif

Préparer une narration propre à enregistrer.

## Format recommandé

- phrases courtes ;
- lignes respirables ;
- pauses naturelles ;
- pas de paragraphes trop longs ;
- indication de ton si nécessaire ;
- pas de surdramatisation.

## Direction voix

Exemple :

Voix calme, intime, légèrement mystérieuse.  
Rythme lent à modéré.  
Ne pas lire comme une publicité.  
Laisser respirer les phrases-oracles.

## À éviter

- phrases trop longues ;
- trop d’adjectifs ;
- ton trailer agressif ;
- émotion forcée ;
- voix de gourou.

---

# ▶️ 10. Livraison YouTube / Shorts

## Objectif

Préparer une publication claire.

## Éléments possibles

- titre ;
- description ;
- thumbnail ;
- chapitre ;
- tags internes ;
- phrase d’accroche ;
- note de production ;
- lien Notion ou GitHub si public ;
- version Shorts verticale.

## Titre

Doit être :

- clair ;
- intriguant ;
- pas trop long ;
- fidèle au contenu ;
- sans promesse mensongère.

## Description courte

Structure :

1. phrase d’accroche ;
2. ce que montre la vidéo ;
3. méthode ou outil si utile ;
4. crédit projet / série ;
5. liens si nécessaires.

## Shorts

Vérifier :

- format vertical ;
- première seconde lisible ;
- narration courte ;
- image forte ;
- sound design propre ;
- pas de surcharge textuelle.

---

# 📚 11. Archivage projet

## Objectif

Ne pas perdre la mémoire de production.

## À archiver

- concept ;
- prompts ;
- image master ;
- variantes ;
- animation ;
- last frame ;
- narration ;
- sound design ;
- nom des fichiers ;
- chemin GitHub ;
- statut ;
- commit ;
- note de production ;
- prochaine action.

## Statuts utiles

- draft ;
- generated ;
- selected ;
- renamed ;
- uploaded ;
- inserted ;
- animated ;
- edited ;
- published ;
- archived ;
- validated.

---

# 🧩 12. Formats de livraison rapides

## Format Notion court

- Titre
- Statut
- Résumé
- Image / asset
- Pack+ court
- Prochaine action

## Format GitHub court

- fichier modifié ;
- asset ajouté ;
- chemin ;
- commit ;
- SHA ;
- statut.

## Format production image

- nom image ;
- format ;
- prompt ;
- usage ;
- insertion prévue.

## Format production vidéo

- image source ;
- prompt animation ;
- mouvement ;
- caméra ;
- last frame ;
- montage.

## Format publication

- titre ;
- description ;
- thumbnail ;
- format ;
- note ;
- statut.

---

# 🧬 13. Block LLM

```text
Active EXPORT_AND_DELIVERY_CARD.

Utilise cette carte pour transformer une sortie créative validée en livraison exploitable : Notion, GitHub, image, animation, Wan/I2V, DaVinci, ElevenLabs, YouTube, Shorts ou archive projet.

Toujours définir :
1. destination ;
2. format ;
3. nom de fichier ;
4. chemin GitHub ou emplacement ;
5. bloc Notion si nécessaire ;
6. bloc LLM si nécessaire ;
7. commit recommandé ;
8. statut ;
9. prochaine action.

Si PACK_PLUS_BUILDER_CARD est active, transforme le Pack+ en formats livrables.

Si QUALITY_CONTROL_CARD est active, ne livre pas tant que les points critiques ne sont pas propres.

Si SCENES_AND_KEYFRAMES_CARD est active, prépare l’image master, la keyframe ou la couverture.

Si VISUAL_STYLE_DNA_CARD est active, respecte nommage, style, fond, transparence et cohérence visuelle.

Si MOTION_AND_CAMERA_CARD est active, prépare prompt Wan/I2V, last frame, continuité LEGO et notes DaVinci.

Si NARRATION_AND_DIALOGUE_CARD est active, prépare un texte voix off respirable.

Si SOUND_AND_MUSIC_DESIGN_CARD est active, prépare une note audio exploitable.

Pour Notion :
- texte humain propre ;
- pas de gros bloc code autour de tout ;
- prompts en blocs dédiés seulement ;
- titres et sections lisibles.

Pour GitHub :
- chemin clair ;
- nom fichier propre ;
- commit en anglais ;
- statut explicite.

Pour image :
- format ;
- usage ;
- nommage ;
- insertion ;
- transparence réelle si demandée.

Pour vidéo :
- image source ;
- prompt animation ;
- mouvement unique ;
- caméra stable ;
- last frame ;
- montage.

Toujours éviter :
- sortie sans destination ;
- nom fichier vague ;
- commit flou ;
- bloc Notion sale ;
- asset non archivé ;
- prochaine action ambiguë ;
- boucle d’audit inutile.
```

---

# 🕯️ 14. Formule courte

Une création devient réelle quand elle trouve sa place.

L’export n’est pas la fin du travail.

C’est le moment où l’œuvre devient utilisable.
