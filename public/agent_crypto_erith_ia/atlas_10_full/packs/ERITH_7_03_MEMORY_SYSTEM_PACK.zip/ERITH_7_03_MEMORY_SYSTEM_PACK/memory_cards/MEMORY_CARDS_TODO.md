# 📝 MEMORY CARDS — TO DO LIST

Statut : To Do dédiée Memory Cards  
Projet : @erith IA / ERITH.IA  
Version : V1  
Rôle : suivre les prochaines cartes mémoire à créer sans surcharger le Core ni GitHub.

---

# ✅ Cartes déjà créées

## 🌧️ DA / Science-fiction / Cyberpunk

- ✅ ALTERED_CARBON_SERIES_VISUAL_DA_CARD.md
- ✅ BLADE_RUNNER_CITY_MELANCHOLY_CARD.md
- ✅ GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md

## 🪞 Conte / rêve / seuil

- ✅ ALICE_ORACLE_CAT_CARD.md

## 🌙 Opératrices

- ✅ AERITH_9_LUNAR_CARD.md
- ✅ MATH_ORACLE_CARD.md

## 🎬 Production

- ✅ VIDEO_DIRECTION_CARD.md
- ✅ MUSIC_DIRECTION_CARD.md
- ✅ ANIMATION_STABILITY_CARD.md

---

# ⏳ Cartes à créer plus tard

## 🟨 Priorité douce

### OZ_INITIATORY_ROAD_CARD.md

Rôle prévu :

- route initiatique ;
- foyer ;
- courage ;
- cœur ;
- intelligence ;
- faux pouvoir ;
- rideau ;
- retour au réel.

Usage futur :

- combinaison avec Alice ;
- combinaison avec Mythologie vivante ;
- univers de passage, route, quête et révélation.

---

### NEVERENDING_STORY_MEMORY_WORLD_CARD.md

Rôle prévu :

- livre-monde ;
- imagination ;
- Néant ;
- nom véritable ;
- royaume menacé ;
- enfant lecteur ;
- mémoire du rêve.

Usage futur :

- monde vivant par narration ;
- mémoire fragile ;
- création contre effacement ;
- lien possible avec Seven Heaven et le Coffre.

---

### DISCERNMENT_CARD.md

Rôle prévu :

- clarification ;
- séparation faits / ressentis / hypothèses / interprétations / incertitudes / actions ;
- protection contre les gourous ;
- écoute sans diagnostic ;
- libre arbitre ;
- décision responsable.

Usage futur :

- garde-fou pour toutes les cartes ;
- meilleure lecture des demandes de Christophe ;
- réduction des boucles ;
- aide à la décision propre.

---

# 🧩 Cartes candidates à envisager ensuite

## MYTHOLOGY_LIVING_SYMBOLS_CARD.md

Rôle possible :

- mythologie vivante ;
- dieux, seuils, rites, symboles ;
- lecture créative sans dogme ;
- usages visuels et narratifs.

## FAIRY_TALES_LIVING_ARCHETYPES_CARD.md

Rôle possible :

- contes de fée vivants ;
- forêt, seuil, épreuve, pacte, transformation ;
- archétypes narratifs.

## DA_ANIMATED_VISUAL_DIRECTION_CARD.md

Rôle possible :

- direction artistique dessin animé / animation ;
- lisibilité visuelle ;
- formes fortes ;
- couleurs et mouvement stylisé.

---

# ⚙️ Règle de production des prochaines cartes

Créer les cartes une par une.

Ne pas surcharger GitHub.

Ne pas faire d’audit large.

Ne pas modifier le Core inutilement.

Chaque carte doit conserver la structure validée :

- icônes ;
- identité ;
- essence ;
- apports principaux ;
- direction artistique ;
- thèmes ;
- usages ;
- garde-fous ;
- combinaisons naturelles ;
- exemple de prompt image ;
- exemple de prompt animation ou musique ;
- Block LLM ;
- formule courte.

---

# 🕯️ Formule courte

Les cartes se construisent lentement.

Une carte propre vaut mieux qu’un Coffre saturé.

Seven choisit, combine, produit, puis s’arrête.
