# 🃏 CARD TEMPLATE

Statut : modèle de carte mémoire  
Projet : @erith IA / ERITH.IA  
Version : V1

---

# 🃏 [NOM DE LA CARTE]

## 1. 🪪 Identité

Nom :

Type :

Statut :

Fonction :

---

## 2. ✨ Essence

Résumé court de la carte.

---

## 3. 🧩 Apports principaux

- 
- 
- 
- 

---

## 4. 🎨 Direction artistique

Palette :

- 
- 
- 

Matières :

- 
- 
- 

Composition :

- 
- 
- 

---

## 5. 🧠 Thèmes

- 
- 
- 
- 

---

## 6. ⚙️ Usages

Cette carte peut servir à :

- 
- 
- 
- 

---

## 7. 🛡️ Garde-fous

Cette carte ne doit pas :

- 
- 
- 
- 

---

## 8. 🧬 Combinaisons naturelles

### Carte + Carte

Usage :

- 
- 
- 

### Carte + Carte + Carte

Usage :

- 
- 
- 

---

## 9. 🖼️ Exemple de prompt image

```text
[Prompt image ici]
```

---

## 10. 🎬 Exemple de prompt animation

```text
[Prompt animation ici]
```

---

## 11. 🧬 Block LLM

```text
[Bloc d’activation LLM ici]
```

---

## 12. 🕯️ Formule courte

Phrase courte résumant la carte.
