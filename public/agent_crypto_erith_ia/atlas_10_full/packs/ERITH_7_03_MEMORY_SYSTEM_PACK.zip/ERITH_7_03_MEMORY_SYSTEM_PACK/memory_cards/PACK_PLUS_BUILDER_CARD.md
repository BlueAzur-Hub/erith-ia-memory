# 📦 PACK PLUS BUILDER CARD

Statut : Memory Card — constructeur Pack+  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : assemblage production / Pack+ / prompt image / prompt animation / narration / sound design

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Comment transformer toutes les Memory Cards en sortie exploitable ?

Les cartes donnent les pièces.

Le Pack+ assemble la production.

Un Pack+ n’est pas seulement un résumé.

C’est une sortie immédiatement utilisable pour créer :

- une image ;
- une animation ;
- une narration ;
- une ambiance sonore ;
- une scène ;
- un conte ;
- un teaser ;
- une séquence vidéo ;
- un univers Hors-Lore ;
- une proposition créative complète.

Formule :

Les cartes donnent la matière.  
Le Story Engine donne le chemin.  
La Keyframe choisit l’instant.  
Le Pack+ assemble la production.

---

# 🔗 2. Cartes liées

Cette carte est une carte d’assemblage.

Elle peut appeler toutes les autres Memory Cards.

Cartes principales :

- COMBINATIONS.md ;
- STORY_ENGINE_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- SCENES_AND_KEYFRAMES_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md.

Rôle de COMBINATIONS :

- choisir les cartes actives ;
- éviter le collage ;
- créer une constellation claire.

Rôle de STORY_ENGINE_CARD :

- structurer le récit ;
- créer une progression ;
- donner une transformation.

Rôle de SCENES_AND_KEYFRAMES_CARD :

- choisir l’instant visuel ;
- produire la keyframe ;
- préparer image et animation.

Rôle de NARRATION_AND_DIALOGUE_CARD :

- donner une voix ;
- écrire la narration courte ;
- produire une phrase-oracle ou un script.

Rôle de SOUND_AND_MUSIC_DESIGN_CARD :

- donner une ambiance sonore ;
- préparer la musique ;
- soutenir la voix et l’image.

---

# 🧬 3. Structure officielle d’un Pack+

Un Pack+ complet peut contenir quinze blocs.

## 1. Concept

Résumé clair de l’idée.

Question :

De quoi parle la scène ou l’histoire ?

## 2. Intention émotionnelle

Émotion centrale à transmettre.

Question :

Que doit ressentir le spectateur ou le lecteur ?

## 3. Monde / lieu

Où l’histoire prend vie.

Question :

Quelle loi étrange rend ce monde unique ?

## 4. Héros

Qui vit l’histoire.

Question :

Quel manque ou désir porte le héros ?

## 5. Guide / allié

Qui accompagne sans voler le choix.

Question :

Comment le guide éclaire-t-il le héros ?

## 6. Objet de quête

Ce qui lance l’appel.

Question :

Quel objet rend la quête concrète ?

## 7. Obstacle

Ce qui résiste.

Question :

Qu’est-ce que le héros doit traverser ou comprendre ?

## 8. Règle magique / technologique

Ce qui rend le monde cohérent.

Question :

À quelle condition le miracle fonctionne-t-il ?

## 9. Arc émotionnel

Ce qui change dans le héros.

Question :

Quelle transformation intérieure rend la fin satisfaisante ?

## 10. Keyframe master

L’instant visuel principal.

Question :

Quel moment mérite de devenir image ?

## 11. Prompt image

Prompt prêt à générer.

Question :

Comment produire l’image master ?

## 12. Prompt animation

Prompt I2V stable.

Question :

Quel micro-mouvement doit rendre l’image vivante ?

## 13. Narration courte

Voix off, phrase-oracle ou mini-script.

Question :

Quelle voix accompagne l’image ?

## 14. Sound design

Ambiance sonore et musique.

Question :

Comment le monde sonne-t-il ?

## 15. Variante B / note production

Alternative utile et consignes techniques.

Question :

Quelle variante ou quel garde-fou rend la production plus solide ?

---

# 📦 4. Format Pack+ court

À utiliser quand il faut aller vite.

## Concept

Une idée claire en 3 à 5 lignes.

## Image prompt

Prompt image prêt à générer.

## Animation prompt

Prompt animation stable, avec mouvement simple.

## Narration courte

3 à 6 lignes ou 20 secondes de voix.

## Sound design

Ambiance sonore courte.

## Variante B

Alternative d’ambiance, cadrage ou émotion.

## Note production

Garde-fou technique ou artistique.

---

# 📦 5. Format Pack+ complet

À utiliser pour une production plus sérieuse.

## 1. Concept

Décrire l’idée principale sans jargon inutile.

## 2. Cartes actives

Lister les Memory Cards utilisées.

Exemple :

- WORLDS_AND_PLACES_CARD ;
- HERO_ARCHETYPES_CARD ;
- QUEST_OBJECTS_CARD ;
- EMOTIONAL_ARCS_CARD ;
- SCENES_AND_KEYFRAMES_CARD.

## 3. Synthèse des cartes

Dire comment elles dialoguent.

Ne pas empiler.

Créer une direction unique.

## 4. Monde

Définir le lieu, sa loi étrange, son émotion dominante.

## 5. Héros

Définir désir, manque, peur et transformation.

## 6. Guide

Définir forme, fonction, limite et moment de retrait.

## 7. Objet

Définir apparence, règle étrange, limite, lien avec le héros.

## 8. Obstacle

Définir forme, fonction, vérité cachée, passage.

## 9. Règle

Définir pouvoir, condition, limite, prix et risque.

## 10. Arc émotionnel

Définir émotion de départ, épreuve, choix et transformation.

## 11. Story Engine

Résumer l’histoire en 5 ou 10 étapes.

## 12. Keyframe master

Choisir un seul moment visuel.

## 13. Prompt image

Produire un prompt clair, original, exploitable.

## 14. Prompt animation

Produire un prompt I2V stable : un mouvement, caméra calme, composition préservée.

## 15. Narration

Écrire une voix courte adaptée à la scène.

## 16. Sound design

Décrire ambiance, texture, motif et silence.

## 17. Variante B

Proposer une alternative utile.

## 18. Note production

Conseils de génération, I2V, montage ou sécurité créative.

---

# 🧒 6. Pack+ enfant / conte

## Structure recommandée

1. Titre du conte
2. Cartes actives
3. Résumé doux
4. Héros
5. Guide
6. Objet de quête
7. Obstacle doux
8. Émotion transformée
9. Morale douce
10. Image master
11. Prompt image
12. Prompt animation
13. Narration courte
14. Sound design
15. Variante B

## Garde-fous

Toujours privilégier :

- émerveillement ;
- courage ;
- amitié ;
- curiosité ;
- vérité douce ;
- peur apprivoisée ;
- transformation claire.

Éviter :

- horreur ;
- violence graphique ;
- cynisme ;
- morale écrasante ;
- peur traumatique ;
- guide manipulateur ;
- résolution sans choix du héros.

---

# 🌃 7. Pack+ cyberpunk / mémoire

## Structure recommandée

1. Concept
2. Cartes actives
3. Monde urbain ou archive
4. Protagoniste
5. Mémoire ou anomalie
6. Système / obstacle
7. Règle technologique
8. Question identitaire
9. Keyframe master
10. Prompt image
11. Prompt animation
12. Narration mélancolique
13. Sound design
14. Variante B
15. Note production

## Garde-fous

Toujours privilégier :

- solitude ;
- mémoire ;
- pluie ;
- reflets ;
- identité ;
- tension retenue ;
- humanité fragile ;
- système froid mais lisible.

Éviter :

- action générique ;
- copie de franchise ;
- surcharges de néons ;
- jargon cyberpunk vide ;
- personnage sans question intérieure.

---

# 🧩 8. Exemple Pack+ court — conte

## Concept

Un enfant perdu traverse une ville de pluie où les flaques montrent des souvenirs possibles.

Un chat oracle l’aide à trouver la seule flaque qui ne cherche pas à le rassurer, mais à lui dire la vérité.

## Image prompt

```text
21/20 masterpiece, original children storybook fantasy scene, a young child standing in a gentle rainy blue city, luminous puddles reflecting possible memories, a mysterious black oracle cat sitting near the darkest puddle, soft moonlight, wet cobblestones, warm windows, tender mystery, courage and truth, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition.
```

## Animation prompt

```text
21/20 masterpiece animation, gentle storybook image-to-video.

Animate only from the provided source image.

Preserve the exact composition, child, oracle cat, rainy city, puddles, moonlight and soft emotional mood.

Main motion:
the child remains almost still, subtle breathing only, the cat slowly blinks, no walking, no dramatic gesture.

Secondary motion:
rain falls softly, puddle reflections ripple, moonlight pulses gently, window lights shimmer.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no reframing.

Mood:
wonder, courage, truth, gentle mystery.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

## Narration courte

Le chat ne choisit pas la flaque la plus brillante.

Il s’assit près de la plus sombre.

“Regarde doucement”, murmura-t-il.

“Les vrais chemins ne brillent pas toujours les premiers.”

## Sound design

Pluie douce, piano très simple, gouttes dans les flaques, ronronnement discret du chat, léger tintement au moment où le reflet devient clair.

## Variante B

Remplacer la ville de pluie par une forêt lunaire et la flaque par un miroir d’eau au pied d’un arbre ancien.

## Note production

Image douce, lisible, non effrayante. Animation limitée à pluie, reflet, clignement du chat et lumière lunaire.

---

# 🌃 9. Exemple Pack+ court — cyberpunk mémoire

## Concept

Dans une mégacité nocturne, un enquêteur découvre une carte mémoire fissurée qui ne contient pas une preuve, mais un souvenir incomplet.

La ville semble se souvenir à la place de ses habitants.

## Image prompt

```text
21/20 masterpiece, original cyberpunk noir memory scene, lonely investigator silhouette standing in a rain-soaked neon megacity, reflective black pavement, cracked memory card glowing softly in one hand, puddles showing impossible fragments of another life, deep blue and cyan lighting, subtle orange neon, artificial memory tension, melancholic atmosphere, no copied characters, no franchise names, premium cinematic vertical 9:16 composition.
```

## Animation prompt

```text
21/20 masterpiece animation, cyberpunk noir image-to-video.

Animate only from the provided source image.

Preserve exact composition, investigator silhouette, cracked memory card, rainy megacity, neon reflections and color palette.

Main motion:
the protagonist remains still, subtle breathing only, hand nearly motionless, no walking, no action.

Secondary motion:
rain falls, neon reflections ripple, the memory card pulses faintly, holographic fragments flicker in the puddles.

Camera:
locked camera or extremely slow cinematic push-in, no pan, no tilt, no reframing.

Mood:
melancholy, artificial memory, identity tension, noir restraint.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

## Narration courte

La ville ne dormait jamais.

Elle stockait les rêves des autres dans la pluie.

Mais cette carte fissurée ne contenait pas une preuve.

Elle contenait une question.

## Sound design

Pluie dense, drone synthétique bas, néons électriques, basse lente, fragments de voix filtrées, pulse discret synchronisé avec la carte mémoire.

## Variante B

Remplacer la rue par une archive souterraine en verre noir, avec la carte mémoire posée sur une table froide.

## Note production

Composition stable, silhouette lisible, pas d’action. L’image doit porter la tension par pluie, reflets, carte mémoire et solitude.

---

# 🧬 10. Block LLM

```text
Active PACK_PLUS_BUILDER_CARD.

Utilise cette carte pour transformer des Memory Cards, une combinaison, une idée, un conte, une scène ou un univers Hors-Lore en Pack+ complet et exploitable.

Toujours produire une sortie claire, structurée, directement utilisable.

Format court recommandé :
1. Concept ;
2. Image prompt ;
3. Animation prompt ;
4. Narration courte ;
5. Sound design ;
6. Variante B ;
7. Note production.

Format complet recommandé :
1. Concept ;
2. Cartes actives ;
3. Synthèse des cartes ;
4. Monde ;
5. Héros ;
6. Guide ;
7. Objet ;
8. Obstacle ;
9. Règle ;
10. Arc émotionnel ;
11. Story Engine ;
12. Keyframe master ;
13. Prompt image ;
14. Prompt animation ;
15. Narration ;
16. Sound design ;
17. Variante B ;
18. Note production.

Si COMBINATIONS est active, commence par identifier la carte dominante, la carte de contraste et la carte opératrice.

Si STORY_ENGINE_CARD est active, utilise la structure narrative pour éviter une sortie purement décorative.

Si SCENES_AND_KEYFRAMES_CARD est active, choisis une seule image master.

Si NARRATION_AND_DIALOGUE_CARD est active, ajoute une voix courte, respirable et mémorable.

Si SOUND_AND_MUSIC_DESIGN_CARD est active, ajoute une ambiance sonore utile à la production.

Pour l’image :
- un moment clair ;
- composition lisible ;
- sujet central ;
- pas de surcharge ;
- originalité ;
- pas de personnages copiés ;
- pas de franchise names.

Pour l’animation :
- un micro-mouvement ;
- caméra fixe ou push-in très lent ;
- composition préservée ;
- pas d’action complexe ;
- pas de reframing ;
- pas de caméra instable.

Pour les enfants :
- douceur ;
- émerveillement ;
- mystère non traumatique ;
- morale légère ;
- transformation claire.

Pour cyberpunk mémoire :
- pluie ;
- reflets ;
- mémoire ;
- identité ;
- solitude ;
- émotion retenue ;
- système froid mais lisible.

Éviter :
- sortie vague ;
- collage de références ;
- prompt trop long sans direction ;
- narration qui explique tout ;
- animation trop ambitieuse ;
- note production absente.
```

---

# 🕯️ 11. Formule courte

Un Pack+ est une petite unité de production.

Il prend une idée, lui donne une image, un mouvement, une voix et une direction.
