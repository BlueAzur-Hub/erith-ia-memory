# 🌧️ BLADE_RUNNER_CITY_MELANCHOLY_CARD

Statut : Memory Card — direction artistique urbaine  
Projet : @erith IA / ERITH.IA  
Version : V1  
Type : influence graphique / ville noire / pluie / néons / mémoire artificielle

---

![Blade Runner City Memory Puddle Master](../assets/images/BLADE_RUNNER_CITY_MEMORY_PUDDLE_MASTER_21_20.png)

Image master 21/20 — Blade Runner City Melancholy Card.  
Scène Hors-Lore originale : ville cyberpunk nocturne sous la pluie, silhouette solitaire, flaque-miroir centrale, mémoire artificielle, reflets instables et mélancolie urbaine.

---

# 1. 🪪 Identité

Nom :

Blade Runner City Melancholy Card

Type :

Carte d’influence visuelle, urbaine et émotionnelle.

Fonction :

Apporter une direction artistique de ville cyberpunk mélancolique : pluie, néons, solitude, mémoire artificielle, humanité incertaine et atmosphère nocturne, sans copier les œuvres, personnages, intrigues ou noms propres associés.

---

# 2. ✨ Essence

Cette carte sert à produire une ville qui semble vivante, ancienne, saturée de pluie, de lumière artificielle et de souvenirs qui ne sont peut-être pas vrais.

Elle porte une question simple :

Qu’est-ce qui reste de l’humain dans une ville qui fabrique ses rêves, ses corps et ses souvenirs ?

Elle n’est pas une carte d’action.

Elle est une carte d’atmosphère, de solitude, de verticalité et de mémoire urbaine.

---

# 3. 🧩 Apports principaux

- Pluie nocturne.
- Néons réfléchis sur sol mouillé.
- Ville verticale dense.
- Mélancolie urbaine.
- Mémoire artificielle.
- Solitude dans la foule.
- Humanité incertaine.
- Architecture industrielle et publicitaire.
- Lumière sale, fumée, brume, contre-jours.
- Présence émotionnelle dans les machines.

---

# 4. 🎨 Direction artistique

Palette :

- noir profond ;
- bleu nuit ;
- cyan électrique ;
- orange sodium ;
- rose néon ;
- jaune publicitaire ;
- reflets pluie ;
- gris béton.

Matières :

- pluie ;
- verre sale ;
- métal humide ;
- béton sombre ;
- vapeur ;
- hologrammes publicitaires ;
- câbles ;
- néons ;
- manteaux mouillés ;
- vitres couvertes de gouttes.

Composition :

- rues profondes ;
- silhouettes petites devant architectures massives ;
- enseignes verticales ;
- fenêtres éclairées ;
- reflets au sol ;
- cadrage cinématique nocturne ;
- personnages vus de dos ou en trois-quarts ;
- ville comme personnage principal.

---

# 5. 🧠 Thèmes

- Mémoire artificielle.
- Humanité incertaine.
- Ville-machine.
- Solitude.
- Désir de vérité.
- Enquête intérieure.
- Identité fabriquée.
- Nostalgie du réel.
- Pluie comme mémoire liquide.
- Lumière artificielle comme faux soleil.

---

# 6. ⚙️ Usages

Cette carte peut servir à :

- créer une ville cyberpunk mélancolique ;
- poser une ambiance nocturne ;
- renforcer un univers Hors-Lore ;
- donner de la profondeur émotionnelle à une scène urbaine ;
- créer un prompt image ;
- créer un prompt animation ;
- guider une ambiance musicale lente et pluvieuse ;
- construire une scène d’enquête ;
- préparer une introduction vidéo verticale ;
- densifier une direction artistique cyberpunk.

---

# 7. 🛡️ Garde-fous

Cette carte ne doit pas :

- copier une œuvre existante ;
- reprendre des personnages connus ;
- reprendre des noms propres ;
- reprendre une intrigue ;
- transformer l’influence en imitation ;
- se limiter à “pluie + néons” sans thème ;
- oublier la mélancolie et la question de l’humain ;
- rendre la ville illisible par surcharge visuelle.

Règle :

La ville doit respirer, pas seulement briller.

---

# 8. 🧬 Combinaisons naturelles

## Blade Runner City Melancholy + Ghost in the Shell

Usage :

- ville-réseau ;
- conscience cybernétique ;
- solitude numérique ;
- ghost dans la foule ;
- pluie et interfaces mentales.

## Blade Runner City Melancholy + Altered Carbon

Usage :

- ville verticale de classes sociales ;
- corps-supports ;
- élites au-dessus des nuages ;
- bas-fonds mouillés ;
- enquête post-humaine.

## Blade Runner City Melancholy + Aerith-9 Lunaire

Usage :

- ville nocturne comme miroir ;
- pluie lunaire ;
- reflets ;
- mémoire douce-amère ;
- solitude poétique.

---

# 9. 🖼️ Exemple de prompt image

```text
21/20 masterpiece, original cyberpunk noir rainy city scene, immense vertical megacity at night, wet reflective streets, neon signs glowing through mist, lonely figure standing under transparent umbrella, memory archive holograms reflected in puddles, cinematic blue and orange lighting, dense atmosphere, melancholic urban solitude, artificial memories, no copied characters, no existing franchise names, original universe only, vertical 9:16 composition, 1080x1920 mobile-ready framing, city as emotional character, premium cinematic lighting, rain, smoke, glass, metal, deep shadows.
```

---

# 10. 🎬 Exemple de prompt animation

```text
21/20 masterpiece animation, original cyberpunk noir rainy megacity image-to-video.

Animate only from the provided source image.

Preserve the exact composition, city geometry, silhouette, rain, neon reflections, lighting, color palette, atmosphere and vertical phone composition.

Main motion:
the character remains almost still, subtle breathing only, tiny coat movement from damp wind, no walking, no speaking, no dramatic gesture.

Secondary motion:
rain falls softly, neon reflections ripple gently in puddles, steam drifts from vents, distant signs flicker subtly, background traffic lights move very slowly.

Camera:
locked camera or extremely slow cinematic push-in, no zoom out, no pan, no tilt, no reframing, no camera reset.

Mood:
melancholic, rainy, lonely, human, artificial memory, cyberpunk noir.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 11. 🧬 Block LLM

```text
Active la carte BLADE_RUNNER_CITY_MELANCHOLY_CARD.

Utilise-la comme influence d’atmosphère urbaine, de pluie, de néons, de mémoire artificielle et de mélancolie cyberpunk.

Apporte :
- ville verticale nocturne ;
- pluie ;
- reflets ;
- néons ;
- solitude ;
- humanité incertaine ;
- mémoire artificielle ;
- ville comme personnage émotionnel.

Interdictions :
- ne pas copier d’œuvre existante ;
- ne pas reprendre les personnages ;
- ne pas reprendre les noms propres ;
- ne pas réduire la carte à pluie + néons ;
- ne pas surcharger la scène au point de perdre la lecture.

Sortie attendue :
direction artistique urbaine, prompt image, prompt animation, ambiance musicale pluvieuse, décor cyberpunk ou scène d’enquête mélancolique.
```

---

# 12. 🕯️ Formule courte

Une ville sous la pluie, pleine de fausses lumières et de vrais fantômes intérieurs.
