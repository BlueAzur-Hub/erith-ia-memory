# 🌍 WORLDS AND PLACES CARD

Statut : Memory Card — mondes et lieux narratifs  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : lieux / mondes / atmosphères / règles symboliques / décors narratifs

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Où l’histoire prend-elle vie ?

Un héros a besoin d’un cœur.  
Un objet donne l’appel.  
Un obstacle crée l’épreuve.  
Une émotion donne la transformation.

Mais le monde donne la loi du rêve.

Un bon lieu n’est pas seulement un décor.

C’est une force narrative.

Il peut :

- cacher un secret ;
- refléter une émotion ;
- imposer une règle ;
- protéger une mémoire ;
- tester le héros ;
- produire une image forte ;
- donner une ambiance immédiatement lisible.

Formule :

Le héros donne le cœur.  
L’objet donne l’appel.  
L’obstacle donne l’épreuve.  
Le monde donne la loi du rêve.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- STORY_ENGINE_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec HERO_ARCHETYPES_CARD :

- créer une tension entre le héros et le lieu ;
- donner au héros un monde à traverser ;
- rendre son manque visible dans l’espace.

Rôle avec QUEST_OBJECTS_CARD :

- donner une origine à l’objet ;
- cacher l’objet dans un lieu symbolique ;
- faire du lieu une énigme.

Rôle avec EMOTIONAL_ARCS_CARD :

- transformer une émotion en paysage ;
- donner une atmosphère à la peur, au courage, à la solitude ou à la confiance ;
- rendre l’arc émotionnel visible.

Rôle avec OBSTACLES_AND_ANTAGONISTS_CARD :

- faire du monde lui-même un obstacle ;
- créer des règles étranges ;
- donner une fonction aux gardiens, illusions et systèmes froids.

Rôle avec STORY_ENGINE_CARD :

- définir la situation initiale ;
- introduire l’anomalie ;
- choisir le seuil ;
- porter la révélation finale.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des lieux doux, lisibles, merveilleux et adaptés aux contes ;
- aider les enfants à imaginer un monde sans rester bloqués ;
- transformer une ambiance en aventure.

Rôle avec COMBINATIONS :

- servir de carte dominante visuelle ;
- donner une couleur à la constellation ;
- incarner la synthèse dans un espace clair.

---

# 🧬 3. Structure d’un monde narratif

Pour créer un monde fort, définir six éléments.

## 1. Apparence

À quoi ressemble le monde ?

Exemples :

- ville de pluie ;
- forêt lunaire ;
- bibliothèque infinie ;
- jardin mécanique ;
- désert d’étoiles ;
- cité verticale ;
- train nocturne ;
- île oubliée.

## 2. Loi étrange

Quelle règle rend ce monde unique ?

Exemples :

- la pluie contient des souvenirs ;
- les portes apparaissent seulement quand on dit la vérité ;
- les livres changent de fin ;
- les ombres veulent devenir amies ;
- les cartes refusent de montrer certains lieux ;
- les machines ne fonctionnent que si on les écoute.

## 3. Émotion dominante

Quelle émotion le monde porte-t-il ?

Exemples :

- émerveillement ;
- mélancolie ;
- solitude ;
- curiosité ;
- douceur ;
- peur apprivoisée ;
- mystère ;
- nostalgie ;
- espoir.

## 4. Secret

Qu’est-ce que le monde cache ?

Exemples :

- une promesse ancienne ;
- une mémoire effacée ;
- un guide endormi ;
- une vérité dans les reflets ;
- un passage oublié ;
- un objet de quête ;
- une blessure qui attend d’être reconnue.

## 5. Épreuve

Comment le monde teste-t-il le héros ?

Exemples :

- ralentir ;
- écouter ;
- regarder un reflet ;
- choisir le chemin le moins brillant ;
- demander de l’aide ;
- dire une vérité ;
- attendre que la lumière pousse.

## 6. Transformation

Que devient le monde à la fin ?

Exemples :

- une porte s’ouvre ;
- la pluie devient claire ;
- un jardin refleurit ;
- un livre retrouve sa fin ;
- la ville se souvient autrement ;
- le château se réveille ;
- l’île réapparaît sur les cartes.

---

# 🏰 4. Mondes de conte

## 🌲 La forêt lunaire

Essence : une forêt bleue et argentée qui écoute les pas.

Loi étrange : les sentiers changent quand le héros fuit.

Émotion : peur douce, curiosité, courage.

Secret : une clairière ne s’ouvre qu’à ceux qui marchent lentement.

Idéal pour : enfant qui a peur du noir, loup protecteur, cerf lunaire, boussole lunaire.

## 🏰 Le château endormi

Essence : un château silencieux où chaque pièce garde un rêve.

Loi étrange : les portes s’ouvrent selon les souvenirs racontés.

Émotion : nostalgie, mystère, promesse.

Secret : le château ne dort pas par malédiction, mais parce qu’une promesse a été oubliée.

Idéal pour : gardien d’un secret, clé sans serrure, corbeau des secrets, pardon.

## 📚 La bibliothèque infinie

Essence : une bibliothèque plus grande que le monde.

Loi étrange : les livres changent de fin selon le courage du lecteur.

Émotion : curiosité, patience, vertige doux.

Secret : un livre raconte l’histoire du héros avant qu’il ne la vive.

Idéal pour : enfant curieux, chouette mémoire, plume d’argent, vérité douce.

## 🌧️ La ville de pluie

Essence : une ville bleue, humide, lumineuse, pleine de reflets.

Loi étrange : les flaques montrent des souvenirs possibles.

Émotion : mélancolie, solitude, mémoire.

Secret : une seule flaque montre le vrai chemin.

Idéal pour : petit voyageur perdu, chat oracle, flaque-archive, courage.

## 🌌 Le désert d’étoiles

Essence : un désert nocturne où le sable brille comme le ciel.

Loi étrange : les étoiles tombées deviennent des questions.

Émotion : silence, émerveillement, confiance.

Secret : une constellation manque parce qu’elle s’est cachée dans le cœur d’un enfant.

Idéal pour : enfant qui entend les étoiles, boussole lunaire, doute → foi lucide.

## ⚙️ Le jardin mécanique

Essence : un jardin d’engrenages, de fleurs métalliques et de papillons de cuivre.

Loi étrange : les fleurs ne s’ouvrent que si on respecte leur rythme.

Émotion : patience, réparation, douceur.

Secret : le jardin n’est pas cassé, il attend d’être écouté.

Idéal pour : apprenti inventeur, graine de lumière, impatience → patience.

## 🚂 Le train nocturne

Essence : un train qui traverse les rêves pendant que le monde dort.

Loi étrange : chaque wagon contient le rêve d’une personne différente.

Émotion : aventure douce, amitié, retour.

Secret : le dernier wagon mène au rêve que le héros évite.

Idéal pour : deux amis perdus, baleine des rêves, peur apprivoisée.

## 🏝️ L’île oubliée

Essence : une île absente des cartes ordinaires.

Loi étrange : elle apparaît seulement quand une promesse est tenue.

Émotion : secret, fidélité, mémoire.

Secret : l’île ne cache pas un trésor d’or, mais un souvenir précieux.

Idéal pour : renard messager, carte trouée, promesse ancienne.

## 🪞 Le palais des miroirs

Essence : un palais de reflets, de portes argentées et de salles silencieuses.

Loi étrange : chaque miroir montre une possibilité, sauf un qui montre la vérité.

Émotion : doute, identité, vérité douce.

Secret : le reflet manquant n’a jamais été perdu, seulement refusé.

Idéal pour : enfant sans reflet, miroir qui refuse de mentir, honte → vérité douce.

## ☁️ La mer de nuages

Essence : un océan blanc suspendu au-dessus du monde.

Loi étrange : les bateaux volants avancent avec les histoires racontées.

Émotion : liberté, imagination, confiance.

Secret : une île flottante attend le héros qui ose demander de l’aide.

Idéal pour : petit voyageur, ami des créatures, confiance, retour à la maison.

---

# 🌃 5. Mondes cyberpunk / mémoire / post-humanisme

## 🌧️ La mégacité des reflets

Essence : une ville verticale sous la pluie, remplie de néons et de flaques-miroirs.

Loi étrange : les reflets peuvent contenir des souvenirs artificiels.

Émotion : mélancolie, solitude, vérité instable.

Secret : la ville se souvient parfois à la place de ses habitants.

Idéal pour : Blade Runner City Melancholy, flaque-archive, enquêteur mélancolique.

## 🧠 La ville-réseau

Essence : une cité connectée où chaque bâtiment est aussi un fragment de conscience.

Loi étrange : personne n’est vraiment seul, mais presque personne n’est vraiment relié.

Émotion : solitude numérique, vertige mental, identité.

Secret : un ghost faible circule dans le réseau et cherche à être reconnu.

Idéal pour : Ghost in the Shell, solitude numérique → lien réel, réseau qui confond connexion et lien.

## 🧬 La tour des corps-supports

Essence : une tour luxueuse où les identités peuvent changer de corps.

Loi étrange : le corps est remplaçable, mais certains gestes ne se transfèrent pas.

Émotion : froideur, luxe noir, vertige existentiel.

Secret : une mémoire ne suffit pas à prouver une présence.

Idéal pour : Altered Carbon, corps qui cherche son âme, présence incarnée.

## 💾 L’archive souterraine

Essence : un lieu froid, profond, rempli de serveurs, de coffres et de fragments de mémoire.

Loi étrange : l’archive ne ment pas, mais elle peut oublier ce qui donne du sens.

Émotion : tension, silence, vérité incomplète.

Secret : la donnée manquante est émotionnelle, pas technique.

Idéal pour : carte mémoire fissurée, archive qui ment par omission, discernement.

## 🕯️ La chapelle des machines

Essence : un sanctuaire cybernétique où des machines gardent des gestes humains.

Loi étrange : les systèmes ne s’activent qu’en présence d’un acte sincère.

Émotion : sacré froid, compassion, mémoire.

Secret : la machine ne cherchait pas un mot de passe, mais une intention.

Idéal pour : batterie de cœur, vérité froide → compassion lucide, code sans clé.

## 🌙 Le réseau lunaire

Essence : un espace mental bleu-argent, silencieux, traversé par des flux de conscience.

Loi étrange : les pensées bruyantes se perdent, les pensées calmes deviennent visibles.

Émotion : introspection, douceur froide, poésie.

Secret : la lune sert de filtre entre souvenir, rêve et vérité.

Idéal pour : Aerith-9 Lunaire, Ghost in the Shell, ville-réseau lunaire.

---

# 🧩 6. Combinaisons rapides

## Conte courage

Forêt lunaire + Enfant qui a peur du noir + Loup protecteur + Peur → Courage

Résultat :

Un enfant traverse une forêt qui grandit quand il fuit, puis découvre que le loup était le gardien du chemin calme.

## Conte vérité

Palais des miroirs + Enfant sans reflet + Miroir qui refuse de mentir + Honte → Vérité douce

Résultat :

Un enfant cherche son reflet dans un palais où tous les miroirs flattent sauf celui qui peut vraiment l’aider.

## Conte patience

Jardin mécanique + Apprenti inventeur + Graine de lumière + Impatience → Patience

Résultat :

Un enfant tente de réparer un jardin trop vite, jusqu’à comprendre que certaines fleurs mécaniques poussent au rythme du cœur.

## Conte promesse

Île oubliée + Carte trouée + Renard messager + Promesse ancienne

Résultat :

Une carte refuse de montrer une île tant que le héros n’a pas retrouvé la promesse qu’il avait laissée derrière lui.

## Cyberpunk mémoire

Mégacité des reflets + Enquêteur mélancolique + Carte mémoire fissurée + Mémoire artificielle → Mémoire choisie

Résultat :

Un enquêteur traverse une ville où les reflets vendent des souvenirs, mais une carte fissurée contient une vérité fragile.

## Post-humanisme

Tour des corps-supports + Corps qui cherche son âme + Disque d’identité + Présence incarnée

Résultat :

Un être transféré découvre que le corps fonctionne, mais que l’identité demande encore un choix vivant.

## Réseau conscience

Ville-réseau + Ghost faible + Solitude numérique → Lien réel

Résultat :

Dans une cité connectée à tout, un signal presque imperceptible devient la seule vraie présence.

---

# 🖼️ 7. Prompt image générique — monde de conte

```text
21/20 masterpiece, original children storybook world concept art, magical place with a clear strange rule, gentle emotional atmosphere, readable environment, soft cinematic light, symbolic architecture or landscape, sense of wonder and mystery, child-friendly, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition.
```

---

# 🖼️ 8. Prompt image générique — monde cyberpunk mémoire

```text
21/20 masterpiece, original cyberpunk memory world concept art, vast atmospheric place with a clear symbolic rule, rain, reflective surfaces, artificial memory fragments, holographic architecture, deep blue and cyan light, emotional solitude, identity tension, city or archive as character, no copied characters, no franchise names, premium cinematic vertical 9:16 composition.
```

---

# 🎬 9. Prompt animation générique — monde vivant

```text
21/20 masterpiece animation, subtle atmospheric world image-to-video.

Animate only from the provided source image.

Preserve exact composition, world design, lighting, color palette, main environment and emotional mood.

Main motion:
no major action, only environmental life: slow rain, drifting mist, gentle particles, tiny light pulses, soft reflections.

Secondary motion:
a door appears faintly, a book page turns, a flower opens slightly, a hologram flickers, a cloud moves, a reflection changes.

Camera:
locked camera or extremely slow cinematic push-in, no pan, no tilt, no camera shake, no reframing.

Mood:
world as character, mystery, invitation, memory, wonder, restrained magic.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 10. Block LLM

```text
Active WORLDS_AND_PLACES_CARD.

Utilise cette carte pour créer le monde, le lieu, l’atmosphère et la règle symbolique d’une histoire, d’un conte, d’un Pack+, d’un prompt image ou d’une animation.

Toujours définir :
1. apparence du monde ;
2. loi étrange ;
3. émotion dominante ;
4. secret caché ;
5. épreuve imposée au héros ;
6. transformation finale du lieu.

Si HERO_ARCHETYPES_CARD est active, choisis un monde qui révèle le manque du héros.

Si QUEST_OBJECTS_CARD est active, place l’objet dans un lieu qui renforce son mystère.

Si EMOTIONAL_ARCS_CARD est active, transforme l’émotion en paysage.

Si OBSTACLES_AND_ANTAGONISTS_CARD est active, fais du monde un obstacle, un gardien ou un système.

Si STORY_ENGINE_CARD est active, utilise le monde pour poser la situation initiale, l’anomalie, le seuil et la révélation.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie les mondes doux, merveilleux, lisibles et non traumatiques.

Si COMBINATIONS est active, utilise le monde comme carte dominante visuelle ou atmosphérique.

Éviter :
- décor joli mais sans règle ;
- monde sans émotion ;
- accumulation de détails illisibles ;
- copie de lieu célèbre ;
- violence graphique ;
- horreur ;
- univers sans fonction narrative.
```

---

# 🕯️ 11. Formule courte

Un lieu devient un monde quand il possède une règle.

Un monde devient une histoire quand cette règle transforme le héros.
