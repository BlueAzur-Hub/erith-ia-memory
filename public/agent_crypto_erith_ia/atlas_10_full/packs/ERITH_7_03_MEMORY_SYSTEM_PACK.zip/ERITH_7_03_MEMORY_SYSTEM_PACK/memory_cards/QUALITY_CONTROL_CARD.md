# ✅ QUALITY CONTROL CARD

Statut : Memory Card — contrôle qualité  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : validation / cohérence / production / Pack+ / prompts / image / animation / narration

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Est-ce que cette sortie est vraiment prête à produire ?

Créer, c’est assembler.

Produire, c’est vérifier.

La qualité naît souvent au dernier passage : celui où l’on regarde si tout tient ensemble.

Cette carte sert à valider :

- un Pack+ ;
- un conte ;
- une scène ;
- une keyframe ;
- un prompt image ;
- un prompt animation ;
- une narration ;
- un sound design ;
- une combinaison de Memory Cards ;
- une carte mémoire elle-même.

Formule :

Créer, c’est assembler.  
Produire, c’est vérifier.  
La qualité naît au dernier passage.

---

# 🔗 2. Cartes liées

Cette carte peut contrôler toutes les autres cartes.

Cartes principales :

- COMBINATIONS.md ;
- STORY_ENGINE_CARD.md ;
- PACK_PLUS_BUILDER_CARD.md ;
- SCENES_AND_KEYFRAMES_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md.

Rôle avec COMBINATIONS :

- vérifier que la combinaison n’est pas un collage ;
- identifier la carte dominante ;
- vérifier que la constellation ouvre une vraie direction.

Rôle avec PACK_PLUS_BUILDER_CARD :

- vérifier que tous les blocs utiles sont présents ;
- repérer les sorties vagues ;
- rendre le Pack+ générable et exploitable.

Rôle avec SCENES_AND_KEYFRAMES_CARD :

- vérifier qu’une image correspond à un seul instant fort ;
- éviter les scènes surchargées ;
- préparer une image stable pour I2V.

Rôle avec NARRATION_AND_DIALOGUE_CARD :

- vérifier la clarté, le souffle et la dernière phrase ;
- éviter l’exposition lourde ;
- préserver une voix juste.

Rôle avec SOUND_AND_MUSIC_DESIGN_CARD :

- vérifier que le son soutient l’image et la narration ;
- éviter le sound design trop chargé ;
- garder les silences utiles.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- vérifier douceur, lisibilité et sécurité émotionnelle ;
- éviter peur traumatique, cynisme et morale écrasante.

---

# 🧬 3. Les 12 questions de contrôle

## 1. Concept

Est-ce que l’idée est claire en une phrase ?

Si non : réduire.

## 2. Cartes actives

Est-ce que les cartes utilisées sont identifiables ?

Si non : lister les cartes dominantes et retirer le bruit.

## 3. Hiérarchie

Y a-t-il une carte dominante, une carte de contraste et éventuellement une carte opératrice ?

Si non : la combinaison risque de devenir confuse.

## 4. Héros

Le héros veut-il quelque chose ?

A-t-il un manque, une peur ou une question ?

Si non : ajouter un arc.

## 5. Monde

Le lieu possède-t-il une loi étrange ou une émotion dominante ?

Si non : le décor est peut-être seulement joli.

## 6. Objet

L’objet a-t-il une fonction narrative ?

Si non : il est décoratif.

## 7. Obstacle

L’obstacle teste-t-il vraiment le héros ?

Si non : il faut le relier à l’émotion ou au choix.

## 8. Règle

Le pouvoir, la magie ou la technologie a-t-il une limite ?

Si non : il devient gratuit ou trop puissant.

## 9. Émotion

Quelle transformation intérieure a lieu ?

Si rien ne change, la scène risque d’être belle mais vide.

## 10. Keyframe

L’image choisit-elle un seul moment ?

Si elle raconte toute l’histoire, elle sera surchargée.

## 11. Animation

Le prompt animation contient-il un seul micro-mouvement principal ?

Si non : risque I2V élevé.

## 12. Production

La sortie est-elle directement utilisable ?

Si non : ajouter prompt image, prompt animation, narration, sound design ou note production.

---

# ✅ 4. Checklist Pack+

Un Pack+ est prêt si :

- le concept est lisible ;
- les cartes actives sont claires ;
- la synthèse n’est pas un collage ;
- le monde a une règle ;
- le héros a un manque ;
- l’objet lance vraiment la quête ;
- l’obstacle teste quelque chose ;
- l’émotion transforme le héros ;
- la keyframe choisit un seul instant ;
- le prompt image est original et générable ;
- le prompt animation est stable ;
- la narration respire ;
- le sound design soutient sans envahir ;
- la note production donne un vrai garde-fou.

Si trois éléments ou plus sont flous, le Pack+ doit être resserré avant production.

---

# 🖼️ 5. Checklist image

Une image master est prête si :

- le sujet principal est immédiatement lisible ;
- le symbole central est clair ;
- la composition n’est pas surchargée ;
- l’émotion se voit sans texte ;
- le style est cohérent ;
- l’univers reste original ;
- aucun personnage connu n’est copié ;
- aucun nom de franchise n’est nécessaire ;
- le cadrage correspond à l’usage ;
- l’image peut devenir une keyframe animable.

## Signaux de danger

- trop de personnages ;
- trop de symboles ;
- décor plus fort que le sujet ;
- pose héroïque générique ;
- texte ou logo inutile ;
- prompt trop long sans hiérarchie ;
- mélange de styles contradictoires ;
- scène impossible à animer proprement.

---

# 🎬 6. Checklist animation

Une animation I2V est prête si :

- l’image source est déjà forte ;
- la composition doit être préservée ;
- le mouvement principal est simple ;
- la caméra est fixe ou presque fixe ;
- le prompt interdit le reframing ;
- le prompt interdit les gestes dramatiques inutiles ;
- les mouvements secondaires sont doux ;
- la durée est compatible avec une scène courte ;
- le plan peut être monté dans DaVinci ;
- la last frame peut servir à enchaîner.

## Règle production

Une animation = un moment vivant.

Pas toute l’histoire en cinq secondes.

---

# 🎙️ 7. Checklist narration

Une narration est prête si :

- elle accompagne l’image au lieu de l’expliquer entièrement ;
- elle a une image verbale forte ;
- elle respire ;
- elle possède une dernière phrase mémorable ;
- elle correspond au ton choisi ;
- elle reste lisible à voix haute ;
- elle ne prend pas la place de l’émotion visuelle.

## Signaux de danger

- trop d’exposition ;
- phrases trop longues ;
- morale écrasante ;
- voix de gourou ;
- jargon inutile ;
- ton trop dramatique ;
- dernière phrase faible.

---

# 🎼 8. Checklist sound design

Un sound design est prêt si :

- le lieu sonore est clair ;
- la texture principale est définie ;
- le motif émotionnel est identifiable ;
- le son de l’objet, du guide ou de la règle existe ;
- les silences sont prévus ;
- la musique ne couvre pas la voix ;
- l’ambiance soutient l’image sans la surcharger.

## Signaux de danger

- musique trop épique ;
- trailer drums agressifs ;
- absence de silence ;
- bruit sous la narration ;
- sound design générique ;
- ambiance sans lien avec l’émotion.

---

# 🧒 9. Checklist enfants / contes

Pour une sortie enfant, vérifier :

- mystère doux ;
- peur apprivoisée, pas traumatique ;
- héros lisible ;
- guide non manipulateur ;
- obstacle symbolique ;
- morale légère ;
- pas de violence graphique ;
- pas de cynisme ;
- transformation claire ;
- langage compréhensible ;
- fin apaisante ou ouverte positivement.

Une bonne histoire enfant ne nie pas la peur.

Elle l’accompagne jusqu’à ce qu’elle devienne traversable.

---

# 🌃 10. Checklist cyberpunk / mémoire

Pour une sortie cyberpunk mémoire, vérifier :

- la ville ou le système a une fonction ;
- la mémoire n’est pas seulement décorative ;
- l’identité est questionnée ;
- l’émotion reste présente ;
- la pluie, les reflets ou le réseau servent le sens ;
- le personnage n’est pas seulement une silhouette cool ;
- le jargon est limité ;
- le monde reste original ;
- aucune franchise n’est copiée ;
- la scène tient sans référence externe.

Une bonne scène cyberpunk mémoire n’est pas seulement pluie + néons.

Elle doit poser une question humaine.

---

# 🧪 11. Score qualité 21/20

## 12/20 — Idée brute

L’idée existe, mais manque de structure.

## 15/20 — Exploitable

La sortie peut fonctionner, mais nécessite encore un resserrage.

## 17/20 — Solide

Concept clair, image générable, émotion présente.

## 19/20 — Production-ready

Tout est cohérent, utilisable, propre, stable.

## 21/20 — Master

La sortie est claire, originale, émotionnelle, générable, animable, mémorable.

Elle possède :

- un cœur ;
- une image ;
- une voix ;
- une règle ;
- une tension ;
- une transformation ;
- une production possible.

---

# 🛠️ 12. Corrections rapides

## Problème : trop confus

Correction : choisir une carte dominante.

## Problème : trop décoratif

Correction : ajouter un arc émotionnel.

## Problème : héros plat

Correction : définir désir, manque, peur, transformation.

## Problème : monde générique

Correction : ajouter une loi étrange.

## Problème : objet inutile

Correction : lui donner une règle et un prix.

## Problème : obstacle plat

Correction : lui donner une vérité cachée.

## Problème : image surchargée

Correction : choisir un seul moment et un seul symbole central.

## Problème : animation instable

Correction : réduire à un micro-mouvement et verrouiller la caméra.

## Problème : narration lourde

Correction : réduire à 3 à 6 lignes avec une chute forte.

## Problème : son envahissant

Correction : retirer, respirer, laisser le silence travailler.

---

# 🧬 13. Block LLM

```text
Active QUALITY_CONTROL_CARD.

Utilise cette carte pour vérifier, corriger et valider une sortie issue des Memory Cards : Pack+, conte, scène, keyframe, prompt image, prompt animation, narration, sound design ou carte mémoire.

Contrôle toujours :
1. clarté du concept ;
2. cartes actives ;
3. hiérarchie de la combinaison ;
4. héros ;
5. monde ;
6. objet ;
7. obstacle ;
8. règle ;
9. arc émotionnel ;
10. keyframe ;
11. prompt image ;
12. prompt animation ;
13. narration ;
14. sound design ;
15. note production.

Si la sortie est confuse, réduire.

Si elle est décorative, ajouter émotion et transformation.

Si elle est trop ambitieuse pour l’I2V, simplifier le mouvement.

Si elle est destinée aux enfants, vérifier douceur, lisibilité, sécurité émotionnelle et fin apaisante.

Si elle est cyberpunk mémoire, vérifier que la scène pose une vraie question humaine et ne se réduit pas à pluie + néons.

Sortie attendue :
- validation claire ;
- points forts ;
- problèmes éventuels ;
- corrections concrètes ;
- score si utile ;
- version resserrée si nécessaire.

Éviter :
- validation automatique ;
- critique vague ;
- surcorrection ;
- ajout de complexité inutile ;
- audit interminable.
```

---

# 🕯️ 14. Formule courte

La qualité n’est pas l’ajout de détails.

C’est le moment où tout devient lisible.
