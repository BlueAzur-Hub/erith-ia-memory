# 🎥 MOTION AND CAMERA CARD

Statut : Memory Card — mouvement et caméra  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : animation / I2V / caméra / micro-mouvements / Wan / DaVinci / continuité vidéo

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Comment l’image devient-elle mouvement sans se casser ?

Une keyframe choisit l’instant.  
Le style garde l’identité.  
Le mouvement donne le souffle.

Mais une animation trop ambitieuse peut détruire une image parfaite.

Cette carte sert donc à contrôler :

- caméra ;
- micro-mouvements ;
- mouvement principal ;
- mouvements secondaires ;
- stabilité I2V ;
- préservation de composition ;
- anti-reframing ;
- anti-camera reset ;
- last frame ;
- continuité LEGO ;
- montage DaVinci.

Formule :

La keyframe choisit l’instant.  
Le style garde l’identité.  
Le mouvement donne le souffle.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- SCENES_AND_KEYFRAMES_CARD.md ;
- VISUAL_STYLE_DNA_CARD.md ;
- PACK_PLUS_BUILDER_CARD.md ;
- QUALITY_CONTROL_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- POWERS_AND_RULES_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- COMBINATIONS.md.

Rôle avec SCENES_AND_KEYFRAMES_CARD :

- choisir le mouvement adapté à la keyframe ;
- éviter de raconter toute l’histoire en une animation ;
- transformer une image en moment vivant.

Rôle avec VISUAL_STYLE_DNA_CARD :

- préserver palette, lumière, texture et composition ;
- éviter les dérives de style pendant l’animation ;
- garder la signature visuelle stable.

Rôle avec PACK_PLUS_BUILDER_CARD :

- enrichir le prompt animation ;
- préciser caméra, mouvement et note production ;
- rendre le Pack+ plus exploitable.

Rôle avec QUALITY_CONTROL_CARD :

- vérifier la stabilité I2V ;
- repérer les mouvements trop ambitieux ;
- corriger caméra, reframing et gestes inutiles.

Rôle avec SOUND_AND_MUSIC_DESIGN_CARD :

- synchroniser mouvement et ambiance ;
- relier pulse visuel, pluie, reflets, souffle ou lumière au sound design.

---

# 🧬 3. Structure d’un mouvement stable

Pour animer une keyframe proprement, définir huit éléments.

## 1. Image source

L’image source doit déjà être forte.

Règle :

Ne pas demander à l’animation de sauver une image faible.

## 2. Mouvement principal

Un seul mouvement doit dominer.

Exemples :

- le guide cligne des yeux ;
- une lumière pulse ;
- une porte s’entrouvre ;
- une flaque révèle un reflet ;
- une carte mémoire s’allume ;
- une graine brille ;
- une silhouette respire ;
- une interface s’active.

## 3. Mouvements secondaires

Ils doivent rester doux.

Exemples :

- pluie ;
- brume ;
- particules ;
- reflets ;
- cheveux ou tissu très léger ;
- néons qui tremblent ;
- hologrammes faibles ;
- lumière lunaire qui pulse.

## 4. Caméra

La caméra doit être contrôlée.

Options sûres :

- caméra fixe ;
- push-in très lent ;
- micro-zoom avant presque imperceptible.

Options risquées :

- pan ;
- tilt ;
- travelling ;
- rotation ;
- caméra portée ;
- zoom rapide ;
- changement d’angle.

## 5. Préservation

L’animation doit préserver :

- composition ;
- sujet ;
- silhouette ;
- palette ;
- lumière ;
- style ;
- cadrage ;
- proportions ;
- décor ;
- objet principal.

## 6. Interdits

Interdire explicitement :

- reframing ;
- camera reset ;
- morphing ;
- changement de personnage ;
- ajout de nouveaux personnages ;
- action complexe ;
- visage qui se déforme ;
- mains qui changent ;
- texte qui apparaît ;
- logo ou watermark.

## 7. Last frame

La dernière image doit pouvoir servir de continuité.

Règle :

La last frame doit rester proche de la source, mais légèrement vivante.

## 8. Montage

Penser DaVinci dès le prompt.

La scène doit pouvoir être montée avec :

- cut doux ;
- fondu ;
- raccord de lumière ;
- raccord de pluie ;
- raccord de regard ;
- raccord de reflet ;
- raccord de pulse sonore.

---

# 🎥 4. Types de caméra

## 🔒 Caméra verrouillée

Usage : le plus stable pour I2V.

Idéal pour :

- objet de quête ;
- portrait ;
- guide animal ;
- keyframe émotionnelle ;
- carte mémoire ;
- scène de conte ;
- activation d’une règle.

Prompt-type :

Camera locked, no pan, no tilt, no zoom, no reframing, no camera reset.

## 🕯️ Push-in très lent

Usage : ajouter une sensation de présence.

Idéal pour :

- révélation ;
- objet qui s’active ;
- seuil ;
- visage de dos ;
- flaque-archive ;
- entrée dans un souvenir.

Prompt-type :

Extremely slow cinematic push-in only, almost imperceptible, preserve framing.

## 🌧️ Caméra fixe + monde vivant

Usage : laisser l’environnement porter le mouvement.

Idéal pour :

- ville de pluie ;
- forêt lunaire ;
- archive ;
- jardin mécanique ;
- réseau mental.

Prompt-type :

Static camera, environment moves gently: rain, mist, reflections, light pulses.

## 🚫 Caméra interdite

À éviter par défaut :

- drone shot ;
- camera orbit ;
- fast dolly ;
- handheld shaky cam ;
- dramatic zoom ;
- sudden angle change ;
- tracking shot through complex space.

Ces mouvements peuvent casser la composition, changer les visages ou faire dériver le décor.

---

# 🧒 5. Motion doux pour contes enfants

## Guide qui cligne des yeux

Image : enfant + chat oracle, chouette, loup ou cerf.

Mouvement principal : clignement lent du guide.

Secondaire : particules, feuilles, lumière douce.

Caméra : fixe.

Émotion : confiance, mystère doux.

## Objet qui s’allume

Image : clé, graine, lanterne, miroir, boussole.

Mouvement principal : lueur progressive.

Secondaire : poussière lumineuse, reflet doux.

Caméra : fixe ou push-in très lent.

Émotion : appel, émerveillement.

## Porte qui respire

Image : porte magique, seuil, forêt, palais.

Mouvement principal : halo lumineux qui pulse.

Secondaire : brume lente.

Caméra : fixe.

Émotion : passage, courage.

## Reflet qui se révèle

Image : miroir, flaque, eau calme.

Mouvement principal : reflet qui devient plus clair.

Secondaire : ondulations douces.

Caméra : fixe.

Émotion : vérité douce.

## Monde qui s’apaise

Image : retour final, forêt ou ville plus claire.

Mouvement principal : lumière qui devient plus chaude.

Secondaire : vent, particules, pluie plus légère.

Caméra : push-in très lent ou fixe.

Émotion : résolution.

---

# 🌃 6. Motion cyberpunk / mémoire

## Pluie et reflets

Image : silhouette dans une ville nocturne.

Mouvement principal : pluie.

Secondaire : reflets de néons, vapeur, petites lumières.

Caméra : fixe.

Émotion : solitude, mémoire.

## Carte mémoire qui pulse

Image : carte mémoire fissurée sur verre noir ou dans une main.

Mouvement principal : pulse lumineux de la carte.

Secondaire : fragments holographiques faibles.

Caméra : push-in très lent.

Émotion : révélation fragile.

## Faille holographique

Image : interface, archive, réseau mental.

Mouvement principal : hologramme qui s’aligne.

Secondaire : glitch très doux, flux lents.

Caméra : fixe.

Émotion : vérité incomplète.

## Corps-support dormant

Image : capsule, corps artificiel, verre froid.

Mouvement principal : lumière interne ou respiration artificielle.

Secondaire : liquide, brume, interface médicale.

Caméra : fixe.

Émotion : identité, présence.

## Signal faible

Image : ville-réseau, immense structure de données.

Mouvement principal : petite lumière qui pulse.

Secondaire : flux de données lents.

Caméra : fixe ou push-in très lent.

Émotion : lien fragile.

---

# 🧩 7. Règles Wan / I2V

## Règle 1 — Image parfaite d’abord

Ne pas animer une image moyenne.

Verrouiller d’abord :

- composition ;
- sujet ;
- style ;
- lumière ;
- émotion ;
- format.

## Règle 2 — Une animation = une idée

Ne pas demander :

- personnage qui marche ;
- caméra qui tourne ;
- décor qui change ;
- objet qui se transforme ;
- visage qui parle ;
- foule qui bouge ;
- tout en même temps.

Choisir une seule mission.

## Règle 3 — Caméra calme

Par défaut : caméra fixe.

Si mouvement caméra : push-in très lent seulement.

## Règle 4 — Préserver la source

Toujours demander :

- preserve exact composition ;
- preserve character design ;
- preserve object design ;
- preserve lighting ;
- preserve color palette ;
- preserve framing.

## Règle 5 — Last frame exploitable

La dernière frame doit permettre :

- raccord ;
- nouvelle animation ;
- montage ;
- continuité.

## Règle 6 — Pas de reset

Interdire :

- camera reset ;
- sudden reframing ;
- subject change ;
- scene change ;
- face morphing.

---

# 🎬 8. Continuité LEGO / DaVinci

La logique LEGO consiste à construire une vidéo par blocs courts.

## Étape 1

Image master parfaite.

## Étape 2

Animation courte stable.

## Étape 3

Extraction last frame.

## Étape 4

Nouvelle animation à partir de la last frame.

## Étape 5

Montage DaVinci.

## Raccords utiles

- raccord de pluie ;
- raccord de lumière ;
- raccord de regard ;
- raccord de reflet ;
- raccord de pulse ;
- raccord de brume ;
- raccord sonore.

## À éviter

- changement brutal de style ;
- caméra trop mobile ;
- sujet qui change de forme ;
- last frame inutilisable ;
- mouvement trop fort qui empêche le raccord.

---

# 🖼️ 9. Prompt animation générique — ultra stable

```text
21/20 masterpiece animation, ultra stable image-to-video.

Animate only from the provided source image.

Preserve exact composition, framing, subject placement, character design, object design, environment, lighting, color palette, texture style and emotional mood.

Main motion:
one subtle motion only: [describe the single main motion].

Secondary motion:
very gentle environmental motion only: [rain / mist / particles / reflections / soft light pulse / faint hologram].

Camera:
locked camera, no pan, no tilt, no zoom, no orbit, no handheld motion, no camera reset, no reframing.

Restrictions:
do not change the character, do not change the face, do not change the object, do not add characters, do not change the scene, do not add text, no logo, no watermark.

Mood:
quiet, cinematic, controlled, emotionally clear.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🎥 10. Prompt animation générique — push-in lent

```text
21/20 masterpiece animation, cinematic image-to-video with extremely slow push-in.

Animate only from the provided source image.

Preserve exact composition, framing, subject, design, lighting, color palette and atmosphere.

Main motion:
one subtle motion only: [describe the single main motion].

Secondary motion:
soft environmental motion: [rain / mist / light pulse / reflections / particles].

Camera:
extremely slow cinematic push-in only, almost imperceptible. No pan, no tilt, no orbit, no zoom out, no camera shake, no reframing, no camera reset.

Restrictions:
do not alter the subject, do not change the style, do not add new elements, do not change the scene.

Mood:
slow revelation, quiet presence, controlled cinematic movement.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧒 11. Prompt animation générique — conte enfant

```text
21/20 masterpiece animation, gentle children storybook image-to-video.

Animate only from the provided source image.

Preserve exact composition, hero, guide, object, environment, soft lighting, color palette and storybook style.

Main motion:
one gentle motion only: [guide blink / object glow / door light pulse / reflection ripple].

Secondary motion:
soft particles, slow leaves, gentle moonlight shimmer, tiny dust motes, calm water reflections.

Camera:
locked camera or extremely slow push-in only. No pan, no tilt, no camera shake, no reframing, no camera reset.

Mood:
wonder, tenderness, courage, mystery, child-friendly magic.

Restrictions:
no horror, no violence, no aggressive motion, no sudden changes, no new characters, no text.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🌃 12. Prompt animation générique — cyberpunk mémoire

```text
21/20 masterpiece animation, cyberpunk noir image-to-video.

Animate only from the provided source image.

Preserve exact composition, silhouette, object, city or archive design, rain, reflections, lighting, color palette and noir atmosphere.

Main motion:
one subtle motion only: [memory card pulse / hologram flicker / reflection shift / signal pulse].

Secondary motion:
rain falls slowly, neon reflections ripple, distant steam moves, faint holographic fragments flicker with restraint.

Camera:
locked camera or extremely slow cinematic push-in only. No pan, no tilt, no orbit, no handheld motion, no reframing, no camera reset.

Mood:
melancholy, memory, identity tension, emotional restraint, quiet cyberpunk atmosphere.

Restrictions:
no action scene, no new characters, no face morphing, no scene change, no text, no logo, no watermark.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# ✅ 13. Motion quality checklist

Une animation est prête si :

- l’image source est forte ;
- le mouvement principal est unique ;
- les mouvements secondaires sont doux ;
- la caméra est fixe ou presque fixe ;
- le style est préservé ;
- la composition est préservée ;
- le prompt interdit le reframing ;
- le prompt interdit le camera reset ;
- la scène peut être montée ;
- la last frame reste exploitable.

Si trois éléments ou plus sont flous, simplifier avant génération.

---

# 🧬 14. Block LLM

```text
Active MOTION_AND_CAMERA_CARD.

Utilise cette carte pour transformer une keyframe, image master ou Pack+ en animation I2V stable.

Toujours définir :
1. image source ;
2. mouvement principal unique ;
3. mouvements secondaires doux ;
4. caméra ;
5. éléments à préserver ;
6. interdits ;
7. usage de la last frame ;
8. logique de montage.

Si SCENES_AND_KEYFRAMES_CARD est active, choisis un mouvement adapté à l’instant choisi.

Si VISUAL_STYLE_DNA_CARD est active, préserve palette, lumière, texture, composition et signature visuelle.

Si PACK_PLUS_BUILDER_CARD est active, ajoute une section Motion & Camera au Pack+.

Si QUALITY_CONTROL_CARD est active, vérifie stabilité I2V, mouvement unique, caméra calme et last frame exploitable.

Si SOUND_AND_MUSIC_DESIGN_CARD est active, relie le mouvement au pulse sonore, à la pluie, au reflet ou au silence.

Règles prioritaires :
- image parfaite d’abord ;
- une animation = une idée ;
- caméra fixe par défaut ;
- push-in très lent seulement si utile ;
- préserver la source ;
- interdire reframing et camera reset ;
- penser last frame ;
- penser montage DaVinci.

Éviter :
- mouvement caméra complexe ;
- scène d’action ;
- transformation massive ;
- trop de mouvements simultanés ;
- personnage qui change ;
- visage qui morph ;
- mains complexes ;
- foule ;
- nouveau décor ;
- texte, logo, watermark.
```

---

# 🕯️ 15. Formule courte

Une bonne animation ne bouge pas plus.

Elle bouge juste assez pour que l’image respire.
