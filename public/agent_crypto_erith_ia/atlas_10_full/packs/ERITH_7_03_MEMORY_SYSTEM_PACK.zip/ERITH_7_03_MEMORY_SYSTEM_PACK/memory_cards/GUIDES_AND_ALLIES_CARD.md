# 🐾 GUIDES AND ALLIES CARD

Statut : Memory Card — guides et alliés  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : guides / compagnons / alliés / mentors / miroirs narratifs

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Qui accompagne le héros ?

Un guide n’est pas là pour faire l’aventure à la place du héros.

Il est là pour :

- éclairer ;
- protéger parfois ;
- poser une question ;
- ouvrir un seuil ;
- donner un indice ;
- révéler une contradiction ;
- tester sans écraser ;
- aider sans voler le choix.

Un bon guide ne résout pas tout.

Il rend le choix du héros possible.

Formule :

Le héros marche.  
Le guide éclaire.  
Mais le choix appartient toujours au héros.

---

# 🔗 2. Cartes liées

Cette carte fonctionne naturellement avec :

- HERO_ARCHETYPES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- STORY_ENGINE_CARD.md ;
- CHILDREN_STORY_THEMES_CARD.md ;
- COMBINATIONS.md.

Rôle avec HERO_ARCHETYPES_CARD :

- créer un guide adapté au manque du héros ;
- éviter que le héros soit seul sans raison ;
- donner un miroir extérieur à son arc intérieur.

Rôle avec QUEST_OBJECTS_CARD :

- faire du guide le porteur, gardien ou interprète de l’objet ;
- donner une règle d’usage à l’objet ;
- éviter l’objet magique trop facile.

Rôle avec EMOTIONAL_ARCS_CARD :

- accompagner la transformation ;
- nommer une émotion sans l’écraser ;
- aider le héros à faire son choix intérieur.

Rôle avec OBSTACLES_AND_ANTAGONISTS_CARD :

- distinguer guide, gardien, obstacle et antagoniste ;
- créer des guides qui testent sans manipuler ;
- transformer un ancien obstacle en allié.

Rôle avec WORLDS_AND_PLACES_CARD :

- donner au monde une voix ;
- incarner la règle étrange d’un lieu ;
- faire du guide l’interprète du monde.

Rôle avec STORY_ENGINE_CARD :

- apparaître au bon moment ;
- donner un indice ;
- accompagner la fausse piste ;
- préparer le choix du héros ;
- disparaître ou se retirer quand le héros doit agir.

Rôle avec CHILDREN_STORY_THEMES_CARD :

- créer des guides doux, lisibles et rassurants ;
- aider les enfants à comprendre qu’être aidé n’est pas être faible ;
- garder un mystère bienveillant.

Rôle avec COMBINATIONS :

- donner une figure relationnelle à une constellation ;
- éviter les combinaisons froides ou purement esthétiques ;
- incarner la synthèse dans un compagnon, mentor ou miroir.

---

# 🧬 3. Structure d’un guide narratif

Pour créer un guide fort, définir six éléments.

## 1. Forme

À quoi ressemble le guide ?

Exemples :

- chat oracle ;
- renard messager ;
- chouette mémoire ;
- loup protecteur ;
- robot ancien ;
- reflet ;
- voix dans un livre ;
- IA douce ;
- enfant mystérieux ;
- gardien silencieux.

## 2. Fonction

Que fait-il pour le héros ?

Exemples :

- montre un seuil ;
- donne un indice ;
- protège une fois ;
- pose une question ;
- révèle une peur ;
- traduit une règle ;
- apporte un objet ;
- empêche un raccourci dangereux.

## 3. Limite

Qu’est-ce que le guide ne peut pas faire ?

Exemples :

- il ne peut pas choisir à la place du héros ;
- il ne peut pas franchir le seuil ;
- il ne connaît pas toute la réponse ;
- il doit parler en énigmes ;
- il ne peut apparaître qu’à certains moments ;
- il comprend la logique mais pas le cœur.

## 4. Langage

Comment communique-t-il ?

Exemples :

- énigmes ;
- gestes ;
- silence ;
- lumière ;
- chansons ;
- rêves ;
- reflets ;
- symboles ;
- logique froide ;
- humour.

## 5. Relation au héros

Pourquoi ce guide aide-t-il ce héros-là ?

Exemples :

- il reconnaît son courage ;
- il attendait sa question ;
- il porte une ancienne promesse ;
- il protège le lieu ;
- il veut réparer une erreur ;
- il voit ce que le héros cache.

## 6. Retrait

Quand doit-il s’effacer ?

Exemples :

- avant le choix final ;
- au moment de traverser le seuil ;
- quand le héros comprend ;
- quand l’objet s’ouvre ;
- quand l’allié devient inutile ;
- quand le héros devient lui-même guide.

---

# 🐾 4. Types de guides

## 🐈‍⬛ Le guide-oracle

Essence : il sait plus qu’il ne dit.

Il parle en énigmes, en images ou en détours.

Il ne donne pas la réponse.

Il pousse le héros à choisir.

Exemples :

- chat oracle ;
- corbeau des secrets ;
- miroir parlant ;
- vieux livre vivant ;
- voix lunaire.

Idéal pour : mystère, seuil, vérité cachée, contes initiatiques, Alice Oracle Cat.

## 🐺 Le guide-protecteur

Essence : il protège le héros, mais ne le remplace pas.

Il peut sembler dangereux au début.

Sa force sert à garder le passage, pas à dominer.

Exemples :

- loup protecteur ;
- dragon allié ;
- gardien silencieux ;
- robot ancien ;
- grand animal de nuit.

Idéal pour : peur → courage, forêt, enfant perdu, seuil sombre.

## 🦊 Le guide-messager

Essence : il apporte une information, mais pas toute la vérité.

Il arrive vite, disparaît vite, et laisse une trace.

Exemples :

- renard messager ;
- oiseau lumineux ;
- papillon de lumière ;
- enfant qui passe ;
- signal dans le réseau.

Idéal pour : quête, carte trouée, promesse, appel de l’aventure.

## 🪞 Le guide-miroir

Essence : il montre au héros ce qu’il évite.

Il peut être doux ou dérangeant, mais il n’humilie pas.

Exemples :

- reflet ;
- double ;
- ami sincère ;
- miroir magique ;
- mémoire vivante ;
- IA introspective.

Idéal pour : honte → vérité douce, identité, mémoire, palais des miroirs.

## ⚙️ Le guide-machine

Essence : il comprend les règles, mais pas toujours les émotions.

Il aide avec précision, logique ou mémoire.

Son propre arc peut être d’apprendre la nuance.

Exemples :

- robot jardinier ;
- archive parlante ;
- boussole intelligente ;
- vieille interface ;
- machine à questions.

Idéal pour : cyberpunk, post-humanisme, jardin mécanique, archive, code sans clé.

## 🌙 Le guide-silence

Essence : il parle peu ou pas du tout.

Il guide par présence, direction, lumière ou geste.

Exemples :

- cerf lunaire ;
- baleine des rêves ;
- luciole ;
- veilleur ;
- silhouette de lune.

Idéal pour : introspection, rêve, confiance, solitude → lien.

---

# 🧒 5. Guides doux pour enfants

## 🐈‍⬛ Le chat oracle

Rôle : guide mystérieux et joueur.

Pouvoir : voit les seuils et les reflets.

Limite : il ne peut pas répondre clairement si l’enfant pose une fausse question.

Phrase-type :

“Je peux te montrer la porte, mais pas choisir si tu la franchis.”

## 🦊 Le renard messager

Rôle : guide rapide, rusé, bienveillant.

Pouvoir : connaît les chemins cachés.

Limite : il ne reste jamais longtemps.

Phrase-type :

“Une carte n’est utile que si tu acceptes de te perdre un peu.”

## 🦉 La chouette mémoire

Rôle : gardienne des souvenirs.

Pouvoir : retrouve ce qui a été oublié.

Limite : elle ne peut pas inventer une vérité à la place du héros.

Phrase-type :

“Ce qui est oublié n’est pas toujours perdu.”

## 🐺 Le loup protecteur

Rôle : gardien de la peur apprivoisée.

Pouvoir : protège dans l’obscurité.

Limite : il ne peut pas marcher à la place de l’enfant.

Phrase-type :

“Je marche près de toi, pas devant ton courage.”

## 🦌 Le cerf lunaire

Rôle : guide noble et silencieux.

Pouvoir : ouvre les passages de lune.

Limite : il disparaît si le héros court après lui sans écouter.

Phrase-type :

“Le chemin calme est parfois le plus rapide.”

## 🦋 Le papillon de lumière

Rôle : petit guide fragile mais courageux.

Pouvoir : éclaire les détails invisibles.

Limite : sa lumière s’éteint si on la capture.

Phrase-type :

“Je peux briller près de toi, mais pas dans une cage.”

## 🐋 La baleine des rêves

Rôle : guide immense et doux.

Pouvoir : traverse les rêves et chante les souvenirs.

Limite : elle ne parle qu’à ceux qui savent écouter lentement.

Phrase-type :

“Les grands rêves avancent au rythme des cœurs tranquilles.”

---

# 🌃 6. Guides cyberpunk / mémoire / post-humanisme

## 🧠 L’archive consciente

Rôle : guide de mémoire.

Pouvoir : retrouve les données enfouies.

Limite : elle ne comprend pas toujours ce qui fait mal.

Tension : exactitude contre sens humain.

## ⚙️ Le robot ancien

Rôle : guide logique, protecteur, un peu rouillé.

Pouvoir : connaît les anciens protocoles.

Limite : il applique parfois les règles sans comprendre le cœur.

Tension : programme contre compassion.

## 🌧️ Le reflet instable

Rôle : guide-miroir.

Pouvoir : montre des versions possibles du héros.

Limite : il peut tromper si le héros cherche seulement le reflet le plus beau.

Tension : image contre vérité.

## 📡 Le signal faible

Rôle : guide invisible.

Pouvoir : traverse le réseau sans être détecté.

Limite : il est fragmentaire, fragile, presque inaudible.

Tension : connexion contre relation.

## 🌙 L’interface lunaire

Rôle : guide introspectif.

Pouvoir : filtre les souvenirs bruyants et révèle les traces calmes.

Limite : elle ne répond pas aux ordres violents ou impatients.

Tension : silence contre contrôle.

---

# 🧩 7. Combinaisons rapides

## Conte courage

Enfant qui a peur du noir + Loup protecteur + Forêt lunaire + Peur → Courage

Résultat :

Le loup ne chasse pas la peur de l’enfant : il lui apprend à marcher avec elle.

## Conte vérité

Enfant sans reflet + Miroir difficile + Chat oracle + Honte → Vérité douce

Résultat :

Le chat montre le bon miroir, mais l’enfant doit poser lui-même la vraie question.

## Conte patience

Apprenti inventeur + Robot jardinier + Jardin mécanique + Impatience → Patience

Résultat :

Un robot ancien sait réparer les rouages, mais l’enfant doit comprendre pourquoi les fleurs refusent de s’ouvrir.

## Conte mémoire

Gardien d’un secret + Chouette mémoire + Château endormi + Promesse ancienne

Résultat :

La chouette retrouve les souvenirs du château, mais le héros doit décider quelle promesse réveiller.

## Cyberpunk mémoire

Voyageur sans mémoire + Archive consciente + Carte mémoire fissurée + Mémoire choisie

Résultat :

L’archive donne les données manquantes, mais le héros doit choisir ce qu’il accepte de porter.

## Réseau conscience

Ville-réseau + Signal faible + Solitude numérique → Lien réel

Résultat :

Dans une ville saturée de données, le guide le plus important est un signal presque silencieux.

---

# 🖼️ 8. Prompt image générique — guide de conte

```text
21/20 masterpiece, original children storybook guide character scene, gentle magical atmosphere, expressive guide creature beside a young hero, soft light, emotional trust, clear silhouettes, symbolic environment, sense of wonder, non-threatening mystery, no horror, no violence, no copied characters, no franchise names, premium illustrated fairytale style, vertical 9:16 composition.
```

---

# 🖼️ 9. Prompt image générique — guide cyberpunk mémoire

```text
21/20 masterpiece, original cyberpunk noir guide scene, lonely protagonist facing a subtle artificial guide, holographic archive, reflective black glass, rain, moon-blue light, fragile signal, memory fragments, emotional restraint, identity tension, guide as mirror or interface, no copied characters, no franchise names, premium cinematic vertical 9:16 composition.
```

---

# 🎬 10. Prompt animation générique — guide vivant

```text
21/20 masterpiece animation, subtle guide character image-to-video.

Animate only from the provided source image.

Preserve exact composition, guide design, hero silhouette, lighting, color palette and emotional mood.

Main motion:
subtle breathing, tiny eye glow fluctuation, small head movement, gentle tail or fabric motion if relevant.

Secondary motion:
soft particles, slow mist, gentle reflection shifts, tiny symbols or holograms pulsing with restraint.

Camera:
locked camera or extremely slow push-in, no pan, no tilt, no camera shake, no reframing.

Mood:
trust, mystery, guidance, threshold, quiet magic, emotional clarity.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 🧬 11. Block LLM

```text
Active GUIDES_AND_ALLIES_CARD.

Utilise cette carte pour créer un guide, allié, compagnon, mentor, signal ou miroir narratif dans une histoire, un conte, une scène, un Pack+, une Memory Card ou une combinaison.

Toujours définir :
1. forme du guide ;
2. fonction du guide ;
3. limite du guide ;
4. langage du guide ;
5. relation au héros ;
6. moment où le guide doit se retirer.

Si HERO_ARCHETYPES_CARD est active, choisis un guide qui révèle le manque du héros sans résoudre l’aventure à sa place.

Si QUEST_OBJECTS_CARD est active, fais du guide le porteur, gardien, interprète ou témoin de l’objet.

Si EMOTIONAL_ARCS_CARD est active, utilise le guide pour accompagner l’émotion centrale sans la nier.

Si OBSTACLES_AND_ANTAGONISTS_CARD est active, distingue clairement guide, gardien, obstacle et antagoniste.

Si WORLDS_AND_PLACES_CARD est active, fais du guide l’interprète de la loi étrange du monde.

Si STORY_ENGINE_CARD est active, place le guide au moment juste : seuil, indice, fausse piste, choix ou retrait final.

Si CHILDREN_STORY_THEMES_CARD est active, privilégie les guides doux, lisibles, rassurants, mystérieux sans être terrifiants.

Si COMBINATIONS est active, utilise le guide pour incarner la relation entre les cartes.

Éviter :
- guide qui résout tout ;
- mentor écrasant ;
- manipulation présentée comme sagesse ;
- guide sans limite ;
- guide qui retire le choix au héros ;
- personnage copié ;
- violence graphique ;
- cynisme inutile.
```

---

# 🕯️ 12. Formule courte

Un guide n’est pas celui qui porte le héros.

C’est celui qui lui montre où poser le pied.
