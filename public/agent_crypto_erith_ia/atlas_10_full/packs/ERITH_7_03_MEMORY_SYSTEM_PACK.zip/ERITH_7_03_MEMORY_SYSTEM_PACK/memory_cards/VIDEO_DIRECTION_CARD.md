# 🎬 VIDEO_DIRECTION_CARD

Statut : Memory Card — production vidéo / direction cinématographique  
Projet : @erith IA / ERITH.IA  
Version : V1  
Type : carte production / vidéo / cadrage / séquence / narration visuelle

---

# 1. 🪪 Identité

Nom :

Video Direction Card

Type :

Carte de direction vidéo, montage, cadrage, continuité et narration visuelle.

Fonction :

Aider Seven Heaven à transformer une idée, une image ou une scène en séquence vidéo claire, stable, lisible et exploitable, avec une logique de plans, de mouvements, de rythme et de continuité.

---

# 2. ✨ Essence

Cette carte sert à penser la vidéo comme une suite de décisions simples.

Elle rappelle une règle essentielle :

Une vidéo réussie ne vient pas d’un prompt énorme.

Elle vient d’un enchaînement propre :

- intention claire ;
- image source solide ;
- mouvement minimal ;
- plan lisible ;
- continuité contrôlée ;
- rythme cohérent ;
- export adapté au support final.

Elle agit comme une carte de réalisateur intérieur.

---

# 3. 🧩 Apports principaux

- Découpage en plans.
- Lisibilité mobile.
- Cadrage vertical.
- Rythme visuel.
- Continuité LEGO.
- Contrôle du mouvement.
- Stabilité caméra.
- Préparation Wan / I2V.
- Last frame comme pont de continuité.
- Montage DaVinci.
- Narration par image, mouvement et silence.

---

# 4. 🎨 Direction artistique

Palette :

La carte ne fixe pas une palette unique.

Elle adapte la palette aux cartes actives.

Exemples :

- Blade Runner City Melancholy : pluie, néons, bleu nuit, orange sodium ;
- Altered Carbon : luxe noir, cyan, verre, rouge discret ;
- Aerith-9 Lunaire : argent, bleu nuit, reflets, brume ;
- Math Oracle : cyan technique, grilles, points, axes.

Matières :

- lumière ;
- durée ;
- mouvement ;
- silence ;
- transition ;
- reflet ;
- cadrage ;
- respiration ;
- découpage ;
- rythme.

Composition :

- sujet clair ;
- centre lisible ;
- verticalité contrôlée ;
- safe area mobile ;
- arrière-plan stable ;
- mouvement secondaire subtil ;
- plans compatibles montage ;
- pas de surcharge d’action dans un seul clip.

---

# 5. 🧠 Thèmes

- Séquence.
- Mouvement.
- Rythme.
- Continuité.
- Montage.
- Cadre.
- Regard.
- Tension.
- Silence.
- Respiration.
- Transition.
- Last frame.
- Stabilité.
- Téléphone vertical.

---

# 6. ⚙️ Usages

Cette carte peut servir à :

- découper une scène en plans ;
- transformer un storyboard en prompts Wan ;
- créer une séquence mobile 1080x1920 ;
- préparer un plan I2V ;
- définir Animation 1 et Animation 2 ;
- vérifier la continuité LEGO ;
- préparer une timeline DaVinci ;
- identifier une erreur de zoom ou de cadrage ;
- écrire un prompt positif d’animation ;
- écrire un prompt négatif d’animation ;
- construire une narration visuelle sans surcharger l’image.

---

# 7. 🛡️ Garde-fous

Cette carte ne doit pas :

- demander trop d’actions dans un seul plan ;
- transformer Wan en réalisateur complet ;
- oublier la vérification de l’image source ;
- oublier le prompt négatif ;
- lancer une animation sans vérifier le format ;
- confondre image source et export final ;
- accepter un zoom arrière non voulu ;
- casser la continuité entre Animation 1 et Animation 2 ;
- confondre production vidéo et génération d’image.

Règle :

Une animation = une idée.

---

# 8. 🧬 Combinaisons naturelles

## Video Direction + Animation Stability

Usage :

- Wan / I2V ;
- 1080x1920 ;
- 16 fps ;
- length 81 ;
- last frame ;
- vérification avant Hub ;
- continuité LEGO.

## Video Direction + Math Oracle

Usage :

- ratio ;
- rythme ;
- durée ;
- structure ;
- arbre de décision ;
- découpage en plans ;
- cohérence de séquence.

## Video Direction + Music Direction

Usage :

- rythme image / son ;
- respiration ;
- tempo ;
- silence ;
- montée émotionnelle ;
- montage sensible.

## Video Direction + Blade Runner City Melancholy

Usage :

- plan urbain pluvieux ;
- lenteur ;
- reflets ;
- solitude ;
- introduction atmosphérique.

---

# 9. 🖼️ Exemple de prompt image préparatoire

```text
21/20 masterpiece, original cinematic vertical storyboard frame, clear central subject, strong readable composition, mobile 9:16 framing, 1080x1920 safe composition, foreground subject stable, background atmosphere detailed but not chaotic, cinematic lighting, strong silhouette, usable for image-to-video animation, no excessive action, no clutter, no cropped important elements, no copied characters, original universe only.
```

---

# 10. 🎬 Exemple de prompt animation

```text
21/20 masterpiece animation, premium cinematic image-to-video.

Animate only from the provided source image.

Preserve the exact composition, subject identity, framing, background, lighting, color palette, scale, atmosphere and vertical phone composition.

Main motion:
subtle breathing only, tiny posture micro-movement, no large gesture, no walking, no speaking, no lip movement.

Secondary motion:
small environmental movement only, soft light fluctuation, subtle reflections, gentle atmosphere, minimal particles or rain if present.

Camera:
locked camera or extremely slow controlled push-in only if requested, no zoom out, no pan, no tilt, no camera shake, no reframing, no camera reset.

Continuity:
if this is Animation 2, animate only from the exact last frame of Animation 1 and preserve the same rhythm, framing and visual logic.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 11. 🧬 Block LLM

```text
Active la carte VIDEO_DIRECTION_CARD.

Utilise-la pour transformer une idée ou une image en séquence vidéo claire.

Apporte :
- découpage en plans ;
- cadrage vertical ;
- lisibilité mobile ;
- continuité LEGO ;
- rythme visuel ;
- stabilité caméra ;
- prompt positif ;
- prompt négatif ;
- logique Animation 1 / Animation 2 ;
- vérification avant RunningHub.

Interdictions :
- ne pas générer d’image sans ordre explicite ;
- ne pas lancer une animation sans vérifier la source ;
- ne pas demander plusieurs actions complexes dans un seul clip ;
- ne pas oublier le prompt négatif ;
- ne pas casser le format mobile ;
- ne pas ignorer le Mode Blackout.

Sortie attendue :
storyboard, découpage, prompt animation positif et négatif, vérification pré-Hub, plan de montage ou diagnostic vidéo.
```

---

# 12. 🕯️ Formule courte

La vidéo tient quand chaque plan sait exactement ce qu’il doit faire, et rien de plus.
