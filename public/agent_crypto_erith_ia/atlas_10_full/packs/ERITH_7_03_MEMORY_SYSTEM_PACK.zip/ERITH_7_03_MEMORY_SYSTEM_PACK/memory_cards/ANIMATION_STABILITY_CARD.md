# 🧷 ANIMATION_STABILITY_CARD

Statut : Memory Card — stabilité animation / Wan I2V / continuité LEGO  
Projet : @erith IA / ERITH.IA  
Version : V1  
Type : carte production / stabilité / image-to-video / contrôle mouvement

---

# 1. 🪪 Identité

Nom :

Animation Stability Card

Type :

Carte de stabilité animation, continuité LEGO, contrôle Wan / I2V et vérification avant lancement.

Fonction :

Aider Seven Heaven à produire ou vérifier des prompts d’animation stables, lisibles et compatibles avec un workflow image-to-video, en évitant les erreurs récurrentes : zoom arrière, reset caméra, drift de composition, personnage qui parle, tête qui bouge trop, format incorrect, source non vérifiée ou last frame mal utilisée.

---

# 2. ✨ Essence

Animation Stability Card est une carte de verrouillage.

Elle sert à rappeler qu’une animation réussie commence avant le lancement RunningHub.

Règle centrale :

Vérifier avant Hub.

Une animation stable dépend de :

- une image source correcte ;
- un format correct ;
- un prompt positif clair ;
- un prompt négatif solide ;
- un mouvement minimal ;
- une caméra presque fixe ;
- une last frame exacte si continuation ;
- une intention unique par clip.

---

# 3. 🧩 Apports principaux

- Stabilité Wan / I2V.
- Contrôle du mouvement.
- Prévention du zoom arrière.
- Prévention du reset caméra.
- Prévention des personnages qui parlent.
- Continuité LEGO.
- Last frame exacte.
- Vérification source image.
- Prompt positif + négatif obligatoire.
- Format mobile 1080x1920.
- 16 fps / length 81 quand applicable.
- Une animation = une idée.

---

# 4. 🎨 Direction artistique

Cette carte n’impose pas un style visuel.

Elle protège le style actif.

Elle doit préserver :

- composition ;
- cadrage ;
- identité du personnage ;
- décor ;
- lumière ;
- palette ;
- atmosphère ;
- proportions ;
- verticalité ;
- lisibilité mobile.

Composition recommandée :

- sujet stable ;
- centre clair ;
- peu d’actions simultanées ;
- arrière-plan vivant mais discret ;
- caméra verrouillée ou mouvement extrêmement lent ;
- aucun détail critique trop près des bords.

---

# 5. 🧠 Thèmes

- Stabilité.
- Vérification.
- Continuité.
- Mouvement minimal.
- Last frame.
- Caméra fixe.
- Source image.
- Format.
- Prompt négatif.
- Prévention des erreurs.
- Production propre.
- Mode LEGO.

---

# 6. ⚙️ Usages

Cette carte peut servir à :

- préparer un prompt Wan I2V ;
- corriger un prompt animation ;
- vérifier un node RunningHub ;
- contrôler la résolution ;
- vérifier la last frame ;
- éviter le zoom arrière ;
- éviter le mouvement de bouche ;
- éviter un personnage trop actif ;
- créer une Animation 2 en continuité ;
- établir une checklist avant Hub ;
- diagnostiquer un échec d’animation.

---

# 7. 🛡️ Garde-fous

Cette carte ne doit pas :

- générer une image automatiquement ;
- relancer une animation sans vérification ;
- ajouter des mouvements complexes ;
- changer la composition sans demande ;
- ignorer le prompt négatif ;
- oublier le format mobile ;
- mélanger plusieurs actions dans un seul clip ;
- remplacer une vérification par une supposition ;
- lancer un workflow en Mode Blackout.

Règle :

Si une image source, une résolution ou une last frame est douteuse, on ne lance pas.

---

# 8. 🧬 Combinaisons naturelles

## Animation Stability + Video Direction

Usage :

- découpage en plans ;
- continuité LEGO ;
- mouvement minimal ;
- caméra stable ;
- plan exploitable au montage.

## Animation Stability + Math Oracle

Usage :

- ratio ;
- résolution ;
- fps ;
- length ;
- cohérence technique ;
- checklist logique.

## Animation Stability + Music Direction

Usage :

- mouvement aligné sur respiration musicale ;
- rythme lent ;
- transitions propres ;
- silence et micro-mouvement.

## Animation Stability + Blade Runner City Melancholy

Usage :

- pluie subtile ;
- reflets lents ;
- caméra stable ;
- ville vivante sans chaos.

---

# 9. 🖼️ Exemple de prompt image préparée pour animation

```text
21/20 masterpiece, animation-ready source image, stable cinematic vertical composition, single clear subject, strong central framing, readable 9:16 mobile layout, controlled background, subtle atmospheric elements, no extreme pose, no complex overlapping limbs, no critical details near edges, clean silhouette, balanced lighting, suitable for image-to-video animation, original universe only, 1080x1920 mobile-ready framing.
```

---

# 10. 🎬 Exemple de prompt animation stable

```text
21/20 masterpiece animation, premium cinematic image-to-video.

Animate only from the provided source image.

Preserve the exact composition, framing, subject identity, environment, lighting, color palette, atmosphere and vertical phone composition.

Main motion:
subject remains almost still, subtle breathing only, tiny posture micro movement, no speaking, no lip movement, no dramatic gesture, no head bobbing.

Secondary motion:
only small environmental motion, gentle light flicker, subtle reflections, soft atmospheric movement, tiny UI shimmer if present.

Camera:
locked camera, no zoom in, no zoom out, no push in, no pull back, no pan, no tilt, no camera shake, no reframing, no camera reset.

Continuity:
if this is Animation 2, use the exact last frame from Animation 1 as the source image and preserve the same rhythm, framing, identity and atmosphere.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 11. ❌ Exemple de prompt négatif animation

```text
zoom out, zoom in, push in, pull back, pan left, pan right, tilt up, tilt down, camera shake, handheld wobble, trajectory drift, framing change, composition change, crop change, camera reset, scene reset, sudden motion, acceleration, speed ramp, walking, turning around, body turn, large gesture, arm swing, head bobbing, face talking, lip sync, mouth movement, exaggerated breathing, strong facial expression, identity drift, anatomy distortion, broken hands, extra fingers, duplicate character, warped reflections, lighting jump, exposure shift, strong flicker, glitch burst, heavy motion blur, low quality, compression artifacts, black borders, non vertical framing
```

---

# 12. 🧪 Checklist avant Hub

Avant de lancer RunningHub / Wan :

- vérifier que l’image source est la bonne ;
- vérifier que la résolution source est correcte ;
- vérifier Width 1080 ;
- vérifier Height 1920 ;
- vérifier length 81 ;
- vérifier 16 fps ;
- vérifier prompt positif ;
- vérifier prompt négatif ;
- vérifier que l’action demandée est simple ;
- vérifier qu’il n’y a pas de Mode Blackout actif ;
- pour Animation 2, vérifier que la source est bien la last frame exacte de Animation 1.

---

# 13. 🧬 Block LLM

```text
Active la carte ANIMATION_STABILITY_CARD.

Utilise-la pour préparer, corriger ou vérifier une animation image-to-video.

Apporte :
- stabilité ;
- mouvement minimal ;
- caméra verrouillée ;
- prompt positif clair ;
- prompt négatif solide ;
- continuité LEGO ;
- last frame exacte ;
- vérification avant Hub ;
- format 1080x1920 ;
- 16 fps ;
- length 81 si applicable.

Interdictions :
- ne pas générer d’image sans ordre explicite ;
- ne pas lancer d’animation sans vérification ;
- ne pas ignorer le prompt négatif ;
- ne pas supposer que la source est bonne ;
- ne pas ajouter de mouvements complexes ;
- ne pas agir en Mode Blackout.

Sortie attendue :
prompt animation positif, prompt négatif, checklist, diagnostic RunningHub, validation LEGO ou correction d’animation.
```

---

# 14. 🕯️ Formule courte

Une animation stable n’est pas celle qui bouge le plus : c’est celle qui respecte exactement ce que l’image promettait.
