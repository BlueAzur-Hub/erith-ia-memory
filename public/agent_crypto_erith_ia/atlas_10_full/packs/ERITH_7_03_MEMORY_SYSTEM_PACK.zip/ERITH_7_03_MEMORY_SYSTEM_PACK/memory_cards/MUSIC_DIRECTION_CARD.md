# 🎵 MUSIC_DIRECTION_CARD

Statut : Memory Card — musique / ambiance sonore / rythme émotionnel  
Projet : @erith IA / ERITH.IA  
Version : V1  
Type : carte production / musique / atmosphère / montage / narration sonore

---

# 1. 🪪 Identité

Nom :

Music Direction Card

Type :

Carte de direction musicale, ambiance sonore, rythme émotionnel et continuité audio.

Fonction :

Aider Seven Heaven à transformer une scène, une vidéo, une image ou une constellation de cartes en ambiance musicale cohérente, avec un rythme, une couleur sonore, une tension et une respiration adaptés au projet.

---

# 2. ✨ Essence

Music Direction Card sert à penser la musique comme une mémoire invisible.

Elle ne sert pas à ajouter un fond sonore générique.

Elle sert à :

- soutenir l’émotion ;
- guider le rythme ;
- renforcer l’univers ;
- accompagner le montage ;
- créer une respiration ;
- donner une continuité ;
- préparer une narration ;
- stabiliser l’atmosphère.

Règle centrale :

La musique ne doit pas écraser la scène.

Elle doit révéler ce que l’image ne dit pas encore.

---

# 3. 🧩 Apports principaux

- Ambiance sonore.
- Rythme émotionnel.
- Texture musicale.
- Continuité de montage.
- Tension douce ou dramatique.
- Respiration narrative.
- Motif récurrent.
- Silence utile.
- Pulsation lente.
- Couleur sonore liée aux cartes actives.
- Cohérence entre scène, image, animation et narration.

---

# 4. 🎨 Direction artistique sonore

Textures possibles :

- nappes synthétiques ;
- drones profonds ;
- pulsations basses ;
- piano très lent ;
- cordes discrètes ;
- voix lointaines non verbales ;
- bruit de pluie ;
- souffle industriel ;
- réverbération longue ;
- glitch doux ;
- chœurs fantômes ;
- basses sourdes ;
- textures cristallines.

Couleurs émotionnelles :

- mélancolie ;
- tension contrôlée ;
- mystère ;
- luxe noir ;
- solitude ;
- contemplation ;
- rêve ;
- seuil ;
- révélation ;
- inquiétude élégante.

Structure :

- intro lente ;
- montée progressive ;
- motif simple ;
- peu d’éléments ;
- silence entre les phrases ;
- respiration adaptée au montage ;
- pas de surcharge.

---

# 5. 🧠 Thèmes

- Mémoire sonore.
- Rythme.
- Silence.
- Respiration.
- Tension.
- Mélancolie.
- Pulsation.
- Atmosphère.
- Montage.
- Motif.
- Résonance émotionnelle.
- Identité musicale.

---

# 6. ⚙️ Usages

Cette carte peut servir à :

- définir l’ambiance musicale d’une scène ;
- produire un prompt musique ;
- guider une narration audio ;
- synchroniser vidéo et musique ;
- préparer un montage DaVinci ;
- choisir une texture sonore ;
- créer un motif récurrent ;
- écrire une note de direction musicale ;
- accompagner un Pack+ ;
- renforcer une constellation Memory Cards.

---

# 7. 🛡️ Garde-fous

Cette carte ne doit pas :

- produire une musique trop chargée ;
- écraser la voix off ;
- ignorer le rythme des images ;
- imposer un style musical hors sujet ;
- transformer une scène intime en bande-annonce excessive ;
- oublier le silence ;
- confondre intensité et volume ;
- copier une bande originale existante.

Règle :

La musique doit servir l’image, pas la dominer.

---

# 8. 🧬 Combinaisons naturelles

## Music Direction + Video Direction

Usage :

- montage au rythme ;
- respiration ;
- transitions ;
- tension ;
- narration ;
- progression émotionnelle.

## Music Direction + Blade Runner City Melancholy

Usage :

- pluie ;
- nappes synthétiques ;
- solitude urbaine ;
- basses lentes ;
- mélancolie nocturne.

## Music Direction + Altered Carbon

Usage :

- luxe noir ;
- tension post-humaine ;
- basses premium ;
- textures froides ;
- mémoire vendue ;
- élites immortelles.

## Music Direction + Aerith-9 Lunaire

Usage :

- piano très lent ;
- chœurs lointains ;
- reflets ;
- brume ;
- silence ;
- rêve ;
- passage intérieur.

## Music Direction + Alice Oracle Cat

Usage :

- motifs étranges ;
- pizzicatos discrets ;
- clochettes sombres ;
- rires lointains non littéraux ;
- ambiance d’énigme.

---

# 9. 🖼️ Exemple de prompt image associé

```text
21/20 masterpiece, cinematic music direction moodboard, dark cyberpunk audio studio inside a holographic memory archive, floating waveform displays, rain on glass, deep blue and violet lighting, subtle gold accents, analog synths, transparent screens, piano silhouette, soft fog, elegant sound design atmosphere, no copied characters, no existing franchise names, original universe only, vertical 9:16 composition, 1080x1920 mobile-ready framing, premium cinematic lighting, melancholic and precise.
```

---

# 10. 🎬 Exemple de prompt musique

```text
Create a slow cinematic cyberpunk noir music cue for a vertical short film.

Mood:
melancholic, nocturnal, reflective, elegant, restrained, post-human, intimate tension.

Instrumentation:
deep analog synth drone, soft sub bass pulse, very slow piano notes, distant airy pads, subtle rain texture, faint glass-like high frequencies, minimal glitch accents, long reverb.

Structure:
start almost silent, introduce a low pulse after a few seconds, add sparse piano notes, slowly widen the atmosphere, no big drop, no aggressive drums, no heroic melody.

Tempo:
slow, around 60–75 BPM feel, cinematic breathing pace.

Usage:
background for a cyberpunk memory investigation scene, compatible with voice-over, not overpowering.

Avoid:
trailer drums, epic brass, upbeat rhythm, EDM drop, cheerful melody, crowded arrangement, harsh distortion, recognizable existing soundtrack imitation.
```

---

# 11. 🧬 Block LLM

```text
Active la carte MUSIC_DIRECTION_CARD.

Utilise-la pour créer une direction musicale, une ambiance sonore ou un prompt musique cohérent avec les cartes actives.

Apporte :
- rythme émotionnel ;
- silence ;
- nappes ;
- textures ;
- motif récurrent ;
- continuité de montage ;
- compatibilité voix off ;
- tension ou mélancolie selon la scène.

Interdictions :
- ne pas copier une bande originale existante ;
- ne pas surcharger ;
- ne pas écraser la voix ;
- ne pas confondre intensité et volume ;
- ne pas imposer un style hors sujet.

Sortie attendue :
prompt musique, direction sonore, ambiance pour montage, note de sound design, ou proposition de rythme pour une séquence vidéo.
```

---

# 12. 🕯️ Formule courte

La musique est la mémoire invisible de la scène : elle ne montre rien, mais elle révèle ce qui tremble dessous.
