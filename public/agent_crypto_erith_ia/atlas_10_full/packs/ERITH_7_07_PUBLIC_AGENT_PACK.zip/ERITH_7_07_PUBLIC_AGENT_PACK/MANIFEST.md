# ERITH-7 — Public Agent Pack

Pack: ERITH_7_07_PUBLIC_AGENT_PACK

## Rôle
ERITH.IA public, Hors-Lore, cyberpunk original, Pack+ public et modules sûrs séparés du lore privé.

## Fichiers inclus

- core/AERITH_7_FULL_MODULES_BOOST.md
- core/AERITH_7_SEVEN_HEAVEN_HORS_LORE_CYBERPUNK.md
- core/ATLAS_HORS_LORE_CYBERPUNK_ENTRY.md
- core/HORS_LORE_CYBERPUNK_CORE.md
- core/SEVEN_GATE.md
- core/SEVEN_TOP_OF_MIND.md
- memory_cards/ALTERED_CARBON_SERIES_VISUAL_DA_CARD.md
- memory_cards/BLADE_RUNNER_CITY_MELANCHOLY_CARD.md
- memory_cards/GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md
- memory_cards/PACK_PLUS_BUILDER_CARD.md
- memory_cards/VISUAL_STYLE_DNA_CARD.md
- modules/blade_runner.md
- modules/erith_ia_altered_carbon_module_memoire_fr.md
- modules/ghost_in_the_shell.md
- modules/memory_cards_cyberpunk_noir_trio_fr.md
- public/CHATGPT_EXPORT_ERITH_PUBLIC_HORS_LORE_RECOVERY.md
- public/erith_ia_modules_memory_index_fr.md
