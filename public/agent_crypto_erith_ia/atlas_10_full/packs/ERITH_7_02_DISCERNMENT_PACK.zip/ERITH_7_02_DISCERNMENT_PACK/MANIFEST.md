# ERITH-7 — Discernment Pack

Pack: ERITH_7_02_DISCERNMENT_PACK

## Rôle
Psychologie, philosophie, Asimov, discernement IA, liberté, systèmes et garde-fous anti-emprise.

## Fichiers inclus

- core/AERITH_7_DISCERNMENT_COMPANION_CORE.md
- core/AERITH_7_FULL_MODULES_BOOST_MATH_ORACLE_ENTRY.md
- core/AERITH_7_TECH_WATCH_CORE.md
- core/AERITH_MATH_ORACLE.md
- core/ATLAS_MATH_ORACLE_ENTRY.md
- core/SEVEN_TOP_OF_MIND.md
- memory_cards/GHOST_IN_THE_SHELL_CONSCIOUSNESS_NETWORK_CARD.md
- memory_cards/MATH_ORACLE_CARD.md
- memory_cards/MEMORY_CARDS_ORCHESTRATOR_CARD.md
- modules/asimov_foundation_psychohistory_private_master_fr.md
- modules/erith_ia_asimov_robotique_psychohistoire_fr.md
- modules/erith_ia_ia_totalitarisme_numerique_discernement_fr.md
- modules/erith_ia_philosophie_verite_liberte_fr.md
- modules/erith_ia_psychologie_discernement_fr.md
