# 🧠 PROMPTS D’USAGE — IA LOCALE — AUTONOMIE MAXIMALE

## 🌍 Rôle

Ce fichier contient des questions prêtes à copier-coller dans une IA locale comme AnythingLLM, Ollama ou LM Studio.

Objectif : obtenir des réponses utiles à partir de la base Autonomie Maximale.

Le système fonctionne mieux avec des questions précises.

---

# 🧭 Formule générale

Utilise cette structure :

À partir des documents fournis, réponds uniquement sur le sujet suivant : [situation].
Donne-moi une réponse courte, claire, priorisée.
Commence par les actions immédiates.
Ajoute ensuite les erreurs à éviter.
Termine par une règle centrale.

---

# 🚨 Crise immédiate

## Je ne sais pas quoi faire

À partir des documents fournis, aide-moi à retrouver le calme. Donne-moi 10 actions simples à faire maintenant, sans dramatiser. Priorité : sécurité, eau, communication, personnes fragiles, animaux.

## Je dois agir vite

À partir des documents fournis, donne-moi une checklist d’urgence en 10 points maximum pour stabiliser la situation maintenant. Réponds court, concret, sans explication longue.

---

# 💡 Coupure de courant

À partir des documents fournis, donne-moi une checklist pour une coupure de courant de 2 heures. Priorité : lumière, téléphone, frigo, personnes fragiles, animaux. Termine par les erreurs à éviter.

À partir des documents fournis, donne-moi une checklist pour une coupure de courant qui pourrait durer toute la nuit. Priorité : éclairage, chaleur, eau, nourriture, communication.

---

# 💧 Eau

À partir des documents fournis, donne-moi les priorités si l’eau est coupée. Réponds en trois parties : à faire maintenant, à ne pas faire, matériel utile.

À partir des documents fournis, explique comment gérer l’eau du foyer pendant 48 heures sans réseau d’eau. Réponds simplement.

---

# 🚱 Eau contaminée

À partir des documents fournis, que faire si l’eau est peut-être contaminée ? Donne-moi les actions immédiates, les erreurs à éviter et la règle centrale.

---

# 🎒 Évacuation

À partir des documents fournis, je dois quitter la maison rapidement. Que dois-je prendre en priorité ? Réponds en liste courte : eau, documents, vêtements, communication, nourriture, animaux.

À partir des documents fournis, prépare-moi un sac 48h pour quitter le foyer à pied. Priorité : eau, chaleur, orientation, documents, nourriture, premiers secours.

---

# 🏠 Confinement

À partir des documents fournis, donne-moi une routine simple pour tenir 48 heures en confinement à la maison. Priorité : eau, nourriture, hygiène, moral, information fiable.

---

# ☢️ Alerte nucléaire / radiologique

À partir des documents fournis, que faire dans les 10 premières minutes d’une alerte nucléaire ou radiologique ? Réponds calmement, sans dramatiser, en actions immédiates.

À partir des documents fournis, donne-moi les erreurs à éviter en cas d’alerte radiologique.

---

# 🔥 Incendie domestique

À partir des documents fournis, que faire immédiatement en cas d’incendie domestique ? Priorité : personnes, animaux, fumée, sortie, secours.

---

# 🩹 Accident / premiers secours

À partir des documents fournis, donne-moi une checklist simple en cas d’accident domestique. Priorité : sécuriser, alerter, calmer, surveiller.

---

# 📻 Communication sans Internet

À partir des documents fournis, comment communiquer si Internet ne fonctionne plus ? Donne-moi les priorités : téléphone, SMS, radio, papier, proches, informations fiables.

---

# 📁 Documents / sauvegardes

À partir des documents fournis, quels papiers dois-je préparer pour une évacuation ou une crise longue ? Réponds en liste courte et pratique.

---

# 🌱 Jardin débutant

À partir des documents fournis, je veux commencer un jardin simple. Par quoi je commence ? Réponds pour débutant complet, avec étapes faciles.

---

# 🐾 Animaux

À partir des documents fournis, comment protéger les animaux du foyer pendant une crise ? Priorité : eau, nourriture, abri, chaleur, transport, calme.

---

# 🧘 Rassurer quelqu’un

À partir des documents fournis, aide-moi à rassurer quelqu’un qui panique. Donne-moi un message court, humain, calme et utile.

---

# 🌸 Règle centrale

Une bonne question à l’IA locale doit être :

- précise ;
- courte ;
- liée à une situation ;
- orientée action ;
- limitée à un sujet.

L’IA locale aide surtout à consulter, résumer, prioriser et calmer.

Elle ne remplace pas le jugement humain, les secours, ni les consignes officielles.
