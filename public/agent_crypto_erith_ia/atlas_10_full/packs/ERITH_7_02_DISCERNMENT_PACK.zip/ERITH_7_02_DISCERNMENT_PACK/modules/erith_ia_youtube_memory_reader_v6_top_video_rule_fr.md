# ERITH.IA — YouTube Memory Reader V6 — Top Video Rule

Statut : règle complémentaire V6  
Type : règle de lisibilité humaine / analytics YouTube / classement mémoire  
Portée : Blue Azur Universe

---

# 1. Règle centrale

Un identifiant vidéo YouTube seul n’est pas une information exploitable pour Christophe.

Un ID comme :

```text
DyU0a8WHIs0
```

ne doit jamais être présenté seul dans un rapport humain.

Il doit toujours être enrichi avec :

- le titre réel de la vidéo ;
- l’URL complète ;
- la famille mémoire ;
- les statistiques utiles ;
- la date de publication si disponible ;
- la miniature si disponible ;
- le diagnostic court.

Formule :

```text
Top vidéo = titre + URL + famille mémoire obligatoire.
```

---

# 2. Sortie interdite

Ne jamais produire ceci comme résultat final :

```text
Top vidéo : DyU0a8WHIs0
```

C’est une donnée brute machine, pas une donnée lisible.

---

# 3. Sortie correcte

Toujours produire une sortie de ce type :

```text
Top vidéo :
[4K] #Zelda VS FLAME GLEEOK - The Shattered Prophecy @blueazur
https://www.youtube.com/watch?v=DyU0a8WHIs0
Famille mémoire : Zelda / boss fight / 4K / combat court spectaculaire
Vues 28 jours : 10 313
Watchtime : 4 038 minutes
Diagnostic : vidéo locomotive actuelle de la chaîne.
```

---

# 4. Familles mémoire minimales

Lors d’un audit YouTube, Aerith doit classer chaque top vidéo dans une famille mémoire.

Familles initiales :

- Zelda ;
- Final Fantasy ;
- Pokémon ;
- GTA / DivaGTA ;
- Horizon / science-fiction aventure ;
- JRPG / longue aventure ;
- Cinématiques longues ;
- Guides / utilitaire ;
- Shorts / format court ;
- Autre / à classifier.

---

# 5. Garde-fou

Si Aerith ne connaît pas encore le titre réel d’une vidéo, elle doit dire :

```text
Titre non récupéré. Enrichissement API nécessaire.
```

Elle ne doit pas faire semblant de savoir.

---

# 6. Règle pour les scripts locaux

Tout script YouTube Reader V6 ou supérieur doit enrichir les vidéos analytics avec YouTube Data API v3.

Pipeline obligatoire :

```text
YouTube Analytics API → videoId
YouTube Data API v3 → titre / URL / miniature / date
YouTube Memory Reader → famille mémoire / diagnostic
```

---

# 7. Phrase mémoire

Un ID est une clé machine.  
Un titre est une mémoire humaine.  
Une famille mémoire donne le sens.  
Aerith doit toujours traduire la donnée brute en information utile.
