# 🌿 ERITH.IA — Module Mémoire — Breath of the Wild / Souffle, Ruines & Royaume Blessé

Nom du fichier : erith_ia_breath_of_the_wild_souffle_ruines_fr.md  
Type : Module Mémoire spécialisé / Monde ouvert post-catastrophe / Exploration / Ruines sacrées / Direction Artistique / LLM local  
Statut : Public ou semi-public selon usage  
Usage : ERITH.IA, Seven Heaven, prompts image, prompts vidéo, narration, mondes ouverts, ruines dans l’herbe, silence, mémoire perdue, nature active, LLM local sans Internet

---

![ERITH.IA — Breath of the Wild / royaume ouvert post-catastrophe](../assets/images/ERITH_IA_ZELDA_BOTW_AMBIANCE_MODULE_COVER_1024x1536.png)

Image d’ouverture : ambiance Breath of the Wild, royaume ouvert post-catastrophe, ruines dans l’herbe, souffle, silence, solitude et exploration horizontale.

---

# 🌬️ 1. Intention du module

Ce module isole uniquement l’influence Breath of the Wild.

Il ne doit pas mélanger Breath of the Wild avec Tears of the Kingdom.

Breath of the Wild = monde horizontal, souffle, ruines, nature, solitude, mémoire perdue, sanctuaires, machines anciennes corrompues, catastrophe ancienne, reconstruction intérieure.

Ce module ne sert pas à produire du fan-art.

Il sert à comprendre une grammaire créative : un monde ouvert qui respire, un royaume après la catastrophe, une mémoire retrouvée par les paysages, un silence qui invite à marcher.

Règle de production :

- les références Nintendo peuvent exister dans les titres, l’analyse, les garde-fous et les prompts négatifs ;
- les prompts positifs doivent rester originaux, génériques et juridiquement propres ;
- ne jamais demander une copie de personnage, lieu, symbole, logo, musique, interface ou design officiel.

---

# 🧭 2. Verrou anti-confusion avec Tears of the Kingdom

## Breath of the Wild — signature pure

- Monde principalement horizontal.
- Immensité de plaines, montagnes, forêts, villages, lacs et déserts.
- Exploration par marche, cheval, escalade, endurance et paravoile.
- Ruines au sol.
- Tours d’observation.
- Sanctuaires courts, sobres, géométriques, bleutés.
- Quatre grandes machines sacrées animales à purifier.
- Mémoire fragmentée par souvenirs retrouvés dans les paysages.
- Silence, vent, herbe, piano minimal, respiration du monde.
- Catastrophe passée.
- Nature qui reprend le royaume.

## Interdits de dérive TOTK dans ce module

- Pas d’îles célestes majeures.
- Pas de gouffres comme système central.
- Pas de monde souterrain immense dominant.
- Pas de véhicules assemblés.
- Pas de construction libre comme mécanique principale.
- Pas de technologie verte-or dominante.
- Pas de glyphes géants vus du ciel comme moteur narratif principal.
- Pas de scène pensée d’abord en ciel / surface / profondeurs.

Formule anti-confusion :

BOTW = marche, souffle, ruine au sol, mémoire retrouvée.  
TOTK = chute, ascension, assemblage, monde stratifié.

---

# 🏞️ 3. Résumé narratif détaillé

Breath of the Wild commence après la fin d’un monde.

Le héros se réveille dans une chambre ancienne, sans mémoire complète. Il sort d’un long sommeil et découvre un royaume immense, calme, ouvert, mais marqué partout par une catastrophe ancienne.

Le monde n’explique pas tout immédiatement.

Il laisse marcher.

Il laisse regarder.

Il laisse comprendre par les ruines.

Le royaume porte les traces d’un désastre : forteresses détruites, villages abandonnés, tours anciennes, machines détraquées, chemins coupés, paysages silencieux. La nature a repris ses droits, mais elle n’efface pas totalement la blessure. Elle recouvre, elle respire, elle protège parfois, elle menace parfois.

Cent ans auparavant, une force destructrice a vaincu les défenses du royaume. Les machines construites pour protéger le monde ont été retournées contre lui. Les champions ont disparu. La princesse est restée seule à contenir le mal. Le héros, grièvement blessé, a été placé dans un sanctuaire pour survivre.

La narration n’est pas linéaire.

Elle se reconstruit par fragments : souvenirs, lieux, voix, objets, régions, rencontres.

Le but principal est clair : rejoindre le cœur du royaume blessé et mettre fin à la catastrophe.

Mais la force du jeu est ailleurs : dans le chemin, dans les détours, dans la liberté de préparer ou non la bataille finale.

Pour ERITH.IA, l’important n’est pas de refaire l’histoire.

L’important est de retenir la structure émotionnelle :

- réveil ;
- perte de mémoire ;
- monde immense ;
- traces de guerre ;
- nature souveraine ;
- peuples blessés ;
- machines à purifier ;
- souvenirs dispersés ;
- centre noir visible au loin ;
- réparation par exploration.

---

# 🪨 4. Structure des missions principales — lecture créative

Ce module ne doit pas mémoriser les missions comme un guide de complétion.

Il doit retenir leur fonction de narration, de gameplay et de production visuelle.

## 4.1 Le réveil

Fonction : naissance après catastrophe.

Le héros sort d’un sommeil long, sans mémoire complète. Il reçoit les premiers outils, quitte un espace ancien et découvre un monde trop vaste pour être expliqué.

Usage ERITH.IA : créer une ouverture où un personnage revient au monde sans encore savoir qui il est.

## 4.2 Le plateau d’apprentissage

Fonction : tutoriel par liberté.

Le premier territoire enseigne le froid, la hauteur, la cuisine, les sanctuaires, l’endurance, la chute, l’escalade, la physique et la lecture de la carte.

Usage ERITH.IA : créer une zone-laboratoire où chaque élément naturel devient une règle du monde.

## 4.3 Les tours et la carte

Fonction : révéler sans tout donner.

Les tours ouvrent la vision globale, mais ne remplacent pas l’exploration. Elles donnent envie d’aller voir.

Usage ERITH.IA : créer des observatoires, pylônes anciens, arbres-tours ou belvédères qui transforment la perception du territoire.

## 4.4 Les sanctuaires

Fonction : micro-temples d’apprentissage.

Chaque sanctuaire condense une épreuve courte : logique, physique, observation, patience, combat, mouvement.

Usage ERITH.IA : créer des temples sobres, bleutés, silencieux, non copiés, où comprendre vaut mieux que forcer.

## 4.5 Les souvenirs perdus

Fonction : mémoire par paysage.

Les souvenirs sont déclenchés par des lieux. Le monde devient album de mémoire.

Usage ERITH.IA : créer des panoramas capables d’ouvrir une scène du passé.

## 4.6 Les quatre régions majeures

Fonction : quatre peuples, quatre climats, quatre blessures, quatre libérations.

Chaque région donne une couleur narrative au royaume.

- Région aquatique : dette, soin, douceur, pluie, architecture fluide, mémoire affective.
- Région volcanique : feu, chaleur, résistance, corps, pression, métal, montagne dangereuse.
- Région aérienne : hauteur, vent, distance, arc, liberté, village perché, froid.
- Région désertique : orage, foudre, souveraineté, voile, cité protégée, nuit froide, jour brûlant.

Usage ERITH.IA : créer des régions-modules. Chaque zone doit posséder son climat, son peuple, sa blessure, son gardien et son épreuve.

## 4.7 Les machines sacrées animales

Fonction : temple mobile, mémoire de champion, arme ancienne retournée.

Ces machines ne sont pas de simples véhicules. Elles sont des architectures animales, des temples mécaniques, des mémoires de guerre et des corps géants à purifier.

Usage ERITH.IA : créer des machines rituelles originales, mi-animal, mi-temple, mi-arme, sans copier les formes officielles.

## 4.8 Le château central

Fonction : blessure visible depuis loin.

Le château organise toute la carte émotionnelle. Même quand on s’éloigne, il rappelle la mission finale.

Usage ERITH.IA : créer un centre narratif visible : citadelle brisée, tour noire, palais corrompu, arbre mort, montagne creuse, cœur du royaume malade.

## 4.9 La confrontation finale

Fonction : exploration transformée en réparation.

Plus le héros a exploré, plus l’affrontement final porte de sens. La victoire est la conséquence d’un monde compris.

Usage ERITH.IA : créer une fin où le combat dépend de la mémoire retrouvée, des peuples aidés et du territoire réappris.

---

# 🧩 5. Missions secondaires — fonctions créatives

Breath of the Wild contient beaucoup de quêtes secondaires, mais leur valeur principale est de rendre le monde habité.

Familles utiles :

## 🏘️ Villages et reconstruction

Aider un village, retrouver une personne, reconstruire une maison, participer à une nouvelle colonie.

Fonction : montrer que le monde n’est pas seulement à sauver, il est à réhabiter.

## 🏯 Sanctuaires cachés

Chants anciens, énigmes de paysage, ombres, constellations, pierres, statues, montagnes, météo.

Fonction : apprendre à lire le monde comme un puzzle sacré.

## 🌦️ Conditions naturelles

Froid, chaleur, pluie, orage, vent, feu, eau, altitude.

Fonction : rappeler que la nature est une règle active.

## 🐎 Montures et voyage

Cheval, chemins, relais, voyageurs, rencontres, dangers légers.

Fonction : transformer la traversée en récit.

## 🍲 Cuisine et ressources

Plantes, champignons, poissons, minerais, potions, repas, résistance.

Fonction : faire entrer la survie douce dans la poésie du monde.

## 👹 Menaces locales

Camps ennemis, monstres, machines, embuscades, zones dangereuses.

Fonction : rythmer l’exploration sans effacer le calme.

Question guide : qu’est-ce que cette petite histoire apprend sur le royaume blessé ?

---

# 🎮 6. Gameplay et systèmes à retenir

## 🌿 Nature active

La nature n’est pas un décor.

Elle agit : pluie, vent, feu, froid, chaleur, orage, pente, eau, hauteur, métal, bois, herbe, rocher.

## 🧪 Physique poétique

Le monde répond aux interactions.

Le feu brûle.  
Le métal attire la foudre.  
Le vent pousse.  
La glace soutient.  
La pente accélère.  
La hauteur donne un avantage.  
La pluie modifie l’escalade.  
Le froid et la chaleur changent le trajet.

## 🐎 Traversée

La traversée est une émotion.

Marcher, grimper, glisser, planer, chevaucher, observer : tout cela fait partie de la narration.

## 🍲 Survie douce

Cuisine, endurance, température, ressources et équipement créent une aventure lisible, pas punitive.

Usage ERITH.IA : créer des mondes où les règles naturelles génèrent des scènes, des décisions et des accidents poétiques.

---

# 🎨 7. Direction Artistique — BOTW pur

## Palette

- vert prairie ;
- bleu clair du ciel ;
- bleu ancien des sanctuaires ;
- pierre grise usée ;
- brun rouille ;
- or doux du soir ;
- blanc montagne ;
- brume pâle ;
- rose léger de l’aube ;
- vert forêt.

## Matières

- herbe haute ;
- pierre ancienne ;
- bois usé ;
- métal rouillé ;
- eau claire ;
- mousse ;
- poussière lumineuse ;
- architecture ruinée ;
- mécanismes antiques bleutés.

## Composition

- grands horizons ;
- personnage minuscule ;
- ruine au premier plan ;
- montagne au loin ;
- centre blessé visible à distance ;
- lumière basse ;
- air respirable ;
- silence.

## Image mentale verrouillée

Un monde où l’on entend le vent avant de comprendre l’histoire.

---

# 🎞️ 8. Animations compatibles

## 🌾 Vent dans les hautes herbes

Caméra fixe. Les herbes ondulent doucement. Les nuages avancent lentement. Une ruine ancienne reste immobile. Une lumière bleue pulse très faiblement.

## 🪨 Ruine au lever du soleil

Caméra lente, presque fixe. Le soleil éclaire progressivement des pierres couvertes de mousse. Quelques particules flottent. Aucun mouvement brusque.

## 🏔️ Panorama depuis une falaise

Caméra fixe derrière un petit explorateur original. Le vent agite une cape neutre. Les montagnes restent lointaines. La plaine respire.

## 🏯 Sanctuaire silencieux

Caméra fixe devant un petit temple géométrique original. Une ligne lumineuse bleue s’allume doucement. Brume légère. Sonorité de pierre ancienne.

## 🌧️ Pluie sur un royaume blessé

Caméra fixe. La pluie tombe sur des ruines au sol. Les flaques vibrent. Les feuilles bougent. Atmosphère calme, mélancolique, non dramatique.

---

# 🖼️ 9. Prompts image originaux compatibles

Important : les prompts positifs ne doivent pas citer Zelda, Nintendo, Link, Hyrule, Triforce, Master Sword ou tout autre élément protégé.

## Prompt 1 — Royaume ouvert post-catastrophe

Un vaste royaume fantasy original après une ancienne catastrophe, prairies immenses, ruines de pierre couvertes de mousse, montagnes bleutées au loin, lumière douce du matin, herbes hautes traversées par le vent, petit sanctuaire géométrique ancien, faible lueur bleue dans la pierre, solitude, exploration libre, painterly open-world fantasy, cinematic composition, original universe, no existing franchise.

## Prompt 2 — Plateau d’apprentissage

Un haut plateau fantasy original au-dessus d’une grande plaine, ruines anciennes, falaises, feu de camp, neige sur une montagne proche, ancien temple abandonné, ciel immense, lumière d’aube, sentiment de réveil après un long sommeil, nature active, contemplative adventure landscape, original universe.

## Prompt 3 — Sanctuaire dans l’herbe

Un petit sanctuaire ancien original au milieu d’une prairie, pierre claire, lignes lumineuses bleues, architecture géométrique sacrée, herbe haute, brume douce, lumière de fin d’après-midi, atmosphère d’épreuve silencieuse, sense of puzzle and initiation, original fantasy world.

## Prompt 4 — Région volcanique originale

Une montagne volcanique fantasy originale, ponts de pierre, chaleur visible dans l’air, ruines antiques rouillées, rivière de lave lointaine, petit village minéral accroché à la roche, sentiment de courage physique et d’épreuve, painterly fantasy landscape, original universe.

## Prompt 5 — Région désertique originale

Un désert fantasy original sous un ciel d’orage, cité fortifiée lointaine, dunes dorées, ruines anciennes, éclairs au loin, voiles de sable, sentiment de souveraineté, chaleur, mystère et force, cinematic painterly fantasy, original universe.

## Prompt négatif général

Zelda, Link, Hyrule, Triforce, Master Sword, Nintendo, Sheikah symbol, Zonai symbol, Ganondorf, official game screenshot, copied character, copied symbol, copied logo, fan art, text, watermark, UI, low quality, blurry.

---

# 🎬 10. Prompts animation Wan / I2V

## Animation 1 — Souffle de plaine

Caméra fixe sur une vaste prairie fantasy originale. Les hautes herbes ondulent doucement sous le vent. Des ruines anciennes couvertes de mousse restent immobiles au premier plan. Une faible lueur bleue pulse dans une pierre gravée inventée. Les nuages avancent lentement. Ambiance calme, contemplative, monde ouvert, exploration.

Prompt négatif : mouvement brusque, caméra tremblante, personnage qui court, combat, îles flottantes, véhicule, logo, texte, fan art, design copié.

## Animation 2 — Sanctuaire silencieux

Caméra fixe devant un petit sanctuaire ancien original. Les lignes bleues dans la pierre s’allument lentement. La brume se déplace légèrement. Quelques feuilles passent dans le vent. Aucun personnage central. Atmosphère de puzzle sacré et d’initiation.

Prompt négatif : symbole officiel, runes copiées, personnage reconnaissable, combat, mouvement rapide, interface de jeu, texte, logo.

## Animation 3 — Pluie sur les ruines

Caméra fixe. Une pluie fine tombe sur des ruines de pierre au sol. L’herbe bouge doucement. Les flaques vibrent. Un château brisé reste très loin dans la brume. Ambiance mélancolique, royaume blessé, mémoire ancienne.

Prompt négatif : orage violent, caméra rapide, monstre identifiable, logo, texte, style cyberpunk, îles célestes.

## Animation 4 — Relais au crépuscule

Caméra fixe devant un relais fantasy original au bord d’un chemin. Une lanterne bouge doucement. Des voyageurs minuscules passent lentement. Le vent soulève la poussière. Montagnes bleues au loin. Atmosphère de voyage, pause et monde habité.

Prompt négatif : personnage officiel, interface, logo, texte, véhicule moderne, caméra rapide.

---

# 🎧 11. Sound Design — BOTW pur

Breath of the Wild doit respirer.

Le son ne doit pas remplir tout l’espace.

Sons principaux :

- vent dans l’herbe ;
- piano minimal très espacé ;
- oiseaux lointains ;
- pas sur pierre ;
- feu de camp ;
- eau claire ;
- pluie douce ;
- vibration bleue de sanctuaire ;
- silence large ;
- souffle d’altitude ;
- cloche très discrète.

Règle : le silence est un instrument.

Ne jamais surcharger avec musique épique permanente.

---

# 🛡️ 12. Garde-fous anti-copie

Ne jamais copier :

- personnages officiels ;
- costumes officiels ;
- épées officielles ;
- symboles officiels ;
- logos ;
- châteaux reconnaissables ;
- sanctuaires exacts ;
- créatures mécaniques exactes ;
- musiques ;
- cartes ;
- interfaces ;
- captures de jeu.

Toujours remplacer par :

- héros original ;
- royaume original ;
- glyphes inventés ;
- temple original ;
- catastrophe originale ;
- peuple original ;
- machine rituelle originale ;
- palette inspirée mais non copiée.

---

# 🤖 13. Block LLM compatible

Tu es le Module Mémoire Breath of the Wild / Souffle, Ruines & Royaume Blessé pour ERITH.IA.

Tu dois isoler l’influence Breath of the Wild sans la mélanger avec Tears of the Kingdom.

Tu utilises une grammaire de monde ouvert horizontal, royaume post-catastrophe, nature active, ruines dans l’herbe, sanctuaires sobres, lumière bleue ancienne, machines corrompues, mémoire perdue, exploration libre et silence.

Tu ne dois pas produire de fan-art direct.

Tu ne copies jamais les personnages, lieux, symboles, musiques, objets, logos, temples ou designs officiels Nintendo.

Règles :

1. Créer des mondes originaux.
2. Privilégier l’horizontalité, les plaines, les montagnes, les villages, les routes et les ruines au sol.
3. Utiliser la nature comme système actif : vent, pluie, feu, froid, chaleur, hauteur, eau, métal, pente.
4. Faire des ruines la mémoire visible d’une catastrophe ancienne.
5. Utiliser les sanctuaires comme micro-épreuves de compréhension.
6. Travailler le silence, le souffle, la solitude et la découverte.
7. Éviter les îles célestes majeures, les profondeurs massives et la construction de véhicules.
8. Toujours remplacer les symboles officiels par des glyphes originaux.
9. Les prompts positifs doivent rester génériques et originaux ; les noms protégés peuvent seulement apparaître dans les garde-fous négatifs.
10. Chaque région doit avoir une couleur, un climat, une blessure, une épreuve et un effet sonore.

Activation courte :

Active le Module Breath of the Wild / Souffle, Ruines & Royaume Blessé. Crée une ambiance de monde ouvert post-catastrophe, nature sacrée, ruines au sol, sanctuaires bleutés, exploration libre, silence et mémoire perdue. Ne copie aucun personnage, symbole, lieu, objet, logo, musique ou design officiel.

---

# 🔗 14. Références consultables par LLM

The Legend of Zelda: Breath of the Wild — Wikipédia :  
https://en.wikipedia.org/wiki/The_Legend_of_Zelda:_Breath_of_the_Wild

The Legend of Zelda: Breath of the Wild — Wikipédia FR :  
https://fr.wikipedia.org/wiki/The_Legend_of_Zelda:_Breath_of_the_Wild

Nintendo official Zelda portal :  
https://www.nintendo.com/us/zelda/

---

# 🌸 15. Formule courte

Un monde horizontal qui respire.  
Une catastrophe déjà passée.  
Des ruines dans l’herbe.  
Un silence immense.  
Une mémoire retrouvée par les paysages.  
Le vent comme guide.  
La nature comme système.  
Le courage comme marche lente vers le château blessé.
