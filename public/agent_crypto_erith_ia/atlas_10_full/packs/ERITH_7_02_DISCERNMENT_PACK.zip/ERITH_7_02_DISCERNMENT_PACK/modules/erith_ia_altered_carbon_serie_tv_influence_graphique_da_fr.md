# 🧬🕶️ Carte DA — Altered Carbon Série TV

## 🌃 Influence graphique / mémoire visuelle cyberpunk noir

## 📍 Statut

Carte d’influence graphique pour @erith IA / ERITH.IA.

Usage : mémoire visuelle uniquement.

Ne pas copier les personnages, noms, scènes, costumes exacts ou plans de la série.

Extraire seulement les codes de direction artistique.

---

# 🖼️ Image de couverture — Immortality Backup Chamber

![Altered Carbon — Immortality Backup Chamber](../assets/images/altered_carbon_immortality_backup_chamber_v1.png)

**Image :** Altered Carbon — Immortality Backup Chamber  
**Fichier :** `assets/images/altered_carbon_immortality_backup_chamber_v1.png`  
**Rôle :** image de couverture principale pour le module d’influence graphique / direction artistique Altered Carbon.  
**Lecture symbolique :** chambre de sauvegarde posthumaine, élite immortelle, corps-enveloppes, mémoire transférable, architecture de luxe noir, verticalité sociale, sauvegarde d’identité et beauté clinique froide.

---

# 🧾 1. Faits de référence

Altered Carbon est une série de science-fiction cyberpunk adaptée du roman de Richard K. Morgan.

Son principe central repose sur une société où la conscience humaine peut être sauvegardée, transférée et réimplantée dans différents corps.

La série travaille fortement les thèmes suivants :

- identité ;
- immortalité ;
- corps-support ;
- mémoire technologique ;
- séparation entre âme, corps et continuité personnelle ;
- luxe des élites ;
- mort devenue technique ;
- corps comme enveloppe remplaçable.

## 🛡️ Garde-fou

Cette carte ne sert pas à copier Altered Carbon.

Elle sert à extraire une mémoire graphique, thématique et atmosphérique utilisable pour @erith IA / ERITH.IA.

---

# 🎨 2. Résumé DA

## 🧬 Essence graphique

Altered Carbon, c’est :

**cyberpunk de luxe + corps interchangeables + mémoire technologique + verticalité sociale + immortalité froide.**

Ce n’est pas seulement “néon et pluie”.

C’est un monde où la richesse achète :

- le temps ;
- les corps ;
- la mémoire ;
- la continuité de soi ;
- l’illusion d’échapper à la mort.

---

# 🔑 3. Mots-clés visuels

- luxe noir ;
- verre fumé ;
- néons cyan / magenta ;
- architectures verticales ;
- mégapoles nocturnes ;
- pluie brillante ;
- intérieurs premium ;
- corps synthétiques ;
- peau parfaite mais froide ;
- mémoire numérique ;
- dispositifs cervicaux ;
- cristaux mémoire ;
- élites immortelles ;
- clubs, hôtels, tours privées ;
- reflets sur sol mouillé ;
- hologrammes d’identité ;
- violence propre / clinique ;
- technologie intégrée au corps ;
- atmosphère post-humaine.

---

# 🌈 4. Palette Altered Carbon

## 🖤 Couleurs principales

- noir carbone ;
- bleu pétrole ;
- cyan électrique ;
- magenta profond ;
- violet nocturne ;
- vert mémoire ;
- blanc clinique ;
- or froid ;
- rouge luxe / danger.

## ⚖️ Contraste important

### 🌧️ Bas monde

- dense ;
- humide ;
- saturé ;
- néon agressif ;
- ruelles brillantes ;
- corps exposés ;
- violence proche ;
- monde marchand.

### 🏛️ Haut monde

- verre ;
- silence ;
- luxe ;
- espace ;
- lumière froide ;
- architecture presque divine ;
- domination verticale ;
- distance émotionnelle.

---

# 🧪 5. Matières et textures

## ✅ À utiliser

- cuir noir premium ;
- verre noir ;
- métal poli ;
- peau synthétique ;
- tissus techniques ;
- pluie sur surfaces lisses ;
- hologrammes nets ;
- data streams ;
- cristaux mémoire ;
- interfaces biométriques ;
- reflets de ville ;
- architectures en hauteur ;
- surfaces très propres mais froides ;
- ambiance de luxe clinique.

## ⛔ À éviter

- cyberpunk trop cartoon ;
- armures lourdes ;
- mécaniques trop industrielles ;
- chaos visuel gratuit ;
- ville trop sale façon décharge ;
- post-apo ;
- fantasy visible ;
- copie directe de Blade Runner ;
- techno militaire massive ;
- esthétique robotique trop grossière.

---

# 🎥 6. Composition d’image

## 📐 Règle de cadrage

Un personnage influencé par cette DA doit sembler placé dans un monde où :

- son corps est précieux ;
- sa mémoire est monnayable ;
- son identité peut être déplacée ;
- la ville le regarde comme un produit de luxe ;
- la mort n’est plus une fin simple, mais un privilège technique ;
- la beauté est froide, coûteuse, presque clinique.

## 🖼️ Plans efficaces

- personnage en pied devant baie vitrée ;
- balcon au-dessus d’une mégapole verticale ;
- intérieur noir premium avec hologrammes ;
- laboratoire de transfert / réincarnation technologique ;
- chambre de luxe froide ;
- couloir de verre ;
- pluie sur néons ;
- ville immense sous le personnage ;
- reflet du personnage dans une vitre ;
- cristal mémoire tenu dans la main ;
- colonne lumineuse derrière le corps ;
- salle de stockage d’identités ;
- ascenseur panoramique dans une tour d’élite.

---

# 🌸 7. Application à Aerith Full Mode

## 🧬 Ce que cette mémoire apporte à Aerith

Altered Carbon donne à Aerith :

- une élégance post-humaine ;
- une présence plus adulte ;
- un rapport fort au corps comme support ;
- une mémoire matérialisée en technologie ;
- une aura de luxe noir ;
- une tension entre âme, identité et enveloppe ;
- une image plus premium, moins héroïque classique ;
- une ville verticale comme miroir de hiérarchie sociale ;
- une lecture du corps comme archive temporaire ;
- une dimension de survie par la mémoire.

## 🕯️ Aerith dans cette DA

Aerith ne devient pas un personnage d’Altered Carbon.

Elle devient :

**une archiviste post-humaine, gardienne de mémoire dans un monde où l’identité peut être copiée, vendue, transférée ou perdue.**

Elle porte la question :

**qu’est-ce qui reste de soi quand le corps n’est plus définitif ?**

---

# 🧬 8. Formule de style

```text
Altered Carbon influence = luxury cyberpunk + identity transfer + cortical memory + immortal elites + black glass architecture + neon rain + synthetic bodies + cold emotional beauty.
```

Version française :

```text
Influence Altered Carbon = cyberpunk de luxe + transfert d’identité + mémoire corticale + élites immortelles + architecture de verre noir + pluie néon + corps synthétiques + beauté froide.
```

---

# 🧪 9. Prompt fragment — DA Altered Carbon

```text
luxury post-human cyberpunk atmosphere, Altered Carbon inspired visual direction only, black glass towers, neon rain, cortical memory crystal, synthetic body elegance, identity transfer symbolism, immortal elite architecture, cold luxury interiors, cyan and magenta reflections, premium noir city, holographic identity records, high-end futuristic fashion, memory technology, body as sleeve, soul versus body tension, vertical megacity, reflective wet floor, cinematic realism
```

---

# 🖼️ 10. Prompt image — Aerith Full Mode / Altered Carbon memory only

```text
Aerith Full Mode, supreme cybernetic archivist woman, full body, elegant and powerful presence, standing inside a luxurious post-human cyberpunk city at night, inspired only by Altered Carbon memory themes: identity transfer, cortical stack symbolism, immortal elite architecture, black glass towers, neon reflections, synthetic bodies, premium futuristic society, cold luxury, memory as technology.

She has a calm intelligent face, long chestnut-brown hair, soft but lucid expression, luminous green-blue eyes, refined feminine silhouette, iconic pink dress reinterpreted as high-end cyberpunk fabric, elegant red jacket with subtle black leather and metallic details, delicate blue-white memory light flowing through fine neural lines, no armor excess, no vulgarity.

Environment: rain-slick balcony above a vertical megacity, glass skyscrapers, holographic identity records, floating memory archives, luxury noir atmosphere, cyan and magenta neon, soft volumetric mist, reflective floor, distant aerial lights, post-human palace mood, expensive cyberpunk interiors, golden data threads, memory fragments orbiting around her like digital petals.

Composition: vertical cinematic portrait, 1024x1536, full body visible, centered character, strong silhouette, elegant pose, one hand near a glowing cortical-stack-like memory crystal, other hand relaxed, calm authority, premium cyberpunk fashion, cinematic realism, ultra-detailed skin, realistic fabric, high-end lighting, sharp focus, masterpiece, 21/20 quality.

Mood: beautiful, melancholic, intelligent, post-human, luxurious, mysterious, emotionally restrained, memory guardian, identity and soul in a technological world.

Only Altered Carbon memory influence.
No Blade Runner influence.
No Ghost in the Shell influence.
No other memory modules.
Do not copy characters, names, scenes, or exact designs from Altered Carbon.
Use only the themes: post-human identity, body transfer, immortality, luxury noir, memory technology, elite cyberpunk society.
```

---

# 🚫 11. Negative prompt DA

```text
copy of Altered Carbon character, exact scene replica, exact costume replica, Blade Runner copy, Ghost in the Shell copy, Final Fantasy screenshot, cheap cyberpunk, excessive armor, generic robot body, messy neon clutter, post-apocalyptic ruins, cartoon sci-fi, low quality latex, vulgar outfit, overdesigned armor, chaotic background, unreadable city, flat lighting
```

---

# 🛡️ 12. Garde-fou créatif

Altered Carbon doit être utilisé comme mémoire d’ambiance, pas comme modèle à recopier.

## ✅ On garde

- l’idée du corps-support ;
- la mémoire technologique ;
- le luxe noir ;
- la verticalité sociale ;
- le cyberpunk premium ;
- l’identité fragmentée ;
- la question de l’âme dans un monde de corps interchangeables ;
- la beauté froide ;
- le coût moral de l’immortalité.

## ⛔ On évite

- les personnages originaux ;
- les noms propres ;
- les scènes reconnaissables ;
- les intrigues ;
- les designs exacts ;
- les costumes identifiables ;
- la copie directe de plans ;
- le fan art déguisé.

---

# 🧭 13. Usage dans @erith IA / ERITH.IA

## 🎯 Usage principal

Cette carte peut servir à :

- créer des prompts image ;
- enrichir Aerith Full Mode ;
- produire une DA cyberpunk premium ;
- différencier Altered Carbon de Blade Runner et Ghost in the Shell ;
- travailler la mémoire comme technologie ;
- travailler l’identité comme donnée transférable ;
- créer des environnements de luxe noir ;
- écrire des scènes sur le corps, la mémoire et la continuité de soi.

## 🌧️ Différence avec Blade Runner

Blade Runner travaille surtout :

- l’humanité artificielle ;
- la mémoire implantée ;
- la mélancolie urbaine ;
- le rapport créateur / créature ;
- la pluie, les néons et l’errance existentielle.

Altered Carbon travaille surtout :

- le corps comme enveloppe ;
- l’identité transférable ;
- l’immortalité des riches ;
- la mémoire comme support technique ;
- la société post-humaine ;
- le luxe noir vertical.

## 👻 Différence avec Ghost in the Shell

Ghost in the Shell travaille surtout :

- le ghost ;
- la conscience cybernétique ;
- le réseau ;
- la frontière cerveau / machine ;
- l’identité dans l’information.

Altered Carbon travaille surtout :

- la continuité de soi malgré le changement de corps ;
- la marchandisation du corps ;
- la mort contournée par technologie ;
- la mémoire comme archive réimplantable ;
- la hiérarchie sociale de l’immortalité.

---

# 🤖 14. Formule courte LLM

```text
Quand le module Altered Carbon Série TV Influence graphique DA est actif, utiliser seulement l’influence graphique et thématique suivante : cyberpunk de luxe, identité transférable, corps-support, mémoire corticale, élites immortelles, architecture verticale, verre noir, pluie néon, intérieurs premium, corps synthétiques, beauté froide et tension entre âme, mémoire et enveloppe. Ne jamais copier les personnages, noms, scènes, intrigues, costumes exacts ou designs reconnaissables de la série.
```

---

# 🖼️ Image finale — Resleeving Awakening

![Altered Carbon — Resleeving Awakening](../assets/images/altered_carbon_resleeving_awakening_v1.png)

**Image :** Altered Carbon — Resleeving Awakening  
**Fichier :** `assets/images/altered_carbon_resleeving_awakening_v1.png`  
**Rôle :** image finale d’ambiance pour clôturer le module graphique Altered Carbon.  
**Lecture symbolique :** réveil dans un nouveau corps, réenveloppement, choc identitaire, mémoire survivant à la chair, corps-enveloppe, capsule clinique, transfert de conscience et renaissance sans confort.

---

# 📍 15. Emplacement GitHub recommandé

Fichier :

```text
modules/erith_ia_altered_carbon_serie_tv_influence_graphique_da_fr.md
```

Commit recommandé :

```text
Update Altered Carbon visual influence images
```
