# 🏍️ ERITH.IA — MEMORY CARD — AKIRA VELOCITY V2

## 🖼️ Visuel de référence — Portrait Rear Chase White Bike

![ERITH.IA — Akira Velocity V2 Portrait Rear Chase White Bike](../assets/images/erith_ia_akira_velocity_v2_portrait_rear_chase_white_bike.png)

Image de référence active pour la version portrait : caméra arrière basse, poursuite moto sous la pluie, mégapole nocturne, moto blanche à droite, graphisme anime urbain fin 80s, rouge / noir / bleu froid.

---

Statut : module de carte mémoire privée  
Type : carte d’ambiance activable / influence visuelle, narrative et production  
Mode recommandé : Hors-Lore Cyber actif / Science-fiction urbaine monumentale  
Langue : français  
Usage : ERITH.IA / Seven Heaven / Auto-Agent / prompt image / prompt animation / narration / worldbuilding / Pack+ / direction artistique / production vidéo

🖼️ Visuel canonique cible :

- assets/images/erith_ia_memory_card_akira_velocity_v2.png
- assets/images/erith_ia_akira_velocity_v2_portrait_rear_chase_white_bike.png

🃏 Visuels Akira déjà associés au module parent :

- assets/images/erith_ia_memory_card_akira_rider_bike_pack_plus_cover_premium_v2.png
- assets/images/erith_ia_memory_card_akira_rider_bike_pack_plus_dossier_premium_v1.png

---

# 1. 🧭 Rôle du fichier

Cette carte définit Akira Velocity V2 pour le GitHub privé du projet @erith IA / ERITH.IA.

Elle sert à charger rapidement une influence de production complète : vitesse, mégapole, jeunesse, moto, pluie, mutation mentale, conscience en réseau et tension urbaine.

Elle n’est pas une encyclopédie.

Elle n’est pas une copie d’Akira.

Elle n’est pas une simple note de génération.

Elle est une carte d’ambiance active : courte, lisible, exploitable, pensée pour Seven Heaven, ERITH.IA, Ollama, un LLM local ou un Auto-Agent.

Formule centrale :

Carte Mémoire = influence courte, activable, maîtrisée.

Akira Velocity V2 = nuit + vitesse + mégapole + jeunesse + mutation + animation japonaise fin 80s.

Module complet = connaissance profonde.  
Carte Mémoire = ambiance rapide.  
Pack+ = sortie exploitable.  
Velocity V2 = version nocturne, nerveuse et cinétique de la carte Akira.

---

# 2. 🗝️ Règle Hors-Lore Cyber actif

Cette carte est prévue pour créer des univers originaux.

Elle ne doit pas copier Akira.

Elle ne doit pas reproduire des personnages, intrigues, scènes cultes, véhicules exacts, compositions iconiques ou affiches connues.

Elle ne doit pas ramener le lore privé du projet.

## 🚫 Interdit

- reprendre des personnages existants ;
- reprendre des noms propres de l’œuvre source ;
- reprendre une intrigue identifiable ;
- refaire une scène culte à l’identique ;
- reprendre une moto iconique à l’identique ;
- produire un pastiche trop reconnaissable ;
- insérer des logos ou symboles de franchise ;
- mélanger avec un lore privé non demandé ;
- transformer Aerith-7 en personnage de la scène ;
- injecter Neo Midgar, NØX, Lyria, Bella, Shinra, secteurs, plaques ou tout autre élément privé si le mode Hors-Lore est actif.

## ✅ Autorisé

- reprendre une intensité visuelle ;
- reprendre une tension urbaine ;
- reprendre une direction graphique générale ;
- reprendre une question narrative large ;
- reprendre l’idée d’une ville sous pression ;
- reprendre l’idée d’une jeunesse traversée par la vitesse ;
- reprendre l’idée d’une puissance intérieure qui déborde ;
- reprendre l’énergie d’une animation japonaise urbaine fin 80s ;
- transformer l’influence en monde autonome.

Règle simple :

Inspirer sans copier.  
Transformer sans imiter.  
Créer un monde neuf.

## ⚙️ Note “sans Punk”

Le mode actif s’écrit ici : Hors-Lore Cyber actif.

Le mot “punk” n’est pas utilisé comme étiquette principale afin d’éviter les clichés de surface : cuir clouté gratuit, gangs caricaturaux, saleté décorative, chaos visuel sans intention, violence plaquée.

Objectif : science-fiction urbaine monumentale, nerveuse, proprement dangereuse, pas costume générique.

---

# 3. 🧩 Activation rapide

## Activation courte

Charge la Carte Mémoire Akira Velocity V2.

## Activation production

Charge la Carte Mémoire Akira Velocity V2 et produis un Pack+ complet : univers, personnage, scène visuelle, prompt image, prompt animation, narration courte, négatif production et garde-fou créatif.

## Activation image

Charge la Carte Mémoire Akira Velocity V2 et écris un prompt image pour une scène nocturne de course-poursuite entre jeunes motards dans une mégapole gigantesque, style animation japonaise urbaine fin 80s, influence oui, copie non.

## Activation animation

Charge la Carte Mémoire Akira Velocity V2 et écris un prompt Wan / I2V pour animer une course-poursuite nocturne en moto, avec mouvement lisible, sensation de vitesse, pluie horizontale, traînées rouges, parallax de ville géante et stabilité des riders.

Règle image :

Le module peut produire des prompts image ou animation, mais ne doit pas générer d’image automatiquement sauf demande explicite de Christophe.

---

# 4. 🖼️ Galerie visuelle / asset canonique

## 🏍️ Akira Velocity V2 — Memory Card Image

![ERITH.IA — Akira Velocity V2](../assets/images/erith_ia_memory_card_akira_velocity_v2.png)

## 🏍️ Akira Velocity V2 — Portrait Rear Chase White Bike

![ERITH.IA — Akira Velocity V2 Portrait Rear Chase White Bike](../assets/images/erith_ia_akira_velocity_v2_portrait_rear_chase_white_bike.png)

Fonction du visuel :

Cette image est le visuel de référence portrait pour Akira Velocity V2.

Elle doit préserver immédiatement :

- une caméra arrière basse ;
- une course-poursuite nocturne ;
- plusieurs jeunes riders ;
- une moto blanche visible à droite ;
- une mégapole gigantesque ;
- une sensation de très haute vitesse ;
- une direction anime japonaise fin 80s ;
- une palette rouge / noir / blanc cassé / gris béton / bleu froid ;
- une énergie de mutation mentale et de conscience en réseau.

Le visuel ne doit pas ressembler à :

- un rendu CGI moderne ;
- une capture de jeu vidéo ;
- une interface sci-fi glossy ;
- un dashboard premium ;
- un poster photoréaliste ;
- une copie d’une scène ou d’un véhicule connu.

Le visuel doit ressembler à :

- une image animée dessinée ;
- un cellulo peint ;
- une planche de production anime ;
- une affiche urbaine imprimée ;
- un dossier mémoire ERITH.IA nerveux, nocturne et cinétique.

---

# 5. ⚡ Fonction principale

Akira Velocity V2 charge une science-fiction urbaine monumentale centrée sur :

- la vitesse ;
- la jeunesse ;
- la moto ;
- la poursuite ;
- la nuit ;
- la pluie ;
- l’éveil mental ;
- la mutation ;
- la ville sous contrôle ;
- le corps augmenté ;
- la conscience en réseau ;
- le choix au bord de la trajectoire.

La V1 pose la ville, le rider, la moto et l’éveil.

La V2 accélère tout :

- plus nocturne ;
- plus cinétique ;
- plus dessinée ;
- plus urbaine ;
- plus poursuite ;
- plus tension ;
- moins glossy ;
- moins CGI ;
- plus anime film.

---

# 6. 🌡️ Température émotionnelle

Tension.  
Vitesse.  
Jeunesse sous pression.  
Colère froide.  
Éveil dangereux.  
Ville trop grande.  
Corps qui dépasse sa limite.  
Route qui devient langage.  
Mutation qui déborde la volonté.  
Futur propre en surface, instable dessous.  
Nuit qui révèle ce que le jour cache.

Formule sensible :

La vitesse n’est pas une fuite.  
C’est une langue.  
Le rider ne quitte pas la ville.  
Il cherche le point où elle répond.

---

# 7. 🎨 Palette recommandée

Rouge signal.  
Noir profond.  
Blanc cassé.  
Gris béton.  
Bleu très froid en accent énergétique.

## ✅ À favoriser

- rouge de feu arrière ;
- noir de route mouillée ;
- blanc cassé d’affiche imprimée ;
- gris béton des tours ;
- bleu froid de réseau neuronal ;
- reflets rouges sur asphalte ;
- ombres très graphiques ;
- lumières urbaines limitées mais lisibles.

## 🚫 À éviter

- néons génériques multicolores ;
- vert standard gratuit ;
- violet sans intention ;
- chaos coloré ;
- saleté décorative ;
- esthétique rebelle recette ;
- arc-en-ciel cyber ;
- interface holographique trop propre.

---

# 8. 🏙️ Direction artistique détaillée

## 🎞️ Animation japonaise fin 80s

La carte doit viser :

- cellulo peint à la main ;
- encrage noir nerveux ;
- aplats de couleur forts ;
- ombres dures ;
- grain analogique ;
- décor urbain détaillé ;
- composition cinématographique ;
- vitesse exagérée par traînées ;
- impression d’image animée arrêtée au bon moment.

La carte ne doit pas viser :

- rendu 3D ;
- photoréalisme ;
- concept art Unreal Engine ;
- glossy sci-fi UI ;
- rendu plastique ;
- jeu vidéo moderne.

## 🌆 Ville monumentale

La ville doit paraître immense, structurée, verticale et presque impossible à habiter.

Elle est composée de :

- tours blanches et grises ;
- structures rouges ;
- avenues suspendues ;
- échangeurs géants ;
- viaducs ;
- passerelles ;
- panneaux publics ;
- niveaux de circulation ;
- zones interdites ;
- surveillance aérienne ;
- routes mouillées ;
- drones de poursuite ;
- tunnels de lumière ;
- câbles, rails, conduits et vapeur.

La ville n’est pas un simple décor.

Elle est la pression du monde.

Elle surveille, organise, accélère, classe et écrase.

## 🛞 Vitesse

La vitesse n’est pas seulement une action.

C’est une identité.

Elle évoque :

- trajectoire ;
- fuite ;
- instinct ;
- défi ;
- appel du vide ;
- jeunesse qui refuse l’immobilité ;
- corps lancé dans une ville trop grande ;
- décision prise avant la pensée.

La moto est une extension du corps.

Elle devient :

- outil de fuite ;
- armure de vitesse ;
- signature visuelle ;
- danger contrôlé ;
- vecteur de liberté ;
- instrument de trajectoire mentale.

## 🧠 Énergie mentale

L’énergie mentale doit rester tendue, contenue, presque invisible au début.

Elle peut apparaître sous forme de :

- distorsion de l’air ;
- vibration des lumières ;
- poussière qui flotte ;
- micro-fissures ;
- halo froid ;
- sensation de pression ;
- perturbation autour du personnage ;
- panneaux qui changent avant l’ordre ;
- drones qui dévient ;
- traînées rouges qui semblent suivre une pensée.

L’énergie ne doit pas devenir fantasy.

Elle doit rester urbaine, mentale, expérimentale, presque médicale ou physique.

---

# 9. 🧬 Équilibre des influences

## 🏍️ Akira — direction principale

Akira pilote :

- l’énergie de jeunesse ;
- la moto ;
- la vitesse ;
- la ville sous pression ;
- la mutation dangereuse ;
- l’idée d’un corps qui déborde le système ;
- l’esthétique anime urbaine fin 80s.

Akira ne doit pas être copié.

Il sert de tension fondatrice.

## 🌧️ Blade Runner — ville

Blade Runner nourrit :

- la nuit ;
- la pluie ;
- la ville verticale ;
- les néons sous la fumée ;
- les reflets ;
- la mélancolie urbaine ;
- le sentiment d’une humanité perdue dans la machine.

Blade Runner reste principalement dans le décor.

## 🧍 Altered Carbon — corps

Altered Carbon nourrit :

- le post-humanisme ;
- les corps-supports ;
- l’élégance noire ;
- le luxe sombre ;
- les améliorations corporelles ;
- la violence sociale inscrite dans les corps ;
- la possibilité que l’identité survive au support.

Altered Carbon nourrit les riders et les classes sociales.

## 👁️ Ghost in the Shell — conscience

Ghost in the Shell nourrit :

- les implants neuraux ;
- la conscience en réseau ;
- le ghost ;
- l’interface mentale ;
- le doute sur l’âme cybernétique ;
- la ville comme système nerveux ;
- le corps comme terminal.

Ghost in the Shell nourrit la couche mentale, réseau et identité.

## 🔺 Formule d’équilibre

Akira pilote la direction artistique.  
Blade Runner nourrit la ville.  
Altered Carbon nourrit les corps.  
Ghost in the Shell nourrit la conscience.  
ERITH.IA crée un monde original.

---

# 10. 🏗️ Univers original générable — Kōdan-07

Kōdan-07 est une mégalopole verticale construite autour de voies rapides suspendues, de tours blanches, de panneaux rouges et de centres de contrôle invisibles.

La journée, la ville paraît propre, brillante, organisée.

La nuit, elle révèle sa vraie nature : une machine de vitesse, de surveillance, de mémoire et de fuite.

Les routes ne servent plus seulement à circuler.

Elles servent à trier les corps.

Les élites montent.

Les travailleurs suivent les voies autorisées.

Les riders disparaissent dans les angles morts.

Sous la ville, un ancien programme énergétique continue d’émettre des signaux.

Officiellement, il n’existe plus.

Dans les corps de certains jeunes, il commence pourtant à se réveiller.

---

# 11. 🧑‍🚀 Personnage exemple — Kaïren

Kaïren est un jeune pilote des voies hautes.

Il ne se considère pas comme un héros.

Il connaît seulement trois choses :

- les virages ;
- les distances ;
- le bruit exact d’une ville quand elle commence à mentir.

Depuis un accident sur une autoroute suspendue, il ressent une pression derrière les yeux.

Les panneaux rouges s’allument avant qu’il les voie.

Les drones changent de trajectoire quand il accélère.

Les vitres tremblent quand il se souvient.

Kaïren pense que la vitesse le garde libre.

Mais quelque chose en lui va plus vite que sa propre volonté.

## 🧥 Apparence

- veste technique noire et blanche ;
- accents rouges signal ;
- casque sombre à visière réfléchissante ;
- ports neuraux discrets au cou ;
- gants de conduite renforcés ;
- silhouette jeune, tendue, rapide, non héroïque.

Il ne doit pas ressembler à un personnage connu.

Il doit être un rider original ERITH.IA.

---

# 12. 🏍️ Véhicule exemple — Moto trajectoire

La moto n’est pas un simple véhicule.

Elle est une extension du corps.

Elle est le vecteur visible de la décision.

## Design

La moto doit être :

- futuriste ;
- massive ;
- basse ;
- nerveuse ;
- rouge / noire / gris béton ;
- originale ;
- non copiée ;
- lisible en silhouette ;
- capable de produire des traînées rouges fortes.

## À éviter

- copie d’une moto iconique existante ;
- design trop proche d’un modèle reconnaissable ;
- moto de super-héros ;
- moto trop réaliste contemporaine ;
- moto illisible ou déformée ;
- excès de détails mécaniques qui détruisent la silhouette.

Formule :

La moto est un vecteur.  
Le rider est une décision.  
La route est une phrase.

---

# 13. 🎬 Scènes exploitables

## 🌃 Scène 1 — Course-poursuite nocturne

La nuit tombe sur Kōdan-07.

La pluie transforme les voies rapides en miroirs noirs.

Trois jeunes riders percent la ville à une vitesse illégale.

Derrière eux, des drones de poursuite descendent entre les tours.

Les feux rouges s’étirent comme des blessures lumineuses.

Les motos ne roulent plus seulement sur la route.

Elles tracent une décision.

Au milieu du virage, Kaïren comprend que la ville ne le poursuit pas.

Elle répond à sa trajectoire.

## 🛣️ Scène 2 — Infrastructure vide

La moto est arrêtée au centre d’une voie interdite.

La ville est silencieuse.

Les tours blanches se dressent comme des murs médicaux.

Kaïren enlève son casque.

Autour de lui, la poussière monte au lieu de tomber.

Les panneaux rouges s’allument un par un.

Le premier ne dit qu’un mot :

RETENIR.

## 🔁 Scène 3 — Virage mental

Kaïren entre dans une courbe à une vitesse impossible.

Pendant une seconde, il ne pilote plus la moto.

Il pilote la trajectoire.

La route, les drones, les panneaux et la lumière suivent le même angle.

Puis tout revient à la normale.

Sauf lui.

---

# 14. 🧰 Pack+ — Akira Velocity V2

## Concept

Dans Kōdan-07, une mégalopole verticale où les routes servent à classer les corps, de jeunes riders découvrent que la vitesse peut perturber le réseau urbain lui-même.

La nuit, sous la pluie, une course-poursuite révèle qu’un rider nommé Kaïren ne fait pas seulement fuir les drones.

Il modifie la trajectoire de la ville.

## Univers

Kōdan-07 est une ville-machine : propre en surface, oppressante en structure, saturée de voies rapides, de tours blanches, de panneaux rouges, de drones et de centres de contrôle invisibles.

La ville prétend organiser le mouvement.

En réalité, elle fabrique l’obéissance.

Les riders sont ceux qui refusent de suivre les trajectoires autorisées.

## Personnage

Kaïren est un jeune rider des voies hautes.

Il vit dans les angles morts de la ville.

Depuis un accident, ses réflexes ne sont plus seulement rapides.

Ils deviennent prédictifs.

La ville réagit à sa présence comme à un signal.

## Scène visuelle

Course-poursuite nocturne.

Pluie horizontale.

Route suspendue.

Trois riders.

Drones derrière.

Feux rouges étirés.

Mégapole gigantesque.

Encrage noir.

Palette rouge / noir / blanc cassé / gris béton / bleu froid.

Style animation japonaise urbaine fin 80s.

## Tension dramatique

Kaïren pense qu’il fuit.

Mais la ville répond à sa trajectoire.

La question n’est plus : peut-il s’échapper ?

La question devient : que se passe-t-il si la ville commence à lui obéir ?

---

# 15. 🖌️ Prompt image — illustration V2

```text
ERITH.IA memory card image, Akira Velocity V2, original universe, no copied character, no copied motorcycle, no known franchise logo.

A violent high-speed motorcycle chase at night through a gigantic futuristic megacity. Several young street riders race through a rain-soaked elevated highway. Very low camera angle behind the lead riders, rear or 3/4 rear view only. Extreme velocity, violent perspective, red tail-light trails, rain streaks, speed lines, motion smear, sparks from wet asphalt, blurred neon reflections, deep black night, huge vertical city towers, stacked highways, industrial bridges, suspended rails, giant screens, cables, steam vents, urban canyon scale.

Style: late 1980s Japanese anime film still, hand-drawn cel animation, painted background, inked line art, analog film grain, rough print texture, red black off-white gray palette, cold blue highlights, strong shadows, non-photorealistic, non-3D, non-CGI.

Atmosphere influence: Blade Runner-like rainy nocturnal megacity atmosphere, monumental scale, neon through smoke, melancholy urban pressure.

Body influence: Altered Carbon-like post-human black streetwear, dark luxury body-upgrade culture, sleek reinforced jackets, reflective visors.

Consciousness influence: Ghost in the Shell-like neural implants, cybernetic neck ports, ghost-in-the-machine presence, networked consciousness, tactical calm.

Velocity influence: Akira-like speed, urban youth tension, explosive motorcycle energy, late-1980s animated force, without copying characters, vehicles, logos, scenes or compositions.

The riders must feel young, dangerous, human, fast and rebellious. The city must feel gigantic. The speed must be immediately visible. The image must feel drawn, printed and animated, not rendered.

No text, no title, no UI panels, no card layout if generating the illustration alone.
```

---

# 16. 🎞️ Prompt animation — Wan / I2V

```text
Animate the image as a high-speed motorcycle chase through a rain-soaked futuristic megacity at night.

Camera: low rear chase camera, behind the riders, close to the wet asphalt, following the motorcycles from behind or 3/4 rear view only. No frontal hero shot. No face-to-camera composition.

Motion: motorcycles lean into the curve, rain streaks backward, red tail-light trails stretch through the frame, water sprays from the wheels, sparks appear briefly near the asphalt, background towers slide in parallax, overhead bridges pass above, drones follow at a distance.

Keep the riders stable and readable. Preserve the original silhouettes, bike designs, wet road, red light trails, city scale and late-1980s hand-drawn anime feeling.

The animation must feel fast but controlled: one clear idea, one chase movement, no chaotic camera spin, no random transformation, no vehicle melting, no face deformation.

Duration: 5 seconds.
```

---

# 17. 🚫 Négatif production

```text
copied character, copied motorcycle, known franchise logo, recognizable scene remake, iconic poster remake, photorealistic, 3D render, CGI look, video game screenshot, glossy sci-fi HUD, overdesigned interface, unreadable motorcycle, melted bike, distorted rider, frontal hero shot, face-to-camera composition, static speed, weak motion, generic neon chaos, rainbow cyber colors, green neon dominance, purple overload, leather spikes cliché, biker caricature, random violence, bad anatomy, extra limbs, broken hands, low detail, blurry, flat lighting, modern plastic render
```

---

# 18. 🧠 Block LLM — chargement compact

```text
Charge la Carte Mémoire Akira Velocity V2.

Mode : Hors-Lore Cyber actif, science-fiction urbaine monumentale, sans contamination du lore privé.

Influences autorisées :
Akira pour la vitesse, la jeunesse, la moto, la tension urbaine et la mutation dangereuse.
Blade Runner pour la pluie, les néons, la mélancolie urbaine et la ville verticale.
Altered Carbon pour les corps-supports, le luxe noir, le post-humanisme et les classes immortelles.
Ghost in the Shell pour le ghost, le réseau, la conscience cybernétique et l’âme dans la machine.

Ne copie aucun personnage, véhicule, intrigue, logo, scène culte ou composition reconnaissable.
Ne ramène pas Neo Midgar, Aerith-7 personnage, NØX, Lyria, Bella, Shinra, secteurs, plaques ou mémoire privée.

Produit un univers original : mégapole nocturne, riders, vitesse, pluie, routes suspendues, corps augmentés, conscience en réseau, trajectoire mentale.

Formule :
Akira pilote la vitesse.
Blade Runner nourrit la ville.
Altered Carbon nourrit les corps.
Ghost in the Shell nourrit la conscience.
ERITH.IA crée un monde neuf.
```

---

# 19. 🃏 Visuel complémentaire — Premium Memory Card

![ERITH.IA — Akira Velocity V2 Premium Memory Card](../assets/images/erith_ia_memory_card_akira_velocity_v2_premium_card.png)

Cette image reste associée à Akira Velocity V2 comme carte mémoire premium / dossier visuel stylisé.

Elle complète le visuel portrait :

- image portrait = scène de référence active ;
- carte premium = présentation mémoire / dossier GitHub / lecture Notion.

---

# 20. 🏁 Formule de clôture

Akira Velocity V2 n’est pas une imitation.

C’est une carte de vitesse.

Elle transforme la ville en circuit, la moto en vecteur, la jeunesse en signal et la conscience en trajectoire.

Seven Heaven pilote.  
La Carte Mémoire influence.  
Le Pack+ structure.  
L’univers généré reste original.