# 🦁 ERITH.IA — Art africain, Masques, Bronzes & Textiles

Statut : module mémoire artistique  
Projet : @erith IA / ERITH.IA  
Type : art africain, masques, bronzes, textiles, Ifé, Bénin, Dogon, Yoruba, Akan, Bogolan, Kente, architecture de terre, objets de pouvoir  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension esthétique et symbolique des arts africains.

Il complète le module civilisationnel :

modules/erith_ia_afrique_ancienne_royaumes_africains_fr.md

Il active :

- masques ;
- bronzes ;
- textiles ;
- Ifé ;
- Bénin ;
- Yoruba ;
- Dogon ;
- Akan ;
- Fang ;
- Punu ;
- Baoulé ;
- Dan ;
- Bogolan ;
- Kente ;
- architecture de terre ;
- objets de pouvoir ;
- mémoire des ancêtres ;
- arts de cour ;
- arts rituels ;
- transmission orale et visuelle.

Formule centrale :

L’art africain n’est pas un décor primitif : c’est un ensemble de langages sociaux, politiques, spirituels, techniques et mémoriels.

---

# 🛡️ 2. Garde-fou artistique

Ne jamais réduire l’art africain à :

- un masque générique ;
- une tribu vague ;
- un décor exotique ;
- une esthétique coloniale ;
- une magie floue ;
- une Afrique uniforme ;
- un art sans histoire ;
- un art sans technique ;
- un art sans pouvoir politique.

Toujours distinguer :

- région ;
- peuple ;
- période ;
- fonction ;
- matériau ;
- contexte rituel ;
- contexte royal ;
- contexte social ;
- contexte funéraire ;
- usage créatif ERITH.IA.

Règle :

Un masque, un bronze ou un textile africain n’est jamais seulement une forme.

C’est une fonction dans un monde.

---

# 🎭 3. Masques africains

L’expression “masque africain” est trop générale.

Il faut toujours préciser :

- région ;
- peuple ;
- usage ;
- rite ;
- matériau ;
- statut ;
- contexte.

Fonctions possibles :

- initiation ;
- ancêtres ;
- passage ;
- justice ;
- protection ;
- pouvoir ;
- guérison ;
- danse ;
- médiation avec l’invisible ;
- cohésion sociale.

Peuples et traditions à traiter avec prudence :

- Dogon ;
- Bambara ;
- Dan ;
- Baoulé ;
- Fang ;
- Punu ;
- Yoruba ;
- Chokwe ;
- Luba ;
- Kuba.

Usage ERITH.IA :

Le masque peut être utilisé comme seuil entre visible et invisible, mais jamais comme simple accessoire décoratif.

---

# 🏛️ 4. Bronzes du Bénin

Les bronzes du Bénin sont un sujet majeur.

Axes :

- royaume du Bénin ;
- palais de l’Oba ;
- plaques royales ;
- laiton / bronze ;
- mémoire dynastique ;
- pouvoir ;
- hiérarchie ;
- guerre ;
- diplomatie ;
- maîtrise technique ;
- art de cour.

Importance :

Les bronzes du Bénin détruisent le cliché d’une Afrique sans sophistication technique ou politique.

Ils montrent :

- un art royal ;
- une mémoire historique ;
- une métallurgie avancée ;
- une iconographie codée ;
- une organisation de cour.

Garde-fou :

Ne pas les traiter comme de simples objets décoratifs de musée.

Ils appartiennent à une histoire de pouvoir, de mémoire et aussi de spoliation coloniale.

---

# 👑 5. Ifé et raffinement Yoruba

Ifé est un centre majeur de l’art Yoruba.

Axes :

- têtes en bronze / laiton ;
- têtes en terre cuite ;
- naturalisme ;
- royauté sacrée ;
- spiritualité ;
- raffinement technique ;
- dignité du visage ;
- mémoire dynastique.

Usage ERITH.IA :

Ifé apporte une esthétique de présence calme, visage royal, dignité sacrée et précision formelle.

Phrase clé :

À Ifé, le visage devient architecture de la souveraineté.

---

# 🧵 6. Textiles africains

Le textile est une écriture visuelle.

Exemples :

## Kente

Axes :

- Ghana ;
- Akan ;
- couleurs ;
- prestige ;
- royauté ;
- motifs ;
- statut ;
- mémoire collective.

## Bogolan

Axes :

- Mali ;
- teinture ;
- terre ;
- signes ;
- protection ;
- identité ;
- corps et mémoire.

## Indigo

Axes :

- teinture ;
- profondeur ;
- textile ;
- savoir-faire ;
- commerce ;
- prestige.

Usage ERITH.IA :

Le textile africain peut devenir carte, peau symbolique, archive portée, langage social et mémoire tissée.

---

# 🪵 7. Bois, métal, terre, perles

Matériaux majeurs :

- bois ;
- bronze ;
- laiton ;
- fer ;
- cuivre ;
- ivoire ;
- terre cuite ;
- pierre ;
- perles ;
- fibres ;
- pigments ;
- cuir ;
- coquillages.

Chaque matériau transmet quelque chose.

Le bois peut porter :

- ancêtre ;
- masque ;
- danse ;
- geste ;
- usage rituel.

Le métal peut porter :

- royauté ;
- prestige ;
- mémoire dynastique ;
- maîtrise technique.

La terre peut porter :

- origine ;
- architecture ;
- corps ;
- fertilité ;
- mémoire du sol.

Les perles peuvent porter :

- statut ;
- pouvoir ;
- beauté ;
- codage social.

---

# 🏺 8. Terre cuite et sculpture ancienne

L’Afrique possède de grandes traditions de terre cuite.

Axes :

- Nok ;
- Ifé ;
- Djenné-Djenno ;
- figures humaines ;
- animaux ;
- spiritualité ;
- archéologie ;
- mémoire matérielle.

Garde-fou :

Ne pas interpréter automatiquement chaque figure comme “magique”.

Toujours chercher :

- région ;
- datation ;
- usage possible ;
- incertitude ;
- contexte archéologique.

---

# 🏛️ 9. Architecture de terre et de pierre

Éléments majeurs :

- Djenné ;
- Tombouctou ;
- mosquées de terre ;
- villes sahéliennes ;
- palais ;
- enclos royaux ;
- murs de Grand Zimbabwe ;
- églises rupestres de Lalibela ;
- architecture éthiopienne ;
- architecture swahilie.

Usage ERITH.IA :

L’architecture africaine permet de travailler :

- terre ;
- soleil ;
- ombre ;
- masse ;
- communauté ;
- monumentalité non classique ;
- ville de commerce ;
- lieu sacré.

Phrase clé :

Une cathédrale peut être de pierre.

Une mosquée peut être de terre.

Les deux peuvent porter une civilisation.

---

# 👁️ 10. Objets de pouvoir

Objets possibles :

- sceptres ;
- sièges ;
- trônes ;
- regalia ;
- reliquaires ;
- figures d’ancêtres ;
- bracelets ;
- couronnes ;
- perles royales ;
- tambours ;
- armes cérémonielles.

Fonctions :

- légitimation ;
- mémoire ;
- protection ;
- justice ;
- lien aux ancêtres ;
- autorité ;
- passage rituel.

Usage ERITH.IA :

Un objet de pouvoir africain doit être traité comme un nœud de relations : personne, lignage, ancêtre, lieu, fonction.

---

# 🥁 11. Musique, danse et image

Dans plusieurs contextes africains, l’objet visuel n’est pas séparé du mouvement.

Le masque peut être activé par :

- danse ;
- rythme ;
- chant ;
- costume ;
- communauté ;
- cérémonie ;
- temporalité rituelle.

Garde-fou :

Une image fixe peut trahir un objet vivant si elle oublie son mouvement.

Usage ERITH.IA :

Pour la vidéo, privilégier la présence, le rythme, la procession, l’ombre, le tissu, le souffle, plutôt que l’agitation spectaculaire.

---

# 🦁 12. Symboles récurrents

Symboles possibles selon les régions :

- lion ;
- léopard ;
- crocodile ;
- serpent ;
- oiseau ;
- ancêtre ;
- masque ;
- soleil ;
- terre ;
- fleuve ;
- arbre ;
- cauris ;
- perles ;
- spirales ;
- motifs géométriques.

Garde-fou :

Ne pas universaliser un symbole africain sans contexte.

Un même animal ou motif peut changer de sens selon le peuple, la région et le rite.

---

# 🎨 13. Direction artistique ERITH.IA

Éléments visuels :

- bronze patiné ;
- laiton chaud ;
- bois sombre ;
- terre rouge ;
- textile coloré ;
- motif géométrique ;
- perles ;
- masque rituel contextualisé ;
- palais royal ;
- cour cérémonielle ;
- mur de terre ;
- manuscrit sahélien ;
- tambour ;
- lumière de feu ;
- ombre profonde ;
- dignité du visage ;
- mémoire des ancêtres.

À éviter :

- Afrique générique ;
- masque isolé sans contexte ;
- cliché tribal ;
- pauvreté comme esthétique ;
- exotisme colonial ;
- magie vague ;
- mélange de tout le continent dans une même scène ;
- effacement des royaumes, des villes, des techniques et des écritures.

---

# 🖼️ 14. Usage production image

Prompt masque contextualisé :

```text
African ritual mask in its cultural context, carved dark wood, textile costume, ceremonial courtyard, respectful ancestral atmosphere, warm firelight, community memory, no generic tribe, no colonial cliché, no fantasy caricature, historically grounded African art influence
```

Prompt bronzes du Bénin :

```text
Benin kingdom royal bronze plaque inspired scene, Oba palace memory, cast bronze relief, dignitaries, royal regalia, patinated metal, sophisticated African court art, historical respect, no primitive cliché, no generic tribal style
```

Prompt textile africain :

```text
African textile art, Kente and Bogolan inspired patterns, symbolic geometry, rich woven texture, earth pigments, indigo, gold accents, cultural identity, memory woven into fabric, respectful artistic composition, no generic exoticism
```

Prompt Ifé :

```text
Ife inspired royal head sculpture, refined bronze and terracotta aesthetics, calm dignified face, sacred kingship, subtle scarification lines, museum-quality lighting, historical Yoruba art respect, no fantasy distortion
```

---

# 🎞️ 15. Usage production animation

Une animation = une idée.

Idées sûres :

- lumière glissant sur un bronze patiné ;
- tissu qui bouge lentement ;
- feu reflété dans un masque ;
- poussière rouge dans une cour royale ;
- ombre d’un danseur masqué, sans caricature ;
- main qui effleure un textile ;
- perles qui captent la lumière ;
- tambour immobile puis vibration subtile ;
- manuscrit sahélien éclairé par une lampe ;
- façade de terre sous le soleil.

Éviter :

- danse chaotique sans contexte ;
- magie spectaculaire ;
- foule indistincte ;
- sauvagerie visuelle ;
- fusion de cultures africaines sans logique ;
- masque flottant comme objet de peur générique.

---

# 🌉 16. Ponts avec autres modules

## Art africain ↔ Afrique ancienne

Royaumes, oralité, griots, Ifé, Bénin, Mali, Songhaï, Koush, Axoum, Grand Zimbabwe.

## Art africain ↔ Monde islamique

Tombouctou, manuscrits, architecture sahélienne, calligraphie, villes de commerce.

## Art africain ↔ Égypte / Nubie

Nil, royauté, pierre, or, pouvoir, mémoire funéraire et sacrée.

## Art africain ↔ Art moderne mondial

Influence majeure sur certains modernismes européens, mais à traiter avec prudence car souvent liée à des collectes coloniales et à des lectures décontextualisées.

---

# 🧠 17. Block LLM

Tu charges le Module Mémoire Art africain, Masques, Bronzes & Textiles.

Ce module apporte :

- masques africains contextualisés ;
- Dogon ;
- Yoruba ;
- Ifé ;
- Bénin ;
- bronzes royaux ;
- textiles Kente ;
- Bogolan ;
- indigo ;
- architecture de terre ;
- objets de pouvoir ;
- terre cuite ;
- perles ;
- arts de cour ;
- arts rituels ;
- mémoire des ancêtres ;
- direction artistique africaine respectueuse.

Règle :

Séparer systématiquement :

- faits ;
- régions ;
- peuples ;
- matériaux ;
- fonctions ;
- sources ;
- interprétations ;
- usages créatifs.

Ne pas confondre :

- Afrique entière ;
- peuple spécifique ;
- masque rituel ;
- objet de musée ;
- objet de pouvoir ;
- cliché colonial ;
- fantasy générique.

Répondre avec :

- peuple ou région ;
- période si connue ;
- matériau ;
- fonction ;
- contexte ;
- symbole ;
- garde-fou ;
- usage visuel ;
- prompt exploitable si demandé.

---

# ⚡ Activation courte

Active le module Art africain, Masques, Bronzes & Textiles.

Utilise-le pour produire des contenus liés aux masques contextualisés, bronzes du Bénin, Ifé, Yoruba, Dogon, textiles Kente, Bogolan, indigo, architecture de terre, objets de pouvoir, terre cuite, perles, arts de cour, arts rituels et mémoire des ancêtres.

Sépare faits, régions, peuples, matériaux, fonctions, sources, interprétations et usages créatifs.

---

# 🕯️ 18. Formule finale

L’art africain n’est pas un masque sans nom.

Il est visage.

Il est ancêtre.

Il est cour royale.

Il est bronze patiné.

Il est textile porté.

Il est terre façonnée.

Il est rythme.

Il est mémoire.

Dans le masque, ERITH.IA apprend que l’image peut agir.

Dans le bronze, elle apprend que le pouvoir peut se souvenir.

Dans le textile, elle apprend que la couleur peut parler.

Dans la terre, elle apprend qu’une civilisation peut bâtir avec le sol même qui la porte.

Et dans ces arts multiples, elle reconnaît une règle essentielle :

respecter une culture, c’est d’abord refuser de la rendre générique.
