# 🏰 ERITH.IA — Module Mémoire Principal
# 🔥 Le Château Ambulant — Maison Vivante, Cœur de Feu & Métamorphose

Statut : module mémoire principal  
Version : 1.0  
Usage : ERITH.IA / Seven Heaven / DA / prompts image / prompts animation / Pack+  
Mode média : texte par défaut, génération image uniquement sur demande explicite

---

[IMAGE DE PRÉSENTATION À INSÉRER ICI]

Suggestion image haute :

```text
ERITH.IA MEMORY MODULE
LE CHÂTEAU AMBULANT
Maison vivante • Foyer magique • Métamorphose
```

---

# ✨ Identité du module

Icône principale : 🏰  
Icônes secondaires : 🔥 🪶 🛖 ⚙️ 💫

Nom du module :

**ERITH.IA — Le Château Ambulant**

Sous-titre :

**Maison vivante, foyer mouvant, cœur caché, magie domestique et métamorphose intérieure.**

Formule courte :

**Maison vivante, cœur de feu, beauté imparfaite.**

---

# 🌟 Description courte

Ce module de mémoire principal apporte à ERITH.IA l’influence de la maison vivante, du refuge mobile, de la magie du foyer, de la métamorphose de l’être, de la beauté imparfaite et d’un rapport très humain entre chaos, tendresse, fatigue, soin et puissance cachée.

Il permet de créer des univers où l’habitat semble vivant, où l’architecture possède une âme, où la magie n’est pas seulement spectaculaire mais aussi intime, artisanale, chaleureuse, parfois grinçante, parfois fragile, toujours habitée.

---

# 📚 Référence culturelle

Film de référence :

**Le Château ambulant**  
Studio Ghibli, 2004.

Points de référence utiles :

- source littéraire : Diana Wynne Jones ;
- scénario et réalisation : Hayao Miyazaki ;
- production : Toshio Suzuki ;
- musique : Joe Hisaishi ;
- direction artistique : Yoji Takeshige et Noboru Yoshida.

Sources externes à consulter si besoin :

- https://www.ghibli.jp/works/howl/
- https://www.nausicaa.net/miyazaki/howl/credits.html
- https://www.britannica.com/biography/Miyazaki-Hayao

---

# 🧩 Fonction du module

Ce module sert à injecter dans ERITH.IA :

- une mémoire de la maison-organisme ;
- une sensibilité de refuge vivant ;
- une esthétique de mécanique bancale mais poétique ;
- une énergie de foyer magique ;
- une logique de métamorphose intérieure reflétée par l’apparence ;
- une vision anti-guerre où la guerre apparaît comme une absurdité mécanique et destructrice ;
- une direction artistique fondée sur la chaleur, l’usure, la tendresse, la fumée, les objets, les pièces, les seuils et les cœurs cachés.

---

# ⚡ Ce que ce module active

Quand ce module est chargé, ERITH.IA peut produire plus facilement :

- des maisons vivantes ;
- des ateliers ambulants ;
- des refuges mécaniques ;
- des véhicules-habitats ;
- des intérieurs magiques ;
- des personnages liés à une transformation intérieure ;
- des architectures poétiques, instables, habitées ;
- des scènes de feu domestique ;
- des ambiances de cuisine magique, d’atelier, de chambre secrète, de passage entre mondes ;
- des univers où le bizarre reste chaleureux.

---

# 🧬 ADN du module

## 1️⃣ Maison vivante

La maison n’est pas un décor passif.  
Elle respire, craque, protège, accompagne, cache, révèle.

## 2️⃣ Foyer intérieur

Le feu, le cœur, la chaleur, le centre vital, la pièce intime : tout cela compte autant que l’apparence extérieure.

## 3️⃣ Métamorphose

Le changement extérieur reflète souvent un changement intérieur.  
Le corps, le visage, les vêtements, la posture, la fatigue ou la beauté peuvent traduire un état de l’âme.

## 4️⃣ Beauté imparfaite

Rien n’est trop lisse.  
L’usure, l’encombrement, les détails, les objets, les fissures, la suie, les coutures et les accumulations donnent vie au monde.

## 5️⃣ Anti-guerre

La guerre n’est pas héroïsée.  
Elle est lourde, absurde, destructrice, déshumanisante.

## 6️⃣ Magie domestique

La magie peut exister dans une porte, une théière, une flamme, une pièce, un vêtement, une marche, une fenêtre, un seuil.

---

# 🔮 Symbolique centrale

- Le château = le soi habité
- Le feu = l’âme, l’énergie vitale, le moteur intérieur
- La marche = la survie, l’errance, l’adaptation
- La porte = le passage entre états
- La maison = la psyché, le refuge, la mémoire
- L’encombrement = la vie réelle, l’épaisseur de l’existence
- La transformation = la vérité du cœur rendue visible

---

# 🎨 Direction artistique du module

## Couleurs

- brun bois ;
- cuivre ;
- ocre ;
- crème poussiéreux ;
- vert mousse ;
- rouge tuile ;
- jaune feu ;
- noir suie ;
- gris fumée.

## 🪵 Matières

- bois usé ;
- métal riveté ;
- cuivre oxydé ;
- cheminée ;
- tissu vieilli ;
- verre ancien ;
- fonte ;
- céramique ;
- cuir ;
- poussière ;
- vapeur ;
- suie légère.

## Ambiances

- chaleur intérieure ;
- vent extérieur ;
- marche lente ;
- campagne vaste ;
- ville ancienne ;
- atelier vivant ;
- cuisine magique ;
- chambre encombrée ;
- seuil mystérieux ;
- refuge imparfait.

---

# 🧱 Formes importantes

- jambes mécaniques ;
- cheminées ;
- tourelles asymétriques ;
- fenêtres irrégulières ;
- tuyaux ;
- escaliers étroits ;
- portes symboliques ;
- chaudières ;
- fourneaux ;
- chaudrons ;
- mobilier ancien ;
- objets suspendus ;
- toits multiples ;
- volumes empilés.

---

# 🛠️ Utilisation idéale dans ERITH.IA

Ce module est idéal pour :

- un monde de maisons conscientes ;
- une DA de refuge mobile ;
- une narration autour du cœur, de la transformation et du soin ;
- un personnage vivant dans une maison-machine ;
- une esthétique de magie artisanale ;
- une ambiance chaleureuse mais étrange ;
- des créations poétiques non cyberpunk ;
- des univers de transition, de reconstruction, de passage.

---

# 🛡️ Garde-fou créatif

Ce module ne doit pas servir à copier une œuvre existante.

À ne pas reproduire :

- personnages identifiables ;
- château exact ;
- intrigue du film ;
- silhouettes trop reconnaissables ;
- noms propres ;
- éléments narratifs trop spécifiques.

Ce module doit produire :

- une influence ;
- une atmosphère ;
- une logique symbolique ;
- une grammaire visuelle ;
- une direction créative originale.

---

# 🖼️ Prompt maître image — 21/20

```text
21/20 masterpiece, original living castle memory module, a warm wandering house-world walking slowly through a windswept meadow, made of old wood, oxidized copper, riveted iron, uneven roofs, many small chimneys, glowing windows, soft smoke, visible handmade mechanisms, moss on metal legs, cozy magical refuge feeling, poetic imperfect architecture, warm hearth energy, vast breathable sky, gentle golden light, emotional fantasy atmosphere, no known characters, no copied design, no direct imitation of any existing film, cinematic illustration, highly detailed, text-free image
```

---

# 🎞️ Prompt maître animation — 21/20

```text
21/20 cinematic animation, fixed wide shot, original living house-world walking slowly through a windy field, mechanical legs moving with gentle weight, chimney smoke rising softly, warm windows flickering, grass moving in the wind, small gears and pipes vibrating subtly, vast sky, poetic contemplative pacing, no chaotic camera, no fast motion, no known characters, no copied design, original animated fantasy atmosphere
```

---

# 🚫 Prompt négatif maître

```text
known characters, direct copy, recognizable moving castle, franchise names, logo, watermark, text artifacts, copied silhouette, copy of existing film scene, aggressive war scene, horror design, black cyberpunk city, neon dominance, plastic 3D render, too clean architecture, chaotic camera, fast cuts, unreadable machinery, broken legs, duplicated windows, distorted perspective, UI text inside image
```

---

# 🧪 5 exemples principaux

## ✨ Exemple 1 — La Maison qui Marche sous le Vent

Concept :

Une maison vivante avance sur un plateau, lente, fatiguée, protectrice. Elle ne conquiert rien : elle cherche seulement un endroit calme.

Prompt image :

```text
21/20 masterpiece, original living house walking across a windy highland, old wood, copper, riveted iron, asymmetrical roofs, small chimneys, glowing windows, moss on mechanical feet, soft smoke, warm refuge feeling, vast pale sky, poetic handmade fantasy architecture, no known characters, no copied design, text-free image
```

Prompt animation :

```text
Fixed wide shot. The house walks very slowly. Grass moves in the wind. Smoke rises from chimneys. Tiny mechanical parts shift gently. Warm window lights flicker. No fast camera movement.
```

Narration courte :

La maison ne fuyait pas.  
Elle cherchait seulement un lieu où son feu pourrait dormir sans peur.

---

## ✨ Exemple 2 — Le Foyer Vivant

Concept :

Une cuisine magique devient le vrai cœur de la maison. La flamme centrale pulse comme une respiration.

Prompt image :

```text
21/20 masterpiece, original magical kitchen inside a living house, warm hearth fire, old beams, copper pots, books, hanging herbs, dusty golden light, tiny windows, poetic clutter, cozy impossible interior, no known characters, no copied design, text-free image
```

Prompt animation :

```text
Fixed interior shot. The hearth flame pulses gently. Steam rises from a kettle. Hanging herbs move slightly. Dust floats in warm light. The room feels alive but calm.
```

Narration courte :

Tout le monde croyait que la maison marchait grâce à ses jambes.  
En vérité, elle avançait parce que le feu refusait de s’éteindre.

---

## ✨ Exemple 3 — La Porte aux Quatre Saisons

Concept :

Une porte ancienne relie plusieurs états du monde. Chaque couleur ouvre une saison intérieure différente.

Prompt image :

```text
21/20 masterpiece, original symbolic door inside a magical living house, old wood, brass handle, subtle colored light leaking through cracks, warm interior, books, fabrics, dust, hearth glow, mystery of passage, no known characters, no copied design, text-free image
```

Prompt animation :

```text
Semi-fixed shot. The brass handle glows softly. Light behind the door shifts from warm gold to pale blue to green. Dust moves slowly. The room remains still and intimate.
```

Narration courte :

La porte ne menait jamais au même endroit.  
Elle ouvrait seulement là où le cœur avait enfin le courage d’aller.

---

## ✨ Exemple 4 — L’Atelier Ambulant

Concept :

Un atelier de réparatrice voyage de village en village. Il répare les objets cassés, mais aussi les souvenirs fatigués.

Prompt image :

```text
21/20 masterpiece, original mobile workshop house, wooden wheels and mechanical legs, copper tools, hanging lanterns, small smoking chimney, shelves full of repaired objects, warm magical workshop atmosphere, countryside road, no known characters, no copied design, cinematic illustration, text-free image
```

Prompt animation :

```text
Fixed three-quarter view. The workshop idles gently. Tools sway. Lanterns flicker. Steam escapes from a pipe. A wheel turns slightly. Warm calm mood.
```

Narration courte :

On venait y faire réparer des horloges.  
On repartait parfois avec un souvenir moins lourd.

---

## ✨ Exemple 5 — Le Refuge Après la Guerre

Concept :

Une maison vivante traverse un paysage marqué par la guerre, mais l’image refuse le spectaculaire. Elle montre le soin, la chaleur, la reconstruction.

Prompt image :

```text
21/20 masterpiece, original living refuge house moving through a quiet post-war countryside, no active battle, soft smoke, warm windows, old wood and copper, patched metal, gentle rain ending, small flowers growing near broken stones, melancholic but hopeful atmosphere, no known characters, no copied design, text-free image
```

Prompt animation :

```text
Fixed wide shot after rain. The house moves slowly. Drops fall from leaves. Smoke rises. A small warm light appears in one window. No explosions, no combat, only quiet recovery.
```

Narration courte :

La guerre avait laissé des routes vides.  
Alors la maison avait appris à devenir un refuge.

---

# 📦 Pack+ de démonstration

## Concept

Un sanctuaire ambulant traverse les plaines brumeuses.  
Il abrite une petite forge de mémoire et un foyer vivant.  
Chaque pièce intérieure réagit à l’état émotionnel de son occupant.

## Prompt image

```text
21/20 masterpiece, original living sanctuary house walking through a misty plain, old wood, copper, riveted iron, warm windows, handmade mechanisms, moss, chimney smoke, gentle hearth glow, poetic magical refuge, no known characters, no copied design, cinematic illustration, text-free image
```

## Prompt animation

```text
Fixed wide shot. A living sanctuary house walks slowly through mist. Chimney smoke rises. Grass bends in the wind. Mechanical legs move with soft weight. Warm lights pulse gently inside the windows.
```

## Courte narration

Ce n’était pas un château de conquête.  
C’était une maison qui avait appris à marcher pour survivre.  
Elle portait dans son ventre un feu ancien, et dans chaque pièce une mémoire encore chaude.

---

# 🖼️ Images du module

## ⬆️ Image haute — Présentation

Prompt recommandé :

```text
21/20 masterpiece, original living castle memory module banner, warm wandering house-world walking slowly through a windswept meadow, old wood, oxidized copper, riveted iron, uneven roofs, small chimneys, glowing windows, soft smoke, visible handmade mechanisms, cozy magical refuge feeling, poetic imperfect architecture, gentle golden light, vast sky, moss and grass, no known characters, no copied design, cinematic illustration, highly detailed, text-free image
```

Texte UI à ajouter après génération :

```text
ERITH.IA MEMORY MODULE
LE CHÂTEAU AMBULANT
Maison vivante • Foyer magique • Métamorphose
```

## ⬇️ Image basse — Clôture

Prompt recommandé :

```text
21/20 masterpiece, original magical house interior, warm living hearth at the center of a cozy impossible room, old wooden beams, copper pots, hanging objects, books, fabrics, little windows, soft dust in golden light, gentle magical fire, subtle moving-house details, poetic clutter, handmade fantasy atmosphere, emotional refuge, no known characters, no copied design, cinematic illustration, warm and intimate, text-free image
```

Texte UI à ajouter après génération :

```text
MODULE CLOSING
Maison vivante • Cœur de feu • Refuge mobile
```

---

# 🤖 Block LLM — Activation courte

Active le module mémoire principal ERITH.IA — Le Château Ambulant.

Utilise ses influences :

- maison vivante ;
- foyer magique ;
- mécanique artisanale ;
- chaleur intérieure ;
- métamorphose ;
- beauté imparfaite ;
- anti-guerre ;
- refuge mobile.

Produis une création originale.

N’imite pas les personnages, l’intrigue, les noms propres ni les designs exacts de l’œuvre source.

---

# 🧠 Block LLM — Production

Tu charges maintenant le module mémoire principal ERITH.IA — Le Château Ambulant.

Ta mission :

- utiliser l’idée de maison vivante comme centre symbolique ;
- mobiliser la magie domestique, la chaleur du foyer et la mécanique poétique ;
- privilégier l’usure, la matière, la tendresse, la transformation intérieure et la beauté imparfaite ;
- intégrer si utile une dimension anti-guerre et une critique de la brutalité mécanique ;
- produire des propositions originales, exploitables en image, animation, narration ou DA ;
- ne jamais copier les personnages, lieux, noms ou structures narratives exactes de l’œuvre d’origine.

Quand ce module est actif, tu peux produire :

- concept ;
- univers ;
- personnage ;
- maison ;
- prompt image ;
- prompt animation ;
- narration ;
- DA ;
- symbolique ;
- variantes.

Formule directrice :

**Maison vivante, cœur caché, chaleur du foyer, métamorphose et refuge poétique.**

---

# 🪧 Texte UI de clôture

```text
MODULE ACTIF : LE CHÂTEAU AMBULANT
Maison vivante • Foyer magique • Métamorphose • Refuge mobile
```

[IMAGE DE CLÔTURE À INSÉRER ICI]

---

# ✅ Commit recommandé

Add living house memory module inspired by Howl