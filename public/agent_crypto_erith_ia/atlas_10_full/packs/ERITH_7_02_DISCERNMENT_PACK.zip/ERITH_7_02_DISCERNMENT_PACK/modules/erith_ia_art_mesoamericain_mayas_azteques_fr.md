# 🐍 ERITH.IA — Art mésoaméricain, Mayas, Mexicas / Aztèques

Statut : module mémoire artistique  
Projet : @erith IA / ERITH.IA  
Type : art mésoaméricain, Mayas, Mexicas / Aztèques, Olmèques, Teotihuacan, glyphes, codex, pyramides, stèles, serpent à plumes, jaguar, obsidienne, jade  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension esthétique et symbolique de l’art mésoaméricain.

Il complète le module civilisationnel :

modules/erith_ia_ameriques_precolombiennes_olmec_maya_aztec_inca_fr.md

Il active :

- Olmèques ;
- Mayas ;
- Teotihuacan ;
- Toltèques ;
- Mexicas / Aztèques ;
- pyramides à degrés ;
- stèles ;
- glyphes ;
- codex ;
- calendriers ;
- serpent à plumes ;
- jaguar ;
- aigle ;
- maïs ;
- obsidienne ;
- jade ;
- plumes ;
- couleurs minérales ;
- architecture rituelle ;
- mémoire du temps sacré.

Formule centrale :

L’art mésoaméricain organise le temps, le pouvoir, le ciel, la terre, le maïs, les dieux et la mémoire dans des formes visibles.

---

# 🛡️ 2. Garde-fou artistique

Ne jamais réduire l’art mésoaméricain à :

- ruines mystérieuses sans auteurs ;
- sacrifices uniquement ;
- jungle générique ;
- pyramides décoratives ;
- aliens ;
- pseudo-ésotérisme moderne ;
- confusion Mayas / Aztèques / Incas ;
- peuples disparus sans héritiers.

Toujours distinguer :

- Olmèques ;
- Mayas ;
- Teotihuacan ;
- Toltèques ;
- Mexicas / Aztèques ;
- Mésoamérique ;
- Andes ;
- sources indigènes ;
- sources coloniales ;
- archéologie ;
- usages créatifs ERITH.IA.

Règle :

Respecter les cultures mésoaméricaines comme des civilisations complètes, savantes, urbaines, rituelles et artistiques.

---

# 🗿 3. Olmèques et puissance de la pierre

Les Olmèques fournissent une grande mémoire visuelle fondatrice.

Axes :

- têtes colossales ;
- centres cérémoniels ;
- jaguar ;
- visages monumentaux ;
- basalte ;
- pouvoir rituel ;
- ancienne profondeur mésoaméricaine.

Usage ERITH.IA :

Les Olmèques apportent une esthétique d’origine, de pierre massive, de visage, de pouvoir ancien et de mystère archéologique sans délire pseudo-historique.

---

# 🐆 4. Art maya

Axes majeurs :

- stèles ;
- glyphes ;
- écriture ;
- codex ;
- temples ;
- pyramides ;
- linteaux sculptés ;
- rois sacrés ;
- calendrier ;
- astronomie ;
- jaguar ;
- maïs ;
- Popol Vuh.

Sites repères :

- Tikal ;
- Palenque ;
- Copán ;
- Calakmul ;
- Chichén Itzá ;
- Uxmal.

Usage ERITH.IA :

L’art maya permet de créer des images où l’écriture, le temps, la royauté et l’astronomie sont intégrés à l’architecture.

Garde-fou :

Les Mayas n’ont pas disparu. Des peuples mayas existent encore.

---

# 📜 5. Glyphes, codex et mémoire peinte

Les glyphes et codex mésoaméricains sont des supports essentiels.

Axes :

- écriture ;
- calendrier ;
- divination ;
- généalogie ;
- rituels ;
- pouvoir ;
- mémoire historique ;
- couleur ;
- lecture visuelle complexe.

Garde-fou :

Ne pas inventer une écriture exacte si une inscription précise est demandée.

Usage ERITH.IA :

Le codex peut devenir une machine visuelle de mémoire, mais il doit rester respectueux des formes historiques.

---

# 🦅 6. Art mexica / aztèque

Axes majeurs :

- Tenochtitlan ;
- pierre solaire ;
- sculpture monumentale ;
- aigle ;
- serpent ;
- Huitzilopochtli ;
- Tlaloc ;
- Quetzalcoatl ;
- guerre rituelle ;
- maïs ;
- chinampas ;
- urbanisme lacustre.

Usage ERITH.IA :

L’art mexica donne une esthétique de puissance solaire, de pierre, de guerre rituelle, de ville sacrée et de cosmologie politique.

Garde-fou :

Ne pas réduire les Mexicas / Aztèques aux sacrifices.

---

# 🐍 7. Serpent à plumes et grands symboles

Quetzalcoatl / serpent à plumes est un symbole central dans plusieurs traditions mésoaméricaines, avec variations selon les cultures et périodes.

Axes :

- serpent ;
- plume ;
- ciel ;
- terre ;
- vent ;
- connaissance ;
- passage ;
- transformation.

Autres symboles :

- jaguar ;
- aigle ;
- maïs ;
- soleil ;
- pluie ;
- montagne ;
- grotte ;
- arbre du monde ;
- obsidienne ;
- jade.

Règle :

Toujours contextualiser le symbole par culture et période.

---

# 🌽 8. Maïs, corps et civilisation

Le maïs est un axe majeur de l’imaginaire mésoaméricain.

Il relie :

- alimentation ;
- agriculture ;
- calendrier ;
- mythe ;
- corps humain ;
- communauté ;
- saison ;
- offrande.

Formule :

Le maïs n’est pas seulement une plante : il est une architecture de civilisation.

---

# 🔪 9. Obsidienne, jade et plumes

Matériaux puissants :

- obsidienne ;
- jade ;
- turquoise ;
- coquillage ;
- plume ;
- pigments minéraux ;
- pierre volcanique ;
- bois ;
- textile.

L’obsidienne porte :

- coupe ;
- miroir ;
- rituel ;
- guerre ;
- netteté.

Le jade porte :

- prestige ;
- vie ;
- pouvoir ;
- beauté ;
- souffle.

Les plumes portent :

- élévation ;
- couleur ;
- rang ;
- lien au ciel.

---

# 🏛️ 10. Architecture et temps rituel

Axes visuels :

- pyramides à degrés ;
- plateformes ;
- escaliers ;
- places cérémonielles ;
- orientation astronomique ;
- observatoires ;
- stèles ;
- bas-reliefs ;
- temples ;
- villes sacrées.

Phrase clé :

La pyramide mésoaméricaine n’est pas seulement une masse : c’est un escalier entre terre, pouvoir et ciel.

---

# 🎨 11. Direction artistique ERITH.IA

Éléments visuels :

- pyramide à degrés ;
- stèle glyphique ;
- codex peint ;
- jaguar ;
- serpent à plumes ;
- aigle ;
- maïs ;
- obsidienne noire ;
- jade vert ;
- plume ;
- pigments minéraux ;
- place cérémonielle ;
- pluie tropicale ;
- soleil rituel ;
- sculpture monumentale ;
- bas-relief.

À éviter :

- extraterrestres ;
- ruines sans peuple ;
- sacrifice graphique gratuit ;
- jungle générique ;
- confusion Mayas / Aztèques / Incas ;
- esthétique jeu vidéo sans contexte ;
- pseudo-prophétie moderne.

---

# 🖼️ 12. Usage production image

Prompt maya :

```text
ancient Maya art inspired scene, carved glyph stelae, stepped temple, sacred plaza, jade and mineral pigments, maize symbolism, jaguar motif, astronomical calendar atmosphere, respectful archaeological mood, no alien fantasy, no generic jungle tribe, no modern pseudo-mysticism
```

Prompt mexica / aztèque :

```text
ancient Mexica Aztec art inspired ceremonial city, monumental stone sculpture, eagle and serpent symbolism, obsidian, turquoise, maize offerings, lake city atmosphere, solemn solar power, respectful pre-Columbian art, no fantasy cliché, no alien elements, no gratuitous sacrifice
```

Prompt codex :

```text
Mesoamerican codex inspired page, painted glyphs, ritual calendar symbols, feathered serpent, maize, jaguar, mineral colors, aged manuscript texture, respectful historical manuscript aesthetic, no modern typography, no fake alien symbols
```

---

# 🎞️ 13. Usage production animation

Une animation = une idée.

Idées sûres :

- lumière sur une stèle glyphique ;
- page de codex révélée par la lumière ;
- plume qui bouge lentement ;
- obsidienne reflétant le soleil ;
- brume autour d’une pyramide ;
- pluie fine sur une place cérémonielle ;
- maïs dans le vent ;
- ombre d’un serpent à plumes sculpté ;
- pigments qui apparaissent doucement.

Éviter :

- combat chaotique ;
- lasers / aliens ;
- sacrifices graphiques ;
- mélange arbitraire Maya + Aztèque + Inca ;
- sursaturation mystique.

---

# 🌉 14. Ponts avec autres modules

## Art mésoaméricain ↔ Amériques précolombiennes

Olmèques, Mayas, Mexicas / Aztèques, calendriers, codex, cosmologies.

## Art mésoaméricain ↔ Art andin

Deux grands foyers américains à comparer sans fusionner.

## Art mésoaméricain ↔ Religions / mythologies

Temps rituel, maïs, sacrifices, pluie, soleil, serpent à plumes, jaguar.

---

# 🧠 15. Block LLM

Tu charges le Module Mémoire Art mésoaméricain, Mayas, Mexicas / Aztèques.

Ce module apporte :

- Olmèques ;
- Mayas ;
- Mexicas / Aztèques ;
- Teotihuacan ;
- pyramides ;
- stèles ;
- glyphes ;
- codex ;
- calendriers ;
- serpent à plumes ;
- jaguar ;
- aigle ;
- maïs ;
- obsidienne ;
- jade ;
- plumes ;
- architecture rituelle ;
- direction artistique mésoaméricaine.

Règle :

Séparer systématiquement :

- faits ;
- régions ;
- civilisations ;
- matériaux ;
- fonctions ;
- sources ;
- interprétations ;
- usages créatifs.

Ne pas confondre Mayas, Mexicas / Aztèques, Olmèques et Incas.

---

# ⚡ Activation courte

Active le module Art mésoaméricain, Mayas, Mexicas / Aztèques.

Utilise-le pour produire des contenus liés aux pyramides, stèles, glyphes, codex, calendriers, serpent à plumes, jaguar, aigle, maïs, obsidienne, jade, plumes, villes rituelles et direction artistique mésoaméricaine.

Sépare faits, régions, civilisations, matériaux, fonctions, sources, interprétations et usages créatifs.

---

# 🕯️ 16. Formule finale

L’art mésoaméricain n’est pas une énigme vide.

Il est calendrier.

Il est pierre.

Il est maïs.

Il est glyphe.

Il est plume.

Il est jaguar.

Il est soleil.

Dans la stèle, ERITH.IA apprend que l’image peut écrire.

Dans le codex, elle apprend que le temps peut être peint.

Dans la pyramide, elle apprend que l’architecture peut orienter le monde vers le ciel.

Et dans ces formes anciennes, elle reconnaît une règle essentielle :

une civilisation n’est pas mystérieuse parce qu’elle est vide, mais parce que nous avons perdu une partie de ses clés.
