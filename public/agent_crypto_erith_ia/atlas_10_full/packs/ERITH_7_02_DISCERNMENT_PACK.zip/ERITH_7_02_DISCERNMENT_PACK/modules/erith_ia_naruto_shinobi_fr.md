# 🍥 ERITH.IA — Module Mémoire — Naruto / Shinobi

Nom du fichier : erith_ia_naruto_shinobi_fr.md  
Type : Module Mémoire / Direction Artistique / Influence anime  
Statut : Public ou semi-public selon usage  
Usage : ERITH.IA, Seven Heaven, modules créatifs, Hors-Lore, prompts image, prompts vidéo, analyse symbolique

---

## 🌀 1. Intention du module

Ce module permet à ERITH.IA d’utiliser Naruto comme influence culturelle, esthétique et symbolique, sans copier l’œuvre, ses personnages, ses noms propres, ses intrigues ou ses designs exacts.

Naruto est utilisé ici comme grammaire d’influence autour de plusieurs axes :

- 🍃 le village comme communauté, mémoire et blessure ;
- 🌀 le chakra comme énergie intérieure structurée ;
- 🦊 la bête scellée comme puissance rejetée ;
- 🧬 le clan comme héritage, don et prison ;
- 👁️ l’œil comme perception, lignée et vérité dangereuse ;
- 📜 le jutsu comme technique, discipline et langage du corps ;
- 🤝 le lien comme force narrative centrale ;
- 🔥 la volonté comme feu intérieur ;
- 🧑‍🏫 la transmission maître / élève ;
- 🩹 la blessure transformée en responsabilité.

Ce module ne sert pas à reproduire Naruto.  
Il sert à créer des mondes originaux inspirés par ses grandes forces symboliques, émotionnelles et visuelles.

---

## 📘 2. Résumé court de Naruto

Naruto est un manga de Masashi Kishimoto, adapté en série animée par Studio Pierrot. L’histoire suit Naruto Uzumaki, un jeune ninja rejeté par son village parce qu’il porte en lui une puissance monstrueuse scellée. Son rêve est de devenir Hokage, chef du village, pour être reconnu et protéger les autres.

L’univers repose sur plusieurs structures fortes :

- 🏯 les villages cachés ;
- 🥷 les shinobi ;
- 🌀 le chakra ;
- 📜 les techniques ninja ;
- 🧬 les clans ;
- 🦊 les démons à queues ;
- 👁️ les pouvoirs héréditaires ;
- 🤝 les équipes ;
- 🔥 la volonté du feu ;
- 🕊️ le cycle de haine et la possibilité de le briser.

La première série animée Naruto compte 220 épisodes.  
Naruto: Shippuden compte 500 épisodes.  
L’ensemble forme l’un des grands piliers mondiaux de l’anime shōnen moderne.

---

## 🧭 3. Résumé détaillé des grands arcs

### 🌱 3.1 Prologue / Académie / Équipe 7

Naruto est présenté comme un enfant isolé, bruyant, maladroit, mais animé par une volonté immense. Il rejoint l’Équipe 7 avec Sasuke, Sakura et Kakashi.

Fonctions narratives :

- solitude initiale ;
- désir de reconnaissance ;
- naissance d’une équipe ;
- rivalité fondatrice ;
- premier rapport maître / élève ;
- découverte de la discipline shinobi.

Usage ERITH.IA :

- personnage rejeté qui cherche une place ;
- équipe fragile construite autour de blessures différentes ;
- mentor masqué ou distant ;
- apprentissage par échec répété ;
- première activation d’un potentiel caché.

---

### 🌉 3.2 Pays des Vagues

Premier arc majeur de mission réelle. Naruto et son équipe découvrent que le monde ninja n’est pas un jeu : pauvreté, mercenariat, sacrifice, armes humaines et attachement aux personnes protégées.

Fonctions narratives :

- passage de l’entraînement à la réalité ;
- ennemi humainisé ;
- violence sociale ;
- loyauté ;
- sacrifice ;
- naissance d’un code moral personnel.

Usage ERITH.IA :

- mission qui révèle le monde réel ;
- adversaire tragique ;
- pont comme symbole de passage ;
- protection d’un peuple ou d’un lieu fragile ;
- première blessure morale du héros.

---

### 🏯 3.3 Examens Chūnin

Les jeunes ninjas affrontent une série d’épreuves physiques, tactiques et psychologiques. L’arc révèle les autres villages, les rivalités, les génies, les monstres intérieurs et les ambitions cachées.

Fonctions narratives :

- tournoi initiatique ;
- épreuve de survie ;
- révélation des clans ;
- hiérarchie des talents ;
- naissance des grandes rivalités ;
- intrusion d’une menace supérieure.

Usage ERITH.IA :

- concours rituel ;
- école dangereuse ;
- forêt d’épreuve ;
- village observateur ;
- talent inné contre volonté travaillée ;
- jeune personnage forcé de montrer son vrai potentiel.

---

### 🐍 3.4 Invasion de Konoha / Orochimaru

La structure du village est attaquée de l’intérieur et de l’extérieur. L’arc oppose héritage, trahison, ambition interdite, immortalité et transmission.

Fonctions narratives :

- maître déchu ;
- savoir interdit ;
- corps comme outil de prolongation ;
- invasion stratégique ;
- sacrifice du chef ;
- village blessé mais vivant.

Usage ERITH.IA :

- ancien disciple devenu menace ;
- science interdite du corps et de l’âme ;
- attaque rituelle contre un centre politique ;
- sacrifice d’un gardien ancien ;
- héritage transmis par la perte.

---

### 🏃 3.5 Recherche de Tsunade

Naruto part chercher une nouvelle figure de commandement. L’arc met en avant le traumatisme, la guérison, la médecine, le pari, le sang et la décision de reprendre une responsabilité malgré la douleur.

Fonctions narratives :

- guérisseuse blessée ;
- peur du sang ;
- pari contre le destin ;
- héritage des anciens ;
- reconnaissance du potentiel de Naruto.

Usage ERITH.IA :

- médecin sacrée traumatisée ;
- chef refusant sa fonction ;
- guérison comme courage ;
- héritage des morts qui pousse à agir ;
- pacte de transmission.

---

### 🌑 3.6 Récupération de Sasuke

Sasuke quitte le village pour chercher une puissance interdite. Naruto et ses alliés tentent de le ramener. L’arc cristallise la rupture, la rivalité et la douleur du lien perdu.

Fonctions narratives :

- ami devenu fuyard ;
- pouvoir contre appartenance ;
- marque maudite ;
- choix de l’ombre ;
- promesse impossible ;
- duel fraternel.

Usage ERITH.IA :

- compagnon qui choisit l’exil ;
- mission de récupération émotionnelle ;
- duel entre lien et vengeance ;
- pouvoir interdit comme accélérateur tragique ;
- promesse qui devient moteur narratif.

---

### 🕰️ 3.7 Début Shippuden / Sauvetage de Gaara

Après l’ellipse, Naruto revient plus mûr. L’Akatsuki devient une menace centrale. L’arc de Gaara montre la solitude du réceptacle, la responsabilité politique et le sacrifice collectif.

Fonctions narratives :

- retour du héros entraîné ;
- réceptacle devenu chef ;
- extraction d’une bête intérieure ;
- sacrifice ;
- fraternité entre êtres rejetés.

Usage ERITH.IA :

- porteur de monstre devenu gardien ;
- chef autrefois rejeté ;
- extraction d’énergie vitale ;
- opération de sauvetage spirituelle ;
- reconnaissance entre deux solitudes.

---

### 🕷️ 3.8 Akatsuki / Asuma / Hidan-Kakuzu

L’Akatsuki s’impose comme réseau d’antagonistes idéologiques. L’arc d’Asuma met en scène la transmission, la perte du maître et la maturation de Shikamaru.

Fonctions narratives :

- organisation de l’ombre ;
- duo d’ennemis complémentaires ;
- mort du mentor ;
- stratégie froide ;
- héritage confié à la génération suivante.

Usage ERITH.IA :

- cellule ennemie rituelle ;
- mentor qui laisse une phrase-clef ;
- disciple obligé de devenir stratège ;
- vengeance transformée en plan ;
- feu transmis.

---

### 🐸 3.9 Jiraiya / Pain / Invasion de Konoha

Jiraiya affronte Pain et meurt en transmettant une dernière information. Naruto revient ensuite comme porteur d’un apprentissage spirituel, affronte Pain et tente de briser le cycle de haine par la compréhension.

Fonctions narratives :

- maître pèlerin ;
- sacrifice d’enquête ;
- village détruit ;
- pouvoir sage ;
- douleur collective ;
- paix impossible sans écoute de la souffrance.

Usage ERITH.IA :

- mentor voyageur ;
- dernier message codé ;
- ville détruite puis relevée ;
- antagoniste né de la guerre ;
- choix de ne pas reproduire la vengeance ;
- parole qui brise un cycle.

---

### 👁️ 3.10 Sasuke / Itachi / vérité du clan

Le conflit entre Sasuke et Itachi révèle une tragédie familiale et politique plus complexe qu’une simple vengeance. La vérité transforme le sens de toute la haine de Sasuke.

Fonctions narratives :

- frère ennemi ;
- mensonge protecteur ;
- clan sacrifié ;
- vérité insupportable ;
- œil comme mémoire et trauma ;
- vengeance déplacée.

Usage ERITH.IA :

- vérité familiale destructrice ;
- protecteur diabolisé ;
- archive cachée d’un massacre ;
- regard héréditaire ;
- amour déformé par le secret ;
- mémoire politique explosive.

---

### 🌊 3.11 Sommet des Kage / Guerre imminente

Les grandes puissances ninja se réunissent face à une menace commune. L’univers s’élargit politiquement : villages, chefs, alliances, diplomatie, guerre mondiale.

Fonctions narratives :

- conseil de dirigeants ;
- rivalités historiques ;
- menace globale ;
- alliance forcée ;
- diplomatie tendue ;
- guerre annoncée.

Usage ERITH.IA :

- conseil des cités cachées ;
- table de guerre ;
- alliance impossible mais nécessaire ;
- monde forcé de reconnaître une menace systémique ;
- chef porteur d’un traumatisme ancien.

---

### ⚔️ 3.12 Quatrième Grande Guerre Ninja

La guerre finale rassemble vivants, morts, anciens héros, anciens ennemis et vérités enfouies. L’arc met en scène l’héritage, la réincarnation symbolique, la manipulation de masse, la guerre totale et la possibilité d’une paix nouvelle.

Fonctions narratives :

- guerre mondiale ;
- armée des morts ;
- héritage des générations ;
- illusions collectives ;
- révélation des origines ;
- union finale ;
- dépassement du cycle de haine.

Usage ERITH.IA :

- guerre des mémoires ;
- anciens héros rappelés comme archives vivantes ;
- illusion-monde imposée à toute l’humanité ;
- alliance finale des rivaux ;
- héritage qui doit être compris, pas seulement vaincu.

---

## 🔮 4. Grammaire symbolique Naruto

### 🌀 4.1 Le chakra

Le chakra est une énergie intérieure structurée. Il n’est pas seulement magique : il relie corps, esprit, discipline, respiration, héritage et intention.

Axes symboliques :

- énergie vitale disciplinée ;
- lien corps / esprit ;
- technique comme forme de langage ;
- pouvoir qui demande entraînement et contrôle.

Usage ERITH.IA :

Créer des systèmes d’énergie où la puissance dépend de la respiration, de la mémoire, du geste, du rythme et de l’intention.

---

### 🦊 4.2 La bête scellée

Le démon intérieur de Naruto représente la puissance rejetée, la peur collective, la solitude imposée et la possibilité de transformer une malédiction en alliance.

Axes symboliques :

- monstre intérieur ;
- puissance héritée sans consentement ;
- rejet social ;
- dialogue avec ce qui fait peur ;
- réconciliation comme maîtrise supérieure.

Usage ERITH.IA :

Créer des personnages qui ne détruisent pas leur part dangereuse, mais apprennent à négocier avec elle.

---

### 🍃 4.3 Le village

Le village caché est à la fois refuge, famille, système politique, machine militaire, mémoire collective et lieu de blessures.

Axes symboliques :

- communauté protectrice ;
- secret collectif ;
- institution imparfaite ;
- appartenance ;
- dette envers les générations précédentes.

Usage ERITH.IA :

Créer des cités-mémoires, des monastères tactiques, des villages cachés technomagiques ou spirituels où chaque lieu porte une cicatrice.

---

### 👁️ 4.4 L’œil héréditaire

L’œil dans Naruto est souvent lié à une lignée, une mémoire, une perception augmentée ou une malédiction familiale.

Axes symboliques :

- voir plus que les autres ;
- héritage qui enferme ;
- regard comme pouvoir ;
- mémoire du sang ;
- perception dangereuse.

Usage ERITH.IA :

Créer des personnages dont la vision révèle la vérité, mais coûte une part d’humanité, de paix ou d’intimité.

---

### 🔥 4.5 La volonté

La volonté est un moteur central de Naruto. Elle n’est pas simple obstination : elle devient capacité à se relever, protéger, transmettre et transformer la haine.

Axes symboliques :

- persévérance ;
- refus de l’abandon ;
- transmission ;
- feu intérieur ;
- promesse tenue malgré la douleur.

Usage ERITH.IA :

Créer des récits où la victoire ne vient pas seulement du talent, mais d’un serment répété jusqu’à devenir forme.

---

## 🎨 5. Direction Artistique — Style Lock Naruto

### 🎛️ 5.1 Palette

Palette dominante :

- 🟠 orange / feu / volonté ;
- 🔵 bleu nuit / chakra ;
- ⚫ noir d’encre / tenue tactique ;
- 🟢 vert forêt / village caché ;
- 🟤 brun terre / entraînement ;
- 🔴 rouge sceau / danger intérieur ;
- ⚪ blanc rituel / bandages / fumée.

Principe :

La DA Naruto doit rester lisible, dynamique, terrestre, tactique et émotionnelle.  
Elle peut être plus chaude et organique que Bleach.  
Le monde doit sentir l’entraînement, la poussière, le bois, la pierre, les toits, les forêts et la course.

---

### 🥷 5.2 Silhouettes

Codes visuels :

- bandeau frontal ;
- veste courte ou manteau de voyage ;
- sandales / bandages / poches tactiques ;
- scrolls ;
- kunai et shuriken ;
- capuche ou masque ;
- posture basse, prête à bondir ;
- mains en signes ;
- silhouette en course ou en saut.

Usage ERITH.IA :

Créer des silhouettes originales de messagers, protecteurs, éclaireurs, maîtres de sceaux, enfants d’un village caché ou gardiens d’un feu ancien.

---

### 🎥 5.3 Plans et cadrages

Plans typiques à retenir :

- course sur les toits ;
- duel dans une forêt ;
- élève face au maître ;
- cercle d’entraînement ;
- gros plan sur les yeux ;
- mains qui forment un signe ;
- personnage seul sur un poteau ou une falaise ;
- village vu depuis les hauteurs ;
- tempête de poussière après impact.

Usage vidéo :

Pour Wan / I2V, éviter les combats complexes.  
Privilégier :

- bandeau qui bouge dans le vent ;
- aura de chakra qui pulse ;
- feuilles qui tournent ;
- mains qui restent presque immobiles autour d’un signe ;
- poussière au sol ;
- regard qui s’allume ;
- clones suggérés par une brume légère plutôt que multipliés en détail.

---

### 🏯 5.4 Architecture

Inspirations structurelles :

- village caché dans la montagne ;
- toits de tuiles ;
- portes monumentales ;
- terrain d’entraînement ;
- forêt d’épreuve ;
- salle du conseil ;
- archives de clans ;
- temple de sceaux ;
- statues géantes de fondateurs ;
- pont entre deux territoires.

Usage ERITH.IA :

Créer des lieux originaux : village du vent rouge, monastère des sceaux, forêt d’entraînement des héritiers, falaise des anciens maîtres, archive des techniques interdites, quartier des clans oubliés.

---

### ✨ 5.5 Énergie et effets

Effets visuels compatibles :

- aura de chakra bleue ou dorée ;
- sceaux rouges ;
- fumée de substitution ;
- feuilles spiralées ;
- poussière ;
- cordes de chakra ;
- lignes de vitesse ;
- fissures de terre ;
- œil activé ;
- silhouette de bête intérieure en arrière-plan.

Éviter :

- lasers sci-fi ;
- armures futuristes sans justification ;
- explosion magique générique ;
- designs trop super-héros ;
- copie directe de tenues Naruto ;
- symboles de villages existants repris tels quels.

---

## 🧬 6. Archétypes utilisables sans copie

### 🍥 6.1 L’enfant rejeté devenu gardien

Personnage porteur d’une force qui effraie son peuple, mais qui choisit malgré tout de protéger ce peuple.

Usage :

- héros solaire ;
- enfant-bouclier ;
- porteur de sceau ;
- gardien d’un village qui l’a rejeté.

---

### 👁️ 6.2 L’héritier aux yeux dangereux

Personnage issu d’un clan dont la perception est un pouvoir et une prison.

Usage :

- rival sombre ;
- survivant de clan ;
- gardien d’une mémoire familiale ;
- personnage tenté par la vengeance.

---

### 🧑‍🏫 6.3 Le maître masqué

Mentor calme, ironique ou distant, porteur d’une blessure passée et d’une méthode indirecte.

Usage :

- guide tactique ;
- professeur survivant ;
- ancien agent d’ombre ;
- gardien de l’équipe.

---

### 📜 6.4 Le maître des sceaux

Personnage qui comprend que le monde est écrit en signes, verrous, flux, contrats et interdits.

Usage :

- archiviste tactique ;
- calligraphe de combat ;
- gardien de prison intérieure ;
- réparateur de liens énergétiques.

---

### 🕊️ 6.5 Le pacificateur après la guerre

Personnage qui a connu la haine, mais cherche à casser son cycle.

Usage :

- ancien soldat ;
- diplomate blessé ;
- héritier d’un conflit ancien ;
- héros qui refuse la vengeance malgré la perte.

---

## 🌌 7. Thèmes compatibles ERITH.IA

Thèmes majeurs :

- 🍃 village ;
- 🌀 chakra ;
- 🦊 bête intérieure ;
- 📜 sceau ;
- 👁️ perception héréditaire ;
- 🧬 clan ;
- 🤝 équipe ;
- 🧑‍🏫 transmission ;
- 🔥 volonté ;
- 🌑 solitude ;
- 🩹 blessure ;
- 🕊️ paix ;
- ⚔️ rivalité ;
- 🏯 héritage politique ;
- 🧠 mémoire collective ;
- 🐍 savoir interdit ;
- 🕰️ cycle de haine.

Connexions fortes avec ERITH.IA :

- module comme jutsu ;
- prompt comme signe d’activation ;
- archive GitHub comme rouleau de techniques ;
- Seven comme gardienne des sceaux ;
- interface comme village caché ;
- mémoire comme chakra structuré ;
- version supérieure comme mode ermite / synchronisation intérieure ;
- bête intérieure comme puissance à intégrer, pas à nier.

---

## 🛡️ 8. Garde-fous créatifs

Ne pas faire :

- ne pas copier Naruto, Sasuke, Sakura, Kakashi, Itachi, Pain, Madara ou d’autres personnages ;
- ne pas reprendre les designs exacts ;
- ne pas utiliser les noms propres de Naruto dans les créations finales Hors-Lore ;
- ne pas reproduire Konoha ou les villages existants tels quels ;
- ne pas copier les symboles officiels de bandeaux ;
- ne pas reprendre les jutsu officiels comme Rasengan, Chidori, Sharingan, Byakugan, etc. ;
- ne pas créer une scène qui semble être un fan art déguisé si l’objectif est un univers original.

Faire :

- utiliser la grammaire symbolique ;
- transformer les influences en archétypes originaux ;
- créer des noms nouveaux ;
- créer des villages, clans et techniques originaux ;
- créer des systèmes de sceaux et d’énergie propres ;
- séparer référence culturelle et production originale.

---

## 🔗 9. Références consultables par LLM

### 🏛️ Sources officielles

Site officiel Naruto :  
https://naruto-official.com/en

Page officielle VIZ — Naruto :  
https://www.viz.com/naruto

Page officielle TV Tokyo — Naruto / Naruto Shippuden :  
https://www.tv-tokyo.co.jp/anime/naruto/

### 📚 Sources de structure narrative

Naruto TV series — Wikipédia :  
https://en.wikipedia.org/wiki/Naruto_(TV_series)

Liste des épisodes Naruto — Wikipédia :  
https://en.wikipedia.org/wiki/List_of_Naruto_episodes

Liste des épisodes Naruto Shippuden — Wikipédia :  
https://en.wikipedia.org/wiki/List_of_Naruto:_Shippuden_episodes

Liste des épisodes Naruto Shippuden — Wikipédia FR :  
https://fr.wikipedia.org/wiki/Liste_des_%C3%A9pisodes_de_Naruto_Shippuden

### 🧭 Sources fan wiki / arcs / concepts

Narutopedia — Naruto Wiki :  
https://naruto.fandom.com/wiki/Narutopedia

Narutopedia — Plot of Naruto :  
https://naruto.fandom.com/wiki/Plot_of_Naruto

Narutopedia — Chakra :  
https://naruto.fandom.com/wiki/Chakra

Narutopedia — Jutsu :  
https://naruto.fandom.com/wiki/Jutsu

Narutopedia — Shinobi :  
https://naruto.fandom.com/wiki/Shinobi

Narutopedia — Tailed Beasts :  
https://naruto.fandom.com/wiki/Tailed_Beast

Narutopedia — Hidden Villages :  
https://naruto.fandom.com/wiki/Hidden_Village

### 🧠 Usage recommandé des liens

Ces liens servent de bibliothèque externe consultable.  
Le module ne doit pas recopier massivement les contenus.  
Il doit s’en servir pour comprendre :

- les arcs ;
- les épisodes ;
- les villages ;
- les clans ;
- la logique du chakra ;
- les techniques ;
- les démons à queues ;
- les structures maître / élève ;
- les codes visuels ;
- les thèmes de solitude, volonté, transmission, paix et cycle de haine.

---

## 🖼️ 10. Prompts maîtres — image

### 🍃 Prompt image — Shinobi original / village caché

Un jeune gardien shinobi original se tient sur le toit d’un village caché construit dans la montagne, bandeau sans symbole officiel, veste courte sombre, rouleau de sceaux attaché au dos, aura de chakra bleu discret autour des mains, feuilles tournoyant dans le vent, lumière dorée de fin d’après-midi, village en contrebas, sentiment de solitude et de volonté, composition cinématographique anime, silhouette lisible, original character design, no existing Naruto character.

Prompt négatif :

Naruto, Sasuke, Sakura, Kakashi, Konoha symbol, Sharingan, Rasengan, Chidori, fan art, copied anime frame, official logo, text, watermark, low quality, superhero costume, sci-fi armor, extra limbs, bad anatomy.

---

### 🦊 Prompt image — Porteur de sceau / bête intérieure

Un personnage original porte un sceau rouge lumineux sur l’abdomen, manteau orange sombre et noir sans design officiel, silhouette d’une bête spirituelle abstraite derrière lui dans la brume, forêt nocturne, poussière, feuilles en spirale, regard déterminé, énergie intérieure contenue, tension entre peur et maîtrise, anime cinematic high detail, original universe, no franchise character.

Prompt négatif :

Kurama exact design, Naruto character, fox demon exact, Konoha symbol, fan art, copied design, glowing overload, gore, logo, text, watermark, poor anatomy.

---

### 📜 Prompt image — Temple des sceaux

Un temple original des sceaux caché dans une forêt ancienne, rouleaux suspendus, calligraphies lumineuses rouges sur le sol, pierres gravées, maître des sceaux en silhouette devant une porte scellée, aura bleue très faible, ambiance de discipline, secret, transmission et danger contenu, style anime cinématographique, terre, bois, pierre, lumière douce, no existing anime location.

Prompt négatif :

Konoha exact, Naruto symbols, copied location, fan art, logo, text, sci-fi neon overload, cluttered composition, low detail.

---

## 🎞️ 11. Prompts maîtres — animation Wan / I2V

### 🍃 Animation 1 — Chakra calme sur le toit

Caméra fixe. Le shinobi original reste immobile sur le toit. Son bandeau et sa veste bougent doucement dans le vent. De petites feuilles traversent le cadre. Une faible aura de chakra bleu pulse autour de ses mains. Le village reste stable en arrière-plan. Aucun saut, aucune course, aucun combat. Ambiance de veille et de promesse. Durée courte, 9:16, 16 fps, mouvement minimal, stabilité maximale.

Prompt négatif :

camera shake, running, jumping, fighting, clones multiplying, face morphing, outfit changing, extra limbs, duplicated character, unstable background, official symbol, text, logo.

---

### 🦊 Animation 2 — Sceau intérieur

Caméra fixe en plan mi-corps. Le personnage baisse légèrement la tête. Le sceau rouge sur l’abdomen pulse lentement. Une ombre de bête abstraite apparaît dans la brume derrière lui, sans forme précise. Les feuilles tournent doucement. L’aura reste contenue. Aucun changement de design. Atmosphère de maîtrise intérieure. Durée courte, 9:16, 16 fps.

Prompt négatif :

monster transformation, exact fox demon, Naruto design, fast motion, camera spin, gore, face distortion, character duplication, official logo, text, watermark.

---

### 📜 Animation 3 — Rouleau de sceaux

Caméra fixe sur un rouleau ouvert au sol. Des lignes de calligraphie rouge s’allument lentement. Une brume blanche apparaît, puis se dissipe. En arrière-plan, une silhouette garde les mains jointes dans un signe stable. Ambiance rituelle, calme, technique, maîtrise. Durée courte, 9:16, 16 fps.

Prompt négatif :

explosion, fast hand signs, flying objects, changing symbols, copied jutsu, text overlay, logo, unstable anatomy, low quality.

---

## 🎬 12. Usage vidéo — cartes utiles

Pour une production ERITH.IA influencée par Naruto, activer en priorité :

- 📐 Géométrie du Plan ;
- 🧠 Psychologie du Plan ;
- 🔮 Symbolique ;
- 🧱 LEGO Continuity ;
- 🩺 Diagnostic Anti-Dérive Wan ;
- 🎧 Sound Design / Voix / Silence.

Risque principal :

La dérive vers le fan art explicite, les clones multiples, les combats trop rapides ou la reproduction de techniques officielles.

Action immédiate recommandée :

Verrouiller une image source très simple :

- un shinobi original ;
- un lieu ;
- un sceau ou une aura ;
- une émotion ;
- un mouvement vidéo maximum.

Point d’arrêt :

Quand le village, le sceau, le chakra et l’émotion sont lisibles, ne pas complexifier.

---

## 🎧 13. Sound Design / Silence

Naruto fonctionne très bien avec une émotion sonore simple : vent, flûte, tambour discret, pas sur le bois, feuilles, respiration, silence avant promesse.

Sons compatibles :

- vent dans les feuilles ;
- tissu ;
- pas sur toiture ;
- souffle court ;
- vibration de chakra ;
- froissement de rouleau ;
- cloche lointaine ;
- tambour discret ;
- silence avant décision ;
- respiration d’un personnage seul.

Éviter :

- musique épique automatique ;
- percussion permanente ;
- techno sans justification ;
- bruitage de combat permanent ;
- surcharge sonore.

Décision sonore recommandée :

La scène doit souvent commencer par le vent ou le silence, puis laisser apparaître un motif simple : souffle, chakra, feuille, battement grave ou phrase intérieure.

---

## 🤖 14. Block LLM compatible

### 🪪 Identité du module

Tu es le Module Mémoire Naruto / Shinobi pour ERITH.IA.

Tu n’es pas un générateur de fan fiction Naruto.  
Tu n’es pas chargé de copier les personnages, les noms propres, les arcs, les villages ou les designs exacts de Naruto.

Tu utilises Naruto comme influence culturelle, symbolique et visuelle autour de :

- le chakra ;
- le village caché ;
- le clan ;
- le sceau ;
- le démon intérieur ;
- le maître et l’élève ;
- l’équipe ;
- la rivalité ;
- la solitude ;
- la volonté ;
- la transmission ;
- le cycle de haine ;
- la paix après la guerre.

### ⚙️ Règles d’usage

Quand ce module est activé :

1. Cherche la fonction symbolique de la demande.
2. Ne copie jamais Naruto directement.
3. Remplace les noms, villages, clans, techniques et pouvoirs par des équivalents originaux.
4. Garde la grammaire visuelle : village, chakra, sceau, feuille, poussière, bandeau neutre, entraînement, transmission.
5. Privilégie les scènes simples, émotionnelles, lisibles.
6. Pour la vidéo, limite le mouvement à une idée claire.
7. Pour les prompts, ajoute toujours un garde-fou anti-fan-art.
8. Pour l’analyse, sépare référence, interprétation et usage créatif.

### 🛑 Limites

Ne pas produire :

- une copie de Naruto, Sasuke, Sakura, Kakashi, Itachi, Pain, Madara ou tout autre personnage ;
- un village officiel reproduit ;
- un symbole officiel de bandeau ;
- un jutsu officiel ;
- un œil officiel reconnaissable ;
- un démon à queues officiel ;
- une intrigue directement reprise ;
- un design identifiable comme image officielle ou fan art direct.

### ⚡ Activation courte

Active le Module Mémoire Naruto / Shinobi.  
Utilise Naruto comme influence symbolique et visuelle autour du chakra, du village caché, du sceau, du démon intérieur, de la volonté, du clan, de la transmission maître / élève et du cycle de haine.  
Ne copie aucun personnage, pouvoir, nom propre, village, jutsu ou design exact.  
Crée uniquement des scènes et concepts originaux compatibles ERITH.IA.

### 🚀 Activation production

Active le Module Mémoire Naruto / Shinobi en mode production ERITH.IA.

Objectif : créer une scène originale influencée par la grammaire Naruto sans copier l’œuvre.

Utilise les axes suivants :

- chakra comme énergie intérieure structurée ;
- sceau comme verrou narratif ;
- village comme mémoire collective ;
- bête intérieure comme puissance rejetée à intégrer ;
- équipe comme famille choisie ;
- maître / élève comme transmission ;
- volonté comme feu intérieur ;
- rivalité comme miroir ;
- cycle de haine comme structure à briser.

Pour une image : produire une composition simple, lisible, émotionnelle.  
Pour une animation : une seule idée de mouvement, caméra fixe, stabilité maximale.  
Pour le son : décider d’abord entre vent, silence, souffle, feuilles, vibration de chakra, tambour discret ou absence de musique.

Toujours inclure un garde-fou : no existing Naruto character, no copied design, no official village symbol, no official jutsu, no franchise logo, no fan art, original universe.

---

## 🌸 15. Formule courte

Naruto, pour ERITH.IA, n’est pas seulement une histoire de ninjas.  
C’est une grammaire de la volonté blessée.

Chakra = énergie intérieure disciplinée.  
Sceau = blessure verrouillée.  
Village = mémoire collective.  
Bête intérieure = puissance rejetée.  
Maître = transmission.  
Rival = miroir.  
Volonté = feu qui refuse de mourir.

ERITH.IA ne copie pas Naruto.  
ERITH.IA apprend à écrire avec la feuille, le sceau, le souffle, la promesse et le feu intérieur.
