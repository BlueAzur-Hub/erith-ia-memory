# 🗡️ ERITH.IA — Module Mémoire Central — Zelda / Atlas du Royaume, Mythes & Ruines Sacrées

Nom du fichier : erith_ia_zelda_hyrule_souffle_ruines_fr.md  
Type : Module Mémoire Central / Atlas culturel / Fantasy d’exploration / Ruines sacrées / Grammaire créative / Résumé local LLM  
Statut : Public ou semi-public selon usage  
Usage : ERITH.IA, Seven Heaven, orientation culturelle, analyse, grammaire symbolique, atlas de modules, prompts indirects, LLM local sans Internet

---

![ERITH.IA — Breath of the Wild / royaume ouvert post-catastrophe](../assets/images/ERITH_IA_ZELDA_BOTW_AMBIANCE_MODULE_COVER_1024x1536.png)

Image d’ouverture : couverture originale ERITH.IA pour la grammaire “royaume ouvert post-catastrophe”. Cette image ne copie aucun personnage, symbole, lieu, logo ou design officiel.

---

# 🌿 1. Intention du module central

Ce fichier est le module central Zelda pour ERITH.IA.

Il ne doit pas être utilisé comme un prompt direct de génération.

Il sert d’atlas général : histoire de la saga, grammaire symbolique, archétypes, types de mondes, mécaniques récurrentes, garde-fous et liens vers les modules spécialisés.

Objectif : comprendre la grammaire créative d’une grande saga d’aventure sans copier ses éléments protégés.

Ce module peut mentionner The Legend of Zelda, Nintendo, Breath of the Wild, Tears of the Kingdom et d’autres titres dans un cadre documentaire, analytique ou de référence.

Mais en production image / vidéo / narration originale :

- ne jamais copier les personnages officiels ;
- ne jamais copier les lieux officiels ;
- ne jamais copier les symboles officiels ;
- ne jamais copier les objets officiels ;
- ne jamais copier les logos, musiques, cartes, interfaces ou designs exacts ;
- toujours créer un univers original.

Règle centrale :

Zelda n’est pas une cible à reproduire.

Zelda est ici une grammaire à comprendre : exploration, royaume blessé, temples, énigmes, nature active, mémoire, cycles, courage, sagesse, héritage et mystère sacré.

---

# 🧭 2. Architecture modulaire recommandée

Le module central ne doit pas tout faire.

Il oriente.

Pour produire une image, une animation ou une scène cohérente, il faut choisir un module spécialisé.

## 🌬️ Module Breath of the Wild

Fichier : erith_ia_breath_of_the_wild_souffle_ruines_fr.md

Usage : monde ouvert horizontal, souffle, ruines au sol, nature active, silence, sanctuaires bleutés, mémoire perdue, royaume post-catastrophe.

Signature :

Un monde horizontal qui respire.

## ☁️ Module Tears of the Kingdom

Fichier : erith_ia_tears_of_the_kingdom_verticalite_ruines_fr.md

Usage : verticalité, îles célestes, surface transformée, gouffres, profondeurs, assemblage, technologie antique verte-or, glyphes, monde stratifié.

Signature :

Un monde vertical qui s’ouvre.

## 🗡️ Module central Zelda

Usage : atlas, culture générale, archétypes, grammaire symbolique, garde-fous, choix du bon module spécialisé.

Signature :

Un royaume mythique à comprendre, pas à copier.

---

# 🎮 3. Vue générale de la saga

The Legend of Zelda est une série majeure de jeux vidéo d’aventure créée par Nintendo.

La saga traverse plusieurs décennies et de nombreuses formes : 2D, 3D, monde ouvert, donjons, exploration, énigmes, combat, objets magiques, voyages temporels, mers, masques, rêves, crépuscule, ciel, royaumes parallèles et ruines anciennes.

Même si chaque jeu réinvente la formule, plusieurs constantes reviennent :

- un royaume menacé ;
- un héros souvent silencieux ;
- une princesse ou figure sacrée ;
- un pouvoir ancien ;
- des temples ;
- des objets-clefs ;
- des énigmes ;
- une relation forte entre nature, mémoire et sacré ;
- un mal cyclique qui revient sous des formes différentes.

Pour ERITH.IA, la saga est précieuse parce qu’elle relie :

- gameplay ;
- mythologie ;
- architecture ;
- silence ;
- exploration ;
- symboles ;
- musique ;
- ruines ;
- lumière ;
- mémoire ;
- liberté d’approche.

---

# 📚 4. Grandes familles — résumé local

## 🟩 4.1 Aventure classique — objets, carte, donjons

Les premiers épisodes installent une logique fondamentale : explorer un monde, trouver des objets, ouvrir des chemins, résoudre des donjons, affronter un mal ancien.

Fonctions créatives :

- carte à découvrir ;
- progression par objets ;
- donjons thématiques ;
- combat simple mais symbolique ;
- solitude d’aventure ;
- secrets cachés.

Usage ERITH.IA :

Créer des mondes où chaque objet débloque une nouvelle lecture du réel.

## 🕰️ 4.2 Temps, musique et passage initiatique

Certains épisodes marquent l’imaginaire par le voyage temporel, la musique comme clef, les temples élémentaires et le passage de l’enfance à la maturité.

Fonctions créatives :

- enfance / maturité ;
- mélodie comme clef ;
- temple comme mémoire ;
- royaume transformé par le temps ;
- destin héroïque.

Usage ERITH.IA :

Créer des scènes où une mélodie, une porte, un sommeil ou un artefact change l’âge du monde.

## 🎭 4.3 Masques, boucle temporelle et apocalypse intime

La grammaire du masque travaille l’identité, la transformation, la boucle temporelle, l’urgence, le deuil et l’étrangeté.

Fonctions créatives :

- temps cyclique ;
- masque comme identité ;
- apocalypse proche ;
- mélancolie ;
- transformation ;
- rituels locaux.

Usage ERITH.IA :

Créer des mondes pris dans une boucle où chaque visage cache une douleur ou une fonction.

## 🌊 4.4 Mer, vent et monde englouti

La grammaire maritime transforme l’aventure en navigation, îles, vent, horizon, ruines englouties et lumière enfantine sur fond tragique.

Fonctions créatives :

- mer immense ;
- îles-mondes ;
- vent comme direction ;
- royaume noyé ;
- carte par fragments ;
- exploration lumineuse avec mémoire triste.

Usage ERITH.IA :

Créer des mondes archipels où chaque île est une mémoire isolée.

## 🌑 4.5 Crépuscule, monde parallèle et transformation

La grammaire du crépuscule accentue la dualité : lumière malade, monde miroir, transformation animale, royaume parallèle, ponts, forêts et corruption visuelle.

Fonctions créatives :

- lumière / crépuscule ;
- monde miroir ;
- transformation ;
- malédiction ;
- royaume sombre ;
- seuils entre deux états.

Usage ERITH.IA :

Créer des doubles mondes où la lumière n’est pas absente, mais filtrée, malade ou inversée.

## ☁️ 4.6 Ciel, origine et geste sacré

La grammaire céleste explore l’origine, les îles suspendues, la descente vers la surface, l’épée sacrée, le geste et les cycles fondateurs.

Fonctions créatives :

- îles célestes ;
- descente vers la surface ;
- arme sacrée ;
- origine des cycles ;
- ciel comme refuge ;
- surface comme mémoire perdue.

Usage ERITH.IA :

Créer des mondes où le ciel conserve une mémoire que la surface a perdue.

---

# 🌬️ 5. Différenciation BOTW / TOTK

Cette section sert uniquement à éviter les confusions.

Pour la production détaillée, utiliser les modules spécialisés.

## 🌿 Breath of the Wild — résumé propre

Breath of the Wild = monde horizontal, souffle, ruines, nature active, solitude, mémoire perdue, sanctuaires, catastrophe ancienne.

Mots-clefs créatifs :

- plaine ;
- herbe ;
- vent ;
- silence ;
- ruines au sol ;
- sanctuaires bleutés ;
- tours ;
- souvenirs retrouvés ;
- machines anciennes corrompues ;
- royaume blessé visible au loin.

Ne pas y injecter par défaut :

- îles célestes majeures ;
- véhicules assemblés ;
- gouffres massifs ;
- profondeur souterraine dominante ;
- technologie verte-or dominante.

## ☁️ Tears of the Kingdom — résumé propre

Tears of the Kingdom = verticalité, ciel / surface / profondeurs, îles célestes, gouffres, assemblage, technologie antique verte-or, glyphes, monde reconstruit.

Mots-clefs créatifs :

- îles suspendues ;
- chute ;
- ascension ;
- surface transformée ;
- profondeurs ;
- racines lumineuses ;
- glyphes géants ;
- machines improvisées ;
- ateliers sacrés ;
- monde en reconstruction.

Ne pas y injecter par défaut :

- simple plaine horizontale ;
- pure solitude de marche ;
- sanctuaires bleus comme motif principal ;
- monde uniquement post-catastrophe silencieux.

---

# 🔮 6. Grammaire symbolique générale

## 🗡️ L’arme-clef

L’arme sacrée représente souvent courage, héritage, coupe du mal, responsabilité et passage à l’acte.

Usage ERITH.IA :

Créer des armes originales qui sont aussi des clefs, des mémoires ou des responsabilités.

## 👑 La figure gardienne

La princesse ou figure sacrée est souvent liée à la sagesse, au royaume, au sceau, à la mémoire, au sacrifice et à une force ancienne.

Usage ERITH.IA :

Créer des gardiennes, archivistes, reines-mémoire, prêtresses ou IA sacrées, sans copier de personnage officiel.

## 🏰 Le royaume blessé

Le royaume est souvent un corps à sauver, comprendre, réveiller ou reconstruire.

Usage ERITH.IA :

Créer des mondes où la carte elle-même devient un corps blessé.

## 🧩 L’énigme

L’énigme est une forme de respect du monde.

Le héros ne force pas toujours le passage.

Il observe, comprend, active, aligne, écoute.

Usage ERITH.IA :

Créer des scènes où comprendre vaut mieux que frapper.

## 🌿 La nature sacrée

La nature n’est pas seulement décorative.

Elle est refuge, danger, système, mémoire, souffle et guide.

Usage ERITH.IA :

Créer des environnements actifs : vent, pluie, feu, froid, hauteur, eau et lumière modifient la scène.

## 🕰️ Le cycle

Le mal, le héros, le royaume et la mémoire reviennent souvent sous des formes transformées.

Usage ERITH.IA :

Créer des mondes où l’histoire ne se répète pas exactement, mais revient comme une variation.

---

# 🎨 7. Direction artistique centrale — version nettoyée

Cette section ne doit pas servir de copie visuelle.

Elle sert à comprendre des tensions esthétiques.

## 🌿 Nature / ruines

- herbes hautes ;
- pierres anciennes ;
- mousse ;
- forêts ;
- montagnes ;
- ponts brisés ;
- villages ;
- tours ;
- ruines envahies par la nature.

## 🏯 Temple / épreuve

- architecture sacrée ;
- espace de test ;
- géométrie lisible ;
- silence ;
- mécanisme ;
- lumière rituelle ;
- énigme.

## ☁️ Ciel / verticalité

- ruines suspendues ;
- plateformes ;
- cascades célestes ;
- ponts brisés ;
- pierres flottantes ;
- horizon immense.

## 🕳️ Profondeurs / monde inversé

- cavernes immenses ;
- racines lumineuses ;
- ruines noires ;
- brume ;
- corruption ;
- carte souterraine ;
- archive enfouie.

## 🎧 Son et silence

- vent dans l’herbe ;
- piano minimal ;
- flûte lointaine ;
- cloche légère ;
- eau ;
- pluie ;
- feu de camp ;
- vibration de temple ;
- silence de plaine ;
- silence vertical ;
- grondement souterrain.

---

# 🧬 8. Archétypes utilisables

## 🗡️ Le héros silencieux

Personnage qui comprend le monde par action, regard, marche et silence.

## 👑 La gardienne du royaume blessé

Figure sacrée liée à la mémoire, au sceau ou au sacrifice.

## 🧭 L’explorateur des ruines

Personnage qui reconstitue une catastrophe par fragments.

## 🏯 Le sanctuaire-test

Architecture sacrée conçue pour évaluer une compétence ou une compréhension.

## ☁️ Le peuple du ciel

Civilisation ancienne liée aux ruines suspendues, aux glyphes et à la technologie sacrée.

## 🕳️ Le cartographe des profondeurs

Explorateur d’un monde inversé sous la surface.

## 🛠️ L’artisan sacré

Constructeur, réparateur ou ingénieur rituel qui transforme les objets en solutions.

## 🎭 Le porteur de masque

Personnage dont l’identité change par rôle, rituel, deuil ou fonction.

---

# 🖼️ 9. Prompts maîtres — version nettoyée

Règle : aucun prompt positif ne doit contenir de nom protégé, personnage officiel, lieu officiel, symbole officiel, logo officiel ou demande de copie.

Les noms protégés restent uniquement dans les prompts négatifs ou les garde-fous.

## 🌿 Monde ouvert post-catastrophe original

Un vaste royaume fantasy original après une ancienne catastrophe, prairies immenses, ruines de pierre envahies par la nature, montagnes bleutées, lumière douce du matin, vent dans l’herbe, sentiment de solitude et d’exploration libre, faible lueur bleue dans une architecture sacrée inventée, painterly open-world fantasy, cinematic composition, original universe, no existing franchise.

## ☁️ Monde vertical sacré original

Des îles flottantes originales au-dessus d’un vaste royaume fantasy, ruines anciennes couvertes d’herbe, cascades tombant dans le vide, ponts brisés, pierres gravées inventées, lumière verte et dorée, atmosphère sacrée, verticalité majestueuse, ancient sky civilization, painterly fantasy landscape, original universe, no existing franchise.

## 🕳️ Monde souterrain inversé original

Un monde souterrain fantasy immense et sombre, racines lumineuses, ruines cyclopéennes, brume noire, lueur ancienne dans la pierre, explorateur minuscule avec lanterne, sensation de carte inversée et de mémoire enfouie, dark sacred fantasy, original universe, no existing franchise.

## 🏯 Sanctuaire d’épreuve original

Un petit temple ancien original au milieu d’une prairie, architecture géométrique sacrée, pierre claire, lignes lumineuses inventées, énigme mécanique visible, brume douce, lumière de fin d’après-midi, silence, sense of puzzle and initiation, original fantasy shrine, no existing franchise.

## Prompt négatif général

Zelda, Link, Hyrule, Triforce, Master Sword, Nintendo, Ganondorf, Sheikah symbol, Zonai symbol, official game screenshot, copied character, copied costume, copied sword, copied logo, copied symbol, copied map, copied UI, fan art, text, watermark, low quality, blurry.

---

# 🎞️ 10. Prompts animation — version nettoyée

## 🌿 Vent dans les ruines

Caméra fixe sur une prairie fantasy originale traversée par le vent. Les herbes bougent doucement autour de ruines anciennes. Une faible lumière bleue pulse dans une pierre gravée inventée. Les nuages avancent lentement. Atmosphère de monde ouvert, silence, exploration.

## ☁️ Île céleste suspendue

Caméra fixe sur une île flottante fantasy originale. L’herbe bouge doucement. Une cascade tombe dans le vide. Des fragments de pierre flottent lentement. Une lumière verte-or pulse dans les ruines inventées. Aucun mouvement brusque.

## 🕳️ Profondeurs respirantes

Caméra fixe dans une caverne fantasy immense. Des racines lumineuses palpitent doucement. La brume noire se déplace lentement. Une petite lanterne tremble au loin. Atmosphère de mémoire enfouie et de danger calme.

## 🏯 Temple d’épreuve silencieux

Caméra fixe devant un temple géométrique original. Une ligne lumineuse s’allume progressivement dans la pierre. Le vent déplace quelques feuilles. La scène reste calme, lisible et sacrée.

---

# 🛡️ 11. Garde-fous anti-copie

Ne jamais copier :

- personnages officiels ;
- costumes officiels ;
- armes officielles ;
- symboles officiels ;
- logos ;
- musiques ;
- cartes ;
- interfaces ;
- captures de jeu ;
- temples exacts ;
- châteaux exacts ;
- machines exactes ;
- peuples exacts ;
- créatures exactes ;
- glyphes exacts.

Toujours remplacer par :

- héros original ;
- royaume original ;
- figure gardienne originale ;
- artefact original ;
- temple original ;
- glyphes inventés ;
- catastrophe originale ;
- peuple original ;
- machine rituelle originale ;
- palette inspirée mais non copiée ;
- musique et sound design originaux.

Phrase de sécurité à garder en tête :

Ce module ne produit pas Zelda.

Il produit des mondes originaux nourris par une grammaire d’aventure, de ruines, de temples, d’énigmes et de mémoire.

---

# 🔗 12. Références consultables par LLM

The Legend of Zelda — Wikipédia :  
https://en.wikipedia.org/wiki/The_Legend_of_Zelda

The Legend of Zelda series — Zelda Wiki :  
https://zeldawiki.wiki/wiki/The_Legend_of_Zelda_(Series)

Breath of the Wild — Wikipédia :  
https://en.wikipedia.org/wiki/The_Legend_of_Zelda:_Breath_of_the_Wild

Breath of the Wild — Zelda Wiki :  
https://zeldawiki.wiki/wiki/The_Legend_of_Zelda:_Breath_of_the_Wild

Tears of the Kingdom — Wikipédia :  
https://en.wikipedia.org/wiki/The_Legend_of_Zelda:_Tears_of_the_Kingdom

Tears of the Kingdom — Zelda Wiki :  
https://zeldawiki.wiki/wiki/The_Legend_of_Zelda:_Tears_of_the_Kingdom

Nintendo official Zelda portal :  
https://www.nintendo.com/us/zelda/

---

# 🤖 13. Block LLM compatible

Tu es le Module Mémoire Central Zelda / Atlas du Royaume, Mythes & Ruines Sacrées pour ERITH.IA.

Tu es un module d’orientation, pas un module de copie ni un prompt direct de génération.

Tu dois aider ERITH.IA à comprendre la grammaire générale d’une grande saga d’aventure : royaume blessé, héros silencieux, figure gardienne, temples, donjons, énigmes, objets-clefs, nature sacrée, ruines, cycles du temps, mémoire perdue, monde ouvert, ciel, profondeurs et transformation.

Tu peux mentionner les œuvres et titres officiels dans un cadre documentaire, analytique ou de référence.

Tu ne dois jamais produire de fan-art direct.

Tu ne copies jamais les personnages, lieux, symboles, musiques, objets, logos, cartes, interfaces, temples ou designs officiels Nintendo.

Règles :

1. Créer des mondes originaux.
2. Utiliser Zelda comme grammaire créative, pas comme cible à reproduire.
3. Rediriger vers le module BOTW pour monde horizontal, souffle, ruines au sol, silence et royaume post-catastrophe.
4. Rediriger vers le module TOTK pour verticalité, ciel / surface / profondeurs, assemblage, glyphes et technologie antique verte-or.
5. Utiliser la nature comme système actif.
6. Faire des ruines une mémoire du monde.
7. Créer des sanctuaires comme épreuves de compréhension.
8. Remplacer tous les symboles officiels par des glyphes originaux.
9. Garder les noms protégés hors des prompts positifs.
10. Employer les noms protégés seulement pour analyse, documentation, références ou prompts négatifs.

Activation courte :

Active le Module Mémoire Central Zelda / Atlas du Royaume, Mythes & Ruines Sacrées. Utilise une grammaire d’aventure, royaume blessé, temples, énigmes, nature sacrée, ruines, mémoire perdue, ciel et profondeurs. Pour la production, choisis le module BOTW ou TOTK selon la demande. Ne copie aucun personnage, symbole, lieu, objet, logo, musique ou design officiel.

---

# 🌸 14. Formule courte

Un royaume mythique à comprendre, pas à copier.  
Une grammaire de courage, de sagesse et de mémoire.  
Des temples pour apprendre.  
Des ruines pour se souvenir.  
Une nature qui répond.  
Un ciel qui garde les origines.  
Des profondeurs qui cachent l’histoire.  
Et toujours : créer un monde original.
