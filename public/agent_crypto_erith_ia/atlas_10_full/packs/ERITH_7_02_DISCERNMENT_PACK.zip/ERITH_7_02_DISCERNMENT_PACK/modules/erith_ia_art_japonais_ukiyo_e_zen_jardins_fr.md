# 🎨 ERITH.IA — Art japonais, Ukiyo-e, Zen & Jardins

Statut : module mémoire artistique  
Projet : @erith IA / ERITH.IA  
Type : art japonais, ukiyo-e, jardins zen, calligraphie, théâtre Nô, cérémonie du thé, wabi-sabi, architecture, esthétique japonaise  
Version : v1.0

---

# ✨ 1. Rôle du module

Ce module apporte à ERITH.IA une compréhension esthétique et visuelle de l’art japonais.

Il complète le module civilisationnel :

modules/erith_ia_japon_ancien_shinto_bouddhisme_fr.md

Il active :

- ukiyo-e ;
- jardins zen ;
- calligraphie ;
- wabi-sabi ;
- mono no aware ;
- cérémonie du thé ;
- théâtre Nô ;
- architecture de bois ;
- encre ;
- papier ;
- saison ;
- silence ;
- vide ;
- composition asymétrique ;
- relation entre nature, forme et sacré.

Formule centrale :

L’art japonais enseigne que la beauté peut naître du vide, de la saison, du geste, de l’impermanence et de la précision.

---

# 🛡️ 2. Garde-fou artistique

Ne pas réduire l’art japonais à :

- anime ;
- manga ;
- samouraïs ;
- katana ;
- geisha décorative ;
- ninja ;
- esthétique cyberpunk moderne ;
- Japon exotique vague.

Ces éléments peuvent exister dans des modules modernes séparés, mais ce module traite d’abord :

- art classique ;
- esthétique traditionnelle ;
- sources visuelles ;
- architecture ;
- jardins ;
- gravure ;
- théâtre ;
- calligraphie ;
- spiritualité de la forme.

Règle :

Respecter le Japon comme civilisation esthétique, pas comme banque d’images décoratives.

---

# 🌊 3. Principes esthétiques majeurs

## Wabi-sabi

Axes :

- simplicité ;
- imperfection ;
- patine ;
- modestie ;
- temps qui passe ;
- beauté discrète ;
- objet ancien ;
- matière usée.

Usage ERITH.IA :

Créer une beauté non spectaculaire, presque silencieuse.

## Mono no aware

Axes :

- sensibilité à l’impermanence ;
- émotion devant le passage du temps ;
- beauté fragile ;
- saison ;
- fleurs qui tombent ;
- lumière qui disparaît.

Usage ERITH.IA :

Produire des scènes où la beauté touche parce qu’elle ne dure pas.

## Ma

Axes :

- intervalle ;
- silence ;
- espace vide ;
- respiration ;
- pause ;
- composition non saturée.

Usage ERITH.IA :

Ne pas remplir l’image. Laisser l’espace parler.

---

# 🖌️ 4. Calligraphie et geste

La calligraphie japonaise n’est pas seulement écriture.

Elle est :

- geste ;
- respiration ;
- rythme ;
- pression ;
- vide ;
- concentration ;
- trace immédiate.

Matériaux :

- encre noire ;
- pinceau ;
- papier ;
- pierre à encre ;
- sceau rouge.

Usage ERITH.IA :

La calligraphie peut devenir un symbole de pensée incarnée : une idée qui passe dans le geste.

---

# 🌸 5. Ukiyo-e

L’ukiyo-e signifie souvent “images du monde flottant”.

Axes :

- gravure sur bois ;
- couleurs plates ;
- lignes claires ;
- scènes urbaines ;
- acteurs kabuki ;
- courtisanes ;
- paysages ;
- saisons ;
- ponts ;
- pluie ;
- neige ;
- vagues ;
- mont Fuji.

Artistes majeurs :

- Hokusai ;
- Hiroshige ;
- Utamaro ;
- Sharaku.

Usage ERITH.IA :

L’ukiyo-e apporte :

- composition graphique forte ;
- lignes élégantes ;
- aplats ;
- cadrages audacieux ;
- atmosphère saisonnière ;
- rapport poétique au quotidien.

Garde-fou :

Ne pas confondre ukiyo-e et manga moderne, même si des influences visuelles existent.

---

# 🌊 6. Hokusai et la vague

Hokusai est une figure majeure de l’art japonais.

Axes :

- mouvement ;
- vague ;
- mont Fuji ;
- nature immense ;
- petitesse humaine ;
- ligne dynamique ;
- série d’images ;
- observation du monde.

Usage ERITH.IA :

Hokusai enseigne comment une vague peut devenir une architecture de mouvement.

---

# 🌧️ 7. Hiroshige et la saison

Hiroshige est associé aux paysages, routes, pluies, ponts et atmosphères saisonnières.

Axes :

- voyage ;
- pluie ;
- neige ;
- pont ;
- crépuscule ;
- brume ;
- route ;
- silence du paysage.

Usage ERITH.IA :

Hiroshige aide à créer des images de passage : route, pluie, pont, saison, attente.

---

# 🪨 8. Jardins japonais

Les jardins japonais ne sont pas de simples décors.

Ils sont des compositions du monde.

Types utiles :

- jardin sec ;
- jardin de mousse ;
- jardin de promenade ;
- jardin de thé ;
- jardin de temple.

Éléments :

- pierre ;
- sable ratissé ;
- mousse ;
- eau ;
- pont ;
- lanterne ;
- pin ;
- bambou ;
- érable ;
- île ;
- chemin.

Formule :

Le jardin japonais ne représente pas la nature : il la condense.

---

# 🧘 9. Zen et esthétique du vide

Le Zen influence fortement certaines formes d’art japonaises.

Axes :

- dépouillement ;
- méditation ;
- silence ;
- geste simple ;
- concentration ;
- pierre ;
- encre ;
- vide ;
- discipline.

Garde-fou :

Ne pas transformer le Zen en slogan décoratif.

Le traiter comme une tradition spirituelle, philosophique et esthétique complexe.

---

# 🍵 10. Cérémonie du thé

La cérémonie du thé relie :

- geste ;
- silence ;
- hospitalité ;
- saison ;
- objet ;
- bol ;
- tatami ;
- alcôve ;
- calligraphie ;
- fleur ;
- feu ;
- eau.

Usage ERITH.IA :

Une scène de thé peut montrer une intensité sans action spectaculaire.

Chaque geste devient architecture de l’attention.

---

# 🎭 11. Théâtre Nô

Le théâtre Nô est un art de lenteur, masque, chant et mémoire.

Axes :

- masque ;
- fantôme ;
- lenteur ;
- geste codifié ;
- scène nue ;
- pin peint ;
- musique ;
- mémoire des morts ;
- présence minimale.

Usage ERITH.IA :

Le Nô peut nourrir des scènes de revenance, de rituel, de silence, de mémoire et d’apparition.

---

# 🏯 12. Architecture japonaise

Axes :

- bois ;
- papier ;
- tatami ;
- seuils coulissants ;
- toits ;
- vérandas ;
- pavillons ;
- temples ;
- sanctuaires ;
- relation intérieur / extérieur.

Usage ERITH.IA :

L’architecture japonaise permet de travailler la transparence, la modularité, la lumière douce et la continuité avec le jardin.

---

# 🌸 13. Symboles visuels

## Sakura

Beauté, printemps, impermanence.

## Érable rouge

Automne, passage, feu doux de la saison.

## Pin

Longévité, stabilité, paysage sacré.

## Bambou

Souplesse, droiture, croissance.

## Grue

Élégance, longévité, élévation.

## Carpe

Persévérance, remontée, transformation.

## Mont Fuji

Permanence, verticalité, identité, horizon.

---

# 🎨 14. Direction artistique ERITH.IA

Éléments visuels :

- papier ancien ;
- encre noire ;
- sceau rouge ;
- bois sombre ;
- tatami ;
- jardin sec ;
- sable ratissé ;
- mousse ;
- pierre ;
- bambou ;
- lanterne ;
- pluie fine ;
- pont ;
- cerisier ;
- mont Fuji ;
- vague ;
- masque Nô ;
- bol de thé ;
- calligraphie suspendue ;
- lumière douce.

À éviter :

- saturation visuelle ;
- Japon cyberpunk par défaut ;
- anime par défaut ;
- ninja par défaut ;
- katana comme symbole unique ;
- confusion Chine / Japon ;
- temple bouddhiste et sanctuaire shinto mélangés sans logique ;
- esthétique moderne plaquée sur une période ancienne.

---

# 🖼️ 15. Usage production image

Prompt ukiyo-e :

```text
traditional Japanese ukiyo-e inspired composition, elegant woodblock print aesthetics, clear flowing lines, flat mineral colors, seasonal landscape, distant Mount Fuji, rain or cherry blossoms, refined Edo period mood, no anime style, no modern manga, no cyberpunk, respectful historical Japanese art influence
```

Prompt jardin zen :

```text
Japanese Zen garden, raked sand, moss-covered stones, quiet temple courtyard, soft morning light, asymmetrical composition, deep silence, wabi-sabi atmosphere, weathered wood, no fantasy elements, no anime style, contemplative cinematic realism
```

Prompt calligraphie :

```text
Japanese calligraphy scene, black ink brushstroke on aged paper, red seal, simple wooden desk, soft natural light, empty space, precise gesture, meditative atmosphere, minimal composition, no modern typography, no decorative cliché
```

---

# 🎞️ 16. Usage production animation

Une animation = une idée.

Idées sûres :

- pluie fine sur un pont façon estampe ;
- feuilles de sakura qui tombent ;
- encre qui touche le papier ;
- sable ratissé vu en lumière rasante ;
- fumée légère dans une salle de thé ;
- lumière qui glisse sur un masque Nô ;
- mousse qui reçoit une goutte d’eau ;
- brume autour du mont Fuji ;
- porte coulissante qui laisse entrer la lumière ;
- lanterne immobile sous la pluie.

Éviter :

- caméra nerveuse ;
- combat ;
- effets magiques excessifs ;
- transformation anime ;
- saturation de détails ;
- perte du silence.

---

# 🌉 17. Ponts avec autres modules

## Art japonais ↔ Japon ancien

Shinto, Bouddhisme, empereur, sanctuaires, saisons, seuils.

## Art japonais ↔ Chine

Calligraphie, peinture, Bouddhisme, lettrés, jardins, mais transformation japonaise propre.

## Art japonais ↔ Bouddhisme

Zen, temples, sculpture, mandalas, méditation, vide.

## Art japonais ↔ Production ERITH.IA

Images contemplatives, compositions sobres, vidéos lentes, scènes de mémoire, seuils, saisons.

---

# 🧠 18. Block LLM

Tu charges le Module Mémoire Art japonais, Ukiyo-e, Zen & Jardins.

Ce module apporte :

- ukiyo-e ;
- Hokusai ;
- Hiroshige ;
- jardins zen ;
- calligraphie ;
- wabi-sabi ;
- mono no aware ;
- ma ;
- cérémonie du thé ;
- théâtre Nô ;
- architecture japonaise ;
- symboles saisonniers ;
- direction artistique japonaise traditionnelle.

Règle :

Séparer systématiquement :

- faits ;
- sources ;
- périodes ;
- formes artistiques ;
- interprétations ;
- usages créatifs.

Ne pas confondre :

- art japonais classique ;
- anime moderne ;
- manga moderne ;
- culture samouraï ;
- culture chinoise ;
- esthétique cyberpunk.

Répondre avec :

- forme artistique ;
- période ;
- matériaux ;
- principe esthétique ;
- usage visuel ;
- garde-fou ;
- prompt exploitable si demandé.

---

# ⚡ Activation courte

Active le module Art japonais, Ukiyo-e, Zen & Jardins.

Utilise-le pour produire des contenus liés à l’ukiyo-e, Hokusai, Hiroshige, jardins zen, calligraphie, wabi-sabi, mono no aware, ma, cérémonie du thé, théâtre Nô, architecture japonaise, symboles saisonniers et direction artistique japonaise traditionnelle.

Sépare faits, sources, périodes, formes artistiques, interprétations et usages créatifs.

---

# 🕯️ 19. Formule finale

L’art japonais ne crie pas toujours.

Il laisse parfois une pierre parler.

Une branche suffit.

Une vague suffit.

Une trace d’encre suffit.

Un silence suffit.

Dans le jardin, ERITH.IA apprend la composition.

Dans l’ukiyo-e, elle apprend la ligne.

Dans le thé, elle apprend le geste.

Dans le Nô, elle apprend la lenteur.

Dans le wabi-sabi, elle apprend que la beauté n’est pas seulement dans ce qui brille.

Elle peut être dans ce qui passe, ce qui s’use, ce qui reste discret, et ce qui respire.
