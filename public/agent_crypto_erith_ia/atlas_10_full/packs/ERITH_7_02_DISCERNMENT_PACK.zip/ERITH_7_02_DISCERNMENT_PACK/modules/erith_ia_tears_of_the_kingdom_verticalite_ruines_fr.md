# ☁️ ERITH.IA — Module Mémoire — Tears of the Kingdom / Verticalité, Assemblage & Ciel Sacré

Nom du fichier : erith_ia_tears_of_the_kingdom_verticalite_ruines_fr.md  
Type : Module Mémoire spécialisé / Verticalité / Îles célestes / Profondeurs / Construction / Ruines sacrées / Direction Artistique / LLM local  
Statut : Public ou semi-public selon usage  
Usage : ERITH.IA, Seven Heaven, prompts image, prompts vidéo, narration, mondes stratifiés, îles célestes, profondeurs, assemblage, technologie antique, LLM local sans Internet

---

![ERITH.IA — Tears of the Kingdom / îles célestes et ruines sacrées](../assets/images/ERITH_IA_ZELDA_TOTK_AMBIANCE_MODULE_COVER_1024x1536.png)

Image d’ouverture : ambiance Tears of the Kingdom, verticalité, îles célestes, ruines suspendues, profondeur inversée, assemblage et technologie antique originale.

---

# ☁️ 1. Intention du module

Ce module isole uniquement l’influence Tears of the Kingdom.

Il ne doit jamais être confondu avec Breath of the Wild.

Tears of the Kingdom = verticalité, ciel / surface / profondeurs, ruines tombées du ciel, construction, assemblage, technologie antique verte-or, mémoire ancienne, glyphes géants, chute, ascension et monde stratifié.

Ce module sert à comprendre une grammaire créative : un monde reconstruit par invention, une civilisation suspendue, des profondeurs inversées, des machines rituelles et une exploration verticale.

Ce module ne sert pas à copier Nintendo.

Règle de production :

- les références Nintendo peuvent exister dans les titres, l’analyse, les garde-fous et les prompts négatifs ;
- les prompts positifs doivent rester originaux, génériques et juridiquement propres ;
- ne jamais demander une copie de personnage, lieu, symbole, logo, musique, interface ou design officiel.

---

# 🧭 2. Verrou anti-confusion avec Breath of the Wild

## Tears of the Kingdom — signature pure

- Monde stratifié en trois couches.
- Îles célestes.
- Surface transformée.
- Gouffres et profondeurs.
- Chute, ascension, plongée, remontée.
- Construction libre.
- Assemblage d’objets.
- Machines improvisées.
- Technologie antique verte-or.
- Glyphes géants visibles depuis le ciel.
- Ruines suspendues.
- Mémoire inscrite dans le territoire.
- Sensation de monde réécrit après un premier royaume ouvert.

## Interdits de dérive BOTW dans ce module

- Pas de monde seulement horizontal.
- Pas de pure solitude contemplative comme moteur principal.
- Pas de ruines uniquement au sol.
- Pas de sanctuaires bleus sobres comme centre esthétique dominant.
- Pas de logique “marche lente dans les plaines” comme cœur du gameplay.
- Pas de monde basé principalement sur le silence et la respiration horizontale.

Formule anti-confusion :

BOTW = souffle et royaume blessé.  
TOTK = verticalité et royaume reconstruit.

---

# 🏝️ 3. Résumé narratif détaillé

Tears of the Kingdom commence par une descente.

Le héros et la princesse explorent les profondeurs sous le château. Ils découvrent une menace ancienne enfouie sous le royaume. Le sol, l’histoire et le pouvoir royal cachent une mémoire plus ancienne que la catastrophe précédente.

La menace ne vient plus seulement d’un passé visible.

Elle remonte.

Le château s’arrache au sol. Des ruines tombent du ciel. Des îles apparaissent dans les hauteurs. Des gouffres ouvrent l’accès à un monde souterrain immense.

Le royaume connu devient stratifié :

- ciel ;
- surface ;
- profondeurs.

Le héros reçoit un bras marqué par une civilisation ancienne. Ce bras agit comme une interface entre le corps, la technologie sacrée, la mémoire et la construction.

La princesse disparaît dans un autre temps.

Le récit devient double :

- explorer un monde vertical fracturé ;
- reconstituer une mémoire antique liée à la fondation du royaume, au sacrifice et au retour d’un mal ancien.

La différence fondamentale avec Breath of the Wild est importante :

dans BOTW, le joueur comprend le monde ;  
dans TOTK, le joueur transforme le monde.

Il assemble.

Il construit.

Il expérimente.

Il détourne les objets.

Il fabrique des solutions.

Le monde devient un atelier sacré.

---

# 🧱 4. Structure des missions principales — lecture créative

Ce module ne doit pas mémoriser les missions comme un guide de complétion.

Il doit retenir leur fonction de narration, de gameplay et de production visuelle.

## 4.1 Les profondeurs sous le château

Fonction : révéler que le royaume repose sur une mémoire interdite.

Usage ERITH.IA : créer une ouverture où un palais, une capitale ou un sanctuaire révèle une couche ancienne sous ses fondations.

## 4.2 L’île céleste de départ

Fonction : apprendre la verticalité.

Le joueur découvre les ruines suspendues, la chute, les plateformes brisées, les mécanismes antiques et les premières capacités de construction.

Usage ERITH.IA : créer des zones suspendues : ponts brisés, cascades célestes, temples aériens, machines rituelles.

## 4.3 Retour à la surface

Fonction : transformer un monde déjà connu.

La surface est désormais percée, surplombée, modifiée et contaminée par les événements.

Usage ERITH.IA : créer un monde familier réécrit par une catastrophe verticale.

## 4.4 Les phénomènes régionaux

Fonction : quatre grandes crises locales liées à des anomalies climatiques ou géographiques.

Usage ERITH.IA : créer des régions où le problème vient d’un axe vertical : tempête aérienne, gouffre, montagne creuse, pollution souterraine, temple suspendu.

## 4.5 Les temples

Fonction : grands systèmes architecturaux liés à un élément.

Les temples sont plus vastes, plus thématiques et plus mécaniques que les sanctuaires de BOTW.

Usage ERITH.IA : créer des temples-systèmes originaux : temple du vent, du feu, des racines, des marées, des orages, des machines.

## 4.6 Les glyphes et les larmes

Fonction : mémoire inscrite dans le territoire.

La carte devient archive géante.

Usage ERITH.IA : créer des symboles visibles depuis le ciel : cicatrices lumineuses, dessins géants, cartes sacrées, traces de mémoire.

## 4.7 Les profondeurs

Fonction : monde inversé.

Sous la surface existe une carte noire, immense et dangereuse.

Les racines lumineuses répondent aux sanctuaires de surface. Les ruines souterraines révèlent une civilisation oubliée.

Usage ERITH.IA : créer des archives souterraines, mines sacrées, temples noirs, racines de lumière, abysses rituels.

## 4.8 Les machines et corps rituels

Fonction : unir mémoire, mécanique et spiritualité.

Le jeu introduit des machines habitées, golems, véhicules improvisés, corps-supports et constructions sacrées.

Usage ERITH.IA : créer des architectures vivantes, plateformes conscientes, machines-oracles, golems rituels, ateliers suspendus.

## 4.9 Le combat final

Fonction : traversée mythologique des couches du monde.

La confrontation finale relie profondeur, ciel, dragon, chute, ascension, sacrifice et mémoire.

Usage ERITH.IA : créer une fin où le héros traverse les trois couches du monde avant de réparer une fracture ancienne.

---

# 🌀 5. Missions secondaires — fonctions créatives

TOTK utilise les quêtes secondaires pour montrer un monde en reconstruction active.

## 🧱 Reconstruction

Villages, routes, ponts, infrastructures, réparations.

Fonction : montrer que le royaume survit par le travail collectif.

## 🛠️ Construction libre

Tests de véhicules, plateformes, machines improvisées.

Fonction : transformer le gameplay en créativité physique.

## 🕳️ Exploration verticale

Grottes, gouffres, ascensions, îles cachées, plateformes aériennes.

Fonction : faire sentir que le monde possède plusieurs couches.

## 🧭 Enquêtes et phénomènes

Mystères, journaux, glyphes, rumeurs, anomalies naturelles.

Fonction : rendre le territoire vivant et instable.

## 👥 Voyageurs et reconstruction sociale

Journalistes, chercheurs, bâtisseurs, aventuriers.

Fonction : montrer un royaume qui tente de redevenir habitable.

Question guide : qu’est-ce que cette invention change dans la manière d’habiter le monde ?

---

# 🧩 6. Gameplay et systèmes à retenir

## 🧱 Assemblage

La grande signature créative est l’assemblage.

Roues, ailes, planches, ventilateurs, batteries, plateformes et mécanismes peuvent être combinés.

Usage ERITH.IA : penser les scènes comme des LEGO sacrés.

## 🧲 Fusion

Un objet peut être combiné à une arme, un bouclier, une flèche ou une machine.

Usage ERITH.IA : créer des artefacts hybrides originaux.

## ⏪ Rembobinage

Le temps local d’un objet peut être inversé.

Usage ERITH.IA : créer des scènes où une plateforme, une pierre ou une machine retourne à son point d’origine.

## ⬆️ Ascension

Le héros traverse certaines surfaces verticalement.

Usage ERITH.IA : penser le monde par couches et passages internes.

## 🌍 Monde stratifié

Le monde est composé de trois cartes connectées :

- ciel : ruines sacrées, origine, lumière ;
- surface : peuples, crise, reconstruction ;
- profondeurs : mémoire noire, mines, corruption.

Usage ERITH.IA : chaque scène doit pouvoir répondre à trois questions :

- que se passe-t-il au-dessus ?
- que se passe-t-il ici ?
- que se passe-t-il dessous ?

---

# 🎨 7. Direction Artistique — TOTK pur

## Palette

- blanc ciel ;
- bleu clair d’altitude ;
- vert antique lumineux ;
- or pierre sacrée ;
- gris ruine suspendue ;
- noir profondeur ;
- rouge corruption ;
- brun mine ;
- lumière racinaire ;
- poussière dorée.

## Matières

- pierre céleste ;
- gravures inventées ;
- blocs flottants ;
- cascades suspendues ;
- bois d’assemblage ;
- roues antiques ;
- ailes mécaniques ;
- ventilateurs rituels ;
- racines lumineuses ;
- minerai sombre ;
- glyphes au sol ;
- brume souterraine.

## Composition

- forte verticalité ;
- vide sous les îles ;
- chute ou ascension ;
- ruines suspendues ;
- profondeur noire en contrepoint ;
- personnage minuscule ;
- spirales et géométrie circulaire ;
- lumière verte-or.

## Image mentale verrouillée

Un monde suspendu entre ciel lumineux et mémoire souterraine.

---

# 🎞️ 8. Animations compatibles

## ☁️ Île céleste suspendue

Caméra fixe sur une île flottante originale. L’herbe bouge doucement. Des pierres flottent lentement. Une cascade tombe dans le vide. Une lumière verte-or pulse dans une ruine.

## 🪂 Chute depuis le ciel

Caméra verticale lente. Des nuages traversent l’image. Des ruines suspendues passent au loin. Le sol apparaît très bas.

## 🕳️ Profondeurs respirantes

Caméra fixe dans une caverne immense. Les racines lumineuses palpitent doucement. La brume noire se déplace.

## 🧱 Machine rituelle assemblée

Caméra fixe sur une machine antique originale. Une roue tourne lentement. Une aile de bois et de pierre vibre. Les lumières vertes s’allument une par une.

## 🌀 Glyphe vu du ciel

Caméra très lente en plongée. Un immense glyphe original apparaît dans l’herbe et la pierre. Une larme lumineuse pulse au centre.

---

# 🖼️ 9. Prompts image originaux compatibles

Important : les prompts positifs ne doivent pas citer Zelda, Nintendo, Link, Hyrule, Triforce, Master Sword ou tout autre élément protégé.

## Prompt 1 — Îles célestes sacrées

Des îles flottantes originales au-dessus d’un vaste royaume fantasy, ruines anciennes couvertes d’herbe, cascades tombant dans le vide, ponts brisés, pierres gravées inventées, lumière verte et dorée, atmosphère sacrée, verticalité majestueuse, ancient sky civilization, painterly fantasy landscape, original universe, no existing franchise.

## Prompt 2 — Monde stratifié

Un paysage fantasy original montrant trois niveaux du monde : îles célestes lumineuses au-dessus, surface transformée au centre, profondeurs sombres visibles par un gouffre immense, racines lumineuses dans le noir, technologie antique verte-or, epic vertical composition, original universe.

## Prompt 3 — Atelier d’assemblage sacré

Un atelier antique original sur une plateforme céleste, roues de pierre, ailes de bois, ventilateurs rituels, blocs gravés inventés, lumière verte-or, outils anciens, sensation de construction sacrée et d’expérimentation, fantasy engineering temple, original universe.

## Prompt 4 — Profondeurs lumineuses

Un monde souterrain fantasy immense et sombre, racines lumineuses, ruines cyclopéennes, brume noire, lueur rouge lointaine, explorateur minuscule avec lanterne, sensation de carte inversée et de mémoire enfouie, dark sacred fantasy, original universe.

## Prompt 5 — Temple suspendu original

Un immense temple fantasy suspendu dans les nuages, architecture circulaire, cascades aériennes, plateformes brisées, lumière verte-or, pierre antique gravée, vide immense sous la structure, cinematic sacred sky fantasy, original universe.

## Prompt négatif général

Zelda, Link, Hyrule, Triforce, Master Sword, Nintendo, Sheikah symbol, Zonai symbol, Ganondorf, official game screenshot, copied character, copied symbol, copied logo, fan art, text, watermark, UI, low quality, blurry.

---

# 🎬 10. Prompts animation Wan / I2V

## Animation 1 — Île céleste suspendue

Caméra fixe sur une île flottante fantasy originale. L’herbe bouge doucement. Une cascade tombe lentement dans le vide. De petits fragments de pierre flottent autour de la ruine. Une lumière verte-or pulse dans les gravures inventées.

Prompt négatif : mouvement brusque, caméra tremblante, personnage reconnaissable, logo, texte, symbole officiel, capture de jeu, fan art.

## Animation 2 — Profondeur respirante

Caméra fixe dans un monde souterrain immense. Des racines lumineuses palpitent lentement. La brume noire glisse entre les ruines. Une faible lueur rouge apparaît très loin.

Prompt négatif : combat, monstre reconnaissable, caméra rapide, logo, texte, interface, design copié.

## Animation 3 — Machine sacrée assemblée

Caméra fixe sur une petite machine antique originale posée sur une plateforme de pierre. Une roue tourne lentement. Un ventilateur rituel s’allume. Une aile de bois vibre légèrement. Les lumières vertes s’activent dans un ordre calme.

Prompt négatif : technologie moderne, cyberpunk, véhicule réaliste, logo, texte, personnage officiel, fan art.

## Animation 4 — Chute dans les nuages

Caméra verticale lente au-dessus d’un monde de nuages. Un explorateur original plonge doucement entre des ruines suspendues. Les îles flottantes passent lentement. Le vide donne une sensation de liberté et de danger.

Prompt négatif : personnage officiel, logo, texte, capture de jeu, caméra brutale.

---

# 🎧 11. Sound Design — TOTK pur

TOTK doit donner une impression de hauteur, de vide, de mécanisme ancien et de profondeur.

Sons principaux :

- vent d’altitude ;
- nappes légères ;
- cloches cristallines ;
- pierre flottante ;
- mécanismes antiques ;
- roues lentes ;
- souffle de chute ;
- basses souterraines ;
- racines lumineuses ;
- grondements lointains ;
- silence vertical.

Règle : le son doit faire sentir les couches du monde.

---

# 🛡️ 12. Garde-fous anti-copie

Ne jamais copier :

- personnages officiels ;
- costumes officiels ;
- épées officielles ;
- symboles officiels ;
- logos ;
- îles exactes ;
- temples exacts ;
- machines exactes ;
- glyphes exacts ;
- créatures exactes ;
- musiques ;
- cartes ;
- interfaces ;
- captures de jeu.

Toujours remplacer par :

- héros original ;
- royaume original ;
- glyphes inventés ;
- civilisation ancienne originale ;
- machines rituelles originales ;
- technologies antiques inventées ;
- profondeurs originales ;
- temples originaux ;
- palette inspirée mais non copiée.

---

# 🤖 13. Block LLM compatible

Tu es le Module Mémoire Tears of the Kingdom / Verticalité, Assemblage & Ciel Sacré pour ERITH.IA.

Tu dois isoler l’influence Tears of the Kingdom sans la mélanger avec Breath of the Wild.

Tu utilises une grammaire de monde stratifié : ciel, surface, profondeurs.

Tu travailles :

- verticalité ;
- ruines suspendues ;
- îles célestes ;
- gouffres ;
- racines lumineuses ;
- technologie antique verte-or ;
- glyphes géants ;
- machines rituelles ;
- assemblage d’objets ;
- reconstruction active du monde.

Tu ne dois pas produire de fan-art direct.

Tu ne copies jamais les personnages, lieux, symboles, musiques, objets, logos, temples ou designs officiels Nintendo.

Règles :

1. Créer des mondes originaux.
2. Privilégier la verticalité : chute, ascension, ciel, surface, profondeurs.
3. Utiliser la construction comme grammaire créative.
4. Penser les objets comme assemblables et transformables.
5. Faire des glyphes une mémoire géographique originale.
6. Faire des profondeurs une archive noire sous le monde.
7. Utiliser la palette vert antique / or / pierre céleste / noir souterrain.
8. Éviter le monde uniquement horizontal et la pure solitude contemplative de BOTW.
9. Toujours remplacer les symboles officiels par des glyphes originaux.
10. Les prompts positifs doivent rester génériques et originaux.
11. Chaque région doit posséder une logique verticale, mécanique ou géologique.

Activation courte :

Active le Module Tears of the Kingdom / Verticalité, Assemblage & Ciel Sacré. Crée une ambiance de monde stratifié, îles célestes, surface transformée, profondeurs, ruines suspendues, assemblage, technologie antique verte-or et mémoire géographique. Ne copie aucun personnage, symbole, lieu, objet, logo, musique ou design officiel.

---

# 🔗 14. Références consultables par LLM

The Legend of Zelda: Tears of the Kingdom — Wikipédia :  
https://en.wikipedia.org/wiki/The_Legend_of_Zelda:_Tears_of_the_Kingdom

The Legend of Zelda: Tears of the Kingdom — Wikipédia FR :  
https://fr.wikipedia.org/wiki/The_Legend_of_Zelda:_Tears_of_the_Kingdom

Nintendo official Zelda portal :  
https://www.nintendo.com/us/zelda/

---

# 🌸 15. Formule courte

Un monde vertical qui s’ouvre.  
Des îles au-dessus des nuages.  
Des gouffres sous la surface.  
Des ruines qui tombent du ciel.  
Des machines que l’on assemble.  
Des glyphes qui écrivent la mémoire dans la terre.  
Un royaume reconstruit par invention.
