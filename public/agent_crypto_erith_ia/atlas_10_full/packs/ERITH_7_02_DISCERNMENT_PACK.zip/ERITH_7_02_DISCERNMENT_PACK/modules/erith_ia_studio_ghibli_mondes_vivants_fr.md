# 🌿 ERITH.IA — Module Mémoire — Studio Ghibli / Mondes Vivants

Nom du fichier : erith_ia_studio_ghibli_mondes_vivants_fr.md  
Type : Module Mémoire / Direction Artistique / Influence animation / Mondes vivants  
Statut : Public ou semi-public selon usage  
Usage : ERITH.IA, Seven Heaven, modules créatifs, Hors-Lore, prompts image, prompts vidéo, analyse symbolique, direction artistique

---

## 🌸 1. Intention du module

Ce module permet à ERITH.IA d’utiliser Studio Ghibli comme influence culturelle, esthétique et symbolique, sans copier les films, les personnages, les créatures, les noms propres, les intrigues ou les designs exacts.

Studio Ghibli est utilisé ici comme grammaire d’influence autour de plusieurs axes :

- 🌿 la nature comme présence vivante ;
- 🌬️ le souffle, le vent et les silences ;
- 🏡 la maison comme refuge, seuil ou organisme ;
- ✈️ le ciel, le vol et l’appel de l’horizon ;
- 🛠️ les machines artisanales, imparfaites, habitées ;
- 👧 l’enfance comme regard de vérité ;
- 🧙 le merveilleux quotidien ;
- 🍲 la nourriture comme soin, lien et réel sensible ;
- 🔥 la guerre comme blessure du monde ;
- 🐺 les esprits, animaux et forces anciennes ;
- 🧹 le travail humble comme transformation ;
- 🕯️ la mélancolie douce ;
- 🕊️ le pacifisme, la réparation et la cohabitation.

Ce module ne sert pas à reproduire Ghibli.  
Il sert à créer des mondes originaux inspirés par sa manière de rendre le monde vivant, respirant, fragile, merveilleux et moralement complexe.

---

## 📘 2. Résumé court du Studio Ghibli

Studio Ghibli est un studio d’animation japonais fondé en 1985, associé notamment à Hayao Miyazaki, Isao Takahata et Toshio Suzuki. Le studio est mondialement reconnu pour ses films d’animation majoritairement dessinés à la main, ses mondes détaillés, son attention aux gestes quotidiens, ses héroïnes fortes, ses thèmes écologiques, pacifistes et spirituels, ainsi que son mélange unique de merveilleux et de réalisme sensible.

Les films Ghibli explorent souvent :

- l’enfance ;
- la nature ;
- le passage entre mondes ;
- les esprits ;
- les ruines ;
- les machines ;
- la guerre ;
- la nourriture ;
- la maison ;
- le vol ;
- la perte ;
- la réparation ;
- la coexistence entre humains et non-humains.

Ghibli ne se réduit pas à un “style mignon”.  
C’est une manière de filmer le vivant : herbes, poussière, nuages, cuisine, bois, pluie, fatigue, peur, courage et silence.

---

## 🎞️ 3. Filmographie repère — grands films et fonctions symboliques

Cette section donne à un LLM une carte synthétique des principaux longs-métrages associés au studio. Elle ne remplace pas les sources officielles ou encyclopédiques.

### 🌬️ 3.1 Nausicaä de la Vallée du Vent — 1984

Film antérieur à la fondation officielle de Ghibli, mais souvent traité comme matrice spirituelle du studio.

Fonctions :

- monde post-catastrophe ;
- écologie profonde ;
- insectes géants ;
- princesse pacificatrice ;
- guerre contre compréhension du vivant ;
- toxicité du monde comme symptôme d’une blessure ancienne.

Usage ERITH.IA :

- vallée-refuge ;
- forêt toxique incomprise ;
- héroïne médiatrice entre humains et créatures ;
- écologie sacrée ;
- monde à écouter avant de vouloir le purifier.

---

### 🏰 3.2 Le Château dans le ciel — 1986

Aventure aérienne autour d’une cité volante, d’un héritage ancien, de pirates du ciel, de machines perdues et d’une technologie devenue légende.

Fonctions :

- cité céleste ;
- cristal / héritage ;
- robots gardiens ;
- pirates comiques et maternels ;
- technologie ancienne ;
- chute des empires.

Usage ERITH.IA :

- ruines célestes ;
- château-machine ;
- île volante végétalisée ;
- gardiens mécaniques mélancoliques ;
- technologie qui survit à ses maîtres.

---

### 🐾 3.3 Mon voisin Totoro — 1988

Film de l’enfance, de la campagne, de la maladie, de l’attente, des esprits forestiers et de la douceur du quotidien.

Fonctions :

- maison de campagne ;
- enfants face à l’inquiétude ;
- esprit protecteur ;
- arbre sacré ;
- pluie, bus, graines, sommeil ;
- merveilleux non expliqué.

Usage ERITH.IA :

- esprit de maison / forêt ;
- enfance qui perçoit ce que les adultes oublient ;
- rituel de plantation ;
- pluie protectrice ;
- creature douce sans explication excessive.

---

### 🪦 3.4 Le Tombeau des lucioles — 1988

Film tragique d’Isao Takahata sur la guerre, la faim, l’enfance détruite et l’échec des adultes.

Fonctions :

- guerre vue par les enfants ;
- faim ;
- lucioles ;
- perte irréversible ;
- anti-spectacle de la guerre ;
- mémoire douloureuse.

Usage ERITH.IA :

- traiter la guerre sans héroïsation ;
- montrer les conséquences sur les corps faibles ;
- utiliser la lumière fragile comme mémoire ;
- ne pas transformer la souffrance en décor esthétique vide.

---

### 🧹 3.5 Kiki la petite sorcière — 1989

Récit d’apprentissage, d’indépendance, de travail, de fatigue, de confiance perdue et retrouvée.

Fonctions :

- jeune fille quittant le foyer ;
- ville européenne imaginaire ;
- balai / vol ;
- service de livraison ;
- perte de pouvoir ;
- art et confiance.

Usage ERITH.IA :

- jeune créatrice qui cherche sa place ;
- pouvoir dépendant de l’état intérieur ;
- ville-port lumineuse ;
- travail humble comme construction de soi ;
- fatigue créative et retour du souffle.

---

### 🐷 3.6 Porco Rosso — 1992

Aviation, mélancolie, anti-fascisme, honneur, amour impossible, mécanique et ciel méditerranéen.

Fonctions :

- pilote maudit ;
- hydravions ;
- hangars ;
- mer adriatique ;
- guerre passée ;
- élégance mélancolique.

Usage ERITH.IA :

- pilote hanté par son passé ;
- machine volante artisanale ;
- ciel comme refuge ;
- guerre refusée ;
- humour sec et mélancolie adulte.

---

### 🌊 3.7 Je peux entendre l’océan — 1993

Film plus réaliste, adolescence, mémoire, distance, malentendus et émotion discrète.

Fonctions :

- lycée ;
- souvenir ;
- relation ambiguë ;
- mer comme arrière-plan émotionnel ;
- réalisme quotidien.

Usage ERITH.IA :

- mémoire adolescente ;
- ville côtière ;
- émotion retenue ;
- silence relationnel ;
- nostalgie sans fantastique.

---

### 🦝 3.8 Pompoko — 1994

Fable écologique et politique sur des tanukis confrontés à l’urbanisation.

Fonctions :

- métamorphose ;
- folklore ;
- résistance à l’urbanisation ;
- comédie collective ;
- perte d’habitat ;
- tristesse derrière le rire.

Usage ERITH.IA :

- peuple-esprit menacé ;
- ville qui avance comme maladie ;
- comédie comme défense ;
- transformation collective ;
- disparition d’un monde rural.

---

### 🐱 3.9 Si tu tends l’oreille — 1995

Récit réaliste sur l’écriture, l’adolescence, la vocation, le doute et l’écoute intérieure.

Fonctions :

- jeune écrivaine ;
- bibliothèque ;
- chat-guide ;
- atelier d’artisan ;
- rêve créatif ;
- discipline et doute.

Usage ERITH.IA :

- module créatif intime ;
- atelier comme sanctuaire ;
- lecture comme piste ;
- vocation qui demande travail ;
- chat comme passeur discret.

---

### 🐺 3.10 Princesse Mononoké — 1997

Conflit entre forêt ancienne, dieux animaux, industrie, survie humaine, guerre et malédiction.

Fonctions :

- forêt sacrée ;
- dieux animaux ;
- fer et industrie ;
- malédiction ;
- héroïne sauvage ;
- conflit sans solution simple ;
- coexistence difficile.

Usage ERITH.IA :

- éviter le dualisme simpliste ;
- faire coexister besoins humains et forces sauvages ;
- forêt comme sujet ;
- malédiction comme haine matérialisée ;
- fer contre chair du monde.

---

### 🛁 3.11 Le Voyage de Chihiro — 2001

Passage initiatique dans un monde d’esprits, bain public, noms volés, travail, pollution, gloutonnerie, mémoire et retour à soi.

Fonctions :

- monde des esprits ;
- nom confisqué ;
- travail comme survie ;
- maison de bains ;
- parents transformés ;
- esprit pollué ;
- identité restaurée.

Usage ERITH.IA :

- seuil entre réel et esprit ;
- institution magique ;
- nom comme clé d’identité ;
- travail humble comme initiation ;
- purification d’un esprit blessé.

---

### 🐱 3.12 Le Royaume des chats — 2002

Conte léger autour d’un royaume animal, d’une héroïne emportée dans un monde parallèle et d’une noblesse féline.

Fonctions :

- monde animal ;
- royaume parallèle ;
- transformation possible ;
- conte d’aventure ;
- identité à préserver.

Usage ERITH.IA :

- cour animale ;
- passage par gratitude mal orientée ;
- héroïne qui doit rester elle-même ;
- monde élégant mais piégeant.

---

### 🔥 3.13 Le Château ambulant — 2004

Maison-machine vivante, malédiction de vieillesse, guerre absurde, magicien fuyant, feu domestique et amour réparateur.

Fonctions :

- maison ambulante ;
- machine organique ;
- vieillesse magique ;
- guerre lointaine ;
- cœur caché ;
- feu-personnage ;
- soin domestique.

Usage ERITH.IA :

- maison vivante ;
- cockpit domestique ;
- machine poétique ;
- cœur moteur ;
- nettoyage comme guérison ;
- amour qui réorganise l’espace.

---

### 🌊 3.14 Ponyo sur la falaise — 2008

Conte marin, enfance, tempête, poisson-fille, magie océanique et amour simple.

Fonctions :

- mer vivante ;
- enfant-poisson ;
- falaise ;
- tsunami merveilleux ;
- famille ;
- amour enfantin.

Usage ERITH.IA :

- mer-personnage ;
- enfance élémentaire ;
- vague comme être vivant ;
- magie simple et massive ;
- maison au bord du monde.

---

### 🌾 3.15 Arrietty — 2010

Petits êtres vivant sous les maisons, emprunt, fragilité, discrétion, regard sur les objets ordinaires.

Fonctions :

- miniaturisation ;
- monde sous le monde ;
- objets géants ;
- fragilité ;
- maladie ;
- cohabitation prudente.

Usage ERITH.IA :

- peuple minuscule ;
- maison comme continent ;
- objets quotidiens transformés en architecture ;
- secret fragile ;
- échelle comme poésie.

---

### 🏞️ 3.16 La Colline aux coquelicots — 2011

Mémoire d’après-guerre, lycée, maison associative, patrimoine, deuil et reconstruction.

Fonctions :

- Japon d’après-guerre ;
- bâtiment étudiant ;
- mémoire familiale ;
- reconstruction ;
- jeunesse tournée vers l’avenir.

Usage ERITH.IA :

- lieu collectif à sauver ;
- maison pleine d’affiches et de poussière ;
- mémoire d’un parent disparu ;
- rénovation comme acte de fidélité.

---

### ✈️ 3.17 Le Vent se lève — 2013

Biographie poétique autour de l’aviation, du rêve technique, de la maladie, de la guerre et de la responsabilité morale de créer.

Fonctions :

- ingénieur rêveur ;
- avions ;
- beauté technique ;
- guerre ;
- amour fragile ;
- création moralement ambivalente.

Usage ERITH.IA :

- inventeur face aux conséquences ;
- machine belle mais récupérée par la guerre ;
- rêve technique contaminé ;
- vent comme appel et avertissement.

---

### 🎋 3.18 Le Conte de la princesse Kaguya — 2013

Style pictural épuré inspiré du conte japonais, enfance, noblesse, cage sociale, fugacité de la vie.

Fonctions :

- aquarelle / trait vivant ;
- conte ancien ;
- enfant de bambou ;
- enfermement social ;
- beauté fragile ;
- retour céleste.

Usage ERITH.IA :

- privilégier le trait, le vide et l’émotion ;
- conte lunaire ;
- personnage enfermé dans une forme sociale ;
- beauté qui ne peut pas être possédée.

---

### 🏚️ 3.19 Souvenirs de Marnie — 2014

Mémoire, solitude, maison au marais, amitié fantomatique, famille et guérison intérieure.

Fonctions :

- maison isolée ;
- marais ;
- enfant solitaire ;
- amie mystérieuse ;
- mémoire familiale ;
- réparation émotionnelle.

Usage ERITH.IA :

- maison-mémoire ;
- amitié à travers le temps ;
- brouillard ;
- solitude qui se déplie ;
- révélation douce d’une filiation.

---

### 🧙 3.20 Aya et la sorcière — 2020

Film en animation 3D, sorcellerie domestique, enfant rusée, maison magique, apprentissage et contrôle.

Fonctions :

- sorcière ;
- maison-laboratoire ;
- enfant manipulatrice mais inventive ;
- magie domestique ;
- relation de pouvoir.

Usage ERITH.IA :

- maison de sorcière moderne ;
- enfant stratège ;
- grimoires et potions ;
- apprentissage par négociation.

---

### 🪶 3.21 Le Garçon et le Héron — 2023

Film tardif de Miyazaki, deuil, guerre, monde parallèle, tour, oiseaux, mémoire familiale et passage initiatique.

Fonctions :

- deuil maternel ;
- tour-seuil ;
- monde impossible ;
- héron ambigu ;
- guerre en arrière-plan ;
- héritage et refus de devenir maître d’un monde truqué.

Usage ERITH.IA :

- tour intérieure ;
- guide animal ambigu ;
- deuil comme passage ;
- monde parallèle instable ;
- choix de revenir au réel plutôt que régner sur l’illusion.

---

## 🔮 4. Grammaire symbolique Ghibli

### 🌿 4.1 Nature vivante

Chez Ghibli, la nature n’est pas un décor. Elle observe, respire, répond, souffre, protège ou résiste.

Usage ERITH.IA :

Créer des forêts, vents, mers, arbres, insectes et montagnes comme présences actives, pas comme arrière-plans passifs.

---

### 🏡 4.2 Maison-refuge / maison-organisme

La maison Ghibli est souvent un personnage : refuge, seuil, corps, mémoire, machine ou monde intérieur.

Usage ERITH.IA :

Créer des maisons vivantes, cockpits domestiques, ateliers, cuisines, greniers, chambres d’enfants, bibliothèques et refuges qui changent selon l’état émotionnel.

---

### ✈️ 4.3 Vol et ciel

Le vol est liberté, fuite, rêve technique, danger, enfance ou mélancolie.

Usage ERITH.IA :

Créer des machines volantes artisanales, cités célestes, nuages habités, ailes mécaniques, dirigeables poétiques ou balais de travail.

---

### 🧹 4.4 Travail humble

Nettoyer, cuisiner, livrer, réparer, porter, ranger, balayer : les gestes ordinaires transforment les personnages.

Usage ERITH.IA :

Ne pas toujours chercher le spectaculaire. Montrer un personnage qui change parce qu’il travaille, soigne, répare ou nourrit.

---

### 🍲 4.5 Nourriture et soin

La nourriture chez Ghibli ancre le merveilleux dans le corps.

Usage ERITH.IA :

Utiliser le repas, le thé, la soupe, le pain, le riz, le feu de cuisine et la table comme preuves de vie.

---

### 🕯️ 4.6 Guerre et pacifisme

La guerre est rarement héroïsée. Elle est blessure, absurdité, destruction des innocents, contamination des rêves techniques.

Usage ERITH.IA :

Traiter la guerre comme catastrophe morale et matérielle, jamais comme simple décor épique.

---

## 🎨 5. Direction Artistique — Style Lock Ghibli

### 🎛️ 5.1 Palette

Palette dominante :

- 🌿 verts naturels ;
- ☁️ bleus de ciel ;
- 🌾 jaunes doux ;
- 🧱 bruns de bois et terre ;
- 🌸 roses légers ;
- 🔥 oranges de feu domestique ;
- 🌫️ gris de pluie ou de guerre ;
- 🕯️ lumières chaudes intérieures.

Principe :

La DA doit sembler respirer.  
Même une machine doit avoir une fatigue, une patine, une histoire.  
Même un décor doit avoir été habité.

---

### 🧍 5.2 Silhouettes

Codes visuels :

- silhouettes simples mais expressives ;
- vêtements pratiques ;
- tabliers, robes, manteaux, bottes, chemises ;
- cheveux et tissus sensibles au vent ;
- gestes quotidiens ;
- animaux ou esprits proches du corps ;
- machines non parfaitement symétriques.

Usage ERITH.IA :

Créer des personnages lisibles par posture et geste : porter un seau, tenir une tasse, courir dans l’herbe, regarder un ciel, réparer une aile.

---

### 🎥 5.3 Plans et cadrages

Plans typiques à retenir :

- personnage minuscule face à un paysage immense ;
- cuisine chaude et vivante ;
- maison sous la pluie ;
- forêt vue depuis un seuil ;
- machine volante dans les nuages ;
- enfant qui regarde une créature ;
- herbes traversées par le vent ;
- silence avant apparition.

Usage vidéo :

Pour Wan / I2V, privilégier :

- caméra fixe ;
- herbes qui bougent ;
- rideaux dans le vent ;
- vapeur de thé ;
- feu qui pulse ;
- nuages lents ;
- machine qui respire ;
- lumière qui traverse une fenêtre ;
- personnage immobile qui écoute.

---

### 🏡 5.4 Architecture et lieux

Inspirations structurelles :

- maisons de campagne ;
- ateliers encombrés ;
- cuisines ;
- ports européens imaginaires ;
- bains publics ;
- châteaux-machines ;
- cités célestes ;
- forêts sacrées ;
- villages côtiers ;
- ruines végétalisées ;
- gares, trains, ponts, greniers.

Usage ERITH.IA :

Créer des lieux originaux : maison-ballon, atelier de nuages, cuisine d’esprits, phare végétal, train des marais, serre volante, village dans un arbre, cockpit domestique.

---

### ✨ 5.5 Effets et matière

Effets visuels compatibles :

- vent visible dans les herbes ;
- poussière dorée ;
- vapeur ;
- pluie douce ;
- lumière chaude ;
- nuages lents ;
- machines qui toussent ;
- bois patiné ;
- tissus qui flottent ;
- esprits discrets ;
- eau comme miroir.

Éviter :

- style IA lisse et plastique ;
- copier Totoro, Chihiro, Howl, Sophie, Ponyo, San ou autres personnages ;
- copier les créatures exactes ;
- saturer de détails sans respiration ;
- rendre tout trop épique ;
- transformer Ghibli en simple filtre pastel.

---

## 🧬 6. Archétypes utilisables sans copie

### 🌿 6.1 L’enfant qui voit le vivant

Personnage qui perçoit une présence que les adultes ignorent ou ont oubliée.

Usage :

- enfant gardien ;
- petite héroïne de seuil ;
- garçon silencieux en deuil ;
- sœur protectrice ;
- enfant qui parle aux maisons, arbres ou vents.

---

### 🧹 6.2 La jeune travailleuse magique

Personnage qui apprend par le travail humble : livrer, nettoyer, cuisiner, réparer.

Usage :

- apprentie sorcière ;
- servante d’un monde d’esprits ;
- livreuse aérienne ;
- gardienne d’atelier ;
- réparatrice de machines vivantes.

---

### 🛠️ 6.3 L’ingénieur rêveur

Personnage qui aime les machines mais doit affronter leur usage moral.

Usage :

- constructeur d’ailes ;
- mécanicien de château mobile ;
- pilote hanté ;
- inventeur pacifiste ;
- artisan de navire volant.

---

### 🐺 6.4 L’esprit ancien

Présence non humaine liée à une forêt, une rivière, une maison, une montagne ou un animal.

Usage :

- gardien silencieux ;
- créature douce mais puissante ;
- dieu malade ;
- esprit pollué ;
- animal-seuil.

---

### 🏡 6.5 La maison vivante

Lieu qui protège, désobéit, tombe malade ou se transforme.

Usage :

- cockpit domestique ;
- maison ambulante ;
- refuge aérien ;
- cuisine magique ;
- grenier mémoire ;
- architecture émotionnelle.

---

## 🌌 7. Thèmes compatibles ERITH.IA

Thèmes majeurs :

- 🌿 nature ;
- 🌬️ souffle ;
- 🏡 maison ;
- ✈️ ciel ;
- 🛠️ machine ;
- 👧 enfance ;
- 🧙 merveilleux ;
- 🍲 nourriture ;
- 🕯️ deuil ;
- 🔥 guerre ;
- 🐺 esprits ;
- 🧹 travail humble ;
- 🌧️ pluie ;
- 🕊️ paix ;
- 🧭 passage ;
- 🏚️ ruines ;
- 💚 réparation.

Connexions fortes avec ERITH.IA :

- interface comme maison vivante ;
- module comme pièce habitée ;
- prompt comme souffle d’activation ;
- GitHub comme grenier d’archives ;
- Notion comme maison éditoriale ;
- Wan I2V comme mise en respiration d’une image ;
- Seven comme gardienne de seuil ;
- production vidéo comme voyage d’île en île, pièce en pièce, monde en monde.

---

## 🛡️ 8. Garde-fous créatifs

Ne pas faire :

- ne pas copier Totoro, Chihiro, Haku, Howl, Sophie, Ponyo, San, Kiki ou d’autres personnages ;
- ne pas reprendre les designs exacts ;
- ne pas utiliser les noms propres Ghibli dans les créations finales Hors-Lore ;
- ne pas reproduire les créatures officielles ;
- ne pas copier les maisons, châteaux, robots ou machines exactes ;
- ne pas réduire Ghibli à “pastel mignon” ;
- ne pas créer une scène qui semble être un fan art déguisé si l’objectif est un univers original.

Faire :

- utiliser la grammaire du vivant ;
- créer des mondes originaux ;
- garder le souffle, le silence et les gestes ;
- donner une histoire aux objets ;
- faire respirer les décors ;
- traiter nature, guerre et enfance avec respect ;
- séparer référence culturelle et production originale.

---

## 🔗 9. Références consultables par LLM

### 🏛️ Sources officielles

Site officiel Studio Ghibli :  
https://www.ghibli.jp/

Studio Ghibli — films / works :  
https://www.ghibli.jp/works/

Ghibli Museum :  
https://www.ghibli-museum.jp/en/

Ghibli Park :  
https://ghibli-park.jp/en/

### 📚 Sources de structure narrative

Studio Ghibli — Wikipédia :  
https://en.wikipedia.org/wiki/Studio_Ghibli

Filmographie Studio Ghibli — Wikipédia :  
https://en.wikipedia.org/wiki/List_of_Studio_Ghibli_works

Hayao Miyazaki — Wikipédia :  
https://en.wikipedia.org/wiki/Hayao_Miyazaki

Isao Takahata — Wikipédia :  
https://en.wikipedia.org/wiki/Isao_Takahata

Toshio Suzuki — Wikipédia :  
https://en.wikipedia.org/wiki/Toshio_Suzuki_(producer)

### 🧭 Sources fan / encyclopédiques

Ghibli Wiki :  
https://ghibli.fandom.com/wiki/Studio_Ghibli

Nausicaä.net — ressources Ghibli :  
http://www.nausicaa.net/

Buta Connection — dossiers Studio Ghibli :  
https://www.buta-connection.net/

### 🧠 Usage recommandé des liens

Ces liens servent de bibliothèque externe consultable.  
Le module ne doit pas recopier massivement les contenus.  
Il doit s’en servir pour comprendre :

- la filmographie ;
- les thèmes récurrents ;
- les directeurs principaux ;
- la place de la nature ;
- la nourriture et les gestes quotidiens ;
- la guerre et le pacifisme ;
- les machines ;
- les maisons ;
- les esprits ;
- les mondes de seuil ;
- la direction artistique dessinée à la main.

---

## 🖼️ 10. Prompts maîtres — image

### 🌿 Prompt image — Maison vivante dans la nature

Une maison vivante originale posée au bord d’une forêt ancienne, architecture de bois, pierre et métal doux, petites fenêtres chaudes, linge qui sèche au vent, herbes hautes en mouvement, cuisine lumineuse visible à travers une porte ouverte, vapeur de soupe, ciel bleu traversé par des nuages lents, atmosphère de refuge, enfance, silence et merveilleux quotidien, animation hand-painted inspired, watercolor softness, cinematic composition, original universe, no existing Studio Ghibli character or creature.

Prompt négatif :

Totoro, Chihiro, Howl, Sophie, Ponyo, Kiki, San, Haku, Ghibli character, copied creature, copied castle, fan art, official logo, text, watermark, plastic 3D, over-smooth AI look, low quality, bad anatomy.

---

### ✈️ Prompt image — Machine volante artisanale

Une machine volante artisanale originale traverse lentement une mer de nuages, ailes de toile, bois, cuivre et rivets, cockpit ouvert rempli de cartes et de petits outils, jeune mécanicienne originale regardant l’horizon, lumière dorée du matin, vent dans les cheveux et les tissus, sentiment de liberté mélancolique, ciel immense, hand-drawn animation look, painterly background, original design, no existing franchise vehicle.

Prompt négatif :

Laputa robot, Howl castle, Porco plane exact, Ghibli vehicle copy, fan art, logo, text, watermark, sci-fi spaceship, plastic render, low detail.

---

### 🛁 Prompt image — Bain des esprits original

Un bain public spirituel original caché dans une vallée brumeuse, lanternes chaudes, vapeur, bois ancien, rivière noire calme, petits esprits inventés sans reprendre de créatures existantes, travailleuse en tablier portant un seau, atmosphère de seuil entre réel et invisible, détails de cuisine et de nettoyage, lumière douce, hand-painted anime background, original universe.

Prompt négatif :

Spirited Away bathhouse exact, No-Face, Chihiro, Haku, Yubaba, soot sprites, copied spirits, Ghibli logo, fan art, text, watermark, over-detailed clutter, low quality.

---

## 🎞️ 11. Prompts maîtres — animation Wan / I2V

### 🌬️ Animation 1 — Maison qui respire

Caméra fixe. La maison reste immobile, mais semble vivante par de petits détails : rideaux qui bougent doucement, herbes dans le vent, vapeur sortant de la cuisine, lumière chaude qui tremble à la fenêtre, nuages lents dans le ciel. Aucun mouvement brusque. Ambiance de refuge, calme, souffle et présence. Durée courte, 9:16, 16 fps, mouvement minimal, stabilité maximale.

Prompt négatif :

camera shake, fast zoom, house walking, morphing architecture, copied Ghibli castle, character duplication, plastic render, text, logo, watermark, unstable background.

---

### ✈️ Animation 2 — Vol lent dans les nuages

Caméra fixe ou très légère poussée lente. Une machine volante originale avance doucement dans les nuages. Les ailes de toile vibrent légèrement. Les nuages bougent lentement. Des cartes frémissent dans le cockpit. Lumière dorée stable. Aucun combat aérien, aucune explosion. Ambiance de liberté mélancolique et d’appel du ciel. Durée courte, 9:16, 16 fps.

Prompt négatif :

dogfight, explosion, fast camera, copied Ghibli aircraft, spaceship, morphing vehicle, unstable wings, text, logo, watermark, low quality.

---

### 🍲 Animation 3 — Cuisine chaude

Caméra fixe dans une petite cuisine vivante. Une soupe fume doucement. Le feu pulse dans l’âtre. Un torchon bouge au vent près de la fenêtre. La lumière du soir traverse la pièce. Aucun grand mouvement. Ambiance de soin, fatigue douce, refuge, repas après voyage. Durée courte, 9:16, 16 fps.

Prompt négatif :

fast movement, fire explosion, copied Ghibli kitchen, character morphing, extra limbs, text, logo, watermark, plastic 3D, unstable objects.

---

## 🎬 12. Usage vidéo — cartes utiles

Pour une production ERITH.IA influencée par Studio Ghibli, activer en priorité :

- 📐 Géométrie du Plan ;
- 🧠 Psychologie du Plan ;
- 🔮 Symbolique ;
- 🧱 LEGO Continuity ;
- 🩺 Diagnostic Anti-Dérive Wan ;
- 🎧 Sound Design / Voix / Silence.

Risque principal :

La dérive vers le “faux style Ghibli” générique, le fan art explicite, la surenchère de créatures mignonnes ou l’image IA trop lisse.

Action immédiate recommandée :

Verrouiller une image source très simple :

- un lieu vivant ;
- un personnage original ;
- un geste quotidien ;
- un élément naturel ;
- une émotion douce ;
- un mouvement vidéo maximum.

Point d’arrêt :

Quand le lieu respire, que la lumière est juste et que le geste est lisible, ne pas complexifier.

---

## 🎧 13. Sound Design / Silence

Ghibli fonctionne avec le silence habité : vent, pluie, bois, pas, feu, cuisine, tissus, insectes, eau, oiseaux, respiration.

Sons compatibles :

- vent dans les herbes ;
- pluie douce ;
- feu de cuisine ;
- bois qui craque ;
- vapeur ;
- cloche lointaine ;
- pas sur plancher ;
- insectes du soir ;
- oiseaux ;
- moteur fatigué ;
- souffle d’une machine ;
- silence avant apparition.

Éviter :

- musique épique automatique ;
- sound design trop hollywoodien ;
- bruitage magique permanent ;
- surcharge sonore ;
- voix off qui explique tout.

Décision sonore recommandée :

La scène doit souvent commencer par un son simple du monde : vent, feu, eau, bois, pluie ou respiration.  
La musique peut attendre. Le silence doit avoir le droit d’exister.

---

## 🤖 14. Block LLM compatible

### 🪪 Identité du module

Tu es le Module Mémoire Studio Ghibli / Mondes Vivants pour ERITH.IA.

Tu n’es pas un générateur de fan fiction Ghibli.  
Tu n’es pas chargé de copier les personnages, les créatures, les noms propres, les films, les lieux ou les designs exacts du Studio Ghibli.

Tu utilises Studio Ghibli comme influence culturelle, symbolique et visuelle autour de :

- la nature vivante ;
- le souffle ;
- la maison-refuge ;
- les machines artisanales ;
- l’enfance ;
- les esprits ;
- la nourriture ;
- le travail humble ;
- le vol ;
- la guerre comme blessure ;
- le soin ;
- le merveilleux quotidien ;
- la réparation.

### ⚙️ Règles d’usage

Quand ce module est activé :

1. Cherche la fonction sensible de la demande.
2. Ne copie jamais Ghibli directement.
3. Remplace les personnages, créatures, maisons, machines et lieux par des équivalents originaux.
4. Garde la grammaire du vivant : vent, herbe, pluie, maison, cuisine, bois, nuages, gestes, silence.
5. Privilégie les scènes simples, respirantes, émotionnelles, lisibles.
6. Pour la vidéo, limite le mouvement à une idée claire.
7. Pour les prompts, ajoute toujours un garde-fou anti-fan-art.
8. Pour l’analyse, sépare référence, interprétation et usage créatif.

### 🛑 Limites

Ne pas produire :

- une copie de Totoro, Chihiro, Haku, Howl, Sophie, Ponyo, Kiki, San ou tout autre personnage ;
- une créature officielle reproduite ;
- un château officiel reproduit ;
- une machine officielle reproduite ;
- un lieu officiel reproduit ;
- une intrigue directement reprise ;
- un design identifiable comme image officielle ou fan art direct.

### ⚡ Activation courte

Active le Module Mémoire Studio Ghibli / Mondes Vivants.  
Utilise Studio Ghibli comme influence symbolique et visuelle autour de la nature vivante, du souffle, de la maison-refuge, des machines artisanales, de l’enfance, des esprits, de la nourriture, du travail humble, du vol, de la guerre comme blessure et du merveilleux quotidien.  
Ne copie aucun personnage, créature, lieu, machine, nom propre, intrigue ou design exact.  
Crée uniquement des scènes et concepts originaux compatibles ERITH.IA.

### 🚀 Activation production

Active le Module Mémoire Studio Ghibli / Mondes Vivants en mode production ERITH.IA.

Objectif : créer une scène originale influencée par la grammaire Ghibli sans copier l’œuvre.

Utilise les axes suivants :

- nature comme présence ;
- maison comme refuge vivant ;
- vent comme mouvement principal ;
- nourriture comme soin ;
- machine comme organisme artisanal ;
- enfant comme regard de vérité ;
- esprit comme force discrète ;
- guerre comme blessure, jamais décor épique ;
- silence comme respiration ;
- geste quotidien comme transformation.

Pour une image : produire une composition simple, lisible, douce, respirante.  
Pour une animation : une seule idée de mouvement, caméra fixe, stabilité maximale.  
Pour le son : décider d’abord entre vent, pluie, feu, bois, eau, insectes, machine fatiguée, cuisine ou silence.

Toujours inclure un garde-fou : no existing Studio Ghibli character, no copied creature, no copied castle, no copied vehicle, no franchise logo, no fan art, original universe.

---

## 🌸 15. Formule courte

Studio Ghibli, pour ERITH.IA, n’est pas un filtre visuel.  
C’est une grammaire du monde vivant.

Nature = présence.  
Maison = refuge.  
Vent = souffle.  
Cuisine = soin.  
Machine = organisme.  
Enfance = vérité.  
Esprit = monde invisible.  
Guerre = blessure.  
Silence = respiration.

ERITH.IA ne copie pas Ghibli.  
ERITH.IA apprend à écrire avec l’herbe, le vent, le feu, la soupe, la maison, la machine fatiguée et le merveilleux quotidien.
