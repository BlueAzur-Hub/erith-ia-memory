# 🏰 ERITH.IA — Direction Artistique
# ☁️ Châteaux Vivants & Ruines Célestes

Statut : module de direction artistique principal  
Version : 1.0  
Usage : ERITH.IA / Seven Heaven / modules mémoire / prompts image / prompts animation / Pack+  
Mode média : texte par défaut, génération image uniquement sur demande explicite

---

[IMAGE DE PRÉSENTATION À INSÉRER ICI]

Suggestion image haute :

```text
ERITH.IA MEMORY ART DIRECTION
CHÂTEAUX VIVANTS & RUINES CÉLESTES
Maisons-mondes • Cités suspendues • Magie domestique • Mémoire du ciel
```

---

# ✨ Identité

Icône principale : 🏰  
Icônes secondaires : ☁️ 🔥 🌿 💎 ⚙️ 🕊️

Nom officiel :

**ERITH.IA — Châteaux Vivants & Ruines Célestes**

Sous-titre :

**Maisons-mondes, cités suspendues, machines tendres et mémoire du ciel.**

Formule courte :

**Une architecture qui respire, marche, vole ou se souvient.**

---

# 🌟 Description courte

Cette direction artistique crée une branche visuelle originale pour ERITH.IA, fondée sur l’architecture vivante, les refuges mobiles, les cités célestes, les ruines envahies par la nature, les machines anciennes, les cristaux de mémoire et la magie douce.

Elle ne cherche pas à copier Studio Ghibli, Hayao Miyazaki ou les films de référence.

Elle extrait plutôt des principes profonds :

- maison vivante ;
- ciel immense ;
- technologie ancienne ;
- merveilleux artisanal ;
- nature souveraine ;
- mémoire architecturale ;
- chaleur du foyer ;
- ruines suspendues ;
- critique du pouvoir et de la guerre ;
- émotion humaine simple.

Cette DA sert à créer une esthétique ERITH.IA autonome : poétique, artisanale, lumineuse, respirable, humaine, avec une profondeur symbolique exploitable en image, animation, narration et univers.

---

# 📚 Sources de référence

Références culturelles principales :

- Le Château ambulant — Studio Ghibli, 2004.
- Le Château dans le ciel — Studio Ghibli, 1986.
- Hayao Miyazaki — scénario, réalisation, univers visuel, motifs du vol, de la machine, de la nature et de l’anti-guerre.
- Joe Hisaishi — mémoire musicale, lyrisme, mélancolie, respiration émotionnelle.
- Diana Wynne Jones — source littéraire du Château ambulant.
- Toshiro Nozaki et Nizo Yamamoto — direction artistique du Château dans le ciel.
- Yoji Takeshige et Noboru Yoshida — direction artistique du Château ambulant.

Sources externes à consulter si besoin :

- https://www.ghibli.jp/works/howl/
- https://www.ghibli.jp/works/laputa/
- https://www.nausicaa.net/miyazaki/howl/credits.html
- https://www.nausicaa.net/miyazaki/laputa/credits.html
- https://www.britannica.com/biography/Miyazaki-Hayao

---

# 🧭 Principe central

Cette DA ne dit pas :

“Fais du Ghibli.”

Elle dit :

**Crée une merveille architecturale originale, artisanale, aérienne et vivante, où la maison peut avoir une âme, où le ciel peut porter des ruines, et où la technologie ancienne doit redevenir humble devant le vivant.**

---

# 🧬 ADN de la DA

## 1️⃣ Architecture vivante

Les bâtiments ne sont pas des décors passifs.

Ils peuvent :

- marcher ;
- respirer ;
- protéger ;
- se souvenir ;
- cacher un cœur ;
- contenir plusieurs mondes ;
- changer selon l’état intérieur de leurs habitants.

Formule :

**Une maison peut être un personnage sans avoir de visage.**

---

## 2️⃣ Ciel ancien

Le ciel n’est pas seulement un fond bleu.

Il devient :

- territoire ;
- mémoire ;
- seuil ;
- royaume ;
- tombeau ;
- promesse ;
- espace sacré.

Formule :

**Le ciel garde les ruines de ce que la terre a oublié.**

---

## 3️⃣ Technologie douce

La technologie ne doit pas être froide, noire ou purement cyberpunk.

Elle est :

- ancienne ;
- artisanale ;
- rivetée ;
- imparfaite ;
- lisible ;
- presque magique ;
- liée aux éléments ;
- vulnérable au temps.

Formule :

**Une machine ancienne doit sembler fabriquée par des mains, pas par une usine invisible.**

---

## 4️⃣ Nature souveraine

La nature n’est pas décorative.

Elle reprend possession :

- des pierres ;
- des tours ;
- des machines ;
- des ponts ;
- des jardins ;
- des ruines ;
- des cristaux ;
- des carcasses mécaniques.

Formule :

**Quand une civilisation disparaît, le vivant continue de lire ses murs.**

---

## 5️⃣ Merveille domestique

Le merveilleux peut être petit.

Il peut vivre dans :

- une flamme ;
- une porte ;
- une théière ;
- une cuisine ;
- une chambre ;
- un escalier ;
- une fenêtre ;
- un objet suspendu ;
- une poussière dans la lumière.

Formule :

**La magie la plus forte n’est pas toujours monumentale : parfois elle tient dans une pièce chaude.**

---

## 6️⃣ Anti-pouvoir

Cette DA doit garder une méfiance envers :

- la guerre ;
- la conquête ;
- les empires ;
- les armes anciennes ;
- la technologie sans conscience ;
- les élites qui veulent posséder le ciel ;
- la puissance coupée du vivant.

Formule :

**Monter trop haut sans sagesse finit par couper l’homme de la terre.**

---

# 🎨 Palette visuelle

## Couleurs principales

- bleu ciel lavé ;
- blanc nuage ;
- vert mousse ;
- vert forêt humide ;
- ocre pierre ;
- beige solaire ;
- brun bois ;
- cuivre oxydé ;
- rouge tuile ;
- jaune feu ;
- gris fumée ;
- turquoise minéral ;
- or discret.

## Couleurs à éviter

- néon cyberpunk dominant ;
- noir métallique dominant ;
- violet saturé agressif ;
- bleu électrique trop numérique ;
- chrome moderne trop propre ;
- ambiance techno froide sans matière.

---

# 🪵 Matières

Matières centrales :

- bois usé ;
- pierre ancienne ;
- mousse ;
- racines ;
- cuivre ;
- métal riveté ;
- verre ancien ;
- cristal ;
- tissu ;
- céramique fissurée ;
- cuir ;
- vapeur ;
- suie ;
- poussière lumineuse ;
- feu doux ;
- herbe ;
- nuages.

Matières à limiter :

- plastique moderne ;
- chrome futuriste ;
- surface trop lisse ;
- néon urbain dominant ;
- verre corporate ;
- métal noir militarisé.

---

# 🧱 Formes clés

## Châteaux vivants

- volumes empilés ;
- jambes mécaniques ;
- cheminées ;
- tourelles bancales ;
- fenêtres irrégulières ;
- portes symboliques ;
- tuyaux ;
- balcons ;
- poêles ;
- chaudières ;
- petites pièces visibles ;
- ateliers ;
- cuisines ;
- intérieurs encombrés.

## Ruines célestes

- arches brisées ;
- colonnes anciennes ;
- plateformes suspendues ;
- ponts aériens ;
- jardins en terrasse ;
- racines géantes ;
- sphères de cristal ;
- noyaux de lévitation ;
- grandes portes de pierre ;
- statues érodées ;
- gardiens silencieux ;
- machines volantes artisanales.

---

# 💡 Lumière

Lumière recommandée :

- matin brumeux ;
- fin d’après-midi dorée ;
- lumière à travers les nuages ;
- feu intérieur ;
- ciel lavé ;
- lueur de cristal très douce ;
- poussière visible dans les rayons ;
- ombres tendres.

Lumière à éviter :

- éclairage dur de blockbuster ;
- néons de nightclub ;
- contrastes cyberpunk extrêmes ;
- lumière noire ou métallique ;
- rendu horrifique.

---

# 🎥 Caméra et composition

## Plans recommandés

- plan large contemplatif ;
- plan fixe respirable ;
- contre-plongée douce vers le ciel ;
- travelling lent ;
- caméra basse près de l’herbe ;
- caméra intérieure proche du feu ;
- plan de seuil à travers une porte ;
- silhouette d’architecture dans les nuages.

## Règle de composition

La DA doit respirer.

Il faut laisser :

- du ciel ;
- du vide ;
- du vent ;
- des distances ;
- des détails vivants ;
- une échelle humaine face au monumental.

Formule :

**Un petit humain + une grande architecture + un ciel immense = merveille lisible.**

---

# 🖼️ Prompt maître image — 21/20

```text
21/20 masterpiece, original poetic animated fantasy art direction, living architecture and sky ruins, a vast house-world and an ancient suspended citadel connected by wooden bridges, pale stone, moss, roots, oxidized copper, old glass, soft glowing crystals, warm hearth lights in tiny windows, clouds drifting below, birds far away, handmade machinery, gentle steam, wind in grass and hanging plants, golden morning light, vast breathable sky, emotional wonder, human-scale details inside monumental architecture, nature reclaiming ancient technology, no known characters, no copied design, no direct imitation of any existing film, cinematic composition, text-free image
```

---

# 🎞️ Prompt maître animation — 21/20

```text
21/20 cinematic animation, fixed wide contemplative shot, original living architecture suspended between earth and sky, a house-world gently breathing while an ancient sky ruin floats behind it, clouds drifting slowly, smoke rising softly from chimneys, leaves and moss moving in the wind, a small crystal core pulsing faintly, warm windows glowing, subtle handmade mechanisms moving, calm light shift, poetic atmosphere, no chaotic camera, no fast motion, no known characters, no copied design, original fantasy world, soft emotional pacing
```

---

# 🚫 Prompt négatif maître

```text
known characters, direct copy of existing film, recognizable castle, recognizable robot, franchise names, logo, watermark, text artifacts, neon cyberpunk dominance, black metallic city, horror atmosphere, militarized sci-fi, glossy corporate surfaces, plastic render, over-sharp 3D, chaotic camera, fast cuts, aggressive action, unreadable architecture, broken anatomy, duplicated elements, UI text inside image
```

---

# 🧪 5 exemples de création avec cette DA

## ✨ Exemple 1 — La Maison-Monde des Vents

Concept :

Une maison vivante avance lentement sur un plateau venteux. Chaque pièce correspond à une saison intérieure.

Prompt image :

```text
21/20 masterpiece, original living house-world walking through a windy highland, old wood, oxidized copper, many chimneys, uneven roofs, tiny warm windows, moss on mechanical legs, soft smoke, vast pale blue sky, handmade fantasy architecture, poetic refuge, no known characters, no copied design, cinematic animated illustration, text-free image
```

Prompt animation :

```text
Fixed wide shot. The house-world walks very slowly through grass moved by wind. Chimney smoke rises gently. Small mechanical details move. Warm windows flicker. Clouds drift slowly. Contemplative pace.
```

---

## ✨ Exemple 2 — Le Foyer des Portes

Concept :

Un intérieur magique où une porte ancienne change de destination selon la couleur d’une flamme centrale.

Prompt image :

```text
21/20 masterpiece, original magical house interior, warm hearth, old door with subtle colored light, hanging objects, books, copper pots, wooden beams, dust in sun rays, handmade details, cozy impossible room, emotional refuge, no known characters, no copied design, text-free image
```

Prompt animation :

```text
Fixed interior shot. The hearth flame pulses softly. The light behind the door changes color very slowly. Dust floats in golden light. Curtains move slightly. No camera shake.
```

---

## ✨ Exemple 3 — Le Jardin au-dessus des Nuages

Concept :

Une ruine suspendue devenue jardin, protégée par le silence, le vent et les oiseaux.

Prompt image :

```text
21/20 masterpiece, original floating sky garden, ancient pale stone ruins, broken arches, moss, roots, hanging plants, clouds below, birds far away, soft golden light, quiet sacred atmosphere, nature reclaiming old technology, no known characters, no copied design, cinematic illustration, text-free image
```

Prompt animation :

```text
Wide fixed shot above clouds. Leaves move gently. Clouds pass below. A faint crystal glow breathes once every few seconds. Birds cross the frame at a distance.
```

---

## ✨ Exemple 4 — La Machine de Lévitation Endormie

Concept :

Une machine ancienne dort dans une crypte aérienne, presque avalée par les racines.

Prompt image :

```text
21/20 masterpiece, original ancient levitation engine inside a floating ruin, stone chamber, oxidized copper rings, roots around machinery, faint turquoise crystal core, soft mist, sacred quiet atmosphere, old technology reclaimed by nature, no known characters, no copied design, text-free image
```

Prompt animation :

```text
Semi-fixed shot. The crystal core pulses faintly. Roots and leaves move with a slow wind. Dust particles drift. The ancient rings vibrate almost imperceptibly.
```

---

## ✨ Exemple 5 — Le Pont entre Maison et Ciel

Concept :

Une passerelle suspendue relie un refuge vivant à une ancienne cité céleste.

Prompt image :

```text
21/20 masterpiece, original fantasy bridge between a living house-world and a floating ancient sky citadel, wooden planks, ropes, stone arches, moss, clouds below, warm windows, golden morning light, vast sky, emotional sense of adventure, no known characters, no copied design, cinematic composition, text-free image
```

Prompt animation :

```text
Fixed shot looking along the bridge. Ropes sway gently. Clouds move below. Warm light flickers in distant windows. Hanging plants shift in the wind.
```

---

# 📦 Pack+ de démonstration

## Concept

Une ancienne cité suspendue s’est lentement liée à une maison vivante qui marche encore sur les plateaux. La maison apporte le feu, la cité apporte la mémoire du ciel. Entre les deux, un pont de bois et de racines sert de passage aux voyageurs qui cherchent un refuge ou une réponse.

## Image

```text
21/20 masterpiece, original living house-world connected to ancient sky ruins by a wooden and root bridge, warm hearth windows, pale stone arches, moss, clouds, soft glowing crystals, handmade machinery, golden light, poetic fantasy, human-scale wonder, no copied design, text-free image
```

## Animation

```text
Wide fixed shot. The house-world breathes softly. The sky ruins remain still above a sea of clouds. A bridge sways slowly in the wind. Chimney smoke rises. A crystal light pulses once. Calm poetic movement.
```

## Narration courte

La maison avait appris à marcher.  
La cité avait appris à attendre.  
Entre le feu et le ciel, quelqu’un avait construit un pont.

---

# 🤖 Block LLM — Activation courte

Active la DA ERITH.IA — Châteaux Vivants & Ruines Célestes.

Utilise une esthétique originale fondée sur :

- maisons vivantes ;
- refuges mobiles ;
- magie domestique ;
- ruines célestes ;
- cités suspendues ;
- cristaux anciens ;
- technologie douce ;
- nature souveraine ;
- ciel immense ;
- mémoire architecturale.

Ne copie pas Studio Ghibli, Hayao Miyazaki, les personnages, les designs exacts, les intrigues ou les noms propres.

Crée une direction originale : merveille architecturale, artisanat vivant, ciel sacré, chaleur humaine et ruines reprises par la nature.

---

# 🧠 Block LLM — Production

Tu charges maintenant la Direction Artistique ERITH.IA — Châteaux Vivants & Ruines Célestes.

Ta mission :

- créer des univers originaux inspirés par les principes de maison vivante, ruine céleste, technologie ancienne, foyer magique et nature souveraine ;
- produire des concepts, prompts image, prompts animation, récits courts, décors, architectures, symboles et variantes ;
- privilégier les matières anciennes : bois, pierre, cuivre, mousse, racines, tissu, feu, cristal, nuages ;
- éviter les designs trop modernes, trop cyberpunk, trop lisses ou trop copiés ;
- garder une lumière douce, respirable, aérienne, humaine ;
- intégrer une lecture symbolique : maison = psyché, feu = cœur, ciel = mémoire, ruine = civilisation passée, racines = retour du vivant, cristal = puissance concentrée ;
- ne jamais copier directement les œuvres sources.

Formule directrice :

**Une architecture qui respire, marche, vole ou se souvient.**

---

# 🪧 Texte UI de clôture

```text
DA ACTIVE : CHÂTEAUX VIVANTS & RUINES CÉLESTES
Maisons-mondes • Cités suspendues • Magie domestique • Mémoire du ciel
```

[IMAGE DE CLÔTURE À INSÉRER ICI]

---

# ✅ Commit recommandé

Add living castles and sky ruins art direction module