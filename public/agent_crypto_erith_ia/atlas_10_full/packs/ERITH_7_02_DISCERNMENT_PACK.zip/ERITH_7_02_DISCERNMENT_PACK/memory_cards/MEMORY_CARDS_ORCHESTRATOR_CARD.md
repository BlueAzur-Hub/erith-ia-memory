# 🧠 MEMORY CARDS ORCHESTRATOR CARD

Statut : Memory Card — orchestrateur du système  
Projet : @erith IA / ERITH.IA  
Version : V1 — Notion Génie  
Type : orchestration / sélection de cartes / composition / anti-surcharge / production guidée

---

# 🌟 1. Principe central

Cette carte sert à répondre à une question simple :

Quelles cartes activer maintenant, dans quel ordre, et pourquoi ?

L’Atlas montre la carte du système.

COMBINATIONS fait dialoguer les cartes.

STORY_ENGINE structure le récit.

PACK_PLUS_BUILDER assemble la sortie.

QUALITY_CONTROL vérifie.

EXPORT_AND_DELIVERY livre.

Mais il manque le chef d’orchestre.

Cette carte choisit les cartes utiles pour une demande précise, sans tout charger inutilement.

Elle sert à :

- identifier l’intention de l’utilisateur ;
- choisir les cartes pertinentes ;
- limiter la surcharge ;
- définir la carte dominante ;
- définir la carte de contraste ;
- définir la carte opératrice ;
- choisir les cartes de production ;
- ajouter contrôle qualité et export si nécessaire ;
- produire une route courte, claire et exploitable.

Formule :

L’Atlas montre la carte.  
L’Orchestrator choisit le chemin.  
Les cartes composent.  
La production commence.

---

# 🔗 2. Cartes liées

Cette carte peut appeler toutes les cartes, mais ne doit jamais tout appeler par réflexe.

Cartes de navigation :

- MEMORY_CARDS_ATLAS_CARD.md ;
- COMBINATIONS.md.

Cartes moteur :

- STORY_ENGINE_CARD.md ;
- PACK_PLUS_BUILDER_CARD.md ;
- QUALITY_CONTROL_CARD.md ;
- EXPORT_AND_DELIVERY_CARD.md.

Cartes narratives :

- CHILDREN_STORY_THEMES_CARD.md ;
- HERO_ARCHETYPES_CARD.md ;
- WORLDS_AND_PLACES_CARD.md ;
- GUIDES_AND_ALLIES_CARD.md ;
- QUEST_OBJECTS_CARD.md ;
- OBSTACLES_AND_ANTAGONISTS_CARD.md ;
- EMOTIONAL_ARCS_CARD.md ;
- POWERS_AND_RULES_CARD.md.

Cartes production :

- SCENES_AND_KEYFRAMES_CARD.md ;
- VISUAL_STYLE_DNA_CARD.md ;
- MOTION_AND_CAMERA_CARD.md ;
- NARRATION_AND_DIALOGUE_CARD.md ;
- SOUND_AND_MUSIC_DESIGN_CARD.md.

---

# 🧭 3. Règle d’or

Ne pas activer toutes les cartes.

Choisir la route la plus courte qui produit un bon résultat.

Une bonne orchestration n’est pas maximale.

Elle est juste.

---

# 🧬 4. Les rôles de cartes

Pour orchestrer une demande, attribuer des rôles.

## 1. Carte dominante

C’est la carte qui donne la direction principale.

Exemples :

- CHILDREN_STORY_THEMES_CARD pour un conte enfant ;
- WORLDS_AND_PLACES_CARD pour une scène de monde ;
- SCENES_AND_KEYFRAMES_CARD pour une image ;
- PACK_PLUS_BUILDER_CARD pour une sortie complète ;
- QUALITY_CONTROL_CARD pour une correction.

## 2. Carte de contraste

C’est la carte qui apporte tension, profondeur ou différence.

Exemples :

- OBSTACLES_AND_ANTAGONISTS_CARD ;
- EMOTIONAL_ARCS_CARD ;
- QUEST_OBJECTS_CARD ;
- POWERS_AND_RULES_CARD.

## 3. Carte opératrice

C’est la carte qui transforme la matière en sortie.

Exemples :

- STORY_ENGINE_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- PACK_PLUS_BUILDER_CARD.

## 4. Carte émotionnelle

C’est la carte qui donne le cœur.

Exemple principal :

- EMOTIONAL_ARCS_CARD.

## 5. Carte de style

C’est la carte qui donne l’identité visuelle.

Exemple principal :

- VISUAL_STYLE_DNA_CARD.

## 6. Carte de mouvement

C’est la carte qui transforme l’image en animation stable.

Exemple principal :

- MOTION_AND_CAMERA_CARD.

## 7. Carte de voix

C’est la carte qui donne narration ou dialogue.

Exemple principal :

- NARRATION_AND_DIALOGUE_CARD.

## 8. Carte sonore

C’est la carte qui donne ambiance audio et musique.

Exemple principal :

- SOUND_AND_MUSIC_DESIGN_CARD.

## 9. Carte de contrôle

C’est la carte qui valide.

Exemple principal :

- QUALITY_CONTROL_CARD.

## 10. Carte de livraison

C’est la carte qui donne une place finale à la sortie.

Exemple principal :

- EXPORT_AND_DELIVERY_CARD.

---

# 🧪 5. Diagnostic rapide de demande

Avant de produire, identifier le type de demande.

## Demande de conte

Mots signaux :

- conte ;
- enfant ;
- histoire ;
- atelier ;
- morale ;
- personnage ;
- rêve ;
- guide ;
- aventure douce.

Cartes probables :

- CHILDREN_STORY_THEMES_CARD ;
- HERO_ARCHETYPES_CARD ;
- STORY_ENGINE_CARD ;
- EMOTIONAL_ARCS_CARD ;
- PACK_PLUS_BUILDER_CARD si sortie complète.

## Demande d’image

Mots signaux :

- image ;
- prompt image ;
- couverture ;
- keyframe ;
- visuel ;
- style ;
- carte mémoire.

Cartes probables :

- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- WORLDS_AND_PLACES_CARD ;
- QUALITY_CONTROL_CARD.

## Demande d’animation

Mots signaux :

- animation ;
- Wan ;
- I2V ;
- mouvement ;
- caméra ;
- last frame ;
- DaVinci ;
- clip.

Cartes probables :

- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- MOTION_AND_CAMERA_CARD ;
- SOUND_AND_MUSIC_DESIGN_CARD ;
- QUALITY_CONTROL_CARD.

## Demande de Pack+

Mots signaux :

- Pack+ ;
- complet ;
- exploitable ;
- image + animation + narration ;
- production.

Cartes probables :

- COMBINATIONS ;
- STORY_ENGINE_CARD ;
- PACK_PLUS_BUILDER_CARD ;
- QUALITY_CONTROL_CARD ;
- EXPORT_AND_DELIVERY_CARD.

## Demande de correction

Mots signaux :

- améliore ;
- vérifie ;
- corrige ;
- c’est trop chargé ;
- pas stable ;
- pas assez clair ;
- qualité.

Cartes probables :

- QUALITY_CONTROL_CARD ;
- carte concernée seulement ;
- EXPORT_AND_DELIVERY_CARD si livraison.

## Demande de livraison

Mots signaux :

- GitHub ;
- Notion ;
- commit ;
- renomme ;
- sandbox ;
- upload ;
- insère ;
- YouTube ;
- archive.

Cartes probables :

- EXPORT_AND_DELIVERY_CARD ;
- QUALITY_CONTROL_CARD si validation nécessaire.

---

# 🛤️ 6. Routes orchestrées

## Route conte enfant courte

Carte dominante : CHILDREN_STORY_THEMES_CARD  
Cœur : HERO_ARCHETYPES_CARD  
Transformation : EMOTIONAL_ARCS_CARD  
Moteur : STORY_ENGINE_CARD  
Sortie : PACK_PLUS_BUILDER_CARD  
Contrôle : QUALITY_CONTROL_CARD

Route :

CHILDREN_STORY_THEMES_CARD → HERO_ARCHETYPES_CARD → EMOTIONAL_ARCS_CARD → STORY_ENGINE_CARD → PACK_PLUS_BUILDER_CARD → QUALITY_CONTROL_CARD

## Route image master

Carte dominante : SCENES_AND_KEYFRAMES_CARD  
Style : VISUAL_STYLE_DNA_CARD  
Monde : WORLDS_AND_PLACES_CARD si nécessaire  
Contrôle : QUALITY_CONTROL_CARD

Route :

SCENES_AND_KEYFRAMES_CARD → VISUAL_STYLE_DNA_CARD → QUALITY_CONTROL_CARD

## Route couverture Memory Card

Carte dominante : VISUAL_STYLE_DNA_CARD  
Image : SCENES_AND_KEYFRAMES_CARD  
Assemblage : PACK_PLUS_BUILDER_CARD  
Contrôle : QUALITY_CONTROL_CARD  
Export : EXPORT_AND_DELIVERY_CARD

Route :

VISUAL_STYLE_DNA_CARD → SCENES_AND_KEYFRAMES_CARD → PACK_PLUS_BUILDER_CARD → QUALITY_CONTROL_CARD → EXPORT_AND_DELIVERY_CARD

## Route animation I2V

Carte dominante : MOTION_AND_CAMERA_CARD  
Keyframe : SCENES_AND_KEYFRAMES_CARD  
Style : VISUAL_STYLE_DNA_CARD  
Son : SOUND_AND_MUSIC_DESIGN_CARD si demandé  
Contrôle : QUALITY_CONTROL_CARD

Route :

SCENES_AND_KEYFRAMES_CARD → VISUAL_STYLE_DNA_CARD → MOTION_AND_CAMERA_CARD → QUALITY_CONTROL_CARD

## Route Pack+ complet

Carte dominante : PACK_PLUS_BUILDER_CARD  
Moteur : STORY_ENGINE_CARD  
Style : VISUAL_STYLE_DNA_CARD  
Production : SCENES_AND_KEYFRAMES_CARD + MOTION_AND_CAMERA_CARD  
Voix : NARRATION_AND_DIALOGUE_CARD  
Son : SOUND_AND_MUSIC_DESIGN_CARD  
Contrôle : QUALITY_CONTROL_CARD  
Export : EXPORT_AND_DELIVERY_CARD

Route :

COMBINATIONS → STORY_ENGINE_CARD → SCENES_AND_KEYFRAMES_CARD → VISUAL_STYLE_DNA_CARD → MOTION_AND_CAMERA_CARD → NARRATION_AND_DIALOGUE_CARD → SOUND_AND_MUSIC_DESIGN_CARD → PACK_PLUS_BUILDER_CARD → QUALITY_CONTROL_CARD → EXPORT_AND_DELIVERY_CARD

## Route cyberpunk mémoire

Carte dominante : WORLDS_AND_PLACES_CARD  
Contraste : QUEST_OBJECTS_CARD ou OBSTACLES_AND_ANTAGONISTS_CARD  
Émotion : EMOTIONAL_ARCS_CARD  
Style : VISUAL_STYLE_DNA_CARD  
Image : SCENES_AND_KEYFRAMES_CARD  
Voix : NARRATION_AND_DIALOGUE_CARD si demandé

Route :

WORLDS_AND_PLACES_CARD → QUEST_OBJECTS_CARD → EMOTIONAL_ARCS_CARD → SCENES_AND_KEYFRAMES_CARD → VISUAL_STYLE_DNA_CARD → QUALITY_CONTROL_CARD

## Route livraison GitHub / Notion

Carte dominante : EXPORT_AND_DELIVERY_CARD  
Contrôle : QUALITY_CONTROL_CARD si besoin

Route :

QUALITY_CONTROL_CARD → EXPORT_AND_DELIVERY_CARD

---

# 🎚️ 7. Niveaux d’orchestration

## Niveau 1 — Réponse rapide

Utiliser 1 à 2 cartes.

Exemples :

- simple prompt image ;
- mini idée ;
- correction courte ;
- commit ;
- nommage.

## Niveau 2 — Sortie solide

Utiliser 3 à 5 cartes.

Exemples :

- image master ;
- conte court ;
- prompt animation ;
- narration courte ;
- Pack+ court.

## Niveau 3 — Production complète

Utiliser 6 à 9 cartes.

Exemples :

- Pack+ complet ;
- courte vidéo ;
- publication ;
- carte mémoire complète ;
- chaîne image → animation → narration → son → export.

## Niveau 4 — Architecture système

Utiliser Atlas + Orchestrator + cartes concernées.

Exemples :

- refonte de workflow ;
- création de nouvelle famille de cartes ;
- organisation de dépôt ;
- mise à jour d’Atlas.

Règle :

Ne jamais utiliser un niveau supérieur si un niveau inférieur suffit.

---

# 🧩 8. Exemples d’orchestration

## Exemple 1 — “Fais-moi un conte enfant avec un chat oracle”

Cartes :

- CHILDREN_STORY_THEMES_CARD ;
- HERO_ARCHETYPES_CARD ;
- GUIDES_AND_ALLIES_CARD ;
- STORY_ENGINE_CARD ;
- EMOTIONAL_ARCS_CARD.

Sortie : conte doux + morale légère.

## Exemple 2 — “Génère un prompt image pour une carte mémoire”

Cartes :

- VISUAL_STYLE_DNA_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- QUALITY_CONTROL_CARD.

Sortie : prompt image propre + garde-fous visuels.

## Exemple 3 — “Fais une version animable Wan”

Cartes :

- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- MOTION_AND_CAMERA_CARD ;
- QUALITY_CONTROL_CARD.

Sortie : prompt I2V stable.

## Exemple 4 — “Prépare-moi un Pack+ complet”

Cartes :

- COMBINATIONS ;
- STORY_ENGINE_CARD ;
- SCENES_AND_KEYFRAMES_CARD ;
- VISUAL_STYLE_DNA_CARD ;
- MOTION_AND_CAMERA_CARD ;
- NARRATION_AND_DIALOGUE_CARD ;
- SOUND_AND_MUSIC_DESIGN_CARD ;
- PACK_PLUS_BUILDER_CARD ;
- QUALITY_CONTROL_CARD.

Sortie : unité de production complète.

## Exemple 5 — “Mets ça sur GitHub / Notion”

Cartes :

- EXPORT_AND_DELIVERY_CARD.

Sortie : chemin, fichier, commit, statut, prochaine action.

---

# ✅ 9. Garde-fous anti-surcharge

L’Orchestrator doit éviter :

- activer toutes les cartes ;
- faire un audit inutile ;
- produire une route trop longue ;
- ajouter des cartes non demandées ;
- transformer une demande simple en architecture ;
- multiplier les variantes ;
- oublier la destination finale ;
- faire une réponse bavarde quand une action suffit.

Question de contrôle :

Quelle est la plus petite combinaison de cartes capable de produire un bon résultat ?

---

# 🧠 10. Algorithme d’orchestration

1. Identifier la demande.
2. Classer la demande : conte, image, animation, Pack+, correction, export, architecture.
3. Choisir la carte dominante.
4. Ajouter une carte de contraste seulement si nécessaire.
5. Ajouter une carte opératrice.
6. Ajouter style, motion, voix ou son seulement si la sortie le demande.
7. Ajouter Quality Control si production ou correction.
8. Ajouter Export si livraison réelle.
9. Produire la sortie.
10. S’arrêter.

---

# 🧬 11. Block LLM

```text
Active MEMORY_CARDS_ORCHESTRATOR_CARD.

Utilise cette carte pour choisir les Memory Cards utiles à une demande précise, sans surcharge.

Règle centrale :
ne charge jamais toutes les cartes par réflexe.
Choisis la route la plus courte capable de produire une bonne sortie.

Procédure :
1. identifier le type de demande : conte, image, animation, Pack+, correction, export, architecture ;
2. choisir une carte dominante ;
3. choisir une carte de contraste si nécessaire ;
4. choisir une carte opératrice ;
5. ajouter les cartes production uniquement si la sortie les demande ;
6. ajouter QUALITY_CONTROL_CARD si la sortie doit être validée ;
7. ajouter EXPORT_AND_DELIVERY_CARD si la sortie doit être livrée ;
8. produire ;
9. s’arrêter.

Rôles possibles :
- dominante ;
- contraste ;
- opératrice ;
- émotion ;
- style ;
- motion ;
- voix ;
- son ;
- contrôle ;
- export.

Routes rapides :
- Conte enfant : CHILDREN_STORY_THEMES_CARD → HERO_ARCHETYPES_CARD → EMOTIONAL_ARCS_CARD → STORY_ENGINE_CARD.
- Image : SCENES_AND_KEYFRAMES_CARD → VISUAL_STYLE_DNA_CARD → QUALITY_CONTROL_CARD.
- Animation : SCENES_AND_KEYFRAMES_CARD → VISUAL_STYLE_DNA_CARD → MOTION_AND_CAMERA_CARD → QUALITY_CONTROL_CARD.
- Pack+ : COMBINATIONS → STORY_ENGINE_CARD → PACK_PLUS_BUILDER_CARD → QUALITY_CONTROL_CARD.
- Livraison : EXPORT_AND_DELIVERY_CARD.
- Correction : QUALITY_CONTROL_CARD d’abord.

Toujours éviter :
- surcharge ;
- audit inutile ;
- routes trop longues ;
- cartes non pertinentes ;
- collage de cartes ;
- production sans destination ;
- livraison sans validation quand la sortie est sensible.

Forme de réponse recommandée si l’utilisateur demande “quelle carte ?” :
1. carte recommandée ;
2. rôle ;
3. pourquoi maintenant ;
4. fichier ;
5. commit recommandé.

Forme de réponse recommandée si l’utilisateur dit “vas-y” :
créer ou modifier directement la carte demandée, puis donner fichier, commit et SHA.
```

---

# 🕯️ 12. Formule courte

Un bon système n’utilise pas toutes ses forces à chaque fois.

Il choisit la bonne force au bon moment.
