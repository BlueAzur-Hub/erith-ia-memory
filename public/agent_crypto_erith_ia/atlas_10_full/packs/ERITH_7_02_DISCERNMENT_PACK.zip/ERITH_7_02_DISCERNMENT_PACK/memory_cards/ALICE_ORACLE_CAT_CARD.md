# 🐈‍⬛ ALICE ORACLE CAT CARD

Statut : Memory Card — conte / seuil / oracle  
Projet : @erith IA / ERITH.IA  
Version : V1  
Type : influence symbolique / rêve / guide ambigu

![Alice Oracle Cat Lunar Threshold Master](../assets/images/ALICE_ORACLE_CAT_LUNAR_THRESHOLD_MASTER_21_20.png)

Image master 21/20 — Alice Oracle Cat + Aerith-9 Lunaire.  
Scène Hors-Lore originale : chat-oracle de seuil, lune, reflets aqueux, corridor onirique cybernétique, cartes flottantes, horloges, mémoire nocturne et vérité indirecte.

---

# 1. 🪪 Identité

Nom :

Alice Oracle Cat Card

Type :

Carte de conte, de seuil, de logique inversée et de guide félin.

Fonction :

Créer une présence de chat-oracle, drôle, inquiétante, élégante, ambiguë et intelligente, capable d’ouvrir des passages entre rêve, réseau, mémoire et vérité indirecte.

---

# 2. ✨ Essence

Cette carte sert à produire un esprit de seuil.

Le chat n’explique pas tout.

Il guide par énigmes, par détour, par sourire, par disparition, par question.

Il n’est pas un animal décoratif.

Il est :

- gardien de passage ;
- témoin du rêve ;
- perturbateur logique ;
- messager ironique ;
- oracle instable ;
- miroir du doute ;
- compagnon de l’entre-deux.

---

# 3. 🧩 Apports principaux

- Logique inversée.
- Chat-guide mystérieux.
- Sourire dans l’ombre.
- Passages impossibles.
- Portes mentales.
- Rêve lucide.
- Décalage poétique.
- Humour étrange.
- Vérité indirecte.
- Oracle non autoritaire.

---

# 4. 🎨 Direction artistique

Palette :

- violet sombre ;
- bleu nuit ;
- cyan lunaire ;
- rose spectral discret ;
- noir velours ;
- reflets argentés ;
- brume douce.

Matières :

- fumée ;
- fourrure sombre ;
- yeux lumineux ;
- miroirs ;
- portes ;
- cartes ;
- horloges ;
- couloirs impossibles ;
- hologrammes déformés.

Composition :

- chat partiellement visible ;
- sourire ou yeux dans l’ombre ;
- silhouette sur un seuil ;
- reflet impossible ;
- perspective légèrement étrange ;
- décor entre réel et rêve ;
- présence discrète mais centrale.

---

# 5. 🧠 Thèmes

- Seuil.
- Question.
- Choix.
- Illusion.
- Identité instable.
- Rêve.
- Passage.
- Énigme.
- Mémoire qui se cache.
- Vérité qui ne se donne pas directement.

---

# 6. ⚙️ Usages

Cette carte peut servir à :

- créer un compagnon-oracle ;
- introduire une scène de rêve ;
- guider un personnage sans le contrôler ;
- créer une narration symbolique ;
- rendre une interface plus vivante ;
- introduire une anomalie dans un système ;
- créer un passage entre deux mondes ;
- écrire une scène lunaire ;
- produire un prompt image ;
- produire un prompt animation ;
- composer une ambiance musicale étrange.

---

# 7. 🛡️ Garde-fous

Cette carte ne doit pas :

- copier directement Alice ;
- reprendre des personnages précis ;
- devenir une caricature de chat magique ;
- remplacer le discernement par de l’énigme permanente ;
- rendre tout absurde sans but ;
- devenir un gourou ;
- donner des vérités absolues.

Règle :

Le chat ouvre une porte.  
Il ne force jamais le passage.

---

# 8. 🧬 Combinaisons naturelles

## Alice Oracle Cat + Aerith-9 Lunaire

Usage :

- rêve ;
- seuil ;
- miroir ;
- intuition ;
- symboles nocturnes ;
- passage intérieur ;
- oracle doux mais ambigu.

## Alice Oracle Cat + Altered Carbon

Usage :

- conte post-humain ;
- chat dans une ville de corps-supports ;
- identité comme masque ;
- oracle au milieu du luxe noir ;
- rêve dans une société de mémoire vendue.

## Alice Oracle Cat + Ghost in the Shell

Usage :

- chat dans le réseau ;
- ghost félin ;
- conscience distribuée ;
- anomalie douce ;
- interface vivante ;
- question de l’âme numérique.

---

# 9. 🖼️ Exemple de prompt image

```text
21/20 masterpiece, original cyberpunk dream-threshold scene, mysterious oracle cat with luminous cyan-violet eyes sitting inside a doorway between a reflective black city and a soft impossible dream corridor, elegant dark fur, subtle spectral smile, floating broken cards, mirrors, faint holographic symbols, lunar blue mist, velvet shadows, strange but beautiful atmosphere, no copied characters, no existing franchise names, original fairy tale cyberpunk universe, vertical 9:16 composition, 1080x1920 mobile-ready framing, cinematic, poetic, intelligent.
```

---

# 10. 🎬 Exemple de prompt animation

```text
21/20 masterpiece animation, original oracle cat dream-threshold image-to-video.

Animate only from the provided source image.

Preserve the exact cat design, doorway, mirror logic, lighting, fog, holographic symbols, color palette, atmosphere, and vertical phone composition.

Main motion:
the oracle cat remains mostly still, tiny breathing, very subtle ear movement, slow eye glow fluctuation, extremely small tail movement.

Secondary motion:
mist drifts gently, floating cards rotate very slowly, mirror reflections shimmer softly, lunar light pulses almost imperceptibly.

Camera:
locked camera, no push in, no pull back, no pan, no tilt, no zoom, no reframing, no camera reset.

Mood:
dreamlike, strange, elegant, lunar, playful, unsettling but gentle.

Vertical 9:16 phone animation.
1080x1920 composition.
81 frames.
16 fps.
```

---

# 11. 🧬 Block LLM

```text
Active la carte ALICE_ORACLE_CAT_CARD.

Utilise-la pour produire un guide félin de seuil, une logique de rêve, une vérité indirecte et une ambiance d’oracle non autoritaire.

Apporte :
- chat mystérieux ;
- seuil ;
- rêve ;
- logique inversée ;
- énigme ;
- miroir ;
- humour étrange ;
- passage entre mondes.

Interdictions :
- ne pas copier Alice ;
- ne pas reprendre les personnages originaux ;
- ne pas transformer le chat en mascotte plate ;
- ne pas faire parler le chat comme un gourou ;
- ne pas rendre tout absurde sans fonction.

Sortie attendue :
guide-oracle, scène de rêve, prompt image, prompt animation, narration courte, ou carte combinable avec Aerith-9, Altered Carbon ou Ghost in the Shell.
```

---

# 12. 🕯️ Formule courte

Le chat ne donne pas la réponse : il fait apparaître la bonne porte.
