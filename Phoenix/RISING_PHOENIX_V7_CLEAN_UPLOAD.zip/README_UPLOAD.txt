RISING PHOENIX V7 CLEAN — UPLOAD PACK
=====================================

Purpose
-------
Clean replacement of the deleted public/lego/rising-phoenix/ directory.
No image generation or image editing was performed for this pack.
All visual files are copied byte-for-byte from existing supplied sources.

Structure
---------
public/lego/rising-phoenix/
  index.html
  style.css
  script.js
  images/  (20 selected images)

Key corrections
---------------
- No images/source semantic library.
- No level-01/level-02/level-03/model-04 folder taxonomy.
- No "Compact by design" section.
- No "destination" section.
- No full-body photo is presented as Model 04.
- Model 04 uses only the confirmed two-reactor detail (DSCN4191.JPG).
- Main configuration images use wide physical views.
- Each selected image has one primary editorial role.
- Hero is eager/preloaded; all other images are lazy-loaded.

Verified source mapping
-----------------------
level01-dragon-speeder.jpg        <- DSCN4044.JPG
level02-dragon-temple.jpg         <- DSCN4136.JPG
level03-rising-phoenix-outdoor.jpg<- DSCN4106.JPG
level03-rising-phoenix-overhead.jpg<- DSCN4113.JPG
model04-dual-reactor.jpg          <- DSCN4191.JPG
engineering-propulsion.jpg        <- DSCN4086.JPG
engineering-front-symmetry.jpg    <- DSCN4122.JPG
engineering-head-temple.jpg       <- DSCN4182.JPG
temple-wu-lloyd.jpg               <- DSCN4148.JPG
temple-handover.jpg               <- DSCN4213.JPG
temple-accessories.jpg            <- DSCN4357.JPG
evolution-01-early-prototype.jpg  <- DSCN3584.JPG
evolution-02-early-alternative.jpg<- DSCN3619.JPG
evolution-03-rebuild.jpg          <- DSCN3701.JPG
evolution-04-lengthening.jpg      <- DSCN3743.JPG
studio-three-quarter.png          <- Golden_Dragon_Extended.Build_Version_11.png
studio-top.png                    <- Golden_Dragon_Extended_17.png
studio-cockpit.png                <- Golden_Dragon_Extended_8.png
studio-propulsion.png             <- Golden_Dragon_Extended.png
hero-rising-phoenix-garden-wide.png <- existing approved V7 hero asset

UPLOAD
------
Extract this ZIP, then upload the folder public/lego/rising-phoenix/ to the repository.
The pack contains 24 files total including this README.
