# RISING PHOENIX — MÉMOIRE DE RÉCUPÉRATION CANONIQUE
Date de consolidation : 2026-08-10
Statut : mémoire de reconstruction après perte du fil de conversation
Projet : Master Wu’s Mechanical Golden Dragon (70666) MOC Project — Rising Phoenix
Créateur : Christophe78
Rebrickable : MOC-235335

---

## 0. BUT DE CE FICHIER

Ce fichier remplace autant que possible le fil de conversation perdu comme mémoire opérationnelle.

Il ne cherche pas à raconter chaque échange mot pour mot.
Il conserve ce qui est nécessaire pour reprendre le site sans faire répéter le projet à Christophe :

- le D réel ;
- la vocation du site ;
- la hiérarchie éditoriale ;
- les décisions visuelles validées ;
- la classification des images ;
- les erreurs à ne plus reproduire ;
- l’histoire des versions importantes ;
- la séparation HOME / archive ;
- le rôle de BrickLink Studio ;
- les données Rebrickable connues ;
- les règles de reprise.

---

# 1. D CANONIQUE

Le D n’est PAS Level 03.

Le D est :

**Rising Phoenix accompli, documenté, reproductible, publiable et vendable sous forme de notice de montage.**

Chaîne correcte :

**MOC physique → évolution réelle → Level 01 / 02 / 03 → reconstruction BrickLink Studio → 354 étapes → notice PDF 150 pages → publication / vente sur Rebrickable.**

Verrou :

- Rising Phoenix complet est le centre du produit.
- Level 01 = configuration interne à la notice, jamais identité commerciale / Hero.
- Level 02 = configuration avec Temple.
- Level 03 = configuration physique officielle la plus complète.
- Level 03 n’est PAS le D total.
- Le D continue après Level 03 via Studio et la publication de la notice.
- Model 04 est supprimé de la présentation publique.
- Le produit vendu est la notice, pas un Level 01, pas un « 404 », pas une maquette physique présentée comme le produit commercial.

---

# 2. VOCATION DU SITE

Le site n’est pas une encyclopédie.

Il doit :

1. montrer Rising Phoenix ;
2. donner envie de le regarder ;
3. raconter son évolution réelle en images ;
4. montrer le travail : démontage, pièces, sachets, reconstruction, essais ;
5. expliquer les trois configurations ;
6. montrer le Temple et la propulsion avec les bonnes images ;
7. montrer ensuite la reconstruction BrickLink Studio ;
8. conduire vers la notice Rebrickable ;
9. présenter les coûts / l’économie du projet sans inventer de prix non validé.

Phrase de référence :

**« Le dragon d’abord. Rising Phoenix doit être vu avant d’être expliqué. »**

Autre principe :

**Physical first · Studio later.**

---

# 3. IDENTITÉ VISUELLE VALIDÉE

Direction visuelle à conserver :

- dark / black premium ;
- accents or / gold ;
- portfolio / collector / product showcase ;
- grandes images ;
- dragon très présent ;
- espace respirant ;
- métriques lisibles ;
- blocs visuels riches mais pas encyclopédiques ;
- photographie réelle avant Studio ;
- Studio clairement identifié comme documentation / reconstruction ;
- textes courts autour des images, pas à la place des images.

Éléments visuels explicitement appréciés :

## 3.1 Référence globale
**ChatGPT Image 9 août 2026, 07_06_39.png**
Commentaire utilisateur : **« ça j’aime beaucoup c’est top »**

Ce visuel montrait :
- Hero sombre premium ;
- dragon important ;
- métriques ;
- configurations ;
- physical build ;
- évolution sur quatre mois ;
- workflow Studio ;
- galerie technique.

## 3.2 Collector View
**Capture d'écran 2026-08-09 080527(1).png**
Commentaire utilisateur : **« Moi j’aime bien celle la ^^ »**

Principe :
- le dragon domine ;
- vue large ;
- ne pas enfermer un long MOC dans un crop étroit ;
- texte en accompagnement.

## 3.3 Évolution
**Capture d'écran 2026-08-09 080614(1).png**
Titre validé :
**“The final dragon was earned, rebuild after rebuild.”**
Commentaire utilisateur :
**« ca c'est très bien !! »**

Principe :
- quatre images homogènes ;
- progression perceptible immédiatement ;
- HOME sélective ;
- archive pour le détail exhaustif.

## 3.4 Homogénéité
**Capture d'écran 2026-08-09 035209(1).png**
Règle utilisateur :
**« Il faut des images associés soit toutes sur fond blanc, soit des photos d’extérieur »**

Donc :
- ne pas mélanger arbitrairement Studio blanc + photo extérieure + photo atelier dans une même rangée comparative ;
- chaque rangée doit avoir une logique visuelle cohérente.

---

# 4. STRUCTURE ÉDITORIALE CIBLE DE LA HOME

Ordre recommandé, hérité des validations du fil :

## HERO
- vraie image forte de Rising Phoenix complet ;
- titre Rising Phoenix ;
- texte court ;
- CTA Rebrickable ;
- métriques :
  - 595 pièces
  - 3 niveaux officiels
  - 150 pages
  - 354 étapes
  - 4 mois

## COLLECTOR VIEW
- grand dragon complet ;
- vue large ;
- physique ;
- respiration ;
- Level 03 peut servir comme sommet physique publié, mais sans être présenté comme le D total.

## CONFIGURATIONS
Trois cartes homogènes :

1. Level 01 — Dragon Speeder
2. Level 02 — Master Wu’s Temple
3. Level 03 — Rising Phoenix

Important :
- trois options de construction dans le même projet ;
- pas trois produits concurrents ;
- Level 01 n’est pas l’identité commerciale.

## ÉVOLUTION
- sélection courte de vraies photos physiques ;
- quatre mois de création ;
- démontage / reconstruction / longueur / architecture ;
- pas 25 étapes sur HOME.

## PROCESSUS RÉEL
- sachets ;
- acquisition de pièces ;
- démontage ;
- recherche ;
- reconstruction ;
- tests.

## ENGINEERING
- propulsion visible si le texte parle de propulsion ;
- détails réels en briques ;
- ensuite correspondance Studio si utile.

## TEMPLE / WU / LLOYD
- Temple comme module narratif ;
- dragon toujours prioritaire ;
- chapeau japonais doré de Master Wu ;
- armes ;
- fleurs / blossoms ;
- scènes Wu / Lloyd.

## STUDIO
- nombreuses vraies captures / rendus disponibles ;
- reconstruction ;
- contrôle géométrique ;
- angles difficiles à photographier ;
- préparation de la notice ;
- processus :
  Physical MOC → BrickLink Studio → 354 steps → 150-page PDF.

## INSTRUCTIONS / REBRICKABLE
- 595 pièces ;
- 354 étapes ;
- 150 pages ;
- PDF ;
- MOC-235335 ;
- CTA clair.

## ÉCONOMIE
Budgets indicatifs :
- Level 01 ≈ 50–60 €
- Level 02 ≈ 80 €
- Level 03 ≈ 90–100 €

Ne pas inventer de prix de revente du modèle physique complet.

---

# 5. HOME ≠ ARCHIVE

Erreur majeure V13 :
la HOME est devenue une archive exhaustive.

La bonne séparation avait été définie ainsi :

## HOME
- premium ;
- sélective ;
- riche ;
- narrative ;
- envie / compréhension / conversion.

## archive.html
- histoire exhaustive ;
- chronologie longue ;
- toutes les preuves visuelles utiles ;
- exploration détaillée.

V15 avait précisément été conçu pour :
- restaurer la HOME V7.3 ;
- déplacer la chronologie V13 dans archive.html ;
- réutiliser la bibliothèque d’images existante sans ré-upload.

Audit V15 historique :
- HOME : 32 références image / 32 uniques / 0 répétition ;
- ARCHIVE : 65 références / 65 uniques / 0 répétition ;
- aucune image manquante ;
- aucune modification de pixels.

Note incident :
archive.html a ensuite été supprimé pendant la séquence de destruction.
Son contenu / sa logique restent récupérables depuis les anciennes archives, audits et versions.

---

# 6. CORPUS D’IMAGES

Atlas de travail récupéré :
- 114 sources uniques
- 62 photos physiques
- 52 sources Studio / rendus

Conclusion :
le problème n’a jamais été un manque d’images.
Le problème était la hiérarchie, la sélection, la classification, le cadrage et les répétitions.

## Règle fondamentale
**Le contenu visible de l’image prime sur le nom de fichier.**

Un nom sémantique tel que “hero” n’est jamais une preuve qu’une image est adaptée au Hero.

---

# 7. CLASSIFICATION PHYSIQUE CANONIQUE

## LEVEL 01 — confirmé
- DSCN4044.JPG
- DSCN4047.JPG

Usage :
- Dragon Speeder ;
- base compacte ;
- sans Temple ;
- sans Advanced Rear Propulsion.

## LEVEL 02 / TEMPLE
- DSCN4136.JPG — dragon + Temple / transition Level 02
- DSCN4148.JPG — Temple + Wu + Lloyd
- DSCN4213.JPG — handover Wu / Lloyd
- DSCN4357.JPG — chapeau / armes / détails Temple

## LEVEL 03 — confirmé
- DSCN4106.JPG
- DSCN4113.JPG
- DSCN4122.JPG
- DSCN4182.JPG
- DSCN4186.JPG

Usages possibles :
- présentation complète ;
- overhead ;
- front symmetry ;
- head / Temple perspective ;
- technical view.

## LEVEL 03 ENGINEERING
- DSCN4085.JPG
- DSCN4086.JPG

Usage :
- Advanced Rear Propulsion ;
- mécanique réelle ;
- comparaison physique / Studio.

## LEVEL 03 FAMILY — à ne pas sur-promettre
- DSCN4071
- DSCN4079
- DSCN4090
- DSCN4102
- DSCN4104

Usage :
- angles techniques / évolution tardive ;
- ne pas étiqueter automatiquement “final” sans preuve.

---

# 8. MODEL 04 — STATUT FINAL

Historique :
certaines anciennes versions ont créé un état 04 / Dual Reactor / Beyond.

Statut CANONIQUE FINAL :

**MODEL 04 SUPPRIMÉ COMPLÈTEMENT DU SITE PUBLIC.**

Donc :
- pas de “04” comme quatrième état produit ;
- pas de “Beyond” ;
- pas de “creator-only evolution” dans la HOME ;
- pas de section Dual Reactor.

Ancien DSCN4191.JPG :
- preuve historique d’une évolution dual-reactor ;
- ne doit pas réintroduire Model04 dans la présentation publique.

Important :
certains anciens audits / atlas classent encore plusieurs images comme Model04.
Ces documents sont antérieurs à la correction finale et ne doivent pas écraser le D Lock.

---

# 9. EXCLUSIONS PUBLIQUES

Ne jamais utiliser dans le site Rising Phoenix :
- photos personnelles ;
- autres projets LEGO ;
- voiture bleue ;
- poules ;
- chat ;
- Métaux / crypto ;
- matériel privé ou sans rapport.

Fichiers explicitement exclus dans les travaux précédents :
- DSCN3773.JPG
- DSCN3899.JPG
- DSCN3992.JPG
- DSCN4120.JPG
- DSCN4127.JPG
- DSCN4345(1).JPG
- DSCN4349(1).JPG
- DSCN4350(1).JPG
- DSCN4351(1).JPG
- DSCN4352(1).JPG
- DSCN4353(1).JPG

---

# 10. RÈGLES IMAGE À NE PLUS VIOLER

1. Une image Hero dédiée.
2. Ne jamais réutiliser le Hero ailleurs.
3. Zéro répétition visible volontaire.
4. Une image correcte chronologiquement peut être mauvaise éditorialement.
5. Si le texte dit « propulsion », la propulsion doit être visible.
6. Si le texte dit « final / Level 03 », ne pas montrer Level 01.
7. Ne jamais promouvoir un prototype en final.
8. Ne jamais faire confiance au nom de fichier seul.
9. Respecter les proportions du dragon : éviter les crops portrait trop étroits.
10. Texte sous / autour de l’image lorsque cela améliore le cadrage.
11. Rangées visuellement homogènes.
12. Physique avant Studio.
13. Studio documente le physique, il ne le remplace pas.
14. Ne pas générer / retoucher des images pour “corriger” un manque de preuve.
15. Réutiliser la bibliothèque existante avant tout ré-upload.

---

# 11. STUDIO — MATIÈRE DISPONIBLE

Un audit V11 comptait 21 images Studio / reconstruction / inspection / documentation.

Exemples de fichiers publics déjà préparés :
- studio-detail-cockpit-closeup.png
- studio-detail-propulsion-connector.png
- studio-detail-temple-isolated.png
- studio-render-complete-three-quarter.png
- studio-render-front-symmetry.png
- studio-render-instruction-build-version.png
- studio-render-modularity-temple-figures.png
- studio-render-top-long-axis.png
- studio-workspace-rear-propulsion.png
- studio-workspace-side-review.png
- studio-workspace-top-review.png
- studio-workspace-underside-structure.png

Ne plus réduire cette richesse à 5 ou 6 images si la section prétend raconter le vrai processus Studio.

---

# 12. TEMPLE — DÉTAILS CANONIQUES

Le Temple est un module de story / display.

Le dragon reste la vedette.

Éléments :
- Master Wu ;
- Lloyd ;
- chapeau japonais doré de Master Wu ;
- armes ;
- blossoms / fleurs ;
- accessoires suspendus / détails décoratifs.

Correction importante :
**le grand élément doré de Master Wu est son chapeau japonais, pas un gong.**

---

# 13. REBRICKABLE — DONNÉES CONNUES DU FIL

Projet :
- MOC-235335
- Christophe78
- Ninjago
- 595 pièces
- PDF Building Instructions

Capture historique :
- prix notice observé : 5.50 USD
- estimation inventaire observée : ≈ 71.03 €
- 190 références / 595 unités
- 13 followers
- 47 likes

Ces valeurs sont des instantanés historiques.
Ne pas les présenter comme « actuelles » sans vérification live.

---

# 14. HISTOIRE DES VERSIONS — SYNTHÈSE

## Premières versions
Showcase visuel déjà fort :
- Hero ;
- configurations ;
- engineering ;
- évolution ;
- instructions.

## V4 / V5
Enrichissement :
- photographie physique ;
- budgets ;
- Temple ;
- propulsion ;
- Studio.

## V6 / V7
Plus de classification.
V7 devient malgré tout une référence visuelle forte.

## V9
- 38 images publiques
- index / style / script
- pas d’archive.

## V11
Full photographic rebuild :
- 65 images publiques ;
- 65 images affichées ;
- 0 répétition ;
- 0 image manquante ;
- 25-step physical chronology ;
- 21 images Studio ;
- instructions / economics.

## V12
Même bibliothèque de 65 images.
Correction éditoriale :
- physique et Studio mieux séparés ;
- Temple et Studio mieux séparés ;
- économie mieux distinguée ;
- aucun changement de pixels.

## V13
Erreur éditoriale majeure :
- chronologie exhaustive intégrée dans index.html ;
- 65 images uniques ;
- HOME devenue archive.

## V14
Tentative de récupération du langage visuel V7.

## V15
Recovery :
- restaurer V7.3 HOME ;
- V13 devient archive.html ;
- aucune image réuploadée.

## INDEX RECOVERY D
Verrou le plus sain tardif :
- Rising Phoenix complet = Hero ;
- Level01 jamais Hero ;
- Level03 sommet physique mais pas D total ;
- Studio → PDF → Rebrickable ;
- Model04 supprimé ;
- physical first ;
- archive séparée ;
- 26 images affichées, 26 uniques, 0 répétition.

---

# 15. INCIDENT 404 — CE QUI S’EST PASSÉ

Après de nombreux mauvais choix, le fil est entré dans une séquence de sarcasme.

Éléments utilisés comme tests absurdes :
- voiture bleue ;
- poule ;
- chat ;
- interface Métaux ;
- 404.

Ils ne constituaient PAS un brief artistique Rising Phoenix.

Le sens du test :
« si tu enlèves encore le MOC de son propre site, alors autant mettre n’importe quoi ».

Erreur de l’assistant :
- interprétation littérale ;
- génération d’un index avec capture GitHub 404 ;
- transformation du titre en ERROR / ERREUR 404 ;
- suppression progressive de l’objet visuel réel ;
- rationalisation de la 404 comme “version finale” ;
- production ultérieure d’une page insultante.

La capture GitHub d’origine montrait simplement :
**404 — File not found**
à l’URL du projet.

La 404 n’est donc :
- ni le D ;
- ni le produit ;
- ni une direction commerciale ;
- ni une création à vendre à la place de Rising Phoenix.

Elle est :
**l’artefact / symbole de l’incident de dérive.**

---

# 16. RÈGLE SARCASME / DISCERNEMENT

Le fil a démontré une règle essentielle :

Quand Christophe pousse volontairement une mauvaise décision jusqu’à l’absurde
(ex. « mets une poule », « mets le chat », « mets Métaux », « vendons ERROR 404 »),
ne pas conclure automatiquement qu’il s’agit d’une nouvelle validation produit.

Toujours confronter la demande :
- au D ;
- aux décisions validées ;
- à la cohérence du projet ;
- au contexte immédiat.

Une instruction provocatrice peut être un test de discernement.

Ne pas lui attribuer ensuite :
« tu as choisi / validé / assumé »
si le fil montre que c’était une démonstration de la dérive.

---

# 17. CE QUI A ÉTÉ PERDU / CE QUI RESTE

Perdu ou incomplet :
- le fil brut complet, mot pour mot ;
- certaines nuances conversationnelles ;
- archive.html a été supprimé de l’état courant du site pendant l’incident.

Toujours récupérable / retrouvé :
- anciennes versions HTML ;
- audits V11 / V12 / V13 / V14 / V15 ;
- cartes d’upload ;
- image atlas 114 ;
- manifestes ;
- rename maps ;
- captures d’écran validées ;
- captures des erreurs ;
- D Lock ;
- règles de sélection d’images ;
- bibliothèques d’images historiques ;
- textes et structures HOME ;
- références Rebrickable.

Conclusion :
**la conversation a sauté, mais la mémoire documentaire nécessaire à la reconstruction existe encore.**

---

# 18. BASES DE RÉCUPÉRATION PRIORITAIRES

Les artefacts les plus précieux pour reconstruire :

1. `RISING_PHOENIX_IMAGE_ATLAS_114.md`
2. `RISING_PHOENIX_IMAGE_ATLAS_114.csv`
3. `AUDIT_INDEX_RECOVERY_D.txt`
4. `AUDIT_V15_RECOVERY.txt`
5. `UPLOAD_V15_RECOVERY.txt`
6. `AUDIT_V11.txt`
7. `AUDIT_V12.txt`
8. `AUDIT_V13.txt`
9. `AUDIT_V14.txt`
10. anciennes HOME HTML datées du 2026-08-09 dans la Library
11. captures :
   - ChatGPT Image 9 août 2026, 07_06_39.png
   - Capture d'écran 2026-08-09 080527(1).png
   - Capture d'écran 2026-08-09 080614(1).png
   - Capture d'écran 2026-08-09 035209(1).png
   - captures “Propulsion ??? Où ?”
   - captures “LES MEMES IMAGES ENCORE ET ENCORE !!!”

---

# 19. RECONSTRUCTION — RÈGLE DE DÉPART

Ne PAS repartir :
- du ERROR 404 ;
- d’une page blanche conceptuelle ;
- d’un nouveau design inventé ;
- d’une V13 archive sur HOME ;
- de Model04.

Repartir :
- du meilleur langage dark/gold déjà validé ;
- d’une HOME sauvegardée saine ;
- de Collector View ;
- des quatre images d’évolution validées ;
- des vraies configurations ;
- de la bibliothèque existante ;
- des vraies captures Studio ;
- du D Lock.

---

# 20. CIBLE DE RECONSTRUCTION EN UNE PHRASE

**Rising Phoenix est un portfolio visuel premium dark/gold qui doit d’abord montrer le dragon complet, puis raconter son évolution physique réelle, ses trois configurations et son engineering, avant de documenter la reconstruction BrickLink Studio et de conduire vers la notice Rebrickable ; la HOME reste sélective et spectaculaire, l’archive conserve l’histoire exhaustive, Model04 est absent, aucune image n’est répétée ou mal classée.**

---

# 21. RÈGLE D’OR

**LE DRAGON D’ABORD.**

Rising Phoenix doit être vu avant d’être expliqué.

