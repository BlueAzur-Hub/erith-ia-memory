RISING PHOENIX — PREMIUM PAGE V1

Files
-----
index.html   Main semantic page
style.css    Human-readable responsive styling
script.js    Small progressive-enhancement layer (menu, reveal, lightbox)
images/      Selected images supplied by Christophe

Deployment
----------
Upload the whole folder while preserving its relative structure.
The page uses no framework, no CDN and no external font.

Suggested GitHub Pages location
-------------------------------
public/lego/rising-phoenix/

The Rebrickable CTA currently points to:
MOC-235335 — Master Wu's Mechanical Golden Dragon (70666) MOC Project: Rising Phoenix

Selected image roles
--------------------
hero-rising-phoenix.png   Main hero render
config-base.png           Base configuration
config-temple.png         Temple configuration
config-extended.png       Extended configuration

detail-cockpit.png        Cockpit detail
detail-propulsion.png     Propulsion connector detail
detail-top.png            Top / long-axis architecture

real-build-hero.jpg       Physical build / outdoor display
real-build-engine.jpg     Physical propulsion detail
real-build-temple.jpg     Physical temple detail

evolution-original.jpg   Early physical model
evolution-parts.jpg      Parts during rebuild
evolution-midbuild.jpg   Intermediate architecture
evolution-final.jpg      Final physical form

Notes
-----
- No price is hard-coded in the page.
- No private information is embedded.
- LEGO and NINJAGO trademark disclaimer is included in the footer.
- Images were copied from the files supplied in the conversation; originals were not modified.
