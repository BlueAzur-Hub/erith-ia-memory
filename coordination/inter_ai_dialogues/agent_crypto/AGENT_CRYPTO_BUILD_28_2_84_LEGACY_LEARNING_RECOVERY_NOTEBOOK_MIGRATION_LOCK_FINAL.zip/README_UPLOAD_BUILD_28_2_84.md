# Upload Build 28.2.84

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

## Après publication

1. Utiliser **le même Firefox et le même profil navigateur** que pour les leçons 28.2.81/82. Les données sont locales à ce profil.
2. Recharger complètement la page.
3. Vérifier l’affichage de **Build 28.2.84**.
4. Dans le Cockpit, repérer **Mémoire pédagogique ancienne détectée**.
5. Cliquer sur **Voir avant import**.
6. Contrôler le module, le nombre de sessions, les étapes et la longueur du texte retrouvé.
7. Cliquer sur **Importer dans mon carnet**.
8. Vérifier ensuite :
   - progression ancienne restaurée ;
   - brouillon ancien dans **Mes notes libres** ;
   - conclusion personnelle laissée vide lorsqu’elle ne peut pas être distinguée honnêtement ;
   - ancienne position BTC fictive toujours présente ;
   - preuves de simulation toujours présentes.
9. Actualiser la page et vérifier qu’aucun doublon n’apparaît.

## Important

L’ancien format limitait le commentaire à 800 caractères. Le Build importe tout ce qui est encore stocké, mais les caractères déjà supprimés par l’ancien format ne peuvent pas être recréés automatiquement.

Le bouton **Ignorer sans supprimer** ne détruit rien. La récupération peut être rouverte plus tard avec **Voir la récupération**.

## SHA-256 des quatre fichiers

```text
app.js       e95c26313b7342c5f32ce839ebf7ce63a53e03d918c94ac79af7ddb705750a2c
index.html   04d2ef76bc4280dfe3d976c2fda7e308836a063ad782a97a9e86691debbcb685
style.css    ae57ab8b2b4a9b9b2d4692e4f051e84c4c499bec644f12ec84cdbb9624817812
version.json 26159039116bf4d6418585c2789ae0d28eaf62e44bc70fe07f4e3fc34be56907
```
