SEVEN HEAVEN R11.2
Pilote de sauvegarde persistante des partitions scellees

Livraison du script, workflow, documentation. Ne modifie ni R10 ni le Coffre.
Le run GitHub CI et le commit de publication sont les preuves de sauvegarde.
