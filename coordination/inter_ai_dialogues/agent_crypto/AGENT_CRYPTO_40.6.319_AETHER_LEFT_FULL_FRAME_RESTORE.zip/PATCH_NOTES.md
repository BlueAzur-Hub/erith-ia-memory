# Agent-Crypto 40.6.319 — Aether left full-frame restore

Functional commit: 7b7b6fb2971374797e66df9b194458643ce78794

Purpose:
- Remove the failed 40.6.318 inner-stage 1450px override.
- Restore the complete 1672/941 Observatory fitted to the actual Aether window.
- Preserve the existing left-positioned Aether outer geometry.
- Do not touch app.js, Window Manager, Lecture Technique, Market Core, Oracle, Strategy or Storage.

Terrain target:
- Firefox normal mode: full Aether visible, no crop/zoom, left side.
- Firefox F11: separate browser fullscreen behavior.
