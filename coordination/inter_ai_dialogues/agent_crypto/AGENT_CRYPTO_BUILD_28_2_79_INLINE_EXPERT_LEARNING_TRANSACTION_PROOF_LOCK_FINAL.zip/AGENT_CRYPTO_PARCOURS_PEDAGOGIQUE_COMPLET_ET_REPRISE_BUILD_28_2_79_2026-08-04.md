# AGENT-CRYPTO — Parcours pédagogique complet et point de reprise

**Date :** 4 août 2026  
**Base publique stable :** Build 28.2.78  
**Objet :** réunir les notions étudiées, les observations faites sur l’interface, les améliorations envisagées et le point exact de reprise.

## 1. Règles de continuité

- Le Build 28.2.78 reste la base stable.
- Aucune suppression, aucune réduction et aucun remplacement destructif.
- Toute amélioration future doit être additive, compatible avec l’existant et réversible.
- Aucun argent réel, aucun ordre réel, aucun retrait réel et aucune connexion Kraken pendant la phase pédagogique.
- Les frais, taux, seuils fiscaux, statuts réglementaires et procédures de plateforme doivent être vérifiés sur les sources officielles au moment de l’usage.
- Les explications doivent distinguer les définitions stables, les données actuelles, les hypothèses pédagogiques, les observations réelles et les fonctions non encore implémentées.

## 2. Simulation réellement observée dans le Build 28.2.78

### Achat fictif

- Capital initial : 100,00 €
- Achat simulé : BTC pour 5,00 €
- Capital restant : 95,00 €
- Valeur de la position : environ 5,00 €
- Quantité observée : environ 0,00009057 BTC
- Exposition : 5,00 € sur un plafond de 30,00 €
- P/L immédiat : proche de 0,00 €
- Journal : `ACHAT SIMULÉ · BTC pour 5,00 €`

### Vente fictive

- Vente simulée BTC : 5,00 €
- Position ensuite fermée
- Portefeuille virtuel : aucune position simulée
- Journal : `VENTE SIMULÉE · Vente simulée BTC pour 5,00 €`

### Limites constatées

Le simulateur affiche le capital, les positions, le total, le P/L, la quantité, la valeur actuelle, l’exposition et le journal. Il n’affiche pas encore clairement le prix d’entrée et de sortie, les frais, le spread, le slippage, le prix d’équilibre, le P/L brut et net séparés, le résultat réalisé détaillé, la durée de détention et la fraîcheur du prix utilisé.

## 3. Notions pédagogiques étudiées

### Lire le marché

- Prix actuel : valeur observée à un instant donné.
- Variation 24 h / 7 j : évolution entre deux bornes temporelles.
- Volume : valeur totale des échanges sur une période.
- Capitalisation : prix multiplié par les unités en circulation.
- Deux sources peuvent diverger sans qu’une soit nécessairement fausse : marché, heure, méthode et fréquence peuvent différer.

### Risque historique

- Volatilité : amplitude des mouvements.
- Drawdown : baisse entre un sommet et le creux suivant.
- VaR : estimation historique d’une perte ordinaire à un niveau de confiance donné ; elle ne décrit pas le pire scénario.

### Volume, liquidité, spread et slippage

- Volume élevé = beaucoup d’échanges, pas une hausse certaine.
- Liquidité = facilité d’acheter ou vendre sans trop déplacer le prix.
- Bid = meilleur prix acheteur.
- Ask = meilleur prix vendeur.
- Spread = écart bid/ask.
- Slippage = différence entre prix attendu et prix moyen exécuté.

### Ordres

- Ordre marché : exécution prioritaire, prix exact non garanti.
- Ordre limite : prix contrôlé, exécution non garantie.
- Stop-loss : sortie au marché, slippage possible.
- Stop-limit : prix minimal contrôlé, sortie non garantie.
- Take-profit : objectif de sortie favorable.
- OCO : l’exécution d’une sortie annule l’autre.

### Frais et seuil de rentabilité

Le coût complet peut inclure frais d’achat, frais de vente, spread, slippage, dépôt, conversion et retrait.

Approximation pédagogique :

`seuil de rentabilité ≈ frais achat + frais vente + spread + slippage`

Une hausse visible ne constitue pas encore un bénéfice tant que tous les coûts ne sont pas couverts.

### Taille de position et exposition

- Taille de position : somme exposée.
- Risque en euros = taille de position × baisse envisagée.
- Allocation : répartition du capital.
- Réserve : argent non exposé.
- Concentration : poids important d’un seul actif.

### Résultat latent, résultat réalisé et prix moyen

- Perte latente : actif encore détenu sous le coût d’achat.
- Perte réalisée : actif vendu sous le coût d’achat.
- Prix moyen réel = coût total payé / quantité totale détenue.
- DCA : calendrier régulier décidé à l’avance.
- Moyenner à la baisse : ajouter du capital après une baisse, ce qui augmente aussi l’exposition.

### Rendement, risque et séries de pertes

- Rapport rendement/risque = gain potentiel / perte potentielle.
- Espérance = probabilité de gain × gain moyen − probabilité de perte × perte moyenne − coûts.
- Un taux de réussite élevé peut rester déficitaire.
- Une perte de 20 % exige une hausse de 25 % pour revenir à l’équilibre.
- Une perte de 50 % exige une hausse de 100 %.

## 4. Retraits, réseaux et portefeuilles

### Anatomie d’un retrait

Un retrait comporte au minimum :

1. actif ;
2. réseau ;
3. adresse de destination ;
4. montant ;
5. frais ;
6. montant net estimé ;
7. statut et TXID.

La vérification doit porter simultanément sur le bon actif, le bon réseau, la bonne adresse, la bonne destination, les frais et les minimums.

### Petit retrait test

1. Vérifier actif, réseau et adresse.
2. Envoyer une petite quantité supérieure au minimum et aux frais.
3. Attendre la réception complète.
4. Vérifier TXID, confirmations et montant net.
5. Revérifier avant tout transfert suivant.

### Problèmes réseau

- Mauvais réseau : risque majeur de perte ou récupération difficile.
- Réseau correct mais lent : confirmations en attente.
- Blocage interne de plateforme : transaction pas encore diffusée ou retenue.
- Pas de TXID : probablement encore côté plateforme.
- TXID présent : transaction diffusée.
- Confirmations suffisantes mais solde absent : vérifier la destination.

### Plateforme et portefeuille personnel

- Plateforme : négociation et conservation par le prestataire.
- Portefeuille personnel : contrôle des clés par l’utilisateur.
- Plus de contrôle signifie plus de responsabilité.

## 5. Sécurité du compte

### Couches minimales

- email sécurisé ;
- mot de passe unique ;
- gestionnaire de mots de passe ;
- passkey ou application d’authentification ;
- 2FA de connexion ;
- 2FA de financement/retrait ;
- protection du trading ;
- verrouillage global des paramètres lorsque la configuration est terminée.

### GSL Kraken

Le verrouillage global des paramètres peut empêcher les modifications sensibles, masquer des informations et imposer un délai de déverrouillage. Il complète la 2FA et aide à empêcher l’ajout ou la modification d’adresses de retrait après compromission.

La clé maîtresse Kraken et la phrase de récupération d’un portefeuille sont deux notions différentes.

### Phishing et faux support

- Ne jamais communiquer mot de passe, codes 2FA ou phrase de récupération.
- Utiliser uniquement les canaux officiels.
- Éviter les liens reçus par message.
- Conserver l’adresse officielle en favori.
- Un support officiel ne demande pas la phrase secrète du portefeuille.

### Blocages de sécurité

Un premier achat instantané ou certaines méthodes de dépôt peuvent entraîner un blocage temporaire de retrait. Cela ne signifie pas nécessairement une panne ou une perte.

### Réaction en cas de doute

- arrêter toute transaction ;
- sécuriser d’abord l’email ;
- modifier les identifiants compromis ;
- vérifier les sessions et paramètres ;
- utiliser uniquement le support officiel ;
- ne jamais envoyer de fonds à une personne prétendant « débloquer » le compte.

## 6. Sécurité du portefeuille personnel

### Adresse publique et secret

- Adresse publique : sert à recevoir.
- Phrase de récupération / clé privée : donne le contrôle du portefeuille.
- La phrase secrète ne doit jamais être transmise à un support, une connaissance ou un site non vérifié.

### Sauvegarde

- noter exactement les mots et leur ordre ;
- conserver la sauvegarde hors ligne ;
- éviter capture d’écran, email et SMS ;
- utiliser un support physique protégé ;
- ne pas laisser la sauvegarde avec l’appareil contenant le portefeuille.

### Perte ou compromission

- Phrase perdue et plus aucun accès : actifs potentiellement irrécupérables.
- Phrase connue d’un tiers : portefeuille considéré compromis.
- Importer la même phrase ailleurs ne corrige pas la compromission.
- Les actifs restants doivent être transférés vers un nouveau portefeuille avec une nouvelle phrase, selon une procédure vérifiée.

### Portefeuille logiciel et matériel

- Logiciel : pratique mais exposé aux risques de l’appareil.
- Matériel : clés protégées par un appareil dédié, mais aucune protection contre une mauvaise adresse, un mauvais réseau, une phrase volée ou une signature mal comprise.
- Aucun appareil ne remplace la vérification humaine.

## 7. Traçabilité et fiscalité française

> Section pédagogique. Les règles doivent être revérifiées au moment de la déclaration.

### Journal à conserver dès la première opération

- date et heure ;
- plateforme ;
- actif et paire ;
- type d’ordre ;
- quantité ;
- prix ;
- montant en euros ;
- frais ;
- identifiant de l’ordre ;
- dépôt ou retrait ;
- réseau ;
- adresse ;
- TXID ;
- justificatif bancaire ;
- export CSV ou relevé ;
- capture utile de confirmation.

### Opérations et déclaration

Pour un particulier fiscalement domicilié en France :

- simple détention : non imposée ;
- vente contre euros : cession imposable potentielle ;
- achat d’un bien ou service en crypto : cession imposable potentielle ;
- échange crypto contre crypto sans soulte : sursis d’imposition ;
- échange avec soulte : traitement spécifique à vérifier.

Le seuil de 305 € porte sur la somme annuelle brute des prix de cession, pas sur le bénéfice.

Formulaires et cases :

- annexe 2086 ;
- 3AN pour une plus-value ;
- 3BN pour une moins-value ;
- 3CN pour l’option au barème progressif lorsqu’elle s’applique ;
- 3916-3916 bis pour les comptes d’actifs numériques à l’étranger.

La page impots.gouv.fr modifiée le 17 juillet 2026 indique, pour la gestion privée, un PFU de 31,4 % : 12,8 % d’impôt et 18,6 % de prélèvements sociaux. Ce taux doit être revérifié, car d’anciens documents mentionnaient 30 %.

Une activité professionnelle ou assimilée, le minage, le staking, la DeFi ou des opérations nombreuses et sophistiquées peuvent relever d’un autre traitement.

## 8. Améliorations futures de l’interface

### Règle absolue

- Conserver 100 % des sections, fonctions, scénarios, données et boutons existants.
- Aucune réduction ni suppression.
- Améliorations uniquement additives et réversibles.

### Info-bulles pédagogiques dynamiques

Chaque bulle doit inclure :

1. définition stable ;
2. valeur actuelle ;
3. lecture contextuelle déterministe ;
4. source ;
5. date et heure ;
6. âge de la donnée ;
7. donnée réelle ou hypothèse ;
8. limite d’interprétation.

Notions prioritaires : prix, variation, volume, capitalisation, liquidité, volatilité, drawdown, VaR, spread, slippage, P/L, exposition, frais, seuil de rentabilité, résultat latent/réalisé, réseau, adresse, TXID et phrase de récupération.

### Simulation enrichie

Ajouter :

- prix d’entrée et prix actuel ;
- variation depuis l’achat ;
- quantité brute et nette ;
- frais achat/vente ;
- spread et slippage estimés ;
- prix d’équilibre ;
- P/L brut et net ;
- résultat réalisé ;
- durée de détention ;
- source et fraîcheur du prix.

### Scénarios instantanés

Boutons :

`−5 % · −3 % · −1 % · prix actuel · +1 % · +3 % · +5 %`

Ils doivent recalculer valeur de position, P/L brut, coûts, P/L net, portefeuille total et explication adaptée.

### Mode École guidé

Conserver tous les exercices et ajouter état de progression, prévisualisation, règles contrôlées, motif exact des refus, comparaison avant/après, protection contre double clic et liens directs vers portefeuille et journal.

### Simulateur de retrait fictif

Prévoir actif, réseau, adresse de démonstration, montant, frais, montant net, minimum, incompatibilités, TXID fictif, confirmations et checklist finale.

### Corrections visuelles

- `DONNÉES À JOUR` → `À JOUR` ;
- verrouiller la largeur du cartouche ;
- éviter le redimensionnement de la fenêtre et le déplacement du graphique ;
- supprimer `−0,00 €` ;
- expliquer les abréviations comme P/L.

## 9. Point exact de reprise

### Terminé

- lecture de l’Observatoire ;
- prix, volume, risque, liquidité ;
- frais et seuil de rentabilité ;
- taille de position ;
- résultat latent et réalisé ;
- ordres Spot ;
- retraits, réseaux et TXID ;
- sécurité du compte et du portefeuille ;
- première boucle complète de simulation fictive ;
- principales lacunes pédagogiques du Build 28.2.78.

### Étapes suivantes

1. relire et valider ce document ;
2. vérifier qu’aucune amélioration ne manque ;
3. établir une liste finale et priorisée ;
4. décider explicitement si un nouveau Build doit être lancé ;
5. seulement ensuite modifier l’interface de manière additive ;
6. produire ZIP, rapport de vérification, hashes, chemins de remplacement et texte de commit complet.

## 10. Sources officielles

### Kraken

- https://support.kraken.com/fr/articles/360000426923-secure-your-account-with-two-factor-authentication-2fa-
- https://support.kraken.com/fr/articles/360000911763-how-does-two-factor-authentication-2fa-for-funding-deposits-withdrawals-work-
- https://support.kraken.com/fr/articles/201396877-what-is-the-global-settings-lock-gsl-
- https://support.kraken.com/fr/articles/13644055237908-how-to-prevent-unwanted-withdrawals
- https://support.kraken.com/fr/articles/backing-up-your-kraken-wallet
- https://support.kraken.com/fr/articles/create-a-wallet-on-kraken-wallet
- https://support.kraken.com/fr/articles/my-kraken-wallet-has-been-compromised
- https://support.kraken.com/fr/articles/kraken-wallet-official-support-and-communication-channels
- https://support.kraken.com/fr/articles/360000389606-why-is-there-a-withdrawal-hold-on-my-account-

### France

- https://www.impots.gouv.fr/particulier/questions/comment-declarer-les-plus-ou-moins-values-sur-cessions-dactifs-numeriques
- https://www.impots.gouv.fr/particulier/les-cessions-mobilieres
- https://www.impots.gouv.fr/formulaire/3916/declaration-par-un-resident-dun-compte-letranger-ou-dun-contrat-de-capitalisation-o
- https://bofip.impots.gouv.fr/bofip/11969-PGP.html/identifiant%3DBOI-RPPM-PVBMC-30-30-20240423
- https://www.economie.gouv.fr/particuliers/gerer-mon-argent/investissement-dans-les-cryptomonnaies-ce-quil-faut-savoir
- https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/crypto-actifs-bitcoin-etc
- https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/crypto-actifs-bitcoin-etc/investir-en-crypto-monnaies-quel-professionnel-choisir

## 11. Verdict

Le socle théorique essentiel est couvert. La prochaine étape n’est pas une nouvelle leçon : c’est la consolidation et la transformation contrôlée de ces constats en cahier des charges d’interface, sans suppression de l’existant.

---

# Complément final — notions avancées de culture crypto

## 12. Stablecoins

Un stablecoin cherche à suivre une référence, souvent le dollar ou l’euro. « Stable » ne signifie ni garanti, ni identique à un dépôt bancaire.

Risques à connaître :

- désancrage ou depeg ;
- qualité des réserves et solidité de l’émetteur ;
- liquidité ;
- gel possible de certaines adresses selon l’émetteur ;
- risque de change pour un utilisateur raisonnant en euros ;
- même nom de jeton disponible sur plusieurs réseaux ;
- faux jetons portant un symbole connu.

Règle : vérifier l’actif, l’adresse de contrat et le réseau.

## 13. Staking et produits de rendement

Le staking consiste à immobiliser ou déléguer certains jetons afin de participer au fonctionnement d’un réseau et recevoir des récompenses possibles.

Le rendement annoncé doit être corrigé par :

- la variation du prix du jeton ;
- les frais ;
- l’inflation de l’offre ;
- le délai de déblocage ;
- le risque du validateur ou de la plateforme ;
- le slashing éventuel ;
- la fiscalité applicable.

Plus de jetons ne signifie pas automatiquement davantage de valeur en euros.

## 14. Tokenomics et dilution

Éléments principaux :

- offre en circulation ;
- offre totale ;
- offre maximale ;
- capitalisation ;
- valorisation pleinement diluée ou FDV ;
- calendrier de vesting ;
- token unlocks ;
- inflation ;
- burn ;
- répartition entre équipe, investisseurs, trésorerie et public ;
- utilité réelle du jeton.

Formules simples :

`capitalisation = prix × offre en circulation`

`FDV = prix × offre maximale ou totalement diluée`

Un faible prix unitaire ne signifie pas qu’un jeton est bon marché. Une forte différence entre capitalisation et FDV peut signaler une dilution potentielle importante.

## 15. Smart contracts et autorisations

Un smart contract est un programme exécuté sur une blockchain. Il applique son code ; ce n’est pas une intelligence capable de juger l’intention de l’utilisateur.

Distinguer :

- connexion d’un portefeuille ;
- signature d’un message ;
- transaction blockchain ;
- approbation ou allowance donnée à un contrat.

Une autorisation illimitée peut exposer davantage de jetons que l’opération actuelle. Déconnecter un site ne révoque pas nécessairement une autorisation déjà enregistrée sur la blockchain.

## 16. DeFi

La finance décentralisée peut proposer échange, prêt, emprunt, fourniture de liquidité et produits de rendement.

Risques :

- bug ou faille de smart contract ;
- clé administrative ;
- oracle de prix défaillant ;
- liquidité insuffisante ;
- gas ;
- slippage et price impact ;
- liquidation d’un emprunt garanti ;
- perte impermanente ;
- dépendance à plusieurs protocoles assemblés.

Un audit réduit certains risques, mais ne garantit jamais l’absence de faille.

## 17. Bridges

Un bridge relie deux réseaux. Selon son fonctionnement, il peut bloquer un actif sur le réseau de départ et produire une représentation sur le réseau d’arrivée.

Vérifier :

- réseau de départ ;
- réseau d’arrivée ;
- bridge officiel ;
- actif reçu ;
- frais sur les deux réseaux ;
- liquidité ;
- temps de transfert ;
- petit test préalable.

Un bridge ajoute une nouvelle couche de risque : contrats, validateurs, réseaux et liquidité.

## 18. Marge, levier, futures et liquidation

- Spot : exposition limitée au capital utilisé, sans liquidation de marché liée à un emprunt.
- Marge : capacité fournie pour ouvrir une position plus grande.
- Levier : exposition supérieure au capital engagé.
- Long : recherche d’une hausse.
- Short : recherche d’une baisse.
- Future : contrat dépendant du prix d’un actif.
- Perpétuel : future sans échéance fixe.
- Funding : paiement périodique entre positions longues et courtes.
- Liquidation : fermeture forcée lorsque la marge devient insuffisante.
- Marge isolée : risque compartimenté.
- Marge croisée : plusieurs positions partagent le même capital.
- Mark price : prix de référence pouvant être utilisé pour la liquidation.

Le levier réduit la marge d’erreur. Un mouvement ordinaire du marché peut provoquer une perte majeure ou une liquidation.

Règle du profil débutant : Spot uniquement, sans levier, marge, futures, perpetuals ni short.

## 19. Arnaques et manipulations

Principaux scénarios :

- fausse plateforme avec gains fictifs ;
- taxe ou dépôt supplémentaire demandé pour débloquer un retrait ;
- faux support ;
- phishing ;
- logiciel de prise de contrôle à distance ;
- malware remplaçant une adresse copiée ;
- address poisoning ;
- faux cadeau demandant d’envoyer d’abord des cryptos ;
- arnaque relationnelle ou sentimentale ;
- faux groupe de trading ;
- pump-and-dump ;
- rug pull ;
- honeypot empêchant la vente ;
- faux jeton ;
- wallet drainer ;
- fausse récupération de fonds ;
- faux emploi ou utilisation du compte comme intermédiaire.

Signaux critiques : rendement garanti, urgence, secret réservé aux initiés, support demandant un code ou un secret, adresse dictée par un tiers, autorisation illimitée incomprise, nouveau paiement exigé pour retirer.

## 20. Checklist finale

Avant un achat Spot fictif ou futur :

- prestataire et domaine vérifiés ;
- compte sécurisé ;
- actif et paire compris ;
- type d’ordre compris ;
- montant borné ;
- frais d’entrée et de sortie connus ;
- spread observé ;
- prix d’équilibre calculé ;
- perte maximale acceptable ;
- aucun levier ;
- absence de pression extérieure ;
- confirmation humaine finale.

Avant un retrait :

- bon actif ;
- bon réseau ;
- bonne adresse ;
- adresse contrôlée après collage ;
- frais et montant net connus ;
- minimum respecté ;
- petit retrait test ;
- TXID et confirmations vérifiés.

Avant une interaction DeFi :

- domaine officiel ;
- réseau correct ;
- contrat identifié ;
- fonction comprise ;
- montant d’autorisation limité ;
- gas, slippage, price impact et minimum reçu connus ;
- méthode de sortie comprise.

En cas d’incompréhension : **ne pas signer et ne pas confirmer.**

---

# Build 28.2.78 — point de reprise

Le Build 28.2.78 ajoute, sans retirer l’existant :

- info-bulles pédagogiques dynamiques dans la simulation ;
- libellés plus compréhensibles ;
- hypothèses manuelles de frais et d’écarts ;
- exemple école explicitement non contractuel ;
- P/L brut séparé du P/L net estimé ;
- prix d’équilibre estimé ;
- scénarios instantanés de −5 % à +5 % ;
- détails de position enrichis ;
- journal d’achat et de vente enrichi ;
- Security Gate vert, orange ou rouge ;
- suppression de l’affichage négatif `−0,00 €` ;
- statut compact `À JOUR` ;
- largeur du cartouche de vérité du graphique verrouillée.

Les sections, fonctions et scénarios existants sont conservés.

## Sources officielles utiles

- AMF — crypto-actifs : https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/crypto-actifs-bitcoin-etc
- AMF — listes blanches et noires : https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/listes-blanches
- Kraken Support : https://support.kraken.com/fr
- Ethereum — smart contracts : https://ethereum.org/fr/developers/docs/smart-contracts/
- Ethereum — DeFi : https://ethereum.org/fr/defi/
- Ethereum — bridges : https://ethereum.org/fr/bridges/
- ESMA — crypto-assets : https://www.esma.europa.eu/investor-corner/crypto-assets
- Europol — prévention : https://www.europol.europa.eu/operations-services-and-innovation/public-awareness-and-prevention-guides
- Impôts — actifs numériques : https://www.impots.gouv.fr/particulier/questions/comment-declarer-les-plus-ou-moins-values-sur-cessions-dactifs-numeriques

Les procédures, frais, statuts réglementaires et règles fiscales doivent toujours être revérifiés au moment de l’usage.


---

# ADDENDUM BUILD 28.2.79 — REPRISE OPÉRATIONNELLE

## Validation de 28.2.78 reçue

Les captures Firefox/Ryzen ont confirmé la présence et le fonctionnement visible des nouveaux blocs pédagogiques, du Security Gate, du laboratoire de retrait et du Scam Sentinel. Retour principal : les explications centrées sous forme de fenêtre modale sont jugées trop intrusives.

## Correction 28.2.79

- remplacement de la fenêtre modale par une aide contextuelle non bloquante ;
- suppression du flou et de l’assombrissement global ;
- panneau réductible et fermable ;
- ajout du parcours expert sur 24 mois ;
- ajout du Transaction Proof Ledger ;
- conservation intégrale des fonctions 28.2.78.

## Point de reprise après publication

1. valider visuellement le nouveau panneau d’aide ;
2. vérifier la persistance du parcours expert ;
3. tester achat, vente et refus fictifs ;
4. contrôler les preuves locales ;
5. relever toute anomalie avant le Build suivant.
