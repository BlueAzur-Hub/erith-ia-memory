# Upload Build 28.2.79

## Remplacer uniquement

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

## Commit

Utiliser le texte complet fourni dans `GITHUB_COMMIT_BUILD_28_2_79.txt`.

## Validation Firefox/Ryzen

1. Attendre la publication GitHub Pages.
2. Ouvrir l’interface publique.
3. Effectuer `Ctrl + F5`.
4. Vérifier l’affichage `Build 28.2.79`.
5. Ouvrir Administration → Simulation.
6. Cliquer sur plusieurs boutons `ⓘ` : le panneau doit rester à droite, sans masquer ni flouter toute la page.
7. Tester Réduire, Développer et Fermer.
8. Modifier un état dans le parcours Expert 24 mois, recharger et vérifier sa persistance.
9. Lancer un achat fictif, une vente fictive et un refus ; vérifier le Transaction Proof Ledger.
10. Vérifier Crypto, Métaux, Decision Board et Bridge.

Aucun fichier de données, collecteur, workflow, Bridge ou Control Center n’est remplacé par ce ZIP.
