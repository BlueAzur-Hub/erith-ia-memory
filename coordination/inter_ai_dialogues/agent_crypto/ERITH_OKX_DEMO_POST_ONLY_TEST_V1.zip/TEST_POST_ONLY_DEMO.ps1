﻿$ErrorActionPreference = "Stop"
$Invariant = [System.Globalization.CultureInfo]::InvariantCulture
$Bridge = "http://127.0.0.1:8787"
$Base = "https://eea.okx.com"
$InstId = "BTC-EUR"
$TargetEur = [decimal]10.00

function D([string]$s) {
    return [decimal]::Parse($s, $Invariant)
}
function S([decimal]$v) {
    return $v.ToString("0.############################", $Invariant)
}
function Get-Order([string]$ordId) {
    return Invoke-RestMethod -Uri "$Bridge/demo/order?ordId=$ordId" -Method Get -TimeoutSec 20
}

Write-Host "============================================================"
Write-Host "ERITH · OKX DEMO · POST-ONLY TEST"
Write-Host "============================================================"

# 1) Bridge health
$health = Invoke-RestMethod -Uri "$Bridge/health" -Method Get -TimeoutSec 10
if (-not $health.ok -or -not $health.demo -or $health.instrument -ne $InstId) {
    throw "Bridge non prêt ou mauvais mode."
}
Write-Host "[OK] Bridge DEMO: $($health.bind)"
Write-Host "[OK] Instrument: $($health.instrument)"

# 2) Fresh public market + instrument rules
$tickerResp = Invoke-RestMethod -Uri "$Base/api/v5/market/ticker?instId=$InstId" -Method Get -TimeoutSec 15
$instResp = Invoke-RestMethod -Uri "$Base/api/v5/public/instruments?instType=SPOT&instId=$InstId" -Method Get -TimeoutSec 15

if ($tickerResp.code -ne "0" -or $tickerResp.data.Count -lt 1) { throw "Ticker OKX indisponible." }
if ($instResp.code -ne "0" -or $instResp.data.Count -lt 1) { throw "Règles instrument OKX indisponibles." }

$t = $tickerResp.data[0]
$i = $instResp.data[0]

$bid = D $t.bidPx
$ask = D $t.askPx
$tick = D $i.tickSz
$lot = D $i.lotSz
$minSz = D $i.minSz

if ($bid -le 0 -or $ask -le 0 -or $tick -le 0 -or $lot -le 0) {
    throw "Valeurs marché/instrument invalides."
}

# 3) Maker BUY one tick below current best bid
$px = $bid - $tick
if ($px -le 0) { throw "Prix calculé invalide." }

$rawSz = $TargetEur / $px
$sz = [decimal]::Ceiling($rawSz / $lot) * $lot
if ($sz -lt $minSz) { $sz = $minSz }

$pxS = S $px
$szS = S $sz
$notional = $px * $sz

Write-Host "[MARKET] bid=$($t.bidPx) ask=$($t.askPx) tick=$($i.tickSz)"
Write-Host "[ORDER] DEMO BUY POST_ONLY BTC-EUR"
Write-Host "[ORDER] px=$pxS  sz=$szS BTC  notional≈$([math]::Round([double]$notional,2)) EUR"

$body = @{
    side = "buy"
    px = $pxS
    sz = $szS
} | ConvertTo-Json -Compress

# 4) Place DEMO order through local bridge
$placed = Invoke-RestMethod -Uri "$Bridge/demo/post-only" -Method Post -ContentType "application/json" -Body $body -TimeoutSec 20

if ($placed.code -ne "0" -or $placed.data.Count -lt 1) {
    Write-Host "[REJECTED] OKX code=$($placed.code) msg=$($placed.msg)" -ForegroundColor Yellow
    $placed | ConvertTo-Json -Depth 10
    Read-Host "Entrée pour fermer"
    exit 2
}

$row = $placed.data[0]
if ($row.sCode -and $row.sCode -ne "0") {
    Write-Host "[REJECTED] sCode=$($row.sCode) sMsg=$($row.sMsg)" -ForegroundColor Yellow
    $placed | ConvertTo-Json -Depth 10
    Read-Host "Entrée pour fermer"
    exit 3
}

$ordId = [string]$row.ordId
if (-not $ordId) { throw "OKX n'a pas retourné ordId." }

Write-Host "[PLACED] ordId=$ordId"

$snapshots = @()
foreach ($sec in @(2, 10, 20)) {
    Start-Sleep -Seconds $(if ($sec -eq 2) {2} elseif ($sec -eq 10) {8} else {10})
    $o = Get-Order $ordId
    $od = $o.data[0]
    $snapshots += [pscustomobject]@{
        after_s = $sec
        state = $od.state
        accFillSz = $od.accFillSz
        avgPx = $od.avgPx
        fee = $od.fee
        feeCcy = $od.feeCcy
        uTime = $od.uTime
    }
    Write-Host "[T+$sec] state=$($od.state) fill=$($od.accFillSz) avgPx=$($od.avgPx) fee=$($od.fee) $($od.feeCcy)"
    if ($od.state -eq "filled" -or $od.state -eq "canceled") { break }
}

# 5) Cancel if still resting/partial after observation window
$latest = Get-Order $ordId
$state = $latest.data[0].state
if ($state -eq "live" -or $state -eq "partially_filled") {
    Write-Host "[CANCEL] ordre encore $state après fenêtre de test."
    $cancelBody = @{ ordId = $ordId } | ConvertTo-Json -Compress
    $cancel = Invoke-RestMethod -Uri "$Bridge/demo/cancel" -Method Post -ContentType "application/json" -Body $cancelBody -TimeoutSec 20
    Start-Sleep -Seconds 2
}

$final = Get-Order $ordId
$f = $final.data[0]

# 6) Save local evidence report
$reportDir = Join-Path $PSScriptRoot "reports"
New-Item -ItemType Directory -Force -Path $reportDir | Out-Null
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportPath = Join-Path $reportDir "okx_demo_post_only_$stamp.json"

$report = [ordered]@{
    mode = "OKX_DEMO"
    instrument = $InstId
    target_eur = [double]$TargetEur
    public_bid_at_submit = $t.bidPx
    public_ask_at_submit = $t.askPx
    tickSz = $i.tickSz
    lotSz = $i.lotSz
    minSz = $i.minSz
    order = @{
        side = "buy"
        ordType = "post_only"
        px = $pxS
        sz = $szS
        ordId = $ordId
    }
    snapshots = $snapshots
    final = @{
        state = $f.state
        accFillSz = $f.accFillSz
        avgPx = $f.avgPx
        fee = $f.fee
        feeCcy = $f.feeCcy
        cTime = $f.cTime
        uTime = $f.uTime
    }
}
$report | ConvertTo-Json -Depth 10 | Set-Content -Path $reportPath -Encoding UTF8

Write-Host ""
Write-Host "================ RESULTAT ================"
Write-Host "state=$($f.state)"
Write-Host "accFillSz=$($f.accFillSz)"
Write-Host "avgPx=$($f.avgPx)"
Write-Host "fee=$($f.fee) $($f.feeCcy)"
Write-Host "rapport=$reportPath"
Write-Host "=========================================="
Write-Host ""
Read-Host "Entrée pour fermer"
