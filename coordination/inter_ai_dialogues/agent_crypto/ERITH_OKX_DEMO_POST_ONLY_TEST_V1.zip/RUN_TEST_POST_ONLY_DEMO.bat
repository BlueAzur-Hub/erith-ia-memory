@echo off
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY TEST
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0TEST_POST_ONLY_DEMO.ps1"
