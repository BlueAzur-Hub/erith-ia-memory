# Canonical entry changes

administrator/index.html now:
- loads ./js/strategy-a-g3-outcome-certification-406222.js after the post-horizon owner/mount repair;
- calls AgentCryptoStrategyAG3OutcomeCertification.render() during canonical evidence mount;
- exposes outcome_certification_available in AgentCryptoCanonicalEvidenceWiring.snapshot().

No Market Core / Strategy A business logic / live-order path change.
