# Agent-Crypto 40.6.136 — Release Delivery

Scope: Aerith-10 ChatGPT activation card only.

Changes:
- Step 1 card is a direct link to the private Aerith-10 minimal ZIP.
- Step 2 card copies Christophe's full master prompt and opens ChatGPT with a best-effort `?prompt=` prefill.
- Step 3 card is a direct link to the canonical Seven Heaven portable archive.
- The full master prompt is included verbatim as `AERITH_10_FULL_MATRIX_MASTER_PROMPT.txt`.

Protected / unchanged:
- Market Core 38.15.11
- version-truth.js
- Atlas CURRENT
- Oracle
- Lecture Technique
- Strategy A
- TRADUS
- Forge d'Aerith Pro
- Notion Aerith-10 portal

Important:
The `?prompt=` deep-link behavior is not a documented stable external API. Clipboard copy is retained as a fallback.
Automatic send is never attempted.
Firefox terrain proof is still required.
