AGENT-CRYPTO 40.6.314 — VISIBLE VERSION DECONTAMINATION

Functional commit: 10bb8c8bf31210f438a38fb5b44be9cb4952363e
Purpose: remove visible development-version scars only.

Visible changes:
- ORACLE V1 · SCÉNARIO COURT / TOP 5 -> ORACLE · SCÉNARIO COURT / TOP 5
- DECISION INTELLIGENCE · CURRENT TRUTH · <build> -> DECISION INTELLIGENCE · CURRENT TRUTH

Protected / unchanged:
- CSS: unchanged
- Aether geometry and F11 contract: unchanged from 40.6.313 terrain PASS
- Window Manager: unchanged
- Market Core 38.15.11: unchanged
- Oracle calculations and internal V1/V2 model semantics: unchanged
- Storage / Strategy / Lecture Technique logic: unchanged

Firefox terrain gate:
1. Ctrl+F5.
2. Oracle scenario header shows ORACLE without V1.
3. Decision Intelligence eyebrow shows no build number.
4. Aether normal -> F11 -> normal remains identical to 40.6.313.
