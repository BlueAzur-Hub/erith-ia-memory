ERITH · PREP .500 EVIDENCE — V6-B BTC-USDC

STATUS: PREPARED LOCALLY / DO NOT RUN UNTIL OPERATOR VALIDATION.

Purpose:
- matched twin of the completed BTC-EUR V6 campaign;
- 50 Demo BUY Post-only attempts, ~10 USDC, 60 s timeout;
- identical fill CDF and markout horizons;
- same OKX Demo safety model.

Bridge:
- new separate port 8792 so the known-good V2 on 8791 is untouched;
- service ERITH_OKX_DEMO_BRIDGE_V3_DUAL_PAIR;
- strict allowlist: BTC-EUR and BTC-USDC only;
- x-simulated-trading: 1;
- no withdrawal/transfer route;
- order/read/cancel require an allowlisted instrument.

Files go beside okx-demo.env in C:\ERITH\okx-demo-bridge\ when Christophe decides to run it.

Run order later:
1. leave existing 8787/8790 alone;
2. start V3 on 8792;
3. verify both BTC-EUR and BTC-USDC instrument checks are OK;
4. run V6-B BTC-USDC;
5. send FINAL JSON to Seven;
6. only then unlock 40.6.500 comparator evidence.

This pack is preparation only; it is not part of 40.6.497-.499 and nothing is pushed.
