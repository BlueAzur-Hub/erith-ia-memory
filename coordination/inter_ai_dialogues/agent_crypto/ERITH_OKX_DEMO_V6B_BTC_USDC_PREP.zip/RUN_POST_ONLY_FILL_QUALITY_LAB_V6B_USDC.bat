@echo off
setlocal
cd /d "%~dp0"
title ERITH - OKX DEMO V6-B BTC-USDC
where py >nul 2>nul
if errorlevel 1 (set "PY=python") else (set "PY=py -3")
%PY% -c "import websocket; print('[OK] websocket-client', websocket.__version__)"
if errorlevel 1 (
  %PY% -m pip install --user websocket-client
  if errorlevel 1 (echo [ERREUR] websocket-client & pause & exit /b 1)
)
%PY% "%~dp0POST_ONLY_FILL_QUALITY_LAB_V6B_USDC.py"
pause
