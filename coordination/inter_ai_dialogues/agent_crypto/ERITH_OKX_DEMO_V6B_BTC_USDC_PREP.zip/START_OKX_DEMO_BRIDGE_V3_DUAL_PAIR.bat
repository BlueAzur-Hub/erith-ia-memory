@echo off
cd /d "%~dp0"
title ERITH - OKX DEMO BRIDGE V3 DUAL PAIR - PORT 8792
py -3 "%~dp0okx_demo_bridge_v3_dual_pair.py"
pause
