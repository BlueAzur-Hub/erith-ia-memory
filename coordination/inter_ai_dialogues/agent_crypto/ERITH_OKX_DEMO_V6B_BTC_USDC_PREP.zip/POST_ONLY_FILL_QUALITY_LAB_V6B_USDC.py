#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import statistics
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING
from pathlib import Path

try:
    import websocket  # websocket-client
except Exception as exc:
    raise SystemExit(
        "DEPENDANCE MANQUANTE: websocket-client\n"
        "Lance RUN_POST_ONLY_FILL_QUALITY_LAB_V6B_USDC.bat : il l'installe automatiquement.\n"
        f"detail={exc}"
    )

# ============================================================
# ERITH · OKX DEMO · POST-ONLY FILL QUALITY LAB V6
# DEMO ONLY — NO LIVE TRADING — NO WITHDRAWAL / TRANSFER ROUTES
# ============================================================

BRIDGE = "http://127.0.0.1:8792"
BRIDGE_SERVICE = "ERITH_OKX_DEMO_BRIDGE_V3_DUAL_PAIR"

REST = "https://eea.okx.com"
WS_DEMO_PUBLIC = "wss://wseeapap.okx.com/ws/v5/public"

INST = "BTC-USDC"
ATTEMPTS = 50
TARGET_QUOTE = Decimal("10")
ORDER_TIMEOUT_S = 60
ORDER_POLL_S = 0.25
GAP_BETWEEN_ATTEMPTS_S = 2

# Ultra-short and short adverse-selection horizons.
MARKOUT_HORIZONS_S = (1, 5, 15, 30, 60, 300, 900)

# Fill CDF checkpoints.
FILL_CDF_S = (1, 2, 5, 10, 20, 30, 60)

# Book context.
DEPTH_LEVELS = 10

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
LOG = ROOT / "post_only_fill_quality_lab_v6b_usdc.log"
LIVE_REPORT = REPORTS / "post_only_fill_quality_lab_v6b_usdc_LIVE.json"


def utc_iso():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def now_ms():
    return int(time.time() * 1000)


def log(msg=""):
    print(msg, flush=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")


def D(x):
    return Decimal(str(x))


def d_or_none(x):
    if x is None or x == "":
        return None
    try:
        return Decimal(str(x))
    except Exception:
        return None


def num_or_none(x):
    d = d_or_none(x)
    return float(d) if d is not None else None


def pct_from(a, b):
    a = d_or_none(a)
    b = d_or_none(b)
    if a is None or b is None or b == 0:
        return None
    return float((a / b - Decimal("1")) * Decimal("100"))


def median(values):
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return statistics.median(vals) if vals else None


def mean(values):
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return statistics.mean(vals) if vals else None


def ceil_step(v, step):
    return (v / step).to_integral_value(rounding=ROUND_CEILING) * step


def http_json(method, url, body=None, headers=None, timeout=20):
    data = None
    hdrs = {
        "Content-Type": "application/json",
        "User-Agent": "ERITH-POSTONLY-FILL-QUALITY-LAB-V6",
    }
    if headers:
        hdrs.update(headers)
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8")
            return r.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            obj = json.loads(raw)
        except Exception:
            obj = {"raw": raw}
        return e.code, obj


def bridge_health():
    s, h = http_json("GET", BRIDGE + "/health")
    if (
        s != 200
        or not h.get("ok")
        or not h.get("demo")
        or h.get("service") != BRIDGE_SERVICE
    ):
        raise RuntimeError(f"Mauvais Bridge: HTTP {s} · {h}")
    return h


def bridge_place(px, sz):
    s, obj = http_json(
        "POST",
        BRIDGE + "/demo/post-only",
        {"instId": INST, "side": "buy", "px": str(px), "sz": str(sz)},
    )
    if s != 200 or str(obj.get("code")) != "0" or not obj.get("data"):
        raise RuntimeError(f"Ordre refusé: HTTP {s} · {obj}")
    row = obj["data"][0]
    if str(row.get("sCode", "0")) != "0":
        raise RuntimeError(f"OKX sCode={row.get('sCode')} · {row.get('sMsg')}")
    ord_id = str(row.get("ordId", "")).strip()
    if not ord_id:
        raise RuntimeError("ordId absent")
    return ord_id, obj


def bridge_get_order(ord_id):
    q = urllib.parse.urlencode({"instId": INST, "ordId": ord_id})
    s, obj = http_json("GET", BRIDGE + "/demo/order?" + q)
    if s != 200 or str(obj.get("code")) != "0" or not obj.get("data"):
        raise RuntimeError(f"Lecture ordre impossible: HTTP {s} · {obj}")
    return obj["data"][0]


def bridge_cancel(ord_id):
    s, obj = http_json("POST", BRIDGE + "/demo/cancel", {"instId": INST, "ordId": ord_id})
    if s != 200 or str(obj.get("code")) != "0":
        raise RuntimeError(f"Annulation impossible: HTTP {s} · {obj}")
    return obj


def get_public_instrument():
    q = urllib.parse.urlencode({"instType": "SPOT", "instId": INST})
    s, obj = http_json("GET", REST + "/api/v5/public/instruments?" + q)
    if s != 200 or str(obj.get("code")) != "0" or not obj.get("data"):
        raise RuntimeError(f"Instrument indisponible: HTTP {s} · {obj}")
    return obj["data"][0]


def load_env():
    path = ROOT / "okx-demo.env"
    if not path.is_file():
        raise RuntimeError(f"Fichier manquant: {path}")
    out = {}
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
            v = v[1:-1]
        out[k.strip()] = v
    need = ("OKX_DEMO_API_KEY", "OKX_DEMO_SECRET_KEY", "OKX_DEMO_PASSPHRASE")
    missing = [k for k in need if not out.get(k)]
    if missing:
        raise RuntimeError("Variables manquantes dans okx-demo.env: " + ", ".join(missing))
    return out


def okx_private_get(path_with_query, env):
    ts = utc_iso()
    prehash = ts + "GET" + path_with_query
    sign = base64.b64encode(
        hmac.new(
            env["OKX_DEMO_SECRET_KEY"].encode("utf-8"),
            prehash.encode("utf-8"),
            hashlib.sha256,
        ).digest()
    ).decode("ascii")
    headers = {
        "OK-ACCESS-KEY": env["OKX_DEMO_API_KEY"],
        "OK-ACCESS-SIGN": sign,
        "OK-ACCESS-TIMESTAMP": ts,
        "OK-ACCESS-PASSPHRASE": env["OKX_DEMO_PASSPHRASE"],
        "x-simulated-trading": "1",
    }
    return http_json("GET", REST + path_with_query, headers=headers)


def get_fee_truth(env):
    path = "/api/v5/account/trade-fee?" + urllib.parse.urlencode(
        {"instType": "SPOT", "instId": INST}
    )
    s, obj = okx_private_get(path, env)
    if s != 200 or str(obj.get("code")) != "0" or not obj.get("data"):
        return {
            "ok": False,
            "http": s,
            "response": obj,
            "maker": None,
            "taker": None,
            "groupId": None,
        }

    row = obj["data"][0]
    maker = row.get("maker")
    taker = row.get("taker")
    group_id = None
    groups = row.get("feeGroup")
    if isinstance(groups, list) and groups:
        # With instId specified, the applicable group is expected to be represented here.
        g = groups[0]
        maker = g.get("maker", maker)
        taker = g.get("taker", taker)
        group_id = g.get("groupId")

    return {
        "ok": True,
        "http": s,
        "level": row.get("level"),
        "maker": maker,
        "taker": taker,
        "groupId": group_id,
        "ts": row.get("ts"),
        "raw": row,
    }


class MarketWatcher:
    def __init__(self):
        self.lock = threading.RLock()
        self.stop_evt = threading.Event()
        self.connected = False
        self.last_error = None
        self.subscription_errors = []

        self.bbo = None
        self.books = {"bids": {}, "asks": {}, "seqId": None, "ts": None, "gaps": 0}
        self.rpi = {"bids": {}, "asks": {}, "seqId": None, "ts": None, "gaps": 0}
        self.events_seen = defaultdict(int)
        self.thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        self.stop_evt.set()

    def _on_open(self, ws):
        self.connected = True
        sub = {
            "id": "ERITHV6",
            "op": "subscribe",
            "args": [
                {"channel": "bbo-tbt", "instId": INST},
                {"channel": "books", "instId": INST},
                {"channel": "books-rpi", "instId": INST},
            ],
        }
        ws.send(json.dumps(sub))

    def _apply_book(self, target, payload, action):
        with self.lock:
            prev = payload.get("prevSeqId")
            seq = payload.get("seqId")
            if (
                target["seqId"] is not None
                and prev is not None
                and int(prev) != int(target["seqId"])
            ):
                target["gaps"] += 1

            if action == "snapshot":
                target["bids"].clear()
                target["asks"].clear()

            for side in ("bids", "asks"):
                for row in payload.get(side) or []:
                    if len(row) < 2:
                        continue
                    px = str(row[0])
                    qty = d_or_none(row[1]) or Decimal("0")
                    if qty == 0:
                        target[side].pop(px, None)
                    else:
                        target[side][px] = list(row)

            target["seqId"] = seq
            target["ts"] = payload.get("ts")

    def _on_message(self, ws, message):
        if message == "pong":
            return
        try:
            obj = json.loads(message)
        except Exception:
            return

        if obj.get("event") == "error":
            with self.lock:
                self.subscription_errors.append(obj)
                self.last_error = obj
            return

        arg = obj.get("arg") or {}
        ch = arg.get("channel")
        data = obj.get("data") or []
        if not ch or not data:
            return

        with self.lock:
            self.events_seen[ch] += 1

        if ch == "bbo-tbt":
            row = data[0]
            bids = row.get("bids") or []
            asks = row.get("asks") or []
            if bids and asks:
                with self.lock:
                    self.bbo = {
                        "bid": str(bids[0][0]),
                        "bidSz": str(bids[0][1]),
                        "ask": str(asks[0][0]),
                        "askSz": str(asks[0][1]),
                        "ts": row.get("ts"),
                        "local_ms": now_ms(),
                    }
            return

        if ch == "books":
            for row in data:
                self._apply_book(self.books, row, obj.get("action"))
            return

        if ch == "books-rpi":
            for row in data:
                self._apply_book(self.rpi, row, obj.get("action"))
            return

    def _on_error(self, ws, err):
        with self.lock:
            self.last_error = repr(err)

    def _on_close(self, ws, code, msg):
        self.connected = False

    def _loop(self):
        while not self.stop_evt.is_set():
            try:
                app = websocket.WebSocketApp(
                    WS_DEMO_PUBLIC,
                    on_open=self._on_open,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close,
                )
                app.run_forever(ping_interval=20, ping_timeout=10)
            except Exception as exc:
                with self.lock:
                    self.last_error = repr(exc)
            if not self.stop_evt.is_set():
                time.sleep(2)

    @staticmethod
    def _sorted_levels(book, side, n):
        rows = []
        for px, row in book[side].items():
            p = d_or_none(px)
            if p is not None:
                rows.append((p, row))
        rows.sort(key=lambda x: x[0], reverse=(side == "bids"))
        return [r for _, r in rows[:n]]

    @staticmethod
    def _imbalance(bids, asks):
        b = sum((d_or_none(r[1]) or Decimal("0")) for r in bids)
        a = sum((d_or_none(r[1]) or Decimal("0")) for r in asks)
        tot = b + a
        if tot == 0:
            return None
        return float(b / tot)

    @staticmethod
    def _exact_level(book, side, px):
        row = book[side].get(str(px))
        if row is None:
            # Decimal normalization fallback.
            pxd = d_or_none(px)
            if pxd is not None:
                for key, val in book[side].items():
                    if d_or_none(key) == pxd:
                        row = val
                        break
        if row is None:
            return None

        out = {
            "price": row[0] if len(row) > 0 else None,
            "qty": row[1] if len(row) > 1 else None,
            "count": row[3] if len(row) > 3 else None,
            "raw": row,
        }
        return out

    def snapshot(self):
        with self.lock:
            bbo = dict(self.bbo) if self.bbo else None

            books_bids = self._sorted_levels(self.books, "bids", DEPTH_LEVELS)
            books_asks = self._sorted_levels(self.books, "asks", DEPTH_LEVELS)
            rpi_bids = self._sorted_levels(self.rpi, "bids", DEPTH_LEVELS)
            rpi_asks = self._sorted_levels(self.rpi, "asks", DEPTH_LEVELS)

            bid = d_or_none(bbo.get("bid")) if bbo else None
            ask = d_or_none(bbo.get("ask")) if bbo else None
            mid = (bid + ask) / Decimal("2") if bid is not None and ask is not None else None

            return {
                "captured_local_ms": now_ms(),
                "connected": self.connected,
                "bbo": bbo,
                "mid": str(mid) if mid is not None else None,
                "books": {
                    "ts": self.books["ts"],
                    "seqId": self.books["seqId"],
                    "gaps": self.books["gaps"],
                    "bid_top10": books_bids,
                    "ask_top10": books_asks,
                    "imbalance_top10": self._imbalance(books_bids, books_asks),
                    "exact_bid": self._exact_level(self.books, "bids", bid) if bid is not None else None,
                },
                "books_rpi": {
                    "ts": self.rpi["ts"],
                    "seqId": self.rpi["seqId"],
                    "gaps": self.rpi["gaps"],
                    "bid_top10": rpi_bids,
                    "ask_top10": rpi_asks,
                    "imbalance_top10": self._imbalance(rpi_bids, rpi_asks),
                    "exact_bid": self._exact_level(self.rpi, "bids", bid) if bid is not None else None,
                },
                "events_seen": dict(self.events_seen),
                "subscription_errors": list(self.subscription_errors),
                "last_error": self.last_error,
            }

    def wait_ready(self, timeout=20):
        end = time.time() + timeout
        while time.time() < end:
            s = self.snapshot()
            if s.get("bbo") and s["bbo"].get("bid") and s["bbo"].get("ask"):
                return s
            time.sleep(0.25)
        raise RuntimeError(
            "WebSocket marché non prêt après "
            f"{timeout}s · last_error={self.last_error} · "
            f"subscription_errors={self.subscription_errors}"
        )


class MarkoutBook:
    def __init__(self, watcher):
        self.watcher = watcher
        self.tasks = []

    def schedule(self, attempt, outcome, event_ms, anchor_mid, fill_px=None):
        self.tasks.append(
            {
                "attempt": attempt,
                "outcome": outcome,  # FULL_FILL / PARTIAL_FILL / NO_FILL
                "event_ms": int(event_ms),
                "anchor_mid": str(anchor_mid) if anchor_mid is not None else None,
                "fill_px": str(fill_px) if fill_px is not None else None,
                "captures": {},
            }
        )

    def capture_due(self):
        now = now_ms()
        for task in self.tasks:
            for h in MARKOUT_HORIZONS_S:
                key = str(h)
                if key in task["captures"]:
                    continue
                due = task["event_ms"] + h * 1000
                if now < due:
                    continue

                s = self.watcher.snapshot()
                mid = d_or_none(s.get("mid"))
                anchor_mid = d_or_none(task.get("anchor_mid"))
                fill_px = d_or_none(task.get("fill_px"))

                cap = {
                    "horizon_s": h,
                    "captured_local_ms": s.get("captured_local_ms"),
                    "bbo": s.get("bbo"),
                    "mid": str(mid) if mid is not None else None,
                    "event_mid_return_pct": pct_from(mid, anchor_mid),
                    "fill_to_mid_markout_pct": pct_from(mid, fill_px) if fill_px is not None else None,
                }
                task["captures"][key] = cap

    def pending(self):
        for task in self.tasks:
            if len(task["captures"]) < len(MARKOUT_HORIZONS_S):
                return True
        return False

    def last_due_ms(self):
        if not self.tasks:
            return None
        return max(t["event_ms"] + max(MARKOUT_HORIZONS_S) * 1000 for t in self.tasks)


def classify_order(final, requested_sz):
    fill = d_or_none(final.get("accFillSz")) or Decimal("0")
    requested = d_or_none(requested_sz) or Decimal("0")
    if fill <= 0:
        return "NO_FILL"
    if requested > 0 and fill + Decimal("1e-18") < requested:
        return "PARTIAL_FILL"
    return "FULL_FILL"


def order_fields(d):
    keys = (
        "instId", "ordId", "clOrdId", "tradeId", "state", "side", "ordType",
        "px", "sz", "accFillSz", "fillPx", "fillSz", "avgPx",
        "fee", "feeCcy", "feeRate", "rebate", "rebateCcy",
        "cTime", "uTime", "fillTime", "cancelSource", "cancelSourceReason",
    )
    return {k: d.get(k) for k in keys}


def exact_fill_latency_ms(order, placement_local_ms):
    fill_time = d_or_none(order.get("fillTime"))
    c_time = d_or_none(order.get("cTime"))
    if fill_time is not None and c_time is not None and fill_time >= c_time:
        return float(fill_time - c_time)
    if fill_time is not None:
        return float(fill_time - Decimal(placement_local_ms))
    return None


def rpi_share_from_exact(rpi_level):
    if not rpi_level:
        return None
    raw = rpi_level.get("raw") or []
    if len(raw) < 3:
        return None
    total = d_or_none(raw[1])
    organic = d_or_none(raw[2])
    if total is None or organic is None or total <= 0:
        return None
    return float((total - organic) / total)


def summarize(results, markouts, fee_truth, watcher):
    valid = [r for r in results if "error" not in r]
    full = [r for r in valid if r.get("outcome") == "FULL_FILL"]
    partial = [r for r in valid if r.get("outcome") == "PARTIAL_FILL"]
    nofill = [r for r in valid if r.get("outcome") == "NO_FILL"]

    latencies_ms = [
        r.get("fill_latency_ms")
        for r in valid
        if r.get("fill_latency_ms") is not None
    ]

    cdf = {}
    denom = len(valid)
    for sec in FILL_CDF_S:
        n = sum(1 for x in latencies_ms if x <= sec * 1000)
        cdf[str(sec)] = {
            "deadline_s": sec,
            "filled_count": n,
            "attempts": denom,
            "probability_pct": round(n * 100 / denom, 2) if denom else None,
        }

    # Markout summaries:
    # - event_mid_return_pct compares market movement after the event for fill vs no-fill.
    # - fill_to_mid_markout_pct measures execution markout only for fills.
    by_h = {}
    for h in MARKOUT_HORIZONS_S:
        fill_event = []
        nofill_event = []
        fill_exec = []

        for t in markouts.tasks:
            c = t["captures"].get(str(h))
            if not c:
                continue
            if t["outcome"] in ("FULL_FILL", "PARTIAL_FILL"):
                if c.get("event_mid_return_pct") is not None:
                    fill_event.append(c["event_mid_return_pct"])
                if c.get("fill_to_mid_markout_pct") is not None:
                    fill_exec.append(c["fill_to_mid_markout_pct"])
            elif t["outcome"] == "NO_FILL":
                if c.get("event_mid_return_pct") is not None:
                    nofill_event.append(c["event_mid_return_pct"])

        med_fill_event = median(fill_event)
        med_nofill_event = median(nofill_event)
        delta = (
            med_fill_event - med_nofill_event
            if med_fill_event is not None and med_nofill_event is not None
            else None
        )

        by_h[str(h)] = {
            "horizon_s": h,
            "filled_event_mid_returns_n": len(fill_event),
            "no_fill_event_mid_returns_n": len(nofill_event),
            "filled_event_mid_return_median_pct": med_fill_event,
            "no_fill_event_mid_return_median_pct": med_nofill_event,
            "filled_minus_no_fill_event_mid_return_median_pct": delta,
            "filled_fill_to_mid_markout_n": len(fill_exec),
            "filled_fill_to_mid_markout_median_pct": median(fill_exec),
        }

    rpi_shares = []
    organic_depths = []
    organic_counts = []
    imbalance = []
    rpi_imbalance = []
    for r in valid:
        pre = r.get("pre_market") or {}
        exact = (pre.get("books") or {}).get("exact_bid")
        if exact:
            organic_depths.append(num_or_none(exact.get("qty")))
            organic_counts.append(num_or_none(exact.get("count")))
        rpi_exact = (pre.get("books_rpi") or {}).get("exact_bid")
        rs = rpi_share_from_exact(rpi_exact)
        if rs is not None:
            rpi_shares.append(rs)
        if (pre.get("books") or {}).get("imbalance_top10") is not None:
            imbalance.append((pre.get("books") or {}).get("imbalance_top10"))
        if (pre.get("books_rpi") or {}).get("imbalance_top10") is not None:
            rpi_imbalance.append((pre.get("books_rpi") or {}).get("imbalance_top10"))

    snap = watcher.snapshot()

    return {
        "attempts_requested": ATTEMPTS,
        "valid_attempts": len(valid),
        "full_fills": len(full),
        "partial_fills": len(partial),
        "no_fill": len(nofill),
        "fill_any_rate_pct": round((len(full) + len(partial)) * 100 / len(valid), 2) if valid else None,
        "full_fill_rate_pct": round(len(full) * 100 / len(valid), 2) if valid else None,
        "fill_latency_ms_median": median(latencies_ms),
        "fill_latency_s_median": (median(latencies_ms) / 1000.0) if latencies_ms else None,
        "fill_cdf": cdf,
        "fee_truth": fee_truth,
        "pretrade_microstructure": {
            "organic_exact_bid_depth_btc_mean": mean(organic_depths),
            "organic_exact_bid_order_count_mean": mean(organic_counts),
            "organic_top10_imbalance_mean": mean(imbalance),
            "rpi_top10_imbalance_mean": mean(rpi_imbalance),
            "rpi_share_at_exact_bid_mean": mean(rpi_shares),
            "rpi_samples": len(rpi_shares),
        },
        "markout_summary": by_h,
        "ws_quality": {
            "events_seen": snap.get("events_seen"),
            "subscription_errors": snap.get("subscription_errors"),
            "books_seq_gaps": (snap.get("books") or {}).get("gaps"),
            "books_rpi_seq_gaps": (snap.get("books_rpi") or {}).get("gaps"),
            "last_error": snap.get("last_error"),
        },
        "interpretation_contract": {
            "negative_filled_minus_no_fill_delta_is_adverse_selection_signal": True,
            "demo_is_not_live_fill_probability": True,
            "depth_is_not_exact_queue_position": True,
            "no_profitability_claim_from_v6_alone": True,
            "strategy_thresholds_unchanged": True,
            "strategy_a_v1_fail_benchmark_unchanged": True,
        },
    }


def save_live(results, markouts, fee_truth, watcher, complete=False):
    REPORTS.mkdir(exist_ok=True)
    payload = {
        "lab": "POST_ONLY_FILL_QUALITY_LAB_V6B_USDC",
        "mode": "OKX_DEMO",
        "instrument": INST,
        "target_quote": str(TARGET_QUOTE),
        "order_timeout_s": ORDER_TIMEOUT_S,
        "markout_horizons_s": list(MARKOUT_HORIZONS_S),
        "ws_url": WS_DEMO_PUBLIC,
        "created_or_updated_at": utc_iso(),
        "complete": complete,
        "summary": summarize(results, markouts, fee_truth, watcher),
        "results": results,
        "markout_tasks": markouts.tasks,
    }
    LIVE_REPORT.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return payload


def sleep_with_markouts(seconds, markouts, results, fee_truth, watcher, save_every_s=10):
    end = time.time() + seconds
    next_save = time.time() + save_every_s
    while time.time() < end:
        markouts.capture_due()
        if time.time() >= next_save:
            save_live(results, markouts, fee_truth, watcher, complete=False)
            next_save = time.time() + save_every_s
        time.sleep(min(0.1, max(0, end - time.time())))


def run_attempt(n, watcher, markouts, inst, results, fee_truth):
    pre = watcher.wait_ready(10)
    bbo = pre["bbo"]
    bid = D(bbo["bid"])
    ask = D(bbo["ask"])

    if bid <= 0 or ask <= 0 or bid >= ask:
        raise RuntimeError(f"BBO invalide: bid={bid} ask={ask}")

    tick = D(inst["tickSz"])
    lot = D(inst["lotSz"])
    min_sz = D(inst["minSz"])

    px = bid
    sz = ceil_step(TARGET_QUOTE / px, lot)
    if sz < min_sz:
        sz = min_sz

    log("")
    log(f"--- ESSAI {n}/{ATTEMPTS} ---")
    log(
        f"[BBO] bid={bid} ask={ask} spread={ask-bid} "
        f"books_imb={pre['books']['imbalance_top10']} "
        f"rpi_imb={pre['books_rpi']['imbalance_top10']}"
    )
    log(
        f"[DEPTH] organic_exact={pre['books']['exact_bid']} "
        f"rpi_exact={pre['books_rpi']['exact_bid']}"
    )
    log(f"[ORDER] DEMO BUY POST_ONLY @ BEST BID · px={px} · sz={sz}")

    placement_local_ms = now_ms()
    ord_id, placed_raw = bridge_place(format(px, "f"), format(sz, "f"))
    log(f"[PLACED] ordId={ord_id}")

    first_fill_seen_local_ms = None
    last_state = None
    snapshots = []
    start = time.time()

    while True:
        markouts.capture_due()

        order = bridge_get_order(ord_id)
        state = str(order.get("state") or "")
        acc = d_or_none(order.get("accFillSz")) or Decimal("0")

        if state != last_state or acc > 0:
            last_state = state
            snapshots.append(
                {
                    "observed_local_ms": now_ms(),
                    **order_fields(order),
                }
            )
            log(
                f"[ORDER STATE] state={state} accFillSz={order.get('accFillSz')} "
                f"fillTime={order.get('fillTime')} tradeId={order.get('tradeId')} "
                f"fee={order.get('fee')} {order.get('feeCcy')} feeRate={order.get('feeRate')}"
            )

        if acc > 0 and first_fill_seen_local_ms is None:
            first_fill_seen_local_ms = now_ms()

        if state in ("filled", "canceled", "mmp_canceled"):
            break

        if time.time() - start >= ORDER_TIMEOUT_S:
            log("[TIMEOUT] 60s -> annulation du reliquat")
            bridge_cancel(ord_id)
            sleep_with_markouts(1.0, markouts, results, fee_truth, watcher, save_every_s=2)
            order = bridge_get_order(ord_id)
            snapshots.append(
                {
                    "observed_local_ms": now_ms(),
                    **order_fields(order),
                }
            )
            break

        time.sleep(ORDER_POLL_S)

    final = bridge_get_order(ord_id)
    final_fields = order_fields(final)
    outcome = classify_order(final_fields, str(sz))
    fill_latency_ms = exact_fill_latency_ms(final_fields, placement_local_ms)

    # Event anchor:
    # - fill/partial: use OKX fillTime when available.
    # - no-fill: use local completion/cancel time.
    if outcome in ("FULL_FILL", "PARTIAL_FILL"):
        event_ms = int(d_or_none(final_fields.get("fillTime")) or now_ms())
        fill_px = d_or_none(final_fields.get("avgPx"))
        if fill_px is None or fill_px <= 0:
            fill_px = d_or_none(final_fields.get("fillPx"))
    else:
        event_ms = now_ms()
        fill_px = None

    event_market = watcher.snapshot()
    anchor_mid = d_or_none(event_market.get("mid"))

    markouts.schedule(
        attempt=n,
        outcome=outcome,
        event_ms=event_ms,
        anchor_mid=anchor_mid,
        fill_px=fill_px,
    )

    r = {
        "attempt": n,
        "submitted_at": utc_iso(),
        "placement_local_ms": placement_local_ms,
        "pre_market": pre,
        "order_request": {
            "side": "buy",
            "ordType": "post_only",
            "px": format(px, "f"),
            "sz": format(sz, "f"),
            "target_quote": str(TARGET_QUOTE),
        },
        "ordId": ord_id,
        "order_snapshots": snapshots,
        "final": final_fields,
        "outcome": outcome,
        "fill_latency_ms": fill_latency_ms,
        "first_fill_seen_local_ms": first_fill_seen_local_ms,
        "event_ms": event_ms,
        "event_market": event_market,
        "anchor_mid": str(anchor_mid) if anchor_mid is not None else None,
        "fill_px_for_markout": str(fill_px) if fill_px is not None else None,
        "depth_is_not_exact_queue_position": True,
    }

    log(
        f"[RESULT] {outcome} · fill_latency_ms={fill_latency_ms} · "
        f"avgPx={final_fields.get('avgPx')} · fee={final_fields.get('fee')} "
        f"{final_fields.get('feeCcy')}"
    )
    return r


def final_console(summary):
    log("")
    log("================ V6 · BILAN ORDRES ================")
    log(f"valid_attempts={summary.get('valid_attempts')}")
    log(f"full_fills={summary.get('full_fills')}")
    log(f"partial_fills={summary.get('partial_fills')}")
    log(f"no_fill={summary.get('no_fill')}")
    log(f"fill_any_rate_pct={summary.get('fill_any_rate_pct')}")
    log(f"fill_latency_s_median={summary.get('fill_latency_s_median')}")
    log("FILL CDF:")
    for sec, row in (summary.get("fill_cdf") or {}).items():
        log(f"  <= {sec}s : {row.get('filled_count')}/{row.get('attempts')} · {row.get('probability_pct')} %")

    log("")
    log("MARKOUT / ADVERSE SELECTION:")
    for h, row in (summary.get("markout_summary") or {}).items():
        log(
            f"  +{h}s · fill_event_mid={row.get('filled_event_mid_return_median_pct')} % "
            f"· nofill_event_mid={row.get('no_fill_event_mid_return_median_pct')} % "
            f"· delta(fill-nofill)={row.get('filled_minus_no_fill_event_mid_return_median_pct')} % "
            f"· fill->mid={row.get('filled_fill_to_mid_markout_median_pct')} %"
        )
    log("===================================================")


def main():
    LOG.write_text("", encoding="utf-8")
    REPORTS.mkdir(exist_ok=True)

    log("=" * 78)
    log("ERITH · OKX DEMO · POST-ONLY FILL QUALITY + ADVERSE SELECTION LAB V6-B BTC-USDC")
    log("=" * 78)
    log("[SAFE] DEMO uniquement · Bridge 8791 obligatoire · aucune route live.")
    log("[SAFE] Aucun retrait, transfert ou ordre de sortie.")

    h = bridge_health()
    log(f"[OK] Bridge={h.get('service')} · {h.get('bind')} · demo={h.get('demo')}")

    env = load_env()
    fee_truth = get_fee_truth(env)
    if fee_truth.get("ok"):
        log(
            f"[FEE TRUTH] level={fee_truth.get('level')} "
            f"maker={fee_truth.get('maker')} taker={fee_truth.get('taker')} "
            f"groupId={fee_truth.get('groupId')}"
        )
    else:
        log(f"[FEE TRUTH] indisponible · HTTP={fee_truth.get('http')} · {fee_truth.get('response')}")

    inst = get_public_instrument()
    log(
        f"[INSTRUMENT] {INST} tickSz={inst.get('tickSz')} "
        f"lotSz={inst.get('lotSz')} minSz={inst.get('minSz')}"
    )

    watcher = MarketWatcher()
    watcher.start()
    ready = watcher.wait_ready(20)
    log(
        f"[WS] READY · {WS_DEMO_PUBLIC} · bbo={ready.get('bbo')} "
        f"events={ready.get('events_seen')}"
    )

    markouts = MarkoutBook(watcher)
    results = []

    try:
        for n in range(1, ATTEMPTS + 1):
            try:
                r = run_attempt(n, watcher, markouts, inst, results, fee_truth)
                results.append(r)
            except Exception as exc:
                log(f"[ESSAI {n}] ERREUR: {type(exc).__name__}: {exc}")
                results.append(
                    {
                        "attempt": n,
                        "submitted_at": utc_iso(),
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

            markouts.capture_due()
            save_live(results, markouts, fee_truth, watcher, complete=False)

            if n < ATTEMPTS:
                sleep_with_markouts(
                    GAP_BETWEEN_ATTEMPTS_S,
                    markouts,
                    results,
                    fee_truth,
                    watcher,
                    save_every_s=2,
                )

        log("")
        log("[ORDERS DONE] 50 tentatives terminées.")
        log("[MONITOR] Aucun nouvel ordre. Fin des markouts +1/+5/+15/+30/+60/+300/+900s.")

        last_due = markouts.last_due_ms()
        next_log = time.time()
        while last_due is not None and now_ms() <= last_due + 1500:
            markouts.capture_due()
            if time.time() >= next_log:
                pending = sum(
                    1
                    for t in markouts.tasks
                    if len(t["captures"]) < len(MARKOUT_HORIZONS_S)
                )
                log(f"[MONITOR] tâches markout encore ouvertes={pending}")
                save_live(results, markouts, fee_truth, watcher, complete=False)
                next_log = time.time() + 30
            time.sleep(0.1)

        markouts.capture_due()
        payload = save_live(results, markouts, fee_truth, watcher, complete=True)

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        final_path = REPORTS / f"post_only_fill_quality_lab_v6b_usdc_FINAL_{stamp}.json"
        final_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        final_console(payload["summary"])
        log(f"rapport_final={final_path}")
        log(f"rapport_live={LIVE_REPORT}")

    finally:
        watcher.stop()


if __name__ == "__main__":
    code = 0
    try:
        main()
    except KeyboardInterrupt:
        code = 130
        log("")
        log("[STOP] Interrompu par l'utilisateur. LIVE.json conserve le dernier checkpoint.")
    except Exception as exc:
        code = 1
        log("")
        log("!!!!!!!! ERREUR LAB V6 !!!!!!!!")
        log(f"{type(exc).__name__}: {exc}")
        log(f"log={LOG}")
    finally:
        print()
        input("Entrée pour fermer...")
    raise SystemExit(code)
