# DELIVERY — AGENT-CRYPTO 40.6.249

Type: ZIP de livraison borné / patch exact de la version 40.6.249.
Ce ZIP n'est pas une copie intégrale du dépôt : il contient les fichiers de la correction Decision Intelligence, le build manifest et le receipt.

Commits:
- 2f6ae1ec83829e04a0111cfe863e9e0e29a67567 — runtime repair
- c33dd500a455c45be6d3402b29c97bc0ff3a55e9 — release 40.6.249
- 4ba02d0d5d855487c5068b676588c41428947a24 — receipt

Fichiers:
- public/agent_crypto_erith_ia/administrator/js/decision-intelligence-current-truth-406243.js  SHA256=ed849e647bd4f233d124db884a18ba075645a7790999eaf0b77eecab286062d0
- public/agent_crypto_erith_ia/administrator/js/decision-intelligence-acceptance.js  SHA256=d642a98e3a9896f972f8b0873cdcdaea5d50e92e8a40152f81a2ae9a63d21cbe
- public/agent_crypto_erith_ia/administrator/build.json  SHA256=769d3a21cfec809eca0582ec73cac97f2167b4420b90b5437ab824efd895659b
- coordination/inter_ai_dialogues/agent_crypto/2026-09-18_AGENT_CRYPTO_40_6_249_DECISION_INTELLIGENCE_NON_DESTRUCTIVE_REFRESH_LOCK.md  SHA256=b7d57ef8c158b4a2c2a77345e12c9e902d1300da0930aaf59a0eddc9d86561a3
