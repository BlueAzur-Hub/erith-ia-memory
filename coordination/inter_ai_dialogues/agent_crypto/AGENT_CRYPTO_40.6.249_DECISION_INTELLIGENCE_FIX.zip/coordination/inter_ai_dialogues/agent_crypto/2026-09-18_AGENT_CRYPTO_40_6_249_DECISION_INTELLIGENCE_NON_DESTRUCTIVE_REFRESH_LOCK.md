# AGENT-CRYPTO 40.6.249 — DECISION INTELLIGENCE NON-DESTRUCTIVE REFRESH LOCK

Date: 2026-09-18
Release: **40.6.249**
Parent: **40.6.248**
Market Core: **38.15.11**
Mode: **PAPER ONLY**
G3: **PENDING**
G9: **LOCKED**

## Context

Firefox terrain on 40.6.248 reported a page-slowdown state while **Decision Intelligence · vérité courante** was open.

40.6.247 remains the last confirmed Firefox terrain PASS baseline.

## Root cause

The 40.6.248 repair added an explicit-open refresh to the existing Decision Intelligence `<details>` owner.

The same `toggle` event called `refresh()`, while `refresh()` removed the open `<details>`, recreated it, restored `open=true`, and rebound the same toggle handler.

That creates a local re-entry / refresh-loop risk:

`toggle → refresh → remove details → recreate open details → toggle → refresh → ...`

## Repair

Modified:

- `public/agent_crypto_erith_ia/administrator/js/decision-intelligence-current-truth-406243.js`
- `public/agent_crypto_erith_ia/administrator/build.json`

The 40.6.248 Version Truth acceptance fix is preserved unchanged.

## Commits

- Runtime repair: `2f6ae1ec83829e04a0111cfe863e9e0e29a67567`
- Release manifest: `c33dd500a455c45be6d3402b29c97bc0ff3a55e9`
- Receipt: `4ba02d0d5d855487c5068b676588c41428947a24`

## Static proof

- JavaScript syntax: **PASS**
- build.json parse: **PASS**
- build: **40.6.249**
- parent: **40.6.248**
- destructive `details.remove()`: **absent**
- in-place host refresh: **present**
- new timer: **none**
- new observer: **none**

## Firefox proof

Reload until `Build 40.6.249 · Administrator`.

Open `Analyse & décision → Decision Intelligence · vérité courante`.

Expected: no Firefox slowdown loop, page remains scrollable, and the panel can be opened/reclosed several times.
