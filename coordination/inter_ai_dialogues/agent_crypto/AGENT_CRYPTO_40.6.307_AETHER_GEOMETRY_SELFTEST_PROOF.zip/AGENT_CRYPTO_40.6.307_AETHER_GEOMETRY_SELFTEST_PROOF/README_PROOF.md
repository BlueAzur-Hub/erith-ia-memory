# Agent-Crypto 40.6.307 — Aether geometry self-test proof

## Delivered commits

- 40.6.306 — single outer geometry owner
  - main commit: `603f08c7e31b7fd7895b5de7f94ac32d55df218b`
- 40.6.307 — reversible F11 screen snapshot
  - main commit: `1afbd75fbb246132ae4f96d06b9040f2dadf1766`

## Root cause proven

The historical Aether CSS stack still contained multiple outer-window geometry owners,
including the old centered portal geometry (`left:50%`, `top:calc(50vh + 99px)`,
`transform:translate(-50%,-50%)`, large 16:9 width). Window Manager geometry only won
while the window was already floating. Revealing/docking in the wrong order exposed the
old centered portal for a frame/state.

40.6.306 removes outer Aether geometry ownership from presentation CSS and makes open/close
atomic: prepare native floating geometry while hidden; reveal last. Close hides DOM first,
then lets Window Manager dock internally.

## F11 failure reproduced before correction

The 40.6.305 F11 detector read `window.screen` live. In the headless Chromium test environment,
`screen.height` followed viewport resizing. After the simulated F11 exit, screen height collapsed
to the normal viewport height, so `isBrowserF11()` remained true and the large geometry stayed.

This is recorded in `05_f11_406305_failure_result.json`:

- normal: 930×523 at x=12
- F11: 1278×719 at x=12
- exit: still 1278×719, F11 state still true

## 40.6.307 correction

40.6.307 freezes the physical screen reference once at F11 bridge installation. No recurring timer,
no MutationObserver, no second geometry owner. F11 geometry remains temporary (`persist:false`).

`07_f11_406307_fixed_result.json` proves:

- normal: 930×523 at x=12
- F11: 1278×719 at x=12
- exit: exact 930×523 restore at x=12
- F11 state returns false

## Integrated contract test

`10_integrated_406307_result.json` tests the whole geometry contract:

- normal left geometry: PASS
- no visible pre-reveal centered frame: PASS
- F11 expansion: PASS
- exact F11 exit restore: PASS
- close/reopen preservation: PASS
- manual resize + close/reopen preservation: PASS
- manual resize + F11 round-trip exact restore: PASS

Overall: PASS.

## Post-merge static reread

After merge of 40.6.307:

- `js/app.js` syntax: PASS
- `js/aether.js` syntax: PASS
- no outer `#atlasAetherStatusPanel` geometry declarations remain in `admin-ribbons.css`
- Aether open/close pre-reveal contract remains present
- F11 screen reference is frozen
- no live `screen.width/screen.height` read remains inside the F11 detector
- exact restore path remains present
- Window Manager SHA: `9cca1083ad0e5318c816c4b1a495261ad5992ce7`
- Aether V2 CSS SHA: `4745156d45f3ba3f51133aa541b9f810ddeeeb66`
- Decision Intelligence SHA: `b04c9c8b5416e7cac0214b0cc2e10934a98f91ba`
- post-boot loader SHA: `9282ab84c0ed2855fa34796e66e360e327584cdf`

Human Firefox terrain validation is still pending and is not claimed as PASS here.
