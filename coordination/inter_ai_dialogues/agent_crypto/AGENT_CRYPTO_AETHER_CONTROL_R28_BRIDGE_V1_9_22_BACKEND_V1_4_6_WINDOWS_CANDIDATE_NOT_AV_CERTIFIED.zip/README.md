# ERITH.IA — R28 · Bridge 1.9.22 · Backend 1.4.6

**CANDIDAT, reconstruit depuis les sources R26 fournies par l’utilisateur.**

Lire `R28_SECURITY_AND_ROLE_INTEGRATION.md` en priorité. R28 reprend l’enveloppe HTTP prévue dans le R27, ajoute une authentification Operator indépendante, préserve l'Owner et les restrictions OKX. Le R27 bloqué par Defender n'est ni inclus ni utilisé. Aucun test antivirus Windows n'a été réalisé ici et les deux interfaces web ne sont pas encore raccordées à cette nouvelle authentification.

---

## Historique R26 (conservé pour la traçabilité)

# ERITH.IA — Atlas Control R26 · Bridge 1.9.20 · Backend 1.4.6

**CANDIDAT R26 — tests hors réseau ; vérification Windows / Firefox R25 encore nécessaire. R24 reste le checkpoint stable.**

Origine : archive R22 1.9.16 envoyée le 18 octobre 2026. Le Bridge reste privé sur 127.0.0.1:8787, le Backend reste 1.4.6, et la lecture OKX (y compris le journal comptable R22) reste exclusivement **READ**, sans permission Trade / Withdraw. Les comptes, mots de passe et jetons persistants ne figurent pas dans le paquet.

## Changements ciblés

1. **Atlas singleflight** : une demande Atlas `market/top5/math/contradictions` calculée pour le même contrat, modèle et paramètres partage la génération en cours avec les requêtes concurrentes, ainsi que le cache après génération. Aucune seconde inférence lancée par une requête jumelle, même si l'attente dépasse son délai.
2. **Une seule inférence lourde en même temps** par processus Bridge, couvrant Atlas et Aerith : toute autre génération non identique attend au maximum 4 secondes puis retourne un commentaire déterministe prudent, sans bloquer les routes de marché, `/health` ni OKX READ.
3. **Télémétrie non sensible** : `bridge/data/diagnostics/atlas_runtime.jsonl` sur le PC uniquement, journalisant dates UTC, PID, 12 premiers caractères de SHA-256 du contrat et durée des calculs. Aucune donnée de compte, secret, mot de passe, prompt ou portefeuille.
4. Métadonnées du Control Center passées à **2.3.2R24** et schéma de configuration à **1.9.18**. Le mutex Windows commun avec R21/R22 reste inchangé. Frontend Trader 40.6.640 et Market Core 38.15.11 intacts.

## Limitations importantes

Ce correctif empêche les appels de modèle *concurrents* au sein d'un Bridge et mutualise les requêtes strictement identiques. Il **n'empêche pas**, à lui seul, le navigateur Administrator de programmer une nouvelle analyse après un **nouveau snapshot canonique différent**, même à 30 minutes d'écart. Le module navigateur sera examiné séparément à partir des traces nouvellement produites. Il n'est pas une amélioration garantie de vitesse pour une inférence unique de `gpt-oss:20b-32k` (modèle pouvant dépasser la VRAM disponible).

## Installer / essayer prudemment

- Ne lancez pas l'EXE R21/R22 et l'EXE R23 simultanément : un seul Control Center doit gérer le Bridge local.
- Conservez le ZIP R22 comme point de restauration. Fermez complètement le Control Center précédent avant un remplacement, hors calcul actif.
- Pour un premier test Windows, préférez **mode Atlas MANUEL** et n'activez AUTO qu'après contrôle des journaux. Aucune reconfiguration de la clé API OKX n'est requise et les anciens identifiants locaux restent sur le poste.
- Avant de qualifier cette version : tests de démarrage Windows, autorisation Aether Trust, vérification `/health`, OKX read-only si désiré, génération Atlas unitaire, essai de deux onglets, analyse des journaux et mesures CPU/RAM/VRAM.

## Tests réalisés dans l'environnement de construction

- `python bridge/bridge.py --self-test` — réussite ;
- `python bridge/test_okx_ledger.py` — **19 contrôles mock/READ** réussis ;
- `python bridge/test_atlas_singleflight.py` — **5 tests de concurrence** réussis (11 appels identiques, réveil après erreur, isolation par modèle/config, surcharge, expiration de l'attente) ;
- `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags '-H windowsgui -s -w' ...` — exécutable Windows PE32+ x86-64 GUI compilé ;
- SHA-256 des sources et binaire dans `SHA256SUMS.txt`.

Aucun test d'API Ollama réelle n'a été effectué. Un succès hors réseau n'atteste pas du comportement sur le PC utilisateur.


### R24 — CT/USDC : mode de devise des frais

Ajout unique : `GET /okx/fee-type`, réservé à l'owner Aether Trust ;
appel privé uniquement en `GET /api/v5/account/config`, avec réponse filtrée.
Valeurs `0` (devise reçue = CT à l'achat) et `1` (devise de cotation = USDC).
L'option réelle dépend du compte. Aucun ordre, aucune modification des frais,
aucun élargissement de la permission OKX, aucun changement Trader / Backend.
Tester d'abord hors ligne puis sur Firefox avec un seul Bridge actif.


### R25 — qualification LIMIT Spot CT-USDC avant un ordre

Route GET `/okx/order-gates?instId=CT-USDC` avec contrôle privé de l'instrument
éligible, des montants disponibles et des plafonds, puis contrôle public des
trois filtres et des limites de prix. Toute paire contradictoire ou réponse
partielle est traitée comme non qualifiée, avec raisons datées ; aucune
configuration privée brute ni aucun jeton n'est renvoyé.

Aucun endpoint d'achat, de vente ou de changement du feeType n'a été créé.
Les opérations réelles nécessiteront une étape ultérieure et la permission
Trade volontaire du propriétaire. **Ne pas remplacer R24 avant recette terrain.**


### R26 — Atlas /conclusion bounded HTTP envelope (CANDIDATE, not Firefox verified)

- POST /conclusion has its own bounded request budget (512 KiB by default; hard cap 1 MiB),
  while ordinary /summary retains the historical 270000-byte limit.
- Validations for empty, oversized, truncated and invalid JSON bodies give distinct errors.
- Log contains only request byte length/limit (no payload, reports, token, or secret).
- Atlas singleflight, Ollama, auth, OKX READ, backend and Market Core are unchanged.
- Must pass real Windows/Firefox current closure before being considered a fix.
- Important: EXE is rebuilt with matching embedded source payload; no manual mixing with R25.
