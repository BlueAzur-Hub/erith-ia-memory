# Agent-Crypto · Bridge R26 / V1.9.20 — conclusion Atlas

## Problème dans R25

`BridgeHandler.read_body()` bornait toutes les requêtes ordinaires à `max_snapshot_chars + 20000`, soit 270 000 octets, y compris `POST /conclusion` qui transporte en plus les quatre rapports Atlas, la pédagogie, l'audit NØX et leurs métadonnées. Le journal terrain observait quatre `POST /summary` 200 puis `POST /conclusion` 400. Il n'existe pas de mesure du Content-Length historique pour attribuer chaque 400 avec certitude.

## Changements dans R26 (candidat)

- Budget HTTP dédié à `/conclusion`: 524 288 octets par défaut, configurable jusqu'à 1 048 576 octets maximum. Aucun changement du budget de `/summary`.
- Erreurs distinctes pour corps vide, trop grand, tronqué, Content-Length invalide et JSON invalide.
- Diagnostic du seul nombre d'octets et de la limite (sans journaliser snapshot, rapports, prompt, informations de compte, token ou mot de passe).
- `source/payload.zip` reconstruit et encapsulé dans l'exécutable Windows R26. Le binaire R25 reste intact ; le nouveau R26 conserve une racine AppData séparée. Le trust Aether existant est dans une racine stable.
- Vérification hors réseau de la réception de plus de 270000 octets avec 4 rapports et fingerprint identique, refus de `/summary` sur la même taille, refus des contenus invalides. Aucun appel réel au modèle.
- Aucun changement du Backend 1.4.6, des appels OKX, du modèle Ollama, du Market Core ni des fichiers de l'Administrator.

## Limites

**Candidat non certifié sur le PC** : ne pas déclarer Atlas CURRENT validé tant que le cycle n'est pas clos dans Firefox. Les erreurs 400 de contrat (`report_modes`, empreintes, schéma V3) restent possibles et doivent être diagnostiquées distinctement. Les relances AUTO de l'Administrator 40.6.714 ne sont pas corrigées ici et devront être arrêtées ou corrigées dans une version distincte.

## Validation

- Syntaxe Python, Go Windows cross-build, tests hors réseau : PASS.
- Windows démarrage / Ollama local / Aether Trust / boucle Atlas complète : NON VÉRIFIÉS.
- Éviter deux Control Centers simultanés ; R25 est le point de repli.
