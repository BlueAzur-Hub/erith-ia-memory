$ErrorActionPreference = "Stop"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

$Out = "ATLAS_CRYPTO_BRIDGE_CONTROL_CENTER_R28_BRIDGE_V1_9_22_BACKEND_V1_4_6.exe"
go build -trimpath -ldflags "-H windowsgui" -o $Out main.go
Write-Host "Compilation terminee : Aether Control V2.3.2R28 / Bridge V1.9.22 / Private Backend V1.4.6 / clean AppData workspace / Backend Startup Truth / Windows GUI."
