# Build R28 Windows — archive de source

Cette archive contient le code Go / Python et le `payload.zip` embarqué, ainsi que les tests. Elle ne nécessite aucune connexion à GitHub et ne télécharge aucun composant à la compilation.

Depuis le dossier `source` sur une machine de développement contrôlée, Go installé :

    GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-H windowsgui" -o ATLAS_CRYPTO_BRIDGE_CONTROL_CENTER_R28.exe main.go

Le binaire R27 n'est pas utilisé. Sous Windows, `source/BUILD_WINDOWS.ps1` fournit la commande équivalente, sans contournement de la politique d'exécution Windows.

Voir `R28_SECURITY_AND_ROLE_INTEGRATION.md` pour les vérifications et les limites de sécurité.
