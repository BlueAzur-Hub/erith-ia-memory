# OKX — lecture privée contrôlée

La couche Aether Trust protège les consultations privées sur `127.0.0.1:8787`.
Identifiants d'API chiffrés avec Windows DPAPI, permissions `Read` uniquement.
Le Bridge n'a **aucune route permettant de négocier, transférer ou retirer**.

## Routes existantes

- `GET /okx/status` : configuration et capacités, pas de secret.
- `GET /okx/account` : soldes Funding et Trading.
- `GET /okx/orders` : ordres Spot.
- `GET /okx/fills` : transactions Spot.
- `GET /okx/fees?instId=BTC-USDC` : barème du compte pour un marché.

## Lecture financière — nouveau

`GET /okx/ledger?ccy=BTC&pages=1`

Le résultat sépare explicitement deux sources :

- `trading_account` : `GET /api/v5/account/bills-archive` (journal Trading, fenêtre des 3 mois selon OKX).
- `funding_account` : `GET /api/v5/asset/bills-history` (journal Funding, historique publié par OKX depuis 2021, selon disponibilités du compte et de la région).

Interroger indépendamment `ccy=BTC` **puis** `ccy=EUR` pour rechercher des écritures dans les deux monnaies. Une requête ne consulte qu'une devise. `pages=1` à `pages=3`, soit au maximum 300 écritures par source et par appel ; les réponses signalent explicitement `has_more`.

**Important :** une écriture de transfert BTC ne prouve pas à elle seule le prix payé en EUR ni le moyen de paiement PayPal. `acquisition_cost_proven`, `origin_of_funds_proven` et `eur_paypal_purchase_proven` demeurent `false` tant que les justificatifs nécessaires n'ont pas été rapprochés. Ne jamais calculer des gains sur une origine non prouvée.

Chaque source peut échouer séparément (permissions, disponibilité EEA, rate limit), sans masquer l'autre. Les messages d'erreur transmis au navigateur sont génériques pour éviter d'exposer des éléments privés. Les détails des écritures ne sont ni envoyés à GitHub ni stockés dans le navigateur par cette route.

La route exige le jeton **owner** Aether Trust ; les rôles operator/reader n'y ont pas accès.

## Vérification sur poste Windows

1. Fermer le Bridge précédent depuis Aether Control ; puis ouvrir le nouvel exécutable.
2. Vérifier Bridge 1.9.16 dans Aether Control ; aucune nouvelle clé API ne doit être demandée si le stockage local DPAPI existe déjà.
3. Se reconnecter à Aether Trust si nécessaire, puis vérifier le Trader (soldes inchangés).
4. Examiner les journaux BTC et EUR via la nouvelle route locale authentifiée, ou attendre son raccordement à un contrôle de lecture humain côté Trader. **Ne pas partager dans un chat le jeton Bearer, les clés API ou les réponses privées brutes.**
5. Si le journal ne contient pas la preuve d'achat PayPal, utiliser l'historique officiel OKX « Acheter des cryptos » ou son justificatif validé ; ne pas inventer de correspondance.

## Précisions

- Aucune modification du Trader, des graphiques, du Coffre ou du Backend public 8790.
- Anciennes routes et structure des réponses préservées.
- Réponse JSON du nouveau lecteur conçue pour une consommation future par le Trader ; **pas encore raccordée à l'affichage des résultats financiers.**
- Le code Python peut être vérifié hors ligne par `python bridge.py --self-test` et `python test_okx_ledger.py`.

Documentation officielle : https://www.okx.com/docs-v5/en/


## Devise de prélèvement des frais Spot — lecture seule

Nouvelle route propriétaire : `GET /okx/fee-type` (Bridge 1.9.18).

Elle lit uniquement `GET /api/v5/account/config`, puis ne renvoie
au navigateur que : `fee_type`, `fee_currency_for_spot_buy_ct_usdc`,
`fetched_at`, `read_only` et des indicateurs de preuve.
Aucun identifiant de compte, clé API, permission globale ou réponse privée brute.

- `fee_type=0` : frais prélevés dans la devise **reçue** ; pour un
  achat Spot CT/USDC, ce sont des CT.
- `fee_type=1` : frais prélevés dans la devise de **cotation** ;
  pour un achat Spot CT/USDC, ce sont des USDC.
- Valeur absente, API refusée, réponse non conforme : route `503`,
  aucune valeur par défaut présumée.

La route est **owner uniquement** sous Aether Trust et n'expose pas
la possibilité de changer le paramètre. Le `POST /api/v5/account/set-fee-type`
reste **interdit**. On ne certifie pas les arrondis/fills ou les contraintes
d'un ordre à partir de ce seul booléen. Aucune donnée secrète dans GitHub.

Hors ligne : `python test_okx_fee_type.py`. Pas de test du compte
réel sur cette machine ; vérification Windows/Firefox à faire sur le poste
avec un Bridge R24 démarré, jamais simultanément avec R23.

## R25 — contrôles Spot CT/USDC préalables à un ordre (GET uniquement)

Nouvelle route propriétaire `GET /okx/order-gates?instId=CT-USDC` (Bridge 1.9.19),
accessible via Aether Trust propriétaire. Lectures OKX privées `/account/instruments`,
`/account/max-avail-size` et `/account/max-size` (tdMode cash), et lectures
publiques `/public/instruments` et `/public/price-limit`.

Le Bridge ne renvoie **que** l'identité CT-USDC, les plafonds, les bornes et des
indicateurs de vérification. Il ne renvoie pas les identifiants du compte, les
clés, les autorisations brutes, les positions ou les flux comptables.

**Important :** `CT-USD` ne devient pas silencieusement `CT-USDC` ; les régions
ayant migré vers des instruments USD avec `tradeQuoteCcy=USDC` nécessiteront
une qualification explicite distincte. Les autres paires sont refusées.

Le Bridge conserve une clé **Read** et n'expose **aucun POST Trade**. Il
ne peut pas passer d'ordre à ce stade. La future capacité de transmission
réelle nécessitera des autorisations Trade distinctes, un contrôle humain
explicite et une livraison séparée.
