"""Offline-only security and correctness checks for GET /okx/fee-type."""
import unittest
from unittest.mock import patch
import bridge

class ReadOnlyFeeType(unittest.TestCase):
    def test_fee_type_zero(self):
        with patch.object(bridge, "okx_private_get", return_value={"code":"0","data":[{"feeType":"0","uid":"SECRET","mainUid":"SECRET","perm":"trade","apiKey":"SECRET"}]}) as get:
            result=bridge.okx_fee_type_payload()
        get.assert_called_once_with("/api/v5/account/config")
        self.assertEqual(result["fee_type"],"0")
        self.assertEqual(result["fee_currency_for_spot_buy_ct_usdc"],"CT")
        self.assertEqual(result["scope"],"spot_fee_currency_mode_for_account")
        self.assertFalse(result["orders_enabled"])
        self.assertFalse(result["fee_amount_and_rounding_verified"])
        self.assertFalse(any(k in result for k in ("uid","mainUid","perm","apiKey","ip","acctLv")))
        self.assertNotIn("SECRET",str(result))

    def test_fee_type_one(self):
        with patch.object(bridge, "okx_private_get", return_value={"code":"0","data":[{"feeType":"1","uid":"SECRET"}]}):
            result=bridge.okx_fee_type_payload()
        self.assertEqual(result["fee_type"],"1")
        self.assertEqual(result["fee_currency_for_spot_buy_ct_usdc"],"USDC")

    def test_invalid_fail_closed(self):
        for payload in ({},{"data":[]},{"data":{}},{"data":[{}]},{"data":[{"feeType":""}]},{"data":[{"feeType":"2"}]},{"data":[{"feeType":0}]},{"data":[{"feeType":"0"},{"feeType":"1"}]}):
            with self.subTest(payload=payload),patch.object(bridge,"okx_private_get",return_value=payload):
                with self.assertRaises(ValueError):bridge.okx_fee_type_payload()

    def test_owner_only(self):
        p=bridge.ROUTE_CAPABILITY
        self.assertIn("/okx/fee-type", bridge.AUTH_PRIVILEGED_GET)
        self.assertEqual(p["/okx/fee-type"],"okx.fee_type.read")
        self.assertIn("okx.fee_type.read",bridge.CAPABILITY_POLICY["owner"])
        for role in ("reader","operator"):
            self.assertNotIn("okx.fee_type.read",bridge.CAPABILITY_POLICY[role])

    def test_read_only_exact_allowlist(self):
        self.assertIn("/api/v5/account/config",bridge.OKX_PRIVATE_READ_PATHS)
        self.assertEqual(bridge.okx_build_request_path("/api/v5/account/config"),"/api/v5/account/config")
        for forbidden in ("/api/v5/account/set-fee-type","/api/v5/trade/order", "/api/v5/account/withdrawal"):
            with self.assertRaises(ValueError):bridge.okx_build_request_path(forbidden)

if __name__=="__main__":
    unittest.main(verbosity=2)
