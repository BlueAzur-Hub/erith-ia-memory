"""Offline verification of the /conclusion HTTP envelope. No sockets or private data."""
import io
import json
from pathlib import Path
from unittest.mock import patch
import importlib.util

spec = importlib.util.spec_from_file_location("atlas_bridge_r28", Path(__file__).with_name("bridge.py"))
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)
CONFIG = json.loads(Path(__file__).with_name("bridge_config.json").read_text(encoding="utf-8"))

class FakeBridge(bridge.BridgeHandler):
    def __init__(self, route: str, data: bytes):
        self.path = route
        self.headers = {"Content-Length": str(len(data))}
        self.rfile = io.BytesIO(data)
        self.results = []
        self.message_log = []

    @property
    def config(self):
        return CONFIG

    def require_authenticated(self, route):
        return {"role": "owner"}

    def send_json(self, status, result):
        self.results.append((status, result))
        return True

    def log_message(self, fmt, *args):
        self.message_log.append(fmt % args)


def verify():
    basic_contract = {
        "schema": "atlas_crypto_fact_contract_v2",
        "canonical_top5": {"symbols": ["BTC", "ETH", "BNB", "XRP", "SOL"], "complete": False, "assets": []},
        "rules": {name: True for name in (
            "market_list_is_not_portfolio", "no_missing_value_to_zero", "no_visual_position_inference",
            "no_unlisted_math_measure", "no_news_from_generic_limit", "no_financial_instruction")},
    }
    reports = {mode: {"answer": "Compte rendu prudent. " * 15, "fingerprint": "same"}
               for mode in bridge.CONCLUSION_REPORT_MODES}
    payload = {
        "profile": "aerith", "snapshot": {"strict_contract": basic_contract, "padding": "x" * 280000},
        "report_modes": list(bridge.CONCLUSION_REPORT_MODES),
        "reports": reports, "report_fingerprint": "same", "pedagogy_contract": {},
    }
    encoded = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    assert 270000 < len(encoded) < CONFIG['generation']['max_conclusion_body_bytes'], len(encoded)
    with patch.object(bridge, "choose_provider", return_value=("ollama", "local")), \
         patch.object(bridge, "call_model_comment", return_value={"used": False, "warnings": []}), \
         patch.object(bridge, "build_aerith_conclusion", return_value="Conclusion déterministe conservée"):
        accepted = FakeBridge("/conclusion", encoded)
        accepted.do_POST()
        assert accepted.results[0][0] == 200, accepted.results
        assert accepted.results[0][1]['source_reports'] == 4
        assert any('CONCLUSION_BODY_ACCEPTED' in row for row in accepted.message_log)
        observed = FakeBridge("/summary", encoded)
        observed.do_POST()
        assert observed.results[0][0] == 200, observed.results
        rejected = FakeBridge("/summary", b"x" * (CONFIG['generation']['max_observation_body_bytes'] + 1))
        rejected.do_POST()
        assert rejected.results[0][0] == 400
        assert 'trop volumineux' in rejected.results[0][1]['error']
        too_big = FakeBridge("/conclusion", b"x" * (CONFIG['generation']['max_conclusion_body_bytes'] + 1))
        too_big.do_POST()
        assert too_big.results[0][0] == 400
        assert 'trop volumineux' in too_big.results[0][1]['error']
        assert any('CONCLUSION_BODY_REJECTED' in row for row in too_big.message_log)
        empty = FakeBridge("/conclusion", b"")
        empty.do_POST()
        assert empty.results[0][0] == 400
        assert 'vide' in empty.results[0][1]['error']
        broken = FakeBridge("/conclusion", b"not json")
        broken.do_POST()
        assert broken.results[0][0] == 400
        assert 'JSON invalide' in broken.results[0][1]['error']
    print('PASS: /conclusion 280 KiB+ accepted with 4 fingerprint-matched reports')
    print('PASS: /summary R28 512 KiB transport limit and hard ceiling')
    print('PASS: /conclusion oversized, empty and bad JSON rejected')
    print('PASS: only byte counts in diagnostic logs')

if __name__ == '__main__':
    verify()
