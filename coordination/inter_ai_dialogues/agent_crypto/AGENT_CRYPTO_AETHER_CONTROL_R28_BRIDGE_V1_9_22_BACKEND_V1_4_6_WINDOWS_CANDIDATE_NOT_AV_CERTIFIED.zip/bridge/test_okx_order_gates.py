"""Offline tests for authenticated, read-only Spot account/instrument limits."""
import unittest
from unittest.mock import patch
import bridge

INST={"code":"0","data":[{"instId":"CT-USDC","instType":"SPOT","baseCcy":"CT","quoteCcy":"USDC","state":"live","tradeQuoteCcyList":["USDC"],"minSz":"10","lotSz":"0.01","tickSz":"0.0001","maxLmtSz":"900","maxLmtAmt":"1000"}]}
AV={"code":"0","data":[{"instId":"CT-USDC","availBuy":"3.2","availSell":"0"}]}
MX={"code":"0","data":[{"instId":"CT-USDC","maxBuy":"10.11","maxSell":"0"}]}
PR={"code":"0","data":[{"instId":"CT-USDC","buyLmt":"0.45","sellLmt":"0.21"}]}

def private(path,params=None):
    if path=="/api/v5/account/instruments":return INST
    if path=="/api/v5/account/max-avail-size":return AV
    if path=="/api/v5/account/max-size":return MX
    raise AssertionError("Unexpected endpoint "+path)

def public(path,params):
    if path=="/api/v5/public/instruments":return INST
    if path=="/api/v5/public/price-limit":return PR
    raise AssertionError("Unexpected endpoint "+path)

class OrderGates(unittest.TestCase):
    def good(self,private_fn=private,public_fn=public):
        with patch.object(bridge,'okx_private_get',side_effect=private_fn),patch.object(bridge,'okx_public_get',side_effect=public_fn):
            return bridge.okx_order_gates_payload()
    def test_success_no_private_leak(self):
        r=self.good()
        for k in ('eligibility_verified','available_verified','account_max_verified','public_rules_verified','price_limits_verified'):
            self.assertTrue(r[k],k)
        self.assertEqual(r['availBuy'],'3.2')
        self.assertEqual(r['availSell'],'0')
        self.assertEqual(r['minSz'],'10')
        self.assertEqual(r['buyLmt'],'0.45')
        self.assertFalse(r['orders_enabled'])
        self.assertFalse(any(k in r for k in ('apiKey','uid','perm','account','token')))
    def test_wrong_pair_fail_closed(self):
        with self.assertRaises(ValueError):bridge.okx_order_gates_payload('CT-USDT')
        def wrong(path,params=None):
            if path=="/api/v5/account/instruments":return {'code':'0','data':[{**INST['data'][0],'instId':'CT-USD'}]}
            return private(path,params)
        r=self.good(wrong)
        self.assertFalse(r['eligibility_verified'])
        self.assertIsNone(r['availBuy'])
    def test_quote_list_refuses_usdc(self):
        def wrong(path,params=None):
            if path=="/api/v5/account/instruments":return {'code':'0','data':[{**INST['data'][0],'tradeQuoteCcyList':['USD']}]}
            return private(path,params)
        r=self.good(wrong)
        self.assertFalse(r['eligibility_verified'])
    def test_fail_closed_private_availability(self):
        def wrong(path,params=None):
            if path=="/api/v5/account/max-avail-size":return {'code':'0','data':[{"instId":"CT-USD","availBuy":"3.2","availSell":"0"}]}
            return private(path,params)
        r=self.good(wrong)
        self.assertTrue(r['eligibility_verified'])
        self.assertFalse(r['available_verified'])
        self.assertIsNone(r['availBuy'])
    def test_no_post_and_capability_scope(self):
        self.assertIn('/okx/order-gates',bridge.AUTH_PRIVILEGED_GET)
        self.assertEqual(bridge.ROUTE_CAPABILITY['/okx/order-gates'],'okx.order_gates.read')
        self.assertIn('okx.order_gates.read',bridge.CAPABILITY_POLICY['owner'])
        self.assertNotIn('okx.order_gates.read',bridge.CAPABILITY_POLICY['operator'])
        self.assertNotIn('okx.order_gates.read',bridge.CAPABILITY_POLICY['reader'])
        self.assertNotIn('/okx/order-gates',bridge.AUTH_PRIVILEGED_POST)
        self.assertFalse(any('order-gates' in x for x in bridge.OKX_PRIVATE_READ_PATHS))
        for path in ('/api/v5/trade/order','/api/v5/trade/order-precheck','/api/v5/account/set-fee-type'):
            with self.assertRaises(ValueError):bridge.okx_build_request_path(path)
    def test_bad_decimals(self):
        for bad in ('-1','Infinity','1e9','0003','3.2 USDC',3.2,None,'1.2.3'):
            self.assertIsNone(bridge.okx_spot_decimal(bad))
    def test_partial_source_failures(self):
        def wrong(path,params):
            if path=="/api/v5/public/price-limit":raise OSError('mock offline')
            return public(path,params)
        r=self.good(public_fn=wrong)
        self.assertTrue(r['public_rules_verified'])
        self.assertFalse(r['price_limits_verified'])
        self.assertIsNone(r['buyLmt'])
if __name__=='__main__':unittest.main(verbosity=2)
