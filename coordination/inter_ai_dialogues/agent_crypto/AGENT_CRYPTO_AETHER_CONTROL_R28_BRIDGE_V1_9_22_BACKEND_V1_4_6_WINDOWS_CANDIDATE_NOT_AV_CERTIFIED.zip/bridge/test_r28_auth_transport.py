"""R28 isolated local tests. No OKX, Ollama, remote requests, or subprocesses."""
from pathlib import Path
import importlib.util
import tempfile
import io
import json
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('aether_bridge_r28', Path(__file__).with_name('bridge.py'))
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)

class Envelope(bridge.BridgeHandler):
    def __init__(self, raw: bytes):
        self.headers = {'Content-Length': str(len(raw))}
        self.rfile = io.BytesIO(raw)
        self.server = type('FakeServer', (), {'config': {'generation': {'max_snapshot_chars':250000}}})()


def main():
    with tempfile.TemporaryDirectory(prefix='aether-r28-') as directory:
        with patch.object(bridge, 'AUTH_OPERATOR_PATH', Path(directory) / 'operator.json'), patch.object(bridge, 'AUTH_PATH', Path(directory) / 'owner.json'), patch.object(bridge, 'LEGACY_AUTH_PATH', Path(directory) / 'legacy.json'):
            bridge.auth_register('OwnerSecret123!')
            bridge.auth_operator_register('OperatorSecret123!')
            assert bridge.auth_verify('OwnerSecret123!')
            assert not bridge.auth_verify('OperatorSecret123!')
            assert bridge.auth_operator_verify('OperatorSecret123!')
            assert not bridge.auth_operator_verify('OwnerSecret123!')
            try:
                bridge.auth_operator_register('SomethingElse12')
                raise AssertionError('Operator overwrite must fail')
            except ValueError:
                pass
            assert bridge.CAPABILITY_POLICY['operator'].isdisjoint({'security.read','okx.account.read','okx.orders.read','okx.ledger.read','book_mirror.publish','oracle_evidence.publish'})
            assert bridge.ROUTE_CAPABILITY['/capabilities'] is None
            operator = bridge.auth_session_create('operator')
            assert operator['persistent'] is False
            assert operator['expires_at'] is not None
            assert 'security.read' not in operator['capabilities']
            bridge.auth_session_revoke(operator['token'])
            assert bridge.auth_session_get(operator['token']) is None
    small = json.dumps({'padding':'A' * 280_000}).encode()
    assert len(small) > 270_000 and len(small) < 524288
    assert Envelope(small).read_body(max_bytes=524288)['padding'].startswith('AAA')
    try:
        Envelope(b'A'*524289).read_body(max_bytes=524288)
        raise AssertionError('R28 must reject requests above its hard cap')
    except ValueError as e:
        assert 'trop volumineux' in str(e)
    print('PASS: R28 Owner/Operator separate verifiers; no escalation; Operator TTL; deny Owner-only capabilities')
    print('PASS: R28 HTTP envelope 280000+ accepted, 524289 rejected; local tests only')

if __name__=='__main__':main()
