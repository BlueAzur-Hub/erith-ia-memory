"""Bounded loopback integration test. No exchange API, model, internet or file publish."""
from pathlib import Path
from unittest.mock import patch
import importlib.util
import tempfile, json, threading, urllib.request, urllib.error

spec=importlib.util.spec_from_file_location('bridge_under_test',Path(__file__).with_name('bridge.py'))
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ORIGIN='https://blueazur-hub.github.io'

def main():
  with tempfile.TemporaryDirectory(prefix='r28-http-') as tmp:
    root=Path(tmp)
    with patch.object(b,'TRUST_ROOT',root), patch.object(b,'AUTH_PATH',root/'owner.json'), patch.object(b,'AUTH_OPERATOR_PATH',root/'operator.json'), patch.object(b,'LEGACY_AUTH_PATH',root/'legacy.json'), patch.object(b,'SECURITY_AUDIT_PATH',root/'audit.jsonl'):
      b.auth_register('OwnerSecret123456')
      config=b.load_config()
      server=b.BridgeServer(('127.0.0.1',0),b.BridgeHandler,config)
      runner=threading.Thread(target=server.serve_forever,daemon=True);runner.start()
      url=f'http://127.0.0.1:{server.server_port}'
      def request(path,method='GET',token='',body=None):
        heads={'Origin':ORIGIN}
        if token:heads['Authorization']='Bearer '+token
        if body is not None:heads['Content-Type']='application/json'
        data=json.dumps(body).encode() if body is not None else None
        req=urllib.request.Request(url+path,method=method,data=data,headers=heads)
        try:
          with urllib.request.urlopen(req,timeout=4) as f:return f.status,json.loads(f.read())
        except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
      try:
        status,owner=request('/auth/login','POST',body={'role':'owner','secret':'OwnerSecret123456'})
        assert status==200 and owner['role']=='owner',(status,owner)
        ot=owner['token']
        assert request('/auth/operator/register','POST',body={'secret':'OperatorSecret123456'})[0]==403
        assert request('/auth/operator/register','POST',ot,body={'secret':'OperatorSecret123456'})[0]==200
        status,operator=request('/auth/login','POST',body={'role':'operator','secret':'OperatorSecret123456'})
        assert status==200 and operator['role']=='operator',(status,operator)
        kt=operator['token']
        assert request('/auth/login','POST',body={'role':'owner','secret':'OperatorSecret123456'})[0]==401
        assert request('/auth/login','POST',body={'role':'operator','secret':'OwnerSecret123456'})[0]==401
        assert request('/auth/login','POST',body={'role':'reader','secret':'OwnerSecret123456'})[0]==400
        assert request('/auth/register','POST',body={'role':'operator','secret':'BadSetup12345'})[0]==403 or b.auth_state_read() is not None
        assert request('/capabilities')[0]==401
        status,caps=request('/capabilities',token=kt)
        assert status==200 and caps['role']=='operator' and 'security.read' not in caps['capabilities']
        assert request('/security/status',token=kt)[0]==403
        assert request('/okx/account',token=kt)[0]==403
        assert request('/oracle-evidence/ingest','POST',kt,body={'test':'forbidden'})[0]==403
        assert request('/capabilities',token=ot)[1]['role']=='owner'
        assert request('/auth/status')[1]['operator_configured'] is True
        assert request('/auth/logout','POST',kt,body={})[0]==200
        assert request('/capabilities',token=kt)[0]==401
        # Simulate a fresh Operator-only machine: no Owner verifier exists.
        (root/'owner.json').unlink()
        assert request('/auth/register','POST',body={'role':'owner','secret':'UnauthorizedOwner123'})[0]==403
      finally:server.shutdown();runner.join(timeout=3);server.server_close()
  print('PASS: HTTP Owner/Operator login, registration Owner-only, no role escalation, capabilities, OKX read refusal, Operator-only bootstrap guard, logout')

if __name__=='__main__':main()
