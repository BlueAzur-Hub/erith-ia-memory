# ERITH.IA — Aether Control R28 · Bridge 1.9.22 · Backend 1.4.6

**Statut : CANDIDAT NON VALIDÉ SUR WINDOWS / FIREFOX.**

Ce paquet est une reconstruction depuis les sources du R26 fournies par l'utilisateur. Il n'utilise ni ne restaure le binaire R27 mis en quarantaine par Microsoft Defender. La nouvelle compilation Windows n'a PAS été analysée par Microsoft Defender dans cet environnement ; elle ne peut pas être déclarée exempte de malware.

## Ce qui a effectivement été modifié

- Limite HTTP de `/summary`, `/chat`, `/scanner-snapshot` portée à **524 288 octets**. Borne stricte par route. `/conclusion` garde sa limite configurable de 524 288 octets, avec plafond absolu de 1 MiB ; authentification reste à 16 384 octets. Le nombre de caractères autorisés dans le snapshot factuel et la génération LLM ne changent pas.
- Aether Trust : `owner` et `operator` ont désormais deux vérificateurs de mots de passe indépendants dans le dossier de confiance local. Le mot de passe Owner ne devient jamais automatiquement un mot de passe Operator.
- `POST /auth/login` : `{"role":"owner","secret":"..."}` ou `{"role":"operator","secret":"..."}`. L'absence de rôle signifie `owner` pour compatibilité. Les réponses indiquent le rôle réellement authentifié.
- `POST /auth/operator/register` : possible uniquement depuis une session `owner` déjà authentifiée, et une origine autorisée ; enregistrement initial uniquement. Alternative locale : `python bridge/bridge.py --configure-operator` sur le PC concerné, sans navigateur ni accès réseau. Sur un PC configuré d’abord en Operator, toute création Owner par formulaire web est refusée ; seule la commande locale explicite `python bridge/bridge.py --configure-owner` peut alors installer un Owner. Aucune rotation automatique ou écrasement des identifiants existants.
- `GET /auth/status` : indique `configured` (Owner) et `operator_configured`. `GET /capabilities` : accessible uniquement après authentification, donne seulement les autorisations du rôle connecté.
- La session Operator expire après 12 heures ; la session Owner conserve sa politique historique (jusqu'à déconnexion/redémarrage du Bridge). Les limites de tentatives et les vérifications d'origine demeurent.
- La compilation Go ne passe plus `-ExecutionPolicy Bypass` à PowerShell. Elle n'arrête plus automatiquement un backend d'une autre version lorsqu'un conflit est identifié ; elle demande une intervention explicite. Elle conserve le contrôle du démarrage/arrêt de ses propres processus.
- Permissions de trading/rétrait **non ajoutées**, routes OKX Owner lecture seule préservées, backend 1.4.6 inchangé, secrets OKX préexistants non inclus.

## Ce qui n'est PAS achevé

**Les deux portes de connexion ne sont pas encore raccordées dans les deux interfaces web publiées.** Ces pages doivent envoyer le rôle sélectionné, conserver le jeton en mémoire, consulter `/auth/status` et `/capabilities`, refuser les routes Owner en contexte Operator, et vérifier la réalité du Bridge (pas une simple `?view=intermediate`). Aucun fichier GitHub, Administrator, Operator ou Trader n'a été modifié dans cette livraison.

**Operator ne dispose pas encore de ses propres routes OKX privées :** le R28 n'élargit pas les permissions Owner. Avant de donner le même niveau fonctionnel aux deux éditions, il faut isoler les identifiants OKX par profil et vérifier les autorisations côté Bridge. La similitude de l'interface n'accorde aucun privilège.

## Vérifications réalisées dans l'environnement de construction

- Contrôle de syntaxe Python (`py_compile`) : PASS.
- `bridge.py --self-test` : PASS.
- `test_r28_auth_transport.py` : PASS (vérificateurs séparés, sessions, plafonds de réception).
- `test_r28_http_roles.py` : PASS (tests HTTP locaux des deux rôles, interdiction d’escalade, refus OKX, déconnexion).
- `verify_conclusion_envelope.py` : PASS (280 Kio+, limite 512 Kio, rejets JSON invalides).
- `test_atlas_singleflight.py` : PASS (5 cas).
- `test_okx_ledger.py` : PASS (19 contrôles).
- `test_okx_fee_type.py` : PASS (5 cas).
- `test_okx_order_gates.py` : PASS (7 cas).
- `private_backend.py --self-test` : PASS.
- Compilation Windows Go : voir le journal de construction joint.

## Important — sécurité Windows

- Ne pas restaurer le R27 signalé par Defender.
- Ne pas désactiver Defender ni créer d'exclusion pour installer R28.
- Une compilation source locale et des empreintes SHA-256 vérifiées **ne prouvent pas** qu'un binaire est sans malware. Avant exécution Windows, procéder aux contrôles de sécurité habituels ; si Defender bloque R28, **ne pas le forcer**.
- Aucun scan hors connexion Windows ni réinstallation n'est requis par ce paquet. Le conseil d'exécuter une analyse hors connexion était une proposition de prudence, pas un prérequis au développement R28.

## Mémoire et migration

L'installation crée un répertoire distinct `2.3.2R28`. La mémoire de confiance Owner reste dans le dossier persistant existant (`%LOCALAPPDATA%\\ERITH.IA\\AtlasCryptoBridge\\trust`). Le nouveau vérificateur Operator est dans ce même dossier sous un nom séparé. Aucun historique ni identifiant ne doit être effacé ni publié.
