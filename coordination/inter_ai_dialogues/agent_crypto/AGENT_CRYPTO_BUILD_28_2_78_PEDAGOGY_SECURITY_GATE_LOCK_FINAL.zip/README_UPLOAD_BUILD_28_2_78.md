# Upload — Agent-Crypto Build 28.2.78

## Version

`Market Core V2.0-Alpha · Build 28.2.78 · PEDAGOGY SECURITY GATE LOCK`

## Base

Build canonique 28.2.77.

## Remplacement

Remplacer uniquement les quatre fichiers suivants :

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Ne supprimer aucun autre fichier et ne modifier ni workflow, ni collecteur, ni Bridge.

## Après publication

1. ouvrir la page publique dans Firefox ;
2. effectuer un rechargement forcé ;
3. vérifier l’identité Build 28.2.78 ;
4. ouvrir Administration → Simulation ;
5. charger l’exemple école et confirmer les hypothèses ;
6. simuler un achat BTC 5 € ;
7. tester les scénarios instantanés ;
8. ouvrir une info-bulle ;
9. vérifier le Security Gate ;
10. tester le retrait fictif et le Scam Sentinel ;
11. vérifier que le cartouche affiche `À JOUR` sans redimensionner le graphique.

## Sécurité

Aucune clé, aucun wallet, aucun ordre, aucun retrait et aucune écriture GitHub ne sont contenus dans le Build.
