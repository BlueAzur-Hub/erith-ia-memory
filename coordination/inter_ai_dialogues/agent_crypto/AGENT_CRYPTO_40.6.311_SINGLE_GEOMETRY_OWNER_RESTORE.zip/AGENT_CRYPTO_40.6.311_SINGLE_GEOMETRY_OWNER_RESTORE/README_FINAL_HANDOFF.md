# Agent-Crypto 40.6.311 — Aether Single Geometry Owner Restore

This package documents the surgical correction applied after the real Firefox failure of 40.6.310.

The correction does not add another CSS layer, migration key, geometry owner, timer, observer, or versioned runtime file.

It restores only the already-proven 40.6.306 presentation ownership for Aether on top of the 40.6.310 state:

- outer geometry removed from Aether presentation CSS;
- Window Manager remains the sole outer geometry owner;
- Aether is prepared while hidden and revealed only after floating geometry is applied;
- 40.6.310 app.js left-state reconciliation remains untouched.

The included screenshot is the 40.6.310 terrain FAIL that triggered this correction.

Final authority remains Christophe's Firefox terrain result.
