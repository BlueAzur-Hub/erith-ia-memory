AGENT-CRYPTO 40.6.312 — AETHER F11 FIELD RESTORE

Version commit:
cf8a94cd1e335d7150385cb82ca99bdce1aff6d2

Contract:
- Outside F11: preserve the current compact Aether at left x≈12.
- Browser F11: restore the field-validated 40.6.297 large 16:9 Aether field.
- Keep Lecture Technique visible at the right boundary.
- Leaving F11: restore the exact pre-F11 rectangle.
- F11 detection uses the reversible 40.6.307 frozen physical-screen reference.

Changed files:
- public/agent_crypto_erith_ia/administrator/js/app.js
- public/agent_crypto_erith_ia/administrator/js/core/admin-window-manager.js
- public/agent_crypto_erith_ia/administrator/build.json
- public/agent_crypto_erith_ia/administrator/index.html

Protected / untouched:
- Market Core 38.15.11
- Oracle
- Lecture Technique
- Strategy
- Storage schema
- Aether CSS outer geometry
