# Agent-Crypto 40.6.322 — Aether left-only default placement

Functional commit: f68f44af52a5ec389065c0cf2552eb5285194341
Parent recovery checkpoint: 40.6.321

Functional CSS diff only:
- left: 50% -> 12px
- transform: translate(-50%,-50%) -> translate(0,-50%)

Unchanged by design:
- top / vertical lane
- width / height / aspect ratio
- free resize
- free drag
- close/reopen default behavior
- F11 behavior
- js/app.js
- js/aether.js
- Window Manager
- Lecture Technique
- Market Core 38.15.11
- Oracle / Strategy / Storage

Local browser bench:
- 1920x948  => x=12, y=198.01, w=1333.31, h=749.98
- 1920x1080 => x=12, y=231.19, w=1450.00, h=815.62
- 1664x928  => x=12, y=198.01, w=1297.77, h=729.98
PASS: y/size/ratio preserved; horizontal translation only.
