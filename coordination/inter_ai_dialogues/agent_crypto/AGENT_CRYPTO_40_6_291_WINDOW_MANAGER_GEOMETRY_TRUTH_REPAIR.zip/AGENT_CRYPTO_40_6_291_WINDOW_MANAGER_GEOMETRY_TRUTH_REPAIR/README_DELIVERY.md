# Agent-Crypto 40.6.291 — Window Manager Geometry Truth Repair

Commit exact: `f8f67a068764b258400b2b6409ec4dbb7af72e7a`
Parent: `40.6.290`
Market Core: `38.15.11` (protégé, inchangé)

## Objet
Corriger le propriétaire géométrique canonique du Window Manager après le retour de la fenêtre native Aether en 40.6.290.

## Fichiers modifiés dans le commit
- `public/agent_crypto_erith_ia/administrator/js/core/admin-window-manager.js`
- `public/agent_crypto_erith_ia/administrator/runtime-shell.html`
- `public/agent_crypto_erith_ia/administrator/build.json`

Aucun nouveau fichier JS versionné n'a été créé.

## Corrections
- `geometryPolicy` n'est plus annulée par `min-width:0 / min-height:0 !important`.
- Les minima Aether 720 × 405 sont respectés tant que le viewport le permet.
- Le resize natif est borné par l'espace réellement disponible depuis la position courante.
- La largeur ET la hauteur réellement rendues sont conservées après resize.
- La géométrie clampée est réappliquée au DOM avant persistance.
- L'ancienne hauteur `win.geometry.height` ne peut plus écraser la nouvelle hauteur.
- L'état `hidden / minimized / floating / maximized / restore*` est persisté de façon cohérente.

## Preuves statiques / CI
- Parse JavaScript `admin-window-manager.js`: PASS.
- Parse `build.json`: PASS.
- ancien pattern de hauteur stale: absent.
- ancien override `min-width:0`: absent.
- Version Truth Guard: PASS.
- Version Delivery Guard: PASS.
- GitHub Pages build: PASS.
- GitHub Pages deploy: PASS.

## Terrain Firefox obligatoire
1. Vérifier `Build 40.6.291`.
2. Ouvrir Aether en état LIBRE.
3. Réduire sa taille depuis le coin inférieur droit.
4. L'agrandir de nouveau.
5. La déplacer près des quatre bords du viewport.
6. Refaire un resize : elle doit rester entièrement récupérable à l'écran.
7. Fermer / rouvrir : géométrie conservée.
8. Ctrl+F5 / rouvrir : géométrie conservée.
9. Agrandir / Restaurer : retour à la géométrie flottante précédente.

Storage reste PAUSÉ jusqu'au PASS terrain.

## Contenu du ZIP
Paquet de livraison reproductible : patch Git exact + manifeste de livraison + message de commit. Le commit `main` reste l'autorité des fichiers complets.
