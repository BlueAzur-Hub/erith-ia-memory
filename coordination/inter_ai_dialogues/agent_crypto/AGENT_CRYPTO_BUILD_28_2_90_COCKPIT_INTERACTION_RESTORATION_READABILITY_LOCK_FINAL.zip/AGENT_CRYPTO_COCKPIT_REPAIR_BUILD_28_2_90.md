# Agent-Crypto — Réparation du cockpit Build 28.2.90

## Base choisie

La réparation repart du **Build 28.2.88**, dernière base conservant l’état pédagogique validé :

- Module 01 compris ;
- Module 02 pratiqué et archivé ;
- Module 03 actif ;
- progression à 15 % ;
- récupération IndexedDB et réconciliation 28.2.88 conservées.

Le JavaScript consolidé de 28.2.89 n’est pas repris.

La seule partie conservée de 28.2.89 est sa couche CSS canonique du cockpit, car Christophe a confirmé que le texte était enfin plus lisible.

## Régression identifiée

La régression interactive avait été introduite avant 28.2.89 :

```html
<input type="checkbox" data-learning-step="read" disabled aria-disabled="true">
```

Les cinq commandes étaient rendues inactives dans le HTML, puis de nouveau verrouillées à chaque rendu JavaScript :

```javascript
input.disabled = true;
```

Le listener historique `change` avait également disparu.

## Correction appliquée

### HTML

Les attributs `disabled` et `aria-disabled` sont retirés des cinq cases de la session guidée.

### JavaScript

Pendant une session active :

```javascript
input.disabled = false;
input.removeAttribute("aria-disabled");
```

Pendant une session déjà archivée :

```javascript
input.disabled = true;
input.setAttribute("aria-disabled", "true");
```

Le listener est restauré une seule fois :

```javascript
document.querySelectorAll("[data-learning-step]").forEach(input => {
  input.addEventListener("change", () =>
    saveLearningStep(input.dataset.learningStep, input.checked)
  );
});
```

Le bouton **J’ai lu cette leçon intégrée** et le bouton d’action principale restent reliés à leurs contrôleurs existants.

### CSS

La couche lisible du cockpit 28.2.89 est conservée, avec une seule correction d’interaction :

- curseur cliquable sur les lignes actives ;
- curseur neutre uniquement lorsque la session est archivée.

## Périmètre non modifié

- schéma IndexedDB ;
- clés `localStorage` ;
- migration historique ;
- progression ;
- archives pédagogiques ;
- profils 100 € et 1 000 € ;
- Crypto ;
- Métaux ;
- Decision Board ;
- Bridge ;
- collecteurs ;
- workflows.

## Point de retour arrière

En cas d’anomalie, revenir au Build 28.2.88. Ne pas revenir au Build 28.2.89 rejeté.
