# Upload — Agent-Crypto Build 28.2.90

## Commit

```text
release agent-crypto build 28.2.90 cockpit interaction restoration readability lock
```

Le corps complet est fourni dans `GITHUB_COMMIT_BUILD_28_2_90.txt`.

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/README.md
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Ne pas modifier les répertoires de données, les collecteurs, les workflows, le Bridge ou les archives pendant cette publication.

## Contrôle après upload

1. Attendre la publication GitHub Pages.
2. Faire `Ctrl + F5` dans Firefox.
3. Vérifier `Build 28.2.90`.
4. Ouvrir le Cockpit d’apprentissage.
5. Vérifier que les cinq cases sont cliquables.
6. Cliquer sur la première case : le compteur doit passer de `0/5` à `1/5`.
7. Décocher : le compteur doit revenir à `0/5`.
8. Cliquer sur `Lire la leçon`, puis sur `J’ai lu cette leçon intégrée`.
9. Vérifier que la première case est cochée et que la prochaine action devient l’étape 2.
10. Recharger Firefox et vérifier que l’état est conservé.

## État attendu conservé

Sur le profil existant de Christophe :

- progression globale : 15 % ;
- Module 02 : Pratiqué ;
- Module 03 : actif ;
- notes et archives inchangées.

Ne pas terminer ni archiver le Module 03 pendant le contrôle initial.
