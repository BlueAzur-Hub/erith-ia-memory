# AGENT-CRYPTO — BUILD 28.2.76

## PUBLICATION IDENTITY SINGLE SOURCE LOCK — RAPPORT DE VÉRIFICATION FINAL

### 1. Identité

- Build : **28.2.76**
- Base exacte : **Build 28.2.75 — Public Crypto Market Archive Lock**
- Archive de base SHA-256 : `6f038a1cf32f76df5b4a683124ab1e191055996901d95eb6d98e6a9814fb9574`
- Portée : correction du contrôle de version et du chemin de mise à jour uniquement.
- GitHub : **aucune écriture effectuée par l’assistant**.

### 2. Défaut corrigé

Le fichier `style.css` du Build 28.2.75 contenait plusieurs couples historiques :

```text
ATLAS_ASSET_BUILD
ATLAS_ASSET_TOKEN
```

Le contrôleur 28.2.75 utilisait une recherche par première occurrence. Il lisait donc `28.2.74` avant le marqueur final `28.2.75`, puis déclarait la publication incomplète.

### 3. Correction appliquée

- un seul couple actif Build/token est placé au début de `style.css` ;
- les anciens marqueurs CSS deviennent `ATLAS_HISTORY_BUILD` et `ATLAS_HISTORY_TOKEN` ;
- les anciennes variables CSS actives deviennent des variables historiques non utilisées ;
- les variables runtime actives exposent uniquement `28.2.76` ;
- `index.html`, `app.js`, `style.css` et `version.json` portent exactement le même Build et le même token ;
- le nouveau vérificateur exige exactement un marqueur Build et un marqueur token par fichier ;
- toute duplication active future est rejetée explicitement.

### 4. Compatibilité avec la page 28.2.75 déjà chargée

Le parseur historique du Build 28.2.75 lit désormais, en première occurrence :

```text
index.html : 28.2.76
app.js     : 28.2.76
style.css  : 28.2.76
```

La publication 28.2.76 peut donc être reconnue comme cohérente par l’ancienne page, ce qui rétablit le bouton de mise à jour.

### 5. Fichiers remplacés

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

### 6. Vérifications automatisées

- contrôles exécutés : **47** ;
- contrôles validés : **47** ;
- échecs : **0**.

Contrôles principaux validés :

- syntaxe JavaScript avec `node --check` ;
- validité JSON de `version.json` ;
- unicité exacte des marqueurs actifs dans les trois fichiers ;
- compatibilité avec le parseur première-occurrence de la 28.2.75 ;
- détection et refus d’un marqueur actif dupliqué ;
- identité runtime complète `index/app/style = 28.2.76` ;
- contrôleur runtime en état `current` ;
- zéro erreur JavaScript pendant le test Chromium injecté ;
- séquence complète des identifiants HTML préservée ;
- nombre de sections HTML préservé ;
- corps visuel CSS restaurable octet pour octet après retrait des seules métadonnées d’identité ;
- collecteur Crypto, workflow Crypto et état du collecteur inchangés par rapport à la base 28.2.75.

### 7. Empreintes des quatre fichiers publics

```text
app.js       76d8fe704d6ac557753caa76d15c976d17dd13f4a9c1cf3eca69ba29c63ae569
index.html   f6465b75537643800d441df41117f25ae030c6b11dbfcafc2bb0b97a085cd1ae
style.css    e32f9caef4c74eecb025d4f52d165229e56b53f2e4cfa0e2e2fbff2cdc144baf
version.json 5cbb9abc46bd7aea18d1649b2d293afeb7f9952740cfe5ef3023a47a85ccbd17
```

### 8. Limites de validation

La propagation réelle GitHub Pages et le clic réel de mise à jour dans Firefox ne peuvent être validés qu’après ta publication. Le paquet ne modifie aucun fichier GitHub automatiquement.

### 9. Éléments préservés

- archive publique Crypto GitHub Actions du Build 28.2.75 ;
- prix live Binance ;
- historiques CoinGecko ;
- Decision Board et contrat de vérité 28.2.73 ;
- News Sentinel et Watchlist ;
- Math Core Crypto et Métaux ;
- interface et collecteur Métaux ;
- Control Center V2.1.0R1 ;
- Bridge V1.7.6 ;
- géométrie et identifiants de l’interface.
