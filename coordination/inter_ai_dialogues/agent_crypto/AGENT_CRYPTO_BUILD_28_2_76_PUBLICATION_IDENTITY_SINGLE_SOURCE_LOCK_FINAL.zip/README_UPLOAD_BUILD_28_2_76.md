# Agent-Crypto — installation du Build 28.2.76

## Objet

Correction ciblée du contrôleur de publication. Le Build 28.2.75 empilait plusieurs marqueurs actifs dans `style.css`; son contrôleur lisait le premier marqueur historique 28.2.74 et bloquait la mise à jour.

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Remplacer les quatre fichiers dans **le même commit**. Ne pas publier `version.json` seul avant les trois autres fichiers.

## Après publication

1. Attendre la fin du déploiement GitHub Pages.
2. Sur la page encore chargée en Build 28.2.75, cliquer sur le bandeau de version.
3. L’état attendu devient :

```text
Nouvelle version disponible · Build 28.2.76
```

4. Cliquer une seconde fois pour installer/recharger la publication cohérente.
5. En cas de cache Firefox persistant, utiliser `Ctrl+F5` une seule fois.

## État final attendu

```text
Market Core V2.0-Alpha · Build 28.2.76
```

Le bandeau `Publication Build 28.2.75 incomplète` ne doit plus apparaître après le chargement complet de la 28.2.76.

## Portée strictement préservée

Aucune modification du collecteur Crypto, du workflow GitHub Actions, des données Crypto, de Binance, des historiques CoinGecko, du domaine Métaux, du Decision Board, de News Sentinel, de Math Core, du Bridge ou de la géométrie visuelle.
