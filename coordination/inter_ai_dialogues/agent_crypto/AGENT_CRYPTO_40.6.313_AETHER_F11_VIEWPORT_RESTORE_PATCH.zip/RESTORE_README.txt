AGENT-CRYPTO 40.6.313 — AETHER F11 VIEWPORT RESTORE
Version commit: 42587041eb2c68ea0fb7ef0847369e4fd43a379d

Contract:
- Normal: preserve current compact Aether at left.
- F11 entry: restore field-validated 40.6.297 large 16:9 Aether (~1450x815 at 1920x1080), bounded by Lecture Technique.
- F11 exit: restore exact pre-F11 rectangle.
- Detection: 40.6.297/.298 viewport grow/shrink >48px.
- Geometry transaction: existing 40.6.298 Window Manager setGeometry API.

No CSS changed.
Market Core 38.15.11, Oracle, Lecture Technique, Storage and Strategy untouched.
