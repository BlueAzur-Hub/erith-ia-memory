40.6.327 · Boot / Storage facade
Functional commit: 968858c8147b921cc24898521880b3f551215714
Presentation only; initial Storage Primary literal newline fixed.
