# Agent-Crypto — Coordination inter-IA

Ce répertoire contient le contexte canonique de reprise du projet **Agent-Crypto @erith.IA**.

## Point d’entrée

Lire dans cet ordre :

1. `AGENT_CRYPTO_MASTER_STATE.md`
2. `AGENT_CRYPTO_NON_REGRESSION_LOCKS.md`
3. `AGENT_CRYPTO_BUILD_HISTORY.md`
4. `AGENT_CRYPTO_FIREFOX_TEST_CHECKLIST.md`
5. `AGENT_CRYPTO_THREAD_SUMMARY.md`

## Archives

### Version courante

`builds/current/AGENT_CRYPTO_BUILD_28_1_75_TARGETED_READABILITY.zip`

Cette archive contient exactement :

- `index.html`
- `style.css`
- `app.js`

### Retours arrière conservés

- Build 28.1.74 : migration du graphique Top 5 vers les chandelles Binance.
- Build 28.1.73 : correction du routage Market Flow vers CoinGecko.
- Build 28.1.72 : référence visuelle du tableau flottant inspiré de la Build 60.

Les versions rejetées ne sont pas stockées ici. Leur historique et leurs régressions sont documentés dans `AGENT_CRYPTO_BUILD_HISTORY.md`.

## Fil de discussion

Le fil complet n’est pas un document canonique : il contient des essais, erreurs, doublons et décisions annulées.

Le fichier `AGENT_CRYPTO_THREAD_SUMMARY.md` contient la synthèse utile pour la reprise.

Un export brut du fil peut être conservé dans `raw_thread/`, uniquement comme archive de provenance.
