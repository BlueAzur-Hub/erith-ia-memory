# Agent-Crypto — Synthèse du fil de travail

Ce document remplace le fil brut pour la reprise inter-IA.

## Décisions stabilisées

1. Les prix live des cinq cryptos principales viennent de Binance WebSocket.
2. Le tableau flottant montre uniquement les prix live, sans surcharge technique.
3. Target Top 5 reste visible sous le graphique.
4. Market Flow utilise CoinGecko.
5. Le marché global, le Top 250 et les scanners restent sur CoinGecko.
6. Les courbes du Top 5 ont été migrées vers les chandelles Binance dans la Build 28.1.74.
7. La Build 28.1.75 améliore uniquement la lisibilité ciblée.
8. Le mode Hausses 5 doit être revu plus tard, séparément.
9. Aucune modification du graphique ne doit être combinée avec une correction typographique ou une autre refonte.
10. Le projet exige une version cumulative à la fois et des retours arrière conservés.

## Problèmes rencontrés

- surcharge du tableau flottant ;
- masquage accidentel du Target Top 5 ;
- valeurs absentes affichées comme zéro ;
- mélange de sources mal expliqué ;
- Market Flow temporairement vide ;
- régressions visuelles successives ;
- texte trop petit dans les sections Administrateur ;
- confusion liée au zoom Firefox à 90 %.

## État actuel

- Build 28.1.75 présente sur le dépôt public ;
- interface jugée très jolie ;
- lisibilité ciblée améliorée ;
- graphique et Hausses 5 volontairement hors du dernier périmètre ;
- prochaine étude séparée : Hausses 5.

## Règle de reprise

Avant toute modification :

1. lire l’état maître ;
2. lire les verrous ;
3. identifier une seule correction ;
4. partir de la dernière archive autorisée ;
5. ne pas modifier les modules hors périmètre ;
6. produire l’audit et le SHA ;
7. attendre la validation Firefox réelle.
