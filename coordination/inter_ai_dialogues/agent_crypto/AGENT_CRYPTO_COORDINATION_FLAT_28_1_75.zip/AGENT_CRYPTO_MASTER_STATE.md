# Agent-Crypto — État maître

Version documentaire : 1.0  
Date : 27 juillet 2026  
Version applicative courante : **V2.0-alpha · Build 28.1.75**

## 1. Finalité

Agent-Crypto est un observatoire crypto prudent destiné à :

- afficher les prix réels du marché ;
- séparer les données live des historiques et archives ;
- comparer plusieurs actifs ;
- fournir des lectures descriptives sans présenter de conseil financier automatique ;
- conserver une interface premium bleu nuit, cyan et champagne ;
- préserver la validation humaine avant toute décision.

## 2. Architecture des sources

### Binance

Binance est utilisé pour le Top 5 :

- BTC/EUR ;
- ETH/EUR ;
- BNB/EUR ;
- XRP/EUR ;
- SOL/EUR.

Fonctions associées :

- tableau flottant `PRIX LIVE BINANCE` ;
- `TARGET TOP 5 LIVE` ;
- flux WebSocket des prix ;
- graphique historique Top 5 via chandelles Binance dans les Builds 28.1.74 et 28.1.75 ;
- cache Binance exact en cas d’échec temporaire ;
- paires EUR directes prioritaires ;
- repli dérivé possible par `crypto/USDT ÷ EURUSDT` lorsque la paire EUR directe est insuffisante.

### CoinGecko

CoinGecko reste utilisé pour le marché global :

- Market Flow ;
- Top 250 ;
- capitalisations ;
- classements ;
- Hausses 5 ;
- Baisses 5 ;
- Volumes 5 ;
- actifs hors Top 5 Binance ;
- snapshots et archives datées ;
- analyses globales.

### CoinMarketCap

CoinMarketCap n’est pas utilisé dans l’application actuelle.

## 3. Règle de vérité

Une donnée doit toujours indiquer implicitement ou explicitement :

- son actif ;
- sa monnaie ;
- sa source ;
- son état : live, direct, cache ou archive ;
- son horodatage lorsqu’il s’agit d’une donnée conservée.

Interdictions :

- transformer une valeur absente en `0,00 €` ;
- présenter une archive comme donnée live ;
- remplacer silencieusement une source par une autre ;
- fusionner un prix Binance et un historique CoinGecko sans l’indiquer ;
- modifier l’historique en injectant artificiellement le dernier prix spot.

## 4. État visuel validé

Le socle visuel comprend :

- header Agent-Crypto ;
- Livecheck ;
- navigation Essentiel / Administrateur ;
- Graphique Analyste pleine largeur ;
- Détail actif à droite, indépendant et repliable ;
- tableau flottant compact ;
- Target Top 5 Live sous le graphique ;
- Market Flow ;
- Market Snapshot ;
- Résumé multi-horizon ;
- News Sentinel ;
- Atlas Decision Board ;
- sections administratives repliables ;
- Sources ;
- Math Core ;
- Forge d’Aerith Pro ;
- pied de page technique.

La Build 28.1.75 ajoute uniquement une amélioration typographique ciblée à 100 % de zoom navigateur.

## 5. État des validations

### Validations statiques effectuées

- JavaScript validé par `node --check` ;
- 431 identifiants HTML uniques ;
- aucun doublon d’identifiant ;
- trois fichiers applicatifs à la racine de l’archive ;
- fonctions protégées inchangées lors du passage 28.1.74 vers 28.1.75 ;
- éléments protégés inchangés.

### Validation Firefox

Les captures utilisateur confirment notamment :

- prix Binance live visibles ;
- badge 5/5 ;
- tableau flottant fonctionnel ;
- Target Top 5 fonctionnel ;
- Market Flow rempli ;
- interface générale fonctionnelle.

Chaque nouvelle build doit cependant être vérifiée dans Firefox après upload GitHub Pages.

## 6. Version courante et retours arrière

### Courante

Build 28.1.75 — lisibilité ciblée.

### Retour arrière immédiat

Build 28.1.74 — même moteur et même architecture, avant le passage typographique.

### Retour arrière fonctionnel

Build 28.1.73 — Market Flow restauré, avant migration des courbes Top 5 vers Binance.

### Référence visuelle

Build 28.1.72 — tableau flottant restauré dans le style de la Build 60.

## 7. GitHub

Application publique :

`public/agent_crypto_erith_ia/web/`

Répertoire de coordination :

`coordination/inter_ai_dialogues/agent_crypto/`

La coordination ne remplace jamais les fichiers publics de l’application. Elle conserve le contexte, les archives, les audits et les règles de reprise.
