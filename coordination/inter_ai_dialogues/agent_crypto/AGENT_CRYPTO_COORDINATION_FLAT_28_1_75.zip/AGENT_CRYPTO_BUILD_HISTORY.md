# Agent-Crypto — Historique utile des builds

## Builds conservées

### 28.1.72 — Version 60 Tooltip Restore

Rôle :

- restauration du design compact du tableau flottant ;
- conservation du moteur Binance WebSocket ;
- suppression des textes parasites.

Statut :

- référence visuelle importante.

### 28.1.73 — Market Flow Source Restore

Rôle :

- Target Top 5 sur Binance ;
- Market Flow sur CoinGecko ;
- les messages Binance ne vident plus Market Flow ;
- archive CoinGecko datée affichable honnêtement.

Statut :

- base fonctionnelle de repli.

### 28.1.74 — Top 5 Binance Klines

Rôle :

- graphique Top 5 alimenté par les chandelles Binance ;
- paires EUR directes prioritaires ;
- repli dérivé `crypto/USDT ÷ EURUSDT` ;
- cache Binance séparé du cache CoinGecko ;
- marché global maintenu sur CoinGecko.

Statut :

- base technique de la version courante.

### 28.1.75 — Targeted Readability

Rôle :

- amélioration ciblée de la lisibilité à 100 % de zoom navigateur ;
- sections Administrateur ;
- Sources ;
- News Sentinel ;
- résumé multi-horizon ;
- Atlas Decision Board ;
- Market Snapshot ;
- pied de page.

Strictement inchangé :

- graphique ;
- Hausses 5 ;
- Target Top 5 ;
- Market Flow ;
- moteurs de données ;
- Détail actif ;
- Math Core ;
- Forge.

Statut :

- version courante.

## Builds rejetées ou non retenues comme bases

### 28.1.63

- ajout d’un tableau supplémentaire au-dessus du graphique ;
- surcharge visuelle.

### 28.1.64

- masquage destructif du Target Top 5 original.

### 28.1.65

- conversion de valeurs absentes en zéro ;
- états de vérité concurrents.

### 28.1.66

- architecture Gateway non déployée ;
- absence de solution live réellement opérationnelle.

### 28.1.68

- tableau flottant surchargé par des informations techniques.

### 28.1.69 à 28.1.71

- corrections successives du tooltip ;
- design progressivement éloigné de la Build 60.

Ces versions ne doivent pas être utilisées comme bases.
