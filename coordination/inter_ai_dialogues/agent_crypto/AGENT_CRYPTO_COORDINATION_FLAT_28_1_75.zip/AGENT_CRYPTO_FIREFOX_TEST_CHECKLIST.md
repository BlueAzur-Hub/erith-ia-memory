# Agent-Crypto — Checklist Firefox

À exécuter après chaque upload GitHub Pages.

## Chargement

- [ ] Ouvrir la page en Firefox.
- [ ] Vérifier le zoom à 100 %.
- [ ] Forcer un rechargement complet si nécessaire.
- [ ] Vérifier que la build affichée correspond à la build uploadée.

## Binance

- [ ] Le badge affiche `Prix live Binance · 5/5`.
- [ ] BTC, ETH, BNB, XRP et SOL affichent des valeurs non nulles.
- [ ] Les valeurs évoluent fréquemment.
- [ ] Le tableau flottant reste compact.
- [ ] Target Top 5 reste visible et cliquable.

## Graphique

- [ ] Top 5 charge cinq séries.
- [ ] Les périodes 24 h, 7 j, 30 j, 60 j, 90 j et 1 an fonctionnent.
- [ ] Le dernier graphique valide reste affiché en cas d’échec.
- [ ] Aucune valeur spot n’est ajoutée artificiellement à la fin d’une série.
- [ ] Le mode Hausses 5 n’est pas évalué dans une correction sans rapport.

## CoinGecko

- [ ] Market Flow reste rempli.
- [ ] Market Snapshot affiche les données du marché global.
- [ ] Une archive est marquée comme archive.
- [ ] Un échec CoinGecko ne crée pas de faux zéro.

## Lisibilité 28.1.75

- [ ] Titres des sections Administrateur lisibles.
- [ ] Descriptions des sections lisibles.
- [ ] Sources lisible.
- [ ] Decision Board lisible.
- [ ] Market Snapshot lisible.
- [ ] Aucun débordement ou chevauchement nouveau.

## Modules protégés

- [ ] Détail actif fonctionne.
- [ ] Math Core est intact.
- [ ] Forge d’Aerith Pro est intact.
- [ ] Le thème visuel est intact.
