# Agent-Crypto — Verrous de non-régression

Ces règles sont obligatoires pour toute nouvelle intervention.

## Interface protégée

Ne pas supprimer, déplacer ou remplacer sans demande explicite :

- le Target Top 5 original sous le graphique ;
- le tableau flottant compact ;
- le Graphique Analyste ;
- Détail actif ;
- Market Flow ;
- Market Snapshot ;
- Math Core ;
- Forge d’Aerith Pro ;
- la palette bleu nuit, cyan et champagne.

## Tableau flottant

Il doit conserver :

- l’identité des cinq cryptos ;
- les couleurs ;
- les prix live ;
- le style compact validé.

Ne pas ajouter dans ses lignes :

- `ACTUEL` ;
- `POINT` ;
- Base 100 ;
- source répétée ;
- date répétée ;
- historique ;
- texte technique parasite.

## Sources

- Top 5 live : Binance.
- Graphique Top 5 : Binance dans les Builds 28.1.74 et 28.1.75.
- Marché global : CoinGecko.
- Market Flow : CoinGecko.
- Hausses, Baisses et Volumes hors Top 5 : CoinGecko.
- Aucune utilisation actuelle de CoinMarketCap.

## Données

- Aucune valeur `null` convertie en zéro.
- Aucune interpolation synthétique des historiques.
- Aucun prix spot injecté dans une série historique.
- Dernier graphique valide conservé en cas d’échec.
- Archive toujours identifiée comme archive.
- Cache toujours identifié comme cache.
- Aucun repli silencieux d’une famille de source vers une autre.

## Méthode de livraison

Chaque build doit fournir :

- une version cumulative unique ;
- un ZIP contenant exactement `index.html`, `style.css`, `app.js` à la racine ;
- un audit JSON ;
- un SHA-256 ;
- un message de commit ;
- la distinction entre validation statique et test Firefox réel.

## GitHub

Ne jamais modifier GitHub sans autorisation explicite de Christophe.

## Périmètre futur

Le mode `Hausses 5` doit être réétudié séparément. Ne pas le corriger en même temps qu’une autre évolution.
