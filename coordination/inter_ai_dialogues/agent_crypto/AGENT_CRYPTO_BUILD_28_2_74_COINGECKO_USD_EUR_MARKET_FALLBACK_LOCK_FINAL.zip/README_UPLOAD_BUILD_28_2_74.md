# Agent-Crypto Build 28.2.74

## Nom
CoinGecko USD→EUR Market Fallback Lock

## Base exacte
Build 28.2.73. `app.js` local : blob Git `d665f02a03cde87c23f17fefcfcb59d6323f3986`, identique au fichier public vérifié avant construction.

## Remplacement
Extraire le ZIP à la racine du dépôt et remplacer uniquement :

- `public/agent_crypto_erith_ia/web/app.js`
- `public/agent_crypto_erith_ia/web/index.html`
- `public/agent_crypto_erith_ia/web/style.css`
- `public/agent_crypto_erith_ia/web/version.json`

## Ordre de données
1. CoinGecko Top 250 EUR direct.
2. CoinGecko Top 250 USD direct + conversion monétaire avec `data/metals/fx/usd_eur.json` (BCE).
3. Dernier snapshot CoinGecko local daté seulement si les deux chemins directs échouent.

## Test restant
Le code, la conversion et le paquet sont vérifiés localement. Le résultat réseau réel et CORS doit être confirmé dans Firefox sur le Ryzen après publication.
