# Rapport de vérification — Build 28.2.74

## Base

- Build source : `28.2.73`
- `app.js` : blob Git `d665f02a03cde87c23f17fefcfcb59d6323f3986`
- `index.html` : blob Git `3660109fb832225fb64bb63c3f3e58235e720580`
- `style.css` : blob Git `62efb2c047c1c3751c8fb677e5783105402d44c4`
- `version.json` : blob Git `68bb933f445cd65687f4d6904313fb9af6fcb83e`

## Résultats automatisés

- [x] Node.js available — /opt/nvm/versions/node/v22.16.0/bin/node
- [x] JavaScript syntax
- [x] USD→EUR conversion unit test — {"ok":true,"convertedAssets":50,"samplePriceEur":80,"fx":0.8}
- [x] version.json parse
- [x] app.js Build 28.2.74
- [x] app.js asset token
- [x] index.html Build 28.2.74
- [x] index.html asset token
- [x] style.css Build 28.2.74
- [x] style.css asset token
- [x] version.json Build 28.2.74
- [x] version.json asset token
- [x] required phrase async coingeckoTop250Usd
- [x] required phrase async ecbUsdEurReference
- [x] required phrase atlasConvertUsdMarketToEur
- [x] required phrase atlasFetchUsdEurMarketFallback
- [x] required phrase CoinGecko direct USD · conversion BCE EUR
- [x] required phrase variations CoinGecko USD
- [x] required phrase Snapshot archivé chargé
- [x] required phrase Dernière lecture conservée
- [x] required phrase status: "SECOURS"
- [x] required phrase ["BACKEND", "SECOURS"].includes(s.status)
- [x] required phrase EUR direct → CoinGecko USD Top 250 + conversion BCE EUR → dernier snapshot local daté
- [x] obsolete phrase removed Marché EUR direct absent
- [x] obsolete phrase removed Le marché EUR requis a échoué
- [x] unchanged signature return change >= 7 || ratio >= 0.08 || Number(score || 0) < 
- [x] unchanged signature .filter(c => Number(c.change24h || 0) >= 2 && Number(c.chang
- [x] unchanged signature const ids = ["bitcoin", "ethereum", "solana"];
- [x] unchanged signature information: 12,
- [x] unchanged signature risk: 8
- [x] unchanged signature state.sourceLock?.mode === "direct"
- [x] unchanged signature atlasMarketAgeMs() <= ATLAS_ANALYSIS_MAX_AGE_MS
- [x] exactly four app replacement files before docs — ['public/agent_crypto_erith_ia/web/style.css', 'public/agent_crypto_erith_ia/web/version.json', 'public/agent_crypto_erith_ia/web/app.js', 'public/agent_crypto_erith_ia/web/index.html']
- [x] no data/collector/workflow replacement

## Contrat fonctionnel

- CoinGecko EUR reste prioritaire ; lorsqu’un fallback USD→EUR valide prend le relais, le chemin EUR est affiché en état `SECOURS` (avertissement non bloquant), jamais comme panne globale.
- Après échec EUR, le programme tente un Top 250 USD complet, puis lit le taux public BCE déjà produit par le collecteur Métaux.
- Prix, capitalisations, volumes, plus hauts, plus bas et totaux monétaires sont convertis en EUR.
- Les valeurs USD originales sont conservées dans les objets marché.
- Les variations 1 h / 24 h / 7 j / 30 j restent les pourcentages CoinGecko en base USD et sont annoncées comme telles.
- Le Decision Board reste actif lorsque le fallback USD→EUR est direct, complet et valide.
- L’archive n’est utilisée qu’après échec des deux chemins directs.
- Aucun calcul de l’indice Atlas, seuil, graphique, collecteur, Bridge, fichier Métaux ou workflow n’est remplacé.

## Limite de vérification

- Le sandbox n’a pas exécuté les requêtes navigateur réelles vers CoinGecko. La réussite réseau/CORS du fallback doit être confirmée dans Firefox sur le Ryzen après publication.

## Fichiers à remplacer

- `public/agent_crypto_erith_ia/web/app.js`
- `public/agent_crypto_erith_ia/web/index.html`
- `public/agent_crypto_erith_ia/web/style.css`
- `public/agent_crypto_erith_ia/web/version.json`
