# Audit du gel de la V2.0.0

## Cause dans le code

`main()` appelait les fonctions Win32 et `runGUI()` sans
`runtime.LockOSThread()`.

Le programme utilise notamment :

```text
CreateWindowExW
GetMessageW
TranslateMessage
DispatchMessageW
DestroyWindow
```

Ces opérations doivent rester sur le thread système propriétaire de la
fenêtre. La migration possible de la goroutine principale expliquait le gel
aléatoire lors du retour dans l’application.

## Correction

Le thread UI est verrouillé avant même le mutex d’instance unique :

```go
func main() {
    runtime.LockOSThread()
    defer runtime.UnlockOSThread()

    // appels Win32 et boucle de messages
}
```

Les tâches réseau restent en arrière-plan. Elles n’écrivent pas directement
dans les contrôles : elles utilisent `PostMessageW`, puis la boucle UI applique
les changements dans `WM_STATUS` et `WM_ACTION_DONE`.
