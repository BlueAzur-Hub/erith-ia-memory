# Atlas-10 Crypto Bridge Desktop V2.0.1 — UI Thread Affinity Lock

## Défaut corrigé

La V2.0.0 utilisait une fenêtre Win32 depuis la goroutine principale sans
verrouiller celle-ci sur un thread système unique.

Une fenêtre Windows et sa file de messages appartiennent au thread système qui
les crée. Or une goroutine Go peut migrer d’un thread système à un autre entre
deux appels. Après un passage dans Firefox puis un retour au Control Center,
la boucle `GetMessageW / DispatchMessageW` pouvait donc ne plus desservir
correctement la fenêtre, qui affichait « Ne répond plus ».

La V2.0.1 applique désormais :

```go
runtime.LockOSThread()
defer runtime.UnlockOSThread()
```

avant tout appel Win32, puis conserve ce verrou jusqu’à la fermeture.

## Test Ryzen

1. Fermer la V2.0.0.
2. Laisser le Bridge V1.7.6 actif s’il fonctionne.
3. Lancer `AtlasCryptoBridgeControlCenter.exe`.
4. Passer plusieurs fois de Firefox au Control Center.
5. Réduire, restaurer, déplacer et agrandir la fenêtre.
6. Cliquer sur `Tester`.
7. Fermer avec la croix.

La fermeture du Control Center laisse le Bridge actif.

## Base inchangée

- Interface : Build 28.1.95
- Bridge : V1.7.6
- Ollama : llama3.2
- aucune écriture GitHub
- aucune popup modale
