import json, os, tempfile, time
class KillSwitch:
    MODES=("PAUSE","DEFENSIVE","EMERGENCY","HALTED")
    def __init__(self,path=None): self.path=path or os.getenv("AERITH_KILL_SWITCH_FILE","/tmp/aerith_kill_switch.json"); self.state=self._load()
    def _load(self):
        try:return json.load(open(self.path,encoding="utf8"))
        except Exception:return {"mode":"HALTED","reason":"SAFE_DEFAULT","updated_at":time.time()}
    def set(self,mode,reason="manual"):
        mode=mode.upper()
        if mode not in self.MODES: raise ValueError("Invalid kill-switch mode")
        self.state={"mode":mode,"reason":reason,"updated_at":time.time()}; d=os.path.dirname(self.path) or "."; fd,tmp=tempfile.mkstemp(dir=d,prefix="ks-",text=True)
        with os.fdopen(fd,"w",encoding="utf8") as f:json.dump(self.state,f); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,self.path); return self.state
    def get(self):return dict(self.state)
