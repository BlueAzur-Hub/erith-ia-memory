from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional

class PositionState(str, Enum):
    FLAT='FLAT'; ENTRY_PENDING='ENTRY_PENDING'; OPEN='OPEN'; EXIT_PENDING='EXIT_PENDING'; PARTIAL='PARTIAL'; UNKNOWN='UNKNOWN'; ERROR='ERROR'

@dataclass(frozen=True)
class OrderIntent:
    symbol: str
    side: str
    quantity: float
    client_order_id: str
    stop_price: Optional[float] = None

@dataclass(frozen=True)
class ExecutionResult:
    accepted: bool
    status: str
    client_order_id: str
    reason: Optional[str] = None

class ExecutionSafety:
    def __init__(self):
        self.state=PositionState.FLAT
        self._seen=set()
    def set_state(self,state): self.state=PositionState(state)
    def validate_intent(self,intent):
        if intent.client_order_id and intent.client_order_id in self._seen: return False,'DUPLICATE_ORDER'
        if self.state in {PositionState.UNKNOWN, PositionState.ERROR, PositionState.ENTRY_PENDING, PositionState.EXIT_PENDING}: return False,'POSITION_STATE_UNSAFE'
        if intent.side not in {'BUY','SELL'}: return False,'INVALID_SIDE'
        if intent.quantity<=0: return False,'INVALID_QUANTITY'
        if not intent.client_order_id: return False,'MISSING_IDEMPOTENCY_KEY'
        if intent.client_order_id in self._seen: return False,'DUPLICATE_ORDER'
        if intent.stop_price is None: return False,'MISSING_STOP'
        if intent.stop_price<=0: return False,'INVALID_STOP'
        return True,None
    def reserve(self,intent):
        ok,reason=self.validate_intent(intent)
        if not ok:return False,reason
        self._seen.add(intent.client_order_id); self.state=PositionState.ENTRY_PENDING
        return True,None
    def reconcile(self,exchange_state):
        try: actual=PositionState(exchange_state)
        except Exception: actual=PositionState.UNKNOWN
        self.state=actual; return actual

class ExchangeAdapter:
    """Strict interface: implementations must be read-only until explicitly certified."""
    environment='SANDBOX'
    def get_position(self,symbol): raise NotImplementedError
    def get_order(self,client_order_id): raise NotImplementedError
    def place_order(self,intent): raise NotImplementedError
    def cancel_order(self,client_order_id): raise NotImplementedError

class SandboxExchange(ExchangeAdapter):
    environment='SANDBOX'
    def __init__(self): self.orders={}; self.position={}
    def get_position(self,symbol): return self.position.get(symbol, {'state':'FLAT','quantity':0.0})
    def get_order(self,client_order_id): return self.orders.get(client_order_id)
    def place_order(self,intent):
        if intent.client_order_id in self.orders: return self.orders[intent.client_order_id]
        order={'client_order_id':intent.client_order_id,'symbol':intent.symbol,'side':intent.side,'quantity':intent.quantity,'status':'FILLED'}
        self.orders[intent.client_order_id]=order; self.position[intent.symbol]={'state':'OPEN','quantity':intent.quantity}
        return order
    def cancel_order(self,client_order_id):
        o=self.orders.get(client_order_id)
        if not o:return False
        if o['status'] in {'FILLED','CANCELED'}:return False
        o['status']='CANCELED'; return True
