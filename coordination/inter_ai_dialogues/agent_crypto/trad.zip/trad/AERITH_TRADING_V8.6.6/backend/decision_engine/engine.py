import copy, json, logging, os, time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict
from .execution import PositionState, OrderIntent, ExecutionSafety
try:
    from prometheus_client import Counter, Gauge, Histogram
except Exception:
    class _M:
        def __init__(self,*a,**k): pass
        def labels(self,*a,**k): return self
        def inc(self,*a,**k): pass
        def observe(self,*a,**k): pass
        def set(self,*a,**k): pass
    Counter=Gauge=Histogram=_M

ACTIONS={'HOLD','OFFENSIVE','PROTECTIVE','NEUTRAL'}; LOGICS={'AND','OR'}
TRUST_STATES={'VALID','DEGRADED','STALE','INVALID'}
MODES={'PAPER','LIMITED_LIVE','LIVE','PAUSE','DEFENSIVE','EMERGENCY','HALTED'}
DECISION_COUNTER=Counter('decision_total','Decisions by action',['action']); DECISION_LATENCY=Histogram('decision_latency_seconds','Decision latency'); RISK_SCORE=Gauge('risk_score','Current risk score'); SAFETY_BLOCK_COUNTER=Counter('safety_block_total','Safety blocks',['reason'])

class DataTrustEngine:
    REQUIRED=('risk_score','opportunity_score')
    def assess(self,data,now=None):
        if not isinstance(data,dict): return 'INVALID','DATA_NOT_OBJECT'
        for k in self.REQUIRED:
            if k not in data: return 'INVALID',f'MISSING_{k.upper()}'
            try:
                v=float(data[k])
                if v != v or v in (float('inf'),float('-inf')): return 'INVALID',f'INVALID_{k.upper()}'
            except (TypeError,ValueError): return 'INVALID',f'INVALID_{k.upper()}'
        ts=data.get('data_timestamp')
        if ts is not None:
            try:
                age=float((time.time() if now is None else now)-float(ts))
                max_age=float(data.get('max_data_age_seconds',30))
                if age>max_age:return 'STALE','DATA_AGE_EXCEEDED'
                if age>max_age*0.7:return 'DEGRADED','DATA_NEAR_STALE'
            except (TypeError,ValueError):return 'INVALID','INVALID_DATA_TIMESTAMP'
        return str(data.get('data_trust','VALID')).upper(),None

class CircuitBreaker:
    def __init__(self,threshold=3): self.threshold=int(threshold); self.failures=0; self.open=False
    def failure(self):
        self.failures+=1
        if self.failures>=self.threshold:self.open=True
    def success(self): self.failures=0; self.open=False
    def check(self): return (False,'CIRCUIT_OPEN') if self.open else (True,None)

class RiskGovernor:
    def __init__(self,config=None):
        c=config or {}; self.max_trade_risk=float(c.get('max_trade_risk',os.getenv('AERITH_MAX_TRADE_RISK',1))); self.max_position_exposure=float(c.get('max_position_exposure',os.getenv('AERITH_MAX_POSITION_EXPOSURE',25))); self.max_daily_loss=float(c.get('max_daily_loss',os.getenv('AERITH_MAX_DAILY_LOSS',3))); self.max_drawdown=float(c.get('max_drawdown',os.getenv('AERITH_MAX_DRAWDOWN',10)))
    def check(self,data):
        for n,v,l in [('trade_risk',data.get('trade_risk',0),self.max_trade_risk),('position_exposure',data.get('position_exposure',0),self.max_position_exposure),('daily_loss',data.get('daily_loss',0),self.max_daily_loss),('drawdown',data.get('drawdown',0),self.max_drawdown)]:
            try:v=float(v)
            except (TypeError,ValueError):return False,f'INVALID_{n.upper()}'
            if v<0:return False,f'INVALID_{n.upper()}'
            if v>l:return False,f'RISK_LIMIT_{n.upper()}'
        return True,None

class DecisionEngine:
    def __init__(self,rules_file=None,logger=None,es_client=None,risk_governor=None,mode=None,execution_safety=None,data_trust=None,circuit_breaker=None):
        rules_file=rules_file or os.path.join(os.path.dirname(__file__),'rules.json'); self.rules=json.load(open(rules_file,encoding='utf8')); self.validate_rules(self.rules); self.logger=logger or logging.getLogger(__name__); self.es=es_client; self.risk_governor=risk_governor or RiskGovernor(); self.mode=(mode or os.getenv('AERITH_MODE','PAPER')).upper(); self.execution=execution_safety or ExecutionSafety(); self.data_trust=data_trust or DataTrustEngine(); self.circuit_breaker=circuit_breaker or CircuitBreaker()
        if self.mode not in MODES: raise ValueError(f'Invalid mode: {self.mode}')
    @staticmethod
    def validate_rules(rules):
        if not isinstance(rules,dict) or not isinstance(rules.get('decision_rules'),list): raise ValueError('Invalid rulebook')
        if rules.get('default_action') not in ACTIONS: raise ValueError('Invalid default_action')
        names=set()
        for r in rules['decision_rules']:
            if not isinstance(r,dict) or not r.get('name') or r.get('action') not in ACTIONS: raise ValueError('Invalid rule')
            if r['name'] in names: raise ValueError('Duplicate rule name')
            names.add(r['name']); logic=str(r.get('logic','AND')).upper()
            if logic not in LOGICS: raise ValueError('Invalid logic')
            if not isinstance(r.get('conditions',[]),list): raise ValueError('Conditions must be a list')
            for c in r.get('conditions',[]): DecisionEngine.validate_condition(c)
    @staticmethod
    def validate_condition(c):
        if not isinstance(c,dict) or not c: raise ValueError('Condition must be a non-empty object')
        if 'logic' in c:
            if str(c.get('logic')).upper() not in LOGICS or not isinstance(c.get('conditions',[]),list): raise ValueError('Invalid nested logic')
            for x in c['conditions']: DecisionEngine.validate_condition(x)
            return
        fields=[k for k in c if k!='not']
        if len(fields)!=1: raise ValueError('Atomic condition must contain exactly one field')
        ops=c[fields[0]]
        if not isinstance(ops,dict) or not ops or not set(ops).issubset({'>','<','>=','<=','==','!='}): raise ValueError('Unsupported condition operator')
    def evaluate_condition(self,data,c):
        if 'logic' in c:return self.evaluate_logic(data,c)
        key=[k for k in c if k!='not'][0]; v=data.get(key)
        if v is None:return False
        result=True
        for op,t in c[key].items(): result=result and {'>':v>t,'<':v<t,'>=':v>=t,'<=':v<=t,'==':v==t,'!=':v!=t}[op]
        return (not result) if c.get('not',False) else result
    def evaluate_logic(self,data,r):
        vals=[self.evaluate_condition(data,c) for c in r.get('conditions',[])]; result=all(vals) if str(r.get('logic','AND')).upper()=='AND' else any(vals); return (not result) if r.get('not',False) else result
    def evaluate_conditions(self,data,r):return self.evaluate_logic(data,r)
    def log_to_elasticsearch(self,e):
        if self.es:
            try:self.es.index(index='aerith-history',document=e)
            except Exception as exc:self.logger.warning('history logging failed: %s',exc)
    def _safety_gate(self,data):
        trust,trust_reason=self.data_trust.assess(data)
        if trust not in TRUST_STATES:return 'HOLD','INVALID_DATA_TRUST_STATE'
        if trust_reason and trust == 'INVALID': return 'HOLD',trust_reason
        if trust=='INVALID':return 'HOLD','DATA_INVALID'
        if trust=='STALE':return 'HOLD','DATA_STALE'
        if trust=='DEGRADED':return 'PROTECTIVE','DATA_DEGRADED'
        if self.mode in {'PAUSE','HALTED'}:return 'HOLD',f'MODE_{self.mode}'
        ok_cb,reason_cb=self.circuit_breaker.check()
        if not ok_cb:return 'HOLD',reason_cb
        if self.mode in {'DEFENSIVE','EMERGENCY'}:return 'PROTECTIVE',f'MODE_{self.mode}'
        ok,reason=self.risk_governor.check(data)
        if not ok:return 'PROTECTIVE',reason
        if self.execution.state in {PositionState.UNKNOWN,PositionState.ERROR}:return 'HOLD','POSITION_STATE_UNSAFE'
        return None,None
    def decide(self,data,persist=True):
        start=time.perf_counter(); data=copy.deepcopy(data or {})
        try:
            try:RISK_SCORE.set(float(data.get('risk_score',0)))
            except Exception:RISK_SCORE.set(0)
            action,reason=self._safety_gate(data)
            if action is None:
                action=self.rules['default_action']
                for r in self.rules['decision_rules']:
                    if self.evaluate_conditions(data,r):action=r['action'];break
            else:SAFETY_BLOCK_COUNTER.labels(reason=reason).inc()
            DECISION_COUNTER.labels(action=action).inc(); entry={'data':data,'action':action,'timestamp':time.time(),'source':'live' if persist else 'replay'}
            if persist:self.log_to_elasticsearch(entry)
            return {'action':action,'reason':reason,'mode':self.mode,'persisted':bool(persist),'position_state':self.execution.state.value}
        finally:DECISION_LATENCY.observe(time.perf_counter()-start)
    def make_decision(self,data,persist=True):return self.decide(data,persist)['action']
    def prepare_order(self,intent):
        ok,reason=self.risk_governor.check({'trade_risk':intent.quantity,'position_exposure':0,'daily_loss':0,'drawdown':0})
        if not ok:return False,reason
        return self.execution.reserve(intent)
