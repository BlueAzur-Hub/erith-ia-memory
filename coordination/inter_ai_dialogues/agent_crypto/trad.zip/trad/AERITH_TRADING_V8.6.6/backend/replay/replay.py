from datetime import datetime
class ReplayEngine:
 def __init__(self,engine,es_client=None): self.engine=engine; self.es=es_client
 def fetch_historical_data(self,start_time,end_time,limit=100):
  if self.es is None:return []
  q={'range':{'timestamp':{'gte':start_time.timestamp(),'lte':end_time.timestamp()}}}; r=self.es.search(index='aerith-history',query=q,size=limit); return [h['_source'] for h in r.get('hits',{}).get('hits',[]) if '_source' in h]
 def replay_scenario(self,s):
  if not isinstance(s,dict) or not isinstance(s.get('data'),dict) or 'action' not in s: raise ValueError('Replay scenario requires data and action')
  old=self.engine.execution.state; self.engine.execution.set_state('FLAT'); result=self.engine.decide(s['data'],persist=False); self.engine.execution.set_state(old)
  return {'original_action':s['action'],'new_action':result['action'],'match':s['action']==result['action'],'reason':result['reason'],'data':s['data']}
 def replay_time_range(self,start_time,end_time,limit=100):return [self.replay_scenario(x) for x in self.fetch_historical_data(start_time,end_time,limit)]
