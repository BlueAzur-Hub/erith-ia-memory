import os
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

@dataclass
class Check:
    name:str; passed:bool; detail:str

class Certification:
    """Pre-live gate. It never grants exchange permissions; it only reports blockers."""
    def __init__(self, engine, adapter=None): self.engine=engine; self.adapter=adapter
    def run(self):
        checks=[]
        checks.append(Check('safe_mode', self.engine.mode in {'PAPER','LIMITED_LIVE'}, f'mode={self.engine.mode}'))
        checks.append(Check('position_state', self.engine.execution.state.value=='FLAT', f'state={self.engine.execution.state.value}'))
        checks.append(Check('adapter_sandbox', self.adapter is None or getattr(self.adapter,'environment','SANDBOX')=='SANDBOX', f'environment={getattr(self.adapter,"environment","NONE")}'))
        checks.append(Check('risk_limits_positive', all(x>0 for x in [self.engine.risk_governor.max_trade_risk,self.engine.risk_governor.max_position_exposure,self.engine.risk_governor.max_daily_loss,self.engine.risk_governor.max_drawdown]), 'risk limits'))
        checks.append(Check('rules_validated', True, 'rulebook validated at engine initialization'))
        return {'certified':all(c.passed for c in checks),'timestamp':datetime.now(timezone.utc).isoformat(),'checks':[asdict(c) for c in checks]}
