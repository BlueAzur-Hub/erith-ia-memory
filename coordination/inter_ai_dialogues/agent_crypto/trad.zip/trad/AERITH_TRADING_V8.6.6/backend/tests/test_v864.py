import os,sys
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..'))
from decision_engine.engine import *
from replay.replay import ReplayEngine
def E(**k): return DecisionEngine(**k)
def test_rules():
 assert E().make_decision({'risk_score':25,'opportunity_score':15},False)=='PROTECTIVE'; assert E().make_decision({'risk_score':1,'opportunity_score':15},False)=='OFFENSIVE'; assert E().make_decision({'risk_score':1,'opportunity_score':1},False)=='PROTECTIVE'; assert E().make_decision({'risk_score':5,'opportunity_score':5},False)=='NEUTRAL'
def test_unknown_position_blocks():
 e=E(); e.execution.set_state('UNKNOWN'); assert e.make_decision({'risk_score':1,'opportunity_score':15},False)=='HOLD'
def test_idempotency():
 e=E(); i=OrderIntent('BTC','BUY',.1,'abc',100); assert e.prepare_order(i)[0]; assert e.prepare_order(i)==(False,'DUPLICATE_ORDER')
def test_unknown_exchange_reality():
 e=E(); assert e.execution.reconcile('bogus')==PositionState.UNKNOWN; assert e.make_decision({'risk_score':1,'opportunity_score':15},False)=='HOLD'
def test_replay_no_side_effect():
 e=E(); calls=[]; e.log_to_elasticsearch=lambda x:calls.append(x); r=ReplayEngine(e).replay_scenario({'data':{'risk_score':1,'opportunity_score':15},'action':'OFFENSIVE'}); assert r['match'] and not calls
def test_invalid_order():
 e=E(); assert e.prepare_order(OrderIntent('BTC','BUY',0,'x'))==(False,'INVALID_QUANTITY')
