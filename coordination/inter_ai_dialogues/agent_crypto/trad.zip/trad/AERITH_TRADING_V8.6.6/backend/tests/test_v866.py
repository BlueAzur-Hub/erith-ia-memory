import os,sys,tempfile,time
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..'))
from decision_engine.engine import DecisionEngine
from decision_engine.execution import OrderIntent, ExecutionSafety, SandboxExchange, PositionState
from certification import Certification

def E(**k): return DecisionEngine(**k)

def test_missing_stop_is_refused():
 e=E(); assert e.prepare_order(OrderIntent('BTC','BUY',.1,'x'))==(False,'MISSING_STOP')

def test_pending_state_refuses_second_order():
 e=E(); i=OrderIntent('BTC','BUY',.1,'x',100); assert e.prepare_order(i)[0]; assert e.prepare_order(OrderIntent('ETH','BUY',.1,'y',100))==(False,'POSITION_STATE_UNSAFE')

def test_sandbox_idempotent_execution():
 x=SandboxExchange(); i=OrderIntent('BTC','BUY',.1,'x',100); a=x.place_order(i); b=x.place_order(i); assert a==b and len(x.orders)==1

def test_reality_overrides_intention():
 s=ExecutionSafety(); s.set_state('OPEN'); assert s.reconcile('FLAT')==PositionState.FLAT

def test_unknown_reconciliation_blocks():
 e=E(); e.execution.reconcile('BAD'); assert e.make_decision({'risk_score':1,'opportunity_score':15},False)=='HOLD'

def test_certification_blocks_live_mode():
 e=E(mode='LIVE'); r=Certification(e,SandboxExchange()).run(); assert not r['certified']

def test_certification_paper_passes():
 e=E(mode='PAPER'); r=Certification(e,SandboxExchange()).run(); assert r['certified']
