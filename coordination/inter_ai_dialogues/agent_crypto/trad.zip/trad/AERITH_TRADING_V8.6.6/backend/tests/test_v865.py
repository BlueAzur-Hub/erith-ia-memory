import os,sys,tempfile,time
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..'))
from decision_engine.engine import *
from control import KillSwitch
def E(**k):return DecisionEngine(**k)
def test_missing_required_data_holds():assert E().make_decision({'risk_score':1},False)=='HOLD'
def test_stale_timestamp_holds():assert E().make_decision({'risk_score':1,'opportunity_score':15,'data_timestamp':time.time()-100},False)=='HOLD'
def test_near_stale_degrades():assert E().decide({'risk_score':1,'opportunity_score':15,'data_timestamp':time.time()-25})['action']=='PROTECTIVE'
def test_circuit_breaker():
 e=E(); [e.circuit_breaker.failure() for _ in range(3)]; assert e.make_decision({'risk_score':1,'opportunity_score':15},False)=='HOLD'
def test_kill_switch_atomic():
 with tempfile.TemporaryDirectory() as d:
  k=KillSwitch(os.path.join(d,'ks.json')); assert k.get()['mode']=='HALTED'; x=k.set('EMERGENCY','test'); assert x['reason']=='test'; assert k.get()['mode']=='EMERGENCY'
def test_v864_regression():assert E().make_decision({'risk_score':1,'opportunity_score':15},False)=='OFFENSIVE'
