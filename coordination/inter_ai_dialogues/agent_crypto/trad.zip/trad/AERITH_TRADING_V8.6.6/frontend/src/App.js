export default function App(){return <main><h1>AERITH TRADING V8.6.4</h1><p>Execution Safety / Risk Firewall</p></main>}
