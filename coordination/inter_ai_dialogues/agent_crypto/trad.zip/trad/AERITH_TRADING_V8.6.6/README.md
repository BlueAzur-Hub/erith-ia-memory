# AERITH TRADING V8.6.6

Live-link readiness hardening release. The system is **not live-certified**. It includes a strict exchange adapter boundary, sandbox execution, mandatory stops, idempotency, reconciliation, Data Trust, Risk Governor, Circuit Breaker, Kill Switch and a pre-live certification gate.

## Test
`PYTHONPATH=backend python -m pytest -q backend/tests`

## Rule
A trading URL/API does not automatically authorize execution. The endpoint must first be identified, authenticated with least privilege, sandbox-tested, reconciled and passed through the certification/chaos suite.
