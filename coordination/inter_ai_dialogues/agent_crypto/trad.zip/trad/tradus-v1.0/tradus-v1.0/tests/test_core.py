import time
from tradus.core import TradusCore
from tradus.models import Action, MarketTick

def test_buy_execution():
    engine = TradusCore()
    tick = MarketTick("X", time.time(), 99, 100, 100, 10, 100)
    decision = engine.process_tick(tick)
    assert decision.action == Action.BUY
    assert decision.risk_approved is True
    assert engine.position("X").quantity == 1

def test_no_trade_when_balanced():
    engine = TradusCore()
    tick = MarketTick("X", time.time(), 99, 100, 50, 50, 100)
    decision = engine.process_tick(tick)
    assert decision.action == Action.NO_TRADE
    assert decision.risk_approved is False
