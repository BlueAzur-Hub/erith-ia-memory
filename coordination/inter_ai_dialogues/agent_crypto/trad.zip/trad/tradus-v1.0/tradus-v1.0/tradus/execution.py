import uuid
from .models import Action, Order, OrderStatus, Position

class PaperExecutor:
    def __init__(self):
        self.orders: list[Order] = []

    def submit(self, symbol: str, action: Action, quantity: float, price: float) -> Order:
        order = Order(str(uuid.uuid4()), symbol, action, quantity, price, OrderStatus.FILLED)
        self.orders.append(order)
        return order

    def apply_fill(self, order: Order, position: Position) -> Position:
        signed = order.quantity if order.action == Action.BUY else -order.quantity
        if signed > 0:
            total_cost = position.average_price * position.quantity + order.price * signed
            new_quantity = position.quantity + signed
            position.average_price = total_cost / new_quantity if new_quantity else 0.0
            position.quantity = new_quantity
        else:
            closing = min(position.quantity, abs(signed))
            position.realized_pnl += (order.price - position.average_price) * closing
            position.quantity += signed
            if position.quantity == 0:
                position.average_price = 0.0
        return position
