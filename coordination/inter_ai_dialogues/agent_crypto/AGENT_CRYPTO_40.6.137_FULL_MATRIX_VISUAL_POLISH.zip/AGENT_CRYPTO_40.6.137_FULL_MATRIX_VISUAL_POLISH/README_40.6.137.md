# Agent-Crypto 40.6.137 — Full Matrix Visual Polish

Scope: Aerith-10 ChatGPT Full Matrix presentation only.

Changed files:
- `public/agent_crypto_erith_ia/administrator/aerith10-portal.css`
- `public/agent_crypto_erith_ia/administrator/assets/aerith10/AERITH_10_FULL_MATRIX_BANNER_40.6.137.jpg`
- `public/agent_crypto_erith_ia/administrator/build.json`
- `public/agent_crypto_erith_ia/administrator/releases/40.6.137/index.html`

What changes:
- Adds the prepared Full Matrix banner to the existing Aerith-10 loader card.
- Preserves the master prompt line breaks with `white-space: pre-wrap`.
- Gives the prompt a bounded scrollable reading surface.
- Adds responsive sizing for the banner/prompt on narrow screens.

Protected / unchanged:
- Market Core 38.15.11
- `js/aerith10-workspace-bridge.js` and the prompt text
- `js/version-truth.js`
- Atlas CURRENT
- Oracle
- Lecture Technique
- Strategy A
- TRADUS
- Forge d'Aerith Pro
- Notion Aerith-10 portal

Suggested commit message:
`style(admin): polish Aerith-10 Full Matrix guide (40.6.137)`

Terrain check after upload:
1. Open Administrator in Firefox with a cold reload.
2. Confirm `Build 40.6.137 · Administrator`.
3. Open Aerith-10 Creator / Full Matrix.
4. Confirm banner visible, no crop issue, prompt line breaks preserved, prompt independently scrollable.
5. Click steps 1/2/3 once each; behavior must match 40.6.136.
6. Stop.
