# Rapport de vérification — Build 28.2.73

## Base

- Build source : `28.2.72`
- `app.js` source : blob Git public `66dd6076b65dd14c0296876f4538eb4671da473c`
- `index.html` source : blob Git public `70889c6f7b4b7ae659e7a3baf4b54cde259b48d6`
- `style.css` source : blob Git public `e22b085886427e83022f7cf854fe68febdcf19e1`
- `version.json` source : blob Git public `905dd272b11b248e06ae9322fa96bae311ede846`

## Résultats

- [x] JavaScript syntax (node --check)
- [x] version.json parse
- [x] app.js contains Build 28.2.73
- [x] app.js contains asset token
- [x] app.js has no previous build marker
- [x] index.html contains Build 28.2.73
- [x] index.html contains asset token
- [x] index.html has no previous build marker
- [x] style.css contains Build 28.2.73
- [x] style.css contains asset token
- [x] style.css has no previous build marker
- [x] version.json contains Build 28.2.73
- [x] version.json contains asset token
- [x] version.json previous build appears only as decision lock base
- [x] required truth phrase: Lecture catégories d’actifs
- [x] required truth phrase: indice de veille Atlas
- [x] required truth phrase: flux CoinGecko
- [x] required truth phrase: historique archivé
- [x] required truth phrase: Consultation Atlas archivée
- [x] required truth phrase: l’indice de veille ne déclenche aucune action
- [x] required truth phrase: action descriptive déterminée par la catégorie de l’actif et l’état direct / archivé, indépendamment de l’indice
- [x] required truth phrase: analyse directe, conclusion active et simulation suspendues
- [x] inaccurate phrase removed: Lecture secteurs
- [x] inaccurate phrase removed: scores et conclusion suspendus
- [x] inaccurate phrase removed: prix archivés consultables, scores Atlas
- [x] unchanged deterministic signature: return change >= 7 || ratio >= 0.08 || Number(score || 0) < 40
- [x] unchanged deterministic signature: .filter(c => Number(c.change24h || 0) >= 2 && Number(c.change7
- [x] unchanged deterministic signature: const ids = ["bitcoin", "ethereum", "solana"];
- [x] unchanged deterministic signature: if (!atlasAnalysisLiveReady()) return "Archive · consultation"
- [x] unchanged deterministic signature: information: 12,
- [x] unchanged deterministic signature: risk: 8
- [x] unchanged deterministic signature: state.sourceLock?.mode === "direct"
- [x] unchanged deterministic signature: state.coins.length >= ATLAS_MARKET_MIN_ASSETS
- [x] unchanged deterministic signature: atlasMarketAgeMs() <= ATLAS_ANALYSIS_MAX_AGE_MS
- [x] exactly four application replacement files — ['public/agent_crypto_erith_ia/web/style.css', 'public/agent_crypto_erith_ia/web/version.json', 'public/agent_crypto_erith_ia/web/app.js', 'public/agent_crypto_erith_ia/web/index.html']
- [x] no collector or workflow file

## Contrat fonctionnel

- Le calcul de l’indice, les seuils de mouvement et d’anomalie, la mémoire et les entrées CoinGecko restent inchangés.
- Le mode archive conserve un indice historique descriptif et les prix archivés pour consultation.
- L’analyse directe, la conclusion active et la simulation restent suspendues hors mode direct récent.
- L’action affichée est explicitement indépendante de l’indice : elle dépend de la catégorie de l’actif et de l’état direct ou archivé.
- Aucun fichier Métaux, Bridge, collecteur, GitHub Actions ou données publiques n’est remplacé.

## Fichiers applicatifs remplacés

- `public/agent_crypto_erith_ia/web/app.js`
- `public/agent_crypto_erith_ia/web/index.html`
- `public/agent_crypto_erith_ia/web/style.css`
- `public/agent_crypto_erith_ia/web/version.json`
