# Agent-Crypto Build 28.2.73

## Nom
Decision Board Truth Contract Lock

## Base vérifiée
Build 28.2.72, `app.js` blob Git public `66dd6076b65dd14c0296876f4538eb4671da473c`.

## Remplacement
Extraire le ZIP à la racine du dépôt et remplacer uniquement :

- `public/agent_crypto_erith_ia/web/app.js`
- `public/agent_crypto_erith_ia/web/index.html`
- `public/agent_crypto_erith_ia/web/style.css`
- `public/agent_crypto_erith_ia/web/version.json`

## Portée
Contrat de vérité visible du Decision Board Crypto uniquement. Aucun changement du moteur de score, des seuils, des sources, du graphique, des collecteurs, de News Sentinel, du Bridge ou du domaine Métaux.
