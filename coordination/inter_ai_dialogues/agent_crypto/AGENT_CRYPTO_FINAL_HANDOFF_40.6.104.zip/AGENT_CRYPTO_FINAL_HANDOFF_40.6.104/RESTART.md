# Reprise minimale

1. Lire administrator/build.json.
2. Exiger build = 40.6.104 avant toute nouvelle chirurgie.
3. Vérifier index-40.6.104.html.
4. Ne créer une nouvelle version que pour un défaut réellement reproduit.
5. Conserver Market Core 38.15.11 et les zones protégées.
6. Lire → diagnostiquer → cibler → corriger → vérifier → arrêter.
7. Une correction = un propriétaire = une preuve = un commit = stop.

Dette terrain restante :
- si nécessaire, fournir une capture Firefox explicite de 40.6.104.
