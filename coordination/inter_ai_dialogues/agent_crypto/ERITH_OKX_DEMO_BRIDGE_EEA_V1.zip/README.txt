ERITH · OKX DEMO BRIDGE

À extraire dans :
C:\ERITH\okx-demo-bridge\

Le dossier doit contenir :
- okx-demo.env              (votre fichier local, non fourni)
- okx_demo_bridge.py
- START_OKX_DEMO_BRIDGE.bat
- CHECK_OKX_DEMO_BRIDGE.bat

Utilisation :
1. Extraire les fichiers dans C:\ERITH\okx-demo-bridge\
2. Ne pas remplacer okx-demo.env
3. Double-cliquer START_OKX_DEMO_BRIDGE.bat
4. Le démarrage teste AUTH + BTC-EUR.
5. Aucun ordre n'est envoyé au démarrage.

Sécurité :
- 127.0.0.1:8787 uniquement
- domaine EEA https://eea.okx.com
- x-simulated-trading: 1 forcé
- BTC-EUR SPOT uniquement
- aucune route retrait/transfert/live
- secrets jamais imprimés
