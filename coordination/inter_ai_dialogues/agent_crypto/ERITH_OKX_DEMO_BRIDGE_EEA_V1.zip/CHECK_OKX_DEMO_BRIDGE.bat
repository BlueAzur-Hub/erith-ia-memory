@echo off
title ERITH - CHECK OKX DEMO BRIDGE
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8787/self-test' -Method Get -TimeoutSec 20; $r | ConvertTo-Json -Depth 8 } catch { Write-Host '[ERREUR]' $_.Exception.Message -ForegroundColor Red }"
echo.
pause
