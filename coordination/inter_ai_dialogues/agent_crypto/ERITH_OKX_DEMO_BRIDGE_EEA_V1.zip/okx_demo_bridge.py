#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import sys
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8787
BASE_URL = "https://eea.okx.com"
INST_ID = "BTC-EUR"
ENV_FILE = Path(__file__).with_name("okx-demo.env")

def load_env(path: Path) -> dict[str, str]:
    if not path.exists():
        raise RuntimeError(f"Fichier introuvable: {path}")
    data = {}
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip()
    return data

ENV = load_env(ENV_FILE)
API_KEY = ENV.get("OKX_DEMO_API_KEY", "")
SECRET_KEY = ENV.get("OKX_DEMO_SECRET_KEY", "")
PASSPHRASE = ENV.get("OKX_DEMO_PASSPHRASE", "")

missing = [name for name, value in (
    ("OKX_DEMO_API_KEY", API_KEY),
    ("OKX_DEMO_SECRET_KEY", SECRET_KEY),
    ("OKX_DEMO_PASSPHRASE", PASSPHRASE),
) if not value]
if missing:
    raise RuntimeError("Valeur(s) manquante(s): " + ", ".join(missing))

def utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")

def sign(timestamp: str, method: str, request_path: str, body: str) -> str:
    prehash = timestamp + method.upper() + request_path + body
    digest = hmac.new(SECRET_KEY.encode(), prehash.encode(), hashlib.sha256).digest()
    return base64.b64encode(digest).decode()

def okx_request(method: str, path: str, query=None, payload=None, private=True):
    method = method.upper()
    query = query or {}
    qs = urllib.parse.urlencode(query)
    request_path = path + (("?" + qs) if qs else "")
    body = ""
    data = None
    if payload is not None:
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
        data = body.encode()

    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ERITH-OKX-DEMO-BRIDGE/1.0",
    }
    if private:
        ts = utc_timestamp()
        headers.update({
            "OK-ACCESS-KEY": API_KEY,
            "OK-ACCESS-SIGN": sign(ts, method, request_path, body),
            "OK-ACCESS-TIMESTAMP": ts,
            "OK-ACCESS-PASSPHRASE": PASSPHRASE,
            "x-simulated-trading": "1",
        })

    req = urllib.request.Request(BASE_URL + request_path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode()
            return resp.status, json.loads(raw)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode(errors="replace")
        try:
            obj = json.loads(raw)
        except Exception:
            obj = {"raw": raw}
        return exc.code, obj
    except Exception as exc:
        return 0, {"code": "LOCAL_ERROR", "msg": str(exc)}

def self_test():
    result = {
        "bridge": "ERITH_OKX_DEMO",
        "region": "EEA",
        "base_url": BASE_URL,
        "demo_header": True,
        "instrument": INST_ID,
        "env_loaded": True,
    }

    s1, a = okx_request("GET", "/api/v5/account/balance", private=True)
    result["auth"] = {
        "http_status": s1,
        "okx_code": str(a.get("code", "")),
        "ok": s1 == 200 and str(a.get("code", "")) == "0",
        "msg": a.get("msg", ""),
    }

    s2, i = okx_request(
        "GET",
        "/api/v5/public/instruments",
        query={"instType": "SPOT", "instId": INST_ID},
        private=False,
    )
    data = i.get("data") if isinstance(i, dict) else None
    result["instrument_check"] = {
        "http_status": s2,
        "okx_code": str(i.get("code", "")) if isinstance(i, dict) else "",
        "ok": s2 == 200 and isinstance(data, list) and len(data) > 0,
        "count": len(data) if isinstance(data, list) else 0,
        "msg": i.get("msg", "") if isinstance(i, dict) else "",
    }
    result["ok"] = result["auth"]["ok"] and result["instrument_check"]["ok"]
    return result

class Handler(BaseHTTPRequestHandler):
    def _json(self, status, obj):
        data = json.dumps(obj, ensure_ascii=False, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _read_json(self):
        n = int(self.headers.get("Content-Length", "0") or "0")
        return json.loads((self.rfile.read(n) if n else b"{}").decode())

    def log_message(self, fmt, *args):
        sys.stdout.write("[LOCAL] " + (fmt % args) + "\n")

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/health":
            return self._json(200, {
                "ok": True,
                "bridge": "ERITH_OKX_DEMO",
                "demo": True,
                "region": "EEA",
                "instrument": INST_ID,
                "bind": f"http://{HOST}:{PORT}",
            })

        if parsed.path == "/self-test":
            r = self_test()
            return self._json(200 if r["ok"] else 502, r)

        if parsed.path == "/demo/order":
            ord_id = (q.get("ordId") or [""])[0].strip()
            if not ord_id:
                return self._json(400, {"ok": False, "error": "ordId requis"})
            s, obj = okx_request(
                "GET", "/api/v5/trade/order",
                query={"instId": INST_ID, "ordId": ord_id},
                private=True
            )
            return self._json(s if s else 502, obj)

        return self._json(404, {"ok": False, "error": "route inconnue"})

    def do_POST(self):
        try:
            body = self._read_json()
        except Exception:
            return self._json(400, {"ok": False, "error": "JSON invalide"})

        if self.path == "/demo/post-only":
            side = str(body.get("side", "")).lower().strip()
            px = str(body.get("px", "")).strip()
            sz = str(body.get("sz", "")).strip()
            if side not in {"buy", "sell"}:
                return self._json(400, {"ok": False, "error": "side doit etre buy ou sell"})
            if not px or not sz:
                return self._json(400, {"ok": False, "error": "px et sz requis"})

            payload = {
                "instId": INST_ID,
                "tdMode": "cash",
                "side": side,
                "ordType": "post_only",
                "px": px,
                "sz": sz,
            }
            s, obj = okx_request("POST", "/api/v5/trade/order", payload=payload, private=True)
            return self._json(s if s else 502, obj)

        if self.path == "/demo/cancel":
            ord_id = str(body.get("ordId", "")).strip()
            if not ord_id:
                return self._json(400, {"ok": False, "error": "ordId requis"})
            s, obj = okx_request(
                "POST",
                "/api/v5/trade/cancel-order",
                payload={"instId": INST_ID, "ordId": ord_id},
                private=True
            )
            return self._json(s if s else 502, obj)

        return self._json(404, {"ok": False, "error": "route inconnue"})

def main():
    print("=" * 60)
    print("ERITH · OKX DEMO BRIDGE")
    print("=" * 60)
    print(f"[OK] env: {ENV_FILE}")
    print("[OK] secrets charges (jamais affiches)")
    print(f"[OK] region EEA: {BASE_URL}")
    print("[OK] DEMO force: x-simulated-trading: 1")
    print(f"[OK] SPOT verrouille: {INST_ID}")
    print("[TEST] Authentification + instrument...")

    r = self_test()
    print("[AUTH]", "OK" if r["auth"]["ok"] else "ECHEC",
          f"(HTTP {r['auth']['http_status']} / OKX {r['auth']['okx_code']})")
    print("[BTC-EUR]", "OK" if r["instrument_check"]["ok"] else "ECHEC",
          f"(count={r['instrument_check']['count']})")

    if not r["ok"]:
        print("\n[STOP] Self-test en echec. Aucun ordre n'a ete envoye.")
        print(json.dumps(r, ensure_ascii=False, indent=2))
        input("\nEntree pour fermer...")
        return 2

    print(f"\n[READY] http://{HOST}:{PORT}")
    print("[READY] GET  /health")
    print("[READY] GET  /self-test")
    print("[READY] POST /demo/post-only")
    print("[READY] GET  /demo/order?ordId=...")
    print("[READY] POST /demo/cancel")
    print("\nAucun ordre n'est envoye au demarrage.")
    print("Ctrl+C pour arreter.")

    server = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
