@echo off
setlocal
cd /d "%~dp0"
title ERITH - OKX DEMO BRIDGE

if not exist "okx-demo.env" (
  echo [ERREUR] okx-demo.env introuvable dans:
  echo %CD%
  echo.
  pause
  exit /b 1
)

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 okx_demo_bridge.py
) else (
  python okx_demo_bridge.py
)

if not %errorlevel%==0 (
  echo.
  echo [ERREUR] Le Bridge s'est arrete avec une erreur.
  pause
)
endlocal
