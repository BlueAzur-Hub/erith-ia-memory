# 40.6.220 canonical entry patch

administrator/index.html

1. Add to EVIDENCE_MODULES immediately after strategy-a-foundation-applicability-truth.js:
   ./js/strategy-a-foundation-delegated-certification-406219.js

2. In mountEvidence(), invoke:
   AgentCryptoStrategyAFoundationDelegatedCertification.run("canonical-window-load")

3. Canonical wiring snapshot now exposes:
   foundation_delegated_available

No Market Core, Strategy A thresholds, Atlas, Oracle, Risk, real-order path,
recurring timer, observer or business network request changed.
