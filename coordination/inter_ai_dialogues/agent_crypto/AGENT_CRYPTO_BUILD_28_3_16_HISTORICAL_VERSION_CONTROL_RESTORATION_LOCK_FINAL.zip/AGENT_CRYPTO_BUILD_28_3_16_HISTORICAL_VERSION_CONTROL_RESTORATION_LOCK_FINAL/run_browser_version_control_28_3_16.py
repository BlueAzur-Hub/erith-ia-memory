import asyncio, json, re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent
WEB=ROOT/'public/agent_crypto_erith_ia/web'
R=[]
def rec(name,ok,details=''):
    ok=bool(ok);R.append({'name':name,'pass':ok,'details':str(details)});print('[version-316]',name,ok,details,flush=True)
    if not ok: raise AssertionError(f'{name}: {details}')
async def load(page):
    html=(WEB/'index.html').read_text(encoding='utf-8')
    html=re.sub(r'<link rel="stylesheet" href="\./style\.css[^>]*>','',html)
    html=re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>','',html)
    html=re.sub(r'<script src="\./app\.js[^>]*></script>','',html)
    await page.set_content(html,wait_until='domcontentloaded',timeout=60000)
    await page.evaluate("""() => {
      const makeStorage=()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>Array.from(m.keys())[i]??null,get length(){return m.size;}}};
      try{Object.defineProperty(window,'sessionStorage',{value:makeStorage(),configurable:true})}catch{}
      try{Object.defineProperty(window,'localStorage',{value:makeStorage(),configurable:true})}catch{}
    }""")
    await page.add_style_tag(content=(WEB/'style.css').read_text(encoding='utf-8'))
    await page.add_script_tag(content=(WEB/'app.js').read_text(encoding='utf-8'))
    await page.wait_for_timeout(400)
async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
    page=await browser.new_page(viewport={'width':1440,'height':900})
    errors=[]; page.on('pageerror',lambda e: errors.append(str(e)))
    await load(page)
    rec('candidate_loaded_2816',await page.evaluate('ATLAS_BUILD === "28.3.16"'))
    rec('candidate_token_2816',await page.evaluate('ATLAS_ASSET_TOKEN === "market-core-v2.0-alpha-build-28.3.16"'))
    rec('runtime_identity_coherent',await page.evaluate('atlasVersionRuntimeIdentity().ok === true'))

    # Normal update: strictly newer Build is detected and installable.
    await page.evaluate("""() => {
      atlasFetchVersionManifest=async()=>({build:'28.3.17',token:'market-core-v2.0-alpha-build-28.3.17',manifest:{build:'28.3.17'}});
      atlasVerifyRemotePublication=async remote=>({ok:true,build:remote.build,token:remote.token});
      window.__navTarget=''; atlasVersionNavigateToUpdate=target=>{window.__navTarget=target;return true;};
    }""")
    available=await page.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('strictly_newer_build_detected',available is True,available)
    rec('newer_build_state_available',await page.locator('#atlasVersionControl').get_attribute('data-state')=='available')
    await page.evaluate('atlasApplyVersionUpdate()')
    target=await page.evaluate('window.__navTarget')
    rec('newer_build_update_url','build=28.3.17' in target and 'asset_token=market-core-v2.0-alpha-build-28.3.17' in target,target)

    # Same Build + different token must NOT become a normal update.
    page2=await browser.new_page(viewport={'width':1440,'height':900}); errors2=[]; page2.on('pageerror',lambda e: errors2.append(str(e))); await load(page2)
    await page2.evaluate("""() => {
      atlasFetchVersionManifest=async()=>({build:'28.3.16',token:'market-core-v2.0-alpha-build-28.3.16-r2',manifest:{build:'28.3.16'}});
      atlasVerifyRemotePublication=async remote=>({ok:true,build:remote.build,token:remote.token});
      window.__navTarget=''; atlasVersionNavigateToUpdate=target=>{window.__navTarget=target;return true;};
    }""")
    same=await page2.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('same_build_changed_token_not_update',same is False,same)
    rec('same_build_changed_token_not_available',await page2.locator('#atlasVersionControl').get_attribute('data-state')!='available')
    await page2.evaluate("atlasApplyVersionUpdate({build:'28.3.16',token:'market-core-v2.0-alpha-build-28.3.16-r2'})")
    rec('same_build_changed_token_not_navigated',(await page2.evaluate('window.__navTarget'))=='',await page2.evaluate('window.__navTarget'))

    # Historical repair mode remains: same Build, same official token, incoherent local markers => repair/reload permitted.
    page3=await browser.new_page(viewport={'width':1440,'height':900}); errors3=[]; page3.on('pageerror',lambda e: errors3.append(str(e))); await load(page3)
    await page3.evaluate("""() => {
      document.querySelector('meta[name=atlas-build]').setAttribute('content','28.3.15');
      atlasFetchVersionManifest=async()=>({build:'28.3.16',token:'market-core-v2.0-alpha-build-28.3.16',manifest:{build:'28.3.16'}});
      atlasVerifyRemotePublication=async remote=>({ok:true,build:remote.build,token:remote.token});
      window.__navTarget=''; atlasVersionNavigateToUpdate=target=>{window.__navTarget=target;return true;};
    }""")
    repair_check=await page3.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('incoherent_runtime_check_returns_false',repair_check is False,repair_check)
    rec('incoherent_runtime_enters_repair',await page3.locator('#atlasVersionControl').get_attribute('data-state')=='repair',await page3.locator('#atlasVersionControl').get_attribute('data-state'))
    await page3.evaluate('atlasVersionControlAction()')
    repair_target=await page3.evaluate('window.__navTarget')
    rec('historical_same_build_repair_navigates','build=28.3.16' in repair_target and 'asset_token=market-core-v2.0-alpha-build-28.3.16' in repair_target,repair_target)

    # Remote manifest behind loaded app remains refused.
    page4=await browser.new_page(viewport={'width':1440,'height':900}); errors4=[]; page4.on('pageerror',lambda e: errors4.append(str(e))); await load(page4)
    await page4.evaluate("""() => {
      atlasFetchVersionManifest=async()=>({build:'28.3.15',token:'market-core-v2.0-alpha-build-28.3.15',manifest:{build:'28.3.15'}});
      atlasVerifyRemotePublication=async remote=>({ok:true,build:remote.build,token:remote.token});
    }""")
    behind=await page4.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('older_remote_refused',behind is False,behind)
    rec('older_remote_state_publishing',await page4.locator('#atlasVersionControl').get_attribute('data-state')=='publishing',await page4.locator('#atlasVersionControl').get_attribute('data-state'))

    ignored=('Failed to fetch','Chart is not defined','Chart is not a constructor')
    critical=[e for e in errors+errors2+errors3+errors4 if not any(x in e for x in ignored)]
    rec('no_critical_page_errors',not critical,critical)
    await browser.close()
  out={'build':'28.3.16','passed':sum(x['pass'] for x in R),'total':len(R),'all_passed':all(x['pass'] for x in R),'results':R}
  (ROOT/'BROWSER_VERSION_CONTROL_RESULTS_28_3_16.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print('[version-316] TOTAL',out['passed'],out['total'])
  raise SystemExit(0 if out['all_passed'] else 1)
asyncio.run(main())
