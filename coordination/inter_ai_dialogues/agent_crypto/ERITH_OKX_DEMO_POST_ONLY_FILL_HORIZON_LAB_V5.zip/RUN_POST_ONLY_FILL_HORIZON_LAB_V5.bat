@echo off
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY FILL HORIZON LAB V5
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0POST_ONLY_FILL_HORIZON_LAB_V5.py"
) else (
  python "%~dp0POST_ONLY_FILL_HORIZON_LAB_V5.py"
)
echo.
pause
