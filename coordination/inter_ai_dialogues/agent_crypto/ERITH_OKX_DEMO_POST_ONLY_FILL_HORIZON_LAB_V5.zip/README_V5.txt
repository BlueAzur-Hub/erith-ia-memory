ERITH · OKX DEMO · POST-ONLY FILL + HORIZON LAB V5

Place these 2 executable files in:
C:\ERITH\okx-demo-bridge\

Required existing component:
- ERITH_OKX_DEMO_BRIDGE_V2 running on 127.0.0.1:8791

Run:
RUN_POST_ONLY_FILL_HORIZON_LAB_V5.bat

V5:
- DEMO only
- 10 BTC-EUR BUY post_only tests at current best bid
- 60 s order timeout
- records OKX cancelSource + cancelSourceReason
- records ticker/book timestamps and exact bid depth
- correct median via statistics.median()
- after each fill, observes public market at +5/+15/+30/+60/+120 min
- writes rolling CHECKPOINT JSON files
- writes a FINAL JSON after the last +120 min observation
- does not place exit orders, live orders, withdrawals, or transfers

Important:
The +120 min monitoring phase can keep the window open for about two hours after the last fill.
