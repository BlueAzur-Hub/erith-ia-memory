#!/usr/bin/env python3
from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request
import urllib.error
import statistics
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
from datetime import datetime

BRIDGE = "http://127.0.0.1:8791"
OKX = "https://eea.okx.com"
INST = "BTC-EUR"
SERVICE = "ERITH_OKX_DEMO_BRIDGE_V2"

ATTEMPTS = 10
ORDER_TIMEOUT_S = 60
ORDER_CHECKPOINTS = (2, 5, 10, 20, 30, 45, 60)
POST_FILL_HORIZONS_S = (300, 900, 1800, 3600, 7200)  # +5/+15/+30/+60/+120 min
TARGET_EUR = Decimal("10")

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
LOG = ROOT / "post_only_horizon_lab_v5.log"

def log(msg=""):
    print(msg, flush=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")

def req(method, url, body=None, timeout=20):
    data = None
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "ERITH-POSTONLY-HORIZON-LAB-V5",
    }
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as x:
            return x.status, json.loads(x.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            obj = json.loads(raw)
        except Exception:
            obj = {"raw": raw}
        return e.code, obj

def D(x):
    return Decimal(str(x))

def fdec(x):
    if x in (None, ""):
        return None
    try:
        return Decimal(str(x))
    except Exception:
        return None

def ceil_step(v: Decimal, step: Decimal) -> Decimal:
    return (v / step).to_integral_value(rounding=ROUND_CEILING) * step

def pct(a: Decimal, b: Decimal):
    if a is None or b is None or b == 0:
        return None
    return float((a / b - Decimal("1")) * Decimal("100"))

def get_health():
    s, h = req("GET", BRIDGE + "/health")
    if s != 200 or not h.get("ok") or not h.get("demo") or h.get("service") != SERVICE:
        raise RuntimeError(f"Mauvais Bridge: HTTP {s} · {h}")
    return h

def get_ticker():
    q = urllib.parse.urlencode({"instId": INST})
    s, t = req("GET", OKX + "/api/v5/market/ticker?" + q)
    if s != 200 or str(t.get("code")) != "0" or not t.get("data"):
        raise RuntimeError(f"Ticker indisponible: HTTP {s} · {t}")
    return t["data"][0]

def get_instrument():
    q = urllib.parse.urlencode({"instType": "SPOT", "instId": INST})
    s, i = req("GET", OKX + "/api/v5/public/instruments?" + q)
    if s != 200 or str(i.get("code")) != "0" or not i.get("data"):
        raise RuntimeError(f"Instrument indisponible: HTTP {s} · {i}")
    return i["data"][0]

def get_book(depth=50):
    q = urllib.parse.urlencode({"instId": INST, "sz": str(depth)})
    s, b = req("GET", OKX + "/api/v5/market/books?" + q)
    if s != 200 or str(b.get("code")) != "0" or not b.get("data"):
        raise RuntimeError(f"Orderbook indisponible: HTTP {s} · {b}")
    return b["data"][0]

def get_market_snapshot():
    t = get_ticker()
    b = get_book(50)
    bid = fdec(t.get("bidPx"))
    ask = fdec(t.get("askPx"))
    last = fdec(t.get("last"))
    mid = None
    if bid is not None and ask is not None:
        mid = (bid + ask) / Decimal("2")
    return {
        "captured_local_ms": int(time.time() * 1000),
        "ticker_ts": t.get("ts"),
        "book_ts": b.get("ts"),
        "bid": str(bid) if bid is not None else None,
        "ask": str(ask) if ask is not None else None,
        "mid": str(mid) if mid is not None else None,
        "last": str(last) if last is not None else None,
        "book": b,
    }

def depth_at_price(book, side, px: Decimal):
    rows = book.get("bids" if side == "buy" else "asks") or []
    for row in rows:
        if len(row) >= 2 and fdec(row[0]) == px:
            return str(row[1])
    return "0"

def get_order(ord_id):
    q = urllib.parse.urlencode({"ordId": ord_id})
    s, o = req("GET", BRIDGE + "/demo/order?" + q)
    if s != 200 or str(o.get("code")) != "0" or not o.get("data"):
        raise RuntimeError(f"Lecture ordre impossible: HTTP {s} · {o}")
    return o["data"][0]

def cancel_order(ord_id):
    s, c = req("POST", BRIDGE + "/demo/cancel", {"ordId": ord_id})
    if s != 200 or str(c.get("code")) != "0":
        raise RuntimeError(f"Annulation impossible: HTTP {s} · {c}")
    return c

def order_fields(d):
    keys = (
        "state", "accFillSz", "avgPx", "fee", "feeCcy", "rebate", "rebateCcy",
        "fillPx", "fillSz", "fillTime", "tradeId",
        "cancelSource", "cancelSourceReason",
        "cTime", "uTime", "ordType", "px", "sz", "side", "instId",
    )
    return {k: d.get(k) for k in keys}

# Post-fill horizon scheduler.
# Each task contains the actual fill time and scheduled +5/+15/+30/+60/+120 minute captures.
HORIZON_TASKS = []

def schedule_horizons(attempt_no, ord_id, fill_time_ms, avg_px, fee, fee_ccy, fill_sz):
    if not fill_time_ms:
        fill_time_ms = int(time.time() * 1000)
    task = {
        "attempt": attempt_no,
        "ordId": ord_id,
        "fill_time_ms": int(fill_time_ms),
        "avgPx": str(avg_px),
        "fee": str(fee) if fee is not None else None,
        "feeCcy": fee_ccy,
        "fillSz": str(fill_sz),
        "captures": {},
    }
    HORIZON_TASKS.append(task)

def capture_due_horizons():
    now_ms = int(time.time() * 1000)
    for task in HORIZON_TASKS:
        entry = fdec(task["avgPx"])
        for h in POST_FILL_HORIZONS_S:
            key = str(h)
            if key in task["captures"]:
                continue
            due_ms = task["fill_time_ms"] + h * 1000
            if now_ms < due_ms:
                continue
            try:
                m = get_market_snapshot()
                bid = fdec(m["bid"])
                ask = fdec(m["ask"])
                mid = fdec(m["mid"])
                last = fdec(m["last"])

                fee = fdec(task.get("fee"))
                fill_sz = fdec(task.get("fillSz"))
                one_way_fee_pct = None
                if (
                    fee is not None and fill_sz is not None and fill_sz > 0
                    and task.get("feeCcy") == "BTC"
                ):
                    one_way_fee_pct = float(abs(fee / fill_sz) * Decimal("100"))

                capture = {
                    "horizon_s": h,
                    "captured_local_ms": m["captured_local_ms"],
                    "ticker_ts": m["ticker_ts"],
                    "book_ts": m["book_ts"],
                    "bid": m["bid"],
                    "ask": m["ask"],
                    "mid": m["mid"],
                    "last": m["last"],
                    "bid_move_pct_from_fill": pct(bid, entry),
                    "mid_move_pct_from_fill": pct(mid, entry),
                    "last_move_pct_from_fill": pct(last, entry),
                    "observed_entry_fee_pct": one_way_fee_pct,
                }
                if one_way_fee_pct is not None and capture["bid_move_pct_from_fill"] is not None:
                    mm_roundtrip_proxy = one_way_fee_pct * 2.0
                    capture["maker_maker_fee_proxy_pct"] = mm_roundtrip_proxy
                    capture["bid_move_minus_mm_fee_proxy_pct"] = (
                        capture["bid_move_pct_from_fill"] - mm_roundtrip_proxy
                    )
                    capture["covers_mm_fee_proxy"] = (
                        capture["bid_move_pct_from_fill"] >= mm_roundtrip_proxy
                    )

                task["captures"][key] = capture
                log(
                    f"[HORIZON] essai={task['attempt']} +{h//60}m "
                    f"bid_move={capture['bid_move_pct_from_fill']}% "
                    f"mid_move={capture['mid_move_pct_from_fill']}%"
                )
            except Exception as e:
                task["captures"][key] = {
                    "horizon_s": h,
                    "error": f"{type(e).__name__}: {e}",
                    "captured_local_ms": int(time.time() * 1000),
                }
                log(f"[HORIZON] essai={task['attempt']} +{h//60}m ERREUR: {e}")

def wait_with_horizons(seconds):
    end = time.time() + seconds
    while True:
        capture_due_horizons()
        remain = end - time.time()
        if remain <= 0:
            break
        time.sleep(min(1.0, remain))

def one_attempt(n, inst):
    t = get_ticker()
    book = get_book(50)

    bid = D(t["bidPx"])
    ask = D(t["askPx"])
    tick = D(inst["tickSz"])
    lot = D(inst["lotSz"])
    min_sz = D(inst["minSz"])

    if bid <= 0 or ask <= 0 or bid >= ask:
        raise RuntimeError(f"Marché non exploitable pour post-only: bid={bid} ask={ask}")

    px = bid  # BEST BID
    sz = ceil_step(TARGET_EUR / px, lot)
    if sz < min_sz:
        sz = min_sz

    queue_depth_before = depth_at_price(book, "buy", px)

    log("")
    log(f"--- ESSAI {n}/{ATTEMPTS} ---")
    log(
        f"[MARKET] bid={bid} ask={ask} spread={ask-bid} tick={tick} "
        f"ticker_ts={t.get('ts')} book_ts={book.get('ts')}"
    )
    log(f"[QUEUE] depth_at_exact_bid_before={queue_depth_before}")
    log(f"[ORDER] BUY POST_ONLY @ BEST BID · px={px} · sz={sz}")

    s, placed = req(
        "POST", BRIDGE + "/demo/post-only",
        {"side": "buy", "px": format(px, "f"), "sz": format(sz, "f")}
    )
    if s != 200 or str(placed.get("code")) != "0" or not placed.get("data"):
        raise RuntimeError(f"Ordre refusé: HTTP {s} · {placed}")

    row = placed["data"][0]
    if str(row.get("sCode", "0")) != "0":
        raise RuntimeError(f"OKX sCode={row.get('sCode')} · {row.get('sMsg')}")

    ord_id = str(row.get("ordId", "")).strip()
    if not ord_id:
        raise RuntimeError("ordId absent")

    placed_local_ms = int(time.time() * 1000)
    log(f"[PLACED] ordId={ord_id}")

    snapshots = []
    previous_elapsed = 0
    scheduled = False

    for target in ORDER_CHECKPOINTS:
        wait_with_horizons(target - previous_elapsed)
        previous_elapsed = target
        d = get_order(ord_id)
        od = order_fields(d)
        od["after_s"] = target
        snapshots.append(od)

        log(
            f"[T+{target}] state={od.get('state')} fill={od.get('accFillSz')} "
            f"avgPx={od.get('avgPx')} fee={od.get('fee')} {od.get('feeCcy')} "
            f"cancelSource={od.get('cancelSource')} "
            f"reason={od.get('cancelSourceReason')}"
        )

        fill_sz = fdec(od.get("accFillSz")) or Decimal("0")
        if fill_sz > 0 and not scheduled:
            avg_px = fdec(od.get("avgPx"))
            fill_time = od.get("fillTime") or od.get("uTime")
            if avg_px:
                schedule_horizons(
                    n, ord_id, fill_time, avg_px,
                    fdec(od.get("fee")), od.get("feeCcy"), fill_sz
                )
                scheduled = True

        if od.get("state") in ("filled", "canceled", "mmp_canceled"):
            break

    d = get_order(ord_id)
    state_before_cancel = d.get("state")

    if state_before_cancel in ("live", "partially_filled"):
        log(f"[CANCEL] user cancel après {previous_elapsed}s")
        cancel_order(ord_id)
        wait_with_horizons(2)

    final = get_order(ord_id)
    final_fields = order_fields(final)

    # If fill only became visible in final state, schedule horizons now.
    final_fill = fdec(final_fields.get("accFillSz")) or Decimal("0")
    if final_fill > 0 and not scheduled:
        avg_px = fdec(final_fields.get("avgPx"))
        fill_time = final_fields.get("fillTime") or final_fields.get("uTime")
        if avg_px:
            schedule_horizons(
                n, ord_id, fill_time, avg_px,
                fdec(final_fields.get("fee")), final_fields.get("feeCcy"), final_fill
            )
            scheduled = True

    # Queue/depth after finalization is contextual only: not a true queue-position measure.
    post_book = get_book(50)
    queue_depth_after = depth_at_price(post_book, "buy", px)

    return {
        "attempt": n,
        "submitted_at": datetime.now().isoformat(timespec="seconds"),
        "placement_local_ms": placed_local_ms,
        "market_at_submit": {
            "bid": str(bid),
            "ask": str(ask),
            "spread": str(ask - bid),
            "tickSz": str(tick),
            "lotSz": str(lot),
            "minSz": str(min_sz),
            "ticker_ts": t.get("ts"),
            "book_ts": book.get("ts"),
            "depth_at_exact_bid_before": queue_depth_before,
            "depth_at_exact_bid_after_final": queue_depth_after,
        },
        "order": {
            "side": "buy",
            "ordType": "post_only",
            "px": format(px, "f"),
            "sz": format(sz, "f"),
            "ordId": ord_id,
        },
        "snapshots": snapshots,
        "state_before_user_cancel": state_before_cancel,
        "final": final_fields,
        "horizon_scheduled": scheduled,
    }

def summarize_orders(results):
    valid = [r for r in results if "error" not in r]
    full, partial, nofill = 0, 0, 0
    first_fill_times = []
    fee_rates = []
    cancel_sources = {}

    for r in valid:
        f = r["final"]
        fill = fdec(f.get("accFillSz")) or Decimal("0")
        size = D(r["order"]["sz"])

        if fill <= 0:
            nofill += 1
        elif fill < size:
            partial += 1
        else:
            full += 1

        for s in r["snapshots"]:
            if (fdec(s.get("accFillSz")) or Decimal("0")) > 0:
                first_fill_times.append(int(s["after_s"]))
                break

        fee = fdec(f.get("fee"))
        if fee is not None and fill > 0 and f.get("feeCcy") == "BTC":
            fee_rates.append(float(abs(fee / fill) * Decimal("100")))

        if f.get("state") == "canceled":
            src = str(f.get("cancelSource") or "")
            reason = str(f.get("cancelSourceReason") or "")
            key = f"{src}|{reason}"
            cancel_sources[key] = cancel_sources.get(key, 0) + 1

    return {
        "valid_attempts": len(valid),
        "filled": full,
        "partial": partial,
        "no_fill": nofill,
        "fill_rate_pct": round((full + partial) * 100 / len(valid), 2) if valid else 0,
        "full_fill_rate_pct": round(full * 100 / len(valid), 2) if valid else 0,
        "first_fill_times_s": first_fill_times,
        "first_fill_median_s": statistics.median(first_fill_times) if first_fill_times else None,
        "observed_entry_fee_rates_pct": fee_rates,
        "observed_entry_fee_median_pct": statistics.median(fee_rates) if fee_rates else None,
        "cancel_sources": cancel_sources,
    }

def summarize_horizons(tasks):
    by_h = {}
    for h in POST_FILL_HORIZONS_S:
        vals_bid = []
        vals_net_proxy = []
        covers = 0
        n_cover_eval = 0
        errors = 0

        for t in tasks:
            c = t["captures"].get(str(h))
            if not c:
                continue
            if "error" in c:
                errors += 1
                continue

            bm = c.get("bid_move_pct_from_fill")
            if bm is not None:
                vals_bid.append(float(bm))

            net = c.get("bid_move_minus_mm_fee_proxy_pct")
            if net is not None:
                vals_net_proxy.append(float(net))

            cv = c.get("covers_mm_fee_proxy")
            if cv is not None:
                n_cover_eval += 1
                covers += 1 if cv else 0

        by_h[str(h)] = {
            "horizon_min": h // 60,
            "observations": len(vals_bid),
            "errors": errors,
            "median_bid_move_pct": statistics.median(vals_bid) if vals_bid else None,
            "median_bid_move_minus_mm_fee_proxy_pct": (
                statistics.median(vals_net_proxy) if vals_net_proxy else None
            ),
            "covers_mm_fee_proxy_count": covers if n_cover_eval else None,
            "covers_mm_fee_proxy_rate_pct": (
                round(covers * 100 / n_cover_eval, 2) if n_cover_eval else None
            ),
        }
    return by_h

def save_report(results, final=False):
    REPORTS.mkdir(exist_ok=True)
    payload = {
        "lab": "POST_ONLY_FILL_HORIZON_LAB_V5",
        "mode": "OKX_DEMO",
        "instrument": INST,
        "attempts_requested": ATTEMPTS,
        "order_timeout_s": ORDER_TIMEOUT_S,
        "placement": "BEST_BID",
        "target_eur": str(TARGET_EUR),
        "post_fill_horizons_s": list(POST_FILL_HORIZONS_S),
        "order_summary": summarize_orders(results),
        "horizon_summary": summarize_horizons(HORIZON_TASKS),
        "results": results,
        "post_fill_tasks": HORIZON_TASKS,
        "complete": final,
    }
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = "FINAL" if final else "CHECKPOINT"
    path = REPORTS / f"post_only_fill_horizon_lab_v5_{suffix}_{stamp}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path

def main():
    LOG.write_text("", encoding="utf-8")
    REPORTS.mkdir(exist_ok=True)

    log("=" * 72)
    log("ERITH · OKX DEMO · POST-ONLY FILL + HORIZON LAB V5")
    log("=" * 72)

    h = get_health()
    inst = get_instrument()
    log(f"[OK] Bridge={h.get('service')} · {h.get('bind')} · demo={h.get('demo')}")
    log(
        f"[OK] {ATTEMPTS} essais · BEST BID · timeout {ORDER_TIMEOUT_S}s · "
        f"horizons +5/+15/+30/+60/+120 min"
    )
    log("[SAFE] DEMO uniquement. Aucun ordre live. Aucun retrait/transfert.")

    results = []

    for n in range(1, ATTEMPTS + 1):
        try:
            r = one_attempt(n, inst)
            results.append(r)
        except Exception as e:
            log(f"[ESSAI {n}] ERREUR: {type(e).__name__}: {e}")
            results.append({"attempt": n, "error": f"{type(e).__name__}: {e}"})

        cp = save_report(results, final=False)
        log(f"[CHECKPOINT] {cp.name}")
        wait_with_horizons(3)

    order_summary = summarize_orders(results)
    log("")
    log("================ BILAN ORDRES ================")
    log(f"valid_attempts={order_summary['valid_attempts']}")
    log(f"filled={order_summary['filled']}")
    log(f"partial={order_summary['partial']}")
    log(f"no_fill={order_summary['no_fill']}")
    log(f"fill_rate_pct={order_summary['fill_rate_pct']}")
    log(f"first_fill_median_s={order_summary['first_fill_median_s']}")
    log(f"entry_fee_median_pct={order_summary['observed_entry_fee_median_pct']}")
    log(f"cancel_sources={order_summary['cancel_sources']}")
    log("==============================================")

    if HORIZON_TASKS:
        last_due_ms = max(
            t["fill_time_ms"] + max(POST_FILL_HORIZONS_S) * 1000
            for t in HORIZON_TASKS
        )
        log("")
        log("[MONITOR] Les ordres sont terminés.")
        log("[MONITOR] Le script continue uniquement à observer le marché public")
        log("[MONITOR] jusqu'au dernier horizon +120 min. Aucun nouvel ordre.")

        next_checkpoint = time.time() + 60
        while int(time.time() * 1000) <= last_due_ms + 3000:
            capture_due_horizons()
            if time.time() >= next_checkpoint:
                cp = save_report(results, final=False)
                log(f"[CHECKPOINT HORIZON] {cp.name}")
                next_checkpoint = time.time() + 60
            time.sleep(1)

    capture_due_horizons()
    final_path = save_report(results, final=True)

    log("")
    log("================ BILAN FINAL =================")
    log(json.dumps(summarize_horizons(HORIZON_TASKS), ensure_ascii=False, indent=2))
    log(f"rapport_final={final_path}")
    log("==============================================")

if __name__ == "__main__":
    code = 0
    try:
        main()
    except KeyboardInterrupt:
        code = 130
        log("")
        log("[STOP] Interrompu par l'utilisateur. Les checkpoints déjà écrits restent disponibles.")
    except Exception as e:
        code = 1
        log("")
        log("!!!!!!!! ERREUR LAB V5 !!!!!!!!")
        log(f"{type(e).__name__}: {e}")
        log(f"log={LOG}")
    finally:
        print()
        input("Entrée pour fermer...")
    raise SystemExit(code)
