# Restore Agent-Crypto 40.6.99

Canonical repository: BlueAzur-Hub/erith-ia-memory

Canonical release commit:

`38d90a68b16b667dc70fde96bc3944fcaf8d75a6`

The exact immutable Administrator entry is:

`public/agent_crypto_erith_ia/administrator/index-40.6.99.html`

This ZIP is a **validated delivery / recovery bundle**, not a duplicate of all unchanged binary assets in the repository.
Use the canonical commit when exact full-tree reconstruction is required.
