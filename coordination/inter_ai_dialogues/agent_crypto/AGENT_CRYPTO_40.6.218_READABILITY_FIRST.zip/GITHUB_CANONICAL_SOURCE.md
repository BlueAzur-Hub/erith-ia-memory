Canonical source remains on GitHub:
BlueAzur-Hub/erith-ia-memory

Presentation asset:
public/agent_crypto_erith_ia/administrator/js/administrator-operator-focus-406216.js

Build truth:
public/agent_crypto_erith_ia/administrator/build.json

Receipt:
public/agent_crypto_erith_ia/administrator/RELEASE_40_6_218.md
