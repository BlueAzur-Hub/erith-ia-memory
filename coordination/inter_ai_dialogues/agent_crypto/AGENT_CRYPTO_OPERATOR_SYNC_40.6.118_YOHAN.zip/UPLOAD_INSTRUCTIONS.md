# Upload — Operator Yohan 40.6.118

Cible : `BlueAzur-Hub/agent-crypto-operator`

## Ce ZIP est une synchronisation bornée

Il part de l'architecture Operator 40.6.99 déjà publiée et remplace uniquement les références de runtime 40.6.99 par le checkpoint canonique Administrator 40.6.118.

Il ne copie pas le gros runtime Administrator.
Il ne modifie pas `yohan-operator-profile.js`.
Il ne touche pas au Market Core 38.15.11.
Il ne configure pas encore le futur Bridge local de Yohan.
Il ne crée aucun ordre réel, wallet ou secret.

## À déposer dans le dépôt

Décompresse le ZIP puis fusionne son contenu à la racine du dépôt.

Remplacer :
- `public/agent_crypto_erith_ia/administrator/YOHAN_PROFILE_README.md`
- `public/agent_crypto_erith_ia/administrator/yohan.html`
- `public/agent_crypto_erith_ia/operator/index.html`
- `public/agent_crypto_erith_ia/operator/build.json`

Ajouter :
- `public/agent_crypto_erith_ia/operator/index-40.6.118.html`

Conserver :
- `public/agent_crypto_erith_ia/administrator/js/yohan-operator-profile.js`
- `public/agent_crypto_erith_ia/operator/index-40.6.99.html`
- le rollback local Administrator 40.6.73 R2
- tous les autres historiques

Commit conseillé :

`sync(agent-crypto-operator): route Yohan Operator to canonical 40.6.118`

## Vérification après publication

1. `operator/build.json` annonce `40.6.118`.
2. `operator/index.html` pointe vers `index-40.6.118.html`.
3. `administrator/yohan.html` charge le runtime maître `index-40.6.118.html`.
4. Le cockpit affiche Build 40.6.118 / Market Core 38.15.11.
5. La couche Yohan reste chargée.
6. Aucun nouveau privilège Administrator, wallet ou ordre réel n'est introduit.

Si une de ces preuves échoue : STOP. Ne pas reconstruire l'interface.
