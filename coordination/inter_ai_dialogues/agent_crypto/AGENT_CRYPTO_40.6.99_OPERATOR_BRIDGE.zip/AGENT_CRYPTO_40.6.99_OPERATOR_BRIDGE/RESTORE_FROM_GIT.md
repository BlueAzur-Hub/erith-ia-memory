# Restore Operator 40.6.99

Canonical repository: `BlueAzur-Hub/erith-ia-memory`

Operator delivery commit:

`aa21501e3d2300c814ed27c508c7b835f6dcb639`

Validated shared runtime release commit:

`38d90a68b16b667dc70fde96bc3944fcaf8d75a6`

Operator entry:
`public/agent_crypto_erith_ia/operator/index-40.6.99.html`

Shared runtime target:
`public/agent_crypto_erith_ia/administrator/index-40.6.99.html?view=intermediate`

The included Aether Operator Bridge is the canonical source already loaded by the shared Administrator runtime. No privilege elevation is added.
