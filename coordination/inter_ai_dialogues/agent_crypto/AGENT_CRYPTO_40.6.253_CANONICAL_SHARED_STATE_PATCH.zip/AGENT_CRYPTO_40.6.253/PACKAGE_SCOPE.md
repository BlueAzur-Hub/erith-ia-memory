# AGENT-CRYPTO 40.6.253 — PACKAGE SCOPE

Exact bounded patch package for the canonical shared-state Decision Intelligence repair.
Contains every file changed by this repair plus receipt and final thread handoff.
This is NOT a full repository snapshot.

Canonical repository: BlueAzur-Hub/erith-ia-memory
Handoff commit before ZIP packaging: 5c3924de84a9ee90f8b29b3ffe961ed648ac1131

Critical rule:
version the publication, not the functions.
Active owner: js/decision-intelligence-current-truth.js
Legacy build-numbered current-truth files remain inert.
