$ErrorActionPreference = "Stop"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

$Out = "AtlasCryptoBridgeControlCenter.exe"
go build -trimpath -ldflags "-H windowsgui -s -w" -o $Out main.go
Write-Host "Compilation terminee : Control Center V2.3.2R18 / Bridge V1.9.13 / Private Backend V1.4.3 OKX ORDERBOOK DEPTH READ ONLY / double supervision locale 8787+8790 / Windows GUI / aucune console hote."
