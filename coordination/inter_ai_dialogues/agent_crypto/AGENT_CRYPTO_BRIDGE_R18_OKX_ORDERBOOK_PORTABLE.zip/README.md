# Aether Control — Atlas-10 Crypto Bridge 2.3.2R18

R17 keeps Oracle Evidence on the existing Bridge 8787 and hardens the GitHub transport after two reproduced write timeouts on R16. It also fixes cold readback for chunks larger than 1 MiB.

## Runtime

- `bridge/bridge.py` — Bridge **V1.9.13** on `127.0.0.1:8787`;
- `backend/private_backend.py` — Private Backend **V1.4.3** on `127.0.0.1:8790`, unchanged and read-only;
- Seven Vault remains independent on `127.0.0.1:8780`.

## New bounded Bridge capability

Owner-only capabilities:
- `oracle_evidence.read`;
- `oracle_evidence.publish`.

Routes:
- `GET /oracle-evidence/status`;
- `POST /oracle-evidence/ingest`.

The ingest owner validates bundle schema, JSONL, SHA-256, row_count, IDs and watermark; atomically commits chunk + PENDING manifest; reads the committed chunk back from GitHub; then commits the manifest as VERIFIED.

## Safety

- existing Aether Trust / Bridge session required;
- GitHub credential remains local to the Bridge;
- no GitHub credential in Firefox;
- no generic GitHub write capability;
- no local Evidence delete API;
- no retention change;
- no automatic upload;
- Backend 8790 unchanged;
- no real order or wallet action.

## Build

Use `source/BUILD_WINDOWS.ps1`. The resulting EXE is Windows GUI (`-H windowsgui`) and embeds the updated payload.

## R17 resilience

- large GitHub blob write timeout: 180 s;
- one bounded retry on timeout/network error;
- cold readback timeout: 120 s;
- files larger than 1 MiB are read back through Git blob API after object-metadata lookup;
- browser-side ingest window is expected to allow up to 300 s in Agent-Crypto 40.6.485;
- no retention or delete behavior changes.


R18 adds OKX multi-level orderbook evidence on Backend 8790 (`/orderbook?asset=BTC&depth=100`) for Agent-Crypto 40.6.492. Read-only only.
