# Atlas-10 Crypto Bridge R18 / Backend V1.4.3 — OKX Orderbook Depth Truth

- Control Center: **2.3.2R18**
- Bridge: **V1.9.13 unchanged**
- Private Backend: **V1.4.3**
- Agent-Crypto target: **40.6.492**
- Backend bind: **127.0.0.1:8790 only**
- New route: `GET /orderbook?asset=BTC&depth=100`
- Upstream: OKX public `GET /api/v5/market/books`
- Read-only: POST/PUT/PATCH/DELETE remain blocked
- No wallet, key, withdrawal, signature or order endpoint
- No Strategy A threshold, Cost Gate, Risk Governor or Market Core modification

## Static verification

- Python compile: PASS
- Private Backend self-test: PASS
- `/health` V1.4.3 read-only capabilities: PASS
- unsupported asset rejects with HTTP 400: PASS
- write method rejects with HTTP 405: PASS
- Windows amd64 GUI rebuild reproducibility: PASS
- Ryzen/Firefox terrain proof: PENDING

## SHA-256

```text
d9209dd5321464f90ffc1b77f7d03b99bfea908900c9ad45c28369811a02a5e6  ATLAS_10_CRYPTO_BRIDGE_CONTROL_CENTER_2_3_2R18_BRIDGE_V1_9_13_BACKEND_V1_4_3_OKX_ORDERBOOK_DEPTH_GUI_NO_CONSOLE.exe
5d5811bc7cbe320eb4b761131833319048c50a794172bb28eded72632339e05a  backend/private_backend.py
abc821e68bc77d183894581c743a085a450edfa06b49348a7c0f374a834b7ec4  bridge/bridge.py
9b814ebe1bfacffd05320217af0fa3b019eefc49a032bec529bcc7fbcd951d3a  bridge/bridge_config.json
22788db865fec6802928a6d5143093cfea451bc73d82e11cf918123932136d1e  source/main.go
385abdded92e52c4f6ef0c909f319f89d4fde956109585d2c02efd6de6f014d2  source/payload.zip
```
