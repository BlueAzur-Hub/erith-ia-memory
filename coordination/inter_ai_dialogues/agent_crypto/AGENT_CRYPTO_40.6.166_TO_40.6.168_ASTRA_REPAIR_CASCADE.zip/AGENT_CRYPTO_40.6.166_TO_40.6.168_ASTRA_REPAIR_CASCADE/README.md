# Astra repair cascade 40.6.166 → 40.6.168

- 40.6.163 delivery-entry correction package
- 40.6.166 Evidence Dossier lifecycle truth
- 40.6.167 Foundation applicability truth
- 40.6.168 Time semantics truth

Firefox terrain remains required. G3 remains PENDING and G9 remains LOCKED.
