# Agent-Crypto Build 28.2.72 — Bridge Canonical Stack Recovery Lock

## Remplacement GitHub

Téléverser le contenu de ce ZIP à la racine du dépôt.

Fichiers remplacés :

- `public/agent_crypto_erith_ia/web/app.js`
- `public/agent_crypto_erith_ia/web/index.html`
- `public/agent_crypto_erith_ia/web/style.css`
- `public/agent_crypto_erith_ia/web/version.json`

## Portée

- Control Center canonique : V2.1.0R1
- Bridge canonique : V1.7.6
- Interface : Build 28.2.72
- Métaux : sources publiques GitHub Actions uniquement
- Aucun changement de géométrie Crypto ou Métaux
- Aucun collecteur modifié
