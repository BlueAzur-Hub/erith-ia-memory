# Upload — Build 28.2.71

Téléverser le contenu du ZIP à la racine du dépôt en conservant les chemins.

## Fichiers applicatifs à remplacer

- `public/agent_crypto_erith_ia/web/app.js`
- `public/agent_crypto_erith_ia/web/index.html`
- `public/agent_crypto_erith_ia/web/style.css`
- `public/agent_crypto_erith_ia/web/version.json`

## Après publication

1. Attendre la fin du déploiement GitHub Pages.
2. Ouvrir le domaine Métaux.
3. Sélectionner `TOUS 5/5` et `24 h`.
4. Faire `Ctrl+F5`.
5. Parcourir le graphique avec la souris et confirmer que les cinq lignes XAU, XAG, XPT, XPD et HG restent visibles.

Aucun fichier de données, collecteur, workflow GitHub Actions, Bridge ou moteur Crypto n'est inclus.
