# Rapport de vérification — Build 28.2.71

## Objet

Finalisation de la géométrie du tableau mobile `PRIX HISTORIQUE` Métaux. La capture 28.2.70 montrait un panneau déclaré 5/5 mais limité visuellement à XAU, XAG et XPT.

## Correction

- cinq lignes visibles simultanément ;
- aucune barre de défilement ;
- en-tête, lignes et pied compactés sur le modèle de densité du tableau Crypto ;
- XPD et HG ne sont plus coupés ;
- prix historique, variation, identité et repère coloré conservés ;
- comportement mobile gauche/droite et point réel le plus proche inchangés.

## Contrôles réussis

- `node --check app.js` ;
- JSON `version.json` valide ;
- cinq éléments HTML Métaux présents ;
- budget géométrique calculé pour un conteneur graphique de 250 px : `{"reference_plot_height_px": 250, "available_panel_height_px": 238, "header_budget_px": 32, "row_height_px": 31, "row_count": 5, "rows_budget_px": 155, "footer_budget_px": 25, "estimated_total_px": 212, "remaining_margin_px": 26, "all_rows_fit": true, "scroll_required": false}` ;
- budget total estimé à 212 px pour 238 px disponibles ; validation visuelle Firefox encore requise ;
- empreinte moteur inspecteur Métaux inchangée : `998cc5708a75dd6eb42094187a8cb06df5e75ae89a51f6681bb8d9e0fb2f9cae` ;
- empreinte moteur inspecteur Crypto inchangée : `303379c9b9f6620b67a60dda0b26a7fa65f7a0b5c33d2cd33575f8480c445cd8` ;
- absence de collecteur, données Métaux, workflow ou Bridge dans le ZIP.

## Validation restante

Contrôle visuel final dans Firefox après publication et `Ctrl+F5`.
