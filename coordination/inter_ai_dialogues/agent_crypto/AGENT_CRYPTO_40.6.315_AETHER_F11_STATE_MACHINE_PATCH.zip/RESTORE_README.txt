AGENT-CRYPTO 40.6.315 — AETHER F11 STATE MACHINE

Functional commit: bb373fb64440918b3a63a31690e3f24d429eed9b
Purpose: remove false F11 detection caused by generic viewport growth.

Repair:
- window.resize is only a wake event
- Firefox window.fullScreen is the F11 state truth
- opening/closing F12 DevTools does not change F11 state
- ordinary browser resize does not change F11 state
- F11 still applies the historical temporary 16:9 Aether field
- F11 exit restores the exact pre-F11 rectangle
- active bridge and dataset names are stable and contain no build number

Protected / unchanged:
- CSS: unchanged
- Window Manager: unchanged
- Market Core 38.15.11: unchanged
- Oracle / Storage / Strategy / Lecture Technique logic: unchanged

Firefox terrain gate:
1. Ctrl+F5.
2. Open Aether in normal browser.
3. Open F12 then close F12: Aether must not jump.
4. Resize Firefox substantially: Aether must not enter the large F11 field.
5. Press F11: Aether must expand to the historical 16:9 field.
6. Press F11 again: exact pre-F11 normal rectangle must return.
