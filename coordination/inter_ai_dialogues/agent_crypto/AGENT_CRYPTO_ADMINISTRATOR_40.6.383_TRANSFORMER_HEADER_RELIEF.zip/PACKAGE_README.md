# Agent-Crypto Administrator 40.6.383 — package de livraison

Build : 40.6.383
Parent : 40.6.382
Commit fonctionnel : 37c938d50f2b81ad6a61d0dfe658681a06108636

Delta exact :
- masque uniquement le badge visuel ENGINE sur <=1280 CSS px ;
- conserve la vérité Engine 38.15.11 dans build.json, meta et runtime ;
- ne déplace aucun autre contrôle ;
- Math Core, REDIVIDER et Lecture Technique inchangés.
