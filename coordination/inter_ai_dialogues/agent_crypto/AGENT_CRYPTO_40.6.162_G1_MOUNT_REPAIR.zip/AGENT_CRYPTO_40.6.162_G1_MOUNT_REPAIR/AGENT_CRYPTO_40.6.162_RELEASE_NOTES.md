# Agent-Crypto 40.6.162 — Strategy A G1 Mount Repair

## Diagnostic terrain 40.6.161
Firefox chargeait bien 40.6.161, mais le panneau `strategyADossier` / `G1 · AFTER-COST DATA TRUTH` était absent de l'export DOM.
L'audit `strategyAEvidenceGateAudit` était, lui, présent et visible.

## Correction
`strategy-a-evidence-dossier.js` conserve ses ancres historiques `strategyASafety` / `strategyAAfterCost`, puis accepte comme fallback :
- `strategyAEvidenceGateAudit` (insertion juste avant l'audit) ;
- `.sapv2-gates` ou `.sapv2-wait` dans `strategyAPaperV2ProofBridge`.

Le montage est retenté uniquement sur des événements bornés : DOMContentLoaded, load, pageshow, click, focusin et double requestAnimationFrame.
Aucun timer récurrent, MutationObserver ou stockage n'est ajouté.

## Garde-fous
- G1 reste `EVIDENCE_REQUIRED`.
- Aucun PASS créé.
- Calculs `datasetReadiness()` inchangés.
- Aucun seuil, lifecycle, Risk, comportement PAPER ou ordre modifié.
- Market Core 38.15.11, Web Classique, Aether, Atlas CURRENT, Oracle, Lecture Technique et TRADUS inchangés.

## Vérifications
- Syntaxe JavaScript : PASS (`node --check`).
- Ancres fallback présentes dans le patch : PASS.
- Aucun `setInterval` / `MutationObserver` ajouté : PASS.
- Nombre de `setTimeout` inchangé par rapport à 40.6.161 (revokeObjectURL existant seulement) : PASS.
- GitHub `build.json` : 40.6.162 vérifié.
- Release immuable 40.6.162 : vérifiée.
- Firefox terrain : PENDING.

## Commits
- Runtime mount repair : `69152de55c31b6c0dade44631c00d1f8f54a1c94`
- Release immuable : `1d94022c73d04cb81979a8ebb767bdbf1da3ebec`
- Promotion : `8c82bdda974c0fba84454a3353cecf80cf2b6d79`
