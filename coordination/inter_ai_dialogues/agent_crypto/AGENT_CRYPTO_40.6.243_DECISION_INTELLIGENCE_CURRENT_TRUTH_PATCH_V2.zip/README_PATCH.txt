AGENT-CRYPTO 40.6.243 — PATCH ZIP

This is a PATCH ZIP, not a complete Administrator snapshot.

Contains:
- new Decision Intelligence current-truth module
- release receipt
- patch manifest / commit references

The canonical GitHub repository contains the complete current index.html and build.json.
