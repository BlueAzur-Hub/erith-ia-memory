Agent-Crypto 40.6.336 Markets Observatory Lazy Cycle Guard
Functional commit: c976e155822100fc8ca063b95b305a2592ecd8dd
Market Core: 38.15.11
PAPER ONLY. No real order.
