#!/usr/bin/env python3
from __future__ import annotations
import base64, hashlib, hmac, json, sys, urllib.parse, urllib.request, urllib.error
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8791
BASE_URL = "https://eea.okx.com"
INST_ID = "BTC-EUR"
ENV_FILE = Path(__file__).with_name("okx-demo.env")
SERVICE_ID = "ERITH_OKX_DEMO_BRIDGE_V2"

def load_env(path: Path):
    if not path.exists():
        raise RuntimeError(f"Fichier introuvable: {path}")
    d = {}
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        d[k.strip()] = v.strip()
    return d

ENV = load_env(ENV_FILE)
API_KEY = ENV.get("OKX_DEMO_API_KEY", "")
SECRET_KEY = ENV.get("OKX_DEMO_SECRET_KEY", "")
PASSPHRASE = ENV.get("OKX_DEMO_PASSPHRASE", "")
missing = [k for k,v in {
    "OKX_DEMO_API_KEY": API_KEY,
    "OKX_DEMO_SECRET_KEY": SECRET_KEY,
    "OKX_DEMO_PASSPHRASE": PASSPHRASE
}.items() if not v]
if missing:
    raise RuntimeError("Valeurs manquantes dans okx-demo.env: " + ", ".join(missing))

def ts():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00","Z")

def sign(timestamp, method, request_path, body):
    msg = timestamp + method.upper() + request_path + body
    dig = hmac.new(SECRET_KEY.encode(), msg.encode(), hashlib.sha256).digest()
    return base64.b64encode(dig).decode()

def okx_request(method, path, query=None, payload=None, private=True):
    query = query or {}
    qs = urllib.parse.urlencode(query)
    req_path = path + (("?" + qs) if qs else "")
    body = ""
    data = None
    if payload is not None:
        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
        data = body.encode("utf-8")
    headers = {"Content-Type":"application/json","User-Agent":"ERITH-OKX-DEMO-BRIDGE-V2"}
    if private:
        t = ts()
        headers.update({
            "OK-ACCESS-KEY": API_KEY,
            "OK-ACCESS-SIGN": sign(t, method, req_path, body),
            "OK-ACCESS-TIMESTAMP": t,
            "OK-ACCESS-PASSPHRASE": PASSPHRASE,
            "x-simulated-trading": "1",
        })
    req = urllib.request.Request(BASE_URL + req_path, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try: obj = json.loads(raw)
        except Exception: obj = {"raw": raw}
        return e.code, obj
    except Exception as e:
        return 0, {"code":"LOCAL_ERROR","msg":str(e)}

def self_test():
    s1, a = okx_request("GET","/api/v5/account/balance",private=True)
    s2, i = okx_request("GET","/api/v5/public/instruments",
                        query={"instType":"SPOT","instId":INST_ID},private=False)
    ok1 = s1 == 200 and str(a.get("code","")) == "0"
    data = i.get("data") if isinstance(i,dict) else None
    ok2 = s2 == 200 and str(i.get("code","")) == "0" and isinstance(data,list) and len(data)>0
    return {
        "ok": bool(ok1 and ok2),
        "auth":{"ok":ok1,"http":s1,"code":str(a.get("code","")),"msg":a.get("msg","")},
        "instrument":{"ok":ok2,"http":s2,"count":len(data) if isinstance(data,list) else 0}
    }

class H(BaseHTTPRequestHandler):
    def _send(self,status,obj):
        b = json.dumps(obj,ensure_ascii=False,indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Content-Length",str(len(b)))
        self.send_header("Cache-Control","no-store")
        self.end_headers()
        self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get("Content-Length","0") or "0")
        return json.loads((self.rfile.read(n) if n else b"{}").decode("utf-8"))

    def log_message(self,fmt,*args):
        sys.stdout.write("[LOCAL] "+(fmt % args)+"\n")

    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(p.query)
        if p.path == "/health":
            return self._send(200,{
                "ok":True,
                "service":SERVICE_ID,
                "demo":True,
                "bind":f"http://{HOST}:{PORT}",
                "port":PORT,
                "instrument":INST_ID,
                "region":"EEA"
            })
        if p.path == "/self-test":
            r = self_test()
            return self._send(200 if r["ok"] else 502,r)
        if p.path == "/demo/order":
            oid = (q.get("ordId") or [""])[0].strip()
            if not oid: return self._send(400,{"ok":False,"error":"ordId requis"})
            s,o = okx_request("GET","/api/v5/trade/order",
                              query={"instId":INST_ID,"ordId":oid},private=True)
            return self._send(s if s else 502,o)
        return self._send(404,{"ok":False,"error":"route inconnue"})

    def do_POST(self):
        try: body = self._body()
        except Exception: return self._send(400,{"ok":False,"error":"JSON invalide"})
        if self.path == "/demo/post-only":
            side = str(body.get("side","")).lower().strip()
            px = str(body.get("px","")).strip()
            sz = str(body.get("sz","")).strip()
            if side not in {"buy","sell"}: return self._send(400,{"ok":False,"error":"side buy/sell"})
            if not px or not sz: return self._send(400,{"ok":False,"error":"px et sz requis"})
            payload = {"instId":INST_ID,"tdMode":"cash","side":side,"ordType":"post_only","px":px,"sz":sz}
            s,o = okx_request("POST","/api/v5/trade/order",payload=payload,private=True)
            return self._send(s if s else 502,o)
        if self.path == "/demo/cancel":
            oid = str(body.get("ordId","")).strip()
            if not oid: return self._send(400,{"ok":False,"error":"ordId requis"})
            s,o = okx_request("POST","/api/v5/trade/cancel-order",
                              payload={"instId":INST_ID,"ordId":oid},private=True)
            return self._send(s if s else 502,o)
        return self._send(404,{"ok":False,"error":"route inconnue"})

def main():
    print("="*64)
    print("ERITH · OKX DEMO BRIDGE V2 · PORT 8791")
    print("="*64)
    try:
        server = ThreadingHTTPServer((HOST,PORT),H)
    except OSError as e:
        print(f"[STOP] Port {PORT} indisponible: {e}")
        input("Entrée pour fermer...")
        return 2

    print(f"[OK] Port {PORT} réservé par CE bridge.")
    print("[TEST] Authentification OKX Demo + BTC-EUR...")
    r = self_test()
    print("[AUTH]", "OK" if r["auth"]["ok"] else "ECHEC",
          f"(HTTP {r['auth']['http']} / OKX {r['auth']['code']})")
    print("[BTC-EUR]", "OK" if r["instrument"]["ok"] else "ECHEC",
          f"(count={r['instrument']['count']})")
    if not r["ok"]:
        server.server_close()
        print("[STOP] Aucun ordre envoyé.")
        print(json.dumps(r,ensure_ascii=False,indent=2))
        input("Entrée pour fermer...")
        return 3

    print(f"[READY] http://{HOST}:{PORT}")
    print(f"[READY] service={SERVICE_ID}")
    print("[READY] DEMO uniquement · x-simulated-trading: 1")
    print("Aucun ordre n'est envoyé au démarrage.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
