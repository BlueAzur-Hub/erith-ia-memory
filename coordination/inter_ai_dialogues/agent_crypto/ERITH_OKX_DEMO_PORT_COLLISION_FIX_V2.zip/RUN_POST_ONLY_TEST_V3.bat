@echo off
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY TEST V3
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0POST_ONLY_TEST_V3.py"
) else (
  python "%~dp0POST_ONLY_TEST_V3.py"
)
echo.
pause
