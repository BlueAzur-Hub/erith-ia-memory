CORRECTION PORT COLLISION

Cause du dernier échec :
- 127.0.0.1:8787 est déjà occupé par AETHER CONTROL / ATLAS-10 CRYPTO BRIDGE.
- Le test V2 interrogeait donc l'ancien Bridge et non le Bridge OKX Demo.

Correction :
- OKX Demo Bridge V2 utilise 127.0.0.1:8791.
- Le test V3 exige explicitement service=ERITH_OKX_DEMO_BRIDGE_V2.
- Le backend historique 8790 et le Bridge Atlas 8787 restent inchangés.

À copier dans C:\ERITH\okx-demo-bridge\ :
- okx_demo_bridge_v2.py
- START_OKX_DEMO_BRIDGE_V2.bat
- POST_ONLY_TEST_V3.py
- RUN_POST_ONLY_TEST_V3.bat

Conserver dans ce dossier :
- okx-demo.env

Ordre :
1. Ne rien fermer côté Aether Control.
2. Lancer START_OKX_DEMO_BRIDGE_V2.bat.
3. Vérifier [READY] http://127.0.0.1:8791.
4. Lancer RUN_POST_ONLY_TEST_V3.bat.
