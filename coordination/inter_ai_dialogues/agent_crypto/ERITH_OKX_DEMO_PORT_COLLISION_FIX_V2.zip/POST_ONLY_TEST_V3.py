#!/usr/bin/env python3
from __future__ import annotations
import json, time, urllib.parse, urllib.request, urllib.error
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
from datetime import datetime

BRIDGE="http://127.0.0.1:8791"
OKX="https://eea.okx.com"
INST="BTC-EUR"
SERVICE="ERITH_OKX_DEMO_BRIDGE_V2"
TARGET=Decimal("10")
ROOT=Path(__file__).resolve().parent
LOG=ROOT/"post_only_test_v3.log"
REPORTS=ROOT/"reports"

def log(s=""):
    print(s,flush=True)
    with LOG.open("a",encoding="utf-8") as f: f.write(s+"\n")

def req(method,url,body=None,timeout=20):
    data=None
    headers={"Content-Type":"application/json","User-Agent":"ERITH-POSTONLY-V3"}
    if body is not None: data=json.dumps(body,separators=(",",":")).encode()
    r=urllib.request.Request(url,data=data,headers=headers,method=method)
    try:
        with urllib.request.urlopen(r,timeout=timeout) as x:
            return x.status,json.loads(x.read().decode())
    except urllib.error.HTTPError as e:
        raw=e.read().decode(errors="replace")
        try:o=json.loads(raw)
        except:o={"raw":raw}
        return e.code,o

def D(x): return Decimal(str(x))
def ceilstep(v,s): return (v/s).to_integral_value(rounding=ROUND_CEILING)*s

def main():
    LOG.write_text("",encoding="utf-8")
    log("="*60); log("ERITH · OKX DEMO · POST-ONLY TEST V3"); log("="*60)

    s,h=req("GET",BRIDGE+"/health")
    if s!=200 or not h.get("ok") or h.get("service")!=SERVICE or not h.get("demo"):
        raise RuntimeError(f"Mauvais service sur 8791: HTTP {s} · {h}")
    log(f"[OK] Bon bridge: {h.get('service')} · {h.get('bind')}")

    q=urllib.parse.urlencode({"instId":INST})
    s,t=req("GET",OKX+"/api/v5/market/ticker?"+q)
    if s!=200 or str(t.get("code"))!="0" or not t.get("data"):
        raise RuntimeError(f"Ticker indisponible: {s} {t}")
    q2=urllib.parse.urlencode({"instType":"SPOT","instId":INST})
    s,i=req("GET",OKX+"/api/v5/public/instruments?"+q2)
    if s!=200 or str(i.get("code"))!="0" or not i.get("data"):
        raise RuntimeError(f"Instrument indisponible: {s} {i}")

    t=t["data"][0]; i=i["data"][0]
    bid,ask,tick,lot,minsz=map(D,[t["bidPx"],t["askPx"],i["tickSz"],i["lotSz"],i["minSz"]])
    px=bid-tick
    sz=ceilstep(TARGET/px,lot)
    if sz<minsz: sz=minsz
    pxs,szs=format(px,"f"),format(sz,"f")
    log(f"[MARKET] bid={bid} ask={ask} tick={tick}")
    log(f"[ORDER] DEMO BUY POST_ONLY px={pxs} sz={szs} BTC")

    s,p=req("POST",BRIDGE+"/demo/post-only",{"side":"buy","px":pxs,"sz":szs})
    if s!=200 or str(p.get("code"))!="0" or not p.get("data"):
        raise RuntimeError(f"Ordre refusé: HTTP {s} · {p}")
    row=p["data"][0]
    if str(row.get("sCode","0"))!="0":
        raise RuntimeError(f"OKX sCode={row.get('sCode')} · {row.get('sMsg')}")
    oid=str(row.get("ordId","")).strip()
    if not oid: raise RuntimeError(f"ordId absent: {p}")
    log(f"[PLACED] ordId={oid}")

    snaps=[]; elapsed=0
    for target in (2,10,20):
        time.sleep(target-elapsed); elapsed=target
        q=urllib.parse.urlencode({"ordId":oid})
        s,o=req("GET",BRIDGE+"/demo/order?"+q)
        if s!=200 or str(o.get("code"))!="0" or not o.get("data"):
            raise RuntimeError(f"Lecture ordre T+{target}: {s} {o}")
        d=o["data"][0]
        snap={k:d.get(k) for k in ("state","accFillSz","avgPx","fee","feeCcy","uTime")}
        snap["after_s"]=target; snaps.append(snap)
        log(f"[T+{target}] state={snap['state']} fill={snap['accFillSz']} avgPx={snap['avgPx']} fee={snap['fee']} {snap['feeCcy']}")
        if snap["state"] in ("filled","canceled"): break

    q=urllib.parse.urlencode({"ordId":oid})
    s,o=req("GET",BRIDGE+"/demo/order?"+q)
    d=o["data"][0]
    if d.get("state") in ("live","partially_filled"):
        log(f"[CANCEL] state={d.get('state')}")
        s,c=req("POST",BRIDGE+"/demo/cancel",{"ordId":oid})
        if s!=200 or str(c.get("code"))!="0":
            raise RuntimeError(f"Annulation refusée: {s} {c}")
        time.sleep(2)

    s,f=req("GET",BRIDGE+"/demo/order?"+q)
    d=f["data"][0]
    REPORTS.mkdir(exist_ok=True)
    path=REPORTS/f"okx_demo_post_only_v3_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    report={
        "mode":"OKX_DEMO","instrument":INST,
        "market":{"bid":str(bid),"ask":str(ask),"tickSz":str(tick),"lotSz":str(lot),"minSz":str(minsz)},
        "order":{"side":"buy","ordType":"post_only","px":pxs,"sz":szs,"ordId":oid},
        "snapshots":snaps,
        "final":{k:d.get(k) for k in ("state","accFillSz","avgPx","fee","feeCcy","cTime","uTime")}
    }
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    log(""); log("=============== RESULTAT ===============")
    for k,v in report["final"].items(): log(f"{k}={v}")
    log(f"rapport={path}"); log("========================================")
    return 0

if __name__=="__main__":
    code=1
    try: code=main()
    except Exception as e:
        log(""); log("!!!!!!!! ERREUR !!!!!!!!"); log(f"{type(e).__name__}: {e}"); log(f"log={LOG}")
    finally:
        print(); input("Entrée pour fermer...")
    raise SystemExit(code)
