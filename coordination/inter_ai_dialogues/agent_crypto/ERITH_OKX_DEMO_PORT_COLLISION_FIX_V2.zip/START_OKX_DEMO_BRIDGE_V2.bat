@echo off
cd /d "%~dp0"
title ERITH - OKX DEMO BRIDGE V2 - 8791
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0okx_demo_bridge_v2.py"
) else (
  python "%~dp0okx_demo_bridge_v2.py"
)
echo.
pause
