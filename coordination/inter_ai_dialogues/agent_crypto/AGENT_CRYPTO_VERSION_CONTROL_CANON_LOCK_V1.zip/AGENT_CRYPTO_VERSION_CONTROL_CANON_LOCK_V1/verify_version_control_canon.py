#!/usr/bin/env python3
"""
Agent-Crypto — VERSION CONTROL CANON LOCK V1
Fail-closed verifier.

NORMAL RULE:
- Controller logic is immutable.
- Every published modification uses a strictly newer Build.
- Token is exactly market-core-v2.0-alpha-build-<BUILD>.
- Build/token identity must agree in app.js, index.html, style.css and version.json.
- Same-Build mutation is forbidden.
- If any check fails: REFUSE BUILD.
"""

import argparse, hashlib, json, re, sys, tempfile, zipfile, shutil
from pathlib import Path

CANON_BUILD = "28.3.16"
CANON_TOKEN = "market-core-v2.0-alpha-build-28.3.16"
TOKEN_PREFIX = "market-core-v2.0-alpha-build-"
CONTROLLER_START = 'function atlasVersionParts(value) {'
CONTROLLER_END = 'const ATLAS_NETWORK_PRIORITY'
PREAMBLE_START = "const ATLAS_RELEASE = "
PREAMBLE_END = "const ATLAS_MARKET_DEGRADE_AFTER_FAILURES"
CANON_CONTROLLER_SHA256 = "118a5aa424907eeb8fabac8585badb763e54705862412da6f252550e7e914a88"
CANON_PREAMBLE_NORMALIZED_SHA256 = "c7582f86bbb8306a31bb26367d8982e30cff1d8e8c612eaf6a022b18fb07442b"
CANON_FILES = {
    "README.md": "f28daf27d1dabfb6dd1872644dd7255f5cb2cb4884f12742d429df706e90980f",
    "web/app.js": "10f5028fa9ee7498b7ff85f55aa0032b9d356945581c7aa735fa50d3967ad688",
    "web/index.html": "41ce311e2ffd63695036a57d6542b0b7d1886d27ebf8c2a2b57a49c4096a9322",
    "web/style.css": "aafc35ccc75bacb7fe5d74717103ef1e1084cc0f8df120ee5e6b02cfb3de503e",
    "web/version.json": "1c17ac6ea7f69be03f03c5ca687685396e6fd695e25192fd4935d9a462c2cfd9"
}
FORBIDDEN_TERMS = [
    "sameBuildTokenChanged",
    "sameBuildIdentityConflict",
    "same_build_identity_conflict",
]

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()

def version_parts(v):
    return [int(x) for x in re.findall(r"\d+", str(v))]

def cmp_version(a, b):
    aa, bb = version_parts(a), version_parts(b)
    n = max(len(aa), len(bb))
    aa += [0] * (n - len(aa))
    bb += [0] * (n - len(bb))
    return (aa > bb) - (aa < bb)

def find_root(base):
    candidates = []
    if (base / "web" / "app.js").is_file() and (base / "README.md").is_file():
        candidates.append(base)
    for p in base.rglob("agent_crypto_erith_ia"):
        if (p / "web" / "app.js").is_file() and (p / "README.md").is_file():
            candidates.append(p)
    if not candidates:
        raise RuntimeError("Impossible de localiser public/agent_crypto_erith_ia.")
    return sorted(set(candidates), key=lambda p: len(str(p)))[0]

def read_text(path):
    return Path(path).read_text(encoding="utf-8")

def exactly_one(pattern, text, label, flags=0):
    matches = list(re.finditer(pattern, text, flags))
    if len(matches) != 1:
        raise AssertionError(f"{label}: attendu exactement 1 marqueur, trouvé {len(matches)}")
    return matches[0]

def extract_controller(app):
    a = app.find(CONTROLLER_START)
    b = app.find(CONTROLLER_END, a)
    if a < 0 or b < 0:
        raise AssertionError("Bornes du contrôleur canonique introuvables.")
    return app[a:b]

def normalize_preamble(app):
    a = app.find(PREAMBLE_START)
    b = app.find(PREAMBLE_END, a)
    if a < 0 or b < 0:
        raise AssertionError("Préambule de version introuvable.")
    s = app[a:b]
    s = re.sub(r'const ATLAS_RELEASE = "[^"]*";', 'const ATLAS_RELEASE = "__RELEASE__";', s, count=1)
    s = re.sub(r'const ATLAS_BUILD = "[^"]*";', 'const ATLAS_BUILD = "__BUILD__";', s, count=1)
    s = re.sub(r'const ATLAS_ASSET_TOKEN = "[^"]*";', 'const ATLAS_ASSET_TOKEN = "__TOKEN__";', s, count=1)
    return s

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True, help="ZIP candidat ou dossier agent_crypto_erith_ia")
    ap.add_argument("--mode", choices=["canonical", "candidate"], default="candidate")
    args = ap.parse_args()

    temp = None
    try:
        target = Path(args.target).resolve()
        if target.is_file() and target.suffix.lower() == ".zip":
            temp = Path(tempfile.mkdtemp(prefix="agent_crypto_version_guard_"))
            with zipfile.ZipFile(target) as z:
                if any(".." in Path(n).parts for n in z.namelist()):
                    raise AssertionError("ZIP contient un chemin non sûr.")
                z.extractall(temp)
            root = find_root(temp)
        elif target.is_dir():
            root = find_root(target)
        else:
            raise RuntimeError("Cible inexistante ou non supportée.")

        required = ["README.md", "web/app.js", "web/index.html", "web/style.css", "web/version.json"]
        for rel in required:
            if not (root / rel).is_file():
                raise AssertionError(f"Fichier obligatoire absent: {rel}")

        app = read_text(root / "web/app.js")
        idx = read_text(root / "web/index.html")
        sty = read_text(root / "web/style.css")
        manifest = json.loads(read_text(root / "web/version.json"))

        # 1 — Immutable controller.
        controller = extract_controller(app)
        controller_hash = sha256_bytes(controller.encode("utf-8"))
        if controller_hash != CANON_CONTROLLER_SHA256:
            raise AssertionError(
                f"CONTROLEUR MODIFIE: {controller_hash} != canon {CANON_CONTROLLER_SHA256}"
            )

        for term in FORBIDDEN_TERMS:
            if term in app:
                raise AssertionError(f"Branche post-incident interdite détectée: {term}")

        # 2 — Immutable preamble structure, except identity values.
        preamble_hash = sha256_bytes(normalize_preamble(app).encode("utf-8"))
        if preamble_hash != CANON_PREAMBLE_NORMALIZED_SHA256:
            raise AssertionError("PREAMBULE DE VERSION MODIFIE.")

        # 3 — One app identity.
        m_release = exactly_one(r'^const ATLAS_RELEASE = "([^"]+)";$', app, "ATLAS_RELEASE", re.M)
        m_build = exactly_one(r'^const ATLAS_BUILD = "([^"]+)";$', app, "ATLAS_BUILD", re.M)
        m_token = exactly_one(r'^const ATLAS_ASSET_TOKEN = "([^"]+)";$', app, "ATLAS_ASSET_TOKEN", re.M)
        app_release, app_build, app_token = m_release.group(1), m_build.group(1), m_token.group(1)

        build = str(manifest.get("build", "")).strip()
        token = str(manifest.get("asset_token", "")).strip()
        release = str(manifest.get("release", "")).strip()
        if not build or not token:
            raise AssertionError("version.json: build/asset_token absent.")

        expected_token = TOKEN_PREFIX + build
        if token != expected_token:
            raise AssertionError(f"Token non canonique: {token} != {expected_token}")
        if app_build != build or app_token != token:
            raise AssertionError("app.js et version.json ne portent pas la même identité.")
        if f"Build {build}" not in app_release or (release and f"Build {build}" not in release):
            raise AssertionError("Libellé release incohérent.")

        # 4 — index.html active identity and cache-busters.
        mi_b = exactly_one(r'<meta\s+name="atlas-build"\s+content="([^"]+)"\s*/?>', idx, "index atlas-build", re.I)
        mi_t = exactly_one(r'<meta\s+name="atlas-asset-token"\s+content="([^"]+)"\s*/?>', idx, "index atlas-asset-token", re.I)
        if mi_b.group(1) != build or mi_t.group(1) != token:
            raise AssertionError("index.html: Build/token incohérents.")
        if f"./style.css?v={token}" not in idx or f"./app.js?v={token}" not in idx:
            raise AssertionError("index.html: cache-busters CSS/JS incohérents.")

        # 5 — style.css exactly one active identity.
        ms_b = exactly_one(r'(?m)^\s*ATLAS_ASSET_BUILD:\s*([^\s]+)\s*$', sty, "style active build")
        ms_t = exactly_one(r'(?m)^\s*ATLAS_ASSET_TOKEN:\s*([^\s]+)\s*$', sty, "style active token")
        mv_b = exactly_one(r'--atlas-asset-build:\s*"([^"]+)"\s*;', sty, "style runtime build")
        mv_t = exactly_one(r'--atlas-asset-token:\s*"([^"]+)"\s*;', sty, "style runtime token")
        if any(v != build for v in [ms_b.group(1), mv_b.group(1)]):
            raise AssertionError("style.css: Build actif incohérent.")
        if any(v != token for v in [ms_t.group(1), mv_t.group(1)]):
            raise AssertionError("style.css: token actif incohérent.")

        # 6 — version.json coherence contract cannot be weakened.
        coherence = manifest.get("coherence_contract") or {}
        policy = coherence.get("active_marker_policy") or {}
        mandatory = {
            "required_count_per_build_marker": 1,
            "required_count_per_token_marker": 1,
            "historical_markers_are_non_active": True,
            "remote_publication_rejected_on_duplicate_active_marker": True,
        }
        for key, expected in mandatory.items():
            if policy.get(key) != expected:
                raise AssertionError(f"coherence_contract affaibli: {key}")
        for key, expected_path in {"index": "index.html", "app": "app.js", "style": "style.css"}.items():
            if (coherence.get(key) or {}).get("path") != expected_path:
                raise AssertionError(f"coherence_contract.{key}.path modifié.")

        # 7 — Same-Build mutation is impossible.
        hashes = {rel: sha256_bytes((root / rel).read_bytes()) for rel in required}
        relation = cmp_version(build, CANON_BUILD)
        if relation < 0:
            raise AssertionError(f"Régression interdite: Build {build} < {CANON_BUILD}")

        if relation == 0:
            if token != CANON_TOKEN:
                raise AssertionError("Même Build canonique avec token différent: interdit.")
            for rel, canonical_hash in CANON_FILES.items():
                if hashes[rel] != canonical_hash:
                    raise AssertionError(
                        f"MUTATION SOUS BUILD {CANON_BUILD} INTERDITE: {rel} diffère."
                    )
            if args.mode == "candidate":
                raise AssertionError(
                    f"Candidate future réutilise Build {CANON_BUILD}: nouveau Build obligatoire."
                )
        elif args.mode == "canonical":
            raise AssertionError(f"Mode canonical attend Build {CANON_BUILD}, trouvé {build}.")

        print("PASS — VERSION CONTROL CANON LOCK")
        print(f"Build: {build}")
        print(f"Token: {token}")
        print(f"Controller SHA-256: {controller_hash}")
        print("Controller: IMMUTABLE")
        print("Same-Build mutation: BLOCKED")
        print("Identity coherence: PASS")
        return 0

    except Exception as exc:
        print("REFUSE BUILD — VERSION CONTROL CANON VIOLATION", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return 2
    finally:
        if temp:
            shutil.rmtree(temp, ignore_errors=True)

if __name__ == "__main__":
    raise SystemExit(main())
