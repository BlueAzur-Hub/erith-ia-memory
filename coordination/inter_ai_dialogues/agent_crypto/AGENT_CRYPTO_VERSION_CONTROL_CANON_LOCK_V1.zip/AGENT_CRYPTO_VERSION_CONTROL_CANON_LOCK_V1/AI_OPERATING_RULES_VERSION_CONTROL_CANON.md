# AGENT-CRYPTO — VERSION CONTROL CANON LOCK V1

## STATUT

**CANONICAL PROTECTED CORE**

Référence fonctionnelle : **Build 28.3.16**, cycle réel Firefox validé :
détection → clic → rechargement → `Mise à jour installée · Build 28.3.16` → état courant.

Le runtime 28.3.16 n'est pas modifié par ce pack.

---

## RÈGLE ABSOLUE

Le sous-système de versionnage n'est plus une zone de travail ordinaire.

Pour toute future Build dont la mission n'est pas explicitement :
`VERSION CONTROL SURGERY`

**IL EST INTERDIT DE MODIFIER LE CONTRÔLEUR DE VERSION.**

Bloc canonique :
- début : `function atlasVersionParts(value) {`
- fin exclusive : `const ATLAS_NETWORK_PRIORITY`
- SHA-256 : `118a5aa424907eeb8fabac8585badb763e54705862412da6f252550e7e914a88`

Si le SHA change :
**REFUSE BUILD.**

---

## SEULES VALEURS MUTABLES POUR UNE BUILD NORMALE

Une nouvelle Build peut uniquement faire évoluer l'identité de publication :
- `ATLAS_RELEASE`
- `ATLAS_BUILD`
- `ATLAS_ASSET_TOKEN`
- meta Build/token dans `index.html`
- marqueurs actifs Build/token dans `style.css`
- Build/token/published_at et métadonnées de mission dans `version.json`
- libellés documentaires associés à la nouvelle Build

Le contrôleur lui-même reste byte-identique.

---

## CONTRAT DE PUBLICATION

1. Toute modification publiée = **nouveau numéro de Build**.
2. Toute nouvelle Build = **nouveau token**.
3. Token canonique :
   `market-core-v2.0-alpha-build-<BUILD>`
4. `app.js`, `index.html`, `style.css`, `version.json` doivent porter exactement la même identité.
5. `README.md` + les quatre fichiers `web/` sont publiés ensemble.
6. Jamais de contenu différent sous un numéro déjà publié.
7. Jamais de hotfix caché à Build égal.
8. Les marqueurs historiques CSS restent non actifs.
9. Une seule identité active par fichier.
10. Le test automatisé ne remplace jamais la validation Firefox réelle.

---

## BUILD 28.3.16 GELÉE

Tout contenu publié de nouveau sous `28.3.16` doit être **octet pour octet** identique au canon.

Toute différence sous `28.3.16` :
**REFUSE BUILD.**

---

## GARDE-FOU OBLIGATOIRE AVANT TOUT ZIP FUTUR

Exécuter :

`python verify_version_control_canon.py --target <ZIP_CANDIDAT> --mode candidate`

Résultat accepté :

`PASS — VERSION CONTROL CANON LOCK`

Tout autre résultat :
**aucun ZIP livré, aucun upload demandé, aucun commit proposé.**

---

## SI UNE IA VEUT « AMÉLIORER » LE VERSIONNAGE

Réponse obligatoire :

**NON. CORE PROTÉGÉ.**

Aucune optimisation, refactorisation, simplification, renommage, architecture de releases,
nouvelle sémantique same-build, nouvelle couche de recovery ou nouvelle politique de token
n'est autorisée sans demande explicite de Christophe ouvrant une chirurgie dédiée.

---

## FORMULE COURTE

**VERSIONNAGE FONCTIONNEL = ON NE TOUCHE PLUS.**

Feature Build :
identité nouvelle → contrôleur inchangé → vérification fail-closed → ZIP → Firefox réel.

