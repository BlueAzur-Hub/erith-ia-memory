function atlasVersionParts(value) {
  const parts = String(value || "").match(/\d+/g);
  return Array.isArray(parts) ? parts.map(Number) : [];
}

function atlasCompareBuildNumbers(left, right) {
  const a = atlasVersionParts(left);
  const b = atlasVersionParts(right);
  const length = Math.max(a.length, b.length);

  for (let index = 0; index < length; index += 1) {
    const difference =
      Number(a[index] || 0) - Number(b[index] || 0);
    if (difference !== 0) return difference > 0 ? 1 : -1;
  }

  return 0;
}

function atlasVersionRequestUrl(path, stamp = Date.now()) {
  const url = new URL(
    path,
    document.baseURI || window.location.href
  );
  url.searchParams.set("_version_check", String(stamp));
  return url.toString();
}

function atlasVersionManifestRequestUrl(stamp = Date.now()) {
  return atlasVersionRequestUrl(
    ATLAS_VERSION_MANIFEST_URL,
    stamp
  );
}

function atlasVersionControlElements() {
  return {
    control: document.getElementById("atlasVersionControl"),
    text: document.getElementById("atlasVersionControlText")
  };
}

function atlasVersionCheckedAtLabel(timestamp = 0) {
  const value = Number(timestamp || 0);
  if (!Number.isFinite(value) || value <= 0) {
    return "Dernière vérification de version : en attente";
  }

  try {
    const formatted = new Intl.DateTimeFormat("fr-FR", {
      dateStyle: "short",
      timeStyle: "medium"
    }).format(new Date(value));

    return `Dernière vérification de version : ${formatted}`;
  } catch {
    return "Dernière vérification de version : effectuée";
  }
}

function atlasVersionControlTooltip(
  mode,
  build,
  checkedAt = 0
) {
  const freshness = atlasVersionCheckedAtLabel(checkedAt);

  if (mode === "checking") {
    return `Vérification forcée de la publication · ${freshness}`;
  }

  if (mode === "available") {
    return (
      `Nouvelle version cohérente disponible · Build ${build}`
      + ` · ${freshness}`
    );
  }

  if (mode === "publishing") {
    return (
      `Publication du Build ${build} encore incomplète`
      + ` · Cliquer pour revérifier · ${freshness}`
    );
  }

  if (mode === "repair") {
    return (
      `Fichiers chargés incohérents · Build ${build}`
      + ` · Cliquer pour recharger la publication cohérente`
    );
  }

  if (mode === "applying") {
    return (
      `Mise à jour vers le Build ${build} en cours`
      + ` · ${freshness}`
    );
  }

  if (mode === "failed") {
    return (
      `Vérification ou actualisation impossible`
      + ` · Cliquer pour réessayer · ${freshness}`
    );
  }

  if (mode === "installed") {
    return (
      `Mise à jour installée · Build ${build}`
      + ` · Cliquer pour vérifier de nouveau`
    );
  }

  return (
    `Version installée · Build ${ATLAS_BUILD}`
    + ` · Cliquer pour vérifier · ${freshness}`
  );
}

function atlasVersionControlState(mode, options = {}) {
  const { control, text } = atlasVersionControlElements();
  if (!control || !text) return false;

  const stateMode = [
    "current",
    "checking",
    "available",
    "publishing",
    "repair",
    "applying",
    "failed",
    "installed"
  ].includes(mode)
    ? mode
    : "current";

  const build =
    String(options.build || ATLAS_BUILD).trim()
    || ATLAS_BUILD;
  const token = String(options.token || "").trim();
  const checkedAt = Number(
    options.checkedAt
    ?? atlasVersionAwarenessState.lastCheckedAt
    ?? 0
  );

  control.classList.remove("ok", "warn", "fail");
  control.dataset.state = stateMode;
  control.removeAttribute("data-remote-build");
  control.removeAttribute("data-remote-token");
  control.removeAttribute("aria-busy");

  if ([
    "available",
    "publishing",
    "repair",
    "failed",
    "applying"
  ].includes(stateMode)) {
    control.dataset.remoteBuild = build;
    if (token) control.dataset.remoteToken = token;
  }

  control.disabled = stateMode === "applying";

  if (stateMode === "checking") {
    control.classList.add("ok");
    text.textContent = "Vérification de version…";
    control.setAttribute(
      "aria-label",
      "Vérification forcée de la publication en cours"
    );
  } else if (stateMode === "available") {
    control.classList.add("warn");
    text.textContent =
      `Nouvelle version disponible · Build ${build}`;
    control.setAttribute(
      "aria-label",
      (
        `Nouvelle version cohérente disponible, Build ${build}.`
        + " Cliquer pour installer."
      )
    );
  } else if (stateMode === "publishing") {
    control.classList.add("warn");
    text.textContent =
      `Publication Build ${build} incomplète · Revérifier`;
    control.setAttribute(
      "aria-label",
      (
        `Publication du Build ${build} encore incomplète.`
        + " Cliquer pour revérifier."
      )
    );
  } else if (stateMode === "repair") {
    control.classList.add("warn");
    text.textContent =
      `Fichiers incohérents · Recharger le Build ${build}`;
    control.setAttribute(
      "aria-label",
      (
        `Les fichiers chargés ne portent pas tous le Build ${build}.`
        + " Cliquer pour recharger."
      )
    );
  } else if (stateMode === "applying") {
    control.classList.add("warn");
    control.setAttribute("aria-busy", "true");
    text.textContent = "Mise à jour en cours…";
    control.setAttribute(
      "aria-label",
      `Mise à jour vers le Build ${build} en cours`
    );
  } else if (stateMode === "failed") {
    control.classList.add("fail");
    text.textContent = "Vérification impossible · Réessayer";
    control.setAttribute(
      "aria-label",
      "Vérification ou actualisation impossible. Cliquer pour réessayer."
    );
  } else if (stateMode === "installed") {
    control.classList.add("ok");
    text.textContent =
      `Mise à jour installée · Build ${build}`;
    control.setAttribute(
      "aria-label",
      (
        `Mise à jour installée, Build ${build}.`
        + " Cliquer pour vérifier de nouveau."
      )
    );
  } else {
    control.classList.add("ok");
    text.textContent = ATLAS_RELEASE;
    control.setAttribute(
      "aria-label",
      (
        `Version installée : Market Core V2.0-Alpha,`
        + ` Build ${ATLAS_BUILD}. Cliquer pour vérifier.`
      )
    );
  }

  control.title = atlasVersionControlTooltip(
    stateMode,
    build,
    checkedAt
  );
  return true;
}

function atlasVersionConfirmationClear() {
  window.clearTimeout(
    atlasVersionAwarenessState.confirmationTimer
  );
  atlasVersionAwarenessState.confirmationTimer = 0;
}

function atlasVersionShowInstalled(
  build = ATLAS_BUILD,
  duration = ATLAS_VERSION_CONFIRMATION_MS
) {
  atlasVersionConfirmationClear();

  const installedBuild =
    String(build || ATLAS_BUILD).trim()
    || ATLAS_BUILD;

  atlasVersionControlState("installed", {
    build: installedBuild
  });

  atlasVersionAwarenessState.confirmationTimer =
    window.setTimeout(() => {
      atlasVersionAwarenessState.confirmationTimer = 0;
      atlasVersionControlState("current");
    }, Math.max(0, Number(duration) || 0));

  return true;
}

function atlasVersionHideUpdate() {
  atlasVersionConfirmationClear();
  atlasVersionAwarenessState.applying = false;
  atlasVersionAwarenessState.remoteBuild = null;
  atlasVersionAwarenessState.remoteToken = null;
  atlasVersionAwarenessState.remotePublication = null;
  return atlasVersionControlState("current");
}

function atlasVersionShowUpdate(
  remoteBuild,
  remoteToken = "",
  publication = null
) {
  const build = String(remoteBuild || "").trim();
  const token = String(remoteToken || "").trim();
  if (!build) return false;

  atlasVersionConfirmationClear();
  atlasVersionAwarenessState.applying = false;
  atlasVersionAwarenessState.remoteBuild = build;
  atlasVersionAwarenessState.remoteToken = token || null;
  atlasVersionAwarenessState.remotePublication = publication;

  return atlasVersionControlState("available", {
    build,
    token
  });
}

function atlasVersionShowPublishing(
  remoteBuild,
  remoteToken = "",
  publication = null
) {
  const build =
    String(remoteBuild || ATLAS_BUILD).trim()
    || ATLAS_BUILD;
  const token = String(remoteToken || "").trim();

  atlasVersionConfirmationClear();
  atlasVersionAwarenessState.applying = false;
  atlasVersionAwarenessState.remoteBuild = build;
  atlasVersionAwarenessState.remoteToken = token || null;
  atlasVersionAwarenessState.remotePublication = publication;

  return atlasVersionControlState("publishing", {
    build,
    token
  });
}

function atlasVersionShowRepair(
  build = ATLAS_BUILD,
  token = ATLAS_ASSET_TOKEN
) {
  const targetBuild =
    String(build || ATLAS_BUILD).trim()
    || ATLAS_BUILD;
  const targetToken = String(token || "").trim();

  atlasVersionConfirmationClear();
  atlasVersionAwarenessState.applying = false;
  atlasVersionAwarenessState.remoteBuild = targetBuild;
  atlasVersionAwarenessState.remoteToken =
    targetToken || null;

  return atlasVersionControlState("repair", {
    build: targetBuild,
    token: targetToken
  });
}

function atlasVersionShowFailure(
  remoteBuild = ATLAS_BUILD,
  remoteToken = ""
) {
  const build =
    String(remoteBuild || ATLAS_BUILD).trim()
    || ATLAS_BUILD;
  const token = String(remoteToken || "").trim();

  atlasVersionConfirmationClear();
  atlasVersionAwarenessState.applying = false;
  atlasVersionAwarenessState.remoteBuild = build;
  atlasVersionAwarenessState.remoteToken = token || null;

  return atlasVersionControlState("failed", {
    build,
    token
  });
}

function atlasVersionManifestBuild(manifest) {
  return String(
    manifest?.build
    || manifest?.version
    || manifest?.release_build
    || ""
  ).trim();
}

function atlasVersionManifestToken(manifest) {
  return String(
    manifest?.asset_token
    || manifest?.assetToken
    || manifest?.token
    || ""
  ).trim();
}

async function atlasFetchVersionText(path, stamp = Date.now()) {
  const response = await fetch(
    atlasVersionRequestUrl(path, stamp),
    {
      cache: "no-store",
      credentials: "same-origin",
      headers: {
        accept: "text/plain, text/html, text/css, application/javascript"
      }
    }
  );

  if (!response.ok) {
    throw new Error(
      `Publication ${path} HTTP ${response.status}`
    );
  }

  return response.text();
}

async function atlasFetchVersionManifest(stamp = Date.now()) {
  const response = await fetch(
    atlasVersionManifestRequestUrl(stamp),
    {
      cache: "no-store",
      credentials: "same-origin",
      headers: {
        accept: "application/json"
      }
    }
  );

  if (!response.ok) {
    throw new Error(
      `Version manifest HTTP ${response.status}`
    );
  }

  const manifest = await response.json();
  const build = atlasVersionManifestBuild(manifest);
  const token = atlasVersionManifestToken(manifest);

  if (!build || !atlasVersionParts(build).length) {
    throw new Error("Version manifest invalide");
  }

  if (!token) {
    throw new Error("Token de publication absent");
  }

  return {
    manifest,
    build,
    token
  };
}

function atlasVersionMetaValue(name) {
  return String(
    document
      .querySelector(`meta[name="${name}"]`)
      ?.getAttribute("content")
    || ""
  ).trim();
}

function atlasVersionCssIdentityValue(name) {
  try {
    return String(
      getComputedStyle(document.documentElement)
        .getPropertyValue(name)
      || ""
    )
      .trim()
      .replace(/^["']|["']$/g, "");
  } catch {
    return "";
  }
}

function atlasVersionRuntimeIdentity() {
  const identity = {
    indexBuild: atlasVersionMetaValue("atlas-build"),
    indexToken: atlasVersionMetaValue(
      "atlas-asset-token"
    ),
    appBuild: ATLAS_BUILD,
    appToken: ATLAS_ASSET_TOKEN,
    styleBuild: atlasVersionCssIdentityValue(
      "--atlas-asset-build"
    ),
    styleToken: atlasVersionCssIdentityValue(
      "--atlas-asset-token"
    )
  };

  const builds = [
    identity.indexBuild,
    identity.appBuild,
    identity.styleBuild
  ];
  const tokens = [
    identity.indexToken,
    identity.appToken,
    identity.styleToken
  ];

  identity.ok =
    builds.every(value => value === ATLAS_BUILD)
    && tokens.every(value => value === ATLAS_ASSET_TOKEN);

  return identity;
}

function atlasVersionIdentityMarker(source, expression) {
  const input = String(source || "");
  const flags = expression.flags.includes("g")
    ? expression.flags
    : `${expression.flags}g`;
  const matcher = new RegExp(expression.source, flags);
  const values = Array.from(
    input.matchAll(matcher),
    match => String(match?.[1] || "").trim()
  ).filter(Boolean);

  return {
    value: values.length === 1 ? values[0] : "",
    count: values.length,
    values
  };
}

function atlasVersionExtractIdentity(kind, text) {
  const source = String(text || "");

  if (kind === "index") {
    const buildMarker = atlasVersionIdentityMarker(
      source,
      /<meta\s+name=["']atlas-build["']\s+content=["']([^"']+)["']/i
    );
    const tokenMarker = atlasVersionIdentityMarker(
      source,
      /<meta\s+name=["']atlas-asset-token["']\s+content=["']([^"']+)["']/i
    );

    return {
      build: buildMarker.value,
      token: tokenMarker.value,
      buildMarkerCount: buildMarker.count,
      tokenMarkerCount: tokenMarker.count,
      referencesApp:
        /<script[^>]+src=["']\.\/app\.js(?:\?[^"']*)?["']/i
          .test(source),
      referencesStyle:
        /<link[^>]+href=["']\.\/style\.css(?:\?[^"']*)?["']/i
          .test(source)
    };
  }

  if (kind === "app") {
    const buildMarker = atlasVersionIdentityMarker(
      source,
      /const\s+ATLAS_BUILD\s*=\s*["']([^"']+)["']/
    );
    const tokenMarker = atlasVersionIdentityMarker(
      source,
      /const\s+ATLAS_ASSET_TOKEN\s*=\s*["']([^"']+)["']/
    );

    return {
      build: buildMarker.value,
      token: tokenMarker.value,
      buildMarkerCount: buildMarker.count,
      tokenMarkerCount: tokenMarker.count
    };
  }

  const buildMarker = atlasVersionIdentityMarker(
    source,
    /ATLAS_ASSET_BUILD:\s*([0-9A-Za-z._-]+)/
  );
  const tokenMarker = atlasVersionIdentityMarker(
    source,
    /ATLAS_ASSET_TOKEN:\s*([a-z0-9._-]+)/
  );

  return {
    build: buildMarker.value,
    token: tokenMarker.value,
    buildMarkerCount: buildMarker.count,
    tokenMarkerCount: tokenMarker.count
  };
}

async function atlasVerifyRemotePublication(remote) {
  const stamp = Date.now();
  const [indexText, appText, styleText] =
    await Promise.all([
      atlasFetchVersionText(
        ATLAS_VERSION_ASSET_URLS.index,
        stamp
      ),
      atlasFetchVersionText(
        ATLAS_VERSION_ASSET_URLS.app,
        stamp
      ),
      atlasFetchVersionText(
        ATLAS_VERSION_ASSET_URLS.style,
        stamp
      )
    ]);

  const identities = {
    index: atlasVersionExtractIdentity(
      "index",
      indexText
    ),
    app: atlasVersionExtractIdentity(
      "app",
      appText
    ),
    style: atlasVersionExtractIdentity(
      "style",
      styleText
    )
  };

  const expectedBuild = String(remote?.build || "");
  const expectedToken = String(remote?.token || "");

  const buildOk = Object.values(identities).every(
    identity => identity.build === expectedBuild
  );
  const tokenOk = Object.values(identities).every(
    identity => identity.token === expectedToken
  );
  const markerCountsOk = Object.values(identities).every(
    identity =>
      identity.buildMarkerCount === 1
      && identity.tokenMarkerCount === 1
  );
  const referencesOk =
    identities.index.referencesApp === true
    && identities.index.referencesStyle === true;

  return {
    ok: buildOk && tokenOk && markerCountsOk && referencesOk,
    build: expectedBuild,
    token: expectedToken,
    identities,
    buildOk,
    tokenOk,
    markerCountsOk,
    referencesOk,
    checkedAt: Date.now()
  };
}

function atlasVersionExpectedUpdateRead() {
  try {
    return {
      build: String(
        sessionStorage.getItem(
          "agent_crypto_expected_build"
        )
        || ""
      ).trim(),
      token: String(
        sessionStorage.getItem(
          "agent_crypto_expected_token"
        )
        || ""
      ).trim()
    };
  } catch {
    return {
      build: "",
      token: ""
    };
  }
}

function atlasVersionExpectedUpdateWrite(build, token = "") {
  try {
    sessionStorage.setItem(
      "agent_crypto_expected_build",
      String(build || "")
    );
    sessionStorage.setItem(
      "agent_crypto_expected_token",
      String(token || "")
    );
    sessionStorage.setItem(
      "agent_crypto_update_started_at",
      new Date().toISOString()
    );
    return true;
  } catch {
    return false;
  }
}

function atlasVersionExpectedUpdateClear() {
  try {
    sessionStorage.removeItem(
      "agent_crypto_expected_build"
    );
    sessionStorage.removeItem(
      "agent_crypto_expected_token"
    );
    sessionStorage.removeItem(
      "agent_crypto_update_started_at"
    );
  } catch {}
}

async function atlasVersionCheck(options = {}) {
  const force = options?.force === true;
  const userInitiated =
    options?.userInitiated === true;

  if (atlasVersionAwarenessState.checking) {
    return false;
  }
  if (
    !force
    && atlasVersionAwarenessState.confirmationTimer
  ) {
    return false;
  }
  if (
    !force
    && document.visibilityState === "hidden"
  ) {
    return false;
  }
  if (!force && navigator.onLine === false) {
    return false;
  }

  atlasVersionAwarenessState.checking = true;
  atlasVersionAwarenessState.lastError = null;

  if (force || userInitiated) {
    atlasVersionControlState("checking");
  }

  try {
    const stamp = Date.now();
    const remote = await atlasFetchVersionManifest(stamp);
    const comparison = atlasCompareBuildNumbers(
      remote.build,
      ATLAS_BUILD
    );

    atlasVersionAwarenessState.remoteBuild = remote.build;
    atlasVersionAwarenessState.remoteToken =
      remote.token || null;
    atlasVersionAwarenessState.lastCheckedAt =
      Date.now();

    if (comparison > 0) {
      const publication =
        await atlasVerifyRemotePublication(remote);

      if (!publication.ok) {
        atlasVersionShowPublishing(
          remote.build,
          remote.token,
          publication
        );
        return false;
      }

      atlasVersionShowUpdate(
        remote.build,
        remote.token,
        publication
      );
      return true;
    }

    if (comparison < 0) {
      atlasVersionShowPublishing(
        ATLAS_BUILD,
        ATLAS_ASSET_TOKEN,
        {
          ok: false,
          reason: "manifest_behind_loaded_app",
          remote
        }
      );
      return false;
    }

    if (force || userInitiated) {
      const publication =
        await atlasVerifyRemotePublication(remote);

      if (!publication.ok) {
        atlasVersionShowPublishing(
          remote.build,
          remote.token,
          publication
        );
        return false;
      }
    }

    const runtime = atlasVersionRuntimeIdentity();
    if (!runtime.ok) {
      atlasVersionShowRepair(
        remote.build,
        remote.token
      );
      return false;
    }

    atlasVersionHideUpdate();
    return false;
  } catch (error) {
    atlasVersionAwarenessState.lastError = String(
      error?.message || error
    );

    const expected = atlasVersionExpectedUpdateRead();
    atlasVersionShowFailure(
      expected.build
      || atlasVersionAwarenessState.remoteBuild
      || ATLAS_BUILD,
      expected.token
      || atlasVersionAwarenessState.remoteToken
      || ATLAS_ASSET_TOKEN
    );

    console.warn(
      "Vérification de version différée :",
      error
    );
    return false;
  } finally {
    atlasVersionAwarenessState.checking = false;
  }
}

function atlasBuildVersionRefreshUrl(
  remoteBuild =
    atlasVersionAwarenessState.remoteBuild
    || ATLAS_BUILD,
  remoteToken =
    atlasVersionAwarenessState.remoteToken
    || ATLAS_ASSET_TOKEN,
  currentHref =
    document.baseURI || window.location.href,
  stamp = Date.now()
) {
  const url = new URL(currentHref);
  url.searchParams.set(
    "build",
    String(remoteBuild || ATLAS_BUILD)
  );
  url.searchParams.set(
    "asset_token",
    String(remoteToken || ATLAS_ASSET_TOKEN)
  );
  url.searchParams.set("_refresh", String(stamp));
  url.hash = "";
  return url.toString();
}

async function atlasClearSameOriginCacheStorage() {
  if (
    !("caches" in window)
    || typeof window.caches?.keys !== "function"
  ) {
    return 0;
  }

  try {
    const names = await window.caches.keys();
    const results = await Promise.all(
      names.map(name => window.caches.delete(name))
    );
    return results.filter(Boolean).length;
  } catch {
    return 0;
  }
}

function atlasVersionNavigateToUpdate(target) {
  window.location.replace(target);
  return true;
}

async function atlasApplyVersionUpdate(options = {}) {
  if (atlasVersionAwarenessState.applying) {
    return false;
  }

  atlasVersionConfirmationClear();

  const { control } = atlasVersionControlElements();
  const requestedBuild = String(
    options.build
    || control?.dataset?.remoteBuild
    || atlasVersionAwarenessState.remoteBuild
    || ATLAS_BUILD
  ).trim();
  const requestedToken = String(
    options.token
    || control?.dataset?.remoteToken
    || atlasVersionAwarenessState.remoteToken
    || ATLAS_ASSET_TOKEN
  ).trim();

  atlasVersionAwarenessState.applying = true;
  atlasVersionControlState("applying", {
    build: requestedBuild,
    token: requestedToken
  });

  try {
    const remote = await atlasFetchVersionManifest();
    const publication =
      await atlasVerifyRemotePublication(remote);

    if (!publication.ok) {
      atlasVersionShowPublishing(
        remote.build,
        remote.token,
        publication
      );
      return false;
    }

    const comparison = atlasCompareBuildNumbers(
      remote.build,
      ATLAS_BUILD
    );
    const repairCurrent =
      comparison === 0
      && (
        options.allowSameBuild === true
        || control?.dataset?.state === "repair"
      );

    if (comparison < 0) {
      atlasVersionShowPublishing(
        ATLAS_BUILD,
        ATLAS_ASSET_TOKEN,
        {
          ok: false,
          reason: "manifest_behind_loaded_app",
          remote
        }
      );
      return false;
    }

    if (comparison === 0 && !repairCurrent) {
      const runtime = atlasVersionRuntimeIdentity();
      if (!runtime.ok) {
        atlasVersionShowRepair(
          remote.build,
          remote.token
        );
      } else {
        atlasVersionExpectedUpdateClear();
        atlasVersionHideUpdate();
        atlasVersionRefreshUrlCleanup();
      }
      return false;
    }

    atlasVersionAwarenessState.remoteBuild =
      remote.build;
    atlasVersionAwarenessState.remoteToken =
      remote.token || null;
    atlasVersionAwarenessState.remotePublication =
      publication;

    atlasVersionExpectedUpdateWrite(
      remote.build,
      remote.token
    );
    await atlasClearSameOriginCacheStorage();

    const target = atlasBuildVersionRefreshUrl(
      remote.build,
      remote.token
    );

    return atlasVersionNavigateToUpdate(target);
  } catch (error) {
    atlasVersionAwarenessState.lastError = String(
      error?.message || error
    );

    atlasVersionShowFailure(
      requestedBuild,
      requestedToken
    );

    console.warn(
      "Actualisation de version impossible :",
      error
    );
    return false;
  } finally {
    atlasVersionAwarenessState.applying = false;
  }
}

async function atlasVersionControlAction() {
  const { control } = atlasVersionControlElements();
  const mode = String(
    control?.dataset?.state || "current"
  );

  if (mode === "applying") return false;

  if (mode === "available") {
    return atlasApplyVersionUpdate();
  }

  if (mode === "repair") {
    return atlasApplyVersionUpdate({
      allowSameBuild: true
    });
  }

  return atlasVersionCheck({
    force: true,
    userInitiated: true
  });
}

function atlasVersionRefreshUrlCleanup() {
  const url = new URL(window.location.href);
  const managed = [
    "_refresh",
    "build",
    "asset_token"
  ];
  const hadManagedParameter = managed.some(
    name => url.searchParams.has(name)
  );

  if (!hadManagedParameter) return false;

  managed.forEach(
    name => url.searchParams.delete(name)
  );
  window.history.replaceState(
    {},
    "",
    `${url.pathname}${url.search}${url.hash}`
  );
  return true;
}

function atlasVersionResolveExpectedUpdate() {
  const expected = atlasVersionExpectedUpdateRead();
  const runtime = atlasVersionRuntimeIdentity();

  if (!expected.build) {
    atlasVersionRefreshUrlCleanup();

    if (!runtime.ok) {
      atlasVersionShowRepair(
        ATLAS_BUILD,
        ATLAS_ASSET_TOKEN
      );
      return "repair";
    }

    atlasVersionControlState("current");
    return "none";
  }

  const buildReached =
    atlasCompareBuildNumbers(
      ATLAS_BUILD,
      expected.build
    ) >= 0;
  const tokenReached =
    !expected.token
    || ATLAS_ASSET_TOKEN === expected.token;

  if (buildReached && tokenReached && runtime.ok) {
    atlasVersionExpectedUpdateClear();
    atlasVersionRefreshUrlCleanup();
    atlasVersionShowInstalled(ATLAS_BUILD);
    return "confirmed";
  }

  atlasVersionRefreshUrlCleanup();

  if (buildReached) {
    atlasVersionShowRepair(
      expected.build || ATLAS_BUILD,
      expected.token || ATLAS_ASSET_TOKEN
    );
    return "repair";
  }

  atlasVersionShowFailure(
    expected.build,
    expected.token
  );
  return "incomplete";
}

function atlasVersionAwarenessSchedule(delay = 2500) {
  window.clearTimeout(
    atlasVersionAwarenessState.timer
  );
  atlasVersionAwarenessState.timer =
    window.setTimeout(
      () => void atlasVersionCheck(),
      Math.max(0, Number(delay) || 0)
    );
}

function atlasVersionAwarenessInit() {
  if (atlasVersionAwarenessState.initialized) {
    return true;
  }
  atlasVersionAwarenessState.initialized = true;

  const control =
    document.getElementById("atlasVersionControl");

  if (control) {
    control.disabled = false;
    control.addEventListener(
      "click",
      () => void atlasVersionControlAction()
    );
  }

  const expectedStatus =
    atlasVersionResolveExpectedUpdate();

  window.addEventListener(
    "online",
    () => atlasVersionAwarenessSchedule(800)
  );

  document.addEventListener(
    "visibilitychange",
    () => {
      if (document.visibilityState === "visible") {
        atlasVersionAwarenessSchedule(700);
      }
    }
  );

  window.setInterval(
    () => void atlasVersionCheck(),
    ATLAS_VERSION_CHECK_INTERVAL_MS
  );

  atlasVersionAwarenessSchedule(
    expectedStatus === "confirmed"
      ? ATLAS_VERSION_CONFIRMATION_MS + 800
      : expectedStatus === "incomplete"
        || expectedStatus === "repair"
        ? 900
        : 2800
  );

  return true;
}

