$ErrorActionPreference = "Stop"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

$Out = "YOHAN_OPERATOR_BRIDGE_CONTROL_CENTER_2_3_2R19Y1_BRIDGE_V1_9_13_BACKEND_V1_4_4_OKX_LOCAL_TRANSPORT_GUI_NO_CONSOLE.exe"
go build -trimpath -ldflags "-H windowsgui -s -w" -o $Out main.go
Write-Host "Compilation terminee : Yohan Operator Control Center V2.3.2R19Y1 / Bridge V1.9.13 / Backend V1.4.4 OKX LOCAL TRANSPORT / double supervision locale 8787+8790 / Windows GUI / aucune console hote."
