@echo off
setlocal
cd /d "%~dp0"
echo.
echo === YOHAN OPERATOR - COMPTE LOCAL BRIDGE ===
echo Le mot de passe reste uniquement sur ce PC sous forme de verifier scrypt.
echo.
where py >nul 2>nul && (py -3 create_operator_account.py & goto :done)
where python >nul 2>nul && (python create_operator_account.py & goto :done)
echo Python 3 introuvable.
:done
pause
endlocal
