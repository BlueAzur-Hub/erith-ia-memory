# Yohan Operator — Bridge Control Center R19Y1

Base exacte : Aether Control 2.3.2R19 · Bridge 1.9.13 · Backend 1.4.4 OKX Local Transport.

Objectif immédiat : **faire fonctionner les données publiques OKX sur le poste Yohan**, même avant la configuration Ollama.

- Control Center Windows GUI, sans console hôte ;
- Bridge : 127.0.0.1:8787 ;
- Backend : 127.0.0.1:8790 ;
- l’EXE démarre automatiquement Bridge + Backend ;
- si Ollama/modèle manque, le Bridge reste actif mais « modèle non prêt » ;
- le Backend 1.4.4 reste indépendant et peut déjà alimenter Bougies / Carnet / Profondeur OKX ;
- rôle d’authentification local forcé à `operator` ;
- publication GitHub / Book Mirror / Oracle Evidence désactivée pour Yohan ;
- aucun wallet, ordre, retrait ou API privée exchange.

## Ordre de test
1. Lancer l’EXE Yohan.
2. Attendre `PRIVATE BACKEND · actif · prêt · V1.4.4`.
3. Cliquer `Ouvrir Operator Yohan`.
4. Ctrl+F5 dans Firefox.
5. Tester Graphique → Bougies puis Profondeur / Carnet.
6. Ollama peut rester non prêt pour ce premier test OKX.
7. Plus tard : `CONFIGURE_YOHAN_OLLAMA.bat`, puis redémarrer Bridge.

Le Backend 1.4.4 est conservé **bit pour bit** depuis le pack R19 fourni par Christophe.
