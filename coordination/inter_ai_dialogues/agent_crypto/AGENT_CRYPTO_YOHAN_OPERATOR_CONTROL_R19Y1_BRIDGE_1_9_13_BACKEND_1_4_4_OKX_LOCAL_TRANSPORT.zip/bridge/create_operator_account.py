#!/usr/bin/env python3
from __future__ import annotations
import getpass, json, urllib.request, urllib.error
URL='http://127.0.0.1:8787/auth/register'
ORIGIN='https://blueazur-hub.github.io'
print('Creation du compte local Yohan Operator Bridge.')
secret=getpass.getpass('Nouveau mot de passe Operator (6+ caracteres): ')
if len(secret)<6: raise SystemExit('Mot de passe trop court.')
req=urllib.request.Request(URL,data=json.dumps({'secret':secret}).encode(),headers={'Content-Type':'application/json','Origin':ORIGIN},method='POST')
try:
    with urllib.request.urlopen(req,timeout=8) as r: payload=json.load(r)
except urllib.error.HTTPError as e:
    print(e.read().decode('utf-8','replace')); raise SystemExit(1)
print('OK · role =',payload.get('role'),'· token temporaire non conserve.')
if payload.get('role')!='operator': raise SystemExit('ERREUR: role inattendu.')
