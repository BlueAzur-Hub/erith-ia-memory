@echo off
setlocal
cd /d "%~dp0"
echo.
echo === YOHAN OPERATOR - CONFIGURATION OLLAMA ===
echo Le Backend OKX fonctionne independamment de cette etape.
echo.
where ollama >nul 2>nul || (
  echo Ollama n'est pas encore installe ou absent du PATH.
  echo Installe/configure Ollama sur le PC de Yohan puis relance ce fichier.
  pause
  exit /b 1
)
echo Modeles disponibles :
ollama list
echo.
set /p MODEL=Nom exact du modele a utiliser ^(ex: gpt-oss:20b-32k^) : 
if "%MODEL%"=="" exit /b 1
where py >nul 2>nul && (py -3 -c "import json,pathlib; p=pathlib.Path('bridge_config.json'); d=json.loads(p.read_text(encoding='utf-8')); d['providers']['ollama']['model']=r'%MODEL%'; p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8'); print('Modele configure:',r'%MODEL%')" & goto :done)
where python >nul 2>nul && (python -c "import json,pathlib; p=pathlib.Path('bridge_config.json'); d=json.loads(p.read_text(encoding='utf-8')); d['providers']['ollama']['model']=r'%MODEL%'; p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8'); print('Modele configure:',r'%MODEL%')" & goto :done)
echo Python 3 est requis pour modifier bridge_config.json automatiquement.
:done
echo Redemarre ensuite le Bridge depuis le Control Center.
pause
endlocal
