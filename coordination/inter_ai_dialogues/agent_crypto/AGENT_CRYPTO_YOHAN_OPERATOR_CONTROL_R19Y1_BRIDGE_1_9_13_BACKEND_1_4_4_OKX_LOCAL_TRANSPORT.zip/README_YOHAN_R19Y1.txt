YOHAN OPERATOR CONTROL 2.3.2R19Y1 — Agent-Crypto 40.6.509

Base : Control Center 2.3.2R19 / Bridge 1.9.13 / Private Backend 1.4.4 OKX Local Transport.

BUT IMMÉDIAT
- Lancer le Control Center sur le PC Yohan.
- Le Control Center démarre Bridge 8787 et Backend 8790 automatiquement.
- Ollama peut être absent/non configuré : cela n’empêche pas le Backend 1.4.4 de servir les données publiques OKX.
- Ouvrir Operator Yohan puis tester Bougies / Carnet / Profondeur.

SÉCURITÉ YOHAN
- Auth locale = rôle operator uniquement.
- Trust séparé : %LOCALAPPDATA%\ERITH.IA\YohanOperatorBridge\trust.
- GitHub publication / Book Mirror / Oracle Evidence désactivés.
- Aucun wallet, ordre réel, retrait ou API privée exchange.

PLUS TARD
- Configurer Ollama avec bridge\CONFIGURE_YOHAN_OLLAMA.bat.
- Créer le compte local avec bridge\CREATE_OPERATOR_ACCOUNT.bat si nécessaire.

URL OPERATOR
https://blueazur-hub.github.io/agent-crypto-operator/public/agent_crypto_erith_ia/administrator/yohan.html
