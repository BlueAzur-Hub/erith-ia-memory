# Agent-Crypto 40.6.217 — Canonical Header Restore

- Parent: 40.6.216
- Engine: Market Core 38.15.11
- PAPER ONLY
- G3 PENDING
- G9 LOCKED

Fix:
- removes the BODY_START operator bar regression;
- restores the canonical Agent-Crypto header as the first visual header;
- moves Gate-3 operator state inside Evidence;
- keeps a compact Créatrice shortcut near the existing Projects cluster;
- preserves the 40.6.216 post-horizon mount repair and post-T0 evidence.

Canonical GitHub commits:
- compatibility operator asset: a644fd9d28fc5ffde4fb0b0ee736d6c32e26ffb5
- release receipt: 3cefb82cce2de444ca8fdcbb53734069e18ef2ab
- build manifest: 487e732b8aa9f44ace5f0e60e97a7f73e79e6de7
