# Restore Agent-Crypto 40.6.98

Canonical repository truth:
- Repository: BlueAzur-Hub/erith-ia-memory
- Commit: `ea8b16f6ec9257e644c0c661ca4af3ad52f09b22`
- Runtime: `public/agent_crypto_erith_ia/administrator/`
- Immutable entry: `index-40.6.98.html`

This ZIP is a portable handoff patch, not a complete repository clone. Restore exact runtime state from the canonical Git commit above.
