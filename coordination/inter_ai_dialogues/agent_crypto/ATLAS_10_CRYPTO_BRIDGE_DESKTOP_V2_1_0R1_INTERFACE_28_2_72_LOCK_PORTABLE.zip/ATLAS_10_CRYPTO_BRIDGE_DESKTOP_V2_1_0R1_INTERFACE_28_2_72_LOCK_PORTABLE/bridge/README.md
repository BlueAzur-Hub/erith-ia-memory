# Atlas-10 Crypto Bridge Ryzen V1.7.6 — Clean Production Lock

Bridge moteur validé, conservé sans modification fonctionnelle pour le raccord à l’Interface Agent-Crypto Build 28.2.72.

## Rôle

Le Bridge fonctionne uniquement sur le Ryzen et fournit :

- `GET /health`
- `GET /profiles`
- `GET /history`
- `GET /scanner-latest`
- `GET /scanner-status`
- `GET /scanner-history`
- `POST /scanner-snapshot`
- `POST /summary`
- `POST /conclusion`
- `POST /chat`

Il produit les quatre rapports Atlas et la conclusion Aerith à partir du contrat factuel transmis par l’Interface.

## Métaux

Le Bridge V1.7.6 ne fournit aucune route Métaux et ne dépend pas de Metals.Dev.
Les cotations et historiques Métaux restent produits par les fichiers publics GitHub Actions : Gold API, Yahoo Finance Futures et BCE.

## Sécurité

- écoute uniquement sur `127.0.0.1:8787`
- aucune action exchange
- aucun wallet
- aucune écriture GitHub
- aucune action d’interface
- aucune clé fournisseur Métaux
- données de marché et historiques Crypto en lecture seule
- snapshots du Scanner conservés uniquement dans le stockage local du Bridge

## Compatibilité

- Interface : Build 28.2.72
- Control Center : V2.1.0R1
- Bridge : V1.7.6
- Ollama : `llama3.2`
- adresse : `http://127.0.0.1:8787`
