package main

import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	_ "embed"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

const (
	appVersion      = "2.1.0R1"
	bridgeVersion   = "1.7.6"
	interfaceBuild  = "28.2.72"
	interfaceURL    = "https://blueazur-hub.github.io/erith-ia-memory/public/agent_crypto_erith_ia/web/index.html"
	bridgeHealthURL = "http://127.0.0.1:8787/health"
	ollamaTagsURL   = "http://127.0.0.1:11434/api/tags"

	windowClass = "ERITH_ATLAS_CRYPTO_BRIDGE_DESKTOP_V210R1"
	windowTitle = "Atlas-10 Crypto Bridge · Control Center V2.1.0R1"
)

//go:embed payload.zip
var embeddedPayload []byte

const (
	WM_CREATE         = 0x0001
	WM_DESTROY        = 0x0002
	WM_SIZE           = 0x0005
	WM_CLOSE          = 0x0010
	WM_DRAWITEM       = 0x002B
	WM_SETFONT        = 0x0030
	WM_COMMAND        = 0x0111
	WM_TIMER          = 0x0113
	WM_CTLCOLORSTATIC = 0x0138
	WM_CTLCOLOREDIT   = 0x0133
	WM_APP            = 0x8000
	WM_STATUS         = WM_APP + 1
	WM_ACTION_DONE    = WM_APP + 2
	WM_TRAY           = WM_APP + 3

	WM_LBUTTONUP     = 0x0202
	WM_LBUTTONDBLCLK = 0x0203
	WM_RBUTTONUP     = 0x0205

	WS_OVERLAPPEDWINDOW = 0x00CF0000
	WS_VISIBLE          = 0x10000000
	WS_CHILD            = 0x40000000
	WS_BORDER           = 0x00800000
	WS_VSCROLL          = 0x00200000
	WS_TABSTOP          = 0x00010000
	WS_CLIPCHILDREN     = 0x02000000

	ES_MULTILINE   = 0x0004
	ES_AUTOVSCROLL = 0x0040
	ES_READONLY    = 0x0800
	ES_NOHIDESEL   = 0x0100

	BS_OWNERDRAW = 0x0000000B

	SW_HIDE       = 0
	SW_SHOW       = 5
	SW_SHOWNORMAL = 1
	SW_RESTORE    = 9

	IDC_ARROW        = 32512
	IDI_APPLICATION  = 32512
	NIM_ADD          = 0
	NIM_DELETE       = 2
	NIF_MESSAGE      = 0x00000001
	NIF_ICON         = 0x00000002
	NIF_TIP          = 0x00000004
	CREATE_NO_WINDOW = 0x08000000

	ID_START       = 101
	ID_STOP        = 102
	ID_RESTART     = 103
	ID_OPEN_UI     = 104
	ID_OPEN_LOGS   = 105
	ID_TEST        = 106
	ID_OPEN_FOLDER = 107
	ID_AUTOSTART   = 108
	ID_AUTO_OPEN   = 109
	ID_TRAY_MODE   = 110
	ID_QUIT        = 111

	DT_CENTER     = 0x00000001
	DT_VCENTER    = 0x00000004
	DT_SINGLELINE = 0x00000020
	TRANSPARENT   = 1

	ODS_DISABLED = 0x0004

	PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
	STILL_ACTIVE                      = 259

	EM_SETBKGNDCOLOR = 0x0443
	EM_SETSEL        = 0x00B1
	EM_SCROLLCARET   = 0x00B7
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")

	procRegisterClassExW    = user32.NewProc("RegisterClassExW")
	procCreateWindowExW     = user32.NewProc("CreateWindowExW")
	procDefWindowProcW      = user32.NewProc("DefWindowProcW")
	procShowWindow          = user32.NewProc("ShowWindow")
	procIsWindowVisible     = user32.NewProc("IsWindowVisible")
	procSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	procLoadIconW           = user32.NewProc("LoadIconW")
	procUpdateWindow        = user32.NewProc("UpdateWindow")
	procGetMessageW         = user32.NewProc("GetMessageW")
	procTranslateMessage    = user32.NewProc("TranslateMessage")
	procDispatchMessageW    = user32.NewProc("DispatchMessageW")
	procPostQuitMessage     = user32.NewProc("PostQuitMessage")
	procDestroyWindow       = user32.NewProc("DestroyWindow")
	procSetWindowTextW      = user32.NewProc("SetWindowTextW")
	procSendMessageW        = user32.NewProc("SendMessageW")
	procPostMessageW        = user32.NewProc("PostMessageW")
	procSetTimer            = user32.NewProc("SetTimer")
	procKillTimer           = user32.NewProc("KillTimer")
	procLoadCursorW         = user32.NewProc("LoadCursorW")
	procEnableWindow        = user32.NewProc("EnableWindow")
	procGetSystemMetrics    = user32.NewProc("GetSystemMetrics")
	procSetProcessDPIAware  = user32.NewProc("SetProcessDPIAware")
	procMoveWindow          = user32.NewProc("MoveWindow")
	procGetClientRect       = user32.NewProc("GetClientRect")
	procFillRect            = user32.NewProc("FillRect")
	procDrawTextW           = user32.NewProc("DrawTextW")
	procGetWindowTextW      = user32.NewProc("GetWindowTextW")
	procInvalidateRect      = user32.NewProc("InvalidateRect")

	procGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	procCreateMutexW       = kernel32.NewProc("CreateMutexW")
	procCloseHandle        = kernel32.NewProc("CloseHandle")
	procOpenProcess        = kernel32.NewProc("OpenProcess")
	procGetExitCodeProcess = kernel32.NewProc("GetExitCodeProcess")

	procShellExecuteW    = shell32.NewProc("ShellExecuteW")
	procShellNotifyIconW = shell32.NewProc("Shell_NotifyIconW")

	procCreateSolidBrush = gdi32.NewProc("CreateSolidBrush")
	procCreatePen        = gdi32.NewProc("CreatePen")
	procDeleteObject     = gdi32.NewProc("DeleteObject")
	procSelectObject     = gdi32.NewProc("SelectObject")
	procSetTextColor     = gdi32.NewProc("SetTextColor")
	procSetBkColor       = gdi32.NewProc("SetBkColor")
	procSetBkMode        = gdi32.NewProc("SetBkMode")
	procRoundRect        = gdi32.NewProc("RoundRect")
	procCreateFontW      = gdi32.NewProc("CreateFontW")

	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
)

type point struct{ X, Y int32 }
type rect struct{ Left, Top, Right, Bottom int32 }
type msg struct {
	Hwnd           syscall.Handle
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             point
	Private        uint32
}
type wndClassEx struct {
	CbSize                        uint32
	Style                         uint32
	LpfnWndProc                   uintptr
	CbClsExtra, CbWndExtra        int32
	HInstance                     syscall.Handle
	HIcon, HCursor, HbrBackground syscall.Handle
	LpszMenuName, LpszClassName   *uint16
	HIconSm                       syscall.Handle
}
type drawItemStruct struct {
	CtlType, CtlID, ItemID, ItemAction, ItemState uint32
	HwndItem, HDC                                 syscall.Handle
	RcItem                                        rect
	ItemData                                      uintptr
}

type healthResponse struct {
	OK            bool   `json:"ok"`
	Ready         bool   `json:"ready"`
	Version       string `json:"version"`
	Model         string `json:"model"`
	RequiredModel string `json:"required_model"`
}
type ollamaTags struct {
	Models []struct {
		Name  string `json:"name"`
		Model string `json:"model"`
	} `json:"models"`
}
type statusSnapshot struct {
	BridgeOK      bool
	OllamaOK      bool
	Managed       bool
	ManagedPID    int
	BridgeText    string
	OllamaText    string
	ModelText     string
	OwnershipText string
	WorkspaceText string
	CheckedText   string
	LogText       string
}
type actionResult struct {
	action   string
	snapshot statusSnapshot
	message  string
	errText  string
}
type pythonCommand struct {
	Path    string
	Prefix  []string
	Display string
}

type appSettings struct {
	AutoStartWindows  bool `json:"auto_start_windows"`
	AutoOpenInterface bool `json:"auto_open_interface"`
	MinimizeToTray    bool `json:"minimize_to_tray"`
}

type notifyIconData struct {
	CbSize           uint32
	HWnd             syscall.Handle
	UID              uint32
	UFlags           uint32
	UCallbackMessage uint32
	HIcon            syscall.Handle
	SzTip            [128]uint16
	DwState          uint32
	DwStateMask      uint32
	SzInfo           [256]uint16
	UVersion         uint32
	SzInfoTitle      [64]uint16
	DwInfoFlags      uint32
	GuidItem         [16]byte
	HBalloonIcon     syscall.Handle
}

var (
	mainWindow                                                                                    syscall.Handle
	titleLabel, subtitleLabel                                                                     syscall.Handle
	labelBridge, labelOllama, labelModel, labelOwnership                                          syscall.Handle
	labelWorkspace, labelChecked, actionLabel, logTitle, footerLabel                              syscall.Handle
	logBox                                                                                        syscall.Handle
	buttonStart, buttonStop, buttonRestart, buttonOpenUI, buttonJournal, buttonTest, buttonFolder syscall.Handle
	buttonAutostart, buttonAutoOpen, buttonTrayMode, buttonQuit                                   syscall.Handle
	buttonHandles                                                                                 []syscall.Handle
	cardControls                                                                                  = map[syscall.Handle]bool{}

	fontTitle, fontSubtitle, fontCard, fontButton, fontLog, fontFooter syscall.Handle
	brushBG, brushPanel, brushCard                                     syscall.Handle

	stateMu       sync.Mutex
	latestStatus  statusSnapshot
	pendingResult actionResult
	lastAction    = "Initialisation du Control Center…"

	workspaceRoot, bridgeDir, logsDir string
	portableMode                      bool

	refreshBusy atomic.Bool
	actionBusy  atomic.Bool
	exiting     atomic.Bool
	startStopMu sync.Mutex
	appMutex    syscall.Handle
	settingsMu  sync.Mutex
	settings    = appSettings{MinimizeToTray: false}
	trayAdded   atomic.Bool
)

func rgb(r, g, b byte) uintptr { return uintptr(r) | uintptr(g)<<8 | uintptr(b)<<16 }

var (
	colorBG      = rgb(5, 13, 24)
	colorPanel   = rgb(10, 25, 42)
	colorCard    = rgb(15, 39, 60)
	colorButton  = rgb(22, 60, 86)
	colorButton2 = rgb(39, 76, 97)
	colorCyan    = rgb(72, 214, 229)
	colorGold    = rgb(232, 198, 105)
	colorText    = rgb(239, 247, 251)
	colorMuted   = rgb(148, 169, 187)
	colorGreen   = rgb(74, 210, 139)
	colorRed     = rgb(255, 108, 123)
)

func utf16Ptr(value string) *uint16 { ptr, _ := syscall.UTF16PtrFromString(value); return ptr }
func loword(v uintptr) uint16       { return uint16(v & 0xffff) }
func hiword(v uintptr) uint16       { return uint16((v >> 16) & 0xffff) }
func setText(hwnd syscall.Handle, text string) {
	if hwnd != 0 {
		procSetWindowTextW.Call(uintptr(hwnd), uintptr(unsafe.Pointer(utf16Ptr(text))))
	}
}
func setFont(hwnd, font syscall.Handle) {
	if hwnd != 0 && font != 0 {
		procSendMessageW.Call(uintptr(hwnd), WM_SETFONT, uintptr(font), 1)
	}
}
func move(hwnd syscall.Handle, x, y, w, h int32) {
	if hwnd != 0 {
		procMoveWindow.Call(uintptr(hwnd), uintptr(x), uintptr(y), uintptr(w), uintptr(h), 1)
	}
}
func shellOpen(target string) {
	procShellExecuteW.Call(0, uintptr(unsafe.Pointer(utf16Ptr("open"))), uintptr(unsafe.Pointer(utf16Ptr(target))), 0, 0, SW_SHOWNORMAL)
}
func appendLauncherLog(message string) {
	if logsDir == "" {
		return
	}
	_ = os.MkdirAll(logsDir, 0o755)
	f, err := os.OpenFile(filepath.Join(logsDir, "desktop.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = fmt.Fprintf(f, "%s  %s\n", time.Now().Format("2006-01-02 15:04:05"), message)
}
func payloadDigest() string { sum := sha256.Sum256(embeddedPayload); return fmt.Sprintf("%x", sum[:]) }

func settingsPath() string {
	return filepath.Join(workspaceRoot, "control_center_settings.json")
}

func loadSettings() {
	settingsMu.Lock()
	defer settingsMu.Unlock()
	data, err := os.ReadFile(settingsPath())
	if err == nil {
		var loaded appSettings
		if json.Unmarshal(data, &loaded) == nil {
			settings = loaded
		}
	}
	if enabled, err := windowsAutostartEnabled(); err == nil {
		settings.AutoStartWindows = enabled
	}
}

func saveSettingsLocked() error {
	data, err := json.MarshalIndent(settings, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(settingsPath(), append(data, '\n'), 0o644)
}

func settingsSnapshot() appSettings {
	settingsMu.Lock()
	defer settingsMu.Unlock()
	return settings
}

func setAutoOpenInterface(enabled bool) error {
	settingsMu.Lock()
	settings.AutoOpenInterface = enabled
	err := saveSettingsLocked()
	settingsMu.Unlock()
	return err
}

func setMinimizeToTray(enabled bool) error {
	settingsMu.Lock()
	settings.MinimizeToTray = enabled
	err := saveSettingsLocked()
	settingsMu.Unlock()
	return err
}

func runHiddenCommand(name string, args ...string) ([]byte, error) {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = hiddenSysProcAttr()
	return cmd.CombinedOutput()
}

func windowsAutostartEnabled() (bool, error) {
	output, err := runHiddenCommand(
		"reg.exe",
		"query",
		`HKCU\Software\Microsoft\Windows\CurrentVersion\Run`,
		"/v",
		"ERITH.IA Atlas Crypto Bridge",
	)
	if err != nil {
		return false, nil
	}
	exePath, e := os.Executable()
	if e != nil {
		return false, e
	}
	text := strings.ToLower(string(output))
	return strings.Contains(text, strings.ToLower(exePath)), nil
}

func setWindowsAutostart(enabled bool) error {
	exePath, err := os.Executable()
	if err != nil {
		return err
	}
	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`
	name := "ERITH.IA Atlas Crypto Bridge"
	if enabled {
		value := `"` + exePath + `"`
		output, err := runHiddenCommand(
			"reg.exe", "add", key,
			"/v", name,
			"/t", "REG_SZ",
			"/d", value,
			"/f",
		)
		if err != nil {
			return fmt.Errorf("activation Windows impossible: %v · %s", err, strings.TrimSpace(string(output)))
		}
	} else {
		output, err := runHiddenCommand("reg.exe", "delete", key, "/v", name, "/f")
		if err != nil {
			text := strings.ToLower(string(output))
			if !strings.Contains(text, "unable to find") &&
				!strings.Contains(text, "introuvable") &&
				!strings.Contains(text, "specified registry") {
				return fmt.Errorf("désactivation Windows impossible: %v · %s", err, strings.TrimSpace(string(output)))
			}
		}
	}
	settingsMu.Lock()
	settings.AutoStartWindows = enabled
	err = saveSettingsLocked()
	settingsMu.Unlock()
	return err
}

func copyUTF16Fixed(dst []uint16, value string) {
	encoded := syscall.StringToUTF16(value)
	if len(encoded) > len(dst) {
		encoded = encoded[:len(dst)]
		if len(encoded) > 0 {
			encoded[len(encoded)-1] = 0
		}
	}
	copy(dst, encoded)
}

func addTrayIcon() bool {
	if mainWindow == 0 || trayAdded.Load() {
		return trayAdded.Load()
	}
	icon, _, _ := procLoadIconW.Call(0, IDI_APPLICATION)
	var nid notifyIconData
	nid.CbSize = uint32(unsafe.Sizeof(nid))
	nid.HWnd = mainWindow
	nid.UID = 1
	nid.UFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
	nid.UCallbackMessage = WM_TRAY
	nid.HIcon = syscall.Handle(icon)
	copyUTF16Fixed(nid.SzTip[:], "Atlas-10 Crypto Bridge Control Center")
	ok, _, _ := procShellNotifyIconW.Call(NIM_ADD, uintptr(unsafe.Pointer(&nid)))
	if ok != 0 {
		trayAdded.Store(true)
		return true
	}
	return false
}

func removeTrayIcon() {
	if mainWindow == 0 || !trayAdded.Load() {
		return
	}
	var nid notifyIconData
	nid.CbSize = uint32(unsafe.Sizeof(nid))
	nid.HWnd = mainWindow
	nid.UID = 1
	procShellNotifyIconW.Call(NIM_DELETE, uintptr(unsafe.Pointer(&nid)))
	trayAdded.Store(false)
}

func restoreFromTray() {
	if mainWindow == 0 {
		return
	}
	procShowWindow.Call(uintptr(mainWindow), SW_RESTORE)
	procSetForegroundWindow.Call(uintptr(mainWindow))
	stateMu.Lock()
	lastAction = "Control Center restauré depuis la zone de notification"
	stateMu.Unlock()
	applyStatus()
}

func requestRealExit() {
	exiting.Store(true)
	removeTrayIcon()
	if mainWindow != 0 {
		procKillTimer.Call(uintptr(mainWindow), 1)
		appendLauncherLog("Control Center quitté ; Bridge laissé actif.")
		procDestroyWindow.Call(uintptr(mainWindow))
	}
}

func resolveWorkspace() error {
	exePath, err := os.Executable()
	if err != nil {
		return err
	}
	exeDir := filepath.Dir(exePath)
	if _, e1 := os.Stat(filepath.Join(exeDir, "portable.flag")); e1 == nil {
		if _, e2 := os.Stat(filepath.Join(exeDir, "bridge", "bridge.py")); e2 == nil {
			portableMode = true
			workspaceRoot = exeDir
			bridgeDir = filepath.Join(exeDir, "bridge")
			logsDir = filepath.Join(exeDir, "logs")
			return os.MkdirAll(logsDir, 0o755)
		}
	}
	localAppData := os.Getenv("LOCALAPPDATA")
	if localAppData == "" {
		localAppData, err = os.UserConfigDir()
		if err != nil {
			return err
		}
	}
	workspaceRoot = filepath.Join(localAppData, "ERITH.IA", "AtlasCryptoBridge", appVersion)
	bridgeDir = filepath.Join(workspaceRoot, "bridge")
	logsDir = filepath.Join(workspaceRoot, "logs")
	marker := filepath.Join(workspaceRoot, ".payload.sha256")
	expected := payloadDigest()
	current, _ := os.ReadFile(marker)
	if strings.TrimSpace(string(current)) != expected {
		if err := os.RemoveAll(workspaceRoot); err != nil {
			return err
		}
		if err := os.MkdirAll(workspaceRoot, 0o755); err != nil {
			return err
		}
		if err := extractZipBytes(embeddedPayload, workspaceRoot); err != nil {
			return err
		}
		if err := os.WriteFile(marker, []byte(expected+"\n"), 0o644); err != nil {
			return err
		}
	}
	return os.MkdirAll(logsDir, 0o755)
}
func extractZipBytes(data []byte, destination string) error {
	reader, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return err
	}
	cleanRoot := filepath.Clean(destination) + string(os.PathSeparator)
	for _, entry := range reader.File {
		target := filepath.Clean(filepath.Join(destination, filepath.FromSlash(entry.Name)))
		if !strings.HasPrefix(target+string(os.PathSeparator), cleanRoot) {
			return fmt.Errorf("chemin ZIP refusé: %s", entry.Name)
		}
		if entry.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		rc, err := entry.Open()
		if err != nil {
			return err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, entry.Mode())
		if err != nil {
			rc.Close()
			return err
		}
		_, copyErr := io.Copy(out, rc)
		closeErr := out.Close()
		rc.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}
func locatePython() (*pythonCommand, error) {
	candidates := []pythonCommand{{Path: "py.exe", Prefix: []string{"-3"}, Display: "py -3"}, {Path: "python.exe", Display: "python"}, {Path: "python3.exe", Display: "python3"}}
	for _, c := range candidates {
		if p, err := exec.LookPath(c.Path); err == nil {
			c.Path = p
			return &c, nil
		}
	}
	return nil, fmt.Errorf("Python 3 est introuvable sur le Ryzen")
}
func hiddenSysProcAttr() *syscall.SysProcAttr {
	return &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
}
func runSelfTest(py *pythonCommand) error {
	args := append(append([]string{}, py.Prefix...), filepath.Join(bridgeDir, "bridge.py"), "--self-test")
	cmd := exec.Command(py.Path, args...)
	cmd.Dir = bridgeDir
	cmd.SysProcAttr = hiddenSysProcAttr()
	output, err := cmd.CombinedOutput()
	appendLauncherLog("Self-test via " + py.Display + ":\n" + strings.TrimSpace(string(output)))
	if err != nil {
		return fmt.Errorf("self-test Bridge échoué: %w", err)
	}
	return nil
}
func isBridgeHealthy() bool {
	client := &http.Client{Timeout: 1100 * time.Millisecond}
	r, err := client.Get(bridgeHealthURL)
	if err != nil {
		return false
	}
	defer r.Body.Close()
	return r.StatusCode == http.StatusOK
}
func processAlive(pid int) bool {
	if pid <= 0 {
		return false
	}
	h, _, _ := procOpenProcess.Call(PROCESS_QUERY_LIMITED_INFORMATION, 0, uintptr(pid))
	if h == 0 {
		return false
	}
	defer procCloseHandle.Call(h)
	var code uint32
	ok, _, _ := procGetExitCodeProcess.Call(h, uintptr(unsafe.Pointer(&code)))
	return ok != 0 && code == STILL_ACTIVE
}
func managedPID() int {
	data, err := os.ReadFile(filepath.Join(bridgeDir, "bridge.pid"))
	if err != nil {
		return 0
	}
	pid, err := strconv.Atoi(strings.TrimSpace(string(data)))
	if err != nil || !processAlive(pid) {
		return 0
	}
	return pid
}
func startBridge() (string, error) {
	startStopMu.Lock()
	defer startStopMu.Unlock()
	if isBridgeHealthy() {
		if pid := managedPID(); pid > 0 {
			return fmt.Sprintf("Bridge déjà actif et pilotable · PID %d", pid), nil
		}
		return "Bridge externe déjà actif · aucune action effectuée", nil
	}
	py, err := locatePython()
	if err != nil {
		return "", err
	}
	if err := runSelfTest(py); err != nil {
		return "", err
	}
	if err := os.MkdirAll(logsDir, 0o755); err != nil {
		return "", err
	}
	logFile, err := os.OpenFile(filepath.Join(logsDir, "bridge.log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return "", err
	}
	args := append(append([]string{}, py.Prefix...), filepath.Join(bridgeDir, "bridge.py"))
	cmd := exec.Command(py.Path, args...)
	cmd.Dir = bridgeDir
	cmd.Stdout = logFile
	cmd.Stderr = logFile
	cmd.SysProcAttr = hiddenSysProcAttr()
	if err := cmd.Start(); err != nil {
		logFile.Close()
		return "", err
	}
	appendLauncherLog(fmt.Sprintf("Bridge lancé avec %s · PID %d", py.Display, cmd.Process.Pid))
	go func() {
		err := cmd.Wait()
		_ = logFile.Close()
		appendLauncherLog(fmt.Sprintf("Processus Bridge terminé: %v", err))
		requestRefresh()
	}()
	deadline := time.Now().Add(8 * time.Second)
	for time.Now().Before(deadline) {
		if isBridgeHealthy() {
			return fmt.Sprintf("Bridge démarré · PID %d", cmd.Process.Pid), nil
		}
		time.Sleep(180 * time.Millisecond)
	}
	return "", fmt.Errorf("Bridge lancé mais /health ne répond pas")
}
func stopBridge() (string, error) {
	startStopMu.Lock()
	defer startStopMu.Unlock()
	if !isBridgeHealthy() {
		_ = os.Remove(filepath.Join(bridgeDir, "bridge.pid"))
		return "Bridge déjà inactif", nil
	}
	pid := managedPID()
	if pid <= 0 {
		return "", fmt.Errorf("Bridge externe détecté : arrêt refusé pour protéger le processus")
	}
	cmd := exec.Command("taskkill.exe", "/PID", strconv.Itoa(pid), "/T", "/F")
	cmd.SysProcAttr = hiddenSysProcAttr()
	output, err := cmd.CombinedOutput()
	if err != nil && processAlive(pid) {
		return "", fmt.Errorf("taskkill a échoué: %v · %s", err, strings.TrimSpace(string(output)))
	}
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if !isBridgeHealthy() {
			_ = os.Remove(filepath.Join(bridgeDir, "bridge.pid"))
			return fmt.Sprintf("Bridge arrêté · PID %d", pid), nil
		}
		time.Sleep(150 * time.Millisecond)
	}
	return "", fmt.Errorf("le Bridge répond encore après l’arrêt")
}
func restartBridge() (string, error) {
	message, err := stopBridge()
	if err != nil {
		return "", err
	}
	time.Sleep(400 * time.Millisecond)
	started, err := startBridge()
	if err != nil {
		return "", err
	}
	return message + " · " + started, nil
}
func tailFile(path string, maxBytes int64) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil {
		return ""
	}
	start := info.Size() - maxBytes
	if start < 0 {
		start = 0
	}
	_, _ = f.Seek(start, io.SeekStart)
	data, _ := io.ReadAll(f)
	return strings.TrimSpace(strings.ReplaceAll(string(data), "\n", "\r\n"))
}
func combinedLogText() string {
	desktop := tailFile(filepath.Join(logsDir, "desktop.log"), 9000)
	bridge := tailFile(filepath.Join(logsDir, "bridge.log"), 11000)
	parts := []string{}
	if desktop != "" {
		parts = append(parts, "=== CONTROL CENTER ===\r\n"+desktop)
	}
	if bridge != "" {
		parts = append(parts, "=== BRIDGE ===\r\n"+bridge)
	}
	if len(parts) == 0 {
		return "Journal prêt. Les actions et contrôles apparaîtront ici."
	}
	text := strings.Join(parts, "\r\n\r\n")
	if len(text) > 20000 {
		text = text[len(text)-20000:]
	}
	return text
}
func writeCombinedJournal() (string, error) {
	if err := os.MkdirAll(logsDir, 0o755); err != nil {
		return "", err
	}
	path := filepath.Join(logsDir, "journal_complet.txt")
	if err := os.WriteFile(path, []byte(strings.ReplaceAll(combinedLogText(), "\r\n", "\n")+"\n"), 0o644); err != nil {
		return "", err
	}
	return path, nil
}
func fetchStatus() statusSnapshot {
	s := statusSnapshot{
		BridgeText:    "BRIDGE\r\n● Inactif",
		OllamaText:    "OLLAMA\r\n● Non détecté",
		ModelText:     "MODÈLE\r\nllama3.2 requis",
		OwnershipText: "PILOTAGE\r\nAucun processus géré",
		WorkspaceText: "DOSSIER TECHNIQUE\r\n" + workspaceRoot,
		CheckedText:   "Dernier contrôle : " + time.Now().Format("15:04:05"),
		LogText:       combinedLogText(),
	}
	client := &http.Client{Timeout: 1500 * time.Millisecond}
	if r, err := client.Get(bridgeHealthURL); err == nil {
		defer r.Body.Close()
		var h healthResponse
		if r.StatusCode == http.StatusOK && json.NewDecoder(r.Body).Decode(&h) == nil && h.OK {
			s.BridgeOK = true
			version := h.Version
			if version == "" {
				version = bridgeVersion
			}
			state := "actif"
			if h.Ready {
				state = "actif · prêt"
			} else {
				state = "actif · modèle non prêt"
			}
			s.BridgeText = "BRIDGE\r\n● " + state + " · V" + version
			if h.Model != "" {
				s.ModelText = "MODÈLE\r\n" + h.Model
			} else if h.RequiredModel != "" {
				s.ModelText = "MODÈLE REQUIS\r\n" + h.RequiredModel
			}
		}
	}
	if r, err := client.Get(ollamaTagsURL); err == nil {
		defer r.Body.Close()
		var tags ollamaTags
		if r.StatusCode == http.StatusOK && json.NewDecoder(r.Body).Decode(&tags) == nil {
			s.OllamaOK = true
			found := false
			for _, m := range tags.Models {
				name := m.Name
				if name == "" {
					name = m.Model
				}
				if strings.HasPrefix(strings.ToLower(name), "llama3.2") {
					found = true
					break
				}
			}
			if found {
				s.OllamaText = "OLLAMA\r\n● Connecté · llama3.2 disponible"
			} else {
				s.OllamaText = "OLLAMA\r\n● Connecté · llama3.2 absent"
			}
		}
	}
	if s.BridgeOK {
		if pid := managedPID(); pid > 0 {
			s.Managed = true
			s.ManagedPID = pid
			s.OwnershipText = fmt.Sprintf("PILOTAGE\r\n● Géré par cette installation · PID %d", pid)
		} else {
			s.OwnershipText = "PILOTAGE\r\n● Bridge externe · lecture seule"
		}
	}
	return s
}
func requestRefresh() {
	if exiting.Load() || mainWindow == 0 {
		return
	}
	procPostMessageW.Call(uintptr(mainWindow), WM_STATUS, 0, 0)
}
func refreshAsync() {
	if exiting.Load() || !refreshBusy.CompareAndSwap(false, true) {
		return
	}
	go func() {
		s := fetchStatus()
		stateMu.Lock()
		latestStatus = s
		stateMu.Unlock()
		refreshBusy.Store(false)
		requestRefresh()
	}()
}
func postActionResult(r actionResult) {
	stateMu.Lock()
	pendingResult = r
	stateMu.Unlock()
	if !exiting.Load() && mainWindow != 0 {
		procPostMessageW.Call(uintptr(mainWindow), WM_ACTION_DONE, 0, 0)
	}
}
func runAction(action string, worker func() (string, error)) {
	if !actionBusy.CompareAndSwap(false, true) {
		return
	}
	stateMu.Lock()
	lastAction = action + "…"
	stateMu.Unlock()
	applyStatus()
	go func() {
		message, err := worker()
		s := fetchStatus()
		r := actionResult{action: action, snapshot: s, message: message}
		if err != nil {
			r.errText = err.Error()
		}
		postActionResult(r)
	}()
}
func setButtonEnabled(hwnd syscall.Handle, enabled bool) {
	v := uintptr(0)
	if enabled {
		v = 1
	}
	procEnableWindow.Call(uintptr(hwnd), v)
	procInvalidateRect.Call(uintptr(hwnd), 0, 1)
}
func applyButtonState(s statusSnapshot) {
	busy := actionBusy.Load()
	setButtonEnabled(buttonStart, !busy && !s.BridgeOK)
	setButtonEnabled(buttonStop, !busy && s.BridgeOK && s.Managed)
	setButtonEnabled(buttonRestart, !busy && s.BridgeOK && s.Managed)
	setButtonEnabled(buttonOpenUI, !busy)
	setButtonEnabled(buttonJournal, !busy)
	setButtonEnabled(buttonTest, !busy)
	setButtonEnabled(buttonFolder, !busy)
	setButtonEnabled(buttonAutostart, !busy)
	setButtonEnabled(buttonAutoOpen, !busy)
	setButtonEnabled(buttonTrayMode, !busy)
	setButtonEnabled(buttonQuit, true)
}
func applyStatus() {
	stateMu.Lock()
	s := latestStatus
	action := lastAction
	stateMu.Unlock()
	setText(labelBridge, s.BridgeText)
	setText(labelOllama, s.OllamaText)
	setText(labelModel, s.ModelText)
	setText(labelOwnership, s.OwnershipText)
	setText(labelWorkspace, s.WorkspaceText)
	setText(labelChecked, s.CheckedText)
	setText(actionLabel, "DERNIÈRE ACTION\r\n"+action)
	set := settingsSnapshot()
	autoStartText := "Démarrage Windows : NON"
	if set.AutoStartWindows {
		autoStartText = "Démarrage Windows : OUI"
	}
	autoOpenText := "Interface auto : NON"
	if set.AutoOpenInterface {
		autoOpenText = "Interface auto : OUI"
	}
	trayText := "Zone notification : NON"
	if set.MinimizeToTray {
		trayText = "Zone notification : OUI"
	}
	setText(buttonAutostart, autoStartText)
	setText(buttonAutoOpen, autoOpenText)
	setText(buttonTrayMode, trayText)
	setText(logBox, s.LogText)
	procSendMessageW.Call(uintptr(logBox), EM_SETSEL, ^uintptr(0), ^uintptr(0))
	procSendMessageW.Call(uintptr(logBox), EM_SCROLLCARET, 0, 0)
	mode := "installation locale"
	if portableMode {
		mode = "dossier portable"
	}
	closeMode := "la croix ferme le Control Center · Bridge laissé actif"
	if set.MinimizeToTray {
		closeMode = "la croix réduit dans la zone de notification · Bridge laissé actif"
	}
	setText(footerLabel, "Interface Agent-Crypto Build "+interfaceBuild+" · "+mode+" · 127.0.0.1:8787 · "+closeMode)
	applyButtonState(s)
}
func testText(s statusSnapshot) string {
	bridge := "ÉCHEC"
	if s.BridgeOK {
		bridge = "OK"
	}
	ollama := "ÉCHEC"
	if s.OllamaOK {
		ollama = "OK"
	}
	control := "externe"
	if s.Managed {
		control = fmt.Sprintf("pilotable · PID %d", s.ManagedPID)
	}
	return fmt.Sprintf("Test terminé · Bridge %s · Ollama %s · %s", bridge, ollama, control)
}
func buttonAction(id uint16) {
	switch id {
	case ID_START:
		runAction("Démarrage du Bridge", startBridge)
	case ID_STOP:
		runAction("Arrêt du Bridge", stopBridge)
	case ID_RESTART:
		runAction("Redémarrage du Bridge", restartBridge)
	case ID_OPEN_UI:
		shellOpen(interfaceURL)
		stateMu.Lock()
		lastAction = "Interface Agent-Crypto ouverte"
		stateMu.Unlock()
		applyStatus()
	case ID_OPEN_LOGS:
		path, err := writeCombinedJournal()
		stateMu.Lock()
		if err != nil {
			lastAction = "Journal : " + err.Error()
		} else {
			lastAction = "Journal complet ouvert"
			shellOpen(path)
		}
		stateMu.Unlock()
		applyStatus()
	case ID_TEST:
		runAction("Test Bridge + Ollama", func() (string, error) { s := fetchStatus(); m := testText(s); appendLauncherLog(m); return m, nil })
	case ID_OPEN_FOLDER:
		shellOpen(workspaceRoot)
		stateMu.Lock()
		lastAction = "Dossier technique ouvert"
		stateMu.Unlock()
		applyStatus()
	case ID_AUTOSTART:
		current := settingsSnapshot().AutoStartWindows
		runAction("Démarrage avec Windows", func() (string, error) {
			next := !current
			if err := setWindowsAutostart(next); err != nil {
				return "", err
			}
			if next {
				return "Démarrage avec Windows activé", nil
			}
			return "Démarrage avec Windows désactivé", nil
		})
	case ID_AUTO_OPEN:
		current := settingsSnapshot().AutoOpenInterface
		next := !current
		stateMu.Lock()
		if err := setAutoOpenInterface(next); err != nil {
			lastAction = "Interface automatique · ÉCHEC · " + err.Error()
		} else if next {
			lastAction = "Ouverture automatique de l’Interface activée"
		} else {
			lastAction = "Ouverture automatique de l’Interface désactivée"
		}
		stateMu.Unlock()
		applyStatus()
	case ID_TRAY_MODE:
		current := settingsSnapshot().MinimizeToTray
		next := !current
		stateMu.Lock()
		if err := setMinimizeToTray(next); err != nil {
			lastAction = "Zone de notification · ÉCHEC · " + err.Error()
		} else if next {
			if addTrayIcon() {
				lastAction = "Zone de notification activée · la croix réduira le Control Center"
			} else {
				lastAction = "Zone de notification enregistrée · icône non créée"
			}
		} else {
			removeTrayIcon()
			lastAction = "Zone de notification désactivée · la croix fermera le Control Center"
		}
		stateMu.Unlock()
		applyStatus()
	case ID_QUIT:
		requestRealExit()
	}
}

func createFont(height int32, weight int32, face string) syscall.Handle {
	h, _, _ := procCreateFontW.Call(uintptr(height), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(utf16Ptr(face))))
	return syscall.Handle(h)
}
func createControl(className, text string, style uint32, parent syscall.Handle, id int, font syscall.Handle) syscall.Handle {
	hwnd, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16Ptr(className))), uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(style), 0, 0, 10, 10, uintptr(parent), uintptr(id), 0, 0)
	h := syscall.Handle(hwnd)
	setFont(h, font)
	return h
}
func registerCard(hwnd syscall.Handle) { cardControls[hwnd] = true }
func getWindowText(hwnd syscall.Handle) string {
	buf := make([]uint16, 256)
	n, _, _ := procGetWindowTextW.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf[:n])
}
func drawButton(dis *drawItemStruct) {
	disabled := dis.ItemState&ODS_DISABLED != 0
	fill := colorButton
	textColor := colorText
	border := colorCyan
	if disabled {
		fill = rgb(27, 39, 52)
		textColor = rgb(92, 110, 126)
		border = rgb(45, 65, 80)
	}
	brush, _, _ := procCreateSolidBrush.Call(fill)
	pen, _, _ := procCreatePen.Call(0, 1, border)
	oldB, _, _ := procSelectObject.Call(uintptr(dis.HDC), brush)
	oldP, _, _ := procSelectObject.Call(uintptr(dis.HDC), pen)
	procRoundRect.Call(uintptr(dis.HDC), uintptr(dis.RcItem.Left), uintptr(dis.RcItem.Top), uintptr(dis.RcItem.Right), uintptr(dis.RcItem.Bottom), 12, 12)
	procSelectObject.Call(uintptr(dis.HDC), oldB)
	procSelectObject.Call(uintptr(dis.HDC), oldP)
	procDeleteObject.Call(brush)
	procDeleteObject.Call(pen)
	procSetBkMode.Call(uintptr(dis.HDC), TRANSPARENT)
	procSetTextColor.Call(uintptr(dis.HDC), textColor)
	procSelectObject.Call(uintptr(dis.HDC), uintptr(fontButton))
	text := getWindowText(dis.HwndItem)
	r := dis.RcItem
	procDrawTextW.Call(uintptr(dis.HDC), uintptr(unsafe.Pointer(utf16Ptr(text))), uintptr(len([]rune(text))), uintptr(unsafe.Pointer(&r)), DT_CENTER|DT_VCENTER|DT_SINGLELINE)
}
func layoutControls(hwnd syscall.Handle) {
	var rc rect
	procGetClientRect.Call(uintptr(hwnd), uintptr(unsafe.Pointer(&rc)))
	w := rc.Right - rc.Left
	h := rc.Bottom - rc.Top
	if w < 920 {
		w = 920
	}
	if h < 720 {
		h = 720
	}
	m := int32(24)
	gap := int32(14)
	content := w - 2*m
	move(titleLabel, m, 18, content, 38)
	move(subtitleLabel, m, 58, content, 28)

	cardW := (content - gap) / 2
	move(labelBridge, m, 104, cardW, 82)
	move(labelOllama, m+cardW+gap, 104, cardW, 82)
	move(labelModel, m, 198, cardW, 82)
	move(labelOwnership, m+cardW+gap, 198, cardW, 82)
	move(labelWorkspace, m, 292, content, 66)
	move(labelChecked, m, 366, cardW, 44)
	move(actionLabel, m+cardW+gap, 366, cardW, 58)

	settingsY := int32(438)
	toggleW := (content - 3*gap) / 4
	toggleH := int32(42)
	toggles := []syscall.Handle{buttonAutostart, buttonAutoOpen, buttonTrayMode, buttonQuit}
	for i, b := range toggles {
		move(b, m+int32(i)*(toggleW+gap), settingsY, toggleW, toggleH)
	}

	controlY := int32(494)
	controlW := (content - 5*gap) / 6
	controlH := int32(46)
	buttons := []syscall.Handle{buttonStart, buttonStop, buttonRestart, buttonOpenUI, buttonTest, buttonJournal}
	for i, b := range buttons {
		move(b, m+int32(i)*(controlW+gap), controlY, controlW, controlH)
	}

	move(logTitle, m, 554, content, 28)
	footerH := int32(50)
	folderW := int32(220)
	logY := int32(588)
	logH := h - logY - footerH - 18
	if logH < 100 {
		logH = 100
	}
	move(logBox, m, logY, content, logH)
	fy := logY + logH + 10
	move(buttonFolder, m, fy, folderW, 38)
	move(footerLabel, m+folderW+gap, fy, content-folderW-gap, 42)
}

func wndProc(hwnd syscall.Handle, message uint32, wParam, lParam uintptr) uintptr {
	switch message {
	case WM_SIZE:
		layoutControls(hwnd)
		return 0
	case WM_COMMAND:
		buttonAction(loword(wParam))
		return 0
	case WM_TIMER:
		refreshAsync()
		return 0
	case WM_STATUS:
		applyStatus()
		return 0
	case WM_TRAY:
		event := uint32(lParam & 0xffff)
		if event == WM_LBUTTONUP || event == WM_LBUTTONDBLCLK || event == WM_RBUTTONUP {
			restoreFromTray()
		}
		return 0
	case WM_ACTION_DONE:
		stateMu.Lock()
		r := pendingResult
		latestStatus = r.snapshot
		if r.errText != "" {
			lastAction = r.action + " · ÉCHEC · " + r.errText
			appendLauncherLog(lastAction)
		} else if r.message != "" {
			lastAction = r.message
			appendLauncherLog(r.message)
		} else {
			lastAction = r.action + " terminé"
		}
		stateMu.Unlock()
		actionBusy.Store(false)
		applyStatus()
		return 0
	case WM_DRAWITEM:
		if lParam != 0 {
			drawButton((*drawItemStruct)(unsafe.Pointer(lParam)))
			return 1
		}
	case WM_CTLCOLORSTATIC:
		hdc := syscall.Handle(wParam)
		child := syscall.Handle(lParam)
		procSetBkMode.Call(uintptr(hdc), TRANSPARENT)
		if cardControls[child] {
			procSetTextColor.Call(uintptr(hdc), colorText)
			procSetBkColor.Call(uintptr(hdc), colorCard)
			return uintptr(brushCard)
		}
		procSetTextColor.Call(uintptr(hdc), colorText)
		procSetBkColor.Call(uintptr(hdc), colorBG)
		return uintptr(brushBG)
	case WM_CTLCOLOREDIT:
		hdc := syscall.Handle(wParam)
		procSetTextColor.Call(uintptr(hdc), colorText)
		procSetBkColor.Call(uintptr(hdc), colorPanel)
		return uintptr(brushPanel)
	case WM_CLOSE:
		set := settingsSnapshot()
		if set.MinimizeToTray && !exiting.Load() {
			if addTrayIcon() {
				procShowWindow.Call(uintptr(hwnd), SW_HIDE)
				stateMu.Lock()
				lastAction = "Control Center réduit dans la zone de notification"
				stateMu.Unlock()
				appendLauncherLog("Control Center réduit dans la zone de notification.")
				return 0
			}
		}
		requestRealExit()
		return 0
	case WM_DESTROY:
		removeTrayIcon()
		mainWindow = 0
		procPostQuitMessage.Call(0)
		return 0
	}
	ret, _, _ := procDefWindowProcW.Call(uintptr(hwnd), uintptr(message), wParam, lParam)
	return ret
}
func buildUI(hwnd syscall.Handle) {
	fontTitle = createFont(-30, 700, "Segoe UI")
	fontSubtitle = createFont(-17, 400, "Segoe UI")
	fontCard = createFont(-19, 600, "Segoe UI")
	fontButton = createFont(-17, 600, "Segoe UI")
	fontLog = createFont(-16, 400, "Consolas")
	fontFooter = createFont(-15, 400, "Segoe UI")
	brushBG = syscall.Handle(mustBrush(colorBG))
	brushPanel = syscall.Handle(mustBrush(colorPanel))
	brushCard = syscall.Handle(mustBrush(colorCard))

	titleLabel = createControl("STATIC", "ATLAS-10 CRYPTO BRIDGE · CONTROL CENTER", WS_CHILD|WS_VISIBLE, hwnd, 0, fontTitle)
	subtitleLabel = createControl("STATIC", "Ryzen local · Atlas/Aerith · pilotage quotidien · Bridge V1.7.6", WS_CHILD|WS_VISIBLE, hwnd, 0, fontSubtitle)
	labelBridge = createControl("STATIC", "BRIDGE\r\n● Vérification…", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontCard)
	registerCard(labelBridge)
	labelOllama = createControl("STATIC", "OLLAMA\r\n● Vérification…", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontCard)
	registerCard(labelOllama)
	labelModel = createControl("STATIC", "MODÈLE\r\nllama3.2", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontCard)
	registerCard(labelModel)
	labelOwnership = createControl("STATIC", "PILOTAGE\r\nDétection…", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontCard)
	registerCard(labelOwnership)
	labelWorkspace = createControl("STATIC", "DOSSIER TECHNIQUE\r\nPréparation…", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontSubtitle)
	registerCard(labelWorkspace)
	labelChecked = createControl("STATIC", "Dernier contrôle : —", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontSubtitle)
	registerCard(labelChecked)
	actionLabel = createControl("STATIC", "DERNIÈRE ACTION\r\nInitialisation…", WS_CHILD|WS_VISIBLE|WS_BORDER, hwnd, 0, fontSubtitle)
	registerCard(actionLabel)

	buttonStart = createControl("BUTTON", "Démarrer", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_START, fontButton)
	buttonStop = createControl("BUTTON", "Arrêter", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_STOP, fontButton)
	buttonRestart = createControl("BUTTON", "Redémarrer", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_RESTART, fontButton)
	buttonOpenUI = createControl("BUTTON", "Ouvrir Interface", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_OPEN_UI, fontButton)
	buttonTest = createControl("BUTTON", "Tester", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_TEST, fontButton)
	buttonJournal = createControl("BUTTON", "Journal", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_OPEN_LOGS, fontButton)
	buttonFolder = createControl("BUTTON", "Dossier technique", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_OPEN_FOLDER, fontButton)
	buttonAutostart = createControl("BUTTON", "Démarrage Windows : NON", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_AUTOSTART, fontButton)
	buttonAutoOpen = createControl("BUTTON", "Interface auto : NON", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_AUTO_OPEN, fontButton)
	buttonTrayMode = createControl("BUTTON", "Zone notification : NON", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_TRAY_MODE, fontButton)
	buttonQuit = createControl("BUTTON", "Quitter Control Center", WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_OWNERDRAW, hwnd, ID_QUIT, fontButton)
	buttonHandles = []syscall.Handle{buttonStart, buttonStop, buttonRestart, buttonOpenUI, buttonTest, buttonJournal, buttonFolder, buttonAutostart, buttonAutoOpen, buttonTrayMode, buttonQuit}

	logTitle = createControl("STATIC", "JOURNAL INTÉGRÉ · pilotage quotidien · aucune popup", WS_CHILD|WS_VISIBLE, hwnd, 0, fontSubtitle)
	logBox = createControl("EDIT", "Journal prêt.", WS_CHILD|WS_VISIBLE|WS_BORDER|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY|ES_NOHIDESEL, hwnd, 0, fontLog)
	procSendMessageW.Call(uintptr(logBox), EM_SETBKGNDCOLOR, 0, colorPanel)
	footerLabel = createControl("STATIC", "Interface Agent-Crypto Build 28.2.72", WS_CHILD|WS_VISIBLE, hwnd, 0, fontFooter)
	layoutControls(hwnd)
}
func mustBrush(color uintptr) uintptr { h, _, _ := procCreateSolidBrush.Call(color); return h }
func acquireSingleInstance() bool {
	handle, _, _ := procCreateMutexW.Call(0, 1, uintptr(unsafe.Pointer(utf16Ptr("Local\\ERITH_ATLAS_CRYPTO_BRIDGE_DESKTOP_V210"))))
	if handle == 0 {
		return true
	}
	appMutex = syscall.Handle(handle)
	if errno, ok := syscall.GetLastError().(syscall.Errno); ok && errno == 183 {
		return false
	}
	return true
}
func runGUI() error {
	procSetProcessDPIAware.Call()
	instance, _, _ := procGetModuleHandleW.Call(0)
	cursor, _, _ := procLoadCursorW.Call(0, IDC_ARROW)
	brushBG = syscall.Handle(mustBrush(colorBG))
	className := utf16Ptr(windowClass)
	class := wndClassEx{CbSize: uint32(unsafe.Sizeof(wndClassEx{})), LpfnWndProc: syscall.NewCallback(wndProc), HInstance: syscall.Handle(instance), HCursor: syscall.Handle(cursor), HbrBackground: brushBG, LpszClassName: className}
	atom, _, err := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&class)))
	if atom == 0 {
		return fmt.Errorf("RegisterClassExW: %v", err)
	}
	width, height := 1120, 860
	screenW, _, _ := procGetSystemMetrics.Call(0)
	screenH, _, _ := procGetSystemMetrics.Call(1)
	x := int32((int(screenW) - width) / 2)
	y := int32((int(screenH) - height) / 2)
	if x < 0 {
		x = 0
	}
	if y < 0 {
		y = 0
	}
	style := WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN
	hwnd, _, err := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(utf16Ptr(windowTitle))), uintptr(style), uintptr(x), uintptr(y), uintptr(width), uintptr(height), 0, 0, instance, 0)
	if hwnd == 0 {
		return fmt.Errorf("CreateWindowExW: %v", err)
	}
	mainWindow = syscall.Handle(hwnd)
	dark := int32(1)
	procDwmSetWindowAttribute.Call(hwnd, 20, uintptr(unsafe.Pointer(&dark)), unsafe.Sizeof(dark))
	buildUI(mainWindow)
	if settingsSnapshot().MinimizeToTray {
		addTrayIcon()
	}
	procShowWindow.Call(hwnd, SW_SHOW)
	procUpdateWindow.Call(hwnd)
	procSetTimer.Call(hwnd, 1, 5000, 0)
	refreshAsync()
	go func() {
		time.Sleep(400 * time.Millisecond)
		if !isBridgeHealthy() {
			msg, err := startBridge()
			if err != nil {
				appendLauncherLog("Démarrage automatique impossible: " + err.Error())
				stateMu.Lock()
				lastAction = "Démarrage automatique · ÉCHEC · " + err.Error()
				stateMu.Unlock()
			} else {
				stateMu.Lock()
				lastAction = msg
				stateMu.Unlock()
			}
		}
		if settingsSnapshot().AutoOpenInterface {
			time.Sleep(350 * time.Millisecond)
			shellOpen(interfaceURL)
			stateMu.Lock()
			lastAction = "Interface Agent-Crypto ouverte automatiquement"
			stateMu.Unlock()
			appendLauncherLog("Interface Agent-Crypto ouverte automatiquement.")
		}
		refreshAsync()
	}()
	var message msg
	for {
		result, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&message)), 0, 0, 0)
		if int32(result) == -1 {
			return fmt.Errorf("GetMessageW a échoué")
		}
		if result == 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&message)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&message)))
	}
	return nil
}
func main() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	if !acquireSingleInstance() {
		return
	}
	if appMutex != 0 {
		defer procCloseHandle.Call(uintptr(appMutex))
	}
	if err := resolveWorkspace(); err != nil {
		_ = os.WriteFile(filepath.Join(os.TempDir(), "atlas_bridge_startup_error.txt"), []byte(err.Error()), 0o644)
		return
	}
	loadSettings()
	appendLauncherLog("Atlas-10 Crypto Bridge Control Center V" + appVersion + " démarré · pilotage quotidien prêt.")
	if err := runGUI(); err != nil {
		appendLauncherLog("Erreur GUI: " + err.Error())
	}
}
