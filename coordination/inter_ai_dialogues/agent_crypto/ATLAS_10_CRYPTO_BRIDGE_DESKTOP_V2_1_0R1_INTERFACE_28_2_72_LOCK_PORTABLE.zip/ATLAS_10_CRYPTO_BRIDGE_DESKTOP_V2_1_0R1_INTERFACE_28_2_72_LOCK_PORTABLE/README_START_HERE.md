# Atlas-10 Crypto Bridge Desktop V2.1.0R1 — Interface 28.2.72 Lock

## Base stable conservée

- Interface Agent-Crypto : Build 28.2.72
- Bridge moteur : V1.7.6, inchangé
- Control Center : V2.1.0 Daily Pilotage Lock + raccord R1
- Ollama : llama3.2
- thread graphique Win32 verrouillé avec `runtime.LockOSThread()`

## Correction R1

- ouverture de l’Interface publique actuelle Build 28.2.72
- affichage du véritable couple Control Center V2.1.0R1 / Bridge V1.7.6
- aucune route ni clé Metals.Dev
- Métaux laissés exclusivement aux archives publiques GitHub Actions
- installation isolée dans `%LOCALAPPDATA%\ERITH.IA\AtlasCryptoBridge\2.1.0R1`

## Fonctions quotidiennes préservées

- démarrage automatique du Bridge intégré lorsqu’aucun Bridge n’est actif
- protection d’un Bridge externe en lecture seule
- démarrage Windows utilisateur optionnel
- ouverture automatique de l’Interface
- zone de notification optionnelle
- fermeture du Control Center sans arrêter automatiquement le Bridge

## Test Ryzen conseillé

1. Fermer les anciens Control Centers.
2. Lancer `AtlasCryptoBridgeControlCenter.exe`.
3. Vérifier Bridge V1.7.6 et Ollama llama3.2.
4. Cliquer sur `Ouvrir Interface`.
5. Dans Administration, lancer `Tester le Bridge local`.
6. Vérifier `Production locale` et les quatre rapports Atlas.
7. Vérifier qu’aucun panneau Metals.Dev n’existe dans le Control Center.

## Sécurité

- écoute locale `127.0.0.1:8787`
- aucun wallet
- aucune action exchange
- aucune écriture GitHub
- aucun jeton
- aucune clé fournisseur Métaux
- aucun arrêt d’un Bridge externe
