# Architecture — Control Center V2.1.0R1

```text
AtlasCryptoBridgeControlCenter.exe
├── GUI Win32 sombre et redimensionnable
├── thread UI verrouillé
├── contrôles réseau asynchrones
├── paramètres JSON locaux
├── démarrage utilisateur Windows optionnel
├── icône de zone de notification optionnelle
├── lancement du Bridge Crypto V1.7.6 si absent
└── ouverture de l’Interface publique Build 28.2.72

bridge/
├── bridge.py V1.7.6 — inchangé
├── bridge_config.json — lecture seule
└── profiles Atlas/Aerith
```

## Limite volontaire

Aucune route Métaux locale. Aucune dépendance Metals.Dev. Les Métaux restent servis par l’archive publique GitHub Actions.

## Fichier de paramètres

Installation autonome :

`%LOCALAPPDATA%\ERITH.IA\AtlasCryptoBridge\2.1.0R1\control_center_settings.json`

Dossier portable :

`control_center_settings.json` à côté de l’EXE.
