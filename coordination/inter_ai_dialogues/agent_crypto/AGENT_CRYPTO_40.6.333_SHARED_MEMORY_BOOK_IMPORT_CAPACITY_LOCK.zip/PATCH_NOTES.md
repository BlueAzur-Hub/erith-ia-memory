# Agent-Crypto 40.6.333 — Shared Memory Book Import Capacity Lock

This is a PATCH archive. The 3.3 MB canonical administrator/app.js is intentionally represented by PATCH_APP_JS_406333.diff plus the functional commit SHA, while the smaller changed files are included in full.

Terrain condition:
- Ryzen panel: 483 source records / 482 canonical snapshots
- Transformer Book export: 230 records / 230 canonical snapshots
- 40.6.332 refused correctly before mutation because the primary cap was 500.

40.6.333:
- primary bounded capacity 500 → 1024;
- worst-case current union 713, leaving 311 headroom;
- canonical identity remains collector_id + market_snapshot_id;
- preflight now protects existing + incoming identities;
- any future eviction attempt still fails before mutation;
- persistence, reread verification and rollback remain mandatory.

Deferred validation:
import Book → reimport identical = 0 new → reload → both collectors persist.
