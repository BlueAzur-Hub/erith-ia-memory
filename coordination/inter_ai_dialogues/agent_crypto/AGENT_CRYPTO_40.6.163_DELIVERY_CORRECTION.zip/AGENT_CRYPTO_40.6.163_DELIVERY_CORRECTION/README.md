# 40.6.163 delivery correction

Corrected release-entry HTML. Do not re-import the earlier ZIP entry reported invalid by Astra. GitHub main already contains the corrected executable entry.
