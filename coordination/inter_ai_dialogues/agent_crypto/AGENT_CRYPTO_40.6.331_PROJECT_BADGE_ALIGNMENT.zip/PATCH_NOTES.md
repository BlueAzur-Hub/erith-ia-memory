# Agent-Crypto 40.6.331 — Project Badge Alignment

Scope: Missions de vie collapsed project summaries only.

Root cause:
The zero-size lazy routing anchor remained a CSS Grid item and consumed the fourth grid cell, pushing the existing PROGRAMME / MISSION ::after badge into an implicit second row.

Correction:
- keep the lazy routing anchor in the DOM;
- remove that zero-size anchor from grid flow;
- pin the existing badge to its intended grid cell;
- preserve responsive alignment.

Protected:
Market Core 38.15.11, Aether 40.6.322 behavior/geometry, Strategy A, Gates, Storage, Security, project content, routing and lazy hydration.

Local Chromium geometry proof:
- before: summary 84 px, badge auto-placement;
- after desktop: summary 64 px, badge column 4 / row 1 / centered;
- responsive: badge column 3, spanning the two text rows.

Firefox operator terrain validation remains required.
