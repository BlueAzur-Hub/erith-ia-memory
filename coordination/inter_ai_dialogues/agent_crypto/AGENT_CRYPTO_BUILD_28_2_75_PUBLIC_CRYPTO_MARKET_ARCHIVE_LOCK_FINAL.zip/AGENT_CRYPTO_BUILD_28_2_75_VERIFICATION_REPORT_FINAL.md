# AGENT-CRYPTO — BUILD 28.2.75

## PUBLIC CRYPTO MARKET ARCHIVE LOCK — RAPPORT DE VÉRIFICATION FINAL

### 1. Identité

- Build : **28.2.75**
- Base exacte : **Build 28.2.74**
- Archive de base SHA-256 : `3c953de2f28eea3e9de3ea7f05e971a919ac176d54030217b189802cfb890eac`
- Portée : récupération du marché Crypto Top 250, conversion USD→EUR, vérité des sources et continuité publique.
- GitHub : **aucune écriture effectuée par l’assistant**.

### 2. Problème corrigé

Le navigateur Firefox ne parvient pas à exploiter les appels directs CoinGecko Top 250, en EUR comme en USD. Le Build 28.2.74 ajoutait un secours USD→EUR dans le navigateur, mais les captures réelles ont confirmé que ce second appel direct échouait lui aussi.

Le Build 28.2.75 retire donc la collecte principale Top 250 du navigateur :

1. GitHub Actions collecte CoinGecko Top 250 en USD ;
2. le collecteur applique le taux public BCE USD/EUR déjà utilisé par le domaine Métaux ;
3. GitHub Actions publie `data/crypto/latest.json` ;
4. Firefox lit ce JSON statique public ;
5. le cache navigateur n’est utilisé qu’en dernier recours.

### 3. Contrat de données

Le snapshot public utilise le schéma `agent_crypto_public_market_snapshot_v1`.

Valeurs monétaires converties avec un seul taux BCE :

- prix actuel ;
- plus haut et plus bas sur 24 heures ;
- capitalisation ;
- volume sur 24 heures ;
- totaux Top 250.

Les valeurs USD originales sont conservées. Les variations 1 h, 24 h, 7 j et 30 j restent celles de CoinGecko en base USD et sont identifiées comme telles.

### 4. Fraîcheur et continuité

- collecte planifiée : toutes les **2 heures** ;
- Decision Board actif : snapshot public âgé de **3 heures maximum** ;
- consultation possible : snapshot âgé de **24 heures maximum** ;
- au-delà de 24 heures : snapshot rejeté ;
- échec de collecte : le dernier `latest.json` valide n’est pas écrasé ;
- l’exécution GitHub Actions passe en échec visible lorsque seule une ancienne copie a pu être préservée.

### 5. Fichiers modifiés ou ajoutés

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
public/agent_crypto_erith_ia/tools/collect_public_crypto.py
public/agent_crypto_erith_ia/data/crypto/status.json
.github/workflows/atlas-public-crypto-market.yml
```

Fichier généré après la première exécution GitHub Actions réussie :

```text
public/agent_crypto_erith_ia/data/crypto/latest.json
```

Aucun `latest.json` artificiel n’est livré dans le ZIP.

### 6. Vérifications automatisées

- Contrôles statiques et cohérence : **51/51** ;
- Tests du collecteur et du contrat workflow : **15/15** ;
- Tests du normaliseur JavaScript public : **7/7** ;
- Total : **73/73 contrôles validés**.

Contrôles principaux validés :

- syntaxe JavaScript avec `node --check` ;
- syntaxe Python avec `py_compile` ;
- syntaxe YAML du workflow ;
- cohérence Build/token 28.2.75 ;
- chargeur actif basé sur le JSON public ;
- absence d’appel direct EUR ou USD Top 250 dans `runLivecheck()` ;
- conversion testée : `1001 USD × 0,8 = 800,8 EUR` ;
- conservation des prix USD originaux ;
- invariants prix, capitalisation et volume ;
- rejet d’un snapshot public de plus de 24 heures ;
- préservation octet pour octet du dernier snapshot valide lors d’un échec simulé ;
- schéma et provenance du snapshot ;
- absence de secret ayant la forme d’un jeton public ;
- ensemble des 674 identifiants DOM inchangé ;
- nombre de sections HTML inchangé ;
- CSS 28.2.74 conservé intégralement, avec métadonnées 28.2.75 ajoutées seulement ;
- aucune modification du collecteur Métaux, des données Métaux ou du Bridge.

### 7. Limites de validation

Ces points ne peuvent être déclarés validés avant publication :

- réponse réelle de CoinGecko depuis l’IP GitHub Actions ;
- récupération réelle du taux BCE par le secours du collecteur si le fichier Métaux est absent ou trop ancien ;
- permission réelle du workflow pour pousser `data/crypto/` dans le dépôt ;
- génération du premier `latest.json` public ;
- lecture réelle du JSON publié dans Firefox sur le Ryzen.

Le Build est donc **techniquement vérifié et prêt à publier**, mais son objectif réseau devient **validé opérationnellement seulement après la première exécution GitHub Actions réussie et le contrôle Firefox**.

### 8. Éléments préservés

- formule de l’indice de veille Atlas ;
- seuils de mouvements et d’anomalies ;
- Watchlist ;
- News Sentinel ;
- Math Core Crypto et Métaux ;
- graphiques Binance et historiques CoinGecko à la demande ;
- interface Métaux et collecteur Métaux ;
- Control Center V2.1.0R1 ;
- Bridge V1.7.6 ;
- géométrie et identifiants de l’interface.
