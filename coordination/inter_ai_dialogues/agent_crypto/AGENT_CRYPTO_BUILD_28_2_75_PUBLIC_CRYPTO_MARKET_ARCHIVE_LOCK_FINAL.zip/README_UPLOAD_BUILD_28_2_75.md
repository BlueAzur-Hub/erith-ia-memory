# Agent-Crypto — installation du Build 28.2.75

## Fichiers à remplacer ou ajouter

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
public/agent_crypto_erith_ia/tools/collect_public_crypto.py
public/agent_crypto_erith_ia/data/crypto/status.json
.github/workflows/atlas-public-crypto-market.yml
```

## Première activation obligatoire

Le ZIP ne contient volontairement aucun `data/crypto/latest.json` fabriqué.

1. Remplacer ou ajouter les sept fichiers ci-dessus.
2. Effectuer le commit GitHub avec le texte livré.
3. Le changement du collecteur ou du workflow doit lancer automatiquement **Atlas Public Crypto Market**.
4. En cas de non-déclenchement : ouvrir **Actions → Atlas Public Crypto Market → Run workflow**.
5. Attendre le commit automatique :

```text
archive public crypto market snapshot
```

6. Vérifier l’apparition de :

```text
public/agent_crypto_erith_ia/data/crypto/latest.json
```

7. Recharger la page dans Firefox avec `Ctrl+F5`.

## État attendu après réussite

```text
Marché public N/250
CoinGecko USD · GitHub Actions · conversion BCE EUR
Snapshot public CoinGecko récent
```

Le Decision Board doit quitter `Archive · consultation` lorsque le snapshot public a moins de trois heures et contient au moins quarante actifs valides.

## Avant la première réussite

Tant que GitHub Actions n’a pas généré `latest.json`, l’interface peut encore utiliser la dernière lecture du cache navigateur ou rester en consultation archivée. Ce comportement est normal pour la première activation.

## En cas d’échec du workflow

- consulter les logs du job `collect` ;
- ne pas supprimer manuellement un ancien `latest.json` valide ;
- le collecteur conserve la dernière copie valide et écrit un état `degraded` ;
- l’exécution reste rouge pour rendre l’échec visible.

Aucune clé API n’est nécessaire. Le workflow ne doit écrire que dans `public/agent_crypto_erith_ia/data/crypto/`.
