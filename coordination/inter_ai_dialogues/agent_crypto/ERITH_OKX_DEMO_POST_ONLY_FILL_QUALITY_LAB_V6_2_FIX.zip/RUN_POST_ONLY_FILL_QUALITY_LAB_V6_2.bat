@echo off
setlocal
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY FILL QUALITY LAB V6.2

echo ============================================================
echo ERITH - OKX DEMO - POST-ONLY FILL QUALITY LAB V6.2
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  set "PY=python"
) else (
  set "PY=py -3"
)

%PY% -c "import websocket; print('[OK] websocket-client', websocket.__version__)"
if errorlevel 1 (
  echo [SETUP] Installation de websocket-client...
  %PY% -m pip install --user websocket-client
  if errorlevel 1 (
    echo [ERREUR] Installation websocket-client impossible.
    pause
    exit /b 1
  )
  %PY% -c "import websocket; print('[OK] websocket-client', websocket.__version__)"
  if errorlevel 1 (
    echo [ERREUR] websocket-client installe mais import impossible.
    pause
    exit /b 1
  )
)

echo [START] Lancement V6.2...
%PY% "%~dp0POST_ONLY_FILL_QUALITY_LAB_V6_2.py"
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" echo [FIN] V6.2 termine avec code %RC%.
pause
exit /b %RC%
