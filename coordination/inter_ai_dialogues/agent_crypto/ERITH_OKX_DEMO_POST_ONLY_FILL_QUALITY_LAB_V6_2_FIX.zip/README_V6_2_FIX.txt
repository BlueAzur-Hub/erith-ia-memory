ERITH · PATCH V6.2

Correction :
- OKX refuse l'identifiant WebSocket "ERITH-V6".
- La documentation OKX impose un id composé uniquement de lettres et chiffres,
  de 1 à 32 caractères.
- V6.2 utilise donc "ERITHV6".

Le Bridge 8791, la clé Demo, les frais et la logique de trading ne changent pas.

Copier ces 2 fichiers dans :
C:\ERITH\okx-demo-bridge\

Puis lancer :
RUN_POST_ONLY_FILL_QUALITY_LAB_V6_2.bat
