# Agent-Crypto 40.6.320 — Aether left without top pin

Functional commit: 0582ca2d65daea276bad5eb5d24a8436e9c036f9

Correction:
- restore the historical 40.6.305 vertical lane for polluted y≈12 state;
- force x=12 on the actual restored Aether state;
- preserve current width and height exactly;
- retire the 40.6.317 Aether aspect-ratio geometry policy and its pre-init size normalizer;
- no CSS enlargement, no Lecture Technique change, no Market Core change.

Terrain target:
- normal Firefox: Aether left, lower than the navigation, same operator size;
- F11 remains temporary browser fullscreen behavior.
