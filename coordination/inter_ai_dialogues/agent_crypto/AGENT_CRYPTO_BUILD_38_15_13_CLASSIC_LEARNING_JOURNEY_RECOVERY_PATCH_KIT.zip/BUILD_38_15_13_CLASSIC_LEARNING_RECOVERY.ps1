param(
  [string]$RepoRoot = "",
  [string]$OutputRoot = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Build = "38.15.13"
$ParentBuild = "38.15.12"
$Release = "Market Core V2.0-Alpha · Build 38.15.13 · CLASSIC LEARNING JOURNEY 01→11 PRESENTATION RECOVERY LOCK"
$Token = "market-core-v2.0-alpha-build-38.15.13"
$Repo = "BlueAzur-Hub/erith-ia-memory"
$WebRel = "public/agent_crypto_erith_ia/web"
$RawBase = "https://raw.githubusercontent.com/$Repo/main/$WebRel"

$ExpectedSha = @{
  "index.html" = "9ff8a4c833aacf88d34e9725c51213f49e34736d9717f0e08c09696888dbffde"
  "app.js" = "01dbca56e9b8e4b23da7925e23f295d9b13dedfb230ba9ad5ee2a3c679f86aea"
  "style.css" = "0c76e3db53c583b5bdfeedd280e00672b968ae97c16091aa8603c3b8ec7f7aa0"
}

$LearningFragment = @'
      <!-- ============================================================
           38.15.13 — CLASSIC LEARNING JOURNEY 01→11 PRESENTATION RECOVERY
           Classic cockpit presentation restored from validated 28.3.x lineage and Administrator 40.4.22 presentation proof.
           Runtime / IndexedDB / learning engines remain owned by app.js.
           ============================================================ -->
      <section class="learning-exercise-guide" id="learningExerciseGuide" hidden aria-live="polite">
        <div class="learning-exercise-guide-copy">
          <p class="learning-breadcrumb" id="learningExerciseBreadcrumb">Cockpit › Module › Exercice</p>
          <b id="learningExerciseGuideTitle">Exercice guidé</b>
          <span id="learningExerciseGuideText">Le cockpit indiquera ici la mission exacte.</span>
        </div>
        <div class="learning-exercise-guide-actions">
          <button class="btn small primary" id="btnLearningExerciseGuidePrimary" type="button">Exercice terminé</button>
          <button class="btn small" id="btnLearningExerciseBack" type="button">Retour à ma session guidée</button>
        </div>
      </section>

      <section class="learning-journey-cockpit" id="learningJourneyCockpit" aria-labelledby="learningCockpitTitle">
        <div class="learning-cockpit-head">
          <div>
            <p class="eyebrow">☉ COCKPIT D’APPRENTISSAGE · ARGENT 100 % FICTIF</p>
            <h3 id="learningCockpitTitle">Prochaine étape</h3>
            <p>Le cockpit relie ton parcours expert, la simulation, les frais et le journal. Il ne donne aucun conseil d’achat et ne peut déclencher aucune opération réelle.</p>
          </div>
          <span class="pill ok" id="learningCockpitStatus">Session prête</span>
        </div>

        <div class="learning-cockpit-summary" aria-label="État actuel de l’apprentissage">
          <article><b>Profil fictif actif</b><span id="learningCockpitProfile">Progression 1 000 €</span><em id="learningCockpitCapital">1 000 € virtuels</em></article>
          <article><b>Progression 24 mois</b><span id="learningCockpitProgress">0 %</span><em id="learningCockpitModules">0/11 modules découverts</em></article>
          <article><b>Portefeuille école</b><span id="learningCockpitPortfolio">Aucune position</span><em id="learningCockpitExposure">0 € exposé</em></article>
          <article><b>Dernière preuve</b><span id="learningCockpitLastProof">Aucune simulation</span><em id="learningCockpitLastProofTime">Journal local vide</em></article>
        </div>

        <div class="learning-cockpit-focus">
          <div class="learning-cockpit-focus-copy">
            <p class="eyebrow">PROCHAINE ÉTAPE PERSONNELLE</p>
            <h4 id="learningCockpitModule">01 · Marché et données</h4>
            <p id="learningCockpitGoal">Commencer par lire les prix, les variations, le volume et la fraîcheur des sources.</p>
            <div class="learning-cockpit-tags">
              <span id="learningCockpitModuleState">À découvrir</span>
              <span id="learningCockpitDuration">Session 15 min</span>
              <span id="learningCockpitRisk">Aucun argent réel</span>
            </div>
          </div>
          <div class="learning-help-setting">
            <label for="learningHelpMode">Niveau des aides ⓘ</label>
            <select id="learningHelpMode">
              <option value="off">Désactivées</option>
              <option value="short" selected>Courtes</option>
              <option value="detailed">Détaillées</option>
            </select>
            <span id="learningHelpModeHint">Définition et valeur actuelle, sans panneau long.</span>
          </div>
        </div>

        <section class="learning-primary-action" id="learningPrimaryActionPanel" data-state="read" aria-labelledby="learningPrimaryActionTitle">
          <div class="learning-primary-action-copy">
            <p class="learning-breadcrumb" id="learningBreadcrumb">Cockpit › Module 01 › Étape 1</p>
            <span class="learning-primary-step" id="learningPrimaryStep">Étape 1/5</span>
            <h4 id="learningPrimaryActionTitle">1. Comprendre les valeurs du marché</h4>
            <p id="learningPrimaryActionText">Le cockpit affiche une seule action principale à la fois.</p>
          </div>
          <button class="btn primary learning-primary-button" id="btnLearningPrimaryAction" type="button" data-action="read">Ouvrir la leçon du Module 01</button>
        </section>

        <section class="learning-completion-panel" id="learningCompletionPanel" hidden aria-labelledby="learningCompletionTitle">
          <div class="learning-completion-head">
            <div>
              <p class="eyebrow">✓ SESSION TERMINÉE ET ARCHIVÉE</p>
              <h4 id="learningCompletionTitle">Module terminé</h4>
              <p id="learningCompletionDate">La preuve d’archivage sera affichée ici.</p>
            </div>
            <span class="pill ok" id="learningCompletionBadge">5/5 étapes</span>
          </div>
          <div class="learning-completion-grid">
            <article><b>Étapes</b><span id="learningCompletionSteps">5/5</span><em>Session complète</em></article>
            <article><b>Notes conservées</b><span id="learningCompletionNotes">0 caractère</span><em>IndexedDB</em></article>
            <article><b>Conclusion conservée</b><span id="learningCompletionTakeaway">0 caractère</span><em>IndexedDB</em></article>
            <article><b>Progression</b><span id="learningCompletionProgress">0 %</span><em id="learningCompletionSessions">0 session archivée</em></article>
          </div>
          <div class="learning-completion-next">
            <div><b>Étape suivante</b><span id="learningCompletionNextModule">02 · Spot et carnet d’ordres</span></div>
            <button class="btn primary" id="btnLearningNextModule" type="button">Passer au module suivant</button>
          </div>
          <div class="learning-completion-actions">
            <button class="btn small" id="btnLearningReviewCompleted" type="button">Relire cette session</button>
            <button class="btn small" id="btnLearningExportCompleted" type="button">Exporter cette session .md</button>
            <button class="btn small" id="btnLearningOpenNotebook" type="button">Voir mon carnet complet</button>
          </div>
        </section>

        <div class="learning-restart-notice" id="learningRestartNotice">
          <div>
            <b id="learningMigrationNoticeTitle">Récupération automatique de ton carnet</b>
            <span id="learningMigrationNoticeText">Aucun clic nécessaire. La copie utilise IndexedDB, même si le stockage local est plein.</span>
          </div>
          <button class="btn small" id="btnRestoreLegacyLearningRecovery" type="button" hidden>Voir le diagnostic</button>
        </div>

        <section class="learning-legacy-recovery" id="learningLegacyRecoveryPanel" aria-labelledby="learningLegacyRecoveryTitle" hidden>
          <div class="learning-legacy-recovery-head">
            <div>
              <p class="eyebrow">⟲ RÉCUPÉRATION AUTOMATIQUE ET VÉRIFIÉE</p>
              <h4 id="learningLegacyRecoveryTitle">Restaurer tes leçons précédentes</h4>
              <p>La récupération se lance automatiquement. Elle lit uniquement ce Firefox, conserve les anciennes clés, écrit le nouveau carnet puis relit chaque résultat avant d’annoncer une réussite.</p>
            </div>
            <span class="pill warn" id="learningLegacyRecoveryStatus">RÉCUPÉRATION EN COURS</span>
          </div>
          <div class="learning-legacy-recovery-summary" id="learningLegacyRecoverySummary"></div>
          <div class="learning-legacy-recovery-result" id="learningLegacyRecoveryResult" data-state="pending"></div>
          <pre class="learning-legacy-recovery-preview" id="learningLegacyRecoveryPreview" hidden></pre>
          <div class="learning-legacy-recovery-actions">
            <button class="btn small" id="btnPreviewLegacyLearning" type="button">Voir le diagnostic</button>
            <button class="btn small primary" id="btnImportLegacyLearning" type="button">Relancer uniquement en cas d’échec</button>
            <button class="btn small" id="btnIgnoreLegacyLearning" type="button">Masquer le diagnostic</button>
          </div>
          <p class="learning-legacy-truth">L’ancien champ était limité à 800 caractères. Le Build restaure tout ce qui existe encore, vérifie la progression après écriture et ne prétend jamais reconstruire les caractères déjà coupés.</p>
        </section>

        <details class="learning-lesson-panel" id="learningLessonPanel">
          <summary><span>LEÇON INTÉGRÉE AU COCKPIT</span><b id="learningLessonTitle">01 · Marché et données</b></summary>
          <div class="learning-lesson-body">
            <p class="learning-lesson-intro" id="learningLessonIntro"></p>
            <div class="learning-lesson-grid">
              <section><h5>Notions à comprendre</h5><ul id="learningLessonConcepts"></ul></section>
              <section><h5>Exemple pédagogique</h5><p id="learningLessonExample"></p></section>
              <section><h5>Données visibles dans ton interface</h5><ul id="learningLessonInterface"></ul></section>
              <section><h5>Règle de sécurité</h5><p id="learningLessonSafety"></p></section>
            </div>
            <button class="btn small primary" id="btnMarkLessonRead" type="button">Valider l’étape 1 après lecture</button>
          </div>
        </details>

        <section class="learning-foundation-panel" id="learningFoundationPanel" aria-labelledby="learningFoundationTitle">
          <header class="learning-foundation-head">
            <div>
              <p class="eyebrow">PARCOURS DÉBUTANT DÉTAILLÉ · PÉDAGOGIE 28.3.44</p>
              <h4 id="learningFoundationTitle">01 · Marché et données</h4>
              <p id="learningFoundationPromise">Chaque notion est définie avant son utilisation.</p>
            </div>
          </header>
          <div class="learning-foundation-status" id="learningFoundationStatus" aria-live="polite"></div>
          <div class="learning-foundation-route" id="learningFoundationRoute" aria-label="Ordre exact du parcours"></div>
          <div class="learning-foundation-steps" id="learningFoundationStepCards"></div>
          <section class="learning-foundation-lab" id="learningFoundationLab" aria-label="Exercice pédagogique du module"></section>
        </section>

        <div class="learning-session-plan" id="learningSessionPlan">
          <div class="learning-session-plan-head">
            <div><b id="learningSessionTitle">Session du jour</b><span id="learningSessionProgress">0/5 étapes</span></div>
            <button class="btn small danger" id="btnResetLearningJourney" type="button" aria-label="Repartir de zéro uniquement dans Agent-Crypto" title="Réinitialise uniquement le parcours Agent-Crypto : progression, notes, archives pédagogiques et simulations fictives. Market, Métaux, Bridge et réglages généraux sont conservés.">Repartir de zéro</button>
          </div>
          <div class="learning-evidence-lock" id="learningEvidenceLock" role="status" aria-live="polite">
            <b>Validation automatique par preuves</b>
            <span>Les cases ci-dessous sont des indicateurs, pas des commandes. Elles deviennent vertes uniquement après l’action exacte expliquée dans le parcours.</span>
          </div>
          <label><input type="checkbox" data-learning-step="read" /> <span><b id="learningStepReadTitle">1. Comprendre la leçon</b><em id="learningStepRead">Le contenu complet se trouve juste au-dessus, dans l’interface.</em><button class="btn small learning-step-action" type="button" data-learning-step-action="read">Ouvrir cette étape</button></span></label>
          <label><input type="checkbox" data-learning-step="open" /> <span><b id="learningStepOpenTitle">2. Ouvrir le panneau exact</b><em id="learningStepOpen">Le Cockpit nomme le panneau et l’action attendue.</em><button class="btn small learning-step-action" type="button" data-learning-step-action="open">Ouvrir cette étape</button></span></label>
          <label><input type="checkbox" data-learning-step="practice" /> <span><b id="learningStepPracticeTitle">3. Faire l’exercice expliqué</b><em id="learningStepPractice">Aucun argent réel et aucun ordre externe.</em><button class="btn small learning-step-action" type="button" data-learning-step-action="practice">Ouvrir cette étape</button></span></label>
          <label><input type="checkbox" data-learning-step="verify" /> <span><b id="learningStepVerifyTitle">4. Lire le résultat expliqué</b><em id="learningStepVerify">Le résultat, son emplacement et son sens sont indiqués.</em><button class="btn small learning-step-action" type="button" data-learning-step-action="verify">Ouvrir cette étape</button></span></label>
          <label><input type="checkbox" data-learning-step="note" /> <span><b id="learningStepNoteTitle">5. Écrire ta conclusion personnelle</b><em id="learningStepNote">La conclusion est séparée de tes notes longues et elle n’est pas tronquée.</em><button class="btn small learning-step-action" type="button" data-learning-step-action="note">Ouvrir cette étape</button></span></label>
        </div>

        <div class="learning-notebook-grid" id="learningNotebookGrid">
          <section class="learning-auto-summary-panel" id="learningAutoSummaryPanel" hidden aria-labelledby="learningAutoSummaryTitle">
            <span id="learningAutoSummaryTitle">Synthèse automatique — générée à partir des preuves</span>
            <pre id="learningAutoSummaryText">La synthèse automatique apparaîtra ici lorsque les preuves du module seront validées.</pre>
            <em id="learningAutoSummaryHint">Lecture seule · aucune conclusion n’est générée sans preuve.</em>
          </section>
          <label class="learning-session-note learning-session-note-free">
            <span id="learningPersonalNotesLabel">Mes notes libres — sauvegarde automatique complète</span>
            <textarea id="learningSessionNotesFree" placeholder="Écris seulement ce que tu veux retenir, vérifier ou reformuler avec tes propres mots. La synthèse automatique reste séparée."></textarea>
            <em id="learningNotesCounter">0 caractère · sauvegarde locale complète</em>
          </label>
          <label class="learning-session-note learning-session-takeaway" id="learningTakeawayField">
            <span>Ce que je retiens — conclusion personnelle (modules concernés)</span>
            <small class="learning-conclusion-guide" id="learningConclusionGuide"><b>Modules concernés :</b> cette conclusion libre reste disponible pour les exercices qui la demandent. Le Module 01 utilise désormais une synthèse guidée et une réponse explicite.</small>
            <textarea id="learningSessionNote" placeholder="Conclusion libre utilisée par les modules qui la demandent. Elle n’est pas obligatoire dans le Module 01."></textarea>
            <em id="learningTakeawayCounter">0 caractère · sauvegarde locale complète</em>
          </label>
        </div>

        <div class="learning-session-complete-action" id="learningCompletionAction">
          <button class="btn primary" id="btnCompleteLearningSession" type="button" disabled>Terminer et archiver le module</button>
          <span id="learningCompletionActionHint">Disponible après la validation technique des 5 étapes.</span>
        </div>

        <details class="learning-secondary-actions" id="learningSecondaryActions">
          <summary>Autres actions et exports</summary>
          <div class="learning-cockpit-actions" id="learningCockpitActions">
            <button class="btn small" id="btnContinueLearning" type="button">Ouvrir la zone du module</button>
            <button class="btn small" id="btnOpenLearningPractice" type="button">Ouvrir directement l’exercice</button>
            <button class="btn small" id="btnOpenLearningProofs" type="button">Voir les preuves de simulation</button>
            <button class="btn small" id="btnExportLearningSession" type="button">Exporter cette session .md</button>
            <button class="btn small" id="btnExportLearningNotebook" type="button">Exporter mon carnet complet .md</button>
            <button class="btn small" id="btnVerifyLearningIntegrity" type="button">Vérifier l’intégrité du parcours</button>
          </div>
          <section class="learning-integrity-panel" id="learningIntegrityPanel" hidden aria-labelledby="learningIntegrityTitle">
            <header>
              <div><b id="learningIntegrityTitle">Diagnostic non destructif du carnet</b><span>Lecture IndexedDB, brouillon, archives, feuille de route et séparation de la simulation.</span></div>
              <span class="pill warn" id="learningIntegrityBadge">NON VÉRIFIÉ</span>
            </header>
            <div class="learning-integrity-summary" id="learningIntegritySummary"></div>
            <pre class="learning-integrity-details" id="learningIntegrityDetails">Aucune vérification lancée.</pre>
            <div class="learning-integrity-actions"><button class="btn small" id="btnExportLearningIntegrity" type="button" disabled>Télécharger le diagnostic JSON</button></div>
            <p>Aucune réparation automatique, aucun reset et aucun effacement ne sont exécutés par ce diagnostic.</p>
          </section>
        </details>

        <div class="learning-cockpit-reading" id="learningCockpitReading">Commence par lire la leçon intégrée. Tes notes sont sauvegardées automatiquement et intégralement dans ce navigateur.</div>
      </section>

      <section class="expert-roadmap-panel" id="expertLearningRoadmap" aria-labelledby="expertRoadmapTitle">
        <div class="expert-roadmap-head">
          <div>
            <p class="eyebrow">◇ PARCOURS EXPERT · HORIZON 24 MOIS</p>
            <h3 id="expertRoadmapTitle">Construire l’expertise sans brûler les étapes</h3>
            <p>Progression locale et personnelle. Aucun score financier, aucune compétition et aucune fonction existante retirée.</p>
          </div>
          <span class="pill ok" id="expertRoadmapBadge">0 module pratiqué</span>
        </div>
        <div class="expert-roadmap-progress" aria-label="Progression du parcours expert">
          <div><b id="expertRoadmapProgressText">0/11 modules découverts</b><span id="expertRoadmapMasteryText">0 pratiqué</span></div>
          <div class="expert-roadmap-bar"><i id="expertRoadmapProgressBar"></i></div>
        </div>
        <div class="expert-roadmap-grid" id="expertRoadmapGrid"></div>
        <div class="expert-roadmap-actions">
          <button class="btn small primary" id="btnExportExpertRoadmap" type="button">Télécharger feuille de route .md</button>
          <button class="btn small" id="btnResetExpertRoadmap" type="button">Réinitialiser seulement la feuille de route</button>
        </div>
        <p class="rule-line">Les états servent uniquement à organiser les révisions : À découvrir → Découvert → Compris → Pratiqué → À revoir.</p>
      </section>
'@

$LearningCss = @'
/* Agent-Crypto @erith.IA — Build 38.15.13 Classic
   Learning Journey 01→11 presentation recovery.
   Presentation layer only. Runtime, IndexedDB, market, Oracle, Atlas and historical canvas ownership remain unchanged. */

#learningJourneyCockpit,
#expertLearningRoadmap { color:var(--text); }

.learning-journey-cockpit {
  margin-top:14px;padding:16px;border:1px solid rgba(92,211,255,.24);border-radius:15px;
  background:radial-gradient(circle at 92% 8%,rgba(72,218,170,.10),transparent 30%),linear-gradient(145deg,rgba(6,19,34,.95),rgba(4,12,24,.94));
  box-shadow:0 18px 44px rgba(0,0,0,.18),inset 0 1px rgba(255,255,255,.03);
}
.learning-cockpit-head,.learning-cockpit-focus,.learning-session-plan-head,.learning-completion-head {
  display:flex;align-items:flex-start;justify-content:space-between;gap:16px;
}
.learning-cockpit-head h3 {margin:4px 0 7px;color:#fff0c8;font-size:19px;line-height:1.25}
.learning-cockpit-head p:not(.eyebrow) {max-width:920px;margin:0;color:#c1d2df;font-size:13px;line-height:1.62}
.learning-cockpit-summary {display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:14px}
.learning-cockpit-summary article {display:grid;gap:6px;min-height:92px;padding:13px;border:1px solid rgba(255,255,255,.10);border-radius:12px;background:rgba(255,255,255,.038)}
.learning-cockpit-summary b {color:#a8bccb;font-size:10.5px;text-transform:uppercase;letter-spacing:.08em}
.learning-cockpit-summary span {color:#f3fbff;font-size:17px;font-weight:850;line-height:1.28}
.learning-cockpit-summary em {color:#a4b8c7;font-size:12px;font-style:normal;line-height:1.48}
.learning-cockpit-focus {margin-top:12px;padding:14px;border:1px solid rgba(89,226,174,.20);border-radius:12px;background:rgba(31,105,92,.10)}
.learning-cockpit-focus-copy {min-width:0;flex:1}
.learning-cockpit-focus h4 {margin:4px 0 7px;color:#e5fff2;font-size:17px;line-height:1.3}
.learning-cockpit-focus-copy>p:not(.eyebrow) {margin:0;color:#c4d7e2;font-size:13px;line-height:1.58}
.learning-cockpit-tags {display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.learning-cockpit-tags span {padding:6px 9px;border:1px solid rgba(112,226,190,.22);border-radius:999px;background:rgba(4,16,27,.56);color:#d0f5e8;font-size:11px;font-weight:800}
.learning-help-setting {display:grid;gap:7px;min-width:230px;padding:11px;border:1px solid rgba(255,255,255,.10);border-radius:10px;background:rgba(2,9,18,.55)}
.learning-help-setting label {color:#a9bdcb;font-size:10.5px;font-weight:850;text-transform:uppercase;letter-spacing:.07em}
.learning-help-setting select {min-height:38px;border:1px solid rgba(255,255,255,.16);border-radius:9px;background:rgba(2,9,18,.9);color:#f2f9ff;padding:8px 10px;font-size:13px;font-weight:800}
.learning-help-setting span {color:#a8bccb;font-size:11.5px;line-height:1.48}

.learning-primary-action {display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:18px;margin-top:12px;padding:16px;border:1px solid rgba(83,202,255,.32);border-radius:13px;background:linear-gradient(135deg,rgba(28,104,172,.20),rgba(33,161,126,.11));box-shadow:inset 0 1px rgba(255,255,255,.04)}
.learning-primary-action[data-state="next_module"],.learning-primary-action[data-state="complete"] {border-color:rgba(76,225,158,.40);background:linear-gradient(135deg,rgba(29,137,94,.21),rgba(33,161,126,.10))}
.learning-primary-action-copy {display:grid;gap:7px;min-width:0}
.learning-breadcrumb {margin:0;color:#a8c3d5;font-size:11.5px;font-weight:850;letter-spacing:.05em;line-height:1.45}
.learning-primary-step {width:max-content;padding:5px 8px;border:1px solid rgba(98,236,255,.25);border-radius:999px;background:rgba(2,12,22,.58);color:#bdefff;font-size:11px;font-weight:900}
.learning-primary-action h4 {margin:0;color:#fff0c8;font-size:18px;line-height:1.3}
.learning-primary-action p:not(.learning-breadcrumb) {margin:0;max-width:900px;color:#c7d9e4;font-size:13px;line-height:1.62}
.learning-primary-button {min-width:260px;min-height:48px;font-size:13px;white-space:normal;text-align:center}

.learning-completion-panel {display:grid;gap:13px;margin-top:12px;padding:15px;border:1px solid rgba(71,223,145,.40);border-radius:13px;background:linear-gradient(145deg,rgba(26,118,80,.18),rgba(3,16,27,.88))}
.learning-completion-panel[hidden] {display:none}
.learning-completion-head h4 {margin:4px 0 6px;color:#e7fff3;font-size:18px}
.learning-completion-head p:not(.eyebrow) {margin:0;color:#bfd5cb;font-size:12px;line-height:1.55}
.learning-completion-grid {display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}
.learning-completion-grid article {display:grid;gap:5px;padding:11px;border:1px solid rgba(255,255,255,.09);border-radius:10px;background:rgba(2,13,22,.52)}
.learning-completion-grid b {color:#9ab9aa;font-size:10.5px;text-transform:uppercase;letter-spacing:.07em}
.learning-completion-grid span {color:#f1fff8;font-size:15px;font-weight:900}
.learning-completion-grid em {color:#91aa9d;font-size:11px;font-style:normal}
.learning-completion-next {display:flex;align-items:center;justify-content:space-between;gap:15px;padding:13px;border:1px solid rgba(255,216,130,.27);border-radius:11px;background:rgba(126,87,18,.10)}
.learning-completion-next>div {display:grid;gap:5px}
.learning-completion-next b {color:#e4c98f;font-size:10.5px;text-transform:uppercase;letter-spacing:.07em}
.learning-completion-next span {color:#fff0c8;font-weight:850}
.learning-completion-actions,.learning-cockpit-actions {display:flex;flex-wrap:wrap;gap:8px}

.learning-restart-notice {display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;column-gap:14px;row-gap:6px;margin-top:12px;padding:12px 14px;border:1px solid rgba(255,194,93,.28);border-radius:11px;background:rgba(123,82,20,.11);color:#cbd8e2;font-size:12px;line-height:1.55}
.learning-restart-notice>div {display:grid;gap:3px}
.learning-restart-notice b {color:#ffe1a6}
.learning-legacy-recovery {display:grid;gap:12px;margin-top:12px;padding:14px;border:1px solid rgba(255,194,93,.28);border-radius:12px;background:rgba(37,27,9,.35)}
.learning-legacy-recovery[hidden] {display:none}
.learning-legacy-recovery-head {display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
.learning-legacy-recovery-head h4 {margin:4px 0 6px;color:#fff0c8;font-size:17px}
.learning-legacy-recovery-head p:not(.eyebrow) {margin:0;color:#c8d5df;line-height:1.55}
.learning-legacy-recovery-summary,.learning-legacy-recovery-result {display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.learning-legacy-recovery-summary>*,.learning-legacy-recovery-result>* {padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:9px;background:rgba(2,9,18,.45)}
.learning-legacy-recovery-preview {max-height:280px;overflow:auto;padding:12px;border:1px solid rgba(255,255,255,.09);border-radius:9px;background:#04101c;color:#cfe5f2;white-space:pre-wrap}
.learning-legacy-recovery-actions {display:flex;flex-wrap:wrap;gap:8px}
.learning-legacy-truth {margin:0;padding:10px 12px;border-left:3px solid #ffbc55;border-radius:8px;background:rgba(255,188,85,.08);color:#e0d4b8;font-size:12px;line-height:1.55}

.learning-lesson-panel {margin-top:12px;border:1px solid rgba(88,210,255,.22);border-radius:13px;background:rgba(3,14,26,.72);overflow:hidden}
.learning-lesson-panel summary {display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 16px;cursor:pointer;list-style:none;background:rgba(67,178,219,.08)}
.learning-lesson-panel summary::-webkit-details-marker {display:none}
.learning-lesson-panel summary span {color:#add1e8;font-size:11px;font-weight:900;letter-spacing:.14em}
.learning-lesson-panel summary b {color:#fff0c8;font-size:14px;text-align:right}
.learning-lesson-body {display:grid;gap:14px;padding:16px}
.learning-lesson-intro {margin:0;padding:13px 14px;border-left:3px solid #45dfa0;border-radius:8px;background:rgba(69,223,160,.07);color:#e0edf4;font-size:13.5px;line-height:1.68}
.learning-lesson-grid {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}
.learning-lesson-grid section {min-width:0;padding:14px;border:1px solid rgba(255,255,255,.09);border-radius:11px;background:rgba(255,255,255,.028)}
.learning-lesson-grid h5 {margin:0 0 9px;color:#ffe7ac;font-size:13.5px}
.learning-lesson-grid p,.learning-lesson-grid li {color:#c8d8e3;font-size:13px;line-height:1.64}
.learning-lesson-grid p {margin:0}
.learning-lesson-grid ul {display:grid;gap:7px;margin:0;padding-left:20px}

.learning-foundation-panel {grid-column:1/-1;margin:18px 0;padding:18px;border:1px solid rgba(94,223,220,.34);border-radius:18px;background:linear-gradient(145deg,rgba(7,31,43,.96),rgba(8,23,36,.96));box-shadow:inset 0 1px 0 rgba(255,255,255,.045),0 18px 38px rgba(0,0,0,.18)}
.learning-foundation-head {display:flex;align-items:flex-start;justify-content:space-between;gap:16px}
.learning-foundation-head h4 {margin:4px 0 6px;font-size:20px;line-height:1.25;color:#f3fbff}
.learning-foundation-head p:not(.eyebrow) {margin:0;max-width:820px;color:rgba(218,239,249,.83);font-size:14px;line-height:1.55}
.learning-foundation-status {display:flex;gap:10px;align-items:flex-start;margin:14px 0;padding:12px 14px;border-radius:12px;background:rgba(21,60,71,.46);color:rgba(221,243,250,.88)}
.learning-foundation-status b {flex:0 0 auto;color:#7fe8df;font-size:13px}
.learning-foundation-status span {font-size:13px;line-height:1.5}
.learning-foundation-route {display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin:14px 0 18px}
.learning-foundation-route span {position:relative;min-height:62px;padding:11px 10px 10px 42px;border:1px solid rgba(114,190,214,.2);border-radius:12px;background:rgba(4,19,31,.62);color:rgba(224,243,250,.88);font-size:11.5px;font-weight:760;line-height:1.35}
.learning-foundation-route b {position:absolute;left:10px;top:10px;display:grid;place-items:center;width:23px;height:23px;border-radius:50%;background:rgba(55,203,193,.17);color:#7fe8df;font-size:11px}
.learning-foundation-steps {display:grid;gap:11px}
.learning-foundation-lab {margin-top:16px;padding-top:16px;border-top:1px solid rgba(116,177,201,.16)}
.foundation-step-card {border:1px solid rgba(116,177,201,.18);border-radius:14px;background:rgba(4,16,27,.62);overflow:hidden}
.foundation-step-card.is-done {border-color:rgba(68,210,171,.4);box-shadow:inset 3px 0 0 rgba(68,210,171,.72)}
.foundation-step-card header {display:flex;justify-content:space-between;gap:12px;padding:12px 14px;background:rgba(18,49,63,.48)}
.foundation-step-card header b {color:#f3fbff;font-size:14px;line-height:1.35}
.foundation-step-card header span {color:#91d8d2;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.04em}
.foundation-step-card dl {display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:0;margin:0}
.foundation-step-card dl div {padding:12px 13px;border-right:1px solid rgba(116,177,201,.12)}
.foundation-step-card dl div:last-child {border-right:0}
.foundation-step-card dt {margin-bottom:5px;color:#75dcd5;font-size:10.5px;font-weight:850;text-transform:uppercase;letter-spacing:.045em}
.foundation-step-card dd {margin:0;color:rgba(218,237,246,.84);font-size:12.5px;line-height:1.5}
.foundation-lab-grid {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.foundation-lab-grid article,.foundation-result-reading {padding:14px;border:1px solid rgba(116,177,201,.2);border-radius:13px;background:rgba(3,16,27,.64)}
.foundation-lab-grid h5 {margin:0 0 8px;color:#f0fbff;font-size:14px}
.foundation-lab-grid p,.foundation-result-reading p {margin:6px 0 10px;color:rgba(219,239,248,.86);font-size:13px;line-height:1.5}
.foundation-lab-grid small,.foundation-result-reading small {display:block;margin:8px 0;color:rgba(172,205,219,.76);font-size:11.5px;line-height:1.45}
.foundation-choice-row {display:flex;flex-wrap:wrap;gap:8px}
.foundation-choice-row button,.learning-foundation-lab button {min-height:34px}

.learning-session-plan {display:grid;gap:8px;margin-top:12px;padding:12px;border:1px solid rgba(255,255,255,.10);border-radius:12px;background:rgba(255,255,255,.028)}
.learning-session-plan-head {align-items:center;margin-bottom:3px}
.learning-session-plan-head b {color:#fff0c8;font-size:14px}
.learning-session-plan-head span {color:#83e9c0;font-size:12px;font-weight:850}
.learning-evidence-lock {display:flex;gap:9px;align-items:flex-start;padding:10px 11px;border-left:3px solid rgba(69,223,160,.72);border-radius:8px;background:rgba(69,223,160,.07)}
.learning-evidence-lock b {color:#9af3cc;white-space:nowrap}
.learning-evidence-lock span {color:#c8dce2;font-size:12px;line-height:1.5}
.learning-session-plan>label {display:grid;grid-template-columns:17px minmax(0,1fr);align-items:start;column-gap:11px;min-height:0;padding:11px 12px;border:1px solid rgba(255,255,255,.08);border-radius:10px;background:rgba(2,9,18,.46);cursor:pointer;text-align:left}
.learning-session-plan>label:has(input:checked) {border-color:rgba(69,223,160,.27);background:rgba(69,223,160,.065)}
.learning-session-plan>label>input {grid-column:1;grid-row:1;align-self:start;justify-self:start;margin-top:3px}
.learning-session-plan>label>span {grid-column:2;grid-row:1;display:grid;gap:4px;min-width:0;text-align:left}
.learning-session-plan label b {color:#edf7ff;font-size:13px;line-height:1.45}
.learning-session-plan label em {color:#b0c3d0;font-size:12px;font-style:normal;line-height:1.5}
.learning-step-action {justify-self:start;margin-top:4px}
input[type="checkbox"] {width:17px;min-width:17px;max-width:17px;height:17px;min-height:17px;max-height:17px;flex:0 0 17px;margin:0;padding:0;box-shadow:none;accent-color:#47df91}

.learning-notebook-grid {display:grid;grid-template-columns:minmax(0,1.35fr) minmax(320px,.65fr);gap:12px;margin-top:12px}
.learning-auto-summary-panel {display:grid;gap:7px;padding:12px;border:1px solid rgba(98,236,255,.18);border-radius:12px;background:rgba(2,14,24,.58)}
.learning-auto-summary-panel[hidden] {display:none}
.learning-auto-summary-panel>span {color:#bdefff;font-weight:850}
.learning-auto-summary-panel pre {margin:0;white-space:pre-wrap;color:#d7e7f1;font:500 12px/1.55 system-ui,sans-serif}
.learning-session-note {display:grid;gap:7px;margin-top:0;padding:12px;border:1px solid rgba(255,255,255,.10);border-radius:12px;background:rgba(2,9,18,.45);color:#adbfcc;font-size:11px;font-weight:850;text-transform:uppercase;letter-spacing:.06em}
.learning-session-note textarea {width:100%;min-height:240px;max-height:none;resize:vertical;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid rgba(255,255,255,.12);border-radius:11px;background:rgba(2,9,18,.72);color:#edf7ff;padding:12px;font:500 13px/1.62 system-ui,sans-serif;text-transform:none;letter-spacing:0}
.learning-session-note em,.learning-session-note small {color:#8fa8b8;font-size:10.5px;font-style:normal;text-transform:none;letter-spacing:0;line-height:1.45}
.learning-session-complete-action {display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:12px;padding:12px;border:1px solid rgba(71,223,145,.20);border-radius:11px;background:rgba(36,117,83,.07)}
.learning-session-complete-action span {color:#a9bdc9;font-size:11.5px}
.learning-secondary-actions {margin-top:10px;border:1px solid rgba(255,255,255,.08);border-radius:10px;background:rgba(2,9,18,.35)}
.learning-secondary-actions>summary {padding:11px 12px;cursor:pointer;color:#b8cad6;font-weight:850}
.learning-secondary-actions>div,.learning-secondary-actions>section {margin:0 12px 12px}
.learning-integrity-panel {display:grid;gap:10px;padding:12px;border:1px solid rgba(255,194,93,.20);border-radius:10px;background:rgba(42,31,10,.28)}
.learning-integrity-panel[hidden] {display:none}
.learning-integrity-panel header {display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
.learning-integrity-panel header>div {display:grid;gap:4px}
.learning-integrity-panel header b {color:#ffe0a0}
.learning-integrity-panel header span {color:#aebfca;font-size:11.5px;line-height:1.45}
.learning-integrity-details {margin:0;max-height:300px;overflow:auto;white-space:pre-wrap;padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:8px;background:#04101c;color:#cde3ef}
.learning-cockpit-reading {margin-top:12px;padding:10px 12px;border-left:3px solid rgba(98,236,255,.55);border-radius:8px;background:rgba(98,236,255,.05);color:#bcd2df;line-height:1.5}

.expert-roadmap-panel {margin-top:12px;padding:13px;border:1px solid rgba(98,236,255,.18);border-radius:14px;background:linear-gradient(180deg,rgba(7,22,38,.78),rgba(4,13,24,.66));box-shadow:inset 0 0 0 1px rgba(255,255,255,.025)}
.expert-roadmap-head {display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
.expert-roadmap-head h3 {margin:2px 0 4px;color:#fff0c8;font-size:15px}
.expert-roadmap-head p:not(.eyebrow) {margin:0;color:#9eb2c7;line-height:1.45}
.expert-roadmap-progress {margin-top:11px;padding:10px;border:1px solid rgba(255,255,255,.10);border-radius:11px;background:rgba(2,9,18,.52)}
.expert-roadmap-progress>div:first-child {display:flex;justify-content:space-between;gap:12px;color:#dceaf6;font-size:10px}
.expert-roadmap-bar {height:8px;margin-top:8px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden}
.expert-roadmap-bar i {display:block;width:0;height:100%;border-radius:inherit;background:linear-gradient(90deg,#43c8ff,#45dfa0);transition:width .25s ease}
.expert-roadmap-grid {display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin-top:11px}
.expert-roadmap-card {padding:10px;border:1px solid rgba(255,255,255,.10);border-radius:11px;background:rgba(255,255,255,.035)}
.expert-roadmap-card[data-status="practiced"] {border-color:rgba(71,223,145,.34);background:rgba(71,223,145,.055)}
.expert-roadmap-card-head {display:flex;align-items:flex-start;justify-content:space-between;gap:8px}
.expert-roadmap-card-head>div {display:grid;gap:3px}
.expert-roadmap-card-head span {color:#83d9d0;font-size:9.5px;text-transform:uppercase;letter-spacing:.06em}
.expert-roadmap-card-head b {color:#f2f9ff;font-size:12.5px;line-height:1.35}
.expert-roadmap-card-head select {max-width:120px;border:1px solid rgba(255,255,255,.12);border-radius:8px;background:#061421;color:#dcebf4;padding:6px;font-size:10px}
.expert-roadmap-card p {color:#aebfcc;font-size:11.5px;line-height:1.5}
.expert-roadmap-card label {display:grid;gap:5px;color:#8fa5b5;font-size:10px}
.expert-roadmap-card textarea {width:100%;min-height:54px;resize:vertical;border:1px solid rgba(255,255,255,.10);border-radius:9px;background:rgba(2,9,18,.68);color:#e8f4ff;padding:8px;font:500 10px/1.4 system-ui,sans-serif}
.expert-roadmap-actions {display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:10px}

@media (max-width:1180px){.learning-cockpit-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.expert-roadmap-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:1050px){.learning-foundation-route{grid-template-columns:1fr}.learning-foundation-route span{min-height:auto}.foundation-step-card dl{grid-template-columns:1fr}.foundation-step-card dl div{border-right:0;border-bottom:1px solid rgba(116,177,201,.12)}.foundation-step-card dl div:last-child{border-bottom:0}}
@media (max-width:980px){.learning-primary-action{grid-template-columns:1fr}.learning-primary-button{min-width:0;width:100%}.learning-lesson-grid,.learning-notebook-grid{grid-template-columns:1fr}.learning-session-note textarea{min-height:210px}.learning-completion-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.learning-completion-next{display:grid}}
@media (max-width:760px){.learning-cockpit-head,.learning-cockpit-focus,.learning-completion-head,.expert-roadmap-head{display:grid}.learning-cockpit-summary,.expert-roadmap-grid{grid-template-columns:1fr}.learning-help-setting{min-width:0}.learning-evidence-lock{flex-direction:column;gap:4px}}
@media (max-width:700px){.learning-foundation-panel{padding:13px}.learning-foundation-head{flex-direction:column}.foundation-lab-grid{grid-template-columns:1fr}}
@media (max-width:560px){.learning-completion-grid,.learning-legacy-recovery-summary,.learning-legacy-recovery-result{grid-template-columns:1fr}.learning-restart-notice{grid-template-columns:1fr}}

/* Guided hand-off strip used when the 01→11 cockpit sends the operator to an exercise. */
.learning-exercise-guide {display:flex;align-items:center;justify-content:space-between;gap:15px;margin:11px 0;padding:12px 14px;border:1px solid rgba(98,236,255,.34);border-radius:12px;background:linear-gradient(135deg,rgba(24,93,144,.28),rgba(5,22,35,.95));box-shadow:0 12px 28px rgba(0,0,0,.20);position:sticky;top:8px;z-index:24}
.learning-exercise-guide[hidden] {display:none}
.learning-exercise-guide-copy {display:grid;gap:5px;min-width:0}
.learning-exercise-guide-copy>b {color:#fff0c8;font-size:14px}
.learning-exercise-guide-copy>span {color:#c8dbe6;font-size:12.5px;line-height:1.5}
.learning-exercise-guide-actions {display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px}
@media (max-width:980px){.learning-exercise-guide{display:grid}.learning-exercise-guide-actions{justify-content:stretch}.learning-exercise-guide-actions .btn{flex:1 1 180px}}

/* Guided hand-off strip used when the 01→11 cockpit sends the operator to an exercise. */
.learning-exercise-guide {display:flex;align-items:center;justify-content:space-between;gap:15px;margin:11px 0;padding:12px 14px;border:1px solid rgba(98,236,255,.34);border-radius:12px;background:linear-gradient(135deg,rgba(24,93,144,.28),rgba(5,22,35,.95));box-shadow:0 12px 28px rgba(0,0,0,.20);position:sticky;top:8px;z-index:24}
.learning-exercise-guide[hidden] {display:none}
.learning-exercise-guide-copy {display:grid;gap:5px;min-width:0}
.learning-exercise-guide-copy>b {color:#fff0c8;font-size:14px}
.learning-exercise-guide-copy>span {color:#c8dbe6;font-size:12.5px;line-height:1.5}
.learning-exercise-guide-actions {display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px}
@media (max-width:980px){.learning-exercise-guide{display:grid}.learning-exercise-guide-actions{justify-content:stretch}.learning-exercise-guide-actions .btn{flex:1 1 180px}}
'@

function Write-Utf8NoBom([string]$Path, [string]$Text) {
  $enc = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

function Get-Sha256([string]$Path) {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Assert-Contains([string]$Text, [string]$Needle, [string]$Label) {
  if (-not $Text.Contains($Needle)) { throw "Validation impossible : motif absent [$Label]" }
}

function Replace-Exact([string]$Text, [string]$Old, [string]$New, [string]$Label) {
  Assert-Contains $Text $Old $Label
  return $Text.Replace($Old, $New)
}

if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
  $OutputRoot = Join-Path (Get-Location) "AGENT_CRYPTO_BUILD_38_15_13_WORK"
}
$OutputRoot = [System.IO.Path]::GetFullPath($OutputRoot)
$SourceDir = Join-Path $OutputRoot "source_381512"
$StageRoot = Join-Path $OutputRoot "clean_upload"
$StageWeb = Join-Path $StageRoot ($WebRel -replace '/', [System.IO.Path]::DirectorySeparatorChar)

if (Test-Path $OutputRoot) { Remove-Item -LiteralPath $OutputRoot -Recurse -Force }
New-Item -ItemType Directory -Path $SourceDir -Force | Out-Null
New-Item -ItemType Directory -Path $StageWeb -Force | Out-Null

$SourceWeb = $null
if (-not [string]::IsNullOrWhiteSpace($RepoRoot)) {
  $candidate = Join-Path ([System.IO.Path]::GetFullPath($RepoRoot)) ($WebRel -replace '/', [System.IO.Path]::DirectorySeparatorChar)
  if (Test-Path (Join-Path $candidate "index.html")) { $SourceWeb = $candidate }
  elseif ((Split-Path $RepoRoot -Leaf) -eq "web" -and (Test-Path (Join-Path $RepoRoot "index.html"))) { $SourceWeb = [System.IO.Path]::GetFullPath($RepoRoot) }
  else { throw "RepoRoot fourni, mais le dossier Web Classique n'a pas été trouvé." }
}

$SourceFiles = @("index.html","app.js","style.css","version.json")
foreach ($name in $SourceFiles) {
  $dest = Join-Path $SourceDir $name
  if ($SourceWeb) {
    Copy-Item -LiteralPath (Join-Path $SourceWeb $name) -Destination $dest -Force
  } else {
    Write-Host "Téléchargement $name depuis la publication courante..."
    Invoke-WebRequest -UseBasicParsing -Uri "$RawBase/$name" -OutFile $dest
  }
}

# Verrou absolu : on ne travaille que sur le checkpoint publié 38.15.12 exact.
foreach ($name in @("index.html","app.js","style.css")) {
  $actual = Get-Sha256 (Join-Path $SourceDir $name)
  if ($actual -ne $ExpectedSha[$name]) {
    throw "Base refusée : $name ne correspond pas au 38.15.12 publié. Attendu $($ExpectedSha[$name]), reçu $actual."
  }
}

$versionPath = Join-Path $SourceDir "version.json"
$baseVersion = Get-Content -Raw -LiteralPath $versionPath | ConvertFrom-Json
if ([string]$baseVersion.build -ne $ParentBuild) { throw "Base refusée : version.json annonce $($baseVersion.build), attendu $ParentBuild." }

$indexPath = Join-Path $SourceDir "index.html"
$appPath = Join-Path $SourceDir "app.js"
$stylePath = Join-Path $SourceDir "style.css"
$index = [System.IO.File]::ReadAllText($indexPath)
$app = [System.IO.File]::ReadAllText($appPath)

if ($index.Contains('id="learningJourneyCockpit"')) { throw "Le cockpit Learning Journey est déjà présent : aucun patch appliqué." }
Assert-Contains $index '<div class="learning-panel" id="learningPanel">' "ancre learningPanel"
Assert-Contains $app 'const ATLAS_BUILD = "38.15.12";' "ATLAS_BUILD 38.15.12"
Assert-Contains $app 'atlasChartStability381512' "verrou canvas historique 38.15.12"
Assert-Contains $app 'title:"08 · Staking et rendements"' "moteur Learning Module 08"

# 1) Index : identité de build + CSS propriétaire stable + présentation statique manquante.
$index = $index.Replace("38.15.12", "38.15.13")
$classicStyleLink = '<link rel="stylesheet" href="./style.css?v=market-core-v2.0-alpha-build-38.15.13" />'
Assert-Contains $index $classicStyleLink "style.css Classic 38.15.13"
$learningStyleLink = $classicStyleLink + "`n  " + '<link rel="stylesheet" href="./learning-journey.css?v=market-core-v2.0-alpha-build-38.15.13" />'
$index = $index.Replace($classicStyleLink, $learningStyleLink)
$anchor = '      <div class="learning-panel" id="learningPanel">'
$fragmentNormalized = $LearningFragment.Replace("`r`n","`n").TrimEnd() + "`n`n"
$index = $index.Replace($anchor, $fragmentNormalized + $anchor)

# 2) app.js : identité courante uniquement. Le propriétaire canvas 381512 reste volontairement intact.
$app = Replace-Exact $app 'const ATLAS_BUILD = "38.15.12";' 'const ATLAS_BUILD = "38.15.13";' "ATLAS_BUILD"
$app = Replace-Exact $app 'interface: "Build 38.15.12",' 'interface: "Build 38.15.13",' "ATLAS_STABLE_STACK"

$rcPattern = '(schema:\s*"agent_crypto_public_stable_rc_v1",\s*build:\s*)"38\.15\.12"'
if (-not [regex]::IsMatch($app, $rcPattern)) { throw "Validation impossible : ATLAS_RC_CONTRACT 38.15.12 absent." }
$app = [regex]::Replace($app, $rcPattern, '$1"38.15.13"', 1)

$app = Replace-Exact $app 'return `RC 38.15.12 CLASSIC HISTORICAL CANVAS STABILITY LOCK · 38.14 CONSERVÉ · audit statique ${audit.pass ? "PASS" : `FAIL [${failed.join(", ") || "inconnu"}]`} · Control Center ${ATLAS_RC_CONTRACT.control_center} · Bridge ${ATLAS_RC_CONTRACT.bridge} · ${ATLAS_RC_CONTRACT.model}`;' 'return `RC 38.15.13 CLASSIC LEARNING JOURNEY 01→11 PRESENTATION RECOVERY · CANVAS 38.15.12 CONSERVÉ · audit statique ${audit.pass ? "PASS" : `FAIL [${failed.join(", ") || "inconnu"}]`} · Control Center ${ATLAS_RC_CONTRACT.control_center} · Bridge ${ATLAS_RC_CONTRACT.bridge} · ${ATLAS_RC_CONTRACT.model}`;' "RC summary"

$truthPattern = '(const ATLAS_RUNTIME_TRUTH_3813 = Object\.freeze\(\{\s*schema:\s*"agent_crypto_runtime_truth_v3813",\s*build:\s*)"38\.15\.12"(,\s*asset_token:\s*)"market-core-v2\.0-alpha-build-38\.15\.12"'
if (-not [regex]::IsMatch($app, $truthPattern)) { throw "Validation impossible : runtime truth 38.15.12 absent." }
$app = [regex]::Replace($app, $truthPattern, '$1"38.15.13"$2"market-core-v2.0-alpha-build-38.15.13"', 1)

# Écriture staging.
$stageIndex = Join-Path $StageWeb "index.html"
$stageApp = Join-Path $StageWeb "app.js"
$stageCss = Join-Path $StageWeb "learning-journey.css"
$stageVersion = Join-Path $StageWeb "version.json"
Write-Utf8NoBom $stageIndex $index
Write-Utf8NoBom $stageApp $app
$classicCss = $LearningCss.Replace("`r`n","`n")
Write-Utf8NoBom $stageCss $classicCss

# 3) Manifest : nouvelle build, parent 38.15.12, style historique inchangé.
$newVersion = [ordered]@{
  schema = "agent_crypto_version_manifest_v3"
  release = $Release
  build = $Build
  asset_token = $Token
  status = "classic_learning_journey_recovery_candidate_requires_operator_validation"
  parent_build = $ParentBuild
  prepared_at = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssK")
  published_at = $null
  files = [ordered]@{
    "app.js" = [ordered]@{ sha256 = (Get-Sha256 $stageApp) }
    "index.html" = [ordered]@{ sha256 = (Get-Sha256 $stageIndex) }
    "style.css" = [ordered]@{ sha256 = $ExpectedSha["style.css"] }
    "learning-journey.css" = [ordered]@{ sha256 = (Get-Sha256 $stageCss) }
  }
  contracts = [ordered]@{
    historical_canvas = $baseVersion.contracts.historical_canvas
    resize = $baseVersion.contracts.resize
    classic_theme = [ordered]@{ modified = $false; style_sha256 = $ExpectedSha["style.css"] }
    learning_journey = [ordered]@{
      modules = 11
      recovered_static_ids = 126
      runtime_owner = "app.js"
      presentation_owner = "learning-journey.css + index.html"
      indexeddb_schema_changed = $false
      storage_reset = $false
      source_proof = "Administrator 40.4.22 + validated pedagogy 28.3.44 lineage"
    }
  }
  notes = @(
    "Built only from the exact published Classic 38.15.12 checkpoint.",
    "Restores the missing Learning Journey 01→11 presentation before the existing pedagogical journal; the existing app.js learning engine remains authoritative.",
    "Adds one stable functional CSS owner: learning-journey.css. No version number is embedded in the functional filename.",
    "Preserves the 38.15.12 historical canvas stability owner atlasChartStability381512 and does not alter chart, Binance, Atlas, Oracle, Bridge or IndexedDB schemas.",
    "Firefox F11 viewport recentering is deliberately excluded from this build and must be treated separately after operator validation."
  )
}
Write-Utf8NoBom $stageVersion (($newVersion | ConvertTo-Json -Depth 12) + "`n")

# 4) Validation structurelle.
$finalIndex = [System.IO.File]::ReadAllText($stageIndex)
$finalApp = [System.IO.File]::ReadAllText($stageApp)
$ids = [regex]::Matches($LearningFragment, 'id="([^"]+)"') | ForEach-Object { $_.Groups[1].Value }
$uniqueIds = @($ids | Sort-Object -Unique)
if ($uniqueIds.Count -ne 126) { throw "Fragment Learning inattendu : $($uniqueIds.Count) IDs uniques au lieu de 126." }
foreach ($id in $uniqueIds) {
  if (-not $finalIndex.Contains('id="' + $id + '"')) { throw "ID Learning manquant après patch : $id" }
}
foreach ($must in @('learningJourneyCockpit','learningLessonPanel','learningFoundationPanel','learningSessionPlan','learningNotebookGrid','expertLearningRoadmap')) {
  if (-not $finalIndex.Contains('id="' + $must + '"')) { throw "Présentation principale manquante : $must" }
}
if (-not $finalApp.Contains('atlasChartStability381512')) { throw "Canvas stability owner 38.15.12 perdu." }
if (-not $finalApp.Contains('title:"08 · Staking et rendements"')) { throw "Moteur pédagogique 08 absent." }
if ($finalApp.Contains('indexedDB.deleteDatabase(')) {
  Write-Warning "app.js contient déjà indexedDB.deleteDatabase dans la base historique ; vérifier que ce chemin n'est pas appelé par cette build. Aucun ajout de ce type n'est effectué par le patch."
}

$validation = @"
AGENT-CRYPTO @erith.IA — BUILD 38.15.13
CLASSIC LEARNING JOURNEY 01→11 PRESENTATION RECOVERY LOCK

STATUS STATIC: PASS
PARENT: 38.15.12 exact published checkpoint

RECOVERY
- Learning Journey cockpit: PASS
- Guided exercise hand-off: PASS
- Integrated lesson: PASS
- Foundation panel/lab: PASS
- Five-step session plan: PASS
- Notebook + integrity diagnostic: PASS
- Expert Roadmap 01→11: PASS
- Static recovered IDs: $($uniqueIds.Count)/126

PROTECTED
- Historical canvas owner atlasChartStability381512: PRESENT / UNCHANGED BY PATCH
- style.css Classic: BYTE-IDENTICAL 38.15.12
- IndexedDB schema: NO CHANGE
- Storage reset/delete/clear: NO NEW OWNER
- Market / Binance / Atlas / Oracle / Bridge: NO PRESENTATION OR RUNTIME PATCH
- Firefox F11 viewport issue: EXCLUDED / NEXT BOUNDED BUILD AFTER OPERATOR TEST

FILES
app.js              $((Get-Sha256 $stageApp))
index.html           $((Get-Sha256 $stageIndex))
style.css            $($ExpectedSha["style.css"])  [UNCHANGED / NOT IN CLEAN UPLOAD]
learning-journey.css $((Get-Sha256 $stageCss))
version.json         $((Get-Sha256 $stageVersion))

FIREFOX OPERATOR CHECK REQUIRED
1. Open Simulation.
2. Confirm Learning Journey 01→11 is visible.
3. Confirm current module and progress are restored from existing IndexedDB.
4. Open integrated lesson; validate step 1.
5. Confirm five-step panel, notes, Expert Roadmap and Module 08 display.
6. Confirm Graph / Oracle / Lecture technique / market remain unchanged.
7. Do NOT judge the F11 recenter issue in this build; it is deliberately out of scope.
"@
$validationPath = Join-Path $OutputRoot "AGENT_CRYPTO_BUILD_38_15_13_VALIDATION.txt"
Write-Utf8NoBom $validationPath ($validation.Replace("`r`n","`n"))

$commitPath = Join-Path $OutputRoot "AGENT_CRYPTO_BUILD_38_15_13_COMMIT_MESSAGE.txt"
Write-Utf8NoBom $commitPath "agent-crypto: build 38.15.13 restore Classic Learning Journey 01-11 presentation parity`n"

$zipPath = Join-Path $OutputRoot "AGENT_CRYPTO_BUILD_38_15_13_CLASSIC_LEARNING_JOURNEY_01_11_PRESENTATION_RECOVERY_LOCK_CLEAN_UPLOAD_4_FILES.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path (Join-Path $StageRoot "public") -DestinationPath $zipPath -CompressionLevel Optimal

Write-Host ""
Write-Host "PASS — Build 38.15.13 staged without GitHub write." -ForegroundColor Green
Write-Host "ZIP: $zipPath"
Write-Host "Validation: $validationPath"
Write-Host "Commit: $commitPath"
Write-Host ""
Write-Host "Firefox remains the final authority before publication." -ForegroundColor Yellow
