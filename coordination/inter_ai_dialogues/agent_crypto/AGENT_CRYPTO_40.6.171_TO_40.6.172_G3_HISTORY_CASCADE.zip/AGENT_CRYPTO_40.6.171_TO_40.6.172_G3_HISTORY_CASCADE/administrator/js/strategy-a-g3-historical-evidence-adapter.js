/* Agent-Crypto @erith.IA — 40.6.172 G3 HISTORICAL EVIDENCE ADAPTER
   Passive adapter over canonical Market Memory rows.
   Strict market timestamps only; saved_at/last_seen_at are never certification time.
   Produces candidate history facts, not replay labels, backtest results, or gate promotion. */
(() => {
  "use strict";
  const BUILD="40.6.172";
  const ROOT_ID="strategyAG3HistoricalEvidenceAdapter";
  const DOSSIER_ID="strategyADossier";
  const AFTER_ID="strategyAG3HistoryOwnerDiscovery";
  const byId=id=>typeof document!=="undefined"?document.getElementById(id):null;
  const safeCall=(fn,fallback=null)=>{try{return typeof fn==="function"?fn():fallback;}catch(_){return fallback;}};
  const finite=v=>{if(v===null||v===undefined||typeof v==="boolean"||(typeof v==="string"&&!v.trim()))return null;const n=Number(v);return Number.isFinite(n)?n:null;};
  const isoStrict=v=>{if(!v)return null;const ms=Date.parse(v);return Number.isFinite(ms)?new Date(ms).toISOString():null;};
  const strictMarketTime=row=>isoStrict(row?.market_generated_at||row?.source_time||row?.snapshot?.market_snapshot?.source_time||row?.market_time||null);
  const sourceId=row=>{
    const nested=row?.snapshot?.market_snapshot||{};
    const id=row?.market_snapshot_id||nested?.snapshot_id||row?.canonical_id||null;
    return id==null||String(id).trim()===""?null:String(id).trim();
  };
  const assetsOf=row=>Array.isArray(row?.assets)?row.assets:Array.isArray(row?.snapshot?.market_snapshot?.assets)?row.snapshot.market_snapshot.assets:[];
  const btcPrice=row=>{
    const asset=assetsOf(row).find(a=>String(a?.symbol||a?.asset_id||a?.provider_symbol||"").trim().toUpperCase()==="BTC"||String(a?.asset_id||"").trim().toLowerCase()==="bitcoin");
    if(!asset)return null;
    return finite(asset?.price_eur);
  };
  const median=values=>{const a=values.filter(Number.isFinite).sort((x,y)=>x-y);if(!a.length)return null;const i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2;};

  function adaptRows(inputRows){
    const rows=Array.isArray(inputRows)?inputRows:[];
    const prepared=rows.map((row,index)=>({index,id:sourceId(row),at:strictMarketTime(row),btc_eur:btcPrice(row)}));
    let sourceChronological=true,prev=null;
    for(const row of prepared){if(!row.at)continue;const ms=Date.parse(row.at);if(prev!==null&&ms<prev)sourceChronological=false;prev=ms;}
    const missing_id=prepared.filter(r=>!r.id).length;
    const missing_market_time=prepared.filter(r=>!r.at).length;
    const missing_btc_price=prepared.filter(r=>r.btc_eur===null).length;
    const ids=prepared.filter(r=>r.id).map(r=>r.id); const duplicate_ids=ids.length-new Set(ids).size;
    const valid=prepared.filter(r=>r.id&&r.at&&r.btc_eur!==null);
    const byIdMap=new Map(); for(const row of valid) if(!byIdMap.has(row.id))byIdMap.set(row.id,row);
    const canonical=[...byIdMap.values()].sort((a,b)=>Date.parse(a.at)-Date.parse(b.at));
    const times=canonical.map(r=>Date.parse(r.at));
    const steps=[]; for(let i=1;i<times.length;i++){const d=(times[i]-times[i-1])/60000;if(Number.isFinite(d)&&d>=0)steps.push(d);}
    const first=canonical[0]?.at||null,last=canonical[canonical.length-1]?.at||null;
    const span=first&&last?(Date.parse(last)-Date.parse(first))/60000:null;
    return {
      source_rows:rows.length,
      valid_fact_rows:valid.length,
      canonical_rows:canonical.length,
      missing_id,
      missing_market_time,
      missing_btc_price,
      duplicate_ids,
      source_chronological:sourceChronological,
      first_at:first,
      last_at:last,
      span_min:Number.isFinite(span)?span:null,
      median_step_min:median(steps),
      field_completeness_pct:rows.length?Number(((valid.length/rows.length)*100).toFixed(1)):null,
      coverage_completeness_pct:null,
      rows:canonical.map(r=>Object.freeze({replay_source_id:r.id,market_at:r.at,btc_eur:r.btc_eur}))
    };
  }

  function snapshot(overrides={}){
    const stats=Object.prototype.hasOwnProperty.call(overrides,"stats")?overrides.stats:safeCall(globalThis.atlasDecisionMemoryStats,null);
    const source=Array.isArray(stats?.canonicalRecords)?stats.canonicalRecords:Array.isArray(stats?.records)?stats.records:Array.isArray(stats?.marketRecords)?stats.marketRecords:[];
    const adapted=adaptRows(source);
    const ownerAvailable=!!stats&&typeof stats==="object";
    const inputReady=ownerAvailable&&adapted.canonical_rows>=2&&adapted.missing_id===0&&adapted.missing_market_time===0&&adapted.missing_btc_price===0&&adapted.duplicate_ids===0&&adapted.source_chronological;
    return {
      schema:"agent_crypto_strategy_a_g3_historical_evidence_adapter_v1",build:BUILD,
      owner:ownerAvailable?"atlasDecisionMemoryStats":null,
      repository_source:ownerAvailable?"js/market-memory-collector.js":null,
      source_kind:"CANONICAL_MARKET_MEMORY",
      certification_scope:"CANDIDATE_HISTORY_ONLY",
      strict_time_fields:Object.freeze(["market_generated_at","source_time","snapshot.market_snapshot.source_time","market_time"]),
      forbidden_time_fields:Object.freeze(["saved_at","last_seen_at"]),
      ...adapted,
      historical_input_ready:inputReady,
      certified_outcome_labels:false,
      certified_replay_rows:0,
      replay_dataset_ready:false,
      backtest_ready:false,
      g3_state:"PENDING",
      paper_only:true,real_order:false,fabricated_data:false,
      reason:!ownerAvailable?"Canonical Market Memory owner unavailable.":inputReady?"Canonical market-history facts are structurally usable as t0 candidates. Outcome labels and complete replay rows remain uncertified; G3 stays PENDING.":"Canonical Market Memory is readable but one or more identity/time/price/chronology facts are incomplete; no replay certification."
    };
  }

  function ensureStyle(){if(typeof document==="undefined"||byId(`${ROOT_ID}Style`))return;const s=document.createElement("style");s.id=`${ROOT_ID}Style`;s.textContent=`#${ROOT_ID}{margin-top:9px;padding:8px;border:1px solid rgba(126,255,186,.22);border-radius:8px;background:rgba(5,28,22,.30)}#${ROOT_ID} .t{font-size:8px;font-weight:950;letter-spacing:.08em;color:#7effba;text-transform:uppercase}#${ROOT_ID} .sub,#${ROOT_ID} .note{font-size:8px;color:#91b9a7;margin-top:3px}#${ROOT_ID} .g{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:5px;margin-top:7px}#${ROOT_ID} .k{padding:6px;border:1px solid rgba(255,255,255,.06);border-radius:7px}#${ROOT_ID} .k span{font-size:7px;color:#759a89;display:block;text-transform:uppercase}#${ROOT_ID} .k b{font-size:9px;color:#effff6;display:block;margin-top:3px}@media(max-width:900px){#${ROOT_ID} .g{grid-template-columns:repeat(2,minmax(0,1fr))}}`;document.head.appendChild(s);}
  function ensureRoot(){if(typeof document==="undefined")return null;const dossier=byId(DOSSIER_ID);if(!dossier)return null;let root=byId(ROOT_ID);if(root)return root;root=document.createElement("section");root.id=ROOT_ID;root.dataset.build=BUILD;const after=byId(AFTER_ID);if(after&&after.parentElement===dossier)after.insertAdjacentElement("afterend",root);else dossier.appendChild(root);return root;}
  const show=(v,s="")=>v===null||v===undefined||v===""?"INCONNU":`${v}${s}`;
  function render(){const d=snapshot(),root=ensureRoot();if(!root)return d;ensureStyle();root.innerHTML=`<div class="t">G3 · HISTORICAL EVIDENCE ADAPTER · ${BUILD}</div><div class="sub">Market Memory canonique → faits historiques stricts · saved_at/last_seen_at interdits comme temps marché.</div><div class="g">
    <div class="k"><span>Owner</span><b>${show(d.owner)}</b></div><div class="k"><span>Lignes source</span><b>${d.source_rows}</b></div><div class="k"><span>Lignes canoniques</span><b>${d.canonical_rows}</b></div><div class="k"><span>Temps marché manquants</span><b>${d.missing_market_time}</b></div><div class="k"><span>Prix BTC manquants</span><b>${d.missing_btc_price}</b></div>
    <div class="k"><span>IDs manquants</span><b>${d.missing_id}</b></div><div class="k"><span>IDs doublons</span><b>${d.duplicate_ids}</b></div><div class="k"><span>Chronologie source</span><b>${d.source_chronological?"OK":"NON"}</b></div><div class="k"><span>Pas médian réel</span><b>${show(d.median_step_min," min")}</b></div><div class="k"><span>Span réel</span><b>${show(d.span_min," min")}</b></div>
    <div class="k"><span>Complétude champs</span><b>${show(d.field_completeness_pct," %")}</b></div><div class="k"><span>Couverture marché</span><b>INCONNU</b></div><div class="k"><span>Input historique t0</span><b>${d.historical_input_ready?"READY":"NOT READY"}</b></div><div class="k"><span>Dataset replay</span><b>NOT READY</b></div><div class="k"><span>G3</span><b>PENDING</b></div>
    </div><div class="note">${d.reason}</div>`;root.dataset.g3State="PENDING";root.dataset.historicalInputReady=d.historical_input_ready?"true":"false";return d;}
  function selfTest(){
    const rows=[
      {market_snapshot_id:"a",market_generated_at:"2026-09-16T00:00:00Z",assets:[{symbol:"BTC",price_eur:65000}]},
      {market_snapshot_id:"b",source_time:"2026-09-16T00:05:00Z",assets:[{symbol:"BTC",price_eur:65100}]}
    ];
    const good=snapshot({stats:{canonicalRecords:rows}});
    const bad=snapshot({stats:{canonicalRecords:[{market_snapshot_id:"x",saved_at:"2026-09-16T00:00:00Z",assets:[{symbol:"BTC",price_eur:65000}]}]}});
    const pass=good.canonical_rows===2&&good.median_step_min===5&&good.historical_input_ready===true&&good.replay_dataset_ready===false&&good.g3_state==="PENDING"&&bad.missing_market_time===1&&bad.historical_input_ready===false&&bad.coverage_completeness_pct===null;
    return {schema:"agent_crypto_strategy_a_g3_historical_evidence_adapter_self_test_v1",build:BUILD,pass,checks:{strict_saved_at_rejected:bad.missing_market_time===1,median_real:good.median_step_min===5,no_gate_promotion:good.g3_state==="PENDING"&&good.replay_dataset_ready===false,coverage_not_invented:good.coverage_completeness_pct===null}};
  }
  globalThis.AgentCryptoStrategyAG3HistoricalEvidenceAdapter=Object.freeze({build:BUILD,snapshot,adapt_rows:adaptRows,render,self_test:selfTest,strict_market_time:true,saved_at_as_market_time:false,last_seen_at_as_market_time:false,coverage_completeness_invented:false,certified_replay_rows:0,backtest_ready:false,g3:"PENDING",recurring_timer:false,observer:false,storage_write:false,network:false,real_order:false,paper_only:true});
  if(typeof document!=="undefined"){const schedule=()=>{try{requestAnimationFrame(()=>render());}catch(_){queueMicrotask(render);}};document.addEventListener("agent-crypto:evidence-view-refreshed",schedule);document.addEventListener("agent-crypto:evidence-data-changed",schedule);document.addEventListener("agent-crypto:runtime-modules-ready",schedule,{once:true});window.addEventListener("pageshow",schedule);if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",schedule,{once:true});else schedule();}
})();
