# Agent-Crypto 40.6.171 → 40.6.172 — G3 History Cascade

## 40.6.171 — History Owner Discovery
- Proves `atlasDecisionMemoryStats()` as the structured owner of canonical Market Memory observations.
- Repository source: `js/market-memory-collector.js`.
- Keeps the exact displayed 24h/300-point chart-series owner UNRESOLVED unless an explicit structured API exists.
- No DOM text scraping and no G3 promotion.

## 40.6.172 — Historical Evidence Adapter
- Reads canonical Market Memory rows passively.
- Certification time may come only from market/source timestamps.
- `saved_at` and `last_seen_at` are forbidden as market-time evidence.
- BTC facts require structured `price_eur`.
- Missing IDs, timestamps and prices remain missing.
- Median step and actual span are derived only from valid rows.
- Market coverage completeness remains UNKNOWN; it is not fabricated from field completeness.
- Historical t0 facts may be structurally READY, while replay labels/backtest remain NOT READY.
- G3 remains PENDING; G9 remains LOCKED.

## GitHub commits
40.6.171:
- module: a09ba018ca94584cab0a8bf0d1151d490923b3d2
- registry: ce316813dc73f0b4acad378925f5b1150a5d3f77
- release: 87ab3248663bc33e45e2df79b20474561cbf939a
- promotion: 220481d7a22ead6b4148fa7263c6d9d4c77b72f1

40.6.172:
- module: 4871530ae5e3318d0581e95f1fa006a9cdd877b8
- registry: 97179af52c6a9b9a702ea6815567ef40f9e40a5c
- release: 8449cb20c54a1306702146c41430fb34307011cc
- promotion: 51740dc579636ddf84f9568c5b4b3e2ff429bbdd

Firefox terrain proof for .171/.172 is still PENDING.
