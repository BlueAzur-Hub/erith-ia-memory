(() => {
  "use strict";

  /*
    Yohan Operator profile — final handoff layer.

    Architecture authority:
    - Operator uses the same canonical Administrator runtime and UI.
    - This file does NOT hide projects, panels or capabilities.
    - This file does NOT grant Administrator/Owner rights.
    - Authentication/permissions belong to the future local Bridge on Yohan's PC.
    - URL/profile parameters are identity/routing hints only, never authorization.
  */

  const PROFILE = Object.freeze({
    id: "yohan-operator",
    displayName: "Yohan",
    targetRole: "operator",
    sameAdministratorRuntime: true,
    sameAdministratorInterface: true,
    authAuthority: "local-bridge-pending",
    bridgeConfigured: false,
    urlParameterIsAuthorization: false,
    grantsAdministratorSession: false,
    grantsRealTrading: false,
    grantsWallet: false,
    hideProjects: false,
    interfaceMutation: false,
    publicSecretEmbedded: false
  });

  function applyIdentityMarker() {
    try {
      document.documentElement.dataset.yohanProfile = "operator";
      document.documentElement.dataset.yohanAuthAuthority = PROFILE.authAuthority;
      document.documentElement.dataset.yohanSameAdministratorRuntime = "true";
      document.documentElement.dataset.yohanSameAdministratorInterface = "true";
      if (document.body) {
        document.body.dataset.yohanProfile = "operator";
        document.body.dataset.yohanAuthAuthority = PROFILE.authAuthority;
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  function snapshot() {
    return Object.freeze({
      profile: PROFILE.id,
      target_role: PROFILE.targetRole,
      auth_authority: PROFILE.authAuthority,
      bridge_configured: PROFILE.bridgeConfigured,
      same_administrator_runtime: PROFILE.sameAdministratorRuntime,
      same_administrator_interface: PROFILE.sameAdministratorInterface,
      grants_administrator_session: PROFILE.grantsAdministratorSession,
      grants_real_trading: PROFILE.grantsRealTrading,
      grants_wallet: PROFILE.grantsWallet,
      hidden_surfaces: 0,
      interface_mutation: PROFILE.interfaceMutation
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applyIdentityMarker, { once: true });
  } else {
    applyIdentityMarker();
  }

  document.addEventListener("erith:system-hydrated", applyIdentityMarker, { passive: true });
  window.addEventListener("pageshow", applyIdentityMarker, { passive: true });

  globalThis.ErithYohanOperatorProfile = Object.freeze({
    profile: PROFILE,
    apply: applyIdentityMarker,
    snapshot
  });
})();
