# UPLOAD — AGENT_CRYPTO_OPERATOR_FINAL_40.6.119

1. Décompresser l'archive.
2. Copier son contenu à la racine du dépôt `BlueAzur-Hub/agent-crypto-operator` en conservant exactement les chemins.
3. Autoriser le remplacement des fichiers actifs :
   - `public/agent_crypto_erith_ia/administrator/yohan.html`
   - `public/agent_crypto_erith_ia/administrator/js/yohan-operator-profile.js`
   - `public/agent_crypto_erith_ia/administrator/YOHAN_PROFILE_README.md`
   - `public/agent_crypto_erith_ia/operator/build.json`
   - `public/agent_crypto_erith_ia/operator/index.html`
4. Ajouter :
   - `public/agent_crypto_erith_ia/operator/index-40.6.119.html`
   - `public/agent_crypto_erith_ia/operator/FINAL_HANDOFF_40.6.119.md`
5. Ne pas supprimer les anciennes entrées versionnées.
6. Commit conseillé :
   `release(agent-crypto-operator): final Yohan handoff 40.6.119`
7. Attendre GitHub Pages, puis ouvrir :
   `https://blueazur-hub.github.io/agent-crypto-operator/public/agent_crypto_erith_ia/operator/index-40.6.119.html`

Important :
- cette livraison n'active pas le futur Bridge local de Yohan ;
- elle ne donne aucun droit Administrator ;
- elle ne masque plus Projects/Portfolio ;
- elle suit le dernier checkpoint terrain retenu, 40.6.119.
