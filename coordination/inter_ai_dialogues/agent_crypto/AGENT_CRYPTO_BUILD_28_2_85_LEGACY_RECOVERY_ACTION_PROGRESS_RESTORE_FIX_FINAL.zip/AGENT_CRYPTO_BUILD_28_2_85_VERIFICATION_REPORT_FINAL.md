# AGENT-CRYPTO — Build 28.2.85 Verification Report

**Build :** 28.2.85  
**Nom :** LEGACY RECOVERY ACTION & PROGRESS RESTORE FIX  
**Base :** Build 28.2.84  
**Date de préparation :** 2026-08-05 01:25 +02:00  
**Statut :** candidat local vérifié — validation publique Firefox/Ryzen requise après publication par Christophe

## Incident traité

Dans le Firefox de Christophe, le Build 28.2.84 détectait correctement l’ancienne mémoire pédagogique — une session déclarée, un module progressé, 550 caractères et trois étapes — mais le clic sur « Importer dans mon carnet » ne produisait aucun changement visible et vérifiable.

Le moteur 28.2.84 fonctionne dans un banc d’essai contrôlé. Le déclencheur précis de l’absence d’effet dans le profil Firefox réel n’est donc pas établi avec certitude. Le défaut certain était l’absence de preuve après action : le Build pouvait demander un clic sans garantir visiblement que les écritures avaient été exécutées, relues et confirmées.

## Correction 28.2.85

Le Build 28.2.85 supprime la dépendance à ce clic ambigu :

- récupération automatique au chargement ;
- lecture des anciennes clés 28.2.81/82 sans suppression ;
- fusion idempotente du parcours, de l’historique, du brouillon actif et des notes ;
- écriture vérifiée par relecture exacte de chaque clé cible ;
- audit indépendant du marqueur 28.2.84 ;
- réparation automatique lorsqu’un ancien marqueur affirme « importé » mais que les cibles ne le prouvent pas ;
- statut visible `RÉCUPÉRÉ · VÉRIFIÉ` uniquement lorsque toutes les conditions sont confirmées ;
- statut `ÉCHEC CONTRÔLÉ` avec erreur explicite en cas d’échec d’écriture ou de quota ;
- ancien brouillon archivé séparément lorsque le nouveau carnet contient déjà une séance non vide ;
- relance manuelle idempotente sans doublon.

## Cas réel attendu après publication

À partir des données détectées sur les captures de Christophe, le résultat attendu est :

- progression restaurée : **6 %** ;
- module actif : **02 · Spot et carnet d’ordres** ;
- étapes compatibles récupérées : **3/3** ;
- notes récupérées : **550/550 caractères encore présents** ;
- historique : au moins **1 preuve pédagogique** ;
- anciennes clés 28.2.81/82 : **intactes**.

Le nombre 550 correspond aux caractères encore présents dans Firefox. Les caractères déjà tronqués par l’ancienne limite de 800 ne peuvent pas être reconstruits.

## Vérification automatisée

**30 contrôles réussis sur 30 — 0 échec.**

Les contrôles comprennent :

- syntaxe JavaScript Node ;
- validité du manifeste JSON ;
- identité Build et asset token ;
- conservation de tous les identifiants HTML du Build 28.2.84 ;
- conservation de toutes les fonctions JavaScript nommées ;
- absence de nouvel appel `fetch` ;
- absence de nouveau WebSocket ;
- récupération automatique sans clic ;
- restauration de 6 % de progression ;
- restauration du module Spot ;
- restauration exacte de 550 caractères ;
- restauration de trois étapes compatibles ;
- conservation exacte des anciennes clés ;
- création d’un historique de récupération ;
- affichage du détail de relecture ;
- relance manuelle sans doublon ;
- réparation d’un faux marqueur 28.2.84 ;
- simulation d’un `QuotaExceededError` ;
- refus d’annoncer une réussite en cas d’échec ;
- maintien des sources anciennes après échec ;
- absence d’erreur JavaScript dans le cas nominal.

## Limites de validation

Le banc Chromium est exécuté par injection locale de l’interface, car la politique administrative du conteneur bloque la navigation vers GitHub Pages et localhost. Les fonctions de récupération, les événements, le DOM et le stockage simulé sont réellement exécutés dans Chromium.

La validation finale de la page publique complète reste le contrôle de Christophe sous Firefox/Ryzen après remplacement des quatre fichiers.

## Fichiers déployables et SHA-256

- `public/agent_crypto_erith_ia/web/app.js`  
  `0f511c60030261b131fb8c6584e3f5feb7c76a433b1d1f8420390c84baf0c3dc`
- `public/agent_crypto_erith_ia/web/index.html`  
  `12add0e44dc262060a7c7ec7a88a5f7d0edab161ed3c6079d85372b5162e7991`
- `public/agent_crypto_erith_ia/web/style.css`  
  `12cffdbdb092d8631298520bb283481d356f345a760a0b7f63c60c3907e45d20`
- `public/agent_crypto_erith_ia/web/version.json`  
  `9439ac3c71491d3a44420282a4fedccf315224b81745de3decddb4d6c2d76a3f`

## Verdict

**PASS local vérifié.** Aucune écriture GitHub, aucune transaction, aucun wallet, aucune clé API, aucun collecteur et aucun workflow n’ont été modifiés.
