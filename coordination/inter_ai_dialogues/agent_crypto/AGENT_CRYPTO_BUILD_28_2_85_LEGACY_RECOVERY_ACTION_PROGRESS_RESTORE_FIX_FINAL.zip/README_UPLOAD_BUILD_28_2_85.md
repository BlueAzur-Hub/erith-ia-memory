# Upload — Agent-Crypto Build 28.2.85

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

## Après l’upload

1. Ouvrir la page avec le **même profil Firefox** que celui utilisé pour les leçons 28.2.81/82.
2. Effectuer un rechargement forcé pour charger `28.2.85`.
3. Vérifier le marqueur de version.
4. Descendre au Cockpit d’apprentissage.
5. Ne cliquer sur aucune leçon avant de lire le bloc de récupération.

Aucun clic d’import n’est désormais requis. Le résultat attendu est affiché automatiquement :

```text
RÉCUPÉRÉ · VÉRIFIÉ
Progression : 6 %
Module actif : 02 · Spot et carnet d’ordres
Étapes compatibles : 3/3
Notes : 550/550 caractères
Sources 28.2.81/82 : intactes
```

Les valeurs sont dynamiques ; elles reflètent ce qui existe réellement dans le stockage Firefox.

## En cas d’échec

Si l’interface affiche `ÉCHEC CONTRÔLÉ`, ne recommencer aucune leçon et ne supprimer aucune donnée. Le panneau donne maintenant l’erreur d’écriture exacte. Envoyer une capture du bloc complet pour correction ciblée.

## Règle de publication

Christophe effectue seul l’upload et le commit GitHub. L’assistante n’effectue aucune écriture distante.
