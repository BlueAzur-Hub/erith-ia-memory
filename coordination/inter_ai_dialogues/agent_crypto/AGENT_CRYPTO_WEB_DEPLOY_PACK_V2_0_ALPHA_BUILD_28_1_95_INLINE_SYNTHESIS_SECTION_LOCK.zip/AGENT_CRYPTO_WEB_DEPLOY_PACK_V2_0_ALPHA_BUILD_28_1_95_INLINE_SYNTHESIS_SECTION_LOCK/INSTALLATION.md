# Installation — Build 28.1.95

Chemin GitHub :

`public/agent_crypto_erith_ia/web/`

Remplacer uniquement :

- `app.js`
- `index.html`
- `style.css`

Commit :

`replace publication popup with permanent synthesis section build 28.1.95`

Le Bridge V1.7.5 déjà installé reste utilisé uniquement pour produire les quatre
rapports Atlas et la conclusion Aerith. Aucun fichier Bridge n’est remplacé.

Comportement :

1. Le Ryzen produit les quatre rapports Atlas.
2. Aerith produit la conclusion.
3. La sous-section permanente de l’Interface se remplit.
4. IndexedDB conserve la synthèse après F5 et après fermeture de Firefox.

Aucune popup.
Aucun bouton de publication.
Aucun appel `/publish-synthesis`.
Aucun jeton GitHub demandé.
