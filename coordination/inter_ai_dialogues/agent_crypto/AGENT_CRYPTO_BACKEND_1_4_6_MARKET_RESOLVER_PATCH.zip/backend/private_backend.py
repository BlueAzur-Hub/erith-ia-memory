#!/usr/bin/env python3
"""Agent-Crypto @erith.IA — Private Local Backend · OKX Dynamic Spot Transport
Read-only public market source bridge. No credentials, no trading, no wallet endpoints.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import platform
import shutil
import subprocess
import math
import statistics
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "1.4.6"
BUILD = "Market Instrument Resolver"
HOST = "127.0.0.1"
PORT = 8790
CACHE_TTL_SECONDS = 15
ORDERBOOK_CACHE_TTL_SECONDS = 3
OKX_TRANSPORT_CACHE_TTL_SECONDS = 2
MARKET_RESOLVE_CACHE_TTL_SECONDS = 90
MAX_ORDERBOOK_DEPTH = 400
CONTEXT_CACHE_TTL_SECONDS = 90
SYSTEM_CACHE_TTL_SECONDS = 3
REQUEST_TIMEOUT_SECONDS = 4.0
COHERENT_PCT = 0.25
WATCH_PCT = 0.75
MAX_ASSETS = 10
DEFAULT_ASSETS = ("BTC", "ETH", "BNB", "XRP", "SOL")
ALLOWED_ORIGINS = {
    "https://blueazur-hub.github.io",
    "http://127.0.0.1",
    "http://localhost",
}

KRAKEN_PAIRS = {
    "BTC": "XBTEUR",
    "ETH": "ETHEUR",
    "BNB": "BNBEUR",
    "XRP": "XRPEUR",
    "SOL": "SOLEUR",
}
COINBASE_PRODUCTS = {asset: f"{asset}-EUR" for asset in DEFAULT_ASSETS}
OKX_INSTRUMENTS = {asset: f"{asset}-EUR" for asset in DEFAULT_ASSETS}
OKX_PUBLIC_QUOTES = ("EUR", "USDC", "USDT")
MARKET_PROVIDERS = ("okx", "bitget", "binance")
DEX_SEARCH = {
    "BTC": "WBTC/USDC",
    "ETH": "WETH/USDC",
    "BNB": "WBNB/USDC",
    "XRP": "XRP/USDC",
    "SOL": "SOL/USDC",
}
DEX_ALIASES = {
    "BTC": {"BTC", "WBTC", "CBBTC"},
    "ETH": {"ETH", "WETH"},
    "BNB": {"BNB", "WBNB"},
    "XRP": {"XRP"},
    "SOL": {"SOL", "WSOL"},
}
USD_QUOTES = {"USD", "USDC", "USDT", "DAI", "USDS", "FDUSD", "USD1"}
DEFILLAMA_CHAINS = ("Ethereum", "Solana", "BSC")

# 40.4.57 — bounded identity policy for symbol-discovered DEX pools.
# This is deliberately NOT address-level proof. It only prevents obviously
# wrong-chain symbol collisions (for example a token named WETH on Solana)
# from being treated as useful context for ETH.
DEX_NETWORK_ALIASES = {
    "eth": "ethereum",
    "ethereum": "ethereum",
    "arbitrum": "arbitrum",
    "arbitrum-one": "arbitrum",
    "base": "base",
    "optimism": "optimism",
    "op-mainnet": "optimism",
    "bsc": "bsc",
    "binance-smart-chain": "bsc",
    "solana": "solana",
    "xrpl": "xrpl",
    "xrp-ledger": "xrpl",
}
DEX_CHAIN_POLICY = {
    "BTC": {"ethereum", "arbitrum", "base"},
    "ETH": {"ethereum", "arbitrum", "base", "optimism"},
    "BNB": {"bsc"},
    "XRP": {"xrpl"},
    "SOL": {"solana"},
}
LIQUIDITY_RATIO_REVIEW = 20.0

SOURCE_REGISTRY = (
    {
        "id": "kraken",
        "label": "Kraken Public",
        "mode": "read_only_public",
        "role": "spot EUR · independent control",
        "auth_required": False,
        "base_url": "https://api.kraken.com/0/public",
    },
    {
        "id": "coinbase",
        "label": "Coinbase Exchange",
        "mode": "read_only_public",
        "role": "public market data · independent control",
        "auth_required": False,
        "base_url": "https://api.exchange.coinbase.com",
    },
    {
        "id": "okx",
        "label": "OKX Public",
        "mode": "read_only_public",
        "role": "spot EUR · independent control",
        "auth_required": False,
        "base_url": "https://www.okx.com/api/v5",
    },
    {
        "id": "binance",
        "label": "Binance Public",
        "mode": "read_only_public",
        "role": "spot fallback · candles discovery",
        "auth_required": False,
        "base_url": "https://api.binance.com/api/v3",
    },
    {
        "id": "bitget",
        "label": "Bitget Public",
        "mode": "read_only_public",
        "role": "spot fallback · candles + timestamped orderbook discovery",
        "auth_required": False,
        "base_url": "https://api.bitget.com/api/v3/market",
    },
    {
        "id": "dexscreener",
        "label": "DEX Screener",
        "mode": "read_only_public",
        "role": "DEX liquidity discovery · context only",
        "auth_required": False,
        "base_url": "https://api.dexscreener.com",
    },
    {
        "id": "geckoterminal",
        "label": "GeckoTerminal",
        "mode": "read_only_public",
        "role": "DEX pool cross-check · context only",
        "auth_required": False,
        "base_url": "https://api.geckoterminal.com/api/v2",
    },
    {
        "id": "defillama",
        "label": "DefiLlama",
        "mode": "read_only_public",
        "role": "DeFi aggregate context · DEX volume / chain TVL",
        "auth_required": False,
        "base_url": "https://api.llama.fi",
    },
)

_cache_lock = threading.Lock()
_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
_gt_semaphore = threading.Semaphore(2)
_system_lock = threading.Lock()
_system_cache: Tuple[float, Dict[str, Any]] = (0.0, {})
_cpu_sample: Optional[Tuple[int, int, int]] = None
QUIET = False


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _number(value: Any) -> Optional[float]:
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    return n if math.isfinite(n) else None


def _fetch_json(url: str, extra_headers: Optional[Dict[str, str]] = None) -> Any:
    headers = {
        "Accept": "application/json",
        "User-Agent": f"Agent-Crypto-Private-Backend/{VERSION}",
        "Cache-Control": "no-cache",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, method="GET", headers=headers)
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}")
        return json.loads(response.read().decode("utf-8"))


def _quote_error(provider: str, asset: str, pair: str, exc: Exception) -> Dict[str, Any]:
    return {
        "provider": provider,
        "asset": asset,
        "pair": pair,
        "status": "unavailable",
        "error": str(exc)[:180],
        "observed_at_utc": utc_now(),
    }


def fetch_kraken(asset: str) -> Dict[str, Any]:
    pair = KRAKEN_PAIRS.get(asset, f"{asset}EUR")
    url = "https://api.kraken.com/0/public/Ticker?" + urllib.parse.urlencode({"pair": pair})
    try:
        payload = _fetch_json(url)
        errors = payload.get("error") or []
        if errors:
            raise RuntimeError("; ".join(map(str, errors)))
        result = payload.get("result") or {}
        if not result:
            raise RuntimeError("empty ticker result")
        ticker = next(iter(result.values()))
        return {
            "provider": "kraken",
            "asset": asset,
            "pair": pair,
            "status": "ok",
            "price_eur": _number((ticker.get("c") or [None])[0]),
            "bid_eur": _number((ticker.get("b") or [None])[0]),
            "ask_eur": _number((ticker.get("a") or [None])[0]),
            "volume_24h": _number((ticker.get("v") or [None, None])[1]),
            "observed_at_utc": utc_now(),
            "source_url": url,
        }
    except Exception as exc:
        return _quote_error("kraken", asset, pair, exc)


def fetch_coinbase(asset: str) -> Dict[str, Any]:
    product = COINBASE_PRODUCTS.get(asset, f"{asset}-EUR")
    url = f"https://api.exchange.coinbase.com/products/{urllib.parse.quote(product)}/stats"
    try:
        payload = _fetch_json(url)
        price = _number(payload.get("last"))
        if price is None:
            raise RuntimeError("missing last price")
        return {
            "provider": "coinbase",
            "asset": asset,
            "pair": product,
            "status": "ok",
            "price_eur": price,
            "bid_eur": None,
            "ask_eur": None,
            "volume_24h": _number(payload.get("volume")),
            "observed_at_utc": utc_now(),
            "source_url": url,
        }
    except Exception as exc:
        return _quote_error("coinbase", asset, product, exc)


def _utc_from_unix_ms(value: Any) -> str:
    try:
        ms = int(str(value))
        if ms <= 0:
            raise ValueError("non-positive timestamp")
        return datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    except (TypeError, ValueError, OverflowError):
        return utc_now()


def fetch_okx(asset: str) -> Dict[str, Any]:
    instrument = OKX_INSTRUMENTS.get(asset, f"{asset}-EUR")
    url = "https://www.okx.com/api/v5/market/ticker?" + urllib.parse.urlencode({"instId": instrument})
    try:
        payload = _fetch_json(url)
        if str(payload.get("code", "")) != "0":
            raise RuntimeError(str(payload.get("msg") or f"OKX code {payload.get('code')}"))
        data = payload.get("data") or []
        if not data:
            raise RuntimeError("instrument unavailable or empty ticker result")
        ticker = data[0] or {}
        if str(ticker.get("instId") or instrument).upper() != instrument.upper():
            raise RuntimeError("unexpected instrument")
        price = _number(ticker.get("last"))
        if price is None or price <= 0:
            raise RuntimeError("missing last price")
        return {
            "provider": "okx",
            "asset": asset,
            "pair": instrument,
            "status": "ok",
            "price_eur": price,
            "bid_eur": _number(ticker.get("bidPx")),
            "ask_eur": _number(ticker.get("askPx")),
            "volume_24h": _number(ticker.get("vol24h")),
            "quote_volume_24h": _number(ticker.get("volCcy24h")),
            "observed_at_utc": _utc_from_unix_ms(ticker.get("ts")),
            "source_url": url,
        }
    except Exception as exc:
        return _quote_error("okx", asset, instrument, exc)


def _normalize_book_depth(value: Any) -> int:
    try:
        depth = int(str(value))
    except (TypeError, ValueError):
        depth = 100
    return max(1, min(MAX_ORDERBOOK_DEPTH, depth))


def _parse_okx_orderbook_payload(payload: Dict[str, Any], asset: str, instrument: str, depth: int, source_url: str) -> Dict[str, Any]:
    if str(payload.get("code", "")) != "0":
        raise RuntimeError(str(payload.get("msg") or f"OKX code {payload.get('code')}"))
    data = payload.get("data") or []
    if not data:
        raise RuntimeError("instrument unavailable or empty orderbook result")
    book = data[0] or {}
    bids_raw = book.get("bids") or []
    asks_raw = book.get("asks") or []
    bids: List[List[float]] = []
    asks: List[List[float]] = []
    for raw, target in ((bids_raw, bids), (asks_raw, asks)):
        for row in raw[:depth]:
            if not isinstance(row, (list, tuple)) or len(row) < 2:
                continue
            price, size = _number(row[0]), _number(row[1])
            if price is None or size is None or price <= 0 or size <= 0:
                continue
            target.append([price, size])
    if not bids or not asks:
        raise RuntimeError("orderbook missing valid bid/ask levels")
    bids.sort(key=lambda row: row[0], reverse=True)
    asks.sort(key=lambda row: row[0])
    best_bid, best_ask = bids[0][0], asks[0][0]
    if best_bid > best_ask:
        raise RuntimeError("crossed OKX orderbook")
    raw_ts = str(book.get("ts") or "").strip()
    if not raw_ts.isdigit() or int(raw_ts) <= 0:
        raise RuntimeError("missing or invalid orderbook timestamp")
    try:
        observed = datetime.fromtimestamp(int(raw_ts) / 1000.0, tz=timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    except (ValueError, OverflowError, OSError) as exc:
        raise RuntimeError("invalid orderbook timestamp") from exc
    return {
        "schema": "agent_crypto_private_backend_orderbook_v1",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "provider": "okx",
        "asset": asset,
        "pair": instrument,
        "status": "ok",
        "requested_depth": depth,
        "levels": {"bids": len(bids), "asks": len(asks)},
        "bids": bids,
        "asks": asks,
        "best_bid_eur": best_bid,
        "best_ask_eur": best_ask,
        "mid_eur": (best_bid + best_ask) / 2.0,
        "observed_at_utc": observed,
        "source_url": source_url,
        "cache": {"state": "fresh", "ttl_seconds": ORDERBOOK_CACHE_TTL_SECONDS},
        "capabilities": ["okx_spot_eur_orderbook_read", "multi_level_depth", "slippage_input"],
        "forbidden": ["orders", "trading", "wallet", "withdrawal", "exchange_private_api"],
        "disclaimer": "read-only public orderbook evidence; no execution or financial recommendation",
    }


def okx_orderbook_payload(asset: str, depth: int = 100) -> Dict[str, Any]:
    asset = str(asset or "BTC").strip().upper()
    if asset not in OKX_INSTRUMENTS:
        raise ValueError("unsupported asset")
    depth = _normalize_book_depth(depth)
    instrument = OKX_INSTRUMENTS[asset]
    cache_key = f"orderbook:{asset}:{depth}"
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= ORDERBOOK_CACHE_TTL_SECONDS:
            result = dict(cached[1])
            result["cache"] = {"state": "hit", "ttl_seconds": ORDERBOOK_CACHE_TTL_SECONDS}
            return result
    url = "https://www.okx.com/api/v5/market/books?" + urllib.parse.urlencode({"instId": instrument, "sz": depth})
    payload = _fetch_json(url)
    result = _parse_okx_orderbook_payload(payload, asset, instrument, depth, url)
    with _cache_lock:
        _cache[cache_key] = (now, result)
    return result


def _normalize_okx_public_asset(value: Any) -> str:
    asset = str(value or "").strip().upper()
    if not (2 <= len(asset) <= 16 and asset.isalnum()):
        raise ValueError("unsupported OKX asset")
    return asset


def _normalize_okx_public_instrument(value: Any) -> str:
    raw = str(value or "").strip().upper().replace("/", "-")
    parts = raw.split("-")
    if len(parts) != 2:
        raise ValueError("unsupported OKX instrument")
    asset = _normalize_okx_public_asset(parts[0])
    quote = parts[1]
    if quote not in OKX_PUBLIC_QUOTES:
        raise ValueError("unsupported OKX quote")
    return f"{asset}-{quote}"


def _okx_public_instrument(asset: Any, quote: Any = "EUR") -> Tuple[str, str, str]:
    asset_u = _normalize_okx_public_asset(asset or "BTC")
    quote_u = str(quote or "EUR").strip().upper()
    if quote_u not in {"EUR", "USD", "USDC", "USDT"}:
        raise ValueError("unsupported quote")
    api_quote = "USDC" if quote_u == "USD" else quote_u
    display_quote = "USD" if quote_u == "USD" else quote_u
    return asset_u, display_quote, _normalize_okx_public_instrument(f"{asset_u}-{api_quote}")




def _market_currency(value: Any) -> str:
    currency = str(value or "USD").strip().upper()
    if currency not in {"USD", "EUR"}:
        raise ValueError("unsupported display currency")
    return currency


def _market_quote_candidates(currency: Any) -> Tuple[str, ...]:
    return ("USDC", "USDT") if _market_currency(currency) == "USD" else ("EUR", "USDC", "USDT")


def _market_match(provider: str, asset: str, quote: str, instrument: str, capabilities: Iterable[str], **extra: Any) -> Dict[str, Any]:
    return {
        "provider": provider,
        "asset": asset,
        "quote": quote,
        "instrument": instrument,
        "capabilities": list(capabilities),
        **extra,
    }


def _probe_okx_spot(asset: str, quote: str) -> Dict[str, Any]:
    instrument = _normalize_okx_public_instrument(f"{asset}-{quote}")
    call = _okx_public_request("/public/instruments", {"instType": "SPOT", "instId": instrument})
    row = next((item for item in call["data"] if str(item.get("instId") or "").upper() == instrument), None)
    if not row:
        raise RuntimeError("instrument absent")
    state = str(row.get("state") or "").lower()
    if state and state not in {"live", "preopen"}:
        raise RuntimeError(f"instrument state {state}")
    return _market_match("okx", asset, quote, instrument, ("candles", "book", "ticker"), source_url=call["url"], venue_state=state or "live")


def _bitget_spot_catalog() -> List[Dict[str, Any]]:
    cache_key = "bitget_spot_catalog_v3"
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= MARKET_RESOLVE_CACHE_TTL_SECONDS:
            rows = cached[1].get("rows") if isinstance(cached[1], dict) else None
            if isinstance(rows, list):
                return rows
    url = "https://api.bitget.com/api/v3/market/instruments?" + urllib.parse.urlencode({"category": "SPOT"})
    payload = _fetch_json(url)
    if str(payload.get("code") or "") != "00000" or not isinstance(payload.get("data"), list):
        raise RuntimeError(str(payload.get("msg") or "Bitget instruments error"))
    rows = [row for row in payload["data"] if isinstance(row, dict)]
    with _cache_lock:
        _cache[cache_key] = (now, {"rows": rows})
    return rows


def _probe_bitget_spot(asset: str, quote: str) -> Dict[str, Any]:
    asset_u = _normalize_okx_public_asset(asset)
    quote_u = str(quote or "").strip().upper()
    if quote_u not in OKX_PUBLIC_QUOTES:
        raise ValueError("unsupported Bitget quote")
    expected_symbol = f"{asset_u}{quote_u}"
    row = next((item for item in _bitget_spot_catalog()
                if str(item.get("symbol") or "").upper() == expected_symbol
                and str(item.get("baseCoin") or "").upper() == asset_u
                and str(item.get("quoteCoin") or "").upper() == quote_u), None)
    if not row:
        raise RuntimeError("instrument absent")
    if str(row.get("status") or "").lower() != "online":
        raise RuntimeError(f"instrument state {row.get('status') or '?'}")
    if str(row.get("symbolType") or "crypto").lower() != "crypto":
        raise RuntimeError("instrument not crypto")
    if str(row.get("isRwa") or "NO").upper() == "YES":
        raise RuntimeError("instrument is RWA")
    instrument = f"{asset_u}-{quote_u}"
    return _market_match("bitget", asset_u, quote_u, instrument, ("candles", "book", "ticker"),
                         source_url="https://api.bitget.com/api/v3/market/instruments?category=SPOT",
                         venue_symbol=expected_symbol, venue_state="online")


def _binance_symbol(asset: str, quote: str) -> str:
    asset_u = _normalize_okx_public_asset(asset)
    quote_u = str(quote or "").strip().upper()
    if quote_u not in OKX_PUBLIC_QUOTES:
        raise ValueError("unsupported Binance quote")
    return f"{asset_u}{quote_u}"


def _probe_binance_spot(asset: str, quote: str) -> Dict[str, Any]:
    symbol = _binance_symbol(asset, quote)
    url = "https://api.binance.com/api/v3/exchangeInfo?" + urllib.parse.urlencode({"symbol": symbol})
    payload = _fetch_json(url)
    rows = payload.get("symbols") or []
    row = next((item for item in rows if str(item.get("symbol") or "").upper() == symbol), None)
    if not row:
        raise RuntimeError("instrument absent")
    if str(row.get("status") or "").upper() != "TRADING":
        raise RuntimeError(f"instrument state {row.get('status') or '?'}")
    if row.get("isSpotTradingAllowed") is False:
        raise RuntimeError("spot trading unavailable")
    instrument = f"{asset}-{quote}"
    return _market_match("binance", asset, quote, instrument, ("candles", "ticker"), source_url=url, venue_symbol=symbol, venue_state="TRADING")


def _market_match_sort_key(match: Dict[str, Any], currency: str) -> Tuple[int, int, str]:
    providers = {name: idx for idx, name in enumerate(MARKET_PROVIDERS)}
    quotes = {name: idx for idx, name in enumerate(_market_quote_candidates(currency))}
    return (providers.get(str(match.get("provider") or ""), 99), quotes.get(str(match.get("quote") or ""), 99), str(match.get("instrument") or ""))


def _market_choose(matches: Iterable[Dict[str, Any]], capability: str, currency: str) -> Optional[Dict[str, Any]]:
    viable = [dict(item) for item in matches if capability in set(item.get("capabilities") or [])]
    viable.sort(key=lambda item: _market_match_sort_key(item, currency))
    return viable[0] if viable else None


def market_resolve_payload(asset: Any, currency: Any = "USD") -> Dict[str, Any]:
    asset_u = _normalize_okx_public_asset(asset)
    currency_u = _market_currency(currency)
    cache_key = f"market_resolve:{asset_u}:{currency_u}"
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= MARKET_RESOLVE_CACHE_TTL_SECONDS:
            result = dict(cached[1])
            result["cache"] = {"state": "hit", "ttl_seconds": MARKET_RESOLVE_CACHE_TTL_SECONDS}
            return result

    quotes = _market_quote_candidates(currency_u)
    jobs = []
    for provider in MARKET_PROVIDERS:
        for quote in quotes:
            jobs.append((provider, quote))
    matches: List[Dict[str, Any]] = []
    errors: List[Dict[str, str]] = []

    def probe(provider: str, quote: str) -> Dict[str, Any]:
        if provider == "okx":
            return _probe_okx_spot(asset_u, quote)
        if provider == "binance":
            return _probe_binance_spot(asset_u, quote)
        if provider == "bitget":
            return _probe_bitget_spot(asset_u, quote)
        raise ValueError("unsupported market provider")

    with ThreadPoolExecutor(max_workers=min(6, len(jobs))) as pool:
        future_map = {pool.submit(probe, provider, quote): (provider, quote) for provider, quote in jobs}
        for future in as_completed(future_map):
            provider, quote = future_map[future]
            try:
                matches.append(future.result())
            except Exception as exc:
                errors.append({"provider": provider, "quote": quote, "error": str(exc)[:160]})

    matches.sort(key=lambda item: _market_match_sort_key(item, currency_u))
    chosen_candles = _market_choose(matches, "candles", currency_u)
    chosen_book = _market_choose(matches, "book", currency_u)
    status = "ok" if chosen_candles or chosen_book else "unavailable"
    result = {
        "schema": "agent_crypto_market_instrument_resolver_v1",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "status": status,
        "asset": asset_u,
        "display_currency": currency_u,
        "provider_order": list(MARKET_PROVIDERS),
        "quote_order": list(quotes),
        "matches": matches,
        "chosen": {"candles": chosen_candles, "book": chosen_book},
        "errors": errors,
        "observed_at_utc": utc_now(),
        "cache": {"state": "fresh", "ttl_seconds": MARKET_RESOLVE_CACHE_TTL_SECONDS},
        "capabilities": ["dynamic_instrument_discovery", "okx_spot_discovery", "binance_spot_discovery", "candles_provider_resolution", "book_provider_resolution"],
        "forbidden": ["orders", "trading", "wallet", "withdrawal", "exchange_private_api"],
    }
    with _cache_lock:
        _cache[cache_key] = (now, result)
    return dict(result)


def _market_candle_rows_okx(instrument: str, bar: str, limit: int) -> Tuple[List[Dict[str, Any]], str]:
    call = _okx_public_request("/market/candles", {"instId": instrument, "bar": _normalize_candle_bar(bar), "limit": limit})
    rows = []
    for raw in call["data"]:
        if not isinstance(raw, (list, tuple)) or len(raw) < 6:
            continue
        rows.append({"t": raw[0], "o": raw[1], "h": raw[2], "l": raw[3], "c": raw[4], "v": raw[5], "confirm": raw[8] if len(raw) > 8 else ""})
    return rows, call["url"]


def _market_candle_rows_binance(instrument: str, bar: str, limit: int) -> Tuple[List[Dict[str, Any]], str]:
    base, quote = instrument.split("-", 1)
    symbol = _binance_symbol(base, quote)
    aliases = {"1m":"1m", "5m":"5m", "15m":"15m", "1h":"1h", "1H":"1h", "4h":"4h", "4H":"4h", "1d":"1d", "1D":"1d", "1j":"1d"}
    interval = aliases.get(str(bar or "15m"))
    if not interval:
        raise ValueError("unsupported candle bar")
    url = "https://api.binance.com/api/v3/klines?" + urllib.parse.urlencode({"symbol": symbol, "interval": interval, "limit": limit})
    payload = _fetch_json(url)
    if not isinstance(payload, list):
        raise RuntimeError("Binance klines payload invalid")
    rows = []
    for raw in payload:
        if not isinstance(raw, (list, tuple)) or len(raw) < 6:
            continue
        rows.append({"t": raw[0], "o": raw[1], "h": raw[2], "l": raw[3], "c": raw[4], "v": raw[5], "confirm": "1"})
    return rows, url


def _market_candle_rows_bitget(instrument: str, bar: str, limit: int) -> Tuple[List[Dict[str, Any]], str]:
    base, quote = instrument.split("-", 1)
    symbol = f"{base}{quote}"
    aliases = {"1m":"1m", "5m":"5m", "15m":"15m", "1h":"1H", "1H":"1H", "4h":"4H", "4H":"4H", "1d":"1D", "1D":"1D", "1j":"1D"}
    interval = aliases.get(str(bar or "15m"))
    if not interval:
        raise ValueError("unsupported candle bar")
    url = "https://api.bitget.com/api/v3/market/candles?" + urllib.parse.urlencode({"category":"SPOT", "symbol":symbol, "interval":interval, "limit":limit})
    payload = _fetch_json(url)
    if str(payload.get("code") or "") != "00000" or not isinstance(payload.get("data"), list):
        raise RuntimeError(str(payload.get("msg") or "Bitget candles error"))
    rows = []
    for raw in payload["data"]:
        if not isinstance(raw, (list, tuple)) or len(raw) < 6:
            continue
        rows.append({"t": raw[0], "o": raw[1], "h": raw[2], "l": raw[3], "c": raw[4], "v": raw[5], "confirm": "1"})
    return rows, url


def market_candles_payload(provider: Any, instrument: Any, bar: Any = "15m", limit: Any = 300) -> Dict[str, Any]:
    provider_u = str(provider or "").strip().lower()
    if provider_u not in MARKET_PROVIDERS:
        raise ValueError("unsupported market provider")
    inst = _normalize_okx_public_instrument(instrument)
    try:
        limit_i = max(1, min(300, int(str(limit))))
    except (TypeError, ValueError):
        limit_i = 300
    if provider_u == "okx":
        rows, source_url = _market_candle_rows_okx(inst, str(bar or "15m"), limit_i)
    elif provider_u == "bitget":
        rows, source_url = _market_candle_rows_bitget(inst, str(bar or "15m"), limit_i)
    else:
        rows, source_url = _market_candle_rows_binance(inst, str(bar or "15m"), limit_i)
    if not rows:
        raise RuntimeError("no candle rows")
    base, quote = inst.split("-", 1)
    return {
        "schema": "agent_crypto_market_candles_v1",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "status": "ok",
        "provider": provider_u,
        "asset": base,
        "quote": quote,
        "instrument": inst,
        "bar": str(bar or "15m"),
        "rows": rows,
        "observed_at_utc": utc_now(),
        "source_url": source_url,
        "capabilities": ["public_candles_read", "browser_local_transport"],
        "forbidden": ["orders", "trading", "wallet", "withdrawal", "exchange_private_api"],
    }

def _market_book_okx(instrument: str, limit: int) -> Tuple[List[Any], List[Any], str, str]:
    call = _okx_public_request("/market/books", {"instId": instrument, "sz": min(400, limit)})
    row = call["data"][0] if call.get("data") else {}
    ts = _number(row.get("ts"))
    if not ts:
        raise RuntimeError("OKX orderbook timestamp missing")
    return row.get("bids") or [], row.get("asks") or [], str(int(ts)), call["url"]


def _market_book_bitget(instrument: str, limit: int) -> Tuple[List[Any], List[Any], str, str]:
    base, quote = instrument.split("-", 1)
    symbol = f"{base}{quote}"
    url = "https://api.bitget.com/api/v3/market/orderbook?" + urllib.parse.urlencode({"category":"SPOT", "symbol":symbol, "limit":max(5, min(1000, limit))})
    payload = _fetch_json(url)
    if str(payload.get("code") or "") != "00000" or not isinstance(payload.get("data"), dict):
        raise RuntimeError(str(payload.get("msg") or "Bitget orderbook error"))
    row = payload["data"]
    ts = _number(row.get("ts"))
    if not ts:
        raise RuntimeError("Bitget orderbook timestamp missing")
    return row.get("b") or [], row.get("a") or [], str(int(ts)), url


def market_book_payload(provider: Any, instrument: Any, limit: Any = 100) -> Dict[str, Any]:
    provider_u = str(provider or "").strip().lower()
    if provider_u not in {"okx", "bitget"}:
        raise ValueError("unsupported market book provider")
    inst = _normalize_okx_public_instrument(instrument)
    try:
        limit_i = max(5, min(400, int(str(limit))))
    except (TypeError, ValueError):
        limit_i = 100
    if provider_u == "okx":
        bids, asks, ts, source_url = _market_book_okx(inst, limit_i)
    else:
        bids, asks, ts, source_url = _market_book_bitget(inst, limit_i)
    if not bids or not asks:
        raise RuntimeError("orderbook empty")
    base, quote = inst.split("-", 1)
    return {
        "schema":"agent_crypto_market_book_v1",
        "backend_version":VERSION,
        "build":BUILD,
        "read_only":True,
        "status":"ok",
        "provider":provider_u,
        "asset":base,
        "quote":quote,
        "pair":inst,
        "instrument":inst,
        "observed_at_utc":datetime.fromtimestamp(int(ts)/1000, tz=timezone.utc).isoformat(timespec="milliseconds").replace("+00:00","Z"),
        "bids":bids,
        "asks":asks,
        "source_url":source_url,
        "capabilities":["public_orderbook_read", "source_timestamp_preserved", "browser_local_transport"],
        "forbidden":["orders", "trading", "wallet", "withdrawal", "exchange_private_api"],
    }


OKX_PUBLIC_PROXY_ENDPOINTS = {
    "candles": {"instId", "bar", "limit"},
    "ticker": {"instId"},
    "books": {"instId", "sz"},
    "books-rpi": {"instId", "sz"},
    "trades": {"instId", "limit"},
}

def okx_public_proxy_payload(endpoint: Any, query: Dict[str, List[str]]) -> Dict[str, Any]:
    ep = str(endpoint or "").strip().lower()
    allowed = OKX_PUBLIC_PROXY_ENDPOINTS.get(ep)
    if not allowed:
        raise ValueError("unsupported OKX public endpoint")
    params: Dict[str, Any] = {}
    for key in allowed:
        values = query.get(key) or []
        if values and str(values[0]).strip():
            params[key] = str(values[0]).strip()
    params["instId"] = _normalize_okx_public_instrument(params.get("instId"))
    if ep == "candles":
        params["bar"] = _normalize_candle_bar(params.get("bar") or "15m")
        try: params["limit"] = max(1, min(300, int(str(params.get("limit") or 300))))
        except (TypeError, ValueError): params["limit"] = 300
    elif ep in {"books", "books-rpi"}:
        try: params["sz"] = max(1, min(20, int(str(params.get("sz") or 20))))
        except (TypeError, ValueError): params["sz"] = 20
    elif ep == "trades":
        try: params["limit"] = max(1, min(100, int(str(params.get("limit") or 20))))
        except (TypeError, ValueError): params["limit"] = 20
    call = _okx_public_request(f"/market/{ep}", params)
    payload = {"code":"0", "msg":"", "data":call["data"]}
    return payload


def _okx_public_request(path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    url = "https://www.okx.com/api/v5" + path + "?" + urllib.parse.urlencode(params)
    payload = _fetch_json(url)
    if str(payload.get("code", "")) != "0":
        raise RuntimeError(str(payload.get("msg") or f"OKX code {payload.get('code')}"))
    data = payload.get("data") or []
    if not isinstance(data, list):
        raise RuntimeError("OKX data is not a list")
    return {"url": url, "data": data}


def _normalize_candle_bar(value: Any) -> str:
    raw = str(value or "15m").strip()
    aliases = {"1m":"1m", "5m":"5m", "15m":"15m", "1h":"1H", "1H":"1H", "4h":"4H", "4H":"4H", "1d":"1D", "1D":"1D", "1j":"1D"}
    if raw not in aliases:
        raise ValueError("unsupported candle bar")
    return aliases[raw]


def okx_candles_payload(asset: Any, quote: Any = "EUR", bar: Any = "15m", limit: Any = 300) -> Dict[str, Any]:
    asset_u, display_quote, instrument = _okx_public_instrument(asset, quote)
    bar_u = _normalize_candle_bar(bar)
    try:
        limit_i = max(1, min(300, int(str(limit))))
    except (TypeError, ValueError):
        limit_i = 300
    cache_key = f"okx_candles:{instrument}:{bar_u}:{limit_i}"
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= OKX_TRANSPORT_CACHE_TTL_SECONDS:
            result = dict(cached[1])
            result["cache"] = {"state":"hit", "ttl_seconds":OKX_TRANSPORT_CACHE_TTL_SECONDS}
            return result
    call = _okx_public_request("/market/candles", {"instId": instrument, "bar": bar_u, "limit": limit_i})
    rows: List[List[Any]] = []
    for row in call["data"][:limit_i]:
        if not isinstance(row, (list, tuple)) or len(row) < 5:
            continue
        try:
            ts = int(str(row[0]))
            if ts <= 0:
                continue
            vals = [float(row[i]) for i in range(1, 5)]
            if not all(math.isfinite(v) and v > 0 for v in vals):
                continue
        except (TypeError, ValueError, OverflowError):
            continue
        rows.append(list(row[:9]))
    if not rows:
        raise RuntimeError("empty or invalid candle series")
    result = {
        "schema":"agent_crypto_private_backend_okx_candles_v1",
        "backend_version":VERSION,
        "build":BUILD,
        "read_only":True,
        "provider":"okx",
        "asset":asset_u,
        "display_quote":display_quote,
        "pair":instrument,
        "bar":bar_u,
        "status":"ok",
        "candles":rows,
        "observed_at_utc":utc_now(),
        "source_url":call["url"],
        "cache":{"state":"fresh", "ttl_seconds":OKX_TRANSPORT_CACHE_TTL_SECONDS},
        "capabilities":["okx_public_candles_read", "browser_local_transport"],
        "forbidden":["orders", "trading", "wallet", "withdrawal", "exchange_private_api"],
    }
    with _cache_lock:
        _cache[cache_key]=(now,result)
    return result


def _okx_component(path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    try:
        call = _okx_public_request(path, params)
        return {"status":"ok", "data":call["data"], "source_url":call["url"]}
    except Exception as exc:
        return {"status":"unavailable", "data":[], "error":str(exc)[:180]}


def okx_microstructure_payload(asset: Any, quote: Any = "EUR", depth: Any = 20, trades: Any = 20) -> Dict[str, Any]:
    asset_u, display_quote, instrument = _okx_public_instrument(asset, quote)
    try:
        depth_i=max(1,min(20,int(str(depth))))
    except (TypeError, ValueError):
        depth_i=20
    try:
        trades_i=max(1,min(100,int(str(trades))))
    except (TypeError, ValueError):
        trades_i=20
    cache_key=f"okx_micro:{instrument}:{depth_i}:{trades_i}"
    now=time.monotonic()
    with _cache_lock:
        cached=_cache.get(cache_key)
        if cached and now-cached[0] <= OKX_TRANSPORT_CACHE_TTL_SECONDS:
            result=dict(cached[1])
            result["cache"]={"state":"hit", "ttl_seconds":OKX_TRANSPORT_CACHE_TTL_SECONDS}
            return result
    specs={
        "ticker":("/market/ticker", {"instId":instrument}),
        "books":("/market/books", {"instId":instrument, "sz":depth_i}),
        "rpi":("/market/books-rpi", {"instId":instrument, "sz":depth_i}),
        "trades":("/market/trades", {"instId":instrument, "limit":trades_i}),
    }
    components: Dict[str, Dict[str, Any]]={}
    with ThreadPoolExecutor(max_workers=4) as pool:
        future_map={pool.submit(_okx_component,path,params):name for name,(path,params) in specs.items()}
        for fut in as_completed(future_map):
            name=future_map[fut]
            try:
                components[name]=fut.result()
            except Exception as exc:
                components[name]={"status":"unavailable", "data":[], "error":str(exc)[:180]}
    ticker=(components.get("ticker") or {}).get("data") or []
    books=(components.get("books") or {}).get("data") or []
    rpi=(components.get("rpi") or {}).get("data") or []
    trade_rows=(components.get("trades") or {}).get("data") or []
    critical_ok=bool(ticker and books)
    all_ok=all((components.get(k) or {}).get("status")=="ok" for k in specs)
    result={
        "schema":"agent_crypto_private_backend_okx_microstructure_v1",
        "backend_version":VERSION,
        "build":BUILD,
        "read_only":True,
        "provider":"okx",
        "asset":asset_u,
        "display_quote":display_quote,
        "pair":instrument,
        "status":"ok" if all_ok else ("partial" if critical_ok else "unavailable"),
        "ticker":ticker[0] if ticker else None,
        "books":books[0] if books else None,
        "rpi":rpi[0] if rpi else None,
        "trades":trade_rows,
        "component_status":{k:{kk:vv for kk,vv in (components.get(k) or {}).items() if kk != "data"} for k in specs},
        "observed_at_utc":utc_now(),
        "cache":{"state":"fresh", "ttl_seconds":OKX_TRANSPORT_CACHE_TTL_SECONDS},
        "capabilities":["okx_public_ticker_read", "okx_public_books_read", "okx_public_books_rpi_read", "okx_public_trades_read", "browser_local_transport"],
        "forbidden":["orders", "trading", "wallet", "withdrawal", "exchange_private_api"],
    }
    with _cache_lock:
        _cache[cache_key]=(now,result)
    return result


def _consensus(quotes: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    prices = [q.get("price_eur") for q in quotes if q.get("status") == "ok" and _number(q.get("price_eur")) is not None]
    prices = [float(p) for p in prices]
    if len(prices) < 2:
        return {"providers": len(prices), "median_eur": prices[0] if prices else None, "spread_pct": None, "verdict": "insufficient"}
    mean = statistics.fmean(prices)
    spread = ((max(prices) - min(prices)) / mean * 100.0) if mean else None
    verdict = "coherent" if spread is not None and spread <= COHERENT_PCT else "watch" if spread is not None and spread <= WATCH_PCT else "divergent"
    return {
        "providers": len(prices),
        "median_eur": statistics.median(prices),
        "min_eur": min(prices),
        "max_eur": max(prices),
        "spread_pct": spread,
        "verdict": verdict,
    }



def _dex_error(provider: str, asset: str, exc: Exception) -> Dict[str, Any]:
    return {
        "provider": provider,
        "asset": asset,
        "status": "unavailable",
        "error": str(exc)[:180],
        "observed_at_utc": utc_now(),
        "context_only": True,
        "identity_proof": False,
    }


def _normalize_network(value: Any) -> Optional[str]:
    raw = str(value or "").strip().lower()
    if not raw:
        return None
    return DEX_NETWORK_ALIASES.get(raw, raw)


def _network_allowed(asset: str, network: Any) -> bool:
    normalized = _normalize_network(network)
    allowed = DEX_CHAIN_POLICY.get(asset, set())
    return bool(normalized and normalized in allowed)


def _dexscreener_pair_orientation(asset: str, pair: Dict[str, Any]) -> Optional[str]:
    aliases = DEX_ALIASES.get(asset, {asset})
    base = str((pair.get("baseToken") or {}).get("symbol") or "").upper()
    quote = str((pair.get("quoteToken") or {}).get("symbol") or "").upper()
    if base in aliases and quote in USD_QUOTES:
        return "asset_base"
    if quote in aliases and base in USD_QUOTES:
        return "asset_quote"
    return None


def _best_dexscreener_pair(asset: str, pairs: Iterable[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    candidates = []
    for pair in pairs or []:
        orientation = _dexscreener_pair_orientation(asset, pair)
        if not orientation:
            continue
        network = _normalize_network(pair.get("chainId"))
        if not _network_allowed(asset, network):
            continue
        liquidity = _number((pair.get("liquidity") or {}).get("usd")) or 0.0
        candidates.append((liquidity, pair))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def fetch_dexscreener(asset: str) -> Dict[str, Any]:
    # Search intended asset/stable pair first, then bounded alias fallback.
    # A result is accepted only when alias orientation AND asset chain policy
    # agree. This rejects obvious symbol collisions while remaining context-only.
    pair_query = DEX_SEARCH.get(asset, f"{asset}/USDC").replace("/", " ")
    alias_query = DEX_SEARCH.get(asset, f"{asset}/USDC").split("/", 1)[0]
    queries = [pair_query] + ([alias_query] if alias_query != pair_query else [])
    try:
        pair = None
        used_url = None
        used_query = None
        for query in queries:
            url = "https://api.dexscreener.com/latest/dex/search?" + urllib.parse.urlencode({"q": query})
            payload = _fetch_json(url)
            pair = _best_dexscreener_pair(asset, payload.get("pairs") or [])
            if pair:
                used_url, used_query = url, query
                break
        if not pair:
            raise RuntimeError("no alias/stable pool on allowed asset network")
        orientation = _dexscreener_pair_orientation(asset, pair)
        network = _normalize_network(pair.get("chainId"))
        raw_pair_price = _number(pair.get("priceUsd"))
        # DEX Screener priceUsd is the base-token price. Do not silently use it
        # as asset price when the asset is on the quote side.
        asset_price = raw_pair_price if orientation == "asset_base" else None
        return {
            "provider": "dexscreener",
            "asset": asset,
            "status": "ok",
            "context_only": True,
            "discovery_method": "symbol_search_chain_bounded_alias_stable_bidirectional",
            "identity_proof": False,
            "identity_status": "bounded_chain_alias",
            "identity_level": "CHAIN_ALIAS_ONLY",
            "query": used_query,
            "queries_attempted": queries[: queries.index(used_query) + 1] if used_query in queries else queries,
            "asset_side": orientation,
            "chain": pair.get("chainId"),
            "network_normalized": network,
            "chain_allowed": True,
            "allowed_networks": sorted(DEX_CHAIN_POLICY.get(asset, set())),
            "dex": pair.get("dexId"),
            "pair_address": pair.get("pairAddress"),
            "base_symbol": (pair.get("baseToken") or {}).get("symbol"),
            "base_address": (pair.get("baseToken") or {}).get("address"),
            "quote_symbol": (pair.get("quoteToken") or {}).get("symbol"),
            "quote_address": (pair.get("quoteToken") or {}).get("address"),
            "asset_address": (pair.get("baseToken") or {}).get("address") if orientation == "asset_base" else (pair.get("quoteToken") or {}).get("address"),
            "stable_address": (pair.get("quoteToken") or {}).get("address") if orientation == "asset_base" else (pair.get("baseToken") or {}).get("address"),
            "asset_price_usd": asset_price,
            "pair_base_price_usd": raw_pair_price,
            "liquidity_usd": _number((pair.get("liquidity") or {}).get("usd")),
            "volume_24h_usd": _number((pair.get("volume") or {}).get("h24")),
            "price_change_24h_pct": _number((pair.get("priceChange") or {}).get("h24")),
            "observed_at_utc": utc_now(),
            "source_url": pair.get("url") or used_url,
        }
    except Exception as exc:
        return _dex_error("dexscreener", asset, exc)


def _gt_network(row: Dict[str, Any]) -> Optional[str]:
    rel = (((row.get("relationships") or {}).get("network") or {}).get("data") or {}).get("id")
    if rel:
        return _normalize_network(rel)
    row_id = str(row.get("id") or "")
    if "_" in row_id:
        return _normalize_network(row_id.split("_", 1)[0])
    return None


def _gt_name_orientation(asset: str, row: Dict[str, Any]) -> Optional[str]:
    aliases = DEX_ALIASES.get(asset, {asset})
    name = str((row.get("attributes") or {}).get("name") or "").upper().replace("-", "/")
    pieces = [piece.strip().split()[0] for piece in name.split("/")[:2] if piece.strip()]
    if len(pieces) < 2:
        return None
    base, quote = pieces[0], pieces[1]
    if base in aliases and quote in USD_QUOTES:
        return "asset_base"
    if quote in aliases and base in USD_QUOTES:
        return "asset_quote"
    return None

def _best_geckoterminal_pool(asset: str, rows: Iterable[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    candidates = []
    for row in rows or []:
        orientation = _gt_name_orientation(asset, row)
        if not orientation:
            continue
        network = _gt_network(row)
        if not _network_allowed(asset, network):
            continue
        attrs = row.get("attributes") or {}
        reserve = _number(attrs.get("reserve_in_usd")) or 0.0
        candidates.append((reserve, row))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def _gt_relationship_address(row: Dict[str, Any], side: str) -> Optional[str]:
    rel = (((row.get("relationships") or {}).get(side) or {}).get("data") or {}).get("id")
    raw = str(rel or "").strip()
    if not raw:
        return None
    return raw.split("_", 1)[1] if "_" in raw else raw

def _normalize_address(network: Any, address: Any) -> Optional[str]:
    raw = str(address or "").strip()
    if not raw:
        return None
    net = _normalize_network(network)
    if net in {"ethereum", "arbitrum", "base", "optimism", "bsc"}:
        return raw.lower()
    return raw

def _asset_address_from_pair(asset: str, item: Dict[str, Any]) -> Optional[str]:
    side = item.get("asset_side")
    if side == "asset_base":
        return item.get("base_address")
    if side == "asset_quote":
        return item.get("quote_address")
    return item.get("asset_address")

def fetch_geckoterminal(asset: str) -> Dict[str, Any]:
    query = DEX_SEARCH.get(asset, f"{asset}/USDC").replace("/", " ")
    url = "https://api.geckoterminal.com/api/v2/search/pools?" + urllib.parse.urlencode({"query": query, "include": "base_token,quote_token"})
    try:
        with _gt_semaphore:
            payload = _fetch_json(url, {"Accept": "application/json;version=20230203"})
        row = _best_geckoterminal_pool(asset, payload.get("data") or [])
        if not row:
            raise RuntimeError("no alias/stable pool on allowed asset network")
        attrs = row.get("attributes") or {}
        network = _gt_network(row)
        orientation = _gt_name_orientation(asset, row)
        volume = attrs.get("volume_usd") or {}
        change = attrs.get("price_change_percentage") or {}
        base_price = _number(attrs.get("base_token_price_usd"))
        quote_price = _number(attrs.get("quote_token_price_usd"))
        asset_price = base_price if orientation == "asset_base" else quote_price if orientation == "asset_quote" else None
        return {
            "provider": "geckoterminal",
            "asset": asset,
            "status": "ok",
            "context_only": True,
            "identity_proof": False,
            "identity_status": "bounded_chain_alias",
            "identity_level": "CHAIN_ALIAS_ONLY",
            "discovery_method": "pool_search_chain_bounded_highest_reserve_alias_stable",
            "query": query,
            "network": network,
            "network_normalized": network,
            "chain_allowed": True,
            "allowed_networks": sorted(DEX_CHAIN_POLICY.get(asset, set())),
            "asset_side": orientation,
            "pool_address": attrs.get("address") or str(row.get("id") or "").split("_", 1)[-1],
            "base_address": _gt_relationship_address(row, "base_token"),
            "quote_address": _gt_relationship_address(row, "quote_token"),
            "asset_address": _gt_relationship_address(row, "base_token") if orientation == "asset_base" else _gt_relationship_address(row, "quote_token"),
            "stable_address": _gt_relationship_address(row, "quote_token") if orientation == "asset_base" else _gt_relationship_address(row, "base_token"),
            "name": attrs.get("name"),
            "asset_price_usd": asset_price,
            "base_token_price_usd": base_price,
            "quote_token_price_usd": quote_price,
            "reserve_usd": _number(attrs.get("reserve_in_usd")),
            "volume_24h_usd": _number(volume.get("h24")),
            "price_change_24h_pct": _number(change.get("h24")),
            "observed_at_utc": utc_now(),
            "source_url": url,
        }
    except Exception as exc:
        return _dex_error("geckoterminal", asset, exc)


def _context_identity_crosscheck(asset: str, ds: Dict[str, Any], gt: Dict[str, Any]) -> Dict[str, Any]:
    providers = [item for item in (ds, gt) if item.get("status") == "ok"]
    networks = sorted({str(item.get("network_normalized") or "") for item in providers if item.get("network_normalized")})
    ds_liq = _number(ds.get("liquidity_usd")) if ds.get("status") == "ok" else None
    gt_liq = _number(gt.get("reserve_usd")) if gt.get("status") == "ok" else None
    ratio = None
    if ds_liq and gt_liq and ds_liq > 0 and gt_liq > 0:
        ratio = max(ds_liq, gt_liq) / min(ds_liq, gt_liq)
    liquidity_review = bool(ratio is not None and ratio >= LIQUIDITY_RATIO_REVIEW)
    same_network = len(networks) == 1 and len(providers) >= 2
    ds_addr = _normalize_address(ds.get("network_normalized"), _asset_address_from_pair(asset, ds)) if ds.get("status") == "ok" else None
    gt_addr = _normalize_address(gt.get("network_normalized"), _asset_address_from_pair(asset, gt)) if gt.get("status") == "ok" else None
    address_crosscheck_available = bool(same_network and ds_addr and gt_addr)
    address_match = bool(address_crosscheck_available and ds_addr == gt_addr)
    address_mismatch = bool(address_crosscheck_available and ds_addr != gt_addr)
    if address_mismatch:
        state, confidence = "review", "low"
        reason = "inter-provider token address mismatch"
    elif address_match and not liquidity_review:
        state, confidence = "proved", "high"
        reason = "same network + alias/stable + inter-provider token address match"
    elif len(providers) >= 2 and not liquidity_review:
        state, confidence = "bounded", "medium"
        reason = "chain + alias bounded; address cross-check unavailable or cross-network"
    elif providers:
        state, confidence = "review" if liquidity_review else "partial", "low"
        reason = "liquidity anomaly" if liquidity_review else "single-provider bounded discovery"
    else:
        state, confidence, reason = "unavailable", "none", "no bounded provider"
    atlas_eligible = state in {"proved", "bounded"} and not liquidity_review and not address_mismatch
    return {
        "asset": asset,
        "status": state,
        "confidence": confidence,
        "reason": reason,
        "providers_ok": len(providers),
        "networks": networks,
        "multi_chain": len(networks) > 1,
        "liquidity_ratio": ratio,
        "liquidity_review": liquidity_review,
        "address_crosscheck_available": address_crosscheck_available,
        "address_level_proof": address_match,
        "address_match": address_match,
        "address_mismatch": address_mismatch,
        "dexscreener_asset_address": ds_addr,
        "geckoterminal_asset_address": gt_addr,
        "atlas_eligible": atlas_eligible,
        "rule": "PROVED only when both providers expose the same asset token address on the same allowed network; otherwise bounded/partial/review",
    }

def fetch_defillama_context() -> Dict[str, Any]:
    def one(chain: str) -> Dict[str, Any]:
        url = f"https://api.llama.fi/overview/dexs/{urllib.parse.quote(chain)}"
        try:
            payload = _fetch_json(url)
            return {
                "chain": chain,
                "status": "ok",
                "dex_volume_24h_usd": _number(payload.get("total24h")),
                "dex_volume_7d_usd": _number(payload.get("total7d")),
                "change_1d_pct": _number(payload.get("change_1d")),
                "observed_at_utc": utc_now(),
                "source_url": url,
            }
        except Exception as exc:
            return {"chain": chain, "status": "unavailable", "error": str(exc)[:180], "observed_at_utc": utc_now()}

    with ThreadPoolExecutor(max_workers=len(DEFILLAMA_CHAINS)) as pool:
        rows = list(pool.map(one, DEFILLAMA_CHAINS))
    chains = [row for row in rows if row.get("status") == "ok"]
    errors = [row for row in rows if row.get("status") != "ok"]
    return {
        "provider": "defillama",
        "status": "ok" if chains else "unavailable",
        "context_only": True,
        "chains": chains,
        "errors": errors,
        "observed_at_utc": utc_now(),
    }


def context_payload(assets: List[str]) -> Dict[str, Any]:
    cache_key = "context:" + ",".join(assets)
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= CONTEXT_CACHE_TTL_SECONDS:
            payload = dict(cached[1])
            payload["cache"] = {"state": "hit", "ttl_seconds": CONTEXT_CACHE_TTL_SECONDS}
            return payload

    tasks = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for asset in assets:
            tasks.append(pool.submit(fetch_dexscreener, asset))
            tasks.append(pool.submit(fetch_geckoterminal, asset))
        tasks.append(pool.submit(fetch_defillama_context))
        results = [future.result() for future in as_completed(tasks)]

    llama = next((item for item in results if item.get("provider") == "defillama"), {"provider": "defillama", "status": "unavailable", "chains": []})
    rows = []
    for asset in assets:
        ds = next((item for item in results if item.get("provider") == "dexscreener" and item.get("asset") == asset), _dex_error("dexscreener", asset, RuntimeError("missing result")))
        gt = next((item for item in results if item.get("provider") == "geckoterminal" and item.get("asset") == asset), _dex_error("geckoterminal", asset, RuntimeError("missing result")))
        identity = _context_identity_crosscheck(asset, ds, gt)
        rows.append({"asset": asset, "dexscreener": ds, "geckoterminal": gt, "identity": identity})

    payload = {
        "schema": "agent_crypto_private_backend_dex_defi_context_v4",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "context_only": True,
        "observed_at_utc": utc_now(),
        "assets": rows,
        "defillama": llama,
        "cache": {"state": "fresh", "ttl_seconds": CONTEXT_CACHE_TTL_SECONDS},
        "quality": {
            "dexscreener_ok": sum(1 for row in rows if row["dexscreener"].get("status") == "ok"),
            "geckoterminal_ok": sum(1 for row in rows if row["geckoterminal"].get("status") == "ok"),
            "defillama_chains_ok": len(llama.get("chains") or []),
            "identity_proved": sum(1 for row in rows if (row.get("identity") or {}).get("status") == "proved"),
            "identity_bounded": sum(1 for row in rows if (row.get("identity") or {}).get("status") == "bounded"),
            "identity_review": sum(1 for row in rows if (row.get("identity") or {}).get("status") == "review"),
            "liquidity_review": sum(1 for row in rows if (row.get("identity") or {}).get("liquidity_review") is True),
        },
        "provenance": {
            "dexscreener": {"class": "DEX_LIQUIDITY_CONTEXT", "mode": "READ_ONLY_PUBLIC", "identity_proof": False},
            "geckoterminal": {"class": "DEX_POOL_CROSSCHECK", "mode": "READ_ONLY_PUBLIC", "identity_proof": False},
            "defillama": {"class": "DEFI_AGGREGATE_CONTEXT", "mode": "READ_ONLY_PUBLIC", "identity_proof": False},
        },
        "rules": {
            "cex_primary_unchanged": "binance",
            "dex_prices_not_promoted_to_cex_truth": True,
            "symbol_search_is_discovery_not_identity_proof": True,
            "wrong_chain_symbol_collision_rejected": True,
            "address_level_identity_proof": "INTER_PROVIDER_WHEN_AVAILABLE",
            "liquidity_ratio_review_threshold": LIQUIDITY_RATIO_REVIEW,
            "financial_signal": False,
        },
        "identity_policy": {
            "type": "chain_alias_plus_inter_provider_address",
            "asset_networks": {asset: sorted(DEX_CHAIN_POLICY.get(asset, set())) for asset in assets},
            "address_level_proof": "INTER_PROVIDER_WHEN_AVAILABLE",
            "wrapped_assets_explicit": True,
        },
        "disclaimer": "DEX/DeFi context only; bounded identity is not canonical asset proof, price truth, execution or financial recommendation",
    }
    with _cache_lock:
        _cache[cache_key] = (now, payload)
    return payload


def normalize_assets(raw: str) -> List[str]:
    items = [item.strip().upper() for item in (raw or "").split(",") if item.strip()]
    if not items:
        items = list(DEFAULT_ASSETS)
    allowed = []
    for asset in items:
        if not asset.replace("_", "").isalnum() or len(asset) > 16:
            continue
        if asset not in allowed:
            allowed.append(asset)
        if len(allowed) >= MAX_ASSETS:
            break
    return allowed


def quotes_payload(assets: List[str]) -> Dict[str, Any]:
    cache_key = "quotes:" + ",".join(assets)
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= CACHE_TTL_SECONDS:
            payload = dict(cached[1])
            payload["cache"] = {"state": "hit", "ttl_seconds": CACHE_TTL_SECONDS}
            return payload

    tasks = []
    with ThreadPoolExecutor(max_workers=min(6, max(1, len(assets) * 3))) as pool:
        for asset in assets:
            tasks.append(pool.submit(fetch_kraken, asset))
            tasks.append(pool.submit(fetch_coinbase, asset))
            tasks.append(pool.submit(fetch_okx, asset))
        results = [future.result() for future in as_completed(tasks)]

    rows = []
    for asset in assets:
        quotes = sorted((q for q in results if q.get("asset") == asset), key=lambda q: q.get("provider", ""))
        rows.append({"asset": asset, "quotes": quotes, "consensus": _consensus(quotes)})

    providers_ok = len({q.get("provider") for q in results if q.get("status") == "ok"})
    quotes_ok = sum(1 for q in results if q.get("status") == "ok")
    payload = {
        "schema": "agent_crypto_private_backend_quotes_v1",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "observed_at_utc": utc_now(),
        "assets": rows,
        "summary": {"assets": len(assets), "quotes_ok": quotes_ok, "quotes_total": len(results), "providers_ok": providers_ok},
        "thresholds": {"coherent_pct": COHERENT_PCT, "watch_pct": WATCH_PCT},
        "cache": {"state": "fresh", "ttl_seconds": CACHE_TTL_SECONDS},
        "disclaimer": "technical source concordance only; no execution or financial recommendation",
    }
    with _cache_lock:
        _cache[cache_key] = (now, payload)
    return payload



# 1.4.1 — local read-only Windows system telemetry for the Aether operator lane.
# No control/action endpoint is added. GPU is read only through nvidia-smi when present.
class _FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", ctypes.c_uint32), ("dwHighDateTime", ctypes.c_uint32)]


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_uint32),
        ("dwMemoryLoad", ctypes.c_uint32),
        ("ullTotalPhys", ctypes.c_uint64),
        ("ullAvailPhys", ctypes.c_uint64),
        ("ullTotalPageFile", ctypes.c_uint64),
        ("ullAvailPageFile", ctypes.c_uint64),
        ("ullTotalVirtual", ctypes.c_uint64),
        ("ullAvailVirtual", ctypes.c_uint64),
        ("ullAvailExtendedVirtual", ctypes.c_uint64),
    ]


def _filetime_value(value: _FILETIME) -> int:
    return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)


def _windows_cpu_sample() -> Optional[Tuple[int, int, int]]:
    if os.name != "nt":
        return None
    try:
        idle, kernel, user = _FILETIME(), _FILETIME(), _FILETIME()
        ok = ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user))
        if not ok:
            return None
        return (_filetime_value(idle), _filetime_value(kernel), _filetime_value(user))
    except Exception:
        return None


def _cpu_percent() -> Optional[float]:
    global _cpu_sample
    current = _windows_cpu_sample()
    if current is None:
        return None
    previous = _cpu_sample
    if previous is None:
        _cpu_sample = current
        time.sleep(0.08)
        current = _windows_cpu_sample()
        previous = _cpu_sample
        if current is None or previous is None:
            return None
    _cpu_sample = current
    idle_delta = current[0] - previous[0]
    kernel_delta = current[1] - previous[1]
    user_delta = current[2] - previous[2]
    total = kernel_delta + user_delta
    if total <= 0:
        return None
    busy = max(0, total - idle_delta)
    return max(0.0, min(100.0, busy / total * 100.0))


def _memory_snapshot() -> Dict[str, Any]:
    if os.name != "nt":
        return {"usage_pct": None, "used_gb": None, "total_gb": None, "available_gb": None}
    try:
        status = _MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            raise OSError("GlobalMemoryStatusEx failed")
        total = int(status.ullTotalPhys)
        available = int(status.ullAvailPhys)
        used = max(0, total - available)
        gib = 1024 ** 3
        return {
            "usage_pct": round((used / total * 100.0), 1) if total else None,
            "used_gb": round(used / gib, 2),
            "total_gb": round(total / gib, 2),
            "available_gb": round(available / gib, 2),
        }
    except Exception:
        return {"usage_pct": None, "used_gb": None, "total_gb": None, "available_gb": None}


def _gpu_snapshot() -> Dict[str, Any]:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return {"status": "unavailable", "name": None, "usage_pct": None, "temperature_c": None, "memory_used_mb": None, "memory_total_mb": None}
    try:
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        result = subprocess.run(
            [exe, "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=1.4,
            check=False,
            creationflags=creationflags,
        )
        if result.returncode != 0 or not result.stdout.strip():
            raise RuntimeError((result.stderr or "nvidia-smi unavailable").strip()[:160])
        row = [part.strip() for part in result.stdout.splitlines()[0].split(",")]
        if len(row) < 5:
            raise RuntimeError("unexpected nvidia-smi output")
        return {
            "status": "ok",
            "name": row[0] or None,
            "usage_pct": _number(row[1]),
            "temperature_c": _number(row[2]),
            "memory_used_mb": _number(row[3]),
            "memory_total_mb": _number(row[4]),
        }
    except Exception as exc:
        return {"status": "unavailable", "name": None, "usage_pct": None, "temperature_c": None, "memory_used_mb": None, "memory_total_mb": None, "error": str(exc)[:160]}


def system_payload(force: bool = False) -> Dict[str, Any]:
    global _system_cache
    now = time.time()
    with _system_lock:
        cached_at, cached = _system_cache
        if not force and cached and now - cached_at < SYSTEM_CACHE_TTL_SECONDS:
            return {**cached, "cache": {"state": "cached", "ttl_seconds": SYSTEM_CACHE_TTL_SECONDS}}
        cpu_pct = _cpu_percent()
        memory = _memory_snapshot()
        gpu = _gpu_snapshot()
        payload = {
            "schema": "agent_crypto_private_backend_system_v1",
            "backend_version": VERSION,
            "build": BUILD,
            "read_only": True,
            "observed_at_utc": utc_now(),
            "platform": {"system": platform.system(), "release": platform.release(), "machine": platform.machine()},
            "cpu": {"name": platform.processor() or None, "usage_pct": round(cpu_pct, 1) if cpu_pct is not None else None, "temperature_c": None},
            "gpu": gpu,
            "memory": memory,
            "cache": {"state": "fresh", "ttl_seconds": SYSTEM_CACHE_TTL_SECONDS},
            "capabilities": ["cpu_usage_read", "memory_usage_read", "nvidia_gpu_read_if_available"],
            "forbidden": ["process_kill", "clock_change", "power_control", "fan_control", "overclock", "gpu_control", "filesystem_write"],
        }
        _system_cache = (now, payload)
        return payload


class Handler(BaseHTTPRequestHandler):
    server_version = f"AgentCryptoPrivateBackend/{VERSION}"

    def log_message(self, fmt: str, *args: Any) -> None:
        if not QUIET:
            print(f"[{utc_now()}] {self.client_address[0]} {fmt % args}")

    def _origin(self) -> Optional[str]:
        origin = self.headers.get("Origin")
        return origin if origin in ALLOWED_ORIGINS else None

    def _headers(self, status: int = 200, content_type: str = "application/json; charset=utf-8") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Agent-Crypto-Read-Only", "true")
        origin = self._origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Accept, Content-Type")
        self.end_headers()

    def _json(self, payload: Any, status: int = 200, head: bool = False) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self._headers(status)
        if not head:
            self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        self._headers(HTTPStatus.NO_CONTENT)

    def do_HEAD(self) -> None:
        self._route(head=True)

    def do_GET(self) -> None:
        self._route(head=False)

    def _blocked(self) -> None:
        self._json({"error": "read_only_backend", "allowed_methods": ["GET", "HEAD", "OPTIONS"]}, HTTPStatus.METHOD_NOT_ALLOWED)

    do_POST = _blocked
    do_PUT = _blocked
    do_PATCH = _blocked
    do_DELETE = _blocked

    def _route(self, head: bool) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/health":
            self._json({
                "schema": "agent_crypto_private_backend_health_v1",
                "status": "ready",
                "version": VERSION,
                "build": BUILD,
                "read_only": True,
                "host": HOST,
                "port": PORT,
                "cache_ttl_seconds": CACHE_TTL_SECONDS,
                "orderbook_cache_ttl_seconds": ORDERBOOK_CACHE_TTL_SECONDS,
                "okx_transport_cache_ttl_seconds": OKX_TRANSPORT_CACHE_TTL_SECONDS,
                "context_cache_ttl_seconds": CONTEXT_CACHE_TTL_SECONDS,
                "sources": list(SOURCE_REGISTRY),
                "capabilities": ["public_market_read", "source_registry", "bounded_cache", "provenance", "concordance", "dex_liquidity_context", "defi_aggregate_context", "source_intelligence_contract", "dex_identity_chain_gate", "dex_inter_provider_address_crosscheck", "atlas_eligibility_gate", "liquidity_anomaly_review", "local_system_telemetry_read", "okx_spot_eur_orderbook_read", "okx_multi_level_depth_read", "okx_public_candles_read", "okx_public_microstructure_read", "okx_public_allowlisted_proxy", "market_instrument_resolver", "market_candles_multi_provider", "market_book_multi_provider", "browser_local_transport"],
                "forbidden": ["orders", "trading", "wallet", "withdrawal", "seed", "signature", "exchange_private_api"],
            }, head=head)
            return
        if parsed.path == "/sources":
            self._json({"read_only": True, "sources": list(SOURCE_REGISTRY)}, head=head)
            return
        if parsed.path == "/system":
            self._json(system_payload(), head=head)
            return
        if parsed.path == "/quotes":
            query = urllib.parse.parse_qs(parsed.query)
            assets = normalize_assets((query.get("assets") or [""])[0])
            self._json(quotes_payload(assets), head=head)
            return
        if parsed.path == "/orderbook":
            query = urllib.parse.parse_qs(parsed.query)
            asset = str((query.get("asset") or ["BTC"])[0]).strip().upper()
            depth = _normalize_book_depth((query.get("depth") or ["100"])[0])
            try:
                self._json(okx_orderbook_payload(asset, depth), head=head)
            except ValueError as exc:
                self._json({"error": "invalid_request", "detail": str(exc), "supported_assets": list(OKX_INSTRUMENTS)}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"schema": "agent_crypto_private_backend_orderbook_v1", "backend_version": VERSION, "build": BUILD, "read_only": True, "provider": "okx", "asset": asset, "pair": OKX_INSTRUMENTS.get(asset), "status": "unavailable", "error": str(exc)[:180], "observed_at_utc": utc_now()}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/market-resolve":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                self._json(market_resolve_payload((query.get("asset") or ["BTC"])[0], (query.get("currency") or ["USD"])[0]), head=head)
            except ValueError as exc:
                self._json({"schema":"agent_crypto_market_instrument_resolver_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"invalid", "error":str(exc)}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"schema":"agent_crypto_market_instrument_resolver_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"unavailable", "error":str(exc)[:180]}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/market-candles":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                self._json(market_candles_payload((query.get("provider") or [""])[0], (query.get("instrument") or [""])[0], (query.get("bar") or ["15m"])[0], (query.get("limit") or ["300"])[0]), head=head)
            except ValueError as exc:
                self._json({"schema":"agent_crypto_market_candles_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"invalid", "error":str(exc)}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"schema":"agent_crypto_market_candles_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"unavailable", "error":str(exc)[:180]}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/market-book":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                self._json(market_book_payload((query.get("provider") or [""])[0], (query.get("instrument") or [""])[0], (query.get("limit") or ["100"])[0]), head=head)
            except ValueError as exc:
                self._json({"schema":"agent_crypto_market_book_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"invalid", "error":str(exc)}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"schema":"agent_crypto_market_book_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"unavailable", "error":str(exc)[:180]}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/okx-public":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                self._json(okx_public_proxy_payload((query.get("endpoint") or [""])[0], query), head=head)
            except ValueError as exc:
                self._json({"code":"51000", "msg":str(exc), "data":[]}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"code":"59999", "msg":str(exc)[:180], "data":[]}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/candles":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                self._json(okx_candles_payload((query.get("asset") or ["BTC"])[0], (query.get("quote") or ["EUR"])[0], (query.get("bar") or ["15m"])[0], (query.get("limit") or ["300"])[0]), head=head)
            except ValueError as exc:
                self._json({"error":"invalid_request", "detail":str(exc)}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"schema":"agent_crypto_private_backend_okx_candles_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"unavailable", "error":str(exc)[:180], "observed_at_utc":utc_now()}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/microstructure":
            query = urllib.parse.parse_qs(parsed.query)
            try:
                payload = okx_microstructure_payload((query.get("asset") or ["BTC"])[0], (query.get("quote") or ["EUR"])[0], (query.get("depth") or ["20"])[0], (query.get("trades") or ["20"])[0])
                status = 200 if payload.get("status") in {"ok","partial"} else HTTPStatus.BAD_GATEWAY
                self._json(payload, status, head=head)
            except ValueError as exc:
                self._json({"error":"invalid_request", "detail":str(exc)}, HTTPStatus.BAD_REQUEST, head=head)
            except Exception as exc:
                self._json({"schema":"agent_crypto_private_backend_okx_microstructure_v1", "backend_version":VERSION, "build":BUILD, "read_only":True, "status":"unavailable", "error":str(exc)[:180], "observed_at_utc":utc_now()}, HTTPStatus.BAD_GATEWAY, head=head)
            return
        if parsed.path == "/context":
            query = urllib.parse.parse_qs(parsed.query)
            assets = normalize_assets((query.get("assets") or [""])[0])
            self._json(context_payload(assets), head=head)
            return
        self._json({"error": "not_found", "routes": ["/health", "/sources", "/system", "/quotes?assets=BTC,ETH,BNB,XRP,SOL", "/orderbook?asset=BTC&depth=100", "/market-resolve?asset=OKB&currency=USD", "/market-candles?provider=okx&instrument=OKB-USDC&bar=15m&limit=300", "/market-book?provider=okx&instrument=OKB-USDC&limit=100", "/okx-public?endpoint=candles&instId=BTC-EUR&bar=15m&limit=300", "/candles?asset=BTC&quote=EUR&bar=15m&limit=300", "/microstructure?asset=BTC&quote=EUR&depth=20&trades=20", "/context?assets=BTC,ETH,BNB,XRP,SOL"]}, HTTPStatus.NOT_FOUND, head=head)


def self_test() -> int:
    kraken_fixture = {"error": [], "result": {"XXBTZEUR": {"a": ["100.2", "1", "1"], "b": ["99.8", "1", "1"], "c": ["100.0", "0.1"], "v": ["2", "3"]}}}
    coinbase_fixture = {"open": "95", "high": "105", "low": "90", "volume": "12", "last": "100.1"}
    okx_fixture = {"code":"0","msg":"","data":[{"instType":"SPOT","instId":"BTC-EUR","last":"100.05","askPx":"100.06","bidPx":"100.04","vol24h":"9.5","volCcy24h":"950.0","ts":"1708669508505"}]}
    okx_book_fixture = {"code":"0","msg":"","data":[{"asks":[["100.10","0.50","0","1"],["100.20","1.00","0","2"]],"bids":[["99.90","0.40","0","1"],["99.80","1.20","0","2"]],"ts":"1708669508505"}]}
    assert _number(kraken_fixture["result"]["XXBTZEUR"]["c"][0]) == 100.0
    assert _number(coinbase_fixture["last"]) == 100.1
    assert _number(okx_fixture["data"][0]["last"]) == 100.05
    assert _utc_from_unix_ms(okx_fixture["data"][0]["ts"]).endswith("Z")
    parsed_book = _parse_okx_orderbook_payload(okx_book_fixture, "BTC", "BTC-EUR", 100, "https://example.invalid/books")
    assert parsed_book["read_only"] is True and parsed_book["provider"] == "okx"
    assert parsed_book["best_bid_eur"] == 99.9 and parsed_book["best_ask_eur"] == 100.1
    assert parsed_book["levels"] == {"bids": 2, "asks": 2}
    assert _normalize_book_depth(999) == 400 and _normalize_book_depth(0) == 1
    assert _normalize_okx_public_instrument("OKB-USDC") == "OKB-USDC"
    assert _normalize_okx_public_instrument("okb/usdt") == "OKB-USDT"
    assert _okx_public_instrument("OKB", "USD")[2] == "OKB-USDC"
    assert _okx_public_instrument("OKB", "USDT")[2] == "OKB-USDT"
    try:
        _normalize_okx_public_instrument("OKB-BTC")
        raise AssertionError("unsupported quote accepted")
    except ValueError:
        pass
    try:
        _normalize_okx_public_instrument("OKB-USDC&evil=1")
        raise AssertionError("unsafe instrument accepted")
    except ValueError:
        pass
    matches_fixture = [
        _market_match("binance", "OKB", "USDT", "OKB-USDT", ("candles", "ticker")),
        _market_match("okx", "OKB", "USDC", "OKB-USDC", ("candles", "book", "ticker")),
    ]
    assert _market_choose(matches_fixture, "candles", "USD")["instrument"] == "OKB-USDC"
    assert _market_choose(matches_fixture, "book", "USD")["provider"] == "okx"
    bitget_only = [_market_match("bitget", "BTW", "USDT", "BTW-USDT", ("candles", "book", "ticker"))]
    assert _market_choose(bitget_only, "candles", "USD")["instrument"] == "BTW-USDT"
    assert _market_choose(bitget_only, "book", "USD")["provider"] == "bitget"
    binance_only = [_market_match("binance", "TEST", "USDT", "TEST-USDT", ("candles", "ticker"))]
    assert _market_choose(binance_only, "candles", "USD")["instrument"] == "TEST-USDT"
    assert _market_choose(binance_only, "book", "USD") is None
    fake_binance = [[1700000000000, "1", "2", "0.5", "1.5", "10", 0, 0, 0, 0, 0, 0]]
    assert fake_binance[0][1:6] == ["1", "2", "0.5", "1.5", "10"]
    c = _consensus([{"status": "ok", "price_eur": 100.0}, {"status": "ok", "price_eur": 100.1}, {"status": "ok", "price_eur": 100.05}])
    assert c["verdict"] == "coherent" and c["providers"] == 3
    ds_fixture = [{"chainId":"ethereum","baseToken":{"symbol":"WETH","address":"0xWETH"},"quoteToken":{"symbol":"USDC","address":"0xUSDC"},"liquidity":{"usd":123456},"priceUsd":"2100"}]
    assert _best_dexscreener_pair("ETH", ds_fixture)["priceUsd"] == "2100"
    ds_reverse = [{"chainId":"ethereum","baseToken":{"symbol":"USDC"},"quoteToken":{"symbol":"WETH"},"liquidity":{"usd":999999},"priceUsd":"1"}]
    assert _best_dexscreener_pair("ETH", ds_reverse) is not None
    assert _dexscreener_pair_orientation("ETH", ds_reverse[0]) == "asset_quote"
    ds_wrong_chain = [{"chainId":"solana","baseToken":{"symbol":"WETH"},"quoteToken":{"symbol":"USDC"},"liquidity":{"usd":9_000_000_000},"priceUsd":"2100"}]
    assert _best_dexscreener_pair("ETH", ds_wrong_chain) is None
    ds_mixed = ds_wrong_chain + [{"chainId":"ethereum","baseToken":{"symbol":"WETH"},"quoteToken":{"symbol":"USDC"},"liquidity":{"usd":2_000_000},"priceUsd":"2100"}]
    assert _best_dexscreener_pair("ETH", ds_mixed)["chainId"] == "ethereum"
    gt_fixture = [{"id":"eth_0xpool","attributes":{"name":"WETH / USDC","reserve_in_usd":"654321","base_token_price_usd":"2100","quote_token_price_usd":"1"},"relationships":{"base_token":{"data":{"id":"eth_0xWETH"}},"quote_token":{"data":{"id":"eth_0xUSDC"}}}}]
    assert _best_geckoterminal_pool("ETH", gt_fixture)["attributes"]["base_token_price_usd"] == "2100"
    gt_wrong_chain = [{"id":"solana_fake","attributes":{"name":"WETH / USDC","reserve_in_usd":"9999999999","base_token_price_usd":"2100"}}]
    assert _best_geckoterminal_pool("ETH", gt_wrong_chain) is None
    gt_mixed = gt_wrong_chain + gt_fixture
    assert _gt_network(_best_geckoterminal_pool("ETH", gt_mixed)) == "ethereum"
    identity = _context_identity_crosscheck("ETH",
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","liquidity_usd":1_000_000},
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","reserve_usd":1_200_000})
    assert identity["status"] == "proved" and identity["address_level_proof"] is True and identity["atlas_eligible"] is True
    anomaly = _context_identity_crosscheck("ETH",
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","liquidity_usd":100_000_000},
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","reserve_usd":1_000_000})
    assert anomaly["status"] == "review" and anomaly["liquidity_review"] is True
    mismatch = _context_identity_crosscheck("ETH", {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xAAA","liquidity_usd":1_000_000}, {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xBBB","reserve_usd":1_100_000})
    assert mismatch["status"] == "review" and mismatch["address_mismatch"] is True and mismatch["atlas_eligible"] is False
    assert normalize_assets("btc,eth,btc") == ["BTC", "ETH"]
    system = system_payload(force=True)
    assert system["read_only"] is True and system["schema"] == "agent_crypto_private_backend_system_v1"
    assert set(["cpu", "gpu", "memory"]).issubset(system)
    assert "orders" in {item for item in ["orders", "trading", "wallet"]}
    print("SELF-TEST PASS")
    print(f"version={VERSION} build={BUILD} read_only=true sources={len(SOURCE_REGISTRY)}")
    print("routes=/health,/sources,/system,/quotes,/orderbook,/market-resolve,/market-candles,/market-book,/okx-public,/candles,/microstructure,/context ; Kraken + Coinbase + OKX + Bitget + Binance public resolver controls ; dynamic candles via local transport ; address-crosschecked DEX identity + source-intelligence contract via public client ; write methods blocked")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Agent-Crypto private local backend — read-only public sources")
    parser.add_argument("--host", default=HOST)
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--quiet", action="store_true", help="suppress request/startup console logs")
    args = parser.parse_args()
    global QUIET
    QUIET = bool(args.quiet)
    if args.self_test:
        return self_test()
    if args.host not in {"127.0.0.1", "localhost"}:
        raise SystemExit("Refusing non-loopback bind: use 127.0.0.1 or localhost")
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    if not QUIET:
        print(f"Agent-Crypto Private Backend V{VERSION} · Build {BUILD}")
        print(f"READ ONLY · http://{args.host}:{args.port} · Kraken + Coinbase + OKX + Binance resolver + multi-provider candles + DEX/DeFi public context + /system")
        print("No API key · no wallet · no order endpoint · Ctrl+C to stop")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
