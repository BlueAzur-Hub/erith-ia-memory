#!/usr/bin/env python3
from __future__ import annotations
import json, time, urllib.parse, urllib.request, urllib.error
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
from datetime import datetime

BRIDGE = "http://127.0.0.1:8791"
OKX = "https://eea.okx.com"
INST = "BTC-EUR"
SERVICE = "ERITH_OKX_DEMO_BRIDGE_V2"

ATTEMPTS = 10
TIMEOUT_S = 60
CHECKPOINTS = (2, 5, 10, 20, 30, 45, 60)
TARGET_EUR = Decimal("10")

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
LOG = ROOT / "post_only_fill_lab_v4.log"

def log(msg=""):
    print(msg, flush=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")

def req(method, url, body=None, timeout=20):
    data = None
    headers = {"Content-Type":"application/json", "User-Agent":"ERITH-POSTONLY-FILL-LAB-V4"}
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as x:
            return x.status, json.loads(x.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            obj = json.loads(raw)
        except Exception:
            obj = {"raw": raw}
        return e.code, obj

def D(x): return Decimal(str(x))

def ceil_step(v: Decimal, step: Decimal) -> Decimal:
    return (v / step).to_integral_value(rounding=ROUND_CEILING) * step

def get_health():
    s, h = req("GET", BRIDGE + "/health")
    if s != 200 or not h.get("ok") or not h.get("demo") or h.get("service") != SERVICE:
        raise RuntimeError(f"Mauvais Bridge: HTTP {s} · {h}")
    return h

def get_market():
    q = urllib.parse.urlencode({"instId": INST})
    s1, t = req("GET", OKX + "/api/v5/market/ticker?" + q)
    if s1 != 200 or str(t.get("code")) != "0" or not t.get("data"):
        raise RuntimeError(f"Ticker indisponible: HTTP {s1} · {t}")

    q2 = urllib.parse.urlencode({"instType":"SPOT", "instId":INST})
    s2, i = req("GET", OKX + "/api/v5/public/instruments?" + q2)
    if s2 != 200 or str(i.get("code")) != "0" or not i.get("data"):
        raise RuntimeError(f"Instrument indisponible: HTTP {s2} · {i}")

    q3 = urllib.parse.urlencode({"instId": INST, "sz": "5"})
    s3, b = req("GET", OKX + "/api/v5/market/books?" + q3)
    if s3 != 200 or str(b.get("code")) != "0" or not b.get("data"):
        raise RuntimeError(f"Orderbook indisponible: HTTP {s3} · {b}")

    return t["data"][0], i["data"][0], b["data"][0]

def get_order(ord_id):
    q = urllib.parse.urlencode({"ordId": ord_id})
    s, o = req("GET", BRIDGE + "/demo/order?" + q)
    if s != 200 or str(o.get("code")) != "0" or not o.get("data"):
        raise RuntimeError(f"Lecture ordre impossible: HTTP {s} · {o}")
    return o["data"][0]

def cancel_order(ord_id):
    s, c = req("POST", BRIDGE + "/demo/cancel", {"ordId": ord_id})
    if s != 200 or str(c.get("code")) != "0":
        raise RuntimeError(f"Annulation impossible: HTTP {s} · {c}")
    return c

def one_attempt(n):
    ticker, inst, book = get_market()

    bid = D(ticker["bidPx"])
    ask = D(ticker["askPx"])
    tick = D(inst["tickSz"])
    lot = D(inst["lotSz"])
    min_sz = D(inst["minSz"])

    if bid <= 0 or ask <= 0 or bid >= ask:
        raise RuntimeError(f"Marché non exploitable pour post-only: bid={bid} ask={ask}")

    # BEST BID, pas bid - tick.
    px = bid
    raw_sz = TARGET_EUR / px
    sz = ceil_step(raw_sz, lot)
    if sz < min_sz:
        sz = min_sz

    pxs = format(px, "f")
    szs = format(sz, "f")

    best_bid_depth = None
    bids = book.get("bids") or []
    if bids:
        best_bid_depth = bids[0][1]

    log("")
    log(f"--- ESSAI {n}/{ATTEMPTS} ---")
    log(f"[MARKET] bid={bid} ask={ask} spread={ask-bid} tick={tick}")
    log(f"[BOOK] best_bid_depth={best_bid_depth}")
    log(f"[ORDER] BUY POST_ONLY @ BEST BID · px={pxs} · sz={szs}")

    s, placed = req("POST", BRIDGE + "/demo/post-only", {"side":"buy","px":pxs,"sz":szs})
    if s != 200 or str(placed.get("code")) != "0" or not placed.get("data"):
        raise RuntimeError(f"Ordre refusé: HTTP {s} · {placed}")

    row = placed["data"][0]
    if str(row.get("sCode","0")) != "0":
        raise RuntimeError(f"OKX sCode={row.get('sCode')} · {row.get('sMsg')}")

    ord_id = str(row.get("ordId","")).strip()
    if not ord_id:
        raise RuntimeError("ordId absent")

    log(f"[PLACED] ordId={ord_id}")

    snaps = []
    elapsed = 0
    terminal = False

    for target in CHECKPOINTS:
        time.sleep(target - elapsed)
        elapsed = target
        d = get_order(ord_id)
        snap = {
            "after_s": target,
            "state": d.get("state"),
            "accFillSz": d.get("accFillSz"),
            "avgPx": d.get("avgPx"),
            "fee": d.get("fee"),
            "feeCcy": d.get("feeCcy"),
            "uTime": d.get("uTime"),
        }
        snaps.append(snap)
        log(f"[T+{target}] state={snap['state']} fill={snap['accFillSz']} avgPx={snap['avgPx']} fee={snap['fee']} {snap['feeCcy']}")
        if snap["state"] in ("filled", "canceled"):
            terminal = True
            break

    d = get_order(ord_id)
    if d.get("state") in ("live", "partially_filled"):
        log(f"[CANCEL] state={d.get('state')} après {elapsed}s")
        cancel_order(ord_id)
        time.sleep(2)

    final = get_order(ord_id)

    result = {
        "attempt": n,
        "submitted_at": datetime.now().isoformat(timespec="seconds"),
        "market": {
            "bid": str(bid),
            "ask": str(ask),
            "spread": str(ask-bid),
            "tickSz": str(tick),
            "lotSz": str(lot),
            "minSz": str(min_sz),
            "best_bid_depth": best_bid_depth,
        },
        "order": {
            "side": "buy",
            "ordType": "post_only",
            "px": pxs,
            "sz": szs,
            "ordId": ord_id,
        },
        "snapshots": snaps,
        "final": {
            "state": final.get("state"),
            "accFillSz": final.get("accFillSz"),
            "avgPx": final.get("avgPx"),
            "fee": final.get("fee"),
            "feeCcy": final.get("feeCcy"),
            "cTime": final.get("cTime"),
            "uTime": final.get("uTime"),
        }
    }
    return result

def summarize(results):
    filled = 0
    partial = 0
    nofill = 0
    fill_times = []

    for r in results:
        fsz = D(r["final"].get("accFillSz") or "0")
        osz = D(r["order"]["sz"])
        if fsz <= 0:
            nofill += 1
        elif fsz < osz:
            partial += 1
        else:
            filled += 1

        if fsz > 0:
            for s in r["snapshots"]:
                if D(s.get("accFillSz") or "0") > 0:
                    fill_times.append(s["after_s"])
                    break

    return {
        "attempts": len(results),
        "filled": filled,
        "partial": partial,
        "no_fill": nofill,
        "fill_rate_pct": round((filled + partial) * 100 / len(results), 2) if results else 0,
        "full_fill_rate_pct": round(filled * 100 / len(results), 2) if results else 0,
        "first_fill_times_s": fill_times,
        "first_fill_median_s": sorted(fill_times)[len(fill_times)//2] if fill_times else None,
    }

def main():
    LOG.write_text("", encoding="utf-8")
    REPORTS.mkdir(exist_ok=True)

    log("="*64)
    log("ERITH · OKX DEMO · POST-ONLY FILL LAB V4")
    log("="*64)

    h = get_health()
    log(f"[OK] Bridge={h.get('service')} · {h.get('bind')}")
    log(f"[OK] {ATTEMPTS} essais · best bid · timeout {TIMEOUT_S}s · ~{TARGET_EUR} EUR")

    results = []
    for n in range(1, ATTEMPTS + 1):
        try:
            r = one_attempt(n)
            results.append(r)
        except Exception as e:
            log(f"[ESSAI {n}] ERREUR: {type(e).__name__}: {e}")
            results.append({"attempt": n, "error": f"{type(e).__name__}: {e}"})
        time.sleep(3)

    valid = [r for r in results if "error" not in r]
    summary = summarize(valid)

    report = {
        "lab": "POST_ONLY_FILL_LAB_V4",
        "mode": "OKX_DEMO",
        "instrument": INST,
        "attempts_requested": ATTEMPTS,
        "timeout_s": TIMEOUT_S,
        "placement": "BEST_BID",
        "target_eur": str(TARGET_EUR),
        "summary": summary,
        "results": results,
    }

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = REPORTS / f"post_only_fill_lab_v4_{stamp}.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    log("")
    log("=================== BILAN ===================")
    log(f"attempts={summary['attempts']}")
    log(f"filled={summary['filled']}")
    log(f"partial={summary['partial']}")
    log(f"no_fill={summary['no_fill']}")
    log(f"fill_rate_pct={summary['fill_rate_pct']}")
    log(f"full_fill_rate_pct={summary['full_fill_rate_pct']}")
    log(f"first_fill_median_s={summary['first_fill_median_s']}")
    log(f"rapport={path}")
    log("=============================================")

if __name__ == "__main__":
    code = 0
    try:
        main()
    except Exception as e:
        code = 1
        log("")
        log("!!!!!!!! ERREUR LAB !!!!!!!!")
        log(f"{type(e).__name__}: {e}")
        log(f"log={LOG}")
    finally:
        print()
        input("Entrée pour fermer...")
    raise SystemExit(code)
