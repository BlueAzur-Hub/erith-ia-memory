@echo off
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY FILL LAB V4
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0POST_ONLY_FILL_LAB_V4.py"
) else (
  python "%~dp0POST_ONLY_FILL_LAB_V4.py"
)
echo.
pause
