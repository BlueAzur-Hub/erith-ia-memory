AGENT-CRYPTO 40.6.248 — PATCH ZIP

Targeted Decision Intelligence repair only.
Canonical GitHub repository remains authoritative for the complete Administrator build.
