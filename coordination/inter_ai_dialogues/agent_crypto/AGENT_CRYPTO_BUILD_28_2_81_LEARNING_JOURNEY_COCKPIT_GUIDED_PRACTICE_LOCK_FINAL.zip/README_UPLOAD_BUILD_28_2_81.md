# UPLOAD — AGENT-CRYPTO BUILD 28.2.81

## Version

**Market Core V2.0-Alpha · Build 28.2.81 — LEARNING JOURNEY COCKPIT & GUIDED PRACTICE LOCK**

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Ne supprimer aucun autre fichier.

## SHA-256 des fichiers

```text
app.js
8f809ef50614e7e2f9d93a258c11389be27aa2267175f4b498014ddad25233e0

index.html
9e0f3856a9180cf9a1560aad69eac6c5171159423029ad7c4f64e9458d4f5b6b

style.css
d71dc1b3552793628ac9554d25d0af6039b2b7aa57da7a4955a53707b0493344

version.json
c45b5a95af25e56033eb8e9c4cf127febfccf855f60054ad412c586f8ef16f97
```

## Validation après upload

1. Attendre la publication GitHub Pages.
2. Recharger complètement Firefox avec `Ctrl + F5`.
3. Vérifier `Build 28.2.81` dans l’en-tête et le pied de page.
4. Ouvrir `Administration → Simulation`.
5. Vérifier le Cockpit d’apprentissage avant le parcours expert.
6. Contrôler le profil actif 1 000 € puis le profil 100 €.
7. Tester `Continuer mon parcours` et `Ouvrir l’exercice`.
8. Tester les aides `Désactivées`, `Courtes` et `Détaillées`.
9. Cocher une étape, écrire une note, terminer puis exporter la session.
10. Vérifier les positions, frais, scénarios, Security Gate, retrait fictif, Scam Sentinel et Transaction Proof Ledger.
11. Contrôler Crypto, Métaux, Decision Board et Bridge.

## Retour attendu

- captures du Cockpit ;
- comportement des raccourcis ;
- persistance des étapes et notes après rechargement ;
- confort des aides courtes ;
- toute anomalie visible ou fonctionnelle.

## Commit

Utiliser le texte complet de `GITHUB_COMMIT_BUILD_28_2_81.txt`.

Aucune écriture GitHub n’a été effectuée par l’assistante.
