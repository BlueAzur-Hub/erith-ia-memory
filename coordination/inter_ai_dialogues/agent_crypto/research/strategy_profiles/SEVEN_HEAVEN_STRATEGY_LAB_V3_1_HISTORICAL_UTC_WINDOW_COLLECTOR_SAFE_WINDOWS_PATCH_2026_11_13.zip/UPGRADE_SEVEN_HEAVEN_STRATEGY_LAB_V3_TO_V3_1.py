"""Safe, offline, source-pinned V3.0 -> V3.1 patch.

Run from the existing V3 application root after stopping port 8777.
Never touches workspace, keys, profiles, trade routes, or public repositories.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import shutil
import socket
import sys
import tempfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
FILES = {
    "src/okx_public.py": "8ef88c5cc84cde2e789e5312b4ad379c15ceb",
    "src/server.py": "252c392f0be2795ef1eb8f4bf8f174cf85b6ac2e",
    "web/app.js": "f0eb3eadb0c34ab91e4cb18fa15d6e1d031e7a51",
    "web/index.html": "e05c7d49ed8016dd043a8a276452500cf22f7736",
}
BACKUP = ROOT / "backup_seven_heaven_strategy_lab_before_v3_1"


def replace_one(text: str, old: str, new: str, name: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"Ancrage {name} attendu une fois ; trouvé {count}. Aucun changement appliqué.")
    return text.replace(old, new, 1)


def git_blob_sha(payload: bytes) -> str:
    return hashlib.sha1(f"blob {len(payload)}\0".encode("ascii") + payload).hexdigest()


def patch_okx(src: str) -> str:
    src = replace_one(src,
        "def collect(workspace: Path, pair: str, *, transport=None, now=None, min_free_bytes=MIN_FREE_BYTES):",
        "def collect(workspace: Path, pair: str, *, transport=None, now=None, min_free_bytes=MIN_FREE_BYTES, end_date=None):",
        "collect signature")
    src = replace_one(src,
        '''    # Use the last COMPLETE 4H UTC boundary, so the 240 x 1H candles
    # can also replay 60 x full 4H candles without hidden partial bars.
    end = int(now // (4 * BASE_INTERVAL_SECONDS)) * (4 * BASE_INTERVAL_SECONDS)
    start = end - COUNT * BASE_INTERVAL_SECONDS
    source_id = f"OKX_{pair.replace('-', '_')}_1H_{end}"
''',
        '''    # Default: keep V3 behavior. Optional historical date is the exclusive
    # 00:00 UTC end boundary, giving the immediately preceding 240 closed 1H bars.
    current_boundary = int(now // (4 * BASE_INTERVAL_SECONDS)) * (4 * BASE_INTERVAL_SECONDS)
    historical = end_date not in (None, "")
    if historical:
        if not isinstance(end_date, str) or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", end_date):
            raise PublicMarketError("Fin historique UTC : date YYYY-MM-DD requise")
        try:
            date_value = datetime.strptime(end_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            end = int(date_value.timestamp())
        except (ValueError, OverflowError) as exc:
            raise PublicMarketError("Date historique UTC invalide") from exc
        if end <= 0 or end > current_boundary:
            raise PublicMarketError("La fin historique doit être passée, complète et en UTC")
    else:
        end = current_boundary
    start = end - COUNT * BASE_INTERVAL_SECONDS
    source_id = f"OKX_{pair.replace('-', '_')}_1H_{end}"
''', "historical UTC boundary")
    src = replace_one(src,
        "    after = None\n    previous_oldest = None\n    for page in range(MAX_PAGES):",
        '''    # OKX 'after' is EXCLUSIVE and requests candles older than this UTC
    # timestamp. This cursor starts directly at the selected historical end,
    # avoiding a long or unbounded scan backward from today's candles.
    after = end * 1000 if historical else None
    previous_oldest = None
    for page in range(MAX_PAGES):''', "historical cursor")
    src = replace_one(src,
        '        "collected_at_utc": datetime.fromtimestamp(now, timezone.utc).isoformat(),',
        '        "collected_at_utc": datetime.fromtimestamp(now, timezone.utc).isoformat(),\n        "historical_end_date_utc": end_date if historical else None,',
        "manifest historical date")
    src = replace_one(src,
        '"meaning": "Recent public CLOSED candles, not a realtime trade or a historic book; "',
        '"meaning": "Public CLOSED candles from the selected UTC window, not a realtime trade or a historic book; "',
        "provenance label")
    return src


def patch_server(src: str) -> str:
    src = replace_one(src,
        '"version": "3.0.0",', '"version": "3.1.0",', "server version")
    src = replace_one(src,
        'self._send({"source": collect_okx(WORKSPACE, data.get("pair"))}, 201)',
        'self._send({"source": collect_okx(WORKSPACE, data.get("pair"), end_date=data.get("end_date"))}, 201)',
        "server historical date input")
    return src


def patch_html(src: str) -> str:
    if src.count("BUILD 3.0.0") != 2:
        raise RuntimeError("Deux étiquettes BUILD V3 attendues dans HTML")
    src = src.replace("BUILD 3.0.0", "BUILD 3.1.0")
    src = replace_one(src,
        '<div class="overline">V3 / PUBLIC MARKET CONNECTORS</div>',
        '<div class="overline">V3.1 / PUBLIC MARKET CONNECTORS</div>',
        "connector label")
    src = replace_one(src,
        '''        <div class="connected-source-grid active-source-row">''',
        '''        <div class="connected-source-grid historical-source-row">
          <label class="field"><span>Fin de période historique <small>UTC · OPTIONNEL</small></span>
            <input id="okx-history-date" type="date" aria-label="Fin de fenêtre historique en UTC, laisser vide pour la période récente">
          </label>
          <p class="source-caution">Champ vide : 10 derniers jours. Une date : 240 bougies 1h clôturées pendant les 10 jours précédant cette date à 00:00 UTC. Chaque archive reste distincte et contrôlée.</p>
        </div>
        <div class="connected-source-grid active-source-row">''',
        "history date picker")
    src = replace_one(src,
        "Les 240 bougies OKX couvrent les dix derniers jours complets alignés à la clôture 4h UTC.",
        "Les 240 bougies OKX couvrent soit les dix derniers jours alignés sur 4h UTC, soit la fenêtre historique choisie.",
        "source caution")
    return src


def patch_js(src: str) -> str:
    src = replace_one(src,
        '''    const pair=$("okx-pair").value;
    notice("OKX public : contrôle des règles Spot, bougies clôturées et cache SHA-256…");
    try {
      const result=await api("/api/okx-import",{pair});''',
        '''    const pair=$("okx-pair").value;
    const end_date=$("okx-history-date").value || null;
    notice("OKX public : contrôle des règles Spot, période UTC, bougies clôturées et cache SHA-256…");
    try {
      const result=await api("/api/okx-import",{pair,end_date});''',
        "JS historical payload")
    src = replace_one(src,
        '''      notice("OKX "+pair+" : 240 bougies 1h fermées et vérifiées sur la clé. "+
             "Tu peux comparer les stratégies en 1h ou 4h. Aucun ordre réel.","success");''',
        '''      notice("OKX "+pair+" : 240 bougies 1h clôturées et vérifiées sur la clé"+
             (end_date ? " pour la fenêtre terminée le "+end_date+" UTC" : " pour la fenêtre récente")+
             ". Comparaison PAPER disponible en 1h ou 4h. Aucun ordre réel.","success");''',
        "JS historical confirmation")
    src = replace_one(src, 'notice(ok?"Seven Heaven V3 opérationnel',
        'notice(ok?"Seven Heaven V3.1 opérationnel', "JS V3.1 welcome")
    src = replace_one(src, '"Seven Heaven V3 opérationnel. Charge une archive Binance ou OKX publique."',
        '"Seven Heaven V3.1 opérationnel. Charge une archive Binance ou OKX publique."',
        "JS V3.1 alternate")
    return src


PATCHERS = {
    "src/okx_public.py": patch_okx,
    "src/server.py": patch_server,
    "web/app.js": patch_js,
    "web/index.html": patch_html,
}


def is_server_running() -> bool:
    with socket.socket() as s:
        s.settimeout(0.25)
        return s.connect_ex(("127.0.0.1", 8777)) == 0


def atomic_write(path: Path, payload: bytes) -> None:
    fd, staged = tempfile.mkstemp(dir=path.parent, prefix=".seven_v31_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(staged, path)
    finally:
        if os.path.exists(staged):
            os.unlink(staged)


def upgrade(root=ROOT, *, enforce_versions=True, require_stopped=True, verbose=True):
    root = Path(root).resolve()
    if require_stopped and is_server_running():
        raise RuntimeError("Le serveur local écoute encore sur 127.0.0.1:8777. Fermer Python (Ctrl+C) avant la mise à niveau.")
    if not (root / "workspace").is_dir():
        raise RuntimeError("Dossier workspace/ absent : ce correctif doit être placé à la racine de la V3 existante.")
    backup = root / BACKUP.name
    if backup.exists():
        raise RuntimeError("Sauvegarde V3 déjà présente : aucune nouvelle mise à niveau automatique. Vérifier avant de recommencer.")
    prepared = {}
    for name, old_gitsha in FILES.items():
        path = root / name
        raw = path.read_bytes()
        actual = git_blob_sha(raw)
        if enforce_versions and actual != old_gitsha:
            raise RuntimeError(f"Source {name} différente de la V3 GitHub attendue : {actual} != {old_gitsha}. Aucun fichier modifié.")
        new_text = PATCHERS[name](raw.decode("utf-8"))
        if name.endswith(".py"):
            compile(new_text, str(path), "exec")
        prepared[name] = (raw, new_text.encode("utf-8"))
    # All source anchors are verified before any file is written.
    for name, (raw, _) in prepared.items():
        dst = backup / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(raw)
    applied=[]
    try:
        for name, (_, changed) in prepared.items():
            atomic_write(root / name, changed)
            applied.append(name)
    except Exception:
        for name in reversed(applied):
            atomic_write(root / name, prepared[name][0])
        raise
    if verbose:
        print("OK : Seven Heaven Strategy Lab V3.1.0 installé (source-pinned, UTF-8, sauvegarde locale).")
        print("Conservé sans lecture ni écriture :", root / "workspace")
        print("Anciennes versions des 4 fichiers :", backup)
        print("Redémarrer le lanceur Python 3.13, vérifier BUILD 3.1.0, choisir une date UTC ou laisser vide.")
    return {name: len(changed) for name, (_, changed) in prepared.items()}


def main():
    try:
        upgrade()
    except (RuntimeError, OSError, UnicodeError, SyntaxError) as exc:
        print("REFUS SANS MODIFICATION :", exc, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
