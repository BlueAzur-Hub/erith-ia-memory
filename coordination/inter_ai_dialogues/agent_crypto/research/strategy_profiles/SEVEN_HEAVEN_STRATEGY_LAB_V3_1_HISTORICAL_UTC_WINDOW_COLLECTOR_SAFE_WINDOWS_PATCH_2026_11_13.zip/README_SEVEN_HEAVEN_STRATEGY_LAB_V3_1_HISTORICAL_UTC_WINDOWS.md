# Seven Heaven Strategy Lab — V3.1 Historical UTC Windows (candidate patch)

**Statut : correctif local V3.1 candidat (13 novembre 2026).** Il ne s'agit pas encore d'une publication GitHub officielle ni d'une validation dans le Firefox du propriétaire. Aucun moteur Freqtrade/Hummingbot et aucun ordre réel.

## Objectif

Permettre de collecter, sans compte et à la demande, une fenêtre historique de **240 bougies horaires closes (10 jours UTC)** autour d'une date de fin choisie, sans perdre la collecte des dix derniers jours déjà disponible dans la V3.0.0.

Une nouvelle entrée **Fin de période historique — UTC (optionnel)** apparaît dans l'Observatoire connecté. Laisser le champ vide reproduit exactement le fonctionnement de V3. Une date `AAAA-MM-JJ` sélectionne les **10 jours précédant 00:00 UTC à cette date**. Exemple : fin `2026-11-03` = période du `2026-10-24 00:00 UTC` au `2026-11-02 23:00 UTC`, si OKX renvoie toutes les bougies.

Le module interroge le même endpoint public OKX Spot `history-candles`. Il part de la date historique avec le curseur `after` exclusif et conserve la pagination bornée de V3 : au maximum six pages de cent réponses. **Aucune bougie manquante n'est inventée** ; l'archive est refusée si la source est incomplète, hors plage ou indisponible. Les quatre paires autorisées, le hash des données, la réserve de 2,5 Go, les six stratégies PAPER et l'absence d'ordres restent inchangés.

Chaque période garde le même identifiant source V3 (`OKX_BTC_USDC_1H_<timestamp_de_fin>`) et un manifeste SHA-256 autonome. Le dossier `workspace/` est préservé sans lecture ni écriture par le correctif. Il n'y a ni migration ni changement de format du journal.

## Installation candidate — une seule commande Windows

1. **Arrêter le serveur Python V3** (`Ctrl+C`). Sauvegarder `E:\seven_heaven_strategy_lab\workspace\` sur un autre support avant toute évolution, conformément au plan directeur.
2. Extraire les trois fichiers de cette archive **directement dans** `E:\seven_heaven_strategy_lab\`, là où se trouvent `src`, `web` et `workspace`. **Ne pas extraire dans `workspace/`.**
3. Double-cliquer sur `INSTALL_SEVEN_HEAVEN_STRATEGY_LAB_V3_1_WINDOWS.cmd`.
4. Si le programme signale `REFUS SANS MODIFICATION`, ne pas forcer. Il compare les quatre sources du programme à leur empreinte Git d'origine et refuse toute modification si elles diffèrent.
5. Si la mise à jour réussit, elle crée `backup_seven_heaven_strategy_lab_before_v3_1/` avec les quatre fichiers V3 avant modification. Relancer le lanceur Python habituel, vérifier **BUILD 3.1.0**, puis laisser la date vide pour un essai V3 inchangé.
6. Ensuite choisir une date historique, collecter une archive OKX, puis comparer six méthodes en 1h. Essayer séparément plusieurs dates représentant différents régimes de marché, toujours avec les mêmes paramètres de capital/frais/glissement.

Le correctif **ne peut pas modifier** le code si le serveur répond déjà sur le port 8777 ; il vérifie les empreintes Git attendues avant l'écriture et effectue les remplacements de fichiers de façon atomique. Aucun compte ni secret n'est requis.

## Couverture de test et limites

- **Contrôlé localement :** compilation Python du correctif, six tests automatiques sur des représentations isolées des fichiers concernés (réussite, refus si source non conforme, refus si ancrage absent, refus si sauvegarde déjà existante) ; préservation de `workspace` et des originaux dans le test de réussite.
- **Non vérifié :** application du patch sur l'archive binaire exacte V3 du propriétaire ; tests d'intégration réels du serveur V3.1 ; collectes historiques OKX réelles ; Firefox V3.1 ; CI Windows sur GitHub. Ne pas confondre la recette officielle V3 avec une recette V3.1.
- Les règles `tickSz`, `lotSz`, `minSz` sont des observations actuelles, non une preuve historique d'exécution. Le simulateur reste une approximation PAPER sur ouverture suivante avec frais/glissement fixes.
- La V3.1 candidate ne collecte pas encore 6 mois d'un seul tenant : **elle permet plusieurs fenêtres sélectionnables de 10 jours**. L'extension des durées et les comparaisons multi-fenêtres automatisées restent à développer après vérification de ce premier changement.

**Fichiers touchés par le correctif :** `src/okx_public.py`, `src/server.py`, `web/app.js`, `web/index.html`. **Fichiers conservés :** `workspace/` et tous les autres composants.
