@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3.13 "UPGRADE_SEVEN_HEAVEN_STRATEGY_LAB_V3_TO_V3_1.py"
) else (
  python "UPGRADE_SEVEN_HEAVEN_STRATEGY_LAB_V3_TO_V3_1.py"
)
echo.
if errorlevel 1 (
  echo ECHEC OU REFUS : conserver la V3 existante et consulter le message ci-dessus.
) else (
  echo Installation terminee. Relancer le lanceur Python habituel.
)
pause
