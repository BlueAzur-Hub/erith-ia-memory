# Agent-Crypto 40.6.302 — Final Handoff

Release: PARKER LEWIS CAN'T LOSE · AETHER ORIGINAL RESTORE · LEFT X12
Functional commit: 881508ec523a3eed5ef54317e2fab3da17ab5149
Published HEAD checked: c72e3d9c9e8793936c3dd9f50ee98099d104e2bd
Market Core: 38.15.11 (protected)

Final intent:
- preserve 40.6.301 restored Aether function lifecycle;
- change only persisted horizontal origin to LEFT x=12;
- preserve y, width, height, floating/minimized/hidden/maximized/z;
- if restoreGeometry exists, change only restoreGeometry.x to 12;
- no CSS added;
- no aether.js change;
- no Window Manager change;
- no new resize/F11 hook;
- Storage and Strategy remain frozen until Firefox terrain validation.

Terrain order for next sister AI:
1. Confirm Build 40.6.302 in runtime.
2. Normal Aether must be LEFT (x≈12).
3. Drag.
4. Free resize.
5. F11.
6. Exit F11 and verify restored normal geometry.
7. Maximize/restore.
8. Close/reopen.
9. F5/reopen.

If LEFT fails, inspect first:
- localStorage key: agent-crypto-administrator:window:aether-watch
- migration marker: agent-crypto-administrator:migration:aether-left-406302
Do not patch CSS to correct x.

Canonical Notion handoff:
https://app.notion.com/p/3e07754fe08481eb95c7cdc4fd8ff099
