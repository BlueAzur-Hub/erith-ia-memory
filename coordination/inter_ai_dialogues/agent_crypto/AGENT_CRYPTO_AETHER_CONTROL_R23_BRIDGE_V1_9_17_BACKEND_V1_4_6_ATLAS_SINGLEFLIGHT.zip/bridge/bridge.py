#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ctypes
import getpass
import json
import os
import re
import signal
import threading
import secrets
import subprocess
import shutil
import base64
import hashlib
import hmac
import time
import urllib.error
import urllib.request
import socket
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlencode, urlparse
from typing import Any

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "bridge_config.json"
PID_PATH = ROOT / "bridge.pid"
LEGACY_AUTH_PATH = ROOT / "bridge_auth.json"

def _persistent_trust_root() -> Path:
    local = str(os.environ.get("LOCALAPPDATA") or "").strip()
    if local:
        return Path(local) / "ERITH.IA" / "AtlasCryptoBridge" / "trust"
    try:
        return Path.home() / ".erith-ia" / "AtlasCryptoBridge" / "trust"
    except Exception:
        return ROOT.parent / "trust"

TRUST_ROOT = _persistent_trust_root()
AUTH_PATH = TRUST_ROOT / "bridge_auth.json"
SECURITY_AUDIT_PATH = ROOT / "data" / "security" / "audit.jsonl"
BOOK_MIRROR_STATUS_PATH = ROOT / "data" / "book_mirror_publication_status.json"



CANONICAL_PROFILE_FILES = {
    "atlas": (
        ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_MULTI_AGENT_CORE.md",
        ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_PERSONA_OPERATING_LAYER.md",
    ),
    "aerith": (
        ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_MULTI_AGENT_CORE.md",
        ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_PERSONA_OPERATING_LAYER.md",
    ),
}

RUNTIME_PROFILE_FILES = {
    "atlas": ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_RUNTIME_PROMPT.md",
    "aerith": ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_RUNTIME_PROMPT.md",
}

MODE_LABELS = {
    "market": "Synthèse du marché",
    "top5": "Analyse du Target Top 5",
    "math": "Explication du Math Core",
    "contradictions": "Contrôle des contradictions",
    "chat": "Réponse à la question libre",
    "conclusion": "Conclusion Aerith-10 Crypto",
}

FORBIDDEN_MODEL_PATTERNS = (
    r"\bportefeuille\b",
    r"\bratio de sharpe\b",
    r"\bvalue at risk\b",
    r"\bexpected shortfall\b",
    r"\bacheter\b",
    r"\bvendre\b",
    r"\bsignal d['’]?achat\b",
    r"\bstop point.{0,30}\bjours?\b",
    r"\bcourbe en bas\b",
)

SAFETY_CONTRACT = """
CONTRAT LOCAL OBLIGATOIRE
- Lecture seule.
- Aucun ordre financier, wallet, exchange, GitHub ou action d'interface.
- La liste du marché n'est jamais un portefeuille.
- Le Target Top 5 canonique est BTC, ETH, BNB, XRP et SOL.
- Agent-Crypto calcule les faits ; le modèle local ne les remplace pas.
- Une mesure absente reste absente.
- Une limite générale n'est pas une actualité.
- La position visuelle d'une courbe ne prouve aucune tendance.
- Le stop point n'est pas une durée : c'est la limite des données disponibles.
""".strip()


FRESHNESS_LABELS = {
    "fresh": "récente",
    "delayed": "retardée",
    "stale": "ancienne",
    "archive": "archivée",
    "expired": "expirée",
    "direct": "directe",
    "cache": "en cache",
    "recent-cache": "en cache récent",
    "local-cache": "en cache local",
}

MODEL_COMMENT_PROFILES = {
    "atlas": (
        "Tu es Atlas-10 Crypto. Ajoute un commentaire analytique très court, "
        "sobre, contradictoire et limité aux faits condensés transmis."
    ),
    "aerith": (
        "Tu es Aerith-10 Crypto. Produis une synthèse pédagogique transversale, concrète et suffisamment détaillée, "
        "strictement limitée au snapshot CURRENT et aux quatre rapports Atlas relus. "
        "Relie marché, Top 5, graphique, Math Core, News Sentinel, Watchlist, contradictions et NØX sans inventer de causalité. "
        "Explique ce que les mesures signifient ici, ce qu’elles ne permettent pas de conclure et les informations manquantes. "
        "Évite de répéter mécaniquement les chiffres déjà exposés et n’écris jamais une consigne générale à l’infinitif comme « analyser », « évaluer » ou « utiliser »."
    ),
}

HISTORY_BINANCE_BASES = (
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api-gcp.binance.com",
)

HISTORY_PERIODS = {
    1: {"interval": "5m", "limit": 300, "api_days": 1},
    7: {"interval": "30m", "limit": 350, "api_days": 7},
    30: {"interval": "2h", "limit": 370, "api_days": 30},
    60: {"interval": "4h", "limit": 370, "api_days": 60},
    90: {"interval": "4h", "limit": 550, "api_days": 90},
    365: {"interval": "12h", "limit": 740, "api_days": 365},
    36500: {"interval": "1d", "limit": 1000, "api_days": "max"},
}

HISTORY_CACHE: dict[str, dict[str, Any]] = {}
HISTORY_CACHE_LOCK = threading.Lock()

# V1.9.14 — Oracle Evidence GitHub timeout/readback resilience; Atlas 4/4 cache preserved.
# The browser still requests the four canonical /summary routes sequentially,
# but one gpt-oss pass produces the four bounded comments for a fingerprint.
# Subsequent summary routes reuse that in-memory result; deterministic report
# construction remains unchanged.
ATLAS_SUITE_COMMENT_CACHE_LOCK = threading.Lock()
ATLAS_SUITE_COMMENT_CACHE: dict[str, dict[str, Any]] = {}
ATLAS_SUITE_COMMENT_CACHE_MAX = 8
# A single in-flight inference per exact Atlas contract + provider/model.
# Per-process guard also serializes expensive Atlas/Aerith model calls;
# it does NOT guard market data, /health or read-only OKX operations.
ATLAS_SUITE_INFLIGHT_LOCK = threading.Lock()
ATLAS_SUITE_INFLIGHT: dict[str, dict[str, Any]] = {}
MODEL_INFERENCE_SEMAPHORE = threading.BoundedSemaphore(1)
MODEL_INFERENCE_QUEUE_TIMEOUT_SECONDS = 4.0
ATLAS_SUITE_INFLIGHT_WAIT_SECONDS = 248.0
ATLAS_RUNTIME_DIAGNOSTICS_PATH = ROOT / "data" / "diagnostics" / "atlas_runtime.jsonl"
ATLAS_RUNTIME_DIAGNOSTICS_LOCK = threading.Lock()


def atlas_runtime_diagnostic(event: str, *, digest: str = "", elapsed_ms: int | None = None) -> None:
    """Local-only bounded fields. Never serialize a contract, prompt, account or token."""
    try:
        record = {"time_utc": utc_now(), "event": event,
                  "digest_prefix": digest[:12], "pid": os.getpid()}
        if elapsed_ms is not None:
            record["elapsed_ms"] = elapsed_ms
        with ATLAS_RUNTIME_DIAGNOSTICS_LOCK:
            ATLAS_RUNTIME_DIAGNOSTICS_PATH.parent.mkdir(parents=True, exist_ok=True)
            with ATLAS_RUNTIME_DIAGNOSTICS_PATH.open("a", encoding="utf-8") as log:
                log.write(json.dumps(record, separators=(",", ":")) + "\n")
    except (OSError, ValueError):
        pass


HISTORY_INFLIGHT: dict[str, dict[str, Any]] = {}
HISTORY_INFLIGHT_LOCK = threading.Lock()


SCANNER_DATA_DIR = ROOT / "data" / "scanner_live"
SCANNER_LATEST_PATH = SCANNER_DATA_DIR / "latest.json"
SCANNER_WRITE_LOCK = threading.Lock()
SCANNER_BINANCE_TICKER_CACHE: dict[str, Any] = {"saved_at": 0.0, "rows": {}}
SCANNER_BINANCE_TICKER_LOCK = threading.Lock()
SCANNER_SCHEMA = "atlas_scanner_live_snapshot_v1"
SCANNER_BASKETS = ("top5", "gainers", "losers", "volume")

MODEL_COMMENT_RULES = """
CONTRAT DU RAISONNEMENT LOCAL ATLAS/AERITH
- Travaille uniquement à partir du dossier factuel transmis par Agent-Crypto.
- Ne crée aucun prix, volume, rendement, source, actualité, position ou mesure absent.
- Distingue fait, hypothèse, interprétation, contradiction, risque, limite et information manquante.
- Aucune instruction d'achat, vente, levier, retrait ou exécution.
- Aucune causalité supposée à partir d'une simple corrélation.
- La liste du marché et la Watchlist ne sont jamais un portefeuille.
- Source Truth, Evidence, Math Quality Gates et Contradictions priment sur une formulation du modèle.
- Si le dossier ne permet pas une conclusion : INFORMATION MANQUANTE.
- Réponds uniquement avec ce JSON : {"lecture":"...","prudence":"...","limites":"..."}.
- Chaque champ peut contenir jusqu'à trois phrases courtes, ancrées dans le snapshot présent.
""".strip()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


# Aether Trust session policy.
# Owner sessions are deliberately non-expiring while the Bridge process is alive:
# they end only by explicit /auth/logout or when the Bridge stops/restarts.
# Non-owner roles keep the historical bounded TTL for compatibility.
AUTH_DEFAULT_SESSION_TTL_SECONDS = 12 * 60 * 60
AUTH_OWNER_SESSION_TTL_SECONDS: int | None = None
AUTH_OWNER_SESSION_POLICY = "persistent_until_logout_or_bridge_stop"
AUTH_MAX_FAILURES = 6
AUTH_FAILURE_WINDOW_SECONDS = 15 * 60
AUTH_SESSIONS: dict[str, dict[str, Any]] = {}
AUTH_SESSIONS_LOCK = threading.Lock()
AUTH_FAILURES: dict[str, list[float]] = {}
AUTH_FAILURES_LOCK = threading.Lock()
AUTH_PRIVILEGED_GET = {"/profiles", "/history", "/scanner-latest", "/scanner-status", "/scanner-history", "/capabilities", "/security/status", "/book-mirror/status", "/oracle-evidence/status", "/okx/status", "/okx/account", "/okx/orders", "/okx/fills", "/okx/fees", "/okx/ledger"}
AUTH_PRIVILEGED_POST = {"/chat", "/summary", "/conclusion", "/scanner-snapshot", "/book-mirror/publish", "/oracle-evidence/ingest"}

OKX_SECRETS_ROOT = TRUST_ROOT.parent / "secrets"
OKX_CREDENTIALS_PATH = OKX_SECRETS_ROOT / "okx_read.dpapi"
OKX_DPAPI_ENTROPY = b"ERITH.IA|AtlasCryptoBridge|OKX_PRIVATE_READ|v1"
OKX_SITE_BASE_URLS = {
    "global": "https://openapi.okx.com",
    "eea": "https://eea.okx.com",
    "us": "https://us.okx.com",
}
OKX_PRIVATE_READ_PATHS = frozenset({
    "/api/v5/account/balance",
    "/api/v5/asset/balances",
    "/api/v5/trade/orders-pending",
    "/api/v5/trade/orders-history",
    "/api/v5/trade/orders-history-archive",
    "/api/v5/trade/fills-history",
    "/api/v5/account/trade-fee",
    "/api/v5/account/bills-archive",
    "/api/v5/asset/bills-history",
})
OKX_PRIVATE_TIMEOUT_SECONDS = 15


def security_audit(event: str, *, ok: bool, detail: str = "", remote: str = "") -> None:
    try:
        SECURITY_AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        row = {"at": utc_now(), "event": str(event), "ok": bool(ok), "detail": str(detail)[:240], "remote": str(remote)[:80]}
        with SECURITY_AUDIT_PATH.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _auth_state_valid(state: dict[str, Any] | None) -> bool:
    return bool(isinstance(state, dict) and state.get("schema") == "atlas_bridge_auth_v1" and str(state.get("salt") or "").strip() and str(state.get("verifier") or "").strip())

def auth_migrate_legacy_if_needed() -> bool:
    """Migrate one valid version-local verifier into stable per-user trust storage."""
    try:
        if AUTH_PATH.exists():
            return False
        TRUST_ROOT.mkdir(parents=True, exist_ok=True)
        candidates: list[Path] = []
        if LEGACY_AUTH_PATH.exists():
            candidates.append(LEGACY_AUTH_PATH)
        try:
            base = ROOT.parent.parent
            for candidate in base.glob("2.3.2R*/bridge/bridge_auth.json"):
                if candidate != AUTH_PATH and candidate not in candidates:
                    candidates.append(candidate)
        except Exception:
            pass
        candidates.sort(key=lambda path: path.stat().st_mtime if path.exists() else 0.0, reverse=True)
        for candidate in candidates:
            try:
                state = load_json(candidate)
            except Exception:
                continue
            if not _auth_state_valid(state):
                continue
            tmp = AUTH_PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, AUTH_PATH)
            return True
        return False
    except Exception:
        return False

def auth_state_read() -> dict[str, Any] | None:
    try:
        auth_migrate_legacy_if_needed()
        state = load_json(AUTH_PATH)
        return state if _auth_state_valid(state) else None
    except Exception:
        return None


def auth_secret_hash(secret: str, salt_hex: str) -> str:
    salt = bytes.fromhex(salt_hex)
    return hashlib.scrypt(str(secret).encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=32).hex()


def auth_register(secret: str) -> dict[str, Any]:
    if auth_state_read() is not None:
        raise ValueError("Bridge Administrator déjà configuré.")
    if len(secret) < 6 or len(secret) > 256:
        raise ValueError("Mot de passe Administrator invalide.")
    salt = secrets.token_hex(16)
    state = {
        "schema": "atlas_bridge_auth_v1",
        "role": "owner",
        "created_at": utc_now(),
        "kdf": "scrypt-n16384-r8-p1-dk32",
        "salt": salt,
        "verifier": auth_secret_hash(secret, salt),
    }
    TRUST_ROOT.mkdir(parents=True, exist_ok=True)
    tmp = AUTH_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, AUTH_PATH)
    return state


def auth_verify(secret: str) -> bool:
    state = auth_state_read()
    if not state:
        return False
    candidate = auth_secret_hash(secret, str(state.get("salt") or ""))
    return hmac.compare_digest(candidate, str(state.get("verifier") or ""))


def auth_failure_allowed(remote: str) -> bool:
    now = time.time()
    with AUTH_FAILURES_LOCK:
        rows = [t for t in AUTH_FAILURES.get(remote, []) if now - t <= AUTH_FAILURE_WINDOW_SECONDS]
        AUTH_FAILURES[remote] = rows
        return len(rows) < AUTH_MAX_FAILURES


def auth_failure_record(remote: str) -> None:
    now = time.time()
    with AUTH_FAILURES_LOCK:
        rows = [t for t in AUTH_FAILURES.get(remote, []) if now - t <= AUTH_FAILURE_WINDOW_SECONDS]
        rows.append(now)
        AUTH_FAILURES[remote] = rows[-AUTH_MAX_FAILURES:]



CAPABILITY_POLICY = {
    "owner": frozenset({"history.read", "scanner.read", "scanner.write", "atlas.run", "aerith.run", "chat.run", "security.read", "book_mirror.publish", "book_mirror.read", "oracle_evidence.publish", "oracle_evidence.read", "okx.account.read", "okx.orders.read", "okx.fills.read", "okx.fees.read", "okx.ledger.read"}),
    "operator": frozenset({"history.read", "scanner.read", "atlas.run", "aerith.run", "chat.run"}),
    "reader": frozenset({"history.read", "scanner.read"}),
}
ROUTE_CAPABILITY = {
    "/profiles": "security.read",
    "/history": "history.read",
    "/scanner-latest": "scanner.read",
    "/scanner-status": "scanner.read",
    "/scanner-history": "scanner.read",
    "/scanner-snapshot": "scanner.write",
    "/summary": "atlas.run",
    "/conclusion": "aerith.run",
    "/chat": "chat.run",
    "/capabilities": "security.read",
    "/security/status": "security.read",
    "/book-mirror/status": "book_mirror.read",
    "/book-mirror/publish": "book_mirror.publish",
    "/oracle-evidence/status": "oracle_evidence.read",
    "/oracle-evidence/ingest": "oracle_evidence.publish",
    "/okx/status": "security.read",
    "/okx/account": "okx.account.read",
    "/okx/orders": "okx.orders.read",
    "/okx/fills": "okx.fills.read",
    "/okx/fees": "okx.fees.read",
    "/okx/ledger": "okx.ledger.read",
}


def capabilities_for_role(role: str) -> list[str]:
    return sorted(CAPABILITY_POLICY.get(str(role), frozenset()))

def auth_session_create(role: str = "owner") -> dict[str, Any]:
    token = secrets.token_urlsafe(36)
    created = time.time()
    persistent = role == "owner"
    expires = None if persistent else created + AUTH_DEFAULT_SESSION_TTL_SECONDS
    row = {
        "role": role,
        "created_at": created,
        "expires_at": expires,
        "persistent": persistent,
        "session_policy": AUTH_OWNER_SESSION_POLICY if persistent else "bounded_ttl",
    }
    with AUTH_SESSIONS_LOCK:
        AUTH_SESSIONS[token] = row
    return {
        "token": token,
        "role": role,
        "expires_at": None if expires is None else datetime.fromtimestamp(expires, timezone.utc).isoformat(),
        "persistent": persistent,
        "session_policy": row["session_policy"],
        "capabilities": capabilities_for_role(role),
    }


def auth_session_get(token: str) -> dict[str, Any] | None:
    if not token:
        return None
    now = time.time()
    with AUTH_SESSIONS_LOCK:
        row = AUTH_SESSIONS.get(token)
        if not row:
            return None
        expires = row.get("expires_at")
        if expires is not None and float(expires) <= now:
            AUTH_SESSIONS.pop(token, None)
            return None
        return dict(row)


def auth_session_revoke(token: str) -> None:
    if not token:
        return
    with AUTH_SESSIONS_LOCK:
        AUTH_SESSIONS.pop(token, None)


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _dpapi_blob(data: bytes) -> tuple[_DATA_BLOB, Any]:
    buffer = ctypes.create_string_buffer(data)
    blob = _DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    return blob, buffer


def dpapi_protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Le stockage OKX persistant exige Windows DPAPI.")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_DATA_BLOB), ctypes.c_wchar_p, ctypes.POINTER(_DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptProtectData.restype = ctypes.c_int
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    in_blob, in_buffer = _dpapi_blob(data)
    entropy_blob, entropy_buffer = _dpapi_blob(OKX_DPAPI_ENTROPY)
    out_blob = _DATA_BLOB()
    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob), None, ctypes.byref(entropy_blob), None, None, 0x1, ctypes.byref(out_blob)
    )
    _ = (in_buffer, entropy_buffer)
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out_blob.pbData, ctypes.c_void_p))


def dpapi_unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Le stockage OKX persistant exige Windows DPAPI.")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_DATA_BLOB), ctypes.POINTER(ctypes.c_wchar_p), ctypes.POINTER(_DATA_BLOB), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptUnprotectData.restype = ctypes.c_int
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    in_blob, in_buffer = _dpapi_blob(data)
    entropy_blob, entropy_buffer = _dpapi_blob(OKX_DPAPI_ENTROPY)
    out_blob = _DATA_BLOB()
    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, ctypes.byref(entropy_blob), None, None, 0x1, ctypes.byref(out_blob)
    )
    _ = (in_buffer, entropy_buffer)
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(ctypes.cast(out_blob.pbData, ctypes.c_void_p))


def okx_site_normalize(value: str) -> str:
    site = str(value or "").strip().lower()
    if site not in OKX_SITE_BASE_URLS:
        raise ValueError("Site OKX invalide. Valeurs: eea, global ou us.")
    return site


def okx_credentials_from_env() -> dict[str, str] | None:
    api_key = str(os.environ.get("ERITH_OKX_API_KEY") or "").strip()
    secret_key = str(os.environ.get("ERITH_OKX_SECRET_KEY") or "").strip()
    passphrase = str(os.environ.get("ERITH_OKX_PASSPHRASE") or "").strip()
    if not (api_key and secret_key and passphrase):
        return None
    return {
        "api_key": api_key,
        "secret_key": secret_key,
        "passphrase": passphrase,
        "site": okx_site_normalize(str(os.environ.get("ERITH_OKX_SITE") or "eea")),
        "storage": "environment",
    }


def okx_credentials_load() -> dict[str, str]:
    env = okx_credentials_from_env()
    if env:
        return env
    if not OKX_CREDENTIALS_PATH.exists():
        raise RuntimeError("Credentials OKX READ absents. Lance CONFIGURE_OKX_READ.bat.")
    raw = dpapi_unprotect(OKX_CREDENTIALS_PATH.read_bytes())
    data = json.loads(raw.decode("utf-8"))
    creds = {
        "api_key": str(data.get("api_key") or "").strip(),
        "secret_key": str(data.get("secret_key") or "").strip(),
        "passphrase": str(data.get("passphrase") or "").strip(),
        "site": okx_site_normalize(str(data.get("site") or "eea")),
        "storage": "windows_dpapi",
    }
    if not (creds["api_key"] and creds["secret_key"] and creds["passphrase"]):
        raise RuntimeError("Credentials OKX READ incomplets.")
    return creds


def okx_credentials_status() -> dict[str, Any]:
    env = okx_credentials_from_env()
    if env:
        return {"configured": True, "storage": "environment", "site": env["site"]}
    if not OKX_CREDENTIALS_PATH.exists():
        return {"configured": False, "storage": "windows_dpapi", "site": None}
    try:
        creds = okx_credentials_load()
        return {"configured": True, "storage": creds["storage"], "site": creds["site"]}
    except Exception as exc:
        return {"configured": False, "storage": "windows_dpapi", "site": None, "error": str(exc)[:180]}


def okx_credentials_save(api_key: str, secret_key: str, passphrase: str, site: str) -> Path:
    if os.name != "nt":
        raise RuntimeError("Configuration OKX persistante disponible uniquement sous Windows.")
    clean = {
        "schema": "agent_crypto_okx_private_read_credentials_v1",
        "api_key": str(api_key or "").strip(),
        "secret_key": str(secret_key or "").strip(),
        "passphrase": str(passphrase or "").strip(),
        "site": okx_site_normalize(site),
        "read_only_intent": True,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    if not (clean["api_key"] and clean["secret_key"] and clean["passphrase"]):
        raise ValueError("API key, Secret key et Passphrase sont requis.")
    OKX_SECRETS_ROOT.mkdir(parents=True, exist_ok=True)
    encrypted = dpapi_protect(json.dumps(clean, ensure_ascii=False).encode("utf-8"))
    tmp = OKX_CREDENTIALS_PATH.with_suffix(".tmp")
    tmp.write_bytes(encrypted)
    os.replace(tmp, OKX_CREDENTIALS_PATH)
    return OKX_CREDENTIALS_PATH


def okx_configure_interactive(config: dict[str, Any]) -> int:
    defaults = config.get("okx_private_read", {})
    default_site = str(defaults.get("default_site") or "eea").strip().lower()
    print("OKX PRIVATE READ · configuration locale chiffrée Windows DPAPI")
    print("Aucun secret n'est envoyé à GitHub ni stocké dans le navigateur.")
    print("Utilise une clé OKX avec permission READ uniquement, sans Trade ni Withdraw.")
    site = input(f"Site OKX [eea/global/us] ({default_site}) : ").strip().lower() or default_site
    api_key = getpass.getpass("OKX API key : ").strip()
    secret_key = getpass.getpass("OKX Secret key : ").strip()
    passphrase = getpass.getpass("OKX Passphrase : ").strip()
    path = okx_credentials_save(api_key, secret_key, passphrase, site)
    print(f"OK · credentials READ protégés par DPAPI : {path}")
    print("Le Bridge n'expose aucune route Trade/Withdraw dans cette version.")
    return 0


def okx_clear_credentials() -> int:
    if OKX_CREDENTIALS_PATH.exists():
        OKX_CREDENTIALS_PATH.unlink()
        print("OK · credentials OKX READ supprimés du stockage local.")
    else:
        print("Aucun credential OKX READ local à supprimer.")
    return 0


def okx_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def okx_sign(secret_key: str, timestamp: str, method: str, request_path: str, body: str = "") -> str:
    prehash = f"{timestamp}{method.upper()}{request_path}{body}".encode("utf-8")
    digest = hmac.new(secret_key.encode("utf-8"), prehash, hashlib.sha256).digest()
    return base64.b64encode(digest).decode("ascii")


def okx_build_request_path(path: str, params: list[tuple[str, str]] | None = None) -> str:
    if path not in OKX_PRIVATE_READ_PATHS:
        raise ValueError("Endpoint OKX refusé par la liste blanche READ.")
    pairs = [(str(k), str(v)) for k, v in (params or []) if str(v) != ""]
    return path if not pairs else f"{path}?{urlencode(pairs)}"


def okx_private_get(path: str, params: list[tuple[str, str]] | None = None) -> dict[str, Any]:
    creds = okx_credentials_load()
    request_path = okx_build_request_path(path, params)
    timestamp = okx_timestamp()
    signature = okx_sign(creds["secret_key"], timestamp, "GET", request_path)
    headers = {
        "Accept": "application/json",
        "OK-ACCESS-KEY": creds["api_key"],
        "OK-ACCESS-SIGN": signature,
        "OK-ACCESS-TIMESTAMP": timestamp,
        "OK-ACCESS-PASSPHRASE": creds["passphrase"],
        "User-Agent": "ERITH-IA-AtlasCryptoBridge/OKX-Private-Read",
    }
    url = OKX_SITE_BASE_URLS[creds["site"]] + request_path
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=OKX_PRIVATE_TIMEOUT_SECONDS) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        try:
            raw_error = exc.read().decode("utf-8", errors="replace")[:2000]
        except Exception:
            raw_error = ""
        raise RuntimeError(f"OKX HTTP {exc.code}: {raw_error or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"OKX inaccessible: {exc.reason}") from exc
    payload = json.loads(raw.decode("utf-8")) if raw else {}
    code = str(payload.get("code") or "")
    if code != "0":
        msg = str(payload.get("msg") or "Erreur OKX").strip()
        raise RuntimeError(f"OKX {code or 'UNKNOWN'}: {msg}")
    return payload


def okx_private_status_payload() -> dict[str, Any]:
    status = okx_credentials_status()
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "enabled": True,
        "read_only": True,
        "configured": bool(status.get("configured")),
        "credential_storage": status.get("storage"),
        "site": status.get("site"),
        "write_routes": False,
        "withdraw_routes": False,
        "capabilities": ["okx.account.read", "okx.orders.read", "okx.fills.read", "okx.fees.read", "okx.ledger.read"],
    }


def okx_account_payload() -> dict[str, Any]:
    trading = okx_private_get("/api/v5/account/balance")
    funding = okx_private_get("/api/v5/asset/balances")
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "read_only": True,
        "source": "OKX Private REST",
        "site": okx_credentials_status().get("site"),
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "trading": trading.get("data") or [],
        "funding": funding.get("data") or [],
    }


def okx_orders_payload() -> dict[str, Any]:
    pending = okx_private_get("/api/v5/trade/orders-pending", [("instType", "SPOT")])
    history = okx_private_get("/api/v5/trade/orders-history-archive", [("instType", "SPOT"), ("limit", "100")])
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "read_only": True,
        "source": "OKX Private REST",
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "pending": pending.get("data") or [],
        "history_3m": history.get("data") or [],
    }


def okx_fills_payload() -> dict[str, Any]:
    fills = okx_private_get("/api/v5/trade/fills-history", [("instType", "SPOT"), ("limit", "100")])
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "read_only": True,
        "source": "OKX Private REST",
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "fills_3m": fills.get("data") or [],
    }


def okx_fees_payload(inst_id: str = "BTC-USDC") -> dict[str, Any]:
    clean_inst = str(inst_id or "BTC-USDC").strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{2,12}-[A-Z0-9]{2,12}", clean_inst):
        raise ValueError("instId OKX invalide.")
    fees = okx_private_get("/api/v5/account/trade-fee", [("instType", "SPOT"), ("instId", clean_inst)])
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "read_only": True,
        "source": "OKX Private REST",
        "instId": clean_inst,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "fees": fees.get("data") or [],
    }


def okx_ledger_params(ccy: str, pages: int) -> tuple[str, int]:
    """Bornes explicites : une devise, trois pages maximum par flux."""
    clean_ccy = str(ccy or "BTC").strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{2,12}", clean_ccy):
        raise ValueError("Devise OKX invalide : une seule devise est autorisée.")
    try:
        page_count = int(pages)
    except (TypeError, ValueError) as exc:
        raise ValueError("Le nombre de pages doit être un entier.") from exc
    if not 1 <= page_count <= 3:
        raise ValueError("Le nombre de pages doit être compris entre 1 et 3.")
    return clean_ccy, page_count


def okx_ledger_stream(path: str, ccy: str, pages: int) -> dict[str, Any]:
    """Historique de pièces comptables ; aucune interprétation de coût d'achat."""
    records: list[dict[str, Any]] = []
    cursor = ""
    seen_cursors: set[str] = set()
    state = "ok"
    reason = ""
    reached_last_page = False
    successful_pages = 0
    for i in range(pages):
        query = [("ccy", ccy), ("limit", "100")]
        if cursor:
            query.append(("after", cursor))
        try:
            data = okx_private_get(path, query)
            batch = data.get("data") or []
            if not isinstance(batch, list):
                raise ValueError("Format de facturation OKX inattendu.")
            if not all(isinstance(item, dict) for item in batch):
                raise ValueError("Enregistrement comptable OKX invalide.")
        except Exception as exc:
            state = "partial" if successful_pages else "unavailable"
            # L'API peut inclure des contenus privés dans ses erreurs HTTP :
            # on ne les envoie pas au navigateur ni au journal d'audit.
            reason = "Lecture impossible sur ce flux ; vérifier les permissions, la région OKX ou la limite API."
            break
        successful_pages += 1
        records.extend(batch)
        if len(batch) < 100:
            reached_last_page = True
            break
        candidate = str(batch[-1].get("billId") or "").strip()
        if not candidate or not candidate.isdigit() or candidate in seen_cursors:
            state = "partial"
            reason = "Pagination impossible à certifier : identifiant de page absent ou répété."
            break
        seen_cursors.add(candidate)
        cursor = candidate
        if i + 1 < pages:
            # Asset bills-history : 1 requête/s. Temporisation volontairement
            # plus lente pour les deux flux et les comptes réels.
            time.sleep(1.1)
    has_more = (not reached_last_page and successful_pages == pages) or state == "partial"
    return {
        "state": state,
        "source_path": path,
        "pages_read": successful_pages,
        "records_count": len(records),
        "records": records,
        "has_more": has_more,
        "last_bill_cursor": cursor if has_more else None,
        "warning": reason or None,
    }


def okx_ledger_payload(ccy: str = "BTC", pages: int = 1) -> dict[str, Any]:
    """Deux journaux OKX indépendants, sans transaction ni calcul inventé."""
    clean_ccy, count = okx_ledger_params(ccy, pages)
    account = okx_ledger_stream("/api/v5/account/bills-archive", clean_ccy, count)
    # La limite asset est plus stricte (1 requête/s) : séparation explicite.
    time.sleep(1.1)
    funding = okx_ledger_stream("/api/v5/asset/bills-history", clean_ccy, count)
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "read_only": True,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "ccy": clean_ccy,
        "pages_requested": count,
        "sources": {"trading_account": account, "funding_account": funding},
        "all_sources_available": all(x["state"] == "ok" for x in (account, funding)),
        "origin_of_funds_proven": False,
        "acquisition_cost_proven": False,
        "eur_paypal_purchase_proven": False,
        "note": (
            "Les journaux prouvent des mouvements, pas systématiquement le prix "
            "d'un achat PayPal en EUR. Recouper avec le justificatif OKX "
            "d'achat avant de calculer le résultat financier."
        ),
        "no_exchange_orders": True,
    }


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_config() -> dict[str, Any]:
    config = load_json(CONFIG_PATH)
    if config.get("host") not in {"127.0.0.1", "localhost"}:
        raise RuntimeError("Le Bridge doit rester lié à 127.0.0.1 ou localhost.")
    return config


def request_json(url: str, payload: dict[str, Any] | None, timeout: int) -> dict[str, Any]:
    data = None
    headers = {"Accept": "application/json"}
    method = "GET"
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
        method = "POST"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read()
    return json.loads(raw.decode("utf-8")) if raw else {}























def history_error_text(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return re.sub(r"\s+", " ", text)[:220]


def history_request_json(url: str, timeout: float) -> Any:
    headers = {
        "Accept": "application/json",
        "User-Agent": "Atlas-10-Crypto-Bridge/1.9.17 (+local-read-only-history)",
    }
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=max(1.0, float(timeout))) as response:
            raw = response.read()
        return json.loads(raw.decode("utf-8")) if raw else None
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")[:180]
        except Exception:
            body = ""
        suffix = f" · {body}" if body else ""
        raise RuntimeError(f"HTTP {exc.code}{suffix}") from exc


def history_cache_get(key: str, max_age_seconds: int) -> dict[str, Any] | None:
    with HISTORY_CACHE_LOCK:
        item = HISTORY_CACHE.get(key)
        if not item:
            return None
        if time.time() - float(item.get("saved_at", 0)) > max_age_seconds:
            HISTORY_CACHE.pop(key, None)
            return None
        payload = item.get("payload")
        return dict(payload) if isinstance(payload, dict) else None


def history_cache_put(key: str, payload: dict[str, Any]) -> None:
    with HISTORY_CACHE_LOCK:
        HISTORY_CACHE[key] = {"saved_at": time.time(), "payload": dict(payload)}
        if len(HISTORY_CACHE) > 160:
            oldest = sorted(HISTORY_CACHE, key=lambda item: HISTORY_CACHE[item].get("saved_at", 0))[:40]
            for stale in oldest:
                HISTORY_CACHE.pop(stale, None)


def history_fetch_binance_rows(symbol: str, interval: str, limit: int, total_timeout: float) -> list[Any]:
    deadline = time.monotonic() + max(2.0, total_timeout)
    errors: list[str] = []
    for base in HISTORY_BINANCE_BASES:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        url = (
            f"{base}/api/v3/klines?symbol={quote(symbol, safe='')}"
            f"&interval={quote(interval, safe='')}&limit={int(limit)}"
        )
        try:
            payload = history_request_json(url, min(5.0, remaining))
            if not isinstance(payload, list) or not payload:
                raise RuntimeError("chandelles absentes")
            return payload
        except Exception as exc:
            errors.append(f"{base}: {history_error_text(exc)}")
    raise RuntimeError(" | ".join(errors) or f"Binance indisponible pour {symbol}")


def history_normalize_binance(rows: list[Any]) -> tuple[list[list[float]], list[list[float]]]:
    series: list[list[float]] = []
    volumes: list[list[float]] = []
    for row in rows:
        if not isinstance(row, list) or len(row) < 8:
            continue
        try:
            timestamp = float(row[0])
            close = float(row[4])
            quote_volume = float(row[7])
        except (TypeError, ValueError):
            continue
        if timestamp > 0 and close > 0:
            series.append([timestamp, close])
            if quote_volume >= 0:
                volumes.append([timestamp, quote_volume])
    return series, volumes


def history_normalize_derived(
    crypto_rows: list[Any],
    eur_rows: list[Any],
) -> tuple[list[list[float]], list[list[float]]]:
    eur_by_time: dict[float, float] = {}
    for row in eur_rows:
        if not isinstance(row, list) or len(row) < 5:
            continue
        try:
            timestamp = float(row[0])
            close = float(row[4])
        except (TypeError, ValueError):
            continue
        if timestamp > 0 and close > 0:
            eur_by_time[timestamp] = close

    series: list[list[float]] = []
    volumes: list[list[float]] = []
    for row in crypto_rows:
        if not isinstance(row, list) or len(row) < 8:
            continue
        try:
            timestamp = float(row[0])
            crypto_close = float(row[4])
            quote_volume_usdt = float(row[7])
        except (TypeError, ValueError):
            continue
        eur_usdt = eur_by_time.get(timestamp)
        if timestamp > 0 and crypto_close > 0 and eur_usdt and eur_usdt > 0:
            series.append([timestamp, crypto_close / eur_usdt])
            if quote_volume_usdt >= 0:
                volumes.append([timestamp, quote_volume_usdt / eur_usdt])
    return series, volumes


def history_payload(
    *,
    coin_id: str,
    symbol: str,
    days: int,
    provider: str,
    source_mode: str,
    source: str,
    interval: str | None,
    api_days: int | str,
    series: list[list[float]],
    volume_series: list[list[float]],
    attempts: list[str],
) -> dict[str, Any]:
    generated_at = utc_now()
    if series:
        try:
            generated_at = datetime.fromtimestamp(series[-1][0] / 1000, timezone.utc).isoformat()
        except Exception:
            pass
    return {
        "ok": True,
        "read_only": True,
        "bridge_version": "1.9.17",
        "coin_id": coin_id,
        "symbol": symbol,
        "days": days,
        "provider": provider,
        "source_mode": source_mode,
        "source": source,
        "interval": interval,
        "api_days": api_days,
        "generated_at": generated_at,
        "point_count": len(series),
        "series": series,
        "volume_series": volume_series,
        "attempts": attempts,
    }


def fetch_history(config: dict[str, Any], coin_id: str, symbol: str, days: int, allow_binance: bool = True) -> dict[str, Any]:
    history_config = config.get("history_proxy", {})
    if history_config.get("enabled", True) is not True:
        raise RuntimeError("Proxy historique désactivé.")

    period = HISTORY_PERIODS[days]
    cache_seconds = int(history_config.get("cache_seconds", 60))
    cache_key = f"{coin_id}:{symbol}:{days}:{int(allow_binance)}"
    cached = history_cache_get(cache_key, cache_seconds)
    if cached:
        cached["cache"] = "bridge-memory-recent"
        return cached

    attempts: list[str] = []
    binance_timeout = float(history_config.get("binance_timeout_seconds", 12))
    coingecko_timeout = float(history_config.get("coingecko_timeout_seconds", 10))
    direct_symbol = f"{symbol}EUR"
    usdt_symbol = f"{symbol}USDT"

    if allow_binance:
        try:
            rows = history_fetch_binance_rows(
                direct_symbol,
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            series, volumes = history_normalize_binance(rows)
            if len(series) < 3:
                raise RuntimeError("série Binance EUR trop courte")
            payload = history_payload(
                coin_id=coin_id,
                symbol=symbol,
                days=days,
                provider="binance",
                source_mode="binance-bridge-direct-klines",
                source=f"Binance Spot {symbol}/EUR · Bridge local",
                interval=str(period["interval"]),
                api_days=period["api_days"],
                series=series,
                volume_series=volumes,
                attempts=attempts,
            )
            history_cache_put(cache_key, payload)
            return payload
        except Exception as exc:
            attempts.append(f"Binance {direct_symbol}: {history_error_text(exc)}")

        try:
            # Deux appels ont chacun un budget borné ; le cache du Bridge évite les répétitions.
            crypto_rows = history_fetch_binance_rows(
                usdt_symbol,
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            eur_rows = history_fetch_binance_rows(
                "EURUSDT",
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            series, volumes = history_normalize_derived(crypto_rows, eur_rows)
            if len(series) < 3:
                raise RuntimeError("série Binance USDT/EUR trop courte")
            payload = history_payload(
                coin_id=coin_id,
                symbol=symbol,
                days=days,
                provider="binance",
                source_mode="binance-bridge-derived-klines",
                source=f"Binance Spot {symbol}/USDT ÷ EUR/USDT · Bridge local",
                interval=str(period["interval"]),
                api_days=period["api_days"],
                series=series,
                volume_series=volumes,
                attempts=attempts,
            )
            history_cache_put(cache_key, payload)
            return payload
        except Exception as exc:
            attempts.append(f"Binance {usdt_symbol}/EURUSDT: {history_error_text(exc)}")

    else:
        attempts.append("Binance ignoré : symbole CoinGecko ambigu dans le Market")

    try:
        api_days = period["api_days"]
        url = (
            "https://api.coingecko.com/api/v3/coins/"
            f"{quote(coin_id, safe='')}/market_chart?vs_currency=eur"
            f"&days={quote(str(api_days), safe='')}&precision=full"
        )
        data = history_request_json(url, coingecko_timeout)
        raw_prices = data.get("prices", []) if isinstance(data, dict) else []
        raw_volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        series = [
            [float(row[0]), float(row[1])]
            for row in raw_prices
            if isinstance(row, list) and len(row) >= 2
            and float(row[0]) > 0 and float(row[1]) > 0
        ]
        volumes = [
            [float(row[0]), float(row[1])]
            for row in raw_volumes
            if isinstance(row, list) and len(row) >= 2
            and float(row[0]) > 0 and float(row[1]) >= 0
        ]
        if len(series) < 3:
            raise RuntimeError("série CoinGecko trop courte")
        payload = history_payload(
            coin_id=coin_id,
            symbol=symbol,
            days=days,
            provider="coingecko",
            source_mode="coingecko-bridge-direct",
            source="CoinGecko market_chart EUR · Bridge local",
            interval=None,
            api_days=api_days,
            series=series,
            volume_series=volumes,
            attempts=attempts,
        )
        history_cache_put(cache_key, payload)
        return payload
    except Exception as exc:
        attempts.append(f"CoinGecko {coin_id}: {history_error_text(exc)}")

    error = RuntimeError("Aucun historique direct disponible via le Bridge.")
    setattr(error, "attempts", attempts)
    raise error


def fetch_history_singleflight(
    config: dict[str, Any],
    coin_id: str,
    symbol: str,
    days: int,
    allow_binance: bool = True,
) -> dict[str, Any]:
    """Une seule récupération externe active par actif/période.

    Les requêtes Firefox concurrentes attendent le même résultat au lieu de
    relancer Binance/CoinGecko. Le résultat reste ensuite couvert par le cache
    mémoire normal du Bridge.
    """
    key = f"{coin_id}:{symbol}:{days}:{int(allow_binance)}"
    with HISTORY_INFLIGHT_LOCK:
        entry = HISTORY_INFLIGHT.get(key)
        owner = entry is None
        if owner:
            entry = {
                "event": threading.Event(),
                "payload": None,
                "error": None,
                "started_at": time.monotonic(),
            }
            HISTORY_INFLIGHT[key] = entry

    assert entry is not None
    if owner:
        try:
            payload = fetch_history(config, coin_id, symbol, days, allow_binance)
            entry["payload"] = payload
            return dict(payload)
        except Exception as exc:
            entry["error"] = exc
            raise
        finally:
            entry["event"].set()
            with HISTORY_INFLIGHT_LOCK:
                HISTORY_INFLIGHT.pop(key, None)

    wait_seconds = max(
        8.0,
        float(config.get("history_proxy", {}).get("singleflight_wait_seconds", 35)),
    )
    if not entry["event"].wait(wait_seconds):
        raise RuntimeError("Historique déjà en cours : délai d’attente dépassé.")
    payload = entry.get("payload")
    if isinstance(payload, dict):
        replay = dict(payload)
        replay["cache"] = "bridge-single-flight"
        return replay
    error = entry.get("error")
    if isinstance(error, Exception):
        raise RuntimeError(str(error)) from error
    raise RuntimeError("Historique simultané terminé sans résultat.")


def scanner_finite(value: Any, *, positive: bool = False) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not (number == number and abs(number) != float("inf")):
        return None
    if positive and number <= 0:
        return None
    return number


def scanner_safe_text(value: Any, limit: int = 160) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    return re.sub(r"\s+", " ", text)[:limit]


def scanner_validate_asset(asset: Any, basket: str, index: int) -> dict[str, Any]:
    if not isinstance(asset, dict):
        raise ValueError(f"Actif invalide dans {basket} à la position {index + 1}.")
    coin_id = scanner_safe_text(asset.get("coin_id"), 80)
    symbol = scanner_safe_text(asset.get("symbol"), 20)
    if not coin_id or not re.fullmatch(r"[a-z0-9-]{1,80}", coin_id):
        raise ValueError(f"coin_id invalide dans {basket}.")
    if not symbol or not re.fullmatch(r"[A-Z0-9]{1,20}", symbol):
        raise ValueError(f"symbol invalide dans {basket}.")
    return {
        "coin_id": coin_id,
        "symbol": symbol,
        "name": scanner_safe_text(asset.get("name"), 120),
        "market_rank": scanner_finite(asset.get("market_rank")),
        "scanner_rank": scanner_finite(asset.get("scanner_rank")),
        "classification_source": scanner_safe_text(asset.get("classification_source"), 100),
        "classification_metric": scanner_safe_text(asset.get("classification_metric"), 60),
        "classification_value": scanner_finite(asset.get("classification_value")),
        "market_price_eur": scanner_finite(asset.get("market_price_eur"), positive=True),
        "market_change_24h_pct": scanner_finite(asset.get("market_change_24h_pct")),
        "market_volume_24h_eur": scanner_finite(asset.get("market_volume_24h_eur")),
        "observed_price_eur": scanner_finite(asset.get("observed_price_eur"), positive=True),
        "observed_change_24h_pct": scanner_finite(asset.get("observed_change_24h_pct")),
        "observed_source": scanner_safe_text(asset.get("observed_source"), 160),
        "observed_status": scanner_safe_text(asset.get("observed_status"), 40),
        "observed_at": scanner_safe_text(asset.get("observed_at"), 60),
        "binance_symbol_candidate": scanner_safe_text(asset.get("binance_symbol_candidate"), 20),
        "binance_candidate_allowed": asset.get("binance_candidate_allowed") is True,
    }


def scanner_validate_snapshot(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Snapshot scanner invalide.")
    if payload.get("schema") != SCANNER_SCHEMA:
        raise ValueError(f"Schéma scanner refusé : {payload.get('schema')!r}.")
    snapshot_id = scanner_safe_text(payload.get("snapshot_id"), 140)
    collector_id = scanner_safe_text(payload.get("collector_id"), 100)
    collected_at = scanner_safe_text(payload.get("collected_at"), 60)
    if not snapshot_id or not re.fullmatch(r"[A-Za-z0-9_.-]{1,140}", snapshot_id):
        raise ValueError("snapshot_id scanner invalide.")
    if not collector_id:
        raise ValueError("collector_id scanner absent.")
    baskets_raw = payload.get("baskets")
    if not isinstance(baskets_raw, dict):
        raise ValueError("Paniers scanner absents.")

    baskets: dict[str, Any] = {}
    for key in SCANNER_BASKETS:
        raw = baskets_raw.get(key)
        if not isinstance(raw, dict):
            raise ValueError(f"Panier {key} absent.")
        assets_raw = raw.get("assets")
        if not isinstance(assets_raw, list) or not 1 <= len(assets_raw) <= 5:
            raise ValueError(f"Panier {key} : 1 à 5 actifs requis.")
        assets = [scanner_validate_asset(asset, key, index) for index, asset in enumerate(assets_raw)]
        coin_ids = [asset["coin_id"] for asset in assets]
        if len(set(coin_ids)) != len(coin_ids):
            raise ValueError(f"Panier {key} : actif dupliqué.")
        baskets[key] = {
            "id": key,
            "label": scanner_safe_text(raw.get("label"), 80) or key,
            "ranking_source": scanner_safe_text(raw.get("ranking_source"), 120),
            "ranking_metric": scanner_safe_text(raw.get("ranking_metric"), 80),
            "assets": assets,
        }

    market_raw = payload.get("market") if isinstance(payload.get("market"), dict) else {}
    exchange_raw = payload.get("exchange_feed") if isinstance(payload.get("exchange_feed"), dict) else {}
    return {
        "schema": SCANNER_SCHEMA,
        "snapshot_id": snapshot_id,
        "collector_id": collector_id,
        "collector_type": scanner_safe_text(payload.get("collector_type"), 60) or "agent_crypto_browser",
        "release": scanner_safe_text(payload.get("release"), 100),
        "collected_at": collected_at or utc_now(),
        "received_at": utc_now(),
        "reason": scanner_safe_text(payload.get("reason"), 80),
        "market": {
            "source": scanner_safe_text(market_raw.get("source"), 100),
            "mode": scanner_safe_text(market_raw.get("mode"), 40),
            "status": scanner_safe_text(market_raw.get("status"), 40),
            "timestamp": scanner_safe_text(market_raw.get("timestamp"), 60),
            "snapshot_id": scanner_safe_text(market_raw.get("snapshot_id"), 140),
            "assets_loaded": scanner_finite(market_raw.get("assets_loaded")),
            "target_assets": scanner_finite(market_raw.get("target_assets")),
            "quote_currency": scanner_safe_text(market_raw.get("quote_currency"), 12) or "EUR",
        },
        "exchange_feed": {
            "source": scanner_safe_text(exchange_raw.get("source"), 100),
            "status": scanner_safe_text(exchange_raw.get("status"), 40),
            "last_message_at": scanner_safe_text(exchange_raw.get("last_message_at"), 60),
            "direct_pairs": scanner_finite(exchange_raw.get("direct_pairs")),
            "derived_pairs": scanner_finite(exchange_raw.get("derived_pairs")),
        },
        "baskets": baskets,
        "safety": {
            "observation_only": True,
            "no_exchange_action": True,
            "no_wallet_action": True,
            "no_github_write": True,
            "ranking_never_decided_by_binance": True,
        },
    }


def scanner_binance_tickers(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    scanner_cfg = config.get("scanner_collector", {})
    ttl = max(10, int(scanner_cfg.get("binance_ticker_cache_seconds", 30)))
    with SCANNER_BINANCE_TICKER_LOCK:
        if time.time() - float(SCANNER_BINANCE_TICKER_CACHE.get("saved_at", 0)) <= ttl:
            rows = SCANNER_BINANCE_TICKER_CACHE.get("rows")
            if isinstance(rows, dict) and rows:
                return rows

    errors: list[str] = []
    timeout = max(2.0, float(scanner_cfg.get("binance_timeout_seconds", 6)))
    for base in HISTORY_BINANCE_BASES:
        try:
            payload = history_request_json(f"{base}/api/v3/ticker/24hr?type=MINI", timeout)
            if not isinstance(payload, list):
                raise RuntimeError("tickers Binance absents")
            rows = {
                str(row.get("symbol") or "").upper(): row
                for row in payload
                if isinstance(row, dict) and row.get("symbol")
            }
            if not rows:
                raise RuntimeError("catalogue ticker Binance vide")
            with SCANNER_BINANCE_TICKER_LOCK:
                SCANNER_BINANCE_TICKER_CACHE["saved_at"] = time.time()
                SCANNER_BINANCE_TICKER_CACHE["rows"] = rows
            return rows
        except Exception as exc:
            errors.append(history_error_text(exc))
    raise RuntimeError(" | ".join(errors) or "Tickers Binance indisponibles")


def scanner_binance_row_price(row: dict[str, Any] | None) -> tuple[float | None, float | None, float | None]:
    if not isinstance(row, dict):
        return None, None, None
    price = scanner_finite(row.get("lastPrice"), positive=True)
    change = scanner_finite(row.get("priceChangePercent"))
    volume = scanner_finite(row.get("quoteVolume"))
    return price, change, volume


def scanner_enrich_asset_binance(asset: dict[str, Any], rows: dict[str, dict[str, Any]], config: dict[str, Any]) -> dict[str, Any]:
    result = dict(asset)
    symbol = str(asset.get("binance_symbol_candidate") or "").upper()
    if not asset.get("binance_candidate_allowed") or not re.fullmatch(r"[A-Z0-9]{2,15}", symbol):
        result["binance_enrichment"] = "not_allowed"
        return result

    reference = scanner_finite(asset.get("market_price_eur"), positive=True)
    if not reference:
        result["binance_enrichment"] = "missing_reference"
        return result

    eur_price, eur_change, eur_volume = scanner_binance_row_price(rows.get(f"{symbol}EUR"))
    usdt_price, usdt_change, usdt_volume = scanner_binance_row_price(rows.get(f"{symbol}USDT"))
    eurusdt_price, eurusdt_change, _ = scanner_binance_row_price(rows.get("EURUSDT"))

    candidate_price = None
    candidate_change = None
    candidate_volume = None
    source = None
    pair = None
    if eur_price:
        candidate_price = eur_price
        candidate_change = eur_change
        candidate_volume = eur_volume
        pair = f"{symbol}EUR"
        source = f"Binance {symbol}/EUR ticker 24 h"
    elif usdt_price and eurusdt_price:
        candidate_price = usdt_price / eurusdt_price
        if usdt_change is not None:
            denominator = 1 + (eurusdt_change or 0) / 100
            candidate_change = ((1 + usdt_change / 100) / denominator - 1) * 100 if denominator > 0 else usdt_change
        candidate_volume = usdt_volume / eurusdt_price if usdt_volume is not None else None
        pair = f"{symbol}USDT/EURUSDT"
        source = f"Binance {symbol}/USDT ÷ EUR/USDT ticker 24 h"

    if not candidate_price:
        result["binance_enrichment"] = "pair_unavailable"
        return result

    max_gap = max(0.01, min(0.50, float(config.get("scanner_collector", {}).get("max_price_alignment_gap_ratio", 0.12))))
    gap = abs(candidate_price - reference) / reference
    if gap > max_gap:
        result["binance_enrichment"] = "rejected_price_alignment"
        result["binance_alignment_gap_ratio"] = round(gap, 6)
        return result

    result.update({
        "observed_price_eur": candidate_price,
        "observed_change_24h_pct": candidate_change if candidate_change is not None else result.get("observed_change_24h_pct"),
        "observed_source": source,
        "observed_status": "live_binance_verified",
        "observed_at": utc_now(),
        "binance_enrichment": "accepted_price_alignment",
        "binance_pair": pair,
        "binance_alignment_gap_ratio": round(gap, 6),
        "binance_quote_volume_eur": candidate_volume,
    })
    return result


def scanner_enrich_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    scanner_cfg = config.get("scanner_collector", {})
    if not scanner_cfg.get("binance_enrichment", True):
        return snapshot
    try:
        rows = scanner_binance_tickers(config)
    except Exception as exc:
        snapshot["binance_enrichment"] = {"status": "unavailable", "error": history_error_text(exc)}
        return snapshot

    accepted = 0
    rejected = 0
    for basket in snapshot.get("baskets", {}).values():
        enriched_assets = []
        for asset in basket.get("assets", []):
            enriched = scanner_enrich_asset_binance(asset, rows, config)
            if enriched.get("binance_enrichment") == "accepted_price_alignment":
                accepted += 1
            elif enriched.get("binance_candidate_allowed"):
                rejected += 1
            enriched_assets.append(enriched)
        basket["assets"] = enriched_assets
    snapshot["binance_enrichment"] = {
        "status": "complete",
        "accepted_assets": accepted,
        "not_accepted_assets": rejected,
        "method": "unique_symbol_plus_price_alignment",
        "ranking_unchanged": True,
    }
    return snapshot


def scanner_data_config(config: dict[str, Any]) -> dict[str, Any]:
    cfg = config.get("scanner_collector", {})
    return {
        "enabled": cfg.get("enabled", True) is True,
        "retention_days": max(1, min(90, int(cfg.get("retention_days", 14)))),
        "max_history_rows": max(1, min(5000, int(cfg.get("max_history_rows", 720)))),
    }


def scanner_prune_files(config: dict[str, Any]) -> None:
    cfg = scanner_data_config(config)
    cutoff = time.time() - cfg["retention_days"] * 86400
    if not SCANNER_DATA_DIR.exists():
        return
    for file in SCANNER_DATA_DIR.glob("20??-??-??.jsonl"):
        try:
            if file.stat().st_mtime < cutoff:
                file.unlink(missing_ok=True)
        except OSError:
            pass


def scanner_read_latest() -> dict[str, Any] | None:
    try:
        payload = load_json(SCANNER_LATEST_PATH)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def scanner_persist_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    cfg = scanner_data_config(config)
    if not cfg["enabled"]:
        raise RuntimeError("Scanner Live Collector désactivé dans bridge_config.json.")
    SCANNER_DATA_DIR.mkdir(parents=True, exist_ok=True)
    with SCANNER_WRITE_LOCK:
        latest = scanner_read_latest()
        if latest and latest.get("snapshot_id") == snapshot.get("snapshot_id"):
            return {"duplicate": True, "path": str(SCANNER_LATEST_PATH.relative_to(ROOT))}
        day = str(snapshot.get("collected_at") or utc_now())[:10]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        daily = SCANNER_DATA_DIR / f"{day}.jsonl"
        line = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")) + "\n"
        with daily.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(line)
        temp = SCANNER_LATEST_PATH.with_suffix(".tmp")
        temp.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(SCANNER_LATEST_PATH)
        scanner_prune_files(config)
        return {"duplicate": False, "path": str(daily.relative_to(ROOT))}


def scanner_history(config: dict[str, Any], basket: str, limit: int) -> list[dict[str, Any]]:
    if basket not in SCANNER_BASKETS:
        raise ValueError("basket autorisé : top5, gainers, losers ou volume.")
    max_rows = scanner_data_config(config)["max_history_rows"]
    limit = max(1, min(max_rows, int(limit)))
    if not SCANNER_DATA_DIR.exists():
        return []
    rows: list[dict[str, Any]] = []
    files = sorted(SCANNER_DATA_DIR.glob("20??-??-??.jsonl"), reverse=True)
    for file in files:
        try:
            lines = file.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in reversed(lines):
            try:
                payload = json.loads(line)
            except Exception:
                continue
            basket_payload = payload.get("baskets", {}).get(basket)
            if not isinstance(basket_payload, dict):
                continue
            rows.append({
                "snapshot_id": payload.get("snapshot_id"),
                "collected_at": payload.get("collected_at"),
                "market": payload.get("market"),
                "exchange_feed": payload.get("exchange_feed"),
                "binance_enrichment": payload.get("binance_enrichment"),
                "basket": basket_payload,
            })
            if len(rows) >= limit:
                return list(reversed(rows))
    return list(reversed(rows))


def scanner_status(config: dict[str, Any]) -> dict[str, Any]:
    latest = scanner_read_latest()
    files = sorted(SCANNER_DATA_DIR.glob("20??-??-??.jsonl")) if SCANNER_DATA_DIR.exists() else []
    return {
        "ok": True,
        "bridge_version": "1.9.17",
        "schema": SCANNER_SCHEMA,
        "enabled": scanner_data_config(config)["enabled"],
        "storage": "local_jsonl",
        "data_directory": str(SCANNER_DATA_DIR.relative_to(ROOT)),
        "daily_files": len(files),
        "latest_snapshot_id": latest.get("snapshot_id") if latest else None,
        "latest_collected_at": latest.get("collected_at") if latest else None,
        "latest_market_timestamp": latest.get("market", {}).get("timestamp") if latest else None,
        "basket_counts": {
            key: len(latest.get("baskets", {}).get(key, {}).get("assets", [])) if latest else 0
            for key in SCANNER_BASKETS
        },
        "read_only_external": True,
        "local_observation_storage": True,
    }


def provider_status(config: dict[str, Any], name: str) -> dict[str, Any]:
    provider = config["providers"][name]
    if not provider.get("enabled"):
        return {"enabled": False, "online": False, "models": [], "error": "désactivé"}

    base = provider["base_url"].rstrip("/")
    try:
        if name == "ollama":
            payload = request_json(f"{base}/api/tags", None, 2)
            models = [
                item.get("name", "")
                for item in payload.get("models", [])
                if item.get("name")
            ]
        else:
            payload = request_json(f"{base}/models", None, 2)
            models = [
                item.get("id", "")
                for item in payload.get("data", [])
                if item.get("id")
            ]
        return {"enabled": True, "online": True, "models": models, "error": ""}
    except Exception as exc:
        return {
            "enabled": True,
            "online": False,
            "models": [],
            "error": str(exc)[:180],
        }


def resolve_required_model(configured: str, models: list[str]) -> str:
    configured = str(configured or "").strip()
    if configured in models:
        return configured

    configured_base = configured.split(":", 1)[0]
    for model in models:
        if model.split(":", 1)[0] == configured_base:
            return model
    return ""


def choose_provider(
    config: dict[str, Any],
    statuses: dict[str, dict[str, Any]] | None = None,
) -> tuple[str, str]:
    """Resolve the active provider without re-probing when status is already known.

    V1.9.5 /health built a provider inventory and then called choose_provider(),
    which probed Ollama a second time in the same HTTP request. Under model load
    that could keep /api/tags busy almost continuously when the Control Center
    also refreshed frequently. V1.9.6 reuses the first inventory.
    """
    preferred = str(config.get("preferred_provider") or "ollama")
    order = [preferred]
    if config.get("allow_provider_fallback", False):
        order.extend(name for name in ("ollama", "lm_studio") if name != preferred)

    for name in order:
        if name not in config["providers"]:
            continue
        provider = config["providers"][name]
        if not provider.get("enabled"):
            continue
        status = (statuses or {}).get(name)
        if not isinstance(status, dict):
            status = provider_status(config, name)
        if not status.get("online"):
            continue
        configured = str(provider.get("model") or "").strip()
        models = list(status.get("models") or [])
        if configured:
            resolved = resolve_required_model(configured, models)
            if resolved:
                return name, resolved
            if provider.get("required"):
                raise RuntimeError(
                    f"Modèle requis absent : {configured}. "
                    f"Installe-le avec : ollama pull {configured}"
                )
        elif models:
            return name, models[0]

    raise RuntimeError(
        "Aucun moteur local prêt. Lance Ollama et vérifie gpt-oss:20b-32k."
    )


def profile_health() -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, canonical_files in CANONICAL_PROFILE_FILES.items():
        runtime_file = RUNTIME_PROFILE_FILES[name]
        missing = [
            str(path.relative_to(ROOT))
            for path in (*canonical_files, runtime_file)
            if not path.exists()
        ]
        result[name] = {
            "loaded": not missing,
            "runtime_mode": "atlas_aerith_fact_contract_v2_v3_truth_evidence_gpt_oss_32k",
            "canonical_files_present": all(path.exists() for path in canonical_files),
            "runtime_file_present": runtime_file.exists(),
            "missing": missing,
        }
    return result


def validate_contract(snapshot: dict[str, Any]) -> dict[str, Any]:
    contract = snapshot.get("strict_contract")
    if not isinstance(contract, dict):
        raise ValueError("Contrat factuel absent du snapshot.")

    schema = str(contract.get("schema") or "").strip()
    allowed = {
        "atlas_crypto_fact_contract_v2",
        "atlas_crypto_fact_contract_v3_truth_evidence",
    }
    if schema not in allowed:
        raise ValueError(
            f"Schéma factuel refusé : {schema!r}; attendus : V2 ou V3 Truth/Evidence."
        )

    top5 = contract.get("canonical_top5")
    if not isinstance(top5, dict):
        raise ValueError("Target Top 5 canonique absent.")

    symbols = top5.get("symbols")
    if symbols != ["BTC", "ETH", "BNB", "XRP", "SOL"]:
        raise ValueError("Target Top 5 non canonique.")

    rules = contract.get("rules")
    if not isinstance(rules, dict):
        raise ValueError("Règles du contrat absentes.")

    required_true = (
        "market_list_is_not_portfolio",
        "no_missing_value_to_zero",
        "no_visual_position_inference",
        "no_unlisted_math_measure",
        "no_news_from_generic_limit",
        "no_financial_instruction",
    )
    for key in required_true:
        if rules.get(key) is not True:
            raise ValueError(f"Règle factuelle non verrouillée : {key}.")

    if schema == "atlas_crypto_fact_contract_v3_truth_evidence":
        required_layers = (
            "source_truth_v2",
            "evidence_v2",
            "math_quality_gates_v2",
            "contradictions_v2",
        )
        for key in required_layers:
            if not isinstance(contract.get(key), dict):
                raise ValueError(f"Couche V3 absente ou invalide : {key}.")
        required_v3_rules = (
            "analytical_fingerprint_v2",
            "source_truth_v2",
            "evidence_independence_required",
            "metric_quality_gates",
            "transactional_conclusion",
        )
        for key in required_v3_rules:
            if rules.get(key) is not True:
                raise ValueError(f"Verrou V3 non actif : {key}.")
        analytical_state = snapshot.get("analytical_state")
        if not isinstance(analytical_state, dict):
            raise ValueError("État analytique V2 absent du snapshot V3.")
        fingerprint = analytical_state.get("fingerprint")
        if not isinstance(fingerprint, dict) or not str(fingerprint.get("value") or "").strip():
            raise ValueError("Empreinte analytique SHA-256 absente du snapshot V3.")

    return contract

def fmt_number(value: Any, digits: int = 2) -> str:
    number = float(value)
    text = f"{number:,.{digits}f}"
    return text.replace(",", "\u202f").replace(".", ",")


def fmt_price(value: Any) -> str:
    number = float(value)
    digits = 6 if abs(number) < 1 else 2
    return f"{fmt_number(number, digits)} €"


def fmt_pct(value: Any) -> str:
    number = float(value)
    sign = "+" if number > 0 else ""
    return f"{sign}{fmt_number(number, 2)} %"


def fmt_risk_pct(value: Any) -> str:
    number = float(value)
    return f"{fmt_number(abs(number), 2)} %"


def safe_value(value: Any, formatter=None) -> str:
    if value is None:
        return "indisponible"
    try:
        return formatter(value) if formatter else str(value)
    except Exception:
        return "indisponible"


STATUS_LABELS = {
    "ready": "prêt",
    "ok": "opérationnel",
    "loading": "chargement",
    "error": "erreur",
    "failed": "échec",
    "stale": "ancien",
    "live": "direct",
    "direct": "direct",
    "local-cache": "cache local",
    "recent-cache": "cache récent",
    "github-cache": "cache GitHub",
    "browser-cache": "cache navigateur",
    "cache": "cache",
    "fresh": "récent",
    "delayed": "retardé",
    "archive": "archive datée",
    "expired": "expiré",
    "linear": "linéaire",
    "log": "logarithmique",
    "price": "prix",
    "base100": "base 100",
    "normal": "normale",
}


def clean_sentence(value: Any) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r"\s+([,;:!?])", r"\1", text)
    text = re.sub(r"([.!?])\1+$", r"\1", text)
    text = re.sub(r"\.{2,}$", ".", text)
    return text


def label_status(value: Any, fallback: str = "inconnu") -> str:
    text = str(value or "").strip()
    if not text:
        return fallback
    return STATUS_LABELS.get(text.lower(), text)


def format_datetime_fr(value: Any) -> str:
    if value in (None, ""):
        return "indisponible"
    text = str(value).strip()
    try:
        normalized = text.replace("Z", "+00:00")
        date = datetime.fromisoformat(normalized)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        local = date.astimezone()
        return local.strftime("%d/%m/%Y à %H:%M:%S")
    except Exception:
        return clean_sentence(text)


def format_score_block(value: Any, fallback: str = "inconnu") -> str:
    if value is None:
        return fallback
    if isinstance(value, dict):
        level = (
            value.get("level")
            or value.get("label")
            or value.get("name")
            or value.get("status")
        )
        score = value.get("score")
        if level and score is not None:
            return f"{clean_sentence(level)} — score {safe_value(score)}/100"
        if level:
            return clean_sentence(level)
        if score is not None:
            return f"score {safe_value(score)}/100"
        compact = [
            f"{clean_sentence(key)} : {clean_sentence(item)}"
            for key, item in value.items()
            if item not in (None, "", [], {})
        ]
        return " · ".join(compact) if compact else fallback
    return clean_sentence(value) or fallback


def normalize_model_comment(value: Any) -> dict[str, str] | None:
    if not isinstance(value, dict):
        return None

    candidate = value
    for wrapper in ("comment", "commentaire", "response", "réponse", "analysis", "analyse"):
        nested = candidate.get(wrapper)
        if isinstance(nested, dict):
            candidate = nested
            break

    aliases = {
        "reading": ("reading", "lecture", "analyse", "interpretation", "interprétation"),
        "caution": ("caution", "prudence", "vigilance", "risque"),
        "limits": ("limits", "limites", "limit", "borne", "bornes"),
    }

    normalized: dict[str, str] = {}
    for target, keys in aliases.items():
        for key in keys:
            item = candidate.get(key)
            if isinstance(item, str) and item.strip():
                normalized[target] = clean_sentence(item)
                break

    return normalized if normalized else None


def parse_model_comment(raw: str) -> dict[str, str] | None:
    text = str(raw or "").strip()
    if not text:
        return None

    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)

    candidates = [text]
    first = text.find("{")
    last = text.rfind("}")
    if first >= 0 and last > first:
        candidates.append(text[first:last + 1])

    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            normalized = normalize_model_comment(parsed)
            if normalized:
                return normalized
        except Exception:
            pass

    labeled: dict[str, str] = {}
    label_map = {
        "reading": ("reading", "lecture", "analyse"),
        "caution": ("caution", "prudence", "vigilance"),
        "limits": ("limits", "limites", "bornes"),
    }
    for target, labels in label_map.items():
        for label in labels:
            match = re.search(
                rf"(?im)^\s*(?:[-*]\s*)?(?:\*\*)?{re.escape(label)}(?:\*\*)?\s*[:\-]\s*(.+)$",
                text,
            )
            if match:
                labeled[target] = clean_sentence(match.group(1))
                break

    return labeled if labeled else None


def freshness_label(value: Any, fallback: str = "inconnue") -> str:
    text = str(value or "").strip()
    if not text:
        return fallback
    return FRESHNESS_LABELS.get(text.lower(), text)


def model_comment_profile(profile: str) -> str:
    return MODEL_COMMENT_PROFILES.get(profile, MODEL_COMMENT_PROFILES["atlas"])


def sanitize_comment_question(value: Any) -> str:
    text = clean_sentence(value)
    if not text:
        return ""

    for pattern in FORBIDDEN_MODEL_PATTERNS:
        text = re.sub(
            pattern,
            "élément réservé au rapport factuel",
            text,
            flags=re.I | re.S,
        )

    text = re.sub(
        r"-?\d+(?:[.,]\d+)?",
        "valeur réservée au rapport factuel",
        text,
    )
    return clean_sentence(text)[:280]


def model_comment_facts(
    contract: dict[str, Any],
    mode: str,
    question: str,
) -> dict[str, Any]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    top5 = contract.get("canonical_top5", {})
    graph = contract.get("graph", {})
    math = contract.get("math", {})
    news = contract.get("news", {})
    contradictions = contract.get("contradictions") or []

    facts = {
        "mission": mode,
        "sources": {
            "binance": label_status(
                contract.get("sources", {}).get("binance", {}).get("feed_status")
            ),
            "coingecko": label_status(
                contract.get("sources", {}).get("coingecko", {}).get("status")
            ),
        },
        "market": {
            "breadth": clean_sentence(
                breadth.get("classification") or "indéterminée"
            ),
            "coverage": (
                "complète"
                if market.get("assets_loaded") == market.get("target_assets")
                else "partielle"
            ),
        },
        "target_group": {
            "coverage": "complète" if top5.get("complete") else "partielle",
        },
        "graph": {
            "history": clean_sentence(
                graph.get("truth_label") or "indisponible"
            ),
            "freshness": freshness_label(graph.get("freshness")),
            "series_available": bool(graph.get("series")),
        },
        "math": {
            "coverage": clean_sentence(math.get("coverage") or "indisponible"),
            "horizon_coherence": clean_sentence(
                math.get("horizon_coherence") or "indisponible"
            ),
            "amplitude": clean_sentence(
                math.get("amplitude_24h") or "indisponible"
            ),
            "global_risk": clean_sentence(
                math.get("risk_global") or "non évalué"
            ),
        },
        "news": {
            "status": label_status(news.get("status")),
            "qualified_event_available": bool(news.get("lead_event")),
            "lead_event": clean_sentence((news.get("lead_event") or {}).get("event_label") or "") or None,
            "lead_source": clean_sentence((news.get("lead_event") or {}).get("source_name") or "") or None,
            "lead_evidence": (news.get("lead_event") or {}).get("evidence"),
            "lead_impact": (news.get("lead_event") or {}).get("impact"),
            "lead_assets": (news.get("lead_event") or {}).get("assets") or [],
        },
        "nox_no_fomo": contract.get("nox_no_fomo_v1") or {},
        "limits_present": bool(contradictions),
    }

    if mode == "chat":
        intent = sanitize_comment_question(question)
        if intent:
            facts["question_intent"] = intent

    if mode == "conclusion":
        report_bundle = contract.get("atlas_reports_v1") or {}
        if isinstance(report_bundle, dict):
            facts["atlas_reports_re_read"] = True
            facts["atlas_reports"] = {
                key: {
                    "label": value.get("label"),
                    "answer": value.get("answer"),
                    "fingerprint": value.get("fingerprint"),
                    "model": value.get("model"),
                }
                for key, value in report_bundle.items()
                if key in CONCLUSION_REPORT_MODES and isinstance(value, dict)
            }

    source_truth = contract.get("source_truth_v2") or {}
    evidence = contract.get("evidence_v2") or {}
    quality = contract.get("math_quality_gates_v2") or {}
    contradictions_v2 = contract.get("contradictions_v2") or {}
    facts["truth_evidence"] = {
        "source_modes": source_truth.get("counts") or {},
        "public_source_failures": source_truth.get("public_source_failures"),
        "evidence_counts": evidence.get("counts") or {},
        "math_quality_counts": quality.get("counts") or {},
        "contradiction_counts": contradictions_v2.get("counts") or {},
    }

    return facts


CONCLUSION_REPORT_MODES = ("market", "top5", "math", "contradictions")
CONCLUSION_REPORT_MAX_CHARS_EACH = 10000
CONCLUSION_REPORT_MAX_CHARS_TOTAL = 36000

def normalize_conclusion_reports(value: Any, fingerprint: str) -> dict[str, dict[str, Any]]:
    if not fingerprint:
        raise ValueError("Fingerprint Atlas CURRENT manquant pour la conclusion.")
    if not isinstance(value, dict):
        raise ValueError("Les quatre rapports Atlas-10 CURRENT doivent être transmis à Aerith.")

    normalized: dict[str, dict[str, Any]] = {}
    total = 0
    for mode in CONCLUSION_REPORT_MODES:
        raw = value.get(mode)
        if not isinstance(raw, dict):
            raise ValueError(f"Rapport Atlas CURRENT manquant : {mode}.")
        answer = str(raw.get("answer") or "").replace("\r\n", "\n").strip()
        report_fp = str(raw.get("fingerprint") or "").strip()
        if report_fp != fingerprint:
            raise ValueError(f"Fingerprint du rapport {mode} différent du snapshot CURRENT.")
        if len(answer) < 120:
            raise ValueError(f"Rapport Atlas CURRENT vide ou trop court : {mode}.")
        answer = answer[:CONCLUSION_REPORT_MAX_CHARS_EACH]
        remaining = CONCLUSION_REPORT_MAX_CHARS_TOTAL - total
        if remaining <= 0:
            raise ValueError("Volume des rapports Atlas trop important pour le contexte de conclusion.")
        answer = answer[:remaining]
        total += len(answer)
        normalized[mode] = {
            "mode": mode,
            "label": clean_sentence(raw.get("label") or MODE_LABELS.get(mode) or mode),
            "answer": answer,
            "fingerprint": report_fp,
            "model": clean_sentence(raw.get("model") or ""),
            "time": clean_sentence(raw.get("time") or ""),
        }

    if set(normalized) != set(CONCLUSION_REPORT_MODES):
        raise ValueError("Les quatre rapports Atlas CURRENT ne sont pas complets.")
    return normalized

def aerith_atlas_reports_re_read_lines(contract: dict[str, Any]) -> list[str]:
    reports = contract.get("atlas_reports_v1") or {}
    if not isinstance(reports, dict) or any(mode not in reports for mode in CONCLUSION_REPORT_MODES):
        return ["- Relecture Atlas : INFORMATION MANQUANTE."]
    lines = ["- Les quatre rapports Atlas-10 CURRENT ont été transmis et relus avant cette synthèse."]
    for index, mode in enumerate(CONCLUSION_REPORT_MODES, start=1):
        report = reports.get(mode) or {}
        label = clean_sentence(report.get("label") or MODE_LABELS.get(mode) or mode)
        model = clean_sentence(report.get("model") or "modèle local")
        lines.append(f"- 0{index} · {label} · {model} · même fingerprint CURRENT.")
    return lines


def deterministic_sources(contract: dict[str, Any]) -> list[str]:
    binance = contract.get("sources", {}).get("binance", {})
    coingecko = contract.get("sources", {}).get("coingecko", {})
    return [
        f"- Binance : {label_status(binance.get('feed_status'))}"
        f" · {clean_sentence(binance.get('source') or 'source non précisée')}"
        f" · {safe_value(binance.get('direct_pairs'))} paires directes"
        f" · {safe_value(binance.get('derived_pairs'))} dérivées.",
        f"- CoinGecko : {label_status(coingecko.get('status'))}"
        f" · mode {label_status(coingecko.get('mode'))}"
        f" · horodatage {format_datetime_fr(coingecko.get('timestamp'))}.",
    ]


def deterministic_top5(contract: dict[str, Any]) -> list[str]:
    top5 = contract["canonical_top5"]
    lines = [
        f"Target canonique : {' / '.join(top5['symbols'])}.",
        f"Couverture : {'5/5' if top5.get('complete') else 'partielle'}.",
    ]
    for row in top5.get("assets", []):
        symbol = row.get("symbol") or "?"
        if not row.get("available"):
            lines.append(f"- {symbol} : prix indisponible.")
            continue
        lines.append(
            f"- {symbol} : {safe_value(row.get('price_eur'), fmt_price)}"
            f" · 24 h {safe_value(row.get('change_24h_pct'), fmt_pct)}"
            f" · {clean_sentence(row.get('source') or 'source inconnue')}"
            f" · état {label_status(row.get('quote_status'))}."
        )
    return lines


def deterministic_market(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    return [
        f"- Univers chargé : {safe_value(market.get('assets_loaded'))}/"
        f"{safe_value(market.get('target_assets'))} actifs, devise EUR.",
        f"- Largeur 24 h : {safe_value(breadth.get('positive'))} hausses"
        f" · {safe_value(breadth.get('negative'))} baisses"
        f" · {safe_value(breadth.get('stable'))} stables"
        f" · classification : {breadth.get('classification') or 'indéterminée'}.",
        f"- Base de calcul : {breadth.get('basis') or 'indisponible'}.",
    ]


def deterministic_graph(contract: dict[str, Any]) -> list[str]:
    graph = contract.get("graph", {})
    lines = [
        f"- Période : {clean_sentence(graph.get('period_label') or 'indisponible')}"
        f" · vue {label_status(graph.get('view'))}"
        f" · échelle {label_status(graph.get('scale'))}.",
        f"- Historique : {clean_sentence(graph.get('truth_label') or 'indisponible')}"
        f" · fournisseur {clean_sentence(graph.get('provider') or 'inconnu')}"
        f" · fraîcheur {freshness_label(graph.get('freshness'))}.",
        "- Règle : aucune tendance n’est déduite de la position verticale à l’écran.",
    ]

    series = graph.get("series") or []
    if series:
        for row in series:
            lines.append(
                f"- {clean_sentence(row.get('symbol') or '?')} : variation de série "
                f"{safe_value(row.get('series_change_pct'), fmt_pct)}"
                f" · {safe_value(row.get('points'))} points."
            )
    else:
        lines.append("- Aucune série exploitable dans le contrat.")

    return lines


def deterministic_math(contract: dict[str, Any]) -> list[str]:
    math = contract.get("math", {})
    window = math.get("active_window") or {}
    risk = math.get("historical_risk") or {}
    ci = risk.get("bootstrap_volatility_window_ci95_pct") or [None, None]

    lines = [
        f"- Actif : {math.get('asset') or 'indisponible'}.",
        f"- Score heuristique : {safe_value(math.get('heuristic_score'))}.",
        f"- Fenêtre active : {window.get('period_label') or 'indisponible'}"
        f" · granularité {window.get('granularity') or 'inconnue'}"
        f" · {safe_value(window.get('observations'))} points"
        f" · complétude {safe_value(window.get('completeness_pct'), fmt_pct)}.",
        f"- Volatilité réalisée sur la fenêtre : {safe_value(risk.get('realized_volatility_window_pct'), fmt_risk_pct)}.",
        f"- Volatilité réalisée annualisée : {safe_value(risk.get('realized_volatility_annualized_pct'), fmt_risk_pct)}.",
        f"- Volatilité EWMA annualisée : {safe_value(risk.get('ewma_volatility_annualized_pct'), fmt_risk_pct)}"
        f" · lambda {safe_value(risk.get('ewma_lambda'))}.",
        f"- Downside deviation annualisée : {safe_value(risk.get('downside_deviation_annualized_pct'), fmt_risk_pct)}.",
        f"- Drawdown maximal : {safe_value(risk.get('max_drawdown_pct'), fmt_risk_pct)}.",
        f"- VaR historique 95 % par pas : {safe_value(risk.get('var_historical_95_step_pct'), fmt_risk_pct)}.",
        f"- Expected Shortfall historique 95 % par pas : {safe_value(risk.get('expected_shortfall_historical_95_step_pct'), fmt_risk_pct)}.",
        f"- Corrélation au BTC : {safe_value(risk.get('correlation_btc'))}"
        f" · bêta {safe_value(risk.get('beta_btc'))}"
        f" · {safe_value(risk.get('benchmark_observations'))} observations alignées.",
        f"- Dispersion IQR par pas : {safe_value(risk.get('dispersion_iqr_step_pct'), fmt_risk_pct)}"
        f" · concentration des 10 % plus forts mouvements : {safe_value(risk.get('concentration_top10_absolute_moves_pct'), fmt_risk_pct)}.",
        f"- Intervalle bootstrap 95 % de volatilité de fenêtre : "
        f"{safe_value(ci[0] if len(ci) > 0 else None, fmt_risk_pct)} à "
        f"{safe_value(ci[1] if len(ci) > 1 else None, fmt_risk_pct)}"
        f" · {safe_value(risk.get('bootstrap_samples'))} rééchantillonnages.",
        f"- Ratio volume / capitalisation : {math.get('volume_market_cap_ratio') or 'indisponible'}.",
        f"- Risque global : {math.get('risk_global') or 'non évalué'}.",
        f"- Limite : {clean_sentence(math.get('limitation') or 'non précisée').rstrip('.')}.",
    ]

    not_calculated = math.get("explicitly_not_calculated") or []
    if not_calculated:
        lines.append("- Mesures non calculées : " + ", ".join(not_calculated) + ".")
    else:
        lines.append("- Toutes les mesures historiques prévues par Math Core V3 sont calculées pour cette fenêtre.")

    return lines


def deterministic_news(contract: dict[str, Any]) -> list[str]:
    news = contract.get("news", {})
    watchlist = contract.get("watchlist", {})
    lead = news.get("lead_event")

    lines = [
        f"- News Sentinel : {label_status(news.get('status'))}"
        f" · archive {format_datetime_fr(news.get('archive_time'))}.",
        f"- Watchlist : {safe_value(watchlist.get('configured_count'))} actifs observés"
        " · ce n’est pas un portefeuille.",
    ]

    if isinstance(lead, dict):
        lines.append(
            f"- Événement directeur : {clean_sentence(lead.get('headline') or lead.get('event_label') or 'sans titre')}"
            f" · preuve {format_score_block(lead.get('evidence'))}"
            f" · impact {format_score_block(lead.get('impact'))}."
        )
    else:
        lines.append("- Aucun événement directeur qualifié n’est fourni.")

    lines.append("- Une limite générale de données n’est jamais transformée en actualité.")
    return lines


def deterministic_contradictions(contract: dict[str, Any]) -> list[str]:
    issues = contract.get("contradictions") or []
    if not issues:
        return ["- Aucune contradiction déterministe enregistrée dans le contrat."]
    return [
        f"- [{clean_sentence(item.get('level') or 'à vérifier')}] "
        f"{clean_sentence(item.get('text') or item.get('code') or 'problème non décrit').rstrip('.')}."
        for item in issues
    ]


def deterministic_stop_point(contract: dict[str, Any]) -> list[str]:
    stop = contract.get("stop_point", {})
    return [
        f"- {stop.get('meaning') or 'Arrêter lorsque les données ne soutiennent plus la conclusion.'}",
        "- Aucune durée arbitraire n’est fixée.",
        "- La chaîne analytique Atlas → NØX → Aerith est automatique : aucune validation humaine n’est requise entre ses étapes.",
        "- Validation humaine uniquement avant une décision ou action financière réelle ; jamais pour autoriser la synthèse.",
    ]



def aerith_count_label(value: int, singular: str, plural: str) -> str:
    if value == 0:
        return f"aucun {singular}"
    if value == 1:
        return f"1 {singular}"
    return f"{value} {plural}"


def aerith_conclusion_situation(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    coverage = None
    try:
        loaded_n = int(loaded)
        target_n = int(target)
        if target_n > 0:
            coverage = (loaded_n / target_n) * 100
    except (TypeError, ValueError, ZeroDivisionError):
        coverage = None

    coverage_text = (
        f" ({fmt_number(coverage, 1)} % de couverture)" if coverage is not None else ""
    )
    return deterministic_sources(contract) + [
        f"- Univers chargé : {safe_value(loaded)}/{safe_value(target)} actifs{coverage_text}, devise EUR.",
        f"- État d’ensemble : {clean_sentence(breadth.get('classification') or 'indéterminée')}.",
        f"- Base de calcul : {breadth.get('basis') or 'indisponible'}.",
    ]


def aerith_conclusion_signal(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    top5 = contract.get("canonical_top5", {})

    try:
        positive_market = int(breadth.get("positive") or 0)
        negative_market = int(breadth.get("negative") or 0)
        stable_market = int(breadth.get("stable") or 0)
    except (TypeError, ValueError):
        positive_market = negative_market = stable_market = 0

    if positive_market > 0 and negative_market >= positive_market * 2:
        breadth_reading = (
            f"La pression baissière est large : {negative_market} baisses, "
            f"soit plus du double des {positive_market} hausses"
        )
    elif negative_market > 0 and positive_market >= negative_market * 2:
        breadth_reading = (
            f"La participation haussière est large : {positive_market} hausses, "
            f"soit plus du double des {negative_market} baisses"
        )
    elif positive_market == 0 and negative_market == 0:
        breadth_reading = "La largeur du marché n’est pas exploitable sur ce snapshot"
    else:
        breadth_reading = (
            f"La largeur reste partagée : {positive_market} hausses et {negative_market} baisses"
        )
    if stable_market:
        breadth_reading += f", avec {stable_market} actifs stables"
    breadth_reading += "."

    rows = [row for row in (top5.get("assets") or []) if row.get("available")]
    finite = [
        float(row.get("change_24h_pct"))
        for row in rows
        if isinstance(row.get("change_24h_pct"), (int, float))
    ]
    positives = sum(1 for value in finite if value > 0)
    negatives = sum(1 for value in finite if value < 0)
    stable = sum(1 for value in finite if value == 0)
    target_reading = " · ".join([
        aerith_count_label(positives, "actif positif", "actifs positifs"),
        aerith_count_label(negatives, "actif négatif", "actifs négatifs"),
        aerith_count_label(stable, "actif stable", "actifs stables"),
    ])
    return [
        f"- {breadth_reading}",
        f"- Target Top 5 : {target_reading} · couverture {'5/5' if top5.get('complete') else 'partielle'}.",
    ]


def aerith_conclusion_vigilance(contract: dict[str, Any]) -> list[str]:
    graph = contract.get("graph", {})
    math = contract.get("math", {})
    news = contract.get("news", {})
    watchlist = contract.get("watchlist", {})
    return [
        f"- Historique graphique : {clean_sentence(graph.get('truth_label') or 'indisponible')}"
        f" · fraîcheur {freshness_label(graph.get('freshness'))}.",
        f"- Math Core : {clean_sentence(math.get('risk_global') or 'risque global non évalué')}"
        f" · limite {clean_sentence(math.get('limitation') or 'non précisée').rstrip('.')}.",
        f"- News Sentinel : {label_status(news.get('status'))}.",
        f"- Watchlist : {safe_value(watchlist.get('configured_count'))} actifs observés"
        " · ce n’est pas un portefeuille.",
    ]


def aerith_conclusion_watch(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    graph = contract.get("graph", {})
    issues = contract.get("contradictions") or []
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    if loaded == target and loaded is not None:
        market_line = "- Vérifier que la prochaine lecture CoinGecko conserve la couverture complète du Market Snapshot."
    else:
        market_line = "- Vérifier si la prochaine lecture CoinGecko complète la couverture encore partielle du Market Snapshot."
    lines = [
        market_line,
        "- Contrôler la continuité des cinq cotations Binance directes du Target Top 5.",
        f"- Relever si la fraîcheur de l’historique graphique reste {freshness_label(graph.get('freshness'))} ou s’améliore.",
    ]
    if issues:
        lines.append("- Recontrôler les contradictions encore classées confirmées ou à vérifier.")
    else:
        lines.append("- Recontrôler l’apparition éventuelle d’une contradiction déterministe au prochain snapshot.")
    return lines



AERITH_GENERIC_COMMENT_PATTERNS = (
    r"^\s*(analyser|évaluer|utiliser|examiner|considérer|vérifier|contrôler|surveiller|prendre en compte|se baser)\b",
    r"\b(informations?|données?)\s+(fournies|disponibles)\b.{0,80}\b(sans ajout|sans modification)\b",
    r"\bqualité des données\b.{0,80}\bfiabilité des informations\b",
)


def aerith_market_coverage(contract: dict[str, Any]) -> tuple[int | None, int | None, float | None]:
    market = contract.get("market", {})
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    try:
        loaded_n = int(loaded)
        target_n = int(target)
        coverage = (loaded_n / target_n) * 100 if target_n > 0 else None
        return loaded_n, target_n, coverage
    except (TypeError, ValueError, ZeroDivisionError):
        return None, None, None


def aerith_top5_distribution(contract: dict[str, Any]) -> tuple[int, int, int, int]:
    rows = [
        row for row in (contract.get("canonical_top5", {}).get("assets") or [])
        if row.get("available")
    ]
    values = [
        float(row.get("change_24h_pct"))
        for row in rows
        if isinstance(row.get("change_24h_pct"), (int, float))
    ]
    positives = sum(1 for value in values if value > 0)
    negatives = sum(1 for value in values if value < 0)
    stable = sum(1 for value in values if value == 0)
    return positives, negatives, stable, len(values)


def aerith_concrete_limits_comment(contract: dict[str, Any]) -> dict[str, str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    graph = contract.get("graph", {})

    try:
        positive_market = int(breadth.get("positive") or 0)
        negative_market = int(breadth.get("negative") or 0)
    except (TypeError, ValueError):
        positive_market = negative_market = 0

    if positive_market > 0 and negative_market >= positive_market * 2:
        opening = "La pression baissière est largement partagée"
    elif negative_market > 0 and positive_market >= negative_market * 2:
        opening = "La participation haussière est largement partagée"
    elif positive_market or negative_market:
        opening = "La largeur du marché reste partagée"
    else:
        opening = "La largeur du marché reste insuffisamment documentée"

    loaded_n, target_n, coverage = aerith_market_coverage(contract)
    market_partial = (
        loaded_n is not None and target_n is not None and target_n > 0 and loaded_n < target_n
    )
    graph_freshness = freshness_label(graph.get("freshness"))
    graph_delayed = graph_freshness in {"retardée", "ancienne", "archivée", "expirée"}

    qualifiers: list[str] = []
    if market_partial:
        qualifiers.append("un Market Snapshot encore incomplet")
    if graph_delayed:
        qualifiers.append(f"un historique graphique {graph_freshness}")

    if qualifiers:
        reading = f"{opening}, mais elle repose sur " + " et sur ".join(qualifiers) + "."
    else:
        reading = f"{opening} sur les sources actuellement disponibles."
    reading += " Elle décrit l’état observé, pas son évolution future."

    positives, negatives, stable, count = aerith_top5_distribution(contract)
    if count and negatives == count:
        caution = (
            "Le Target Top 5 est entièrement négatif, mais cette convergence ne constitue "
            "ni une prévision ni un signal d’exécution."
        )
    elif count and positives == count:
        caution = (
            "Le Target Top 5 est entièrement positif, mais cette convergence ne constitue "
            "ni une prévision ni un signal d’exécution."
        )
    elif count:
        caution = (
            "Le Target Top 5 reste partagé ; cette distribution ne constitue ni une prévision "
            "ni un signal d’exécution."
        )
    else:
        caution = (
            "Le Target Top 5 n’est pas suffisamment couvert pour soutenir une prévision "
            "ou un signal d’exécution."
        )

    limits_parts = [
        "Les risques de protocole, de contrepartie, de réglementation, de liquidité d’exécution "
        "et les données on-chain ne sont pas évalués."
    ]
    if market_partial:
        if coverage is not None:
            limits_parts.append(
                f"La couverture CoinGecko reste partielle à {fmt_number(coverage, 1)} %."
            )
        else:
            limits_parts.append("La couverture CoinGecko reste partielle.")
    if graph_delayed:
        limits_parts.append("L’historique graphique ne fournit pas encore une fraîcheur directe.")

    return {
        "reading": reading,
        "caution": caution,
        "limits": " ".join(limits_parts),
    }


def validate_aerith_concrete_comment(
    comment: dict[str, Any],
    contract: dict[str, Any],
) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(comment, dict):
        return False, ["commentaire Aerith non structuré"]

    required = ("reading", "caution", "limits")
    values: dict[str, str] = {}
    for key in required:
        value = str(comment.get(key) or "").strip()
        values[key] = value
        if len(value) < 35:
            warnings.append(f"commentaire Aerith trop générique : {key}")
        lowered = value.lower()
        for pattern in AERITH_GENERIC_COMMENT_PATTERNS:
            if re.search(pattern, lowered, flags=re.I | re.S):
                warnings.append(f"consigne générique refusée : {key}")
                break

    if not re.search(r"baissi|haussi|largeur|état observé|marché", values["reading"], flags=re.I):
        warnings.append("lecture Aerith non ancrée dans le marché observé")
    if not re.search(r"prévision|exécution|décision|certitude|signal", values["caution"], flags=re.I):
        warnings.append("prudence Aerith non concrète")
    if not re.search(
        r"protocole|contrepartie|réglementation|liquidité|on-chain|couverture|historique|non évalu",
        values["limits"],
        flags=re.I,
    ):
        warnings.append("limites Aerith non reliées aux risques absents")

    return not warnings, warnings

def aerith_conclusion_news(contract: dict[str, Any]) -> list[str]:
    news = contract.get("news", {}) or {}
    lead = news.get("lead_event") or {}
    if not lead:
        return [
            f"- News Sentinel : {label_status(news.get('status'))}.",
            "- Aucun événement directeur qualifié n’est disponible : ne pas fabriquer de causalité marché.",
        ]

    event = clean_sentence(lead.get("event_label") or "événement sans libellé")
    source = clean_sentence(lead.get("source_name") or "source non précisée")
    evidence = lead.get("evidence") or {}
    impact = lead.get("impact") or {}
    if isinstance(evidence, dict):
        evidence_text = clean_sentence(evidence.get("label") or evidence.get("quality") or "non qualifiée")
        if evidence.get("score") is not None:
            evidence_text += f" · score {safe_value(evidence.get('score'))}/100"
    else:
        evidence_text = clean_sentence(evidence or "non qualifiée")
    if isinstance(impact, dict):
        impact_text = clean_sentence(impact.get("label") or "non qualifié")
        if impact.get("score") is not None:
            impact_text += f" · score {safe_value(impact.get('score'))}/100"
    else:
        impact_text = clean_sentence(impact or "non qualifié")
    assets = [str(x).strip() for x in (lead.get("assets") or []) if str(x).strip()]
    sectors = [str(x).strip() for x in (lead.get("sectors") or []) if str(x).strip()]
    scope = " · ".join((assets + sectors)[:8]) or "portée à qualifier"
    decision = clean_sentence(lead.get("decision") or "observation")
    return [
        f"- Événement directeur : {event}.",
        f"- Source : {source} · preuve {evidence_text}.",
        f"- Impact potentiel : {impact_text} · actifs/secteurs : {scope}.",
        f"- Lecture News : {decision}.",
        "- La proximité temporelle entre une news et un mouvement de prix ne démontre pas la causalité.",
    ]


def aerith_conclusion_nox(contract: dict[str, Any]) -> list[str]:
    audit = contract.get("nox_no_fomo_v1") or {}
    status = str(audit.get("status") or "PRUDENCE").strip().upper()
    fomo = clean_sentence(audit.get("fomo") or "à vérifier")
    causal = clean_sentence(audit.get("causal_inference") or "NON ÉTABLIE")
    decision = clean_sentence(audit.get("decision") or "Continuer en observation")
    flags = [clean_sentence(x) for x in (audit.get("flags") or []) if clean_sentence(x)]
    lines = [
        f"- État NØX : {status} · FOMO {fomo}.",
        f"- Causalité : {causal}.",
        f"- Refroidissement : {decision}.",
    ]
    if flags:
        lines.append("- Motifs : " + " · ".join(flags[:5]) + ".")
    lines.append("- NØX ne produit ni prix, ni ordre, ni recommandation financière.")
    return lines


def build_aerith_conclusion(contract: dict[str, Any], comment: dict[str, str]) -> str:
    sections = [
        ("1. Situation générale", aerith_conclusion_situation(contract)),
        ("2. Relecture des quatre rapports Atlas-10 CURRENT", aerith_atlas_reports_re_read_lines(contract)),
        ("3. Synthèse transversale Aerith-10", render_comment(comment, "aerith")),
        ("4. Signal dominant", aerith_conclusion_signal(contract)),
        ("5. News Sentinel — événement et preuve", aerith_conclusion_news(contract)),
        ("6. Points de vigilance", aerith_conclusion_vigilance(contract)),
        ("7. NØX No-FOMO — refroidissement", aerith_conclusion_nox(contract)),
        ("8. Contradictions importantes", deterministic_contradictions(contract)),
        ("9. Ce qu’il faut surveiller ensuite", aerith_conclusion_watch(contract)),
        ("10. Comprendre cette page — vulgarisation", [
            "- Atlas décrit les faits et calculs présents dans le snapshot ; NØX cherche les exagérations, la pression FOMO et les causalités non démontrées ; Aerith croise l’ensemble sans remplacer les données.",
            "- Prix : valeur observée à l’instant du snapshot, pas une prévision.",
            "- Volume : quantité ou valeur échangée sur une période ; une baisse de volume n’explique pas à elle seule une hausse ou une baisse de prix.",
            "- Volatilité : amplitude des mouvements observés ; elle ne donne pas la direction future.",
            "- Corrélation : deux séries peuvent évoluer ensemble sans lien de cause à effet.",
            "- VaR / Expected Shortfall : mesures statistiques historiques du risque ; elles ne constituent ni garantie ni perte maximale certaine.",
            "- News : importance potentielle et niveau de preuve doivent être séparés ; une actualité importante n’est jamais automatiquement un signal d’exécution.",
            "- INFORMATION MANQUANTE reste INFORMATION MANQUANTE : aucune valeur absente ne doit être inventée.",
        ]),
        ("11. Limites et stop point", deterministic_stop_point(contract)),
    ]
    lines: list[str] = []
    for title, body in sections:
        lines.append(f"**{title}**")
        lines.append("")
        lines.extend(body)
        lines.append("")
    return "\n".join(lines).strip()

def allowed_number_tokens(contract: dict[str, Any]) -> set[str]:
    raw = json.dumps(contract, ensure_ascii=False)
    numbers = re.findall(r"-?\d+(?:[.,]\d+)?", raw)
    allowed: set[str] = set()

    for token in numbers:
        normalized = token.replace(",", ".")
        allowed.add(token)
        allowed.add(normalized)
        try:
            value = float(normalized)
        except ValueError:
            continue
        for digits in range(0, 7):
            rendered = f"{value:.{digits}f}"
            allowed.add(rendered)
            allowed.add(rendered.replace(".", ","))

    # Numéros de sections autorisés.
    allowed.update(str(i) for i in range(1, 10))
    return allowed


def validate_model_comment(comment: dict[str, Any], contract: dict[str, Any]) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(comment, dict):
        return False, ["sortie locale non structurée"]

    required = ("reading", "caution", "limits")
    for key in required:
        value = comment.get(key)
        if not isinstance(value, str) or not value.strip():
            warnings.append(f"champ du commentaire absent : {key}")

    text = "\n".join(str(comment.get(key) or "") for key in required).strip()
    if len(text) > 3600:
        warnings.append("analyse locale trop longue")

    lowered = text.lower()
    for pattern in FORBIDDEN_MODEL_PATTERNS:
        if re.search(pattern, lowered, flags=re.I | re.S):
            warnings.append(f"formulation interdite : {pattern}")

    allowed = allowed_number_tokens(contract)
    for token in re.findall(r"-?\d+(?:[.,]\d+)?", text):
        if token not in allowed and token.replace(",", ".") not in allowed:
            warnings.append(f"nombre non autorisé : {token}")

    return not warnings, warnings


def read_runtime_profile(profile: str) -> str:
    runtime_file = RUNTIME_PROFILE_FILES.get(profile)
    if not runtime_file or not runtime_file.exists():
        raise RuntimeError("Prompt runtime local manquant.")
    return runtime_file.read_text(encoding="utf-8")


def atlas_suite_cache_key(contract: dict[str, Any]) -> str:
    payload = json.dumps(contract, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def parse_atlas_suite_comments(raw: str) -> dict[str, dict[str, str]]:
    text = str(raw or "").strip()
    if not text:
        return {}
    text = re.sub(r"^```(?:json)?\\s*", "", text, flags=re.I)
    text = re.sub(r"\\s*```$", "", text)
    candidates = [text]
    first = text.find("{")
    last = text.rfind("}")
    if first >= 0 and last > first:
        candidates.append(text[first:last + 1])
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
        except Exception:
            continue
        if isinstance(parsed, dict) and isinstance(parsed.get("comments"), dict):
            parsed = parsed["comments"]
        if not isinstance(parsed, dict):
            continue
        result: dict[str, dict[str, str]] = {}
        for mode in CONCLUSION_REPORT_MODES:
            value = parsed.get(mode)
            if isinstance(value, dict):
                normalized = normalize_model_comment(value)
                if normalized:
                    result[mode] = normalized
        if result:
            return result
    return {}


def guarded_model_request(url: str, payload: dict[str, Any], timeout: int) -> dict[str, Any]:
    """Protect low-VRAM workstations from overlapping Atlas and Aerith inference.

    Requests arriving when another model inference is busy fail closed to the
    existing deterministic fallback instead of queueing another large model.
    Market-data, health and OKX read-only requests do not use this semaphore.
    """
    if not MODEL_INFERENCE_SEMAPHORE.acquire(timeout=MODEL_INFERENCE_QUEUE_TIMEOUT_SECONDS):
        atlas_runtime_diagnostic("model_busy_refused")
        raise RuntimeError("Atlas/Aerith : inférence locale déjà occupée (protection anti-surcharge)")
    started = time.monotonic()
    atlas_runtime_diagnostic("model_inference_started")
    try:
        return request_json(url, payload, timeout)
    finally:
        atlas_runtime_diagnostic("model_inference_finished", elapsed_ms=int((time.monotonic() - started) * 1000))
        MODEL_INFERENCE_SEMAPHORE.release()


def atlas_suite_cached_result(key: str) -> dict[str, Any] | None:
    with ATLAS_SUITE_COMMENT_CACHE_LOCK:
        value = ATLAS_SUITE_COMMENT_CACHE.get(key)
        return dict(value) if isinstance(value, dict) else None


def atlas_suite_store_result(key: str, value: dict[str, Any]) -> None:
    with ATLAS_SUITE_COMMENT_CACHE_LOCK:
        ATLAS_SUITE_COMMENT_CACHE[key] = dict(value)
        while len(ATLAS_SUITE_COMMENT_CACHE) > ATLAS_SUITE_COMMENT_CACHE_MAX:
            oldest = next(iter(ATLAS_SUITE_COMMENT_CACHE))
            if oldest == key and len(ATLAS_SUITE_COMMENT_CACHE) == 1:
                break
            ATLAS_SUITE_COMMENT_CACHE.pop(oldest, None)


def call_model_atlas_suite_comments(
    config: dict[str, Any],
    provider_name: str,
    model: str,
    contract: dict[str, Any],
) -> dict[str, Any]:
    """Serve concurrent identical four-report requests from one model pass.

    The cache covers completed work; the Event below covers work in progress.
    The key includes provider/model/settings, preventing a stale model result
    from being presented as the output of another provider or model.
    """
    settings = config.get("performance", {})
    generation = config.get("generation", {})
    key_material = json.dumps({
        "contract": atlas_suite_cache_key(contract), "provider": provider_name,
        "model": model, "num_ctx": settings.get("atlas_suite_num_ctx", 8192),
        "num_predict": settings.get("atlas_suite_num_predict", 900),
        "temperature": generation.get("temperature", 0.08),
    }, sort_keys=True, separators=(",", ":"))
    key = hashlib.sha256(key_material.encode("utf-8")).hexdigest()
    with ATLAS_SUITE_INFLIGHT_LOCK:
        # Do the second cache read under the reservation lock: a prior owner
        # may have completed after the first caller entered this function.
        cached = atlas_suite_cached_result(key)
        if cached is not None:
            cached["cache_hit"] = True
            atlas_runtime_diagnostic("atlas_cache_hit", digest=key)
            return cached
        entry = ATLAS_SUITE_INFLIGHT.get(key)
        owner = entry is None
        if owner:
            entry = {"event": threading.Event(), "result": None, "error": None}
            ATLAS_SUITE_INFLIGHT[key] = entry
    assert entry is not None
    if not owner:
        atlas_runtime_diagnostic("atlas_joined_existing", digest=key)
        if not entry["event"].wait(ATLAS_SUITE_INFLIGHT_WAIT_SECONDS):
            atlas_runtime_diagnostic("atlas_join_timeout", digest=key)
            # Never fall through and launch a second inference on timeout.
            return {"used": False, "cache_hit": False, "provider_failure": True,
                    "warnings": ["Génération Atlas identique déjà en cours : attente dépassée"],
                    "comments": {}, "inflight_timeout": True}
        if entry["error"] is not None:
            return {"used": False, "cache_hit": False, "provider_failure": True,
                    "warnings": ["Échec du producteur Atlas concurrent"], "comments": {}}
        done = entry.get("result") or {}
        return {**done, "cache_hit": True, "inflight_shared": True}
    started = time.monotonic()
    atlas_runtime_diagnostic("atlas_owner_started", digest=key)
    try:
        done = _generate_atlas_suite_comments_uncached(
            config, provider_name, model, contract, key)
        entry["result"] = dict(done)
        return done
    except Exception as exc:
        entry["error"] = type(exc).__name__
        raise
    finally:
        # Wake waiters on both success and failure. The map is emptied to
        # prevent permanently stuck entries or unbounded memory growth.
        entry["event"].set()
        with ATLAS_SUITE_INFLIGHT_LOCK:
            if ATLAS_SUITE_INFLIGHT.get(key) is entry:
                ATLAS_SUITE_INFLIGHT.pop(key, None)


def _generate_atlas_suite_comments_uncached(
    config: dict[str, Any], provider_name: str, model: str,
    contract: dict[str, Any], key: str,
) -> dict[str, Any]:
    """Original one-pass four-comment producer; only its owner calls Ollama."""
    provider = config["providers"][provider_name]
    base = provider["base_url"].rstrip("/")
    timeout = int(provider.get("timeout_seconds", 120))
    generation = config.get("generation", {})
    performance = config.get("performance", {})
    temperature = float(generation.get("temperature", 0.08))
    num_ctx = max(4096, int(performance.get("atlas_suite_num_ctx", 8192)))
    num_predict = max(256, int(performance.get("atlas_suite_num_predict", 900)))
    keep_alive = performance.get("atlas_suite_keep_alive", "90s")

    facts = model_comment_facts(contract, "market", "")
    facts["mission"] = "atlas_suite_4"
    facts["planned_modes"] = list(CONCLUSION_REPORT_MODES)
    facts["output_contract"] = {
        "keys": list(CONCLUSION_REPORT_MODES),
        "fields_each": ["reading", "caution", "limits"],
        "numbers": "do_not_add_any_number_not_present_in_facts",
        "style": "three short factual French sentences per mode",
    }

    runtime_profile = read_runtime_profile("atlas")
    system = (
        runtime_profile
        + "\\n\\n"
        + model_comment_profile("atlas")
        + "\\n\\n"
        + MODEL_COMMENT_RULES
        + "\\n\\nTu produis en UNE SEULE PASSE les quatre commentaires bornés Atlas CURRENT. "
        + "Retourne uniquement un objet JSON avec les clés market, top5, math, contradictions. "
        + "Chaque clé contient reading, caution, limits. Aucun texte hors JSON."
    )
    user = (
        "Produis les quatre commentaires à partir de ce dossier contrôlé. "
        "N'invente aucun fait, nombre, causalité, portefeuille ou recommandation.\\n\\n"
        + json.dumps(facts, ensure_ascii=False, separators=(",", ":"))
    )

    try:
        if provider_name == "ollama":
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "stream": False,
                "format": "json",
                "keep_alive": keep_alive,
                "options": {
                    "temperature": temperature,
                    "num_ctx": num_ctx,
                    "num_predict": num_predict,
                },
            }
            result = guarded_model_request(f"{base}/api/chat", payload, timeout)
            raw = str(result.get("message", {}).get("content", "") or "").strip()
        else:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": temperature,
                "stream": False,
                "response_format": {"type": "json_object"},
            }
            result = guarded_model_request(f"{base}/chat/completions", payload, timeout)
            choices = result.get("choices") or []
            raw = str(choices[0].get("message", {}).get("content", "") if choices else "").strip()
    except Exception as exc:
        suite = {
            "used": False,
            "cache_hit": False,
            "provider_failure": True,
            "warnings": [f"suite Atlas locale indisponible après {timeout}s : {type(exc).__name__}"],
            "comments": {},
        }
        atlas_suite_store_result(key, suite)
        return suite

    parsed = parse_atlas_suite_comments(raw)
    comments: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []
    for mode in CONCLUSION_REPORT_MODES:
        comment = parsed.get(mode)
        valid, mode_warnings = validate_model_comment(comment or {}, contract)
        if valid and comment:
            comments[mode] = {"used": True, "comment": comment, "warnings": []}
        else:
            comments[mode] = {
                "used": False,
                "comment": deterministic_comment("atlas", mode),
                "warnings": mode_warnings or [f"commentaire suite Atlas manquant : {mode}"],
            }
            warnings.extend(comments[mode]["warnings"])

    suite = {
        "used": any(bool(value.get("used")) for value in comments.values()),
        "cache_hit": False,
        "provider_failure": False,
        "warnings": warnings,
        "comments": comments,
        "num_ctx": num_ctx,
        "model_calls_for_atlas_4_4": 1,
    }
    atlas_suite_store_result(key, suite)
    return suite


def call_model_comment(
    config: dict[str, Any],
    provider_name: str,
    model: str,
    profile: str,
    mode: str,
    question: str,
    contract: dict[str, Any],
) -> dict[str, Any]:
    provider = config["providers"][provider_name]
    base = provider["base_url"].rstrip("/")
    timeout = int(provider.get("timeout_seconds", 120))
    if mode == "conclusion":
        timeout = min(
            timeout,
            int(config.get("generation", {}).get("conclusion_comment_timeout_seconds", 300))
        )
    temperature = float(config.get("generation", {}).get("temperature", 0.08))

    facts = model_comment_facts(contract, mode, question)

    runtime_profile = read_runtime_profile(profile)
    system = (
        runtime_profile
        + "\n\n"
        + model_comment_profile(profile)
        + "\n\n"
        + MODEL_COMMENT_RULES
        + "\n\nLe dossier factuel est déjà construit par Agent-Crypto et validé par le Bridge."
        + "\nPour une conclusion Aerith, le dossier contient aussi le texte des quatre rapports Atlas CURRENT : relis-les réellement avant de synthétiser."
        + "\nLe modèle explique et met en perspective ; il ne remplace ni Data Truth, ni Math Core, ni les contradictions."
    )

    user = (
        "Commente seulement ce dossier contrôlé. Pour une conclusion, croise réellement les quatre rapports Atlas transmis avec le snapshot et NØX. "
        "Ne reconstruis aucun fait et n’ajoute aucune information.\n\n"
        + json.dumps(facts, ensure_ascii=False, separators=(",", ":"))
    )

    try:
        if provider_name == "ollama":
            performance = config.get("performance", {})
            if mode == "conclusion":
                num_ctx = max(8192, int(performance.get("conclusion_num_ctx", 16384)))
                num_predict = max(512, int(performance.get("conclusion_num_predict", 1400)))
                keep_alive = performance.get("conclusion_keep_alive", 0)
            else:
                num_ctx = max(4096, int(performance.get("comment_num_ctx", 8192)))
                num_predict = max(192, int(performance.get("comment_num_predict", 480)))
                keep_alive = performance.get("comment_keep_alive", "60s")
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "stream": False,
                "format": "json",
                "keep_alive": keep_alive,
                "options": {
                    "temperature": temperature,
                    "num_ctx": num_ctx,
                    "num_predict": num_predict,
                },
            }
            result = guarded_model_request(f"{base}/api/chat", payload, timeout)
            raw = str(result.get("message", {}).get("content", "") or "").strip()
        else:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": temperature,
                "stream": False,
                "response_format": {"type": "json_object"},
            }
            result = guarded_model_request(f"{base}/chat/completions", payload, timeout)
            choices = result.get("choices") or []
            raw = str(
                choices[0].get("message", {}).get("content", "")
                if choices else ""
            ).strip()
    except Exception as exc:
        return {
            "used": False,
            "warnings": [f"commentaire local indisponible après {timeout}s : {type(exc).__name__}"],
            "comment": None,
            "provider_failure": True,
            "provider_error": str(exc)[:220],
        }

    parsed = parse_model_comment(raw)
    if not parsed:
        return {
            "used": False,
            "warnings": ["commentaire local non structuré"],
            "comment": None,
        }

    valid, warnings = validate_model_comment(parsed, contract)
    return {
        "used": valid,
        "warnings": warnings,
        "comment": parsed if valid else None,
    }


def deterministic_comment(profile: str, mode: str) -> dict[str, str]:
    if profile == "aerith":
        return {
            "reading": (
                "Les sources convergent vers une lecture de prudence, mais elles décrivent "
                "un état présent et non une certitude sur la suite."
            ),
            "caution": (
                "Une variation ou une actualité isolée ne suffit pas à justifier une décision ; "
                "la cohérence des sources et leur fraîcheur doivent d’abord être confirmées."
            ),
            "limits": (
                "Le risque mesuré reste historique et partiel ; les dimensions de protocole, "
                "contrepartie, réglementation, exécution et données on-chain ne sont pas couvertes."
            ),
        }

    return {
        "reading": (
            "Le contrat factuel permet de comparer les sources, les horizons et "
            "les séries sans reconstruire les données."
        ),
        "caution": (
            "Toute conclusion qui dépasse les mesures présentes doit être rejetée "
            "ou classée à vérifier."
        ),
        "limits": (
            "Le rapport reste descriptif, en lecture seule, et ne couvre pas "
            "les risques absents du Math Core."
        ),
    }


def render_comment(comment: dict[str, str], profile: str) -> list[str]:
    name = "Aerith-10" if profile == "aerith" else "Atlas-10"
    return [
        f"- Lecture {name} : {comment['reading']}",
        f"- Prudence : {comment['caution']}",
        f"- Limites : {comment['limits']}",
    ]


def build_report(
    contract: dict[str, Any],
    profile: str,
    mode: str,
    comment: dict[str, str],
) -> str:
    sections: list[tuple[str, list[str]]]

    if mode == "top5":
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Target Top 5 canonique", deterministic_top5(contract)),
            ("3. Graphique lié au Top 5", deterministic_graph(contract)),
            ("4. Commentaire local borné", render_comment(comment, profile)),
            ("5. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("6. Stop point", deterministic_stop_point(contract)),
        ]
    elif mode == "math":
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Math Core — mesures réellement calculées", deterministic_math(contract)),
            ("3. Commentaire local borné", render_comment(comment, profile)),
            ("4. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("5. Stop point", deterministic_stop_point(contract)),
        ]
    elif mode == "contradictions":
        sections = [
            ("1. Verrous du contrat", [
                "- Top 5 canonique : BTC / ETH / BNB / XRP / SOL.",
                "- Aucun null transformé en zéro.",
                "- Aucune mesure Math absente inventée.",
                "- Aucune position visuelle du graphique interprétée comme tendance.",
                "- Aucune limite générale transformée en actualité.",
            ]),
            ("2. Contradictions détectées", deterministic_contradictions(contract)),
            ("3. Sources à vérifier", deterministic_sources(contract)),
            ("4. Commentaire local borné", render_comment(comment, profile)),
            ("5. Stop point", deterministic_stop_point(contract)),
        ]
    else:
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Lecture globale déterministe", deterministic_market(contract)),
            ("3. Target Top 5 canonique", deterministic_top5(contract)),
            ("4. Graphique", deterministic_graph(contract)),
            ("5. Math Core", deterministic_math(contract)),
            ("6. News Sentinel / Watchlist", deterministic_news(contract)),
            ("7. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("8. Commentaire local borné", render_comment(comment, profile)),
            ("9. Stop point", deterministic_stop_point(contract)),
        ]

    lines: list[str] = []
    for title, body in sections:
        lines.append(f"**{title}**")
        lines.append("")
        lines.extend(body)
        lines.append("")

    return "\n".join(lines).strip()



BOOK_MIRROR_SCHEMA = "agent_crypto_book_mirror_v36"
BOOK_MIRROR_REPOSITORY = "BlueAzur-Hub/erith-ia-memory"
BOOK_MIRROR_BRANCH = "main"
BOOK_MIRROR_PATH = "public/agent_crypto_erith_ia/administrator/book_mirror.json"
BOOK_MIRROR_MAX_BYTES = 2_500_000
BOOK_MIRROR_WRITE_LOCK = threading.Lock()


def github_credential() -> tuple[str, str]:
    for key in ("AGENT_CRYPTO_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"):
        value = str(os.environ.get(key) or "").strip()
        if value:
            return value, f"env:{key}"
    gh = shutil.which("gh")
    if gh:
        try:
            cp = subprocess.run([gh, "auth", "token"], capture_output=True, text=True, timeout=6, check=True)
            value = cp.stdout.strip()
            if value:
                return value, "gh-cli"
        except Exception:
            pass
    git = shutil.which("git")
    if git:
        try:
            cp = subprocess.run([git, "credential", "fill"], input="protocol=https\nhost=github.com\n\n", capture_output=True, text=True, timeout=8, check=True)
            fields = dict(line.split("=", 1) for line in cp.stdout.splitlines() if "=" in line)
            value = str(fields.get("password") or "").strip()
            if value:
                return value, "git-credential"
        except Exception:
            pass
    return "", ""


def github_json(
    method: str,
    url: str,
    token: str,
    payload: dict[str, Any] | None = None,
    timeout: int = 18,
    *,
    retries: int = 0,
    accept: str = "application/vnd.github+json",
    operation: str = "GitHub request",
) -> tuple[int, Any]:
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Accept": accept,
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "Atlas-10-Crypto-Bridge/1.9.17",
    }
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"

    attempts = max(1, int(retries) + 1)
    last_exc: BaseException | None = None
    for attempt in range(1, attempts + 1):
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=max(1, int(timeout))) as response:
                raw = response.read()
                return response.status, json.loads(raw.decode("utf-8")) if raw else {}
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            try:
                body = json.loads(raw.decode("utf-8")) if raw else {}
            except Exception:
                body = {"message": raw.decode("utf-8", errors="replace")[:500]}
            return exc.code, body
        except (TimeoutError, socket.timeout, urllib.error.URLError) as exc:
            last_exc = exc
            reason = getattr(exc, "reason", exc)
            timeout_like = isinstance(reason, (TimeoutError, socket.timeout)) or "timed out" in str(reason).lower()
            if attempt < attempts:
                time.sleep(min(2.0 * attempt, 5.0))
                continue
            code = "GITHUB_TIMEOUT" if timeout_like else "GITHUB_NETWORK_ERROR"
            raise RuntimeError(f"{code} · {operation} · après {attempts} tentative(s) · {str(reason)[:220]}") from exc
    raise RuntimeError(f"GITHUB_NETWORK_ERROR · {operation} · {str(last_exc)[:220]}")


def book_mirror_validate(payload: dict[str, Any]) -> tuple[str, str]:
    if str(payload.get("schema") or "") != BOOK_MIRROR_SCHEMA:
        raise ValueError("Schéma book_mirror refusé.")
    if payload.get("observation_only") is not True:
        raise ValueError("Le miroir doit rester observation_only.")
    execution = payload.get("execution") or {}
    if str(execution.get("producer") or "") != "ryzen" or str(execution.get("consumer") or "") != "transformer_book":
        raise ValueError("Provenance Ryzen → Transformer Book requise.")
    package = payload.get("package")
    if not isinstance(package, dict):
        raise ValueError("Paquet CURRENT absent.")
    reports = package.get("reports") or {}
    required = ("market", "top5", "math", "contradictions")
    if not all(str((reports.get(mode) or {}).get("answer") or "").strip() for mode in required):
        raise ValueError("Atlas 4/4 complet requis avant publication Book.")
    conclusion = package.get("conclusion") or {}
    if not str(conclusion.get("answer") or "").strip():
        raise ValueError("Conclusion Aerith complète requise.")
    fp = str(payload.get("fingerprint") or "").strip()
    if not fp or len(fp) > 180:
        raise ValueError("Fingerprint miroir absent ou invalide.")
    generated = str(payload.get("generated_at") or "").strip()
    return fp, generated


def book_mirror_status() -> dict[str, Any]:
    token, mode = github_credential()
    previous = None
    try: previous = load_json(BOOK_MIRROR_STATUS_PATH)
    except Exception: previous = None
    return {"ok": True, "bridge_version": "1.9.17", "enabled": True, "credential_ready": bool(token), "credential_mode": mode or None, "repository": BOOK_MIRROR_REPOSITORY, "branch": BOOK_MIRROR_BRANCH, "path": BOOK_MIRROR_PATH, "generic_github_write": False, "last_publication": previous}


def book_mirror_publish(payload: dict[str, Any]) -> dict[str, Any]:
    fp, generated = book_mirror_validate(payload)
    token, mode = github_credential()
    if not token:
        raise RuntimeError("Credential GitHub local absent : publication Book indisponible.")
    raw = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if len(raw) > BOOK_MIRROR_MAX_BYTES:
        raise ValueError("book_mirror.json trop volumineux.")
    api = f"https://api.github.com/repos/{BOOK_MIRROR_REPOSITORY}/contents/{BOOK_MIRROR_PATH}"
    with BOOK_MIRROR_WRITE_LOCK:
        status, existing = github_json("GET", api + f"?ref={BOOK_MIRROR_BRANCH}", token)
        existing_sha = str(existing.get("sha") or "") if status == 200 and isinstance(existing, dict) else ""
        if status not in {200, 404}:
            raise RuntimeError(f"GitHub lecture miroir refusée HTTP {status}.")
        current_fp = ""
        current_generated = ""
        if status == 200 and isinstance(existing, dict):
            try:
                decoded = base64.b64decode(str(existing.get("content") or "").replace("\n", ""))
                current = json.loads(decoded.decode("utf-8"))
                current_fp = str(current.get("fingerprint") or "")
                current_generated = str(current.get("generated_at") or "")
            except Exception:
                pass
        if current_fp == fp:
            result = {"ok": True, "changed": False, "fingerprint": fp, "generated_at": generated, "credential_mode": mode, "path": BOOK_MIRROR_PATH}
        else:
            # Refuse obvious rollback when both payloads expose comparable snapshot timestamps.
            new_snapshot = str((payload.get("package") or {}).get("snapshot_at") or "")
            old_snapshot = ""
            try:
                old_snapshot = str((current.get("package") or {}).get("snapshot_at") or "")
            except Exception:
                old_snapshot = ""
            if old_snapshot and new_snapshot:
                try:
                    old_dt = datetime.fromisoformat(old_snapshot.replace("Z", "+00:00"))
                    new_dt = datetime.fromisoformat(new_snapshot.replace("Z", "+00:00"))
                    if new_dt < old_dt:
                        raise ValueError("Rollback book_mirror refusé : snapshot plus ancien que le miroir publié.")
                except ValueError as exc:
                    if "Rollback book_mirror refusé" in str(exc):
                        raise
            body = {"message": f"agent-crypto: update Book mirror {fp[:18]}", "content": base64.b64encode(raw).decode("ascii"), "branch": BOOK_MIRROR_BRANCH}
            if existing_sha: body["sha"] = existing_sha
            put_status, put = github_json("PUT", api, token, body, timeout=25)
            if put_status not in {200, 201}:
                raise RuntimeError(f"GitHub publication miroir refusée HTTP {put_status}: {str((put or {}).get('message') or '')[:220]}")
            result = {"ok": True, "changed": True, "fingerprint": fp, "generated_at": generated, "credential_mode": mode, "path": BOOK_MIRROR_PATH, "content_sha": str((put.get("content") or {}).get("sha") or "")}
        BOOK_MIRROR_STATUS_PATH.parent.mkdir(parents=True, exist_ok=True)
        BOOK_MIRROR_STATUS_PATH.write_text(json.dumps({**result, "published_at": utc_now()}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        security_audit("book_mirror_publish", ok=True, detail=f"changed={result['changed']} fp={fp[:24]}")
        return result

# 40.6.485 / Bridge V1.9.14 — Oracle Evidence GitHub timeout + large-file readback resilience.
# Existing Bridge 8787 is the only trusted write owner. The browser never receives
# a GitHub credential and this owner exposes no local Evidence deletion API.
ORACLE_EVIDENCE_BUNDLE_SCHEMA = "agent_crypto_oracle_evidence_transport_bundle_v1"
ORACLE_EVIDENCE_CHUNK_SCHEMA = "agent_crypto_oracle_evidence_cold_chunk_v1"
ORACLE_EVIDENCE_MANIFEST_SCHEMA = "agent_crypto_oracle_evidence_cold_archive_manifest_v1"
ORACLE_EVIDENCE_REPOSITORY = "BlueAzur-Hub/erith-ia-memory"
ORACLE_EVIDENCE_BRANCH = "main"
ORACLE_EVIDENCE_COLD_ROOT = "public/agent_crypto_erith_ia/data/oracle_evidence"
ORACLE_EVIDENCE_MANIFEST_PATH = ORACLE_EVIDENCE_COLD_ROOT + "/manifest.json"
ORACLE_EVIDENCE_MAX_ROWS = 1000
ORACLE_EVIDENCE_DEFAULT_ROWS = 500
ORACLE_EVIDENCE_MAX_BODY_BYTES = 32 * 1024 * 1024
ORACLE_EVIDENCE_RELATIVE_PATH_RE = re.compile(r"^\d{4}/\d{2}/\d{2}/evidence-\d+-\d+-\d+\.jsonl$")
ORACLE_EVIDENCE_WRITE_LOCK = threading.Lock()
ORACLE_EVIDENCE_GITHUB_SMALL_TIMEOUT_SECONDS = 45
ORACLE_EVIDENCE_GITHUB_LARGE_TIMEOUT_SECONDS = 180
ORACLE_EVIDENCE_GITHUB_READBACK_TIMEOUT_SECONDS = 120
ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES = 1


def oracle_evidence_sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def oracle_evidence_jsonl_rows(text: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(str(text).splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"JSONL invalide ligne {number}: {exc.msg}") from exc
        if not isinstance(row, dict):
            raise ValueError(f"JSONL ligne {number}: objet attendu.")
        rows.append(row)
    return rows


def oracle_evidence_mark(t0: Any, row_id: Any) -> tuple[int, str]:
    return int(t0), str(row_id or "")


def oracle_evidence_validate_bundle(bundle: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(bundle, dict) or str(bundle.get("schema") or "") != ORACLE_EVIDENCE_BUNDLE_SCHEMA:
        raise ValueError("Schéma bundle Oracle Evidence refusé.")
    # .482 is the proven chunk producer; .483/.484 bundles remain accepted for replay/idempotence.
    if str(bundle.get("build") or "") not in {"40.6.482", "40.6.483", "40.6.484", "40.6.485"}:
        raise ValueError("Build bundle Oracle Evidence non autorisé.")
    chunk = bundle.get("chunk")
    if not isinstance(chunk, dict) or str(chunk.get("schema") or "") != ORACLE_EVIDENCE_CHUNK_SCHEMA:
        raise ValueError("Schéma chunk Oracle Evidence refusé.")
    if str(chunk.get("payload_format") or "") != "jsonl":
        raise ValueError("Oracle Evidence exige payload_format=jsonl.")
    relative_path = str(chunk.get("relative_path") or "")
    if not ORACLE_EVIDENCE_RELATIVE_PATH_RE.fullmatch(relative_path) or ".." in relative_path or relative_path.startswith("/"):
        raise ValueError("Chemin relatif Oracle Evidence refusé.")
    jsonl = bundle.get("jsonl")
    if not isinstance(jsonl, str) or not jsonl:
        raise ValueError("Payload JSONL Oracle Evidence absent.")
    rows = oracle_evidence_jsonl_rows(jsonl)
    row_count = int(chunk.get("row_count") or 0)
    if row_count < 1 or row_count > ORACLE_EVIDENCE_MAX_ROWS or len(rows) != row_count:
        raise ValueError("row_count Oracle Evidence invalide.")
    digest = oracle_evidence_sha256_text(jsonl)
    if digest != str(chunk.get("sha256") or ""):
        raise ValueError("SHA-256 Oracle Evidence invalide.")
    first, last = rows[0], rows[-1]
    if str(first.get("schema") or "") != "atlas.oracle.evidence.v1" or str(last.get("schema") or "") != "atlas.oracle.evidence.v1":
        raise ValueError("Schéma Evidence inattendu.")
    for idx, row in enumerate(rows, start=1):
        if str(row.get("schema") or "") != "atlas.oracle.evidence.v1":
            raise ValueError(f"Evidence ligne {idx}: schéma inattendu.")
        if not str(row.get("id") or "") or not int(row.get("t0") or 0):
            raise ValueError(f"Evidence ligne {idx}: id/t0 absent.")
    if int(first.get("t0") or 0) != int(chunk.get("first_t0") or 0) or str(first.get("id") or "") != str(chunk.get("first_id") or ""):
        raise ValueError("Borne initiale Oracle Evidence incohérente.")
    if int(last.get("t0") or 0) != int(chunk.get("last_t0") or 0) or str(last.get("id") or "") != str(chunk.get("last_id") or ""):
        raise ValueError("Borne finale Oracle Evidence incohérente.")
    watermark = chunk.get("watermark_after") or {}
    if oracle_evidence_mark(watermark.get("t0") or 0, watermark.get("id")) != oracle_evidence_mark(last.get("t0") or 0, last.get("id")):
        raise ValueError("Watermark Oracle Evidence incohérent.")
    if chunk.get("local_rows_deleted") is not False or chunk.get("local_retention_allowed") is not False:
        raise ValueError("Verrou de rétention locale Oracle Evidence invalide.")
    if bundle.get("browser_github_write") is not False or bundle.get("github_token_embedded") is not False or bundle.get("local_delete_authorized") is not False:
        raise ValueError("Verrou navigateur/local Oracle Evidence invalide.")
    return {
        "relative_path": relative_path,
        "row_count": row_count,
        "sha256": digest,
        "jsonl": jsonl,
        "rows": rows,
        "chunk": dict(chunk),
    }


def oracle_evidence_manifest_validate(manifest: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(manifest, dict) or str(manifest.get("schema") or "") != ORACLE_EVIDENCE_MANIFEST_SCHEMA:
        raise RuntimeError("Manifest Oracle Evidence invalide.")
    if manifest.get("local_retention_allowed") is not False or manifest.get("github_token_in_browser") is not False or manifest.get("browser_github_write") is not False:
        raise RuntimeError("Verrou sécurité du manifest Oracle Evidence invalide.")
    if not isinstance(manifest.get("chunks"), list):
        raise RuntimeError("Liste chunks Oracle Evidence invalide.")
    return manifest


def github_ref_head(repository: str, branch: str, token: str) -> str:
    status, data = github_json(
        "GET",
        f"https://api.github.com/repos/{repository}/git/ref/heads/{quote(branch, safe='')}",
        token,
        timeout=ORACLE_EVIDENCE_GITHUB_SMALL_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation="Oracle Evidence · lire ref",
    )
    if status != 200 or not isinstance(data, dict):
        raise RuntimeError(f"GitHub ref Oracle Evidence refusée HTTP {status}.")
    return str((data.get("object") or {}).get("sha") or "")


def github_commit_tree_sha(repository: str, commit_sha: str, token: str) -> str:
    status, data = github_json(
        "GET",
        f"https://api.github.com/repos/{repository}/git/commits/{commit_sha}",
        token,
        timeout=ORACLE_EVIDENCE_GITHUB_SMALL_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation="Oracle Evidence · lire commit",
    )
    if status != 200 or not isinstance(data, dict):
        raise RuntimeError(f"GitHub commit Oracle Evidence refusé HTTP {status}.")
    return str((data.get("tree") or {}).get("sha") or "")


def github_get_blob_text(repository: str, blob_sha: str, token: str) -> str:
    status, data = github_json(
        "GET",
        f"https://api.github.com/repos/{repository}/git/blobs/{quote(blob_sha, safe='')}",
        token,
        timeout=ORACLE_EVIDENCE_GITHUB_READBACK_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation="Oracle Evidence · relire blob",
    )
    if status != 200 or not isinstance(data, dict):
        raise RuntimeError(f"GitHub blob Oracle Evidence illisible HTTP {status}.")
    if str(data.get("encoding") or "") != "base64":
        raise RuntimeError("Encodage blob GitHub Oracle Evidence inattendu.")
    try:
        return base64.b64decode(str(data.get("content") or "").replace("\n", "")).decode("utf-8")
    except Exception as exc:
        raise RuntimeError("Décodage blob GitHub Oracle Evidence impossible.") from exc


def github_read_text(repository: str, path: str, ref: str, token: str) -> str:
    # GitHub Contents only embeds file content directly up to 1 MiB.
    # For larger Oracle Evidence chunks, request object metadata to obtain the
    # blob SHA, then read the Git blob endpoint (supported up to 100 MiB).
    api = f"https://api.github.com/repos/{repository}/contents/{quote(path, safe='/')}?ref={quote(ref, safe='')}"
    status, data = github_json(
        "GET",
        api,
        token,
        timeout=ORACLE_EVIDENCE_GITHUB_READBACK_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        accept="application/vnd.github.object+json",
        operation="Oracle Evidence · lire contenu",
    )
    if status != 200 or not isinstance(data, dict):
        raise RuntimeError(f"GitHub lecture Oracle Evidence refusée HTTP {status}.")
    encoding = str(data.get("encoding") or "")
    content = str(data.get("content") or "")
    if encoding == "base64" and content:
        try:
            return base64.b64decode(content.replace("\n", "")).decode("utf-8")
        except Exception as exc:
            raise RuntimeError("Décodage GitHub Oracle Evidence impossible.") from exc
    blob_sha = str(data.get("sha") or "").strip()
    if blob_sha:
        return github_get_blob_text(repository, blob_sha, token)
    raise RuntimeError("Métadonnées GitHub Oracle Evidence sans contenu ni blob SHA.")


def github_create_blob(repository: str, content: str, token: str) -> str:
    status, data = github_json(
        "POST",
        f"https://api.github.com/repos/{repository}/git/blobs",
        token,
        {"content": content, "encoding": "utf-8"},
        timeout=ORACLE_EVIDENCE_GITHUB_LARGE_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation=f"Oracle Evidence · créer blob {len(content.encode('utf-8'))} octets",
    )
    if status != 201 or not isinstance(data, dict):
        raise RuntimeError(f"GitHub blob Oracle Evidence refusé HTTP {status}.")
    return str(data.get("sha") or "")


def github_commit_files_atomic(repository: str, branch: str, parent_sha: str, files: dict[str, str], message: str, token: str) -> str:
    current = github_ref_head(repository, branch, token)
    if not current or current != parent_sha:
        raise RuntimeError("GitHub main a bougé : ingestion Oracle Evidence arrêtée fail-closed.")
    base_tree = github_commit_tree_sha(repository, parent_sha, token)
    entries = []
    for path, content in files.items():
        entries.append({"path": path, "mode": "100644", "type": "blob", "sha": github_create_blob(repository, content, token)})
    status, tree = github_json(
        "POST",
        f"https://api.github.com/repos/{repository}/git/trees",
        token,
        {"base_tree": base_tree, "tree": entries},
        timeout=ORACLE_EVIDENCE_GITHUB_SMALL_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation="Oracle Evidence · créer tree",
    )
    if status != 201 or not isinstance(tree, dict):
        raise RuntimeError(f"GitHub tree Oracle Evidence refusé HTTP {status}.")
    status, commit = github_json(
        "POST",
        f"https://api.github.com/repos/{repository}/git/commits",
        token,
        {"message": message, "tree": str(tree.get("sha") or ""), "parents": [parent_sha]},
        timeout=ORACLE_EVIDENCE_GITHUB_SMALL_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation="Oracle Evidence · créer commit",
    )
    if status != 201 or not isinstance(commit, dict):
        raise RuntimeError(f"GitHub commit Oracle Evidence refusé HTTP {status}.")
    commit_sha = str(commit.get("sha") or "")
    status, result = github_json(
        "PATCH",
        f"https://api.github.com/repos/{repository}/git/refs/heads/{quote(branch, safe='')}",
        token,
        {"sha": commit_sha, "force": False},
        timeout=ORACLE_EVIDENCE_GITHUB_SMALL_TIMEOUT_SECONDS,
        retries=ORACLE_EVIDENCE_GITHUB_TIMEOUT_RETRIES,
        operation="Oracle Evidence · mettre à jour ref",
    )
    if status != 200:
        raise RuntimeError(f"GitHub ref update Oracle Evidence refusée HTTP {status}: {str((result or {}).get('message') or '')[:180]}")
    return commit_sha


def oracle_evidence_pending_manifest(manifest: dict[str, Any], validated: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    out = json.loads(json.dumps(oracle_evidence_manifest_validate(manifest)))
    rel = validated["relative_path"]
    existing = next((row for row in out["chunks"] if str(row.get("relative_path") or "") == rel), None)
    if existing:
        if str(existing.get("sha256") or "") != validated["sha256"] or int(existing.get("row_count") or 0) != validated["row_count"]:
            raise ValueError("Collision de chunk Oracle Evidence.")
        return out, False
    current = out.get("watermark")
    first_mark = oracle_evidence_mark(validated["chunk"].get("first_t0") or 0, validated["chunk"].get("first_id"))
    if current and first_mark <= oracle_evidence_mark(current.get("t0") or 0, current.get("id")):
        raise ValueError("Lot Oracle Evidence antérieur ou égal au watermark froid courant.")
    entry = dict(validated["chunk"])
    entry.update({
        "status": "WRITTEN_PENDING_VERIFY",
        "written_at": utc_now(),
        "verified_at": None,
        "write_commit": None,
        "verification": {"read_back": False, "sha256": False, "row_count": False, "json_parse": False, "manifest_commit": False},
    })
    out["build"] = "40.6.485"
    out["chunks"].append(entry)
    out["local_retention_allowed"] = False
    out["local_delete_requires_verified_cold_copy"] = True
    out["github_token_in_browser"] = False
    out["browser_github_write"] = False
    out["transport"] = {
        "status": "EXISTING_BRIDGE_8787",
        "owner": "Atlas-10 Crypto Bridge V1.9.17",
        "endpoint": "http://127.0.0.1:8787/oracle-evidence/ingest",
        "operator_triggered": True,
        "automatic_upload": False,
    }
    return out, True


def oracle_evidence_verified_manifest(manifest: dict[str, Any], validated: dict[str, Any], write_commit: str) -> dict[str, Any]:
    out = json.loads(json.dumps(oracle_evidence_manifest_validate(manifest)))
    rel = validated["relative_path"]
    entry = next((row for row in out["chunks"] if str(row.get("relative_path") or "") == rel), None)
    if not entry:
        raise RuntimeError("Chunk Oracle Evidence absent après écriture.")
    if str(entry.get("sha256") or "") != validated["sha256"] or int(entry.get("row_count") or 0) != validated["row_count"]:
        raise RuntimeError("Manifest/chunk Oracle Evidence divergent.")
    entry["status"] = "VERIFIED"
    entry["verified_at"] = utc_now()
    entry["write_commit"] = write_commit
    entry["verification"] = {"read_back": True, "sha256": True, "row_count": True, "json_parse": True, "manifest_commit": True}
    verified = [row for row in out["chunks"] if str(row.get("status") or "").upper() == "VERIFIED"]
    out["archived_rows"] = sum(int(row.get("row_count") or 0) for row in verified)
    out["watermark"] = dict(entry.get("watermark_after") or {})
    out["build"] = "40.6.485"
    out["local_retention_allowed"] = False
    out["local_delete_requires_verified_cold_copy"] = True
    out["github_token_in_browser"] = False
    out["browser_github_write"] = False
    out["transport"] = {
        "status": "EXISTING_BRIDGE_8787",
        "owner": "Atlas-10 Crypto Bridge V1.9.17",
        "endpoint": "http://127.0.0.1:8787/oracle-evidence/ingest",
        "operator_triggered": True,
        "automatic_upload": False,
    }
    out["verification"] = {
        "required": ["read_back", "sha256", "row_count", "json_parse", "manifest_commit"],
        "verified_chunks": len(verified),
        "last_verified_at": entry["verified_at"],
    }
    return out


def oracle_evidence_verify_readback(text: str, validated: dict[str, Any]) -> dict[str, Any]:
    rows = oracle_evidence_jsonl_rows(text)
    digest = oracle_evidence_sha256_text(text)
    if digest != validated["sha256"] or len(rows) != validated["row_count"]:
        raise RuntimeError("Relecture froide Oracle Evidence divergente.")
    return {"sha256": digest, "row_count": len(rows), "json_parse": True}


def oracle_evidence_status() -> dict[str, Any]:
    token, mode = github_credential()
    payload: dict[str, Any] = {
        "ok": True,
        "bridge_version": "1.9.17",
        "enabled": True,
        "owner": "Atlas-10 Crypto Bridge V1.9.17",
        "endpoint": "http://127.0.0.1:8787/oracle-evidence/ingest",
        "repository": ORACLE_EVIDENCE_REPOSITORY,
        "branch": ORACLE_EVIDENCE_BRANCH,
        "cold_root": ORACLE_EVIDENCE_COLD_ROOT,
        "manifest_path": ORACLE_EVIDENCE_MANIFEST_PATH,
        "credential_ready": bool(token),
        "credential_mode": mode or None,
        "browser_github_write": False,
        "github_token_in_browser": False,
        "automatic_upload": False,
        "local_delete_api": False,
        "local_retention_allowed": False,
        "default_chunk_rows": ORACLE_EVIDENCE_DEFAULT_ROWS,
        "max_chunk_rows": ORACLE_EVIDENCE_MAX_ROWS,
    }
    if token:
        try:
            head = github_ref_head(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_BRANCH, token)
            manifest = oracle_evidence_manifest_validate(json.loads(github_read_text(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_MANIFEST_PATH, head, token)))
            payload.update({
                "github_head": head,
                "archived_rows": int(manifest.get("archived_rows") or 0),
                "chunks": len(manifest.get("chunks") or []),
                "verified_chunks": len([x for x in manifest.get("chunks") or [] if str(x.get("status") or "").upper() == "VERIFIED"]),
                "watermark": manifest.get("watermark"),
            })
        except Exception as exc:
            payload["archive_status_error"] = str(exc)[:240]
    return payload


def oracle_evidence_ingest(bundle: dict[str, Any]) -> dict[str, Any]:
    validated = oracle_evidence_validate_bundle(bundle)
    token, mode = github_credential()
    if not token:
        raise RuntimeError("Credential GitHub local absent : archivage Oracle Evidence indisponible.")
    with ORACLE_EVIDENCE_WRITE_LOCK:
        head = github_ref_head(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_BRANCH, token)
        manifest = oracle_evidence_manifest_validate(json.loads(github_read_text(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_MANIFEST_PATH, head, token)))
        existing = next((row for row in manifest["chunks"] if str(row.get("relative_path") or "") == validated["relative_path"]), None)
        if existing and str(existing.get("status") or "").upper() == "VERIFIED":
            if str(existing.get("sha256") or "") != validated["sha256"] or int(existing.get("row_count") or 0) != validated["row_count"]:
                raise ValueError("Chunk Oracle Evidence VERIFIED existant mais divergent.")
            readback = github_read_text(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_COLD_ROOT + "/" + validated["relative_path"], head, token)
            proof = oracle_evidence_verify_readback(readback, validated)
            result = {
                "ok": True, "status": "VERIFIED", "idempotent": True,
                "bridge_version": "1.9.17", "relative_path": validated["relative_path"],
                "sha256": proof["sha256"], "row_count": proof["row_count"],
                "write_commit": str(existing.get("write_commit") or ""), "verify_commit": head,
                "credential_mode": mode, "local_rows_deleted": False, "local_retention_allowed": False,
            }
            security_audit("oracle_evidence_ingest", ok=True, detail=f"idempotent rows={proof['row_count']} sha={proof['sha256'][:18]}")
            return result

        pending, is_new = oracle_evidence_pending_manifest(manifest, validated)
        if is_new:
            write_commit = github_commit_files_atomic(
                ORACLE_EVIDENCE_REPOSITORY,
                ORACLE_EVIDENCE_BRANCH,
                head,
                {
                    ORACLE_EVIDENCE_COLD_ROOT + "/" + validated["relative_path"]: validated["jsonl"],
                    ORACLE_EVIDENCE_MANIFEST_PATH: json.dumps(pending, ensure_ascii=False, indent=2) + "\n",
                },
                "feat(agent-crypto): ingest Oracle Evidence cold chunk via Bridge 1.9.17",
                token,
            )
        else:
            write_commit = head

        # Independent readback from the exact committed GitHub state.
        readback = github_read_text(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_COLD_ROOT + "/" + validated["relative_path"], write_commit, token)
        proof = oracle_evidence_verify_readback(readback, validated)
        written_manifest = oracle_evidence_manifest_validate(json.loads(github_read_text(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_MANIFEST_PATH, write_commit, token)))
        verified_manifest = oracle_evidence_verified_manifest(written_manifest, validated, write_commit)
        verify_commit = github_commit_files_atomic(
            ORACLE_EVIDENCE_REPOSITORY,
            ORACLE_EVIDENCE_BRANCH,
            write_commit,
            {ORACLE_EVIDENCE_MANIFEST_PATH: json.dumps(verified_manifest, ensure_ascii=False, indent=2) + "\n"},
            "chore(agent-crypto): mark Oracle Evidence cold chunk VERIFIED",
            token,
        )
        final_manifest = oracle_evidence_manifest_validate(json.loads(github_read_text(ORACLE_EVIDENCE_REPOSITORY, ORACLE_EVIDENCE_MANIFEST_PATH, verify_commit, token)))
        final_entry = next((row for row in final_manifest["chunks"] if str(row.get("relative_path") or "") == validated["relative_path"]), None)
        if not final_entry or str(final_entry.get("status") or "").upper() != "VERIFIED":
            raise RuntimeError("Manifest Oracle Evidence final non VERIFIED.")
        result = {
            "ok": True, "status": "VERIFIED", "idempotent": False,
            "bridge_version": "1.9.17", "relative_path": validated["relative_path"],
            "sha256": proof["sha256"], "row_count": proof["row_count"],
            "write_commit": write_commit, "verify_commit": verify_commit,
            "credential_mode": mode, "local_rows_deleted": False, "local_retention_allowed": False,
        }
        security_audit("oracle_evidence_ingest", ok=True, detail=f"rows={proof['row_count']} sha={proof['sha256'][:18]} verify={verify_commit[:12]}")
        return result

class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "AtlasCryptoBridge/1.9.17"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {self.address_string()} {fmt % args}")

    @property
    def config(self) -> dict[str, Any]:
        return self.server.config  # type: ignore[attr-defined]

    def allowed_origin(self) -> str:
        origin = self.headers.get("Origin", "")
        allowed = self.config.get("allowed_origins", [])
        if not origin:
            return ""
        if origin in allowed:
            return origin
        return ""

    def send_json(self, status: int, payload: dict[str, Any]) -> bool:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            origin = self.allowed_origin()
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
            self.end_headers()
            self.wfile.write(data)
            return True
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError):
            # Firefox peut annuler une ancienne requête lorsque le graphique
            # change. La réponse n'est plus utile ; le Bridge reste sain.
            return False

    def bearer_token(self) -> str:
        value = str(self.headers.get("Authorization") or "").strip()
        if not value.lower().startswith("bearer "):
            return ""
        return value.split(" ", 1)[1].strip()

    def require_authenticated(self, route: str) -> dict[str, Any] | None:
        token = self.bearer_token()
        session = auth_session_get(token)
        if not session:
            security_audit("auth_required", ok=False, detail=route, remote=self.client_address[0])
            self.send_json(401, {"ok": False, "error": "Authentification Administrator Bridge requise.", "auth_required": True})
            return None
        capability = ROUTE_CAPABILITY.get(route)
        if capability and capability not in CAPABILITY_POLICY.get(str(session.get("role") or ""), frozenset()):
            security_audit("capability_refused", ok=False, detail=f"{route}:{capability}", remote=self.client_address[0])
            self.send_json(403, {"ok": False, "error": "Capacité Bridge refusée.", "required_capability": capability})
            return None
        return session

    def do_OPTIONS(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return
        self.send_json(204, {})

    def do_GET(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return

        parsed_url = urlparse(self.path)
        route = parsed_url.path

        if route == "/auth/status":
            token = self.bearer_token()
            session = auth_session_get(token)
            self.send_json(200, {
                "ok": True,
                "configured": auth_state_read() is not None,
                "authenticated": session is not None,
                "role": session.get("role") if session else None,
                "session_ttl_seconds": 0, "owner_session_persistent": True, "owner_session_policy": AUTH_OWNER_SESSION_POLICY,
                "bridge_version": "1.9.17",
            })
            return

        privileged_session = None
        if route in AUTH_PRIVILEGED_GET:
            privileged_session = self.require_authenticated(route)
            if privileged_session is None:
                return

        if route == "/capabilities":
            role = str(privileged_session.get("role") or "reader")
            self.send_json(200, {"ok": True, "bridge_version": "1.9.17", "role": role, "capabilities": capabilities_for_role(role), "refusal_default": True})
            return

        if route == "/security/status":
            self.send_json(200, {"ok": True, "bridge_version": "1.9.17", "auth_configured": auth_state_read() is not None, "sessions_memory_only": True, "audit_log": str(SECURITY_AUDIT_PATH.relative_to(ROOT)), "generic_github_write": False, "book_mirror_publication": True, "exchange_actions": False, "wallet_actions": False, "okx_private_read": okx_private_status_payload()})
            return

        if route == "/book-mirror/status":
            self.send_json(200, book_mirror_status())
            return

        if route == "/oracle-evidence/status":
            try:
                self.send_json(200, oracle_evidence_status())
            except Exception as exc:
                security_audit("oracle_evidence_status", ok=False, detail=str(exc), remote=self.client_address[0])
                self.send_json(503, {"ok": False, "error": str(exc)})
            return

        if route == "/okx/status":
            self.send_json(200, okx_private_status_payload())
            return

        if route == "/okx/account":
            try:
                self.send_json(200, okx_account_payload())
            except Exception as exc:
                security_audit("okx_account_read", ok=False, detail=str(exc)[:220], remote=self.client_address[0])
                self.send_json(503, {"ok": False, "error": str(exc), "read_only": True, "bridge_version": "1.9.17"})
            return

        if route == "/okx/orders":
            try:
                self.send_json(200, okx_orders_payload())
            except Exception as exc:
                security_audit("okx_orders_read", ok=False, detail=str(exc)[:220], remote=self.client_address[0])
                self.send_json(503, {"ok": False, "error": str(exc), "read_only": True, "bridge_version": "1.9.17"})
            return

        if route == "/okx/fills":
            try:
                self.send_json(200, okx_fills_payload())
            except Exception as exc:
                security_audit("okx_fills_read", ok=False, detail=str(exc)[:220], remote=self.client_address[0])
                self.send_json(503, {"ok": False, "error": str(exc), "read_only": True, "bridge_version": "1.9.17"})
            return

        if route == "/okx/ledger":
            try:
                params = parse_qs(parsed_url.query)
                unknown = set(params) - {"ccy", "pages"}
                if unknown:
                    raise ValueError("Paramètre de journal OKX non autorisé.")
                ccy = (params.get("ccy") or ["BTC"])[0]
                pages_value = (params.get("pages") or ["1"])[0]
                ccy, pages = okx_ledger_params(ccy, pages_value)
                self.send_json(200, okx_ledger_payload(ccy, pages))
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc), "read_only": True})
            except Exception:
                security_audit("okx_ledger_read", ok=False, detail="Flux comptable indisponible", remote=self.client_address[0])
                self.send_json(503, {"ok": False, "error": "Lecture comptable momentanément indisponible", "read_only": True})
            return

        if route == "/okx/fees":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                inst_id = str((query.get("instId") or ["BTC-USDC"])[0]).strip().upper()
                self.send_json(200, okx_fees_payload(inst_id))
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc), "read_only": True})
            except Exception as exc:
                security_audit("okx_fees_read", ok=False, detail=str(exc)[:220], remote=self.client_address[0])
                self.send_json(503, {"ok": False, "error": str(exc), "read_only": True, "bridge_version": "1.9.17"})
            return

        if route == "/health":
            providers = {
                name: provider_status(self.config, name)
                for name in ("ollama", "lm_studio")
            }
            active = None
            model = None
            readiness_error = ""
            try:
                # V1.9.6 — reuse the provider inventory above. /health must be a
                # cheap readiness read, not two consecutive Ollama /api/tags probes.
                active, model = choose_provider(self.config, providers)
            except Exception as exc:
                readiness_error = str(exc)

            required_model = str(
                self.config.get("providers", {})
                .get("ollama", {})
                .get("model") or "gpt-oss:20b-32k"
            )
            model_ready = bool(active and model)

            self.send_json(200, {
                "ok": True,
                "ready": model_ready,
                "model_ready": model_ready,
                "required_model": required_model,
                "readiness_error": readiness_error,
                "service": "Atlas-10 Crypto Bridge Ryzen",
                "version": "1.9.17",
                "quality": "strict_contract_v2_v3_truth_evidence",
                "comment_prompt_policy": "sanitized_comment_v1",
                "forbidden_control_terms_sent_to_model": False,
                "time": utc_now(),
                "read_only": True,
                "auth": {"required_for_privileged_routes": True, "configured": auth_state_read() is not None, "session_ttl_seconds": 0, "owner_session_persistent": True, "owner_session_policy": AUTH_OWNER_SESSION_POLICY},
                "book_mirror": {"enabled": True, "owner": "Bridge 1.9.17", "path": BOOK_MIRROR_PATH, "generic_github_write": False},
                "oracle_evidence": {"enabled": True, "owner": "Bridge 1.9.17", "route": "/oracle-evidence/ingest", "authenticated": True, "generic_github_write": False, "local_delete_api": False},
                "history_proxy_read_only": True,
                "history_route": "/history",
                "scanner_collector_route": "/scanner-snapshot",
                "scanner_status_route": "/scanner-status",
                "scanner_latest_route": "/scanner-latest",
                "scanner_history_route": "/scanner-history",
                "aerith_conclusion_route": "/conclusion",
                "local_observation_storage": True,
                "inference_policy": {
                    "atlas_4_4_model_calls": 1 if self.config.get("performance", {}).get("atlas_suite_single_model_pass", True) else 4,
                    "aerith_conclusion_model_calls": 1,
                    "atlas_num_ctx": int(self.config.get("performance", {}).get("atlas_suite_num_ctx", 8192)),
                    "conclusion_num_ctx": int(self.config.get("performance", {}).get("conclusion_num_ctx", 16384)),
                    "unload_after_conclusion": self.config.get("performance", {}).get("conclusion_keep_alive", 0) == 0,
                },
                "provider": active,
                "model": model,
                "providers": providers,
                "profiles": profile_health(),
                "actions": {
                    "exchange": False,
                    "wallet": False,
                    "github": False,
                    "github_publication": False,
                    "ui": False,
                },
            })
            return

        if route == "/profiles":
            self.send_json(200, {
                "ok": True,
                "quality": "strict_contract_v2_v3_truth_evidence",
                "profiles": profile_health(),
            })
            return

        if route == "/history":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                coin_id = str((query.get("coin_id") or [""])[0]).strip().lower()
                symbol = str((query.get("symbol") or [""])[0]).strip().upper()
                days_raw = str((query.get("days") or ["1"])[0]).strip()
                if not re.fullmatch(r"[a-z0-9-]{1,80}", coin_id):
                    raise ValueError("coin_id invalide.")
                if not re.fullmatch(r"[A-Z0-9]{2,15}", symbol):
                    raise ValueError("symbol invalide.")
                try:
                    days = int(days_raw)
                except ValueError as exc:
                    raise ValueError("days invalide.") from exc
                if days not in HISTORY_PERIODS:
                    raise ValueError("Période autorisée : 1, 7, 30, 60, 90, 365 ou 36500 jours.")
                allow_binance_raw = str((query.get("allow_binance") or ["1"])[0]).strip().lower()
                allow_binance = allow_binance_raw not in {"0", "false", "no"}
                payload = fetch_history_singleflight(
                    self.config, coin_id, symbol, days, allow_binance
                )
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc), "read_only": True})
            except Exception as exc:
                self.send_json(503, {
                    "ok": False,
                    "error": str(exc),
                    "attempts": list(getattr(exc, "attempts", [])),
                    "read_only": True,
                    "bridge_version": "1.9.17",
                })
            else:
                self.send_json(200, payload)
            return

        if route == "/scanner-latest":
            latest = scanner_read_latest()
            self.send_json(200, {
                "ok": True,
                "bridge_version": "1.9.17",
                "schema": SCANNER_SCHEMA,
                "available": latest is not None,
                "snapshot": latest,
                "read_only_external": True,
                "local_observation_storage": True,
            })
            return

        if route == "/scanner-status":
            self.send_json(200, scanner_status(self.config))
            return

        if route == "/scanner-history":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                basket = str((query.get("basket") or ["top5"])[0]).strip().lower()
                limit_raw = str((query.get("limit") or ["120"])[0]).strip()
                limit = int(limit_raw)
                rows = scanner_history(self.config, basket, limit)
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": "1.9.17",
                    "schema": SCANNER_SCHEMA,
                    "basket": basket,
                    "count": len(rows),
                    "rows": rows,
                    "read_only_external": True,
                })
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc)})
            except Exception as exc:
                self.send_json(503, {"ok": False, "error": str(exc)})
            return

        self.send_json(404, {"ok": False, "error": "Route inconnue."})

    def read_body(self, max_bytes: int | None = None) -> dict[str, Any]:
        raw_length = self.headers.get("Content-Length", "0")
        length = int(raw_length)
        max_snapshot = int(
            self.config.get("generation", {})
            .get("max_snapshot_chars", 250000)
        )
        limit = int(max_bytes) if max_bytes is not None else max_snapshot + 20000
        if length <= 0 or length > limit:
            raise ValueError("Corps vide ou trop volumineux.")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def do_POST(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return

        route = urlparse(self.path).path
        if route in {"/auth/register", "/auth/login", "/auth/logout"}:
            if not self.headers.get("Origin") or not self.allowed_origin():
                self.send_json(403, {"ok": False, "error": "Origin Administrator exacte requise."})
                return
            try:
                body = self.read_body(max_bytes=16_384)
                if route == "/auth/logout":
                    token = self.bearer_token()
                    if not auth_session_get(token):
                        self.send_json(401, {"ok": False, "error": "Session Bridge absente."})
                        return
                    auth_session_revoke(token)
                    security_audit("logout", ok=True, remote=self.client_address[0])
                    self.send_json(200, {"ok": True, "logged_out": True, "bridge_version": "1.9.17"})
                    return
                remote = self.client_address[0]
                if not auth_failure_allowed(remote):
                    security_audit("login_rate_limit", ok=False, remote=remote)
                    self.send_json(429, {"ok": False, "error": "Trop de tentatives. Réessaie plus tard."})
                    return
                secret = str(body.get("secret") or "")
                if route == "/auth/register":
                    auth_register(secret)
                elif not auth_verify(secret):
                    auth_failure_record(remote)
                    security_audit("login", ok=False, detail="secret refused", remote=remote)
                    self.send_json(401, {"ok": False, "error": "Mot de passe Administrator Bridge incorrect."})
                    return
                session = auth_session_create("owner")
                security_audit("register" if route == "/auth/register" else "login", ok=True, remote=remote)
                self.send_json(200, {"ok": True, "bridge_version": "1.9.17", **session})
                return
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc)})
                return
            except Exception as exc:
                self.send_json(503, {"ok": False, "error": str(exc)})
                return

        if route not in AUTH_PRIVILEGED_POST:
            self.send_json(404, {"ok": False, "error": "Route inconnue."})
            return
        if self.require_authenticated(route) is None:
            return

        try:
            if route == "/oracle-evidence/ingest":
                body = self.read_body(max_bytes=ORACLE_EVIDENCE_MAX_BODY_BYTES)
            elif route == "/book-mirror/publish":
                body = self.read_body(max_bytes=BOOK_MIRROR_MAX_BYTES + 16_384)
            else:
                body = self.read_body()

            if route == "/oracle-evidence/ingest":
                try:
                    self.send_json(200, oracle_evidence_ingest(body))
                except ValueError as exc:
                    security_audit("oracle_evidence_ingest", ok=False, detail=str(exc), remote=self.client_address[0])
                    self.send_json(400, {"ok": False, "error": str(exc)})
                except Exception as exc:
                    security_audit("oracle_evidence_ingest", ok=False, detail=str(exc), remote=self.client_address[0])
                    self.send_json(503, {"ok": False, "error": str(exc)})
                return

            if route == "/book-mirror/publish":
                try:
                    self.send_json(200, book_mirror_publish(body))
                except ValueError as exc:
                    security_audit("book_mirror_publish", ok=False, detail=str(exc), remote=self.client_address[0])
                    self.send_json(400, {"ok": False, "error": str(exc)})
                except Exception as exc:
                    security_audit("book_mirror_publish", ok=False, detail=str(exc), remote=self.client_address[0])
                    self.send_json(503, {"ok": False, "error": str(exc)})
                return

            if route == "/scanner-snapshot":
                snapshot = scanner_validate_snapshot(body)
                snapshot = scanner_enrich_snapshot(snapshot, self.config)
                stored = scanner_persist_snapshot(snapshot, self.config)
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": "1.9.17",
                    "schema": SCANNER_SCHEMA,
                    "snapshot_id": snapshot.get("snapshot_id"),
                    "collected_at": snapshot.get("collected_at"),
                    "duplicate": stored.get("duplicate", False),
                    "storage_path": stored.get("path"),
                    "binance_enrichment": snapshot.get("binance_enrichment"),
                    "snapshot": snapshot,
                    "read_only_external": True,
                    "local_observation_storage": True,
                })
                return

            profile = str(body.get("profile") or "atlas").strip().lower()
            if profile not in RUNTIME_PROFILE_FILES:
                raise ValueError("Profil autorisé : atlas ou aerith.")

            snapshot = body.get("snapshot")
            if not isinstance(snapshot, dict):
                raise ValueError("Le snapshot Agent-Crypto doit être un objet JSON.")

            contract = validate_contract(snapshot)
            provider_name, model = choose_provider(self.config)

            if route == "/conclusion":
                if profile != "aerith":
                    raise ValueError("La conclusion finale utilise uniquement le profil Aerith-10.")
                report_modes = body.get("report_modes") or []
                if report_modes != list(CONCLUSION_REPORT_MODES):
                    raise ValueError("Les quatre rapports Atlas-10 validés sont requis dans l’ordre canonique.")
                report_fingerprint = str(body.get("report_fingerprint") or "").strip()
                contract["atlas_reports_v1"] = normalize_conclusion_reports(body.get("reports"), report_fingerprint)
                pedagogy_body = body.get("pedagogy_contract")
                if isinstance(pedagogy_body, dict):
                    contract["pedagogy_v1"] = pedagogy_body
                nox_body = body.get("nox_audit")
                if nox_body is not None:
                    if not isinstance(nox_body, dict):
                        raise ValueError("L'audit NØX doit être un objet JSON.")
                    if str(nox_body.get("schema") or "") != "agent_crypto_nox_no_fomo_v1":
                        raise ValueError("Schéma NØX No-FOMO refusé.")
                    if str(nox_body.get("status") or "").upper() not in {"CALME", "PRUDENCE", "STOP"}:
                        raise ValueError("Statut NØX invalide.")
                    contract["nox_no_fomo_v1"] = nox_body
                model_result = call_model_comment(
                    self.config,
                    provider_name,
                    model,
                    "aerith",
                    "conclusion",
                    "Produire une conclusion prudente après les quatre rapports Atlas-10 validés. Relire tout le snapshot : marché, Top 5, graphique, Math Core, News Sentinel, contradictions, preuves et NØX. Expliquer en français simple les termes crypto, banque, trading et statistiques utilisés. Pour chaque indicateur important : dire ce qu’il mesure, ce que la valeur signifie ici et ce qu’elle ne permet pas de conclure. Ne jamais transformer une actualité en causalité ou signal d’exécution sans preuve. Une donnée absente reste INFORMATION MANQUANTE.",
                    contract,
                )
                if model_result["used"]:
                    candidate = model_result["comment"]
                    concrete_ok, concrete_warnings = validate_aerith_concrete_comment(candidate, contract)
                    if concrete_ok:
                        comment = candidate
                        model_comment_used = True
                        warnings: list[str] = []
                    else:
                        comment = aerith_concrete_limits_comment(contract)
                        model_comment_used = False
                        warnings = list(model_result.get("warnings") or []) + concrete_warnings
                else:
                    comment = aerith_concrete_limits_comment(contract)
                    model_comment_used = False
                    warnings = model_result["warnings"]
                answer = build_aerith_conclusion(contract, comment)
                self.send_json(200, {
                    "ok": True,
                    "profile": "aerith",
                    "provider": provider_name,
                    "model": model,
                    "time": utc_now(),
                    "quality": "strict_contract_v2_v3_truth_evidence",
                    "model_comment_used": model_comment_used,
                    "deterministic_fallback_used": not model_comment_used,
                    "validation_warnings": warnings,
                    "answer": answer,
                    "source_reports": 4,
                    "reports_re_read": True,
                    "report_modes_re_read": list(CONCLUSION_REPORT_MODES),
                    "news_context_used": True,
                    "nox_no_fomo_used": bool(contract.get("nox_no_fomo_v1")),
                    "report_fingerprint": report_fingerprint,
                    "read_only": True,
                })
                return

            if route == "/summary":
                mode = str(body.get("mode") or "market").strip().lower()
                if mode not in {"market", "top5", "math", "contradictions"}:
                    raise ValueError(
                        "Mode autorisé : market, top5, math ou contradictions."
                    )
                question = MODE_LABELS[mode]
            else:
                mode = "chat"
                question = str(body.get("question") or "").strip()
                max_question = int(
                    self.config.get("generation", {})
                    .get("max_question_chars", 4000)
                )
                if not question or len(question) > max_question:
                    raise ValueError("Question vide ou trop longue.")

            suite_meta: dict[str, Any] | None = None
            if (
                route == "/summary"
                and profile == "atlas"
                and bool(self.config.get("performance", {}).get("atlas_suite_single_model_pass", True))
            ):
                suite_meta = call_model_atlas_suite_comments(
                    self.config, provider_name, model, contract
                )
                suite_row = (suite_meta.get("comments") or {}).get(mode) or {}
                comment = suite_row.get("comment") or deterministic_comment(profile, mode)
                model_comment_used = bool(suite_row.get("used"))
                warnings = list(suite_row.get("warnings") or suite_meta.get("warnings") or [])
            else:
                model_result = call_model_comment(
                    self.config,
                    provider_name,
                    model,
                    profile,
                    mode,
                    question,
                    contract,
                )

                if model_result["used"]:
                    comment = model_result["comment"]
                    model_comment_used = True
                    warnings = []
                else:
                    comment = deterministic_comment(profile, mode)
                    model_comment_used = False
                    warnings = model_result["warnings"]

            report_mode = "market" if mode == "chat" else mode
            answer = build_report(
                contract,
                profile,
                report_mode,
                comment,
            )

            self.send_json(200, {
                "ok": True,
                "profile": profile,
                "provider": provider_name,
                "model": model,
                "time": utc_now(),
                "quality": "strict_contract_v2_v3_truth_evidence",
                "model_comment_used": model_comment_used,
                "atlas_suite_single_model_pass": bool(suite_meta is not None),
                "atlas_suite_cache_hit": bool(suite_meta.get("cache_hit")) if suite_meta else False,
                "atlas_model_calls_for_4_4": int(suite_meta.get("model_calls_for_atlas_4_4", 1)) if suite_meta else None,
                "validation_warnings": warnings,
                "answer": answer,
                "read_only": True,
            })

        except ValueError as exc:
            self.send_json(400, {"ok": False, "error": str(exc)})
        except Exception as exc:
            self.send_json(503, {"ok": False, "error": str(exc)})


class BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        handler: type[BaseHTTPRequestHandler],
        config: dict[str, Any],
    ) -> None:
        super().__init__(address, handler)
        self.config = config


def self_test() -> int:
    config = load_config()
    profiles = profile_health()

    assert config["host"] in {"127.0.0.1", "localhost"}
    assert all(item["loaded"] for item in profiles.values()), profiles
    allowed_schemas = config.get("strict_contract", {}).get("accepted_schemas") or []
    assert "atlas_crypto_fact_contract_v2" in allowed_schemas
    assert "atlas_crypto_fact_contract_v3_truth_evidence" in allowed_schemas

    sample = {
        "strict_contract": {
            "schema": "atlas_crypto_fact_contract_v2",
            "rules": {
                "market_list_is_not_portfolio": True,
                "no_missing_value_to_zero": True,
                "no_visual_position_inference": True,
                "no_unlisted_math_measure": True,
                "no_news_from_generic_limit": True,
                "no_financial_instruction": True,
            },
            "canonical_top5": {
                "symbols": ["BTC", "ETH", "BNB", "XRP", "SOL"],
                "complete": False,
                "assets": [],
            },
        }
    }
    validate_contract(sample)
    sample_v3 = json.loads(json.dumps(sample))
    sample_v3["strict_contract"]["schema"] = "atlas_crypto_fact_contract_v3_truth_evidence"
    sample_v3["strict_contract"]["rules"].update({
        "analytical_fingerprint_v2": True,
        "source_truth_v2": True,
        "evidence_independence_required": True,
        "metric_quality_gates": True,
        "transactional_conclusion": True,
    })
    sample_v3["strict_contract"]["source_truth_v2"] = {"schema": "source_truth_v2", "counts": {"DIRECT": 1}}
    sample_v3["strict_contract"]["evidence_v2"] = {"schema": "evidence_v2", "events": [], "counts": {}}
    sample_v3["strict_contract"]["math_quality_gates_v2"] = {"schema": "math_quality_gates_v2", "gates": [], "counts": {}}
    sample_v3["strict_contract"]["contradictions_v2"] = {"schema": "contradictions_v2", "items": [], "counts": {"total": 0}}
    sample_v3["analytical_state"] = {"schema": "analytical_state_v2", "fingerprint": {"algorithm": "SHA-256", "value": "self-test"}}
    validate_contract(sample_v3)
    sample_contract = sample["strict_contract"]
    sample_contract.update({
        "sources": {
            "binance": {"feed_status": "ready", "source": "Binance WebSocket", "direct_pairs": 5, "derived_pairs": 0},
            "coingecko": {"status": "ready", "mode": "direct", "timestamp": utc_now()},
        },
        "market": {"assets_loaded": 250, "target_assets": 250, "breadth_24h": {"positive": 40, "negative": 200, "stable": 10, "classification": "largeur négative", "basis": "Variations 24 h"}},
        "graph": {"truth_label": "Historique en cache retardé", "freshness": "delayed"},
        "math": {"risk_global": "Partiel", "limitation": "mesures historiques seulement"},
        "news": {"status": "ready"},
        "watchlist": {"configured_count": 34},
        "contradictions": [{"level": "à vérifier", "text": "Historique non direct"}],
        "stop_point": {"meaning": "Arrêter lorsque les données ne soutiennent plus une conclusion."},
    })
    sample_contract["canonical_top5"]["complete"] = True
    sample_contract["canonical_top5"]["assets"] = [
        {"available": True, "symbol": symbol, "change_24h_pct": change}
        for symbol, change in zip(["BTC", "ETH", "BNB", "XRP", "SOL"], [-1.0, -2.0, 0.5, -3.0, -2.5])
    ]
    concrete_comment = aerith_concrete_limits_comment(sample_contract)
    conclusion = build_aerith_conclusion(sample_contract, concrete_comment)
    assert "Situation générale" in conclusion and "Limites et stop point" in conclusion
    assert "pas son évolution future" in conclusion
    assert "signal d’exécution" in conclusion

    generic_comment = {
        "reading": "Analyser l’état du marché et des sources.",
        "caution": "Évaluer la qualité des données et la fiabilité des informations.",
        "limits": "Utiliser uniquement les informations fournies, sans ajout ou modification.",
    }
    generic_valid, generic_warnings = validate_aerith_concrete_comment(generic_comment, sample_contract)
    assert generic_valid is False and generic_warnings

    bad_comment = {
        "reading": "Votre portefeuille suit un ratio de Sharpe de 2.",
        "caution": "Acheter demain.",
        "limits": "Stop point dans 30 jours.",
    }
    valid, warnings = validate_model_comment(
        bad_comment,
        sample["strict_contract"],
    )
    assert valid is False and warnings

    print("Configuration : OK")
    print("Profils Atlas/Aerith : OK")
    print("Contrats factuels V2 + V3 Truth/Evidence : OK")
    print("Filtre anti-invention : OK")
    assert set(HISTORY_PERIODS) == {1, 7, 30, 60, 90, 365, 36500}
    assert config.get("history_proxy", {}).get("enabled", True) is True
    print("Proxy historique local : OK")

    # Aether Trust owner session must not expire on a wall-clock TTL.
    trust_session = auth_session_create("owner")
    trust_token = str(trust_session.get("token") or "")
    assert trust_token
    assert trust_session.get("persistent") is True
    assert trust_session.get("expires_at") is None
    assert trust_session.get("session_policy") == AUTH_OWNER_SESSION_POLICY
    stored_trust = auth_session_get(trust_token)
    assert stored_trust is not None and stored_trust.get("persistent") is True
    auth_session_revoke(trust_token)
    assert auth_session_get(trust_token) is None
    print("Aether Trust owner persistant jusqu'au logout / arrêt Bridge : OK")

    owner_caps = set(capabilities_for_role("owner"))
    assert {"okx.account.read", "okx.orders.read", "okx.fills.read", "okx.fees.read"}.issubset(owner_caps)
    assert not {"okx.account.read", "okx.orders.read", "okx.fills.read", "okx.fees.read", "okx.ledger.read"}.intersection(capabilities_for_role("operator"))
    assert ROUTE_CAPABILITY["/okx/account"] == "okx.account.read"
    assert ROUTE_CAPABILITY["/okx/orders"] == "okx.orders.read"
    assert ROUTE_CAPABILITY["/okx/fills"] == "okx.fills.read"
    assert ROUTE_CAPABILITY["/okx/fees"] == "okx.fees.read"
    assert ROUTE_CAPABILITY["/okx/ledger"] == "okx.ledger.read"
    assert okx_ledger_params("btc", "3") == ("BTC", 3)
    sample_path = okx_build_request_path("/api/v5/account/balance", [("ccy", "BTC,USDC")])
    assert sample_path == "/api/v5/account/balance?ccy=BTC%2CUSDC"
    assert okx_build_request_path("/api/v5/asset/bills-history", [("ccy", "BTC")]) == "/api/v5/asset/bills-history?ccy=BTC"
    assert okx_build_request_path("/api/v5/account/bills-archive", [("ccy", "BTC")]) == "/api/v5/account/bills-archive?ccy=BTC"
    sample_signature = okx_sign("secret", "2020-12-08T09:08:57.715Z", "GET", sample_path)
    assert sample_signature == "xHiSfkXSh+ILrpFJB4iHuzzETtzlJHqc6ZqoPsySCV0="
    try:
        okx_build_request_path("/api/v5/trade/order", [])
        raise AssertionError("Une route d'écriture OKX ne doit jamais passer la liste blanche READ.")
    except ValueError:
        pass
    print("OKX Private READ · capacités + signature + liste blanche : OK")

    sample_scanner = {
        "schema": SCANNER_SCHEMA,
        "snapshot_id": "self-test_2026-07-28-15-30",
        "collector_id": "self-test",
        "collected_at": utc_now(),
        "market": {"source": "CoinGecko", "mode": "direct", "status": "ready", "assets_loaded": 237, "target_assets": 250, "quote_currency": "EUR"},
        "exchange_feed": {"source": "Binance WebSocket", "status": "ready", "direct_pairs": 5, "derived_pairs": 0},
        "baskets": {
            key: {
                "id": key,
                "label": key,
                "ranking_source": "CoinGecko Market Snapshot",
                "ranking_metric": "change_24h_pct" if key != "volume" else "volume_24h_eur",
                "assets": [{
                    "coin_id": "bitcoin",
                    "symbol": "BTC",
                    "name": "Bitcoin",
                    "market_rank": 1,
                    "scanner_rank": 1,
                    "classification_value": 1.0,
                    "market_price_eur": 50000,
                    "observed_price_eur": 50000,
                    "observed_source": "Binance BTCEUR WebSocket",
                    "observed_status": "live",
                    "binance_symbol_candidate": "BTC",
                    "binance_candidate_allowed": True,
                }],
            }
            for key in SCANNER_BASKETS
        },
    }
    sample_fp = "self-test-current-fingerprint"
    sample_reports = {
        mode: {
            "label": MODE_LABELS[mode],
            "answer": (f"Rapport {mode} CURRENT. " * 20).strip(),
            "fingerprint": sample_fp,
            "model": "gpt-oss:20b-32k",
            "time": utc_now(),
        }
        for mode in CONCLUSION_REPORT_MODES
    }
    normalized_reports = normalize_conclusion_reports(sample_reports, sample_fp)
    assert len(normalized_reports) == 4
    assert all(row["fingerprint"] == sample_fp for row in normalized_reports.values())

    validated_scanner = scanner_validate_snapshot(sample_scanner)
    assert validated_scanner["schema"] == SCANNER_SCHEMA
    assert all(validated_scanner["baskets"][key]["assets"] for key in SCANNER_BASKETS)
    print("Scanner Live Collector : OK")
    print("Conclusion Aerith-10 Crypto : OK")
    print("Relecture réelle des 4 rapports Atlas CURRENT : OK")
    print("Mode observation locale · écriture externe générique interdite · miroir Book borné : OK")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--configure-okx-read", action="store_true")
    parser.add_argument("--clear-okx-read", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return self_test()

    config = load_config()
    if args.configure_okx_read:
        return okx_configure_interactive(config)
    if args.clear_okx_read:
        return okx_clear_credentials()

    host = config.get("host", "127.0.0.1")
    port = int(config.get("port", 8787))
    PID_PATH.write_text(str(os.getpid()), encoding="ascii")

    server = BridgeServer((host, port), BridgeHandler, config)

    def shutdown_handler(signum: int, frame: Any) -> None:
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown_handler)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, shutdown_handler)

    print("=" * 70)
    print("ATLAS-10 CRYPTO BRIDGE RYZEN V1.9.17")
    print(f"Adresse : http://{host}:{port}")
    print("Modèle : Ollama gpt-oss:20b-32k")
    print("Qualité : contrats V2/V3 Truth-Evidence · Atlas/Aerith · lecture seule")
    print("Mode : observation locale · GitHub générique interdit · Book + Oracle Evidence bornés")
    print("=" * 70)

    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        server.server_close()
        try:
            PID_PATH.unlink(missing_ok=True)
        except Exception:
            pass
        print("Bridge arrêté.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
