@echo off
setlocal
cd /d "%~dp0"
title Agent-Crypto · Configuration OKX PRIVATE READ
echo.
echo ================================================================
echo   OKX PRIVATE READ · Aether Trust · Bridge 8787
echo ================================================================
echo   Utilise une cle API OKX avec permission READ uniquement.
echo   Aucun Trade. Aucun Withdraw. Secrets proteges par Windows DPAPI.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 bridge.py --configure-okx-read
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python bridge.py --configure-okx-read
  goto :end
)
echo Python 3 est introuvable sur ce PC.
echo Ouvre le dossier technique depuis Aether Control puis installe/active Python 3.
:end
echo.
pause
endlocal
