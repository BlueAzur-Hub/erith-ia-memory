@echo off
setlocal
cd /d "%~dp0"
title Agent-Crypto · Suppression OKX PRIVATE READ
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 bridge.py --clear-okx-read
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python bridge.py --clear-okx-read
  goto :end
)
echo Python 3 est introuvable sur ce PC.
:end
echo.
pause
endlocal
