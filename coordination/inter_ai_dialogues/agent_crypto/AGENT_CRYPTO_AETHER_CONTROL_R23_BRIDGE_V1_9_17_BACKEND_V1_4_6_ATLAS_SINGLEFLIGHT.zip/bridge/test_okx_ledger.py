"""Tests hors réseau des journaux privés OKX. Aucune clé ni compte requis."""
import importlib.util
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("okx_bridge_under_test", Path(__file__).with_name("bridge.py"))
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


def run():
    assert bridge.okx_ledger_params("btc", "2") == ("BTC", 2)
    for ccy, pages in (("BTC,EUR", "1"), ("BTC", "0"), ("BTC", "4"), ("X;BAD", "1")):
        try:
            bridge.okx_ledger_params(ccy, pages)
            raise AssertionError("Une validation d'entrée a ete contournee")
        except ValueError:
            pass
    for path in ("/api/v5/asset/transfer", "/api/v5/trade/order", "/api/v5/asset/withdrawal"):
        try:
            bridge.okx_build_request_path(path)
            raise AssertionError("Route de transaction indument autorisee")
        except ValueError:
            pass

    calls = []
    def fake_get(path, params):
        calls.append((path, list(params)))
        if path == "/api/v5/account/bills-archive":
            return {"data": [{"billId": "111", "ccy": "BTC", "balChg": "0.001", "ts": "1"}]}
        return {"data": [{"billId": "222", "ccy": "BTC", "balChg": "0.001", "ts": "2"}]}
    with patch.object(bridge, "okx_private_get", side_effect=fake_get), patch.object(bridge.time, "sleep"):
        result = bridge.okx_ledger_payload("BTC", 1)
    assert result["ok"] and result["read_only"] and not result["acquisition_cost_proven"]
    assert not result["eur_paypal_purchase_proven"] and not result["origin_of_funds_proven"]
    assert len(calls) == 2
    assert all(("ccy", "BTC") in params for _, params in calls)
    assert result["sources"]["trading_account"]["records_count"] == 1
    assert result["sources"]["funding_account"]["records_count"] == 1

    count = 0
    def fake_paging(path, params):
        nonlocal count
        count += 1
        if count == 1:
            return {"data": [{"billId": str(i + 101)} for i in range(100)]}
        assert ("after", "200") in params
        return {"data": [{"billId": "100"}]}
    with patch.object(bridge, "okx_private_get", side_effect=fake_paging), patch.object(bridge.time, "sleep"):
        page_result = bridge.okx_ledger_stream("/api/v5/asset/bills-history", "BTC", 2)
    assert page_result["records_count"] == 101 and page_result["pages_read"] == 2
    assert not page_result["has_more"] and page_result["state"] == "ok"

    def fail_get(path, params):
        raise RuntimeError("Personal financial secret: should not appear in client output")
    with patch.object(bridge, "okx_private_get", side_effect=fail_get), patch.object(bridge.time, "sleep"):
        failed = bridge.okx_ledger_payload("BTC", 1)
    assert not failed["all_sources_available"]
    assert "secret" not in str(failed).lower()
    assert all(v["state"] == "unavailable" for v in failed["sources"].values())
    assert not any("okx.ledger.read" in bridge.capabilities_for_role(role) for role in ("operator", "reader"))
    assert "okx.ledger.read" in bridge.capabilities_for_role("owner")
    assert "/okx/ledger" in bridge.AUTH_PRIVILEGED_GET
    print("OK: 19 controles mock / pagination / securite / absence de calcul non prouve")


if __name__ == "__main__":
    run()
