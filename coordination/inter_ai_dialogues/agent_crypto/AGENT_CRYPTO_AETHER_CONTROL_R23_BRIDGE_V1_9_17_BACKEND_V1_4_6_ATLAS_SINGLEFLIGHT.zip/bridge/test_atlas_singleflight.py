"""Pure offline concurrent-regression tests. Never call Ollama, OKX or the network."""
import importlib.util
import threading
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("bridge_under_test_singleflight", Path(__file__).with_name("bridge.py"))
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)

CONFIG = {"providers": {"ollama": {"base_url": "http://127.0.0.1:11434", "timeout_seconds": 3}},
          "performance": {"atlas_suite_num_ctx": 8192, "atlas_suite_num_predict": 900},
          "generation": {"temperature": 0.08}}


class AtlasSingleflight(unittest.TestCase):
    def setUp(self):
        bridge.ATLAS_SUITE_COMMENT_CACHE.clear()
        bridge.ATLAS_SUITE_INFLIGHT.clear()

    def test_many_tabs_share_one_inference(self):
        entered = threading.Event()
        release = threading.Event()
        calls = []
        def fake_generate(config, provider, model, contract, key):
            calls.append(key)
            entered.set()
            self.assertTrue(release.wait(4), "Owner should be released")
            result = {"used": True, "cache_hit": False, "comments": {"market": {"used": True}}}
            bridge.atlas_suite_store_result(key, result)
            return result
        with patch.object(bridge, "_generate_atlas_suite_comments_uncached", side_effect=fake_generate):
            with ThreadPoolExecutor(max_workers=12) as executor:
                first = executor.submit(bridge.call_model_atlas_suite_comments, CONFIG, "ollama", "model-A", {"x": 1})
                self.assertTrue(entered.wait(2))
                others = [executor.submit(bridge.call_model_atlas_suite_comments, CONFIG, "ollama", "model-A", {"x": 1}) for _ in range(10)]
                time.sleep(.1)
                release.set()
                results = [first.result(timeout=3)] + [x.result(timeout=3) for x in others]
        self.assertEqual(len(calls), 1)
        self.assertEqual(len(results), 11)
        self.assertTrue(all(r["used"] for r in results))
        self.assertTrue(any(r["cache_hit"] for r in results[1:]))
        self.assertEqual(bridge.ATLAS_SUITE_INFLIGHT, {})

    def test_failure_unblocks_waiters_and_allows_new_owner(self):
        entered = threading.Event()
        release = threading.Event()
        def fail(*args):
            entered.set()
            release.wait(2)
            raise RuntimeError("example")
        with patch.object(bridge, "_generate_atlas_suite_comments_uncached", side_effect=fail):
            with ThreadPoolExecutor(max_workers=2) as executor:
                first = executor.submit(bridge.call_model_atlas_suite_comments, CONFIG, "ollama", "model-B", {"x": 2})
                self.assertTrue(entered.wait(2))
                second = executor.submit(bridge.call_model_atlas_suite_comments, CONFIG, "ollama", "model-B", {"x": 2})
                time.sleep(.04)
                release.set()
                with self.assertRaises(RuntimeError): first.result(timeout=2)
                result = second.result(timeout=2)
                self.assertTrue(result["provider_failure"])
        self.assertEqual(bridge.ATLAS_SUITE_INFLIGHT, {})

    def test_provider_and_settings_separate_cache_entries(self):
        n = []
        def fake_generate(config, provider, model, contract, key):
            n.append(key)
            return {"used": True, "cache_hit": False, "comments": {}}
        with patch.object(bridge, "_generate_atlas_suite_comments_uncached", side_effect=fake_generate):
            for model in ("model-A", "model-B"):
                bridge.call_model_atlas_suite_comments(CONFIG, "ollama", model, {"x": 1})
            config2 = {**CONFIG, "performance": {**CONFIG["performance"], "atlas_suite_num_ctx": 4096}}
            bridge.call_model_atlas_suite_comments(config2, "ollama", "model-A", {"x": 1})
        self.assertEqual(len(set(n)), 3)

    def test_other_expensive_model_cannot_overlap(self):
        entered = threading.Event()
        release = threading.Event()
        def fake_request(*args):
            entered.set()
            self.assertTrue(release.wait(2))
            return {"message": {"content": "{}"}}
        with patch.object(bridge, "request_json", side_effect=fake_request), \
             patch.object(bridge, "MODEL_INFERENCE_QUEUE_TIMEOUT_SECONDS", .05):
            with ThreadPoolExecutor(max_workers=2) as executor:
                first = executor.submit(bridge.guarded_model_request,"ollama",{},3)
                self.assertTrue(entered.wait(1))
                second = executor.submit(bridge.guarded_model_request,"ollama",{},3)
                with self.assertRaisesRegex(RuntimeError,"déjà occupée"):
                    second.result(timeout=1)
                release.set()
                self.assertEqual(first.result(timeout=1)["message"]["content"],"{}")
        # Semaphore must be released even if the model raises.
        with patch.object(bridge, "request_json", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                bridge.guarded_model_request("ollama",{},3)
        with patch.object(bridge, "request_json", return_value={"ok":True}):
            self.assertTrue(bridge.guarded_model_request("ollama",{},3)["ok"])

    def test_wait_timeout_does_not_start_second_generation(self):
        entry = {"event": threading.Event(), "result": None, "error": None}
        original = bridge.atlas_suite_cached_result
        # Reserve as if another thread is already computing a specific contract.
        k = bridge.hashlib.sha256(bridge.json.dumps({"contract": bridge.atlas_suite_cache_key({"x":3}),
            "provider":"ollama","model":"M","num_ctx":8192,"num_predict":900,
            "temperature":0.08},sort_keys=True,separators=(",",":")).encode()).hexdigest()
        bridge.ATLAS_SUITE_INFLIGHT[k] = entry
        with patch.object(bridge, "ATLAS_SUITE_INFLIGHT_WAIT_SECONDS", .03), \
             patch.object(bridge, "_generate_atlas_suite_comments_uncached") as generator:
            result=bridge.call_model_atlas_suite_comments(CONFIG,"ollama","M",{"x":3})
        self.assertTrue(result["inflight_timeout"])
        generator.assert_not_called()
        del bridge.ATLAS_SUITE_INFLIGHT[k]

if __name__ == '__main__':
    unittest.main(verbosity=2)
