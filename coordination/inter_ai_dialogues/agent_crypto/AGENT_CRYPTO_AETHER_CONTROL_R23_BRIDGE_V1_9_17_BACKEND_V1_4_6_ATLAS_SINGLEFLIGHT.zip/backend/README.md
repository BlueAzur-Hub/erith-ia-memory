PRIVATE BACKEND 1.4.6 · MARKET INSTRUMENT RESOLVER · VALIDATED R2

Read-only local market backend on 127.0.0.1:8790.
Validated terrain baseline with Trader / Administrator 40.6.621:
- M -> Bitget -> M-USDT : candles + fresh book PASS
- XAUT -> OKX -> XAUT-USDT : candles + fresh book PASS
- OKB -> OKX -> OKB-USDC : candles + fresh book PASS

No API key. No wallet. No order route. No write method.
This R20 package keeps Backend 1.4.6 and Bridge 1.9.13 unchanged at protocol level.
