# Seven Heaven · Trader — R3 T0 / lecture G1 (8 octobre 2026)

## Destination
Établir une observation T0 manuelle et horodatée, dans le dossier Paper déjà présent. G1 « QUALITÉ DES DONNÉES » reste sous la seule autorité canonique de Strategy A.

## Sources déjà existantes
- Actif, devise et graphe natif depuis `AgentCryptoTraderPaperPreparation.snapshot()`.
- OHLCV de Bougies via `AgentCryptoMarketMicroscope.snapshot()`, cohérence de paire, ouverture, OHLC, volume, horodatages croissants, lacunes, statut non confirmé.
- Carnet OKX via `AgentCryptoOkxMicrostructure.snapshot()`, paire, source et fraîcheur au moment T0.
- G1 exact via `AgentCryptoStrategyAGateCanonicalTruth.snapshot()` et complétude des jeux de données via `AgentCryptoStrategyAEvidenceDossier.snapshot()` si accessibles.
- Contrôles explicites contre les confusions EUR, USD, USDC et USDT. Observation du graphique toujours NON LIVE.

## Règles de vérité et de sécurité
- Le bouton « Capturer T0 (sans stockage) » effectue une lecture volontaire. Rien n'est enregistré en localStorage, IndexedDB ou sur réseau.
- La capture est immutable et réinitialisée au changement d'actif ou de devise.
- La qualité T0 du marché ne vaut PAS certification du jeu de données Strategy A : aucun PASS G1, ordre Paper, ordre réel, nouveau propriétaire graphique, nouveau collecteur, timer ou modification du Bridge.
- Build stable 40.6.624 ; Market Core 38.15.11 et Archive R9 préservés.

## Contrôles précommit
10 tests ciblés PASS : compilation JS, immutabilité, OHLCV correcte, bougies anciennes, cotation divergente, OHLCV malformée, actif incohérent, G1 inchangé, intégrité after-cost non inventée et aucune autorisation de transaction.

## Livrables et acceptation
Fichiers : `trader-paper-t0.js` (nouveau) et `trader-runtime-mirror.js` (injection seulement). GitHub Actions + GitHub Pages à contrôler après livraison. Test Firefox opérateur requis : ouvrir Dossier Paper, cliquer Capturer T0, comparer faits/limites et G1. Ne pas annoncer certification terrain anticipée.
