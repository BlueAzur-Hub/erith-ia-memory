AGENT-CRYPTO 40.6.317 — AETHER 16:9 OUTER GEOMETRY

Functional commit: 91bda0225aa9a7e427ecf015061c7c1ad73c6f3c

Purpose:
- repair the failed 40.6.316 black-side-band normal Aether state
- make the Window Manager the aspect-ratio authority for Aether outer geometry

Changes:
- Aether geometryPolicy now owns aspectRatio 1672/941, anchored on height
- native pointer-up persistence records normalized current geometry
- persisted non-16:9 Aether geometry is repaired before manager.init
- 40.6.316 transient F11 geometry separation is retained

Protected / unchanged:
- CSS: unchanged
- Aether artwork and inner stage: unchanged
- Market Core 38.15.11: unchanged
- Oracle / Storage schema / Strategy / Lecture Technique: unchanged

Firefox terrain gate:
1. Ctrl+F5.
2. Normal Aether must have no black side bands.
3. Outer frame must be 1672/941 and stay compact.
4. Open/close F12: no jump into F11 geometry.
5. Press F11: large historical field.
6. Exit F11: exact compact 16:9 normal rectangle.
