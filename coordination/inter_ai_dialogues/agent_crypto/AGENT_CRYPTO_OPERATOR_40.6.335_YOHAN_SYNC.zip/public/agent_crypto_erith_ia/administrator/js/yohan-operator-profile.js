(() => {
  "use strict";

  const PROFILE = Object.freeze({
    id: "yohan-operator",
    deliveryBuild: "40.6.335",
    runtime: "canonical-master-shared",
    sameAdministratorInterface: true,
    hideProjects: false,
    forceReducedView: false,
    grantsAdministratorSession: false,
    bridgeAuthenticationOwner: "future-remote-authority",
    publicSecretEmbedded: false,
    helpLayerV2Available: true
  });

  function apply() {
    document.documentElement.dataset.yohanProfile = "operator";
    document.documentElement.dataset.yohanOperatorDelivery = "40.6.335";
    document.documentElement.dataset.yohanSharedAdministratorRuntime = "true";
    if (document.body) {
      document.body.dataset.yohanProfile = "operator";
      document.body.dataset.yohanOperatorDelivery = "40.6.335";
    }
    try {
      document.dispatchEvent(new CustomEvent("erith:yohan-operator-profile-ready", {
        detail: { build: "40.6.335", shared_runtime: true, ui_reduction: false, authorization_granted: false, help_layer_v2: true }
      }));
    } catch (_) {}
    return true;
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", apply, { once: true });
  else apply();

  globalThis.ErithYohanOperatorProfile = Object.freeze({
    profile: PROFILE,
    apply,
    contract: Object.freeze({
      dom_hiding: false,
      view_forcing: false,
      storage_write: false,
      recurring_timer: false,
      observer: false,
      administrator_grant: false,
      real_trading_grant: false,
      wallet_grant: false
    })
  });
})();
