# ERITH.IA Operator Client — préversion d'authentification Windows

* Bridge 1.9.13 / Backend 1.4.4, Interface + Trader 40.6.640.
* L'EXE GUI et le dossier source complet sont inclus dans le ZIP.
* Le Control Center et le Bridge possèdent une configuration locale Operator indépendante ; aucun accès Owner.
* Python 3 est nécessaire aux services. Ollama est facultatif et n'est pas fourni.
* Les ports 8787 et 8790 doivent être libres. Ne pas installer à la place du Bridge Administrator R22.
* Aucune clé OKX, aucun compte personnel, aucun ordre réel et aucun bot ne sont inclus/activés.
* Cette préversion nécessite encore une recette réelle dans Windows et Firefox avant une utilisation quotidienne.
* Le ZIP historique R19Y1 a été vérifié par son empreinte SHA-256 puis transformé pour ce build.
* Sources modifiables sous bridge/, backend/ et source/. Le module source/payload.zip doit être reconstruit avant chaque compilation.
* Le poste du titulaire produit un dossier de confiance neuf. Ne jamais recopier les fichiers DPAPI/trust d'un autre ordinateur.
