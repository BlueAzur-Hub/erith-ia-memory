# Installation — Build 28.1.94 + Bridge V1.7.5

## 1. Interface GitHub

Dans `public/agent_crypto_erith_ia/web/`, remplacer uniquement :

- `app.js`
- `index.html`
- `style.css`

Commit :

`add automatic book publication build 28.1.94 bridge 1.7.5`

## 2. Bridge Ryzen

1. Fermer le Bridge V1.7.4.
2. Extraire le dossier `bridge/` dans un nouveau dossier local.
3. Lancer une seule fois `CONFIGURE_GITHUB_PUBLICATION.bat`.
4. Coller un jeton GitHub finement limité au dépôt, permission `Contents: Read and write`.
5. Lancer `START_BRIDGE.bat`.

## 3. Test réel

1. Sur le Ryzen, laisser Atlas produire les quatre rapports puis Aerith la conclusion.
2. La fenêtre `Publication Book` apparaît.
3. Cliquer `Publier sur le Book`.
4. Attendre `Publication confirmée`.
5. Sur le Book, ouvrir ou actualiser l’Interface.
6. Vérifier 4/4 rapports, conclusion disponible, puis F5.

Le JSON manuel reste disponible comme secours, mais il n’est plus nécessaire dans le flux normal.
