# Atlas-10 Crypto Bridge Ryzen V1.7.5 — Publication automatique Book

Cette version conserve toutes les fonctions V1.7.4 et ajoute une seule écriture externe bornée : la publication de la synthèse Atlas/Aerith destinée au Book.

## Flux

`4 rapports Atlas -> conclusion Aerith -> fenêtre Publication Book -> un clic -> Bridge -> GitHub Data -> Book -> IndexedDB`

Le Ryzen ne télécharge plus de JSON à gérer. Le Book n’importe plus de fichier. Il ouvre seulement l’Interface.

## Chemin GitHub verrouillé

Le Bridge peut modifier uniquement :

`public/agent_crypto_erith_ia/data/latest_atlas_aerith_synthesis.json`

Il ne peut modifier aucun autre fichier, aucun workflow et aucune branche autre que `main` du dépôt `BlueAzur-Hub/erith-ia-memory`.

## Configuration unique du Ryzen

1. Créer un jeton GitHub finement limité au seul dépôt `BlueAzur-Hub/erith-ia-memory`.
2. Autorisation minimale : **Contents — Read and write**.
3. Lancer `CONFIGURE_GITHUB_PUBLICATION.bat`.
4. Coller le jeton lorsque la fenêtre le demande.
5. Lancer ensuite `START_BRIDGE.bat` normalement.

Le jeton est conservé dans le profil Windows local, jamais dans l’Interface publique, jamais dans le ZIP et jamais dans GitHub Pages.

## Utilisation courante

Après les quatre rapports et la conclusion, la fenêtre **Publication Book** apparaît. Cliquer sur **Publier sur le Book**.

Le Bridge publie le fichier canonique. Le Book récupère automatiquement la publication depuis GitHub Pages et la conserve dans IndexedDB.

## Sécurité

- écoute uniquement sur `127.0.0.1:8787` ;
- origine autorisée : `https://blueazur-hub.github.io` ;
- aucune clé exchange ;
- aucun wallet ;
- aucun ordre financier ;
- aucune écriture GitHub générale ;
- publication limitée à un fichier JSON validé ;
- schéma, quatre rapports, conclusion et empreinte obligatoires ;
- import JSON manuel conservé comme secours ;
- mémoire IndexedDB 28.1.92 conservée.

## Routes nouvelles

- `POST /publish-synthesis` — validation et publication bornée ;
- `GET /health` — expose uniquement l’état configuré/non configuré, jamais le jeton.

## Compatibilité

- Interface : Agent-Crypto V2.0-alpha · Build 28.1.94 ;
- Bridge : V1.7.5 ;
- moteur : Ollama `llama3.2` ;
- adresse : `127.0.0.1:8787`.
