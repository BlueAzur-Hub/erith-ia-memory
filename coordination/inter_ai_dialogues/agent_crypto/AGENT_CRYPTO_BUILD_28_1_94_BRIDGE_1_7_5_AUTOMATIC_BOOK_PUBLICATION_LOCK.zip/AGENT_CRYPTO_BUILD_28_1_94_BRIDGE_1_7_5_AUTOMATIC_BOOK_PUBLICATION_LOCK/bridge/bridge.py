#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import getpass
import json
import os
import re
import signal
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse
from typing import Any

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "bridge_config.json"
PID_PATH = ROOT / "bridge.pid"


GITHUB_PUBLISH_REQUEST_SCHEMA = "agent_crypto_bridge_publish_request_v1"
GITHUB_PUBLISH_SYNTHESIS_SCHEMA = "agent_crypto_shared_synthesis_v1"
GITHUB_PUBLISH_REPOSITORY = "BlueAzur-Hub/erith-ia-memory"
GITHUB_PUBLISH_BRANCH = "main"
GITHUB_PUBLISH_PATH = "public/agent_crypto_erith_ia/data/latest_atlas_aerith_synthesis.json"
GITHUB_PUBLISH_PAGES_URL = "https://blueazur-hub.github.io/erith-ia-memory/public/agent_crypto_erith_ia/data/latest_atlas_aerith_synthesis.json"
GITHUB_PUBLISH_REPORT_MODES = ("market", "top5", "math", "contradictions")
GITHUB_PUBLISH_LOCK = threading.Lock()

CANONICAL_PROFILE_FILES = {
    "atlas": (
        ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_MULTI_AGENT_CORE.md",
        ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_PERSONA_OPERATING_LAYER.md",
    ),
    "aerith": (
        ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_MULTI_AGENT_CORE.md",
        ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_PERSONA_OPERATING_LAYER.md",
    ),
}

RUNTIME_PROFILE_FILES = {
    "atlas": ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_RUNTIME_PROMPT.md",
    "aerith": ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_RUNTIME_PROMPT.md",
}

MODE_LABELS = {
    "market": "Synthèse du marché",
    "top5": "Analyse du Target Top 5",
    "math": "Explication du Math Core",
    "contradictions": "Contrôle des contradictions",
    "chat": "Réponse à la question libre",
    "conclusion": "Conclusion Aerith-10 Crypto",
}

FORBIDDEN_MODEL_PATTERNS = (
    r"\bportefeuille\b",
    r"\bratio de sharpe\b",
    r"\bvalue at risk\b",
    r"\bexpected shortfall\b",
    r"\bacheter\b",
    r"\bvendre\b",
    r"\bsignal d['’]?achat\b",
    r"\bstop point.{0,30}\bjours?\b",
    r"\bcourbe en bas\b",
)

SAFETY_CONTRACT = """
CONTRAT LOCAL OBLIGATOIRE
- Lecture seule.
- Aucun ordre financier, wallet, exchange, GitHub ou action d'interface.
- La liste du marché n'est jamais un portefeuille.
- Le Target Top 5 canonique est BTC, ETH, BNB, XRP et SOL.
- Agent-Crypto calcule les faits ; le modèle local ne les remplace pas.
- Une mesure absente reste absente.
- Une limite générale n'est pas une actualité.
- La position visuelle d'une courbe ne prouve aucune tendance.
- Le stop point n'est pas une durée : c'est la limite des données disponibles.
""".strip()


FRESHNESS_LABELS = {
    "fresh": "récente",
    "delayed": "retardée",
    "stale": "ancienne",
    "archive": "archivée",
    "expired": "expirée",
    "direct": "directe",
    "cache": "en cache",
    "recent-cache": "en cache récent",
    "local-cache": "en cache local",
}

MODEL_COMMENT_PROFILES = {
    "atlas": (
        "Tu es Atlas-10 Crypto. Ajoute un commentaire analytique très court, "
        "sobre, contradictoire et limité aux faits condensés transmis."
    ),
    "aerith": (
        "Tu es Aerith-10 Crypto. Ajoute un commentaire pédagogique très court, "
        "prudent, hiérarchisé et limité aux faits condensés transmis. "
        "Évite de répéter les chiffres déjà exposés et formule la limite principale de façon concrète. N’écris jamais une consigne générale à l’infinitif comme « analyser », « évaluer » ou « utiliser »."
    ),
}

HISTORY_BINANCE_BASES = (
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api-gcp.binance.com",
)

HISTORY_PERIODS = {
    1: {"interval": "5m", "limit": 300, "api_days": 1},
    7: {"interval": "30m", "limit": 350, "api_days": 7},
    30: {"interval": "2h", "limit": 370, "api_days": 30},
    60: {"interval": "4h", "limit": 370, "api_days": 60},
    90: {"interval": "4h", "limit": 550, "api_days": 90},
    365: {"interval": "12h", "limit": 740, "api_days": 365},
    36500: {"interval": "1d", "limit": 1000, "api_days": "max"},
}

HISTORY_CACHE: dict[str, dict[str, Any]] = {}
HISTORY_CACHE_LOCK = threading.Lock()
HISTORY_INFLIGHT: dict[str, dict[str, Any]] = {}
HISTORY_INFLIGHT_LOCK = threading.Lock()


SCANNER_DATA_DIR = ROOT / "data" / "scanner_live"
SCANNER_LATEST_PATH = SCANNER_DATA_DIR / "latest.json"
SCANNER_WRITE_LOCK = threading.Lock()
SCANNER_BINANCE_TICKER_CACHE: dict[str, Any] = {"saved_at": 0.0, "rows": {}}
SCANNER_BINANCE_TICKER_LOCK = threading.Lock()
SCANNER_SCHEMA = "atlas_scanner_live_snapshot_v1"
SCANNER_BASKETS = ("top5", "gainers", "losers", "volume")

MODEL_COMMENT_RULES = """
CONTRAT DU COMMENTAIRE LOCAL
- Trois phrases courtes seulement.
- Aucun chiffre.
- Aucun nom de mesure absent.
- Aucune instruction financière.
- Aucune donnée extérieure.
- Aucun actif ajouté.
- Aucune causalité supposée.
- Termine par les limites visibles.
- Pour Aerith, chaque phrase doit commenter le snapshot présent et non reformuler une consigne.
- Les verbes génériques à l’infinitif comme analyser, évaluer ou utiliser sont interdits.
""".strip()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_config() -> dict[str, Any]:
    config = load_json(CONFIG_PATH)
    if config.get("host") not in {"127.0.0.1", "localhost"}:
        raise RuntimeError("Le Bridge doit rester lié à 127.0.0.1 ou localhost.")
    return config


def request_json(url: str, payload: dict[str, Any] | None, timeout: int) -> dict[str, Any]:
    data = None
    headers = {"Accept": "application/json"}
    method = "GET"
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
        method = "POST"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read()
    return json.loads(raw.decode("utf-8")) if raw else {}



def github_secret_path() -> Path:
    local_app_data = str(os.environ.get("LOCALAPPDATA") or "").strip()
    base = Path(local_app_data) if local_app_data else ROOT / "private"
    return base / "ERITH.IA" / "AgentCrypto" / "github_publish_secret.json"


def load_github_token() -> str:
    token = str(os.environ.get("ERITH_GITHUB_TOKEN") or "").strip()
    if token:
        return token
    path = github_secret_path()
    if not path.exists():
        return ""
    try:
        payload = load_json(path)
    except Exception:
        return ""
    return str(payload.get("token") or "").strip()


def github_publication_config(config: dict[str, Any]) -> dict[str, Any]:
    section = config.get("github_publication") or {}
    repository = str(section.get("repository") or GITHUB_PUBLISH_REPOSITORY)
    branch = str(section.get("branch") or GITHUB_PUBLISH_BRANCH)
    path = str(section.get("path") or GITHUB_PUBLISH_PATH)
    if repository != GITHUB_PUBLISH_REPOSITORY:
        raise RuntimeError("Dépôt GitHub de publication non autorisé.")
    if branch != GITHUB_PUBLISH_BRANCH:
        raise RuntimeError("Branche GitHub de publication non autorisée.")
    if path != GITHUB_PUBLISH_PATH:
        raise RuntimeError("Chemin GitHub de publication non autorisé.")
    return {
        "enabled": section.get("enabled", True) is True,
        "repository": repository,
        "branch": branch,
        "path": path,
        "pages_url": GITHUB_PUBLISH_PAGES_URL,
        "max_bytes": int(section.get("max_bytes") or 5 * 1024 * 1024),
        "timeout_seconds": int(section.get("timeout_seconds") or 30),
    }


def github_api_call(
    method: str,
    url: str,
    token: str,
    payload: dict[str, Any] | None = None,
    timeout: int = 30,
) -> tuple[int, dict[str, Any]]:
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "ERITH-IA-Agent-Crypto-Bridge/1.7.5",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=max(5, int(timeout))) as response:
            raw = response.read()
            parsed = json.loads(raw.decode("utf-8")) if raw else {}
            return int(response.status), parsed if isinstance(parsed, dict) else {}
    except urllib.error.HTTPError as exc:
        try:
            raw = exc.read().decode("utf-8", errors="replace")
            parsed = json.loads(raw) if raw else {}
        except Exception:
            parsed = {}
        return int(exc.code), parsed if isinstance(parsed, dict) else {}


def github_error_message(status: int, payload: dict[str, Any]) -> str:
    if status == 401:
        return "jeton GitHub refusé"
    if status == 403:
        return "permission GitHub insuffisante ou limite API atteinte"
    if status == 404:
        return "dépôt GitHub ou chemin de publication introuvable"
    if status == 409:
        return "conflit de publication GitHub"
    message = re.sub(r"\s+", " ", str(payload.get("message") or "erreur GitHub")).strip()
    return f"GitHub HTTP {status} · {message[:180]}"


def validate_publish_request(body: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    if body.get("schema") != GITHUB_PUBLISH_REQUEST_SCHEMA:
        raise ValueError("Schéma de requête de publication invalide.")
    synthesis = body.get("synthesis")
    if not isinstance(synthesis, dict):
        raise ValueError("Synthèse Atlas/Aerith absente.")
    if synthesis.get("schema") != GITHUB_PUBLISH_SYNTHESIS_SCHEMA:
        raise ValueError("Schéma de synthèse Atlas/Aerith invalide.")
    fingerprint = str(synthesis.get("fingerprint") or "").strip()
    if not fingerprint:
        raise ValueError("Empreinte de synthèse absente.")
    reports = synthesis.get("reports")
    if not isinstance(reports, dict):
        raise ValueError("Rapports Atlas absents.")
    for mode in GITHUB_PUBLISH_REPORT_MODES:
        answer = str((reports.get(mode) or {}).get("answer") or "").strip()
        if not answer:
            raise ValueError(f"Rapport Atlas manquant : {mode}.")
    conclusion = synthesis.get("conclusion")
    if not isinstance(conclusion, dict) or not str(conclusion.get("answer") or "").strip():
        raise ValueError("Conclusion Aerith absente.")
    clean = json.loads(json.dumps(synthesis, ensure_ascii=False))
    clean["publication"] = {
        "channel": "github_pages_data",
        "repository": GITHUB_PUBLISH_REPOSITORY,
        "branch": GITHUB_PUBLISH_BRANCH,
        "repository_path": GITHUB_PUBLISH_PATH,
        "published_by": "Atlas-10 Crypto Bridge Ryzen V1.7.5",
        "published_at": utc_now(),
        "read_only_book": True,
    }
    raw = json.dumps(clean, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    maximum = github_publication_config(config)["max_bytes"]
    if len(raw) > maximum:
        raise ValueError("Synthèse supérieure à la limite de publication GitHub.")
    return clean


def existing_github_fingerprint(payload: dict[str, Any]) -> str:
    encoded = str(payload.get("content") or "").replace("\n", "")
    if not encoded:
        return ""
    try:
        decoded = base64.b64decode(encoded).decode("utf-8")
        existing = json.loads(decoded)
    except Exception:
        return ""
    return str(existing.get("fingerprint") or "").strip() if isinstance(existing, dict) else ""


def publish_synthesis_to_github(body: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    publication = github_publication_config(config)
    if not publication["enabled"]:
        raise RuntimeError("Publication GitHub désactivée dans bridge_config.json.")
    token = load_github_token()
    if not token:
        raise RuntimeError("Publication GitHub non configurée. Lance CONFIGURE_GITHUB_PUBLICATION.bat une seule fois sur le Ryzen.")
    synthesis = validate_publish_request(body, config)
    raw = json.dumps(synthesis, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    encoded = base64.b64encode(raw).decode("ascii")
    repository = publication["repository"]
    path = quote(publication["path"], safe="/")
    branch = publication["branch"]
    url = f"https://api.github.com/repos/{repository}/contents/{path}"

    with GITHUB_PUBLISH_LOCK:
        status, existing = github_api_call(
            "GET", f"{url}?ref={quote(branch, safe='')}", token,
            timeout=publication["timeout_seconds"],
        )
        if status not in {200, 404}:
            raise RuntimeError(github_error_message(status, existing))
        existing_sha = str(existing.get("sha") or "") if status == 200 else ""
        existing_fingerprint = existing_github_fingerprint(existing) if status == 200 else ""
        if existing_fingerprint and existing_fingerprint == str(synthesis.get("fingerprint") or ""):
            return {
                "ok": True,
                "unchanged": True,
                "fingerprint": existing_fingerprint,
                "commit_sha": "",
                "repository_path": publication["path"],
                "pages_url": publication["pages_url"],
                "published_at": synthesis.get("publication", {}).get("published_at"),
            }

        snapshot_label = re.sub(r"\s+", " ", str(synthesis.get("snapshot_label") or "snapshot")).strip()[:80]
        put_payload: dict[str, Any] = {
            "message": f"publish atlas aerith synthesis {snapshot_label}",
            "content": encoded,
            "branch": branch,
        }
        if existing_sha:
            put_payload["sha"] = existing_sha
        put_status, result = github_api_call(
            "PUT", url, token, put_payload,
            timeout=publication["timeout_seconds"],
        )
        if put_status not in {200, 201}:
            raise RuntimeError(github_error_message(put_status, result))
        commit_sha = str((result.get("commit") or {}).get("sha") or "")
        content_sha = str((result.get("content") or {}).get("sha") or "")
        return {
            "ok": True,
            "unchanged": False,
            "fingerprint": str(synthesis.get("fingerprint") or ""),
            "commit_sha": commit_sha,
            "content_sha": content_sha,
            "repository_path": publication["path"],
            "pages_url": publication["pages_url"],
            "published_at": synthesis.get("publication", {}).get("published_at"),
        }


def configure_github_publication() -> int:
    print("Configuration unique de la publication GitHub Agent-Crypto.")
    print(f"Dépôt verrouillé : {GITHUB_PUBLISH_REPOSITORY}")
    print(f"Chemin verrouillé : {GITHUB_PUBLISH_PATH}")
    token = getpass.getpass("Colle le jeton GitHub finement limité au dépôt (Contents: Read and write) : ").strip()
    if len(token) < 20:
        print("Jeton refusé : valeur vide ou trop courte.")
        return 2
    status, payload = github_api_call("GET", "https://api.github.com/user", token, timeout=20)
    if status != 200:
        print("Jeton refusé : " + github_error_message(status, payload))
        return 3
    path = github_secret_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({
        "schema": "erith_agent_crypto_github_secret_v1",
        "token": token,
        "repository": GITHUB_PUBLISH_REPOSITORY,
        "path": GITHUB_PUBLISH_PATH,
        "configured_at": utc_now(),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    login = str(payload.get("login") or "compte GitHub")
    print(f"Configuration enregistrée pour {login}.")
    print(f"Secret local : {path}")
    print("Le jeton n’est jamais envoyé à l’Interface ni enregistré dans GitHub Pages.")
    return 0


def remove_github_publication() -> int:
    path = github_secret_path()
    try:
        path.unlink(missing_ok=True)
    except Exception as exc:
        print(f"Suppression impossible : {exc}")
        return 2
    print("Jeton local de publication supprimé.")
    return 0


def history_error_text(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return re.sub(r"\s+", " ", text)[:220]


def history_request_json(url: str, timeout: float) -> Any:
    headers = {
        "Accept": "application/json",
        "User-Agent": "Atlas-10-Crypto-Bridge/1.7.5 (+local-read-only-history)",
    }
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=max(1.0, float(timeout))) as response:
            raw = response.read()
        return json.loads(raw.decode("utf-8")) if raw else None
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")[:180]
        except Exception:
            body = ""
        suffix = f" · {body}" if body else ""
        raise RuntimeError(f"HTTP {exc.code}{suffix}") from exc


def history_cache_get(key: str, max_age_seconds: int) -> dict[str, Any] | None:
    with HISTORY_CACHE_LOCK:
        item = HISTORY_CACHE.get(key)
        if not item:
            return None
        if time.time() - float(item.get("saved_at", 0)) > max_age_seconds:
            HISTORY_CACHE.pop(key, None)
            return None
        payload = item.get("payload")
        return dict(payload) if isinstance(payload, dict) else None


def history_cache_put(key: str, payload: dict[str, Any]) -> None:
    with HISTORY_CACHE_LOCK:
        HISTORY_CACHE[key] = {"saved_at": time.time(), "payload": dict(payload)}
        if len(HISTORY_CACHE) > 160:
            oldest = sorted(HISTORY_CACHE, key=lambda item: HISTORY_CACHE[item].get("saved_at", 0))[:40]
            for stale in oldest:
                HISTORY_CACHE.pop(stale, None)


def history_fetch_binance_rows(symbol: str, interval: str, limit: int, total_timeout: float) -> list[Any]:
    deadline = time.monotonic() + max(2.0, total_timeout)
    errors: list[str] = []
    for base in HISTORY_BINANCE_BASES:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        url = (
            f"{base}/api/v3/klines?symbol={quote(symbol, safe='')}"
            f"&interval={quote(interval, safe='')}&limit={int(limit)}"
        )
        try:
            payload = history_request_json(url, min(5.0, remaining))
            if not isinstance(payload, list) or not payload:
                raise RuntimeError("chandelles absentes")
            return payload
        except Exception as exc:
            errors.append(f"{base}: {history_error_text(exc)}")
    raise RuntimeError(" | ".join(errors) or f"Binance indisponible pour {symbol}")


def history_normalize_binance(rows: list[Any]) -> tuple[list[list[float]], list[list[float]]]:
    series: list[list[float]] = []
    volumes: list[list[float]] = []
    for row in rows:
        if not isinstance(row, list) or len(row) < 8:
            continue
        try:
            timestamp = float(row[0])
            close = float(row[4])
            quote_volume = float(row[7])
        except (TypeError, ValueError):
            continue
        if timestamp > 0 and close > 0:
            series.append([timestamp, close])
            if quote_volume >= 0:
                volumes.append([timestamp, quote_volume])
    return series, volumes


def history_normalize_derived(
    crypto_rows: list[Any],
    eur_rows: list[Any],
) -> tuple[list[list[float]], list[list[float]]]:
    eur_by_time: dict[float, float] = {}
    for row in eur_rows:
        if not isinstance(row, list) or len(row) < 5:
            continue
        try:
            timestamp = float(row[0])
            close = float(row[4])
        except (TypeError, ValueError):
            continue
        if timestamp > 0 and close > 0:
            eur_by_time[timestamp] = close

    series: list[list[float]] = []
    volumes: list[list[float]] = []
    for row in crypto_rows:
        if not isinstance(row, list) or len(row) < 8:
            continue
        try:
            timestamp = float(row[0])
            crypto_close = float(row[4])
            quote_volume_usdt = float(row[7])
        except (TypeError, ValueError):
            continue
        eur_usdt = eur_by_time.get(timestamp)
        if timestamp > 0 and crypto_close > 0 and eur_usdt and eur_usdt > 0:
            series.append([timestamp, crypto_close / eur_usdt])
            if quote_volume_usdt >= 0:
                volumes.append([timestamp, quote_volume_usdt / eur_usdt])
    return series, volumes


def history_payload(
    *,
    coin_id: str,
    symbol: str,
    days: int,
    provider: str,
    source_mode: str,
    source: str,
    interval: str | None,
    api_days: int | str,
    series: list[list[float]],
    volume_series: list[list[float]],
    attempts: list[str],
) -> dict[str, Any]:
    generated_at = utc_now()
    if series:
        try:
            generated_at = datetime.fromtimestamp(series[-1][0] / 1000, timezone.utc).isoformat()
        except Exception:
            pass
    return {
        "ok": True,
        "read_only": True,
        "bridge_version": "1.7.5",
        "coin_id": coin_id,
        "symbol": symbol,
        "days": days,
        "provider": provider,
        "source_mode": source_mode,
        "source": source,
        "interval": interval,
        "api_days": api_days,
        "generated_at": generated_at,
        "point_count": len(series),
        "series": series,
        "volume_series": volume_series,
        "attempts": attempts,
    }


def fetch_history(config: dict[str, Any], coin_id: str, symbol: str, days: int, allow_binance: bool = True) -> dict[str, Any]:
    history_config = config.get("history_proxy", {})
    if history_config.get("enabled", True) is not True:
        raise RuntimeError("Proxy historique désactivé.")

    period = HISTORY_PERIODS[days]
    cache_seconds = int(history_config.get("cache_seconds", 60))
    cache_key = f"{coin_id}:{symbol}:{days}:{int(allow_binance)}"
    cached = history_cache_get(cache_key, cache_seconds)
    if cached:
        cached["cache"] = "bridge-memory-recent"
        return cached

    attempts: list[str] = []
    binance_timeout = float(history_config.get("binance_timeout_seconds", 12))
    coingecko_timeout = float(history_config.get("coingecko_timeout_seconds", 10))
    direct_symbol = f"{symbol}EUR"
    usdt_symbol = f"{symbol}USDT"

    if allow_binance:
        try:
            rows = history_fetch_binance_rows(
                direct_symbol,
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            series, volumes = history_normalize_binance(rows)
            if len(series) < 3:
                raise RuntimeError("série Binance EUR trop courte")
            payload = history_payload(
                coin_id=coin_id,
                symbol=symbol,
                days=days,
                provider="binance",
                source_mode="binance-bridge-direct-klines",
                source=f"Binance Spot {symbol}/EUR · Bridge local",
                interval=str(period["interval"]),
                api_days=period["api_days"],
                series=series,
                volume_series=volumes,
                attempts=attempts,
            )
            history_cache_put(cache_key, payload)
            return payload
        except Exception as exc:
            attempts.append(f"Binance {direct_symbol}: {history_error_text(exc)}")

        try:
            # Deux appels ont chacun un budget borné ; le cache du Bridge évite les répétitions.
            crypto_rows = history_fetch_binance_rows(
                usdt_symbol,
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            eur_rows = history_fetch_binance_rows(
                "EURUSDT",
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            series, volumes = history_normalize_derived(crypto_rows, eur_rows)
            if len(series) < 3:
                raise RuntimeError("série Binance USDT/EUR trop courte")
            payload = history_payload(
                coin_id=coin_id,
                symbol=symbol,
                days=days,
                provider="binance",
                source_mode="binance-bridge-derived-klines",
                source=f"Binance Spot {symbol}/USDT ÷ EUR/USDT · Bridge local",
                interval=str(period["interval"]),
                api_days=period["api_days"],
                series=series,
                volume_series=volumes,
                attempts=attempts,
            )
            history_cache_put(cache_key, payload)
            return payload
        except Exception as exc:
            attempts.append(f"Binance {usdt_symbol}/EURUSDT: {history_error_text(exc)}")

    else:
        attempts.append("Binance ignoré : symbole CoinGecko ambigu dans le Market")

    try:
        api_days = period["api_days"]
        url = (
            "https://api.coingecko.com/api/v3/coins/"
            f"{quote(coin_id, safe='')}/market_chart?vs_currency=eur"
            f"&days={quote(str(api_days), safe='')}&precision=full"
        )
        data = history_request_json(url, coingecko_timeout)
        raw_prices = data.get("prices", []) if isinstance(data, dict) else []
        raw_volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        series = [
            [float(row[0]), float(row[1])]
            for row in raw_prices
            if isinstance(row, list) and len(row) >= 2
            and float(row[0]) > 0 and float(row[1]) > 0
        ]
        volumes = [
            [float(row[0]), float(row[1])]
            for row in raw_volumes
            if isinstance(row, list) and len(row) >= 2
            and float(row[0]) > 0 and float(row[1]) >= 0
        ]
        if len(series) < 3:
            raise RuntimeError("série CoinGecko trop courte")
        payload = history_payload(
            coin_id=coin_id,
            symbol=symbol,
            days=days,
            provider="coingecko",
            source_mode="coingecko-bridge-direct",
            source="CoinGecko market_chart EUR · Bridge local",
            interval=None,
            api_days=api_days,
            series=series,
            volume_series=volumes,
            attempts=attempts,
        )
        history_cache_put(cache_key, payload)
        return payload
    except Exception as exc:
        attempts.append(f"CoinGecko {coin_id}: {history_error_text(exc)}")

    error = RuntimeError("Aucun historique direct disponible via le Bridge.")
    setattr(error, "attempts", attempts)
    raise error


def fetch_history_singleflight(
    config: dict[str, Any],
    coin_id: str,
    symbol: str,
    days: int,
    allow_binance: bool = True,
) -> dict[str, Any]:
    """Une seule récupération externe active par actif/période.

    Les requêtes Firefox concurrentes attendent le même résultat au lieu de
    relancer Binance/CoinGecko. Le résultat reste ensuite couvert par le cache
    mémoire normal du Bridge.
    """
    key = f"{coin_id}:{symbol}:{days}:{int(allow_binance)}"
    with HISTORY_INFLIGHT_LOCK:
        entry = HISTORY_INFLIGHT.get(key)
        owner = entry is None
        if owner:
            entry = {
                "event": threading.Event(),
                "payload": None,
                "error": None,
                "started_at": time.monotonic(),
            }
            HISTORY_INFLIGHT[key] = entry

    assert entry is not None
    if owner:
        try:
            payload = fetch_history(config, coin_id, symbol, days, allow_binance)
            entry["payload"] = payload
            return dict(payload)
        except Exception as exc:
            entry["error"] = exc
            raise
        finally:
            entry["event"].set()
            with HISTORY_INFLIGHT_LOCK:
                HISTORY_INFLIGHT.pop(key, None)

    wait_seconds = max(
        8.0,
        float(config.get("history_proxy", {}).get("singleflight_wait_seconds", 35)),
    )
    if not entry["event"].wait(wait_seconds):
        raise RuntimeError("Historique déjà en cours : délai d’attente dépassé.")
    payload = entry.get("payload")
    if isinstance(payload, dict):
        replay = dict(payload)
        replay["cache"] = "bridge-single-flight"
        return replay
    error = entry.get("error")
    if isinstance(error, Exception):
        raise RuntimeError(str(error)) from error
    raise RuntimeError("Historique simultané terminé sans résultat.")


def scanner_finite(value: Any, *, positive: bool = False) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not (number == number and abs(number) != float("inf")):
        return None
    if positive and number <= 0:
        return None
    return number


def scanner_safe_text(value: Any, limit: int = 160) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    return re.sub(r"\s+", " ", text)[:limit]


def scanner_validate_asset(asset: Any, basket: str, index: int) -> dict[str, Any]:
    if not isinstance(asset, dict):
        raise ValueError(f"Actif invalide dans {basket} à la position {index + 1}.")
    coin_id = scanner_safe_text(asset.get("coin_id"), 80)
    symbol = scanner_safe_text(asset.get("symbol"), 20)
    if not coin_id or not re.fullmatch(r"[a-z0-9-]{1,80}", coin_id):
        raise ValueError(f"coin_id invalide dans {basket}.")
    if not symbol or not re.fullmatch(r"[A-Z0-9]{1,20}", symbol):
        raise ValueError(f"symbol invalide dans {basket}.")
    return {
        "coin_id": coin_id,
        "symbol": symbol,
        "name": scanner_safe_text(asset.get("name"), 120),
        "market_rank": scanner_finite(asset.get("market_rank")),
        "scanner_rank": scanner_finite(asset.get("scanner_rank")),
        "classification_source": scanner_safe_text(asset.get("classification_source"), 100),
        "classification_metric": scanner_safe_text(asset.get("classification_metric"), 60),
        "classification_value": scanner_finite(asset.get("classification_value")),
        "market_price_eur": scanner_finite(asset.get("market_price_eur"), positive=True),
        "market_change_24h_pct": scanner_finite(asset.get("market_change_24h_pct")),
        "market_volume_24h_eur": scanner_finite(asset.get("market_volume_24h_eur")),
        "observed_price_eur": scanner_finite(asset.get("observed_price_eur"), positive=True),
        "observed_change_24h_pct": scanner_finite(asset.get("observed_change_24h_pct")),
        "observed_source": scanner_safe_text(asset.get("observed_source"), 160),
        "observed_status": scanner_safe_text(asset.get("observed_status"), 40),
        "observed_at": scanner_safe_text(asset.get("observed_at"), 60),
        "binance_symbol_candidate": scanner_safe_text(asset.get("binance_symbol_candidate"), 20),
        "binance_candidate_allowed": asset.get("binance_candidate_allowed") is True,
    }


def scanner_validate_snapshot(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Snapshot scanner invalide.")
    if payload.get("schema") != SCANNER_SCHEMA:
        raise ValueError(f"Schéma scanner refusé : {payload.get('schema')!r}.")
    snapshot_id = scanner_safe_text(payload.get("snapshot_id"), 140)
    collector_id = scanner_safe_text(payload.get("collector_id"), 100)
    collected_at = scanner_safe_text(payload.get("collected_at"), 60)
    if not snapshot_id or not re.fullmatch(r"[A-Za-z0-9_.-]{1,140}", snapshot_id):
        raise ValueError("snapshot_id scanner invalide.")
    if not collector_id:
        raise ValueError("collector_id scanner absent.")
    baskets_raw = payload.get("baskets")
    if not isinstance(baskets_raw, dict):
        raise ValueError("Paniers scanner absents.")

    baskets: dict[str, Any] = {}
    for key in SCANNER_BASKETS:
        raw = baskets_raw.get(key)
        if not isinstance(raw, dict):
            raise ValueError(f"Panier {key} absent.")
        assets_raw = raw.get("assets")
        if not isinstance(assets_raw, list) or not 1 <= len(assets_raw) <= 5:
            raise ValueError(f"Panier {key} : 1 à 5 actifs requis.")
        assets = [scanner_validate_asset(asset, key, index) for index, asset in enumerate(assets_raw)]
        coin_ids = [asset["coin_id"] for asset in assets]
        if len(set(coin_ids)) != len(coin_ids):
            raise ValueError(f"Panier {key} : actif dupliqué.")
        baskets[key] = {
            "id": key,
            "label": scanner_safe_text(raw.get("label"), 80) or key,
            "ranking_source": scanner_safe_text(raw.get("ranking_source"), 120),
            "ranking_metric": scanner_safe_text(raw.get("ranking_metric"), 80),
            "assets": assets,
        }

    market_raw = payload.get("market") if isinstance(payload.get("market"), dict) else {}
    exchange_raw = payload.get("exchange_feed") if isinstance(payload.get("exchange_feed"), dict) else {}
    return {
        "schema": SCANNER_SCHEMA,
        "snapshot_id": snapshot_id,
        "collector_id": collector_id,
        "collector_type": scanner_safe_text(payload.get("collector_type"), 60) or "agent_crypto_browser",
        "release": scanner_safe_text(payload.get("release"), 100),
        "collected_at": collected_at or utc_now(),
        "received_at": utc_now(),
        "reason": scanner_safe_text(payload.get("reason"), 80),
        "market": {
            "source": scanner_safe_text(market_raw.get("source"), 100),
            "mode": scanner_safe_text(market_raw.get("mode"), 40),
            "status": scanner_safe_text(market_raw.get("status"), 40),
            "timestamp": scanner_safe_text(market_raw.get("timestamp"), 60),
            "snapshot_id": scanner_safe_text(market_raw.get("snapshot_id"), 140),
            "assets_loaded": scanner_finite(market_raw.get("assets_loaded")),
            "target_assets": scanner_finite(market_raw.get("target_assets")),
            "quote_currency": scanner_safe_text(market_raw.get("quote_currency"), 12) or "EUR",
        },
        "exchange_feed": {
            "source": scanner_safe_text(exchange_raw.get("source"), 100),
            "status": scanner_safe_text(exchange_raw.get("status"), 40),
            "last_message_at": scanner_safe_text(exchange_raw.get("last_message_at"), 60),
            "direct_pairs": scanner_finite(exchange_raw.get("direct_pairs")),
            "derived_pairs": scanner_finite(exchange_raw.get("derived_pairs")),
        },
        "baskets": baskets,
        "safety": {
            "observation_only": True,
            "no_exchange_action": True,
            "no_wallet_action": True,
            "no_github_write": True,
            "ranking_never_decided_by_binance": True,
        },
    }


def scanner_binance_tickers(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    scanner_cfg = config.get("scanner_collector", {})
    ttl = max(10, int(scanner_cfg.get("binance_ticker_cache_seconds", 30)))
    with SCANNER_BINANCE_TICKER_LOCK:
        if time.time() - float(SCANNER_BINANCE_TICKER_CACHE.get("saved_at", 0)) <= ttl:
            rows = SCANNER_BINANCE_TICKER_CACHE.get("rows")
            if isinstance(rows, dict) and rows:
                return rows

    errors: list[str] = []
    timeout = max(2.0, float(scanner_cfg.get("binance_timeout_seconds", 6)))
    for base in HISTORY_BINANCE_BASES:
        try:
            payload = history_request_json(f"{base}/api/v3/ticker/24hr?type=MINI", timeout)
            if not isinstance(payload, list):
                raise RuntimeError("tickers Binance absents")
            rows = {
                str(row.get("symbol") or "").upper(): row
                for row in payload
                if isinstance(row, dict) and row.get("symbol")
            }
            if not rows:
                raise RuntimeError("catalogue ticker Binance vide")
            with SCANNER_BINANCE_TICKER_LOCK:
                SCANNER_BINANCE_TICKER_CACHE["saved_at"] = time.time()
                SCANNER_BINANCE_TICKER_CACHE["rows"] = rows
            return rows
        except Exception as exc:
            errors.append(history_error_text(exc))
    raise RuntimeError(" | ".join(errors) or "Tickers Binance indisponibles")


def scanner_binance_row_price(row: dict[str, Any] | None) -> tuple[float | None, float | None, float | None]:
    if not isinstance(row, dict):
        return None, None, None
    price = scanner_finite(row.get("lastPrice"), positive=True)
    change = scanner_finite(row.get("priceChangePercent"))
    volume = scanner_finite(row.get("quoteVolume"))
    return price, change, volume


def scanner_enrich_asset_binance(asset: dict[str, Any], rows: dict[str, dict[str, Any]], config: dict[str, Any]) -> dict[str, Any]:
    result = dict(asset)
    symbol = str(asset.get("binance_symbol_candidate") or "").upper()
    if not asset.get("binance_candidate_allowed") or not re.fullmatch(r"[A-Z0-9]{2,15}", symbol):
        result["binance_enrichment"] = "not_allowed"
        return result

    reference = scanner_finite(asset.get("market_price_eur"), positive=True)
    if not reference:
        result["binance_enrichment"] = "missing_reference"
        return result

    eur_price, eur_change, eur_volume = scanner_binance_row_price(rows.get(f"{symbol}EUR"))
    usdt_price, usdt_change, usdt_volume = scanner_binance_row_price(rows.get(f"{symbol}USDT"))
    eurusdt_price, eurusdt_change, _ = scanner_binance_row_price(rows.get("EURUSDT"))

    candidate_price = None
    candidate_change = None
    candidate_volume = None
    source = None
    pair = None
    if eur_price:
        candidate_price = eur_price
        candidate_change = eur_change
        candidate_volume = eur_volume
        pair = f"{symbol}EUR"
        source = f"Binance {symbol}/EUR ticker 24 h"
    elif usdt_price and eurusdt_price:
        candidate_price = usdt_price / eurusdt_price
        if usdt_change is not None:
            denominator = 1 + (eurusdt_change or 0) / 100
            candidate_change = ((1 + usdt_change / 100) / denominator - 1) * 100 if denominator > 0 else usdt_change
        candidate_volume = usdt_volume / eurusdt_price if usdt_volume is not None else None
        pair = f"{symbol}USDT/EURUSDT"
        source = f"Binance {symbol}/USDT ÷ EUR/USDT ticker 24 h"

    if not candidate_price:
        result["binance_enrichment"] = "pair_unavailable"
        return result

    max_gap = max(0.01, min(0.50, float(config.get("scanner_collector", {}).get("max_price_alignment_gap_ratio", 0.12))))
    gap = abs(candidate_price - reference) / reference
    if gap > max_gap:
        result["binance_enrichment"] = "rejected_price_alignment"
        result["binance_alignment_gap_ratio"] = round(gap, 6)
        return result

    result.update({
        "observed_price_eur": candidate_price,
        "observed_change_24h_pct": candidate_change if candidate_change is not None else result.get("observed_change_24h_pct"),
        "observed_source": source,
        "observed_status": "live_binance_verified",
        "observed_at": utc_now(),
        "binance_enrichment": "accepted_price_alignment",
        "binance_pair": pair,
        "binance_alignment_gap_ratio": round(gap, 6),
        "binance_quote_volume_eur": candidate_volume,
    })
    return result


def scanner_enrich_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    scanner_cfg = config.get("scanner_collector", {})
    if not scanner_cfg.get("binance_enrichment", True):
        return snapshot
    try:
        rows = scanner_binance_tickers(config)
    except Exception as exc:
        snapshot["binance_enrichment"] = {"status": "unavailable", "error": history_error_text(exc)}
        return snapshot

    accepted = 0
    rejected = 0
    for basket in snapshot.get("baskets", {}).values():
        enriched_assets = []
        for asset in basket.get("assets", []):
            enriched = scanner_enrich_asset_binance(asset, rows, config)
            if enriched.get("binance_enrichment") == "accepted_price_alignment":
                accepted += 1
            elif enriched.get("binance_candidate_allowed"):
                rejected += 1
            enriched_assets.append(enriched)
        basket["assets"] = enriched_assets
    snapshot["binance_enrichment"] = {
        "status": "complete",
        "accepted_assets": accepted,
        "not_accepted_assets": rejected,
        "method": "unique_symbol_plus_price_alignment",
        "ranking_unchanged": True,
    }
    return snapshot


def scanner_data_config(config: dict[str, Any]) -> dict[str, Any]:
    cfg = config.get("scanner_collector", {})
    return {
        "enabled": cfg.get("enabled", True) is True,
        "retention_days": max(1, min(90, int(cfg.get("retention_days", 14)))),
        "max_history_rows": max(1, min(5000, int(cfg.get("max_history_rows", 720)))),
    }


def scanner_prune_files(config: dict[str, Any]) -> None:
    cfg = scanner_data_config(config)
    cutoff = time.time() - cfg["retention_days"] * 86400
    if not SCANNER_DATA_DIR.exists():
        return
    for file in SCANNER_DATA_DIR.glob("20??-??-??.jsonl"):
        try:
            if file.stat().st_mtime < cutoff:
                file.unlink(missing_ok=True)
        except OSError:
            pass


def scanner_read_latest() -> dict[str, Any] | None:
    try:
        payload = load_json(SCANNER_LATEST_PATH)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def scanner_persist_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    cfg = scanner_data_config(config)
    if not cfg["enabled"]:
        raise RuntimeError("Scanner Live Collector désactivé dans bridge_config.json.")
    SCANNER_DATA_DIR.mkdir(parents=True, exist_ok=True)
    with SCANNER_WRITE_LOCK:
        latest = scanner_read_latest()
        if latest and latest.get("snapshot_id") == snapshot.get("snapshot_id"):
            return {"duplicate": True, "path": str(SCANNER_LATEST_PATH.relative_to(ROOT))}
        day = str(snapshot.get("collected_at") or utc_now())[:10]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        daily = SCANNER_DATA_DIR / f"{day}.jsonl"
        line = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")) + "\n"
        with daily.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(line)
        temp = SCANNER_LATEST_PATH.with_suffix(".tmp")
        temp.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(SCANNER_LATEST_PATH)
        scanner_prune_files(config)
        return {"duplicate": False, "path": str(daily.relative_to(ROOT))}


def scanner_history(config: dict[str, Any], basket: str, limit: int) -> list[dict[str, Any]]:
    if basket not in SCANNER_BASKETS:
        raise ValueError("basket autorisé : top5, gainers, losers ou volume.")
    max_rows = scanner_data_config(config)["max_history_rows"]
    limit = max(1, min(max_rows, int(limit)))
    if not SCANNER_DATA_DIR.exists():
        return []
    rows: list[dict[str, Any]] = []
    files = sorted(SCANNER_DATA_DIR.glob("20??-??-??.jsonl"), reverse=True)
    for file in files:
        try:
            lines = file.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in reversed(lines):
            try:
                payload = json.loads(line)
            except Exception:
                continue
            basket_payload = payload.get("baskets", {}).get(basket)
            if not isinstance(basket_payload, dict):
                continue
            rows.append({
                "snapshot_id": payload.get("snapshot_id"),
                "collected_at": payload.get("collected_at"),
                "market": payload.get("market"),
                "exchange_feed": payload.get("exchange_feed"),
                "binance_enrichment": payload.get("binance_enrichment"),
                "basket": basket_payload,
            })
            if len(rows) >= limit:
                return list(reversed(rows))
    return list(reversed(rows))


def scanner_status(config: dict[str, Any]) -> dict[str, Any]:
    latest = scanner_read_latest()
    files = sorted(SCANNER_DATA_DIR.glob("20??-??-??.jsonl")) if SCANNER_DATA_DIR.exists() else []
    return {
        "ok": True,
        "bridge_version": "1.7.5",
        "schema": SCANNER_SCHEMA,
        "enabled": scanner_data_config(config)["enabled"],
        "storage": "local_jsonl",
        "data_directory": str(SCANNER_DATA_DIR.relative_to(ROOT)),
        "daily_files": len(files),
        "latest_snapshot_id": latest.get("snapshot_id") if latest else None,
        "latest_collected_at": latest.get("collected_at") if latest else None,
        "latest_market_timestamp": latest.get("market", {}).get("timestamp") if latest else None,
        "basket_counts": {
            key: len(latest.get("baskets", {}).get(key, {}).get("assets", [])) if latest else 0
            for key in SCANNER_BASKETS
        },
        "read_only_external": True,
        "local_observation_storage": True,
    }


def provider_status(config: dict[str, Any], name: str) -> dict[str, Any]:
    provider = config["providers"][name]
    if not provider.get("enabled"):
        return {"enabled": False, "online": False, "models": [], "error": "désactivé"}

    base = provider["base_url"].rstrip("/")
    try:
        if name == "ollama":
            payload = request_json(f"{base}/api/tags", None, 2)
            models = [
                item.get("name", "")
                for item in payload.get("models", [])
                if item.get("name")
            ]
        else:
            payload = request_json(f"{base}/models", None, 2)
            models = [
                item.get("id", "")
                for item in payload.get("data", [])
                if item.get("id")
            ]
        return {"enabled": True, "online": True, "models": models, "error": ""}
    except Exception as exc:
        return {
            "enabled": True,
            "online": False,
            "models": [],
            "error": str(exc)[:180],
        }


def resolve_required_model(configured: str, models: list[str]) -> str:
    configured = str(configured or "").strip()
    if configured in models:
        return configured

    configured_base = configured.split(":", 1)[0]
    for model in models:
        if model.split(":", 1)[0] == configured_base:
            return model
    return ""


def choose_provider(config: dict[str, Any]) -> tuple[str, str]:
    preferred = str(config.get("preferred_provider") or "ollama")
    order = [preferred]
    if config.get("allow_provider_fallback", False):
        order.extend(
            name for name in ("ollama", "lm_studio")
            if name != preferred
        )

    for name in order:
        if name not in config["providers"]:
            continue

        provider = config["providers"][name]
        if not provider.get("enabled"):
            continue

        status = provider_status(config, name)
        if not status["online"]:
            continue

        configured = str(provider.get("model") or "").strip()
        if configured:
            resolved = resolve_required_model(configured, status["models"])
            if resolved:
                return name, resolved
            if provider.get("required"):
                raise RuntimeError(
                    f"Modèle requis absent : {configured}. "
                    f"Installe-le avec : ollama pull {configured}"
                )
        elif status["models"]:
            return name, status["models"][0]

    raise RuntimeError(
        "Aucun moteur local prêt. Lance Ollama et installe llama3.2."
    )


def profile_health() -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, canonical_files in CANONICAL_PROFILE_FILES.items():
        runtime_file = RUNTIME_PROFILE_FILES[name]
        missing = [
            str(path.relative_to(ROOT))
            for path in (*canonical_files, runtime_file)
            if not path.exists()
        ]
        result[name] = {
            "loaded": not missing,
            "runtime_mode": "strict_fact_contract_v2_sanitized_comment_math_v3",
            "canonical_files_present": all(path.exists() for path in canonical_files),
            "runtime_file_present": runtime_file.exists(),
            "missing": missing,
        }
    return result


def validate_contract(snapshot: dict[str, Any]) -> dict[str, Any]:
    contract = snapshot.get("strict_contract")
    if not isinstance(contract, dict):
        raise ValueError("Contrat factuel V2 absent du snapshot.")

    expected = "atlas_crypto_fact_contract_v2"
    if contract.get("schema") != expected:
        raise ValueError(
            f"Schéma factuel refusé : {contract.get('schema')!r}; attendu : {expected}."
        )

    top5 = contract.get("canonical_top5")
    if not isinstance(top5, dict):
        raise ValueError("Target Top 5 canonique absent.")

    symbols = top5.get("symbols")
    if symbols != ["BTC", "ETH", "BNB", "XRP", "SOL"]:
        raise ValueError("Target Top 5 non canonique.")

    rules = contract.get("rules")
    if not isinstance(rules, dict):
        raise ValueError("Règles du contrat absentes.")

    required_true = (
        "market_list_is_not_portfolio",
        "no_missing_value_to_zero",
        "no_visual_position_inference",
        "no_unlisted_math_measure",
        "no_news_from_generic_limit",
        "no_financial_instruction",
    )
    for key in required_true:
        if rules.get(key) is not True:
            raise ValueError(f"Règle factuelle non verrouillée : {key}.")

    return contract


def fmt_number(value: Any, digits: int = 2) -> str:
    number = float(value)
    text = f"{number:,.{digits}f}"
    return text.replace(",", "\u202f").replace(".", ",")


def fmt_price(value: Any) -> str:
    number = float(value)
    digits = 6 if abs(number) < 1 else 2
    return f"{fmt_number(number, digits)} €"


def fmt_pct(value: Any) -> str:
    number = float(value)
    sign = "+" if number > 0 else ""
    return f"{sign}{fmt_number(number, 2)} %"


def fmt_risk_pct(value: Any) -> str:
    number = float(value)
    return f"{fmt_number(abs(number), 2)} %"


def safe_value(value: Any, formatter=None) -> str:
    if value is None:
        return "indisponible"
    try:
        return formatter(value) if formatter else str(value)
    except Exception:
        return "indisponible"


STATUS_LABELS = {
    "ready": "prêt",
    "ok": "opérationnel",
    "loading": "chargement",
    "error": "erreur",
    "failed": "échec",
    "stale": "ancien",
    "live": "direct",
    "direct": "direct",
    "local-cache": "cache local",
    "recent-cache": "cache récent",
    "github-cache": "cache GitHub",
    "browser-cache": "cache navigateur",
    "cache": "cache",
    "fresh": "récent",
    "delayed": "retardé",
    "archive": "archive datée",
    "expired": "expiré",
    "linear": "linéaire",
    "log": "logarithmique",
    "price": "prix",
    "base100": "base 100",
    "normal": "normale",
}


def clean_sentence(value: Any) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r"\s+([,;:!?])", r"\1", text)
    text = re.sub(r"([.!?])\1+$", r"\1", text)
    text = re.sub(r"\.{2,}$", ".", text)
    return text


def label_status(value: Any, fallback: str = "inconnu") -> str:
    text = str(value or "").strip()
    if not text:
        return fallback
    return STATUS_LABELS.get(text.lower(), text)


def format_datetime_fr(value: Any) -> str:
    if value in (None, ""):
        return "indisponible"
    text = str(value).strip()
    try:
        normalized = text.replace("Z", "+00:00")
        date = datetime.fromisoformat(normalized)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        local = date.astimezone()
        return local.strftime("%d/%m/%Y à %H:%M:%S")
    except Exception:
        return clean_sentence(text)


def format_score_block(value: Any, fallback: str = "inconnu") -> str:
    if value is None:
        return fallback
    if isinstance(value, dict):
        level = (
            value.get("level")
            or value.get("label")
            or value.get("name")
            or value.get("status")
        )
        score = value.get("score")
        if level and score is not None:
            return f"{clean_sentence(level)} — score {safe_value(score)}/100"
        if level:
            return clean_sentence(level)
        if score is not None:
            return f"score {safe_value(score)}/100"
        compact = [
            f"{clean_sentence(key)} : {clean_sentence(item)}"
            for key, item in value.items()
            if item not in (None, "", [], {})
        ]
        return " · ".join(compact) if compact else fallback
    return clean_sentence(value) or fallback


def normalize_model_comment(value: Any) -> dict[str, str] | None:
    if not isinstance(value, dict):
        return None

    candidate = value
    for wrapper in ("comment", "commentaire", "response", "réponse", "analysis", "analyse"):
        nested = candidate.get(wrapper)
        if isinstance(nested, dict):
            candidate = nested
            break

    aliases = {
        "reading": ("reading", "lecture", "analyse", "interpretation", "interprétation"),
        "caution": ("caution", "prudence", "vigilance", "risque"),
        "limits": ("limits", "limites", "limit", "borne", "bornes"),
    }

    normalized: dict[str, str] = {}
    for target, keys in aliases.items():
        for key in keys:
            item = candidate.get(key)
            if isinstance(item, str) and item.strip():
                normalized[target] = clean_sentence(item)
                break

    return normalized if normalized else None


def parse_model_comment(raw: str) -> dict[str, str] | None:
    text = str(raw or "").strip()
    if not text:
        return None

    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)

    candidates = [text]
    first = text.find("{")
    last = text.rfind("}")
    if first >= 0 and last > first:
        candidates.append(text[first:last + 1])

    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            normalized = normalize_model_comment(parsed)
            if normalized:
                return normalized
        except Exception:
            pass

    labeled: dict[str, str] = {}
    label_map = {
        "reading": ("reading", "lecture", "analyse"),
        "caution": ("caution", "prudence", "vigilance"),
        "limits": ("limits", "limites", "bornes"),
    }
    for target, labels in label_map.items():
        for label in labels:
            match = re.search(
                rf"(?im)^\s*(?:[-*]\s*)?(?:\*\*)?{re.escape(label)}(?:\*\*)?\s*[:\-]\s*(.+)$",
                text,
            )
            if match:
                labeled[target] = clean_sentence(match.group(1))
                break

    return labeled if labeled else None


def freshness_label(value: Any, fallback: str = "inconnue") -> str:
    text = str(value or "").strip()
    if not text:
        return fallback
    return FRESHNESS_LABELS.get(text.lower(), text)


def model_comment_profile(profile: str) -> str:
    return MODEL_COMMENT_PROFILES.get(profile, MODEL_COMMENT_PROFILES["atlas"])


def sanitize_comment_question(value: Any) -> str:
    text = clean_sentence(value)
    if not text:
        return ""

    for pattern in FORBIDDEN_MODEL_PATTERNS:
        text = re.sub(
            pattern,
            "élément réservé au rapport factuel",
            text,
            flags=re.I | re.S,
        )

    text = re.sub(
        r"-?\d+(?:[.,]\d+)?",
        "valeur réservée au rapport factuel",
        text,
    )
    return clean_sentence(text)[:280]


def model_comment_facts(
    contract: dict[str, Any],
    mode: str,
    question: str,
) -> dict[str, Any]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    top5 = contract.get("canonical_top5", {})
    graph = contract.get("graph", {})
    math = contract.get("math", {})
    news = contract.get("news", {})
    contradictions = contract.get("contradictions") or []

    facts = {
        "mission": mode,
        "sources": {
            "binance": label_status(
                contract.get("sources", {}).get("binance", {}).get("feed_status")
            ),
            "coingecko": label_status(
                contract.get("sources", {}).get("coingecko", {}).get("status")
            ),
        },
        "market": {
            "breadth": clean_sentence(
                breadth.get("classification") or "indéterminée"
            ),
            "coverage": (
                "complète"
                if market.get("assets_loaded") == market.get("target_assets")
                else "partielle"
            ),
        },
        "target_group": {
            "coverage": "complète" if top5.get("complete") else "partielle",
        },
        "graph": {
            "history": clean_sentence(
                graph.get("truth_label") or "indisponible"
            ),
            "freshness": freshness_label(graph.get("freshness")),
            "series_available": bool(graph.get("series")),
        },
        "math": {
            "coverage": clean_sentence(math.get("coverage") or "indisponible"),
            "horizon_coherence": clean_sentence(
                math.get("horizon_coherence") or "indisponible"
            ),
            "amplitude": clean_sentence(
                math.get("amplitude_24h") or "indisponible"
            ),
            "global_risk": clean_sentence(
                math.get("risk_global") or "non évalué"
            ),
        },
        "news": {
            "status": label_status(news.get("status")),
            "qualified_event_available": bool(news.get("lead_event")),
        },
        "limits_present": bool(contradictions),
    }

    if mode == "chat":
        intent = sanitize_comment_question(question)
        if intent:
            facts["question_intent"] = intent

    return facts


def deterministic_sources(contract: dict[str, Any]) -> list[str]:
    binance = contract.get("sources", {}).get("binance", {})
    coingecko = contract.get("sources", {}).get("coingecko", {})
    return [
        f"- Binance : {label_status(binance.get('feed_status'))}"
        f" · {clean_sentence(binance.get('source') or 'source non précisée')}"
        f" · {safe_value(binance.get('direct_pairs'))} paires directes"
        f" · {safe_value(binance.get('derived_pairs'))} dérivées.",
        f"- CoinGecko : {label_status(coingecko.get('status'))}"
        f" · mode {label_status(coingecko.get('mode'))}"
        f" · horodatage {format_datetime_fr(coingecko.get('timestamp'))}.",
    ]


def deterministic_top5(contract: dict[str, Any]) -> list[str]:
    top5 = contract["canonical_top5"]
    lines = [
        f"Target canonique : {' / '.join(top5['symbols'])}.",
        f"Couverture : {'5/5' if top5.get('complete') else 'partielle'}.",
    ]
    for row in top5.get("assets", []):
        symbol = row.get("symbol") or "?"
        if not row.get("available"):
            lines.append(f"- {symbol} : prix indisponible.")
            continue
        lines.append(
            f"- {symbol} : {safe_value(row.get('price_eur'), fmt_price)}"
            f" · 24 h {safe_value(row.get('change_24h_pct'), fmt_pct)}"
            f" · {clean_sentence(row.get('source') or 'source inconnue')}"
            f" · état {label_status(row.get('quote_status'))}."
        )
    return lines


def deterministic_market(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    return [
        f"- Univers chargé : {safe_value(market.get('assets_loaded'))}/"
        f"{safe_value(market.get('target_assets'))} actifs, devise EUR.",
        f"- Largeur 24 h : {safe_value(breadth.get('positive'))} hausses"
        f" · {safe_value(breadth.get('negative'))} baisses"
        f" · {safe_value(breadth.get('stable'))} stables"
        f" · classification : {breadth.get('classification') or 'indéterminée'}.",
        f"- Base de calcul : {breadth.get('basis') or 'indisponible'}.",
    ]


def deterministic_graph(contract: dict[str, Any]) -> list[str]:
    graph = contract.get("graph", {})
    lines = [
        f"- Période : {clean_sentence(graph.get('period_label') or 'indisponible')}"
        f" · vue {label_status(graph.get('view'))}"
        f" · échelle {label_status(graph.get('scale'))}.",
        f"- Historique : {clean_sentence(graph.get('truth_label') or 'indisponible')}"
        f" · fournisseur {clean_sentence(graph.get('provider') or 'inconnu')}"
        f" · fraîcheur {freshness_label(graph.get('freshness'))}.",
        "- Règle : aucune tendance n’est déduite de la position verticale à l’écran.",
    ]

    series = graph.get("series") or []
    if series:
        for row in series:
            lines.append(
                f"- {clean_sentence(row.get('symbol') or '?')} : variation de série "
                f"{safe_value(row.get('series_change_pct'), fmt_pct)}"
                f" · {safe_value(row.get('points'))} points."
            )
    else:
        lines.append("- Aucune série exploitable dans le contrat.")

    return lines


def deterministic_math(contract: dict[str, Any]) -> list[str]:
    math = contract.get("math", {})
    window = math.get("active_window") or {}
    risk = math.get("historical_risk") or {}
    ci = risk.get("bootstrap_volatility_window_ci95_pct") or [None, None]

    lines = [
        f"- Actif : {math.get('asset') or 'indisponible'}.",
        f"- Score heuristique : {safe_value(math.get('heuristic_score'))}.",
        f"- Fenêtre active : {window.get('period_label') or 'indisponible'}"
        f" · granularité {window.get('granularity') or 'inconnue'}"
        f" · {safe_value(window.get('observations'))} points"
        f" · complétude {safe_value(window.get('completeness_pct'), fmt_pct)}.",
        f"- Volatilité réalisée sur la fenêtre : {safe_value(risk.get('realized_volatility_window_pct'), fmt_risk_pct)}.",
        f"- Volatilité réalisée annualisée : {safe_value(risk.get('realized_volatility_annualized_pct'), fmt_risk_pct)}.",
        f"- Volatilité EWMA annualisée : {safe_value(risk.get('ewma_volatility_annualized_pct'), fmt_risk_pct)}"
        f" · lambda {safe_value(risk.get('ewma_lambda'))}.",
        f"- Downside deviation annualisée : {safe_value(risk.get('downside_deviation_annualized_pct'), fmt_risk_pct)}.",
        f"- Drawdown maximal : {safe_value(risk.get('max_drawdown_pct'), fmt_risk_pct)}.",
        f"- VaR historique 95 % par pas : {safe_value(risk.get('var_historical_95_step_pct'), fmt_risk_pct)}.",
        f"- Expected Shortfall historique 95 % par pas : {safe_value(risk.get('expected_shortfall_historical_95_step_pct'), fmt_risk_pct)}.",
        f"- Corrélation au BTC : {safe_value(risk.get('correlation_btc'))}"
        f" · bêta {safe_value(risk.get('beta_btc'))}"
        f" · {safe_value(risk.get('benchmark_observations'))} observations alignées.",
        f"- Dispersion IQR par pas : {safe_value(risk.get('dispersion_iqr_step_pct'), fmt_risk_pct)}"
        f" · concentration des 10 % plus forts mouvements : {safe_value(risk.get('concentration_top10_absolute_moves_pct'), fmt_risk_pct)}.",
        f"- Intervalle bootstrap 95 % de volatilité de fenêtre : "
        f"{safe_value(ci[0] if len(ci) > 0 else None, fmt_risk_pct)} à "
        f"{safe_value(ci[1] if len(ci) > 1 else None, fmt_risk_pct)}"
        f" · {safe_value(risk.get('bootstrap_samples'))} rééchantillonnages.",
        f"- Ratio volume / capitalisation : {math.get('volume_market_cap_ratio') or 'indisponible'}.",
        f"- Risque global : {math.get('risk_global') or 'non évalué'}.",
        f"- Limite : {clean_sentence(math.get('limitation') or 'non précisée').rstrip('.')}.",
    ]

    not_calculated = math.get("explicitly_not_calculated") or []
    if not_calculated:
        lines.append("- Mesures non calculées : " + ", ".join(not_calculated) + ".")
    else:
        lines.append("- Toutes les mesures historiques prévues par Math Core V3 sont calculées pour cette fenêtre.")

    return lines


def deterministic_news(contract: dict[str, Any]) -> list[str]:
    news = contract.get("news", {})
    watchlist = contract.get("watchlist", {})
    lead = news.get("lead_event")

    lines = [
        f"- News Sentinel : {label_status(news.get('status'))}"
        f" · archive {format_datetime_fr(news.get('archive_time'))}.",
        f"- Watchlist : {safe_value(watchlist.get('configured_count'))} actifs observés"
        " · ce n’est pas un portefeuille.",
    ]

    if isinstance(lead, dict):
        lines.append(
            f"- Événement directeur : {clean_sentence(lead.get('headline') or lead.get('event_label') or 'sans titre')}"
            f" · preuve {format_score_block(lead.get('evidence'))}"
            f" · impact {format_score_block(lead.get('impact'))}."
        )
    else:
        lines.append("- Aucun événement directeur qualifié n’est fourni.")

    lines.append("- Une limite générale de données n’est jamais transformée en actualité.")
    return lines


def deterministic_contradictions(contract: dict[str, Any]) -> list[str]:
    issues = contract.get("contradictions") or []
    if not issues:
        return ["- Aucune contradiction déterministe enregistrée dans le contrat."]
    return [
        f"- [{clean_sentence(item.get('level') or 'à vérifier')}] "
        f"{clean_sentence(item.get('text') or item.get('code') or 'problème non décrit').rstrip('.')}."
        for item in issues
    ]


def deterministic_stop_point(contract: dict[str, Any]) -> list[str]:
    stop = contract.get("stop_point", {})
    return [
        f"- {stop.get('meaning') or 'Arrêter lorsque les données ne soutiennent plus la conclusion.'}",
        "- Aucune durée arbitraire n’est fixée.",
        "- Validation humaine obligatoire.",
    ]



def aerith_count_label(value: int, singular: str, plural: str) -> str:
    if value == 0:
        return f"aucun {singular}"
    if value == 1:
        return f"1 {singular}"
    return f"{value} {plural}"


def aerith_conclusion_situation(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    coverage = None
    try:
        loaded_n = int(loaded)
        target_n = int(target)
        if target_n > 0:
            coverage = (loaded_n / target_n) * 100
    except (TypeError, ValueError, ZeroDivisionError):
        coverage = None

    coverage_text = (
        f" ({fmt_number(coverage, 1)} % de couverture)" if coverage is not None else ""
    )
    return deterministic_sources(contract) + [
        f"- Univers chargé : {safe_value(loaded)}/{safe_value(target)} actifs{coverage_text}, devise EUR.",
        f"- État d’ensemble : {clean_sentence(breadth.get('classification') or 'indéterminée')}.",
        f"- Base de calcul : {breadth.get('basis') or 'indisponible'}.",
    ]


def aerith_conclusion_signal(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    top5 = contract.get("canonical_top5", {})

    try:
        positive_market = int(breadth.get("positive") or 0)
        negative_market = int(breadth.get("negative") or 0)
        stable_market = int(breadth.get("stable") or 0)
    except (TypeError, ValueError):
        positive_market = negative_market = stable_market = 0

    if positive_market > 0 and negative_market >= positive_market * 2:
        breadth_reading = (
            f"La pression baissière est large : {negative_market} baisses, "
            f"soit plus du double des {positive_market} hausses"
        )
    elif negative_market > 0 and positive_market >= negative_market * 2:
        breadth_reading = (
            f"La participation haussière est large : {positive_market} hausses, "
            f"soit plus du double des {negative_market} baisses"
        )
    elif positive_market == 0 and negative_market == 0:
        breadth_reading = "La largeur du marché n’est pas exploitable sur ce snapshot"
    else:
        breadth_reading = (
            f"La largeur reste partagée : {positive_market} hausses et {negative_market} baisses"
        )
    if stable_market:
        breadth_reading += f", avec {stable_market} actifs stables"
    breadth_reading += "."

    rows = [row for row in (top5.get("assets") or []) if row.get("available")]
    finite = [
        float(row.get("change_24h_pct"))
        for row in rows
        if isinstance(row.get("change_24h_pct"), (int, float))
    ]
    positives = sum(1 for value in finite if value > 0)
    negatives = sum(1 for value in finite if value < 0)
    stable = sum(1 for value in finite if value == 0)
    target_reading = " · ".join([
        aerith_count_label(positives, "actif positif", "actifs positifs"),
        aerith_count_label(negatives, "actif négatif", "actifs négatifs"),
        aerith_count_label(stable, "actif stable", "actifs stables"),
    ])
    return [
        f"- {breadth_reading}",
        f"- Target Top 5 : {target_reading} · couverture {'5/5' if top5.get('complete') else 'partielle'}.",
    ]


def aerith_conclusion_vigilance(contract: dict[str, Any]) -> list[str]:
    graph = contract.get("graph", {})
    math = contract.get("math", {})
    news = contract.get("news", {})
    watchlist = contract.get("watchlist", {})
    return [
        f"- Historique graphique : {clean_sentence(graph.get('truth_label') or 'indisponible')}"
        f" · fraîcheur {freshness_label(graph.get('freshness'))}.",
        f"- Math Core : {clean_sentence(math.get('risk_global') or 'risque global non évalué')}"
        f" · limite {clean_sentence(math.get('limitation') or 'non précisée').rstrip('.')}.",
        f"- News Sentinel : {label_status(news.get('status'))}.",
        f"- Watchlist : {safe_value(watchlist.get('configured_count'))} actifs observés"
        " · ce n’est pas un portefeuille.",
    ]


def aerith_conclusion_watch(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    graph = contract.get("graph", {})
    issues = contract.get("contradictions") or []
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    if loaded == target and loaded is not None:
        market_line = "- Vérifier que la prochaine lecture CoinGecko conserve la couverture complète du Market Snapshot."
    else:
        market_line = "- Vérifier si la prochaine lecture CoinGecko complète la couverture encore partielle du Market Snapshot."
    lines = [
        market_line,
        "- Contrôler la continuité des cinq cotations Binance directes du Target Top 5.",
        f"- Relever si la fraîcheur de l’historique graphique reste {freshness_label(graph.get('freshness'))} ou s’améliore.",
    ]
    if issues:
        lines.append("- Recontrôler les contradictions encore classées confirmées ou à vérifier.")
    else:
        lines.append("- Recontrôler l’apparition éventuelle d’une contradiction déterministe au prochain snapshot.")
    return lines



AERITH_GENERIC_COMMENT_PATTERNS = (
    r"^\s*(analyser|évaluer|utiliser|examiner|considérer|vérifier|contrôler|surveiller|prendre en compte|se baser)\b",
    r"\b(informations?|données?)\s+(fournies|disponibles)\b.{0,80}\b(sans ajout|sans modification)\b",
    r"\bqualité des données\b.{0,80}\bfiabilité des informations\b",
)


def aerith_market_coverage(contract: dict[str, Any]) -> tuple[int | None, int | None, float | None]:
    market = contract.get("market", {})
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    try:
        loaded_n = int(loaded)
        target_n = int(target)
        coverage = (loaded_n / target_n) * 100 if target_n > 0 else None
        return loaded_n, target_n, coverage
    except (TypeError, ValueError, ZeroDivisionError):
        return None, None, None


def aerith_top5_distribution(contract: dict[str, Any]) -> tuple[int, int, int, int]:
    rows = [
        row for row in (contract.get("canonical_top5", {}).get("assets") or [])
        if row.get("available")
    ]
    values = [
        float(row.get("change_24h_pct"))
        for row in rows
        if isinstance(row.get("change_24h_pct"), (int, float))
    ]
    positives = sum(1 for value in values if value > 0)
    negatives = sum(1 for value in values if value < 0)
    stable = sum(1 for value in values if value == 0)
    return positives, negatives, stable, len(values)


def aerith_concrete_limits_comment(contract: dict[str, Any]) -> dict[str, str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    graph = contract.get("graph", {})

    try:
        positive_market = int(breadth.get("positive") or 0)
        negative_market = int(breadth.get("negative") or 0)
    except (TypeError, ValueError):
        positive_market = negative_market = 0

    if positive_market > 0 and negative_market >= positive_market * 2:
        opening = "La pression baissière est largement partagée"
    elif negative_market > 0 and positive_market >= negative_market * 2:
        opening = "La participation haussière est largement partagée"
    elif positive_market or negative_market:
        opening = "La largeur du marché reste partagée"
    else:
        opening = "La largeur du marché reste insuffisamment documentée"

    loaded_n, target_n, coverage = aerith_market_coverage(contract)
    market_partial = (
        loaded_n is not None and target_n is not None and target_n > 0 and loaded_n < target_n
    )
    graph_freshness = freshness_label(graph.get("freshness"))
    graph_delayed = graph_freshness in {"retardée", "ancienne", "archivée", "expirée"}

    qualifiers: list[str] = []
    if market_partial:
        qualifiers.append("un Market Snapshot encore incomplet")
    if graph_delayed:
        qualifiers.append(f"un historique graphique {graph_freshness}")

    if qualifiers:
        reading = f"{opening}, mais elle repose sur " + " et sur ".join(qualifiers) + "."
    else:
        reading = f"{opening} sur les sources actuellement disponibles."
    reading += " Elle décrit l’état observé, pas son évolution future."

    positives, negatives, stable, count = aerith_top5_distribution(contract)
    if count and negatives == count:
        caution = (
            "Le Target Top 5 est entièrement négatif, mais cette convergence ne constitue "
            "ni une prévision ni un signal d’exécution."
        )
    elif count and positives == count:
        caution = (
            "Le Target Top 5 est entièrement positif, mais cette convergence ne constitue "
            "ni une prévision ni un signal d’exécution."
        )
    elif count:
        caution = (
            "Le Target Top 5 reste partagé ; cette distribution ne constitue ni une prévision "
            "ni un signal d’exécution."
        )
    else:
        caution = (
            "Le Target Top 5 n’est pas suffisamment couvert pour soutenir une prévision "
            "ou un signal d’exécution."
        )

    limits_parts = [
        "Les risques de protocole, de contrepartie, de réglementation, de liquidité d’exécution "
        "et les données on-chain ne sont pas évalués."
    ]
    if market_partial:
        if coverage is not None:
            limits_parts.append(
                f"La couverture CoinGecko reste partielle à {fmt_number(coverage, 1)} %."
            )
        else:
            limits_parts.append("La couverture CoinGecko reste partielle.")
    if graph_delayed:
        limits_parts.append("L’historique graphique ne fournit pas encore une fraîcheur directe.")

    return {
        "reading": reading,
        "caution": caution,
        "limits": " ".join(limits_parts),
    }


def validate_aerith_concrete_comment(
    comment: dict[str, Any],
    contract: dict[str, Any],
) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(comment, dict):
        return False, ["commentaire Aerith non structuré"]

    required = ("reading", "caution", "limits")
    values: dict[str, str] = {}
    for key in required:
        value = str(comment.get(key) or "").strip()
        values[key] = value
        if len(value) < 35:
            warnings.append(f"commentaire Aerith trop générique : {key}")
        lowered = value.lower()
        for pattern in AERITH_GENERIC_COMMENT_PATTERNS:
            if re.search(pattern, lowered, flags=re.I | re.S):
                warnings.append(f"consigne générique refusée : {key}")
                break

    if not re.search(r"baissi|haussi|largeur|état observé|marché", values["reading"], flags=re.I):
        warnings.append("lecture Aerith non ancrée dans le marché observé")
    if not re.search(r"prévision|exécution|décision|certitude|signal", values["caution"], flags=re.I):
        warnings.append("prudence Aerith non concrète")
    if not re.search(
        r"protocole|contrepartie|réglementation|liquidité|on-chain|couverture|historique|non évalu",
        values["limits"],
        flags=re.I,
    ):
        warnings.append("limites Aerith non reliées aux risques absents")

    return not warnings, warnings

def build_aerith_conclusion(contract: dict[str, Any], comment: dict[str, str]) -> str:
    sections = [
        ("1. Situation générale", aerith_conclusion_situation(contract)),
        ("2. Signal dominant", aerith_conclusion_signal(contract)),
        ("3. Points de vigilance", aerith_conclusion_vigilance(contract)),
        ("4. Contradictions importantes", deterministic_contradictions(contract)),
        ("5. Ce qu’il faut surveiller ensuite", aerith_conclusion_watch(contract)),
        ("6. Limites et stop point", render_comment(comment, "aerith") + deterministic_stop_point(contract)),
    ]
    lines: list[str] = []
    for title, body in sections:
        lines.append(f"**{title}**")
        lines.append("")
        lines.extend(body)
        lines.append("")
    return "\n".join(lines).strip()


def allowed_number_tokens(contract: dict[str, Any]) -> set[str]:
    raw = json.dumps(contract, ensure_ascii=False)
    numbers = re.findall(r"-?\d+(?:[.,]\d+)?", raw)
    allowed: set[str] = set()

    for token in numbers:
        normalized = token.replace(",", ".")
        allowed.add(token)
        allowed.add(normalized)
        try:
            value = float(normalized)
        except ValueError:
            continue
        for digits in range(0, 7):
            rendered = f"{value:.{digits}f}"
            allowed.add(rendered)
            allowed.add(rendered.replace(".", ","))

    # Numéros de sections autorisés.
    allowed.update(str(i) for i in range(1, 10))
    return allowed


def validate_model_comment(comment: dict[str, Any], contract: dict[str, Any]) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(comment, dict):
        return False, ["sortie locale non structurée"]

    required = ("reading", "caution", "limits")
    for key in required:
        value = comment.get(key)
        if not isinstance(value, str) or not value.strip():
            warnings.append(f"champ du commentaire absent : {key}")

    text = "\n".join(str(comment.get(key) or "") for key in required).strip()
    if len(text) > 1800:
        warnings.append("commentaire local trop long")

    lowered = text.lower()
    for pattern in FORBIDDEN_MODEL_PATTERNS:
        if re.search(pattern, lowered, flags=re.I | re.S):
            warnings.append(f"formulation interdite : {pattern}")

    allowed = allowed_number_tokens(contract)
    for token in re.findall(r"-?\d+(?:[.,]\d+)?", text):
        if token not in allowed and token.replace(",", ".") not in allowed:
            warnings.append(f"nombre non autorisé : {token}")

    return not warnings, warnings


def read_runtime_profile(profile: str) -> str:
    runtime_file = RUNTIME_PROFILE_FILES.get(profile)
    if not runtime_file or not runtime_file.exists():
        raise RuntimeError("Prompt runtime local manquant.")
    return runtime_file.read_text(encoding="utf-8")


def call_model_comment(
    config: dict[str, Any],
    provider_name: str,
    model: str,
    profile: str,
    mode: str,
    question: str,
    contract: dict[str, Any],
) -> dict[str, Any]:
    provider = config["providers"][provider_name]
    base = provider["base_url"].rstrip("/")
    timeout = int(provider.get("timeout_seconds", 120))
    temperature = float(config.get("generation", {}).get("temperature", 0.08))

    facts = model_comment_facts(contract, mode, question)

    system = (
        model_comment_profile(profile)
        + "\n\n"
        + MODEL_COMMENT_RULES
        + "\n\nLe rapport factuel est déjà construit par le Bridge."
        + "\nRéponds uniquement avec ce JSON : "
          '{"lecture":"...","prudence":"...","limites":"..."}'
    )

    user = (
        "Commente seulement cet état condensé. "
        "Ne reconstruis aucun fait et n’ajoute aucune information.\n\n"
        + json.dumps(facts, ensure_ascii=False, separators=(",", ":"))
    )

    if provider_name == "ollama":
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "format": "json",
            "options": {"temperature": temperature},
        }
        result = request_json(f"{base}/api/chat", payload, timeout)
        raw = str(result.get("message", {}).get("content", "") or "").strip()
    else:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "stream": False,
            "response_format": {"type": "json_object"},
        }
        result = request_json(f"{base}/chat/completions", payload, timeout)
        choices = result.get("choices") or []
        raw = str(
            choices[0].get("message", {}).get("content", "")
            if choices else ""
        ).strip()

    parsed = parse_model_comment(raw)
    if not parsed:
        return {
            "used": False,
            "warnings": ["commentaire local non structuré"],
            "comment": None,
        }

    valid, warnings = validate_model_comment(parsed, contract)
    return {
        "used": valid,
        "warnings": warnings,
        "comment": parsed if valid else None,
    }


def deterministic_comment(profile: str, mode: str) -> dict[str, str]:
    if profile == "aerith":
        return {
            "reading": (
                "Les sources convergent vers une lecture de prudence, mais elles décrivent "
                "un état présent et non une certitude sur la suite."
            ),
            "caution": (
                "Une variation ou une actualité isolée ne suffit pas à justifier une décision ; "
                "la cohérence des sources et leur fraîcheur doivent d’abord être confirmées."
            ),
            "limits": (
                "Le risque mesuré reste historique et partiel ; les dimensions de protocole, "
                "contrepartie, réglementation, exécution et données on-chain ne sont pas couvertes."
            ),
        }

    return {
        "reading": (
            "Le contrat factuel permet de comparer les sources, les horizons et "
            "les séries sans reconstruire les données."
        ),
        "caution": (
            "Toute conclusion qui dépasse les mesures présentes doit être rejetée "
            "ou classée à vérifier."
        ),
        "limits": (
            "Le rapport reste descriptif, en lecture seule, et ne couvre pas "
            "les risques absents du Math Core."
        ),
    }


def render_comment(comment: dict[str, str], profile: str) -> list[str]:
    name = "Aerith-10" if profile == "aerith" else "Atlas-10"
    return [
        f"- Lecture {name} : {comment['reading']}",
        f"- Prudence : {comment['caution']}",
        f"- Limites : {comment['limits']}",
    ]


def build_report(
    contract: dict[str, Any],
    profile: str,
    mode: str,
    comment: dict[str, str],
) -> str:
    sections: list[tuple[str, list[str]]]

    if mode == "top5":
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Target Top 5 canonique", deterministic_top5(contract)),
            ("3. Graphique lié au Top 5", deterministic_graph(contract)),
            ("4. Commentaire local borné", render_comment(comment, profile)),
            ("5. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("6. Stop point", deterministic_stop_point(contract)),
        ]
    elif mode == "math":
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Math Core — mesures réellement calculées", deterministic_math(contract)),
            ("3. Commentaire local borné", render_comment(comment, profile)),
            ("4. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("5. Stop point", deterministic_stop_point(contract)),
        ]
    elif mode == "contradictions":
        sections = [
            ("1. Verrous du contrat", [
                "- Top 5 canonique : BTC / ETH / BNB / XRP / SOL.",
                "- Aucun null transformé en zéro.",
                "- Aucune mesure Math absente inventée.",
                "- Aucune position visuelle du graphique interprétée comme tendance.",
                "- Aucune limite générale transformée en actualité.",
            ]),
            ("2. Contradictions détectées", deterministic_contradictions(contract)),
            ("3. Sources à vérifier", deterministic_sources(contract)),
            ("4. Commentaire local borné", render_comment(comment, profile)),
            ("5. Stop point", deterministic_stop_point(contract)),
        ]
    else:
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Lecture globale déterministe", deterministic_market(contract)),
            ("3. Target Top 5 canonique", deterministic_top5(contract)),
            ("4. Graphique", deterministic_graph(contract)),
            ("5. Math Core", deterministic_math(contract)),
            ("6. News Sentinel / Watchlist", deterministic_news(contract)),
            ("7. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("8. Commentaire local borné", render_comment(comment, profile)),
            ("9. Stop point", deterministic_stop_point(contract)),
        ]

    lines: list[str] = []
    for title, body in sections:
        lines.append(f"**{title}**")
        lines.append("")
        lines.extend(body)
        lines.append("")

    return "\n".join(lines).strip()


class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "AtlasCryptoBridge/1.7.5"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {self.address_string()} {fmt % args}")

    @property
    def config(self) -> dict[str, Any]:
        return self.server.config  # type: ignore[attr-defined]

    def allowed_origin(self) -> str:
        origin = self.headers.get("Origin", "")
        allowed = self.config.get("allowed_origins", [])
        if not origin:
            return ""
        if origin in allowed:
            return origin
        if any(
            origin.startswith(prefix)
            for prefix in allowed
            if prefix.startswith("http://127.0.0.1")
            or prefix.startswith("http://localhost")
        ):
            return origin
        return ""

    def send_json(self, status: int, payload: dict[str, Any]) -> bool:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            origin = self.allowed_origin()
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
            self.wfile.write(data)
            return True
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError):
            # Firefox peut annuler une ancienne requête lorsque le graphique
            # change. La réponse n'est plus utile ; le Bridge reste sain.
            return False

    def do_OPTIONS(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return
        self.send_json(204, {})

    def do_GET(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return

        parsed_url = urlparse(self.path)
        route = parsed_url.path

        if route == "/health":
            providers = {
                name: provider_status(self.config, name)
                for name in ("ollama", "lm_studio")
            }
            active = None
            model = None
            readiness_error = ""
            try:
                active, model = choose_provider(self.config)
            except Exception as exc:
                readiness_error = str(exc)

            required_model = str(
                self.config.get("providers", {})
                .get("ollama", {})
                .get("model") or "llama3.2"
            )
            model_ready = bool(active and model)

            self.send_json(200, {
                "ok": True,
                "ready": model_ready,
                "model_ready": model_ready,
                "required_model": required_model,
                "readiness_error": readiness_error,
                "service": "Atlas-10 Crypto Bridge Ryzen",
                "version": "1.7.5",
                "quality": "strict_contract_v2",
                "comment_prompt_policy": "sanitized_comment_v1",
                "forbidden_control_terms_sent_to_model": False,
                "time": utc_now(),
                "read_only": True,
                "history_proxy_read_only": True,
                "history_route": "/history",
                "scanner_collector_route": "/scanner-snapshot",
                "scanner_status_route": "/scanner-status",
                "scanner_latest_route": "/scanner-latest",
                "scanner_history_route": "/scanner-history",
                "aerith_conclusion_route": "/conclusion",
                "github_publication_route": "/publish-synthesis",
                "github_publication": {
                    "configured": bool(load_github_token()),
                    "repository": GITHUB_PUBLISH_REPOSITORY,
                    "path": GITHUB_PUBLISH_PATH,
                    "pages_url": GITHUB_PUBLISH_PAGES_URL,
                    "write_scope": "single_file_only",
                },
                "local_observation_storage": True,
                "provider": active,
                "model": model,
                "providers": providers,
                "profiles": profile_health(),
                "actions": {
                    "exchange": False,
                    "wallet": False,
                    "github": False,
                    "github_publication_single_file": True,
                    "ui": False,
                },
            })
            return

        if route == "/profiles":
            self.send_json(200, {
                "ok": True,
                "quality": "strict_contract_v2",
                "profiles": profile_health(),
            })
            return

        if route == "/history":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                coin_id = str((query.get("coin_id") or [""])[0]).strip().lower()
                symbol = str((query.get("symbol") or [""])[0]).strip().upper()
                days_raw = str((query.get("days") or ["1"])[0]).strip()
                if not re.fullmatch(r"[a-z0-9-]{1,80}", coin_id):
                    raise ValueError("coin_id invalide.")
                if not re.fullmatch(r"[A-Z0-9]{2,15}", symbol):
                    raise ValueError("symbol invalide.")
                try:
                    days = int(days_raw)
                except ValueError as exc:
                    raise ValueError("days invalide.") from exc
                if days not in HISTORY_PERIODS:
                    raise ValueError("Période autorisée : 1, 7, 30, 60, 90, 365 ou 36500 jours.")
                allow_binance_raw = str((query.get("allow_binance") or ["1"])[0]).strip().lower()
                allow_binance = allow_binance_raw not in {"0", "false", "no"}
                payload = fetch_history_singleflight(
                    self.config, coin_id, symbol, days, allow_binance
                )
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc), "read_only": True})
            except Exception as exc:
                self.send_json(503, {
                    "ok": False,
                    "error": str(exc),
                    "attempts": list(getattr(exc, "attempts", [])),
                    "read_only": True,
                    "bridge_version": "1.7.5",
                })
            else:
                self.send_json(200, payload)
            return

        if route == "/scanner-latest":
            latest = scanner_read_latest()
            self.send_json(200, {
                "ok": True,
                "bridge_version": "1.7.5",
                "schema": SCANNER_SCHEMA,
                "available": latest is not None,
                "snapshot": latest,
                "read_only_external": True,
                "local_observation_storage": True,
            })
            return

        if route == "/scanner-status":
            self.send_json(200, scanner_status(self.config))
            return

        if route == "/scanner-history":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                basket = str((query.get("basket") or ["top5"])[0]).strip().lower()
                limit_raw = str((query.get("limit") or ["120"])[0]).strip()
                limit = int(limit_raw)
                rows = scanner_history(self.config, basket, limit)
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": "1.7.5",
                    "schema": SCANNER_SCHEMA,
                    "basket": basket,
                    "count": len(rows),
                    "rows": rows,
                    "read_only_external": True,
                })
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc)})
            except Exception as exc:
                self.send_json(503, {"ok": False, "error": str(exc)})
            return

        self.send_json(404, {"ok": False, "error": "Route inconnue."})

    def read_body(self, max_bytes: int | None = None) -> dict[str, Any]:
        raw_length = self.headers.get("Content-Length", "0")
        length = int(raw_length)
        max_snapshot = int(
            self.config.get("generation", {})
            .get("max_snapshot_chars", 250000)
        )
        limit = int(max_bytes) if max_bytes is not None else max_snapshot + 20000
        if length <= 0 or length > limit:
            raise ValueError("Corps vide ou trop volumineux.")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def do_POST(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return

        if self.path not in {"/chat", "/summary", "/conclusion", "/scanner-snapshot", "/publish-synthesis"}:
            self.send_json(404, {"ok": False, "error": "Route inconnue."})
            return

        try:
            if self.path == "/publish-synthesis":
                publication = github_publication_config(self.config)
                body = self.read_body(max_bytes=publication["max_bytes"] + 65536)
                result = publish_synthesis_to_github(body, self.config)
                self.send_json(200, {
                    **result,
                    "bridge_version": "1.7.5",
                    "write_scope": "single_file_only",
                    "exchange_actions": False,
                    "wallet_actions": False,
                })
                return

            body = self.read_body()

            if self.path == "/scanner-snapshot":
                snapshot = scanner_validate_snapshot(body)
                snapshot = scanner_enrich_snapshot(snapshot, self.config)
                stored = scanner_persist_snapshot(snapshot, self.config)
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": "1.7.5",
                    "schema": SCANNER_SCHEMA,
                    "snapshot_id": snapshot.get("snapshot_id"),
                    "collected_at": snapshot.get("collected_at"),
                    "duplicate": stored.get("duplicate", False),
                    "storage_path": stored.get("path"),
                    "binance_enrichment": snapshot.get("binance_enrichment"),
                    "snapshot": snapshot,
                    "read_only_external": True,
                    "local_observation_storage": True,
                })
                return

            profile = str(body.get("profile") or "atlas").strip().lower()
            if profile not in RUNTIME_PROFILE_FILES:
                raise ValueError("Profil autorisé : atlas ou aerith.")

            snapshot = body.get("snapshot")
            if not isinstance(snapshot, dict):
                raise ValueError("Le snapshot Agent-Crypto doit être un objet JSON.")

            contract = validate_contract(snapshot)
            provider_name, model = choose_provider(self.config)

            if self.path == "/conclusion":
                if profile != "aerith":
                    raise ValueError("La conclusion finale utilise uniquement le profil Aerith-10.")
                report_modes = body.get("report_modes") or []
                if report_modes != ["market", "top5", "math", "contradictions"]:
                    raise ValueError("Les quatre rapports Atlas-10 validés sont requis dans l’ordre canonique.")
                model_result = call_model_comment(
                    self.config,
                    provider_name,
                    model,
                    "aerith",
                    "chat",
                    "Produire une conclusion prudente après les quatre rapports Atlas-10 validés.",
                    contract,
                )
                if model_result["used"]:
                    candidate = model_result["comment"]
                    concrete_ok, concrete_warnings = validate_aerith_concrete_comment(candidate, contract)
                    if concrete_ok:
                        comment = candidate
                        model_comment_used = True
                        warnings: list[str] = []
                    else:
                        comment = aerith_concrete_limits_comment(contract)
                        model_comment_used = False
                        warnings = list(model_result.get("warnings") or []) + concrete_warnings
                else:
                    comment = aerith_concrete_limits_comment(contract)
                    model_comment_used = False
                    warnings = model_result["warnings"]
                answer = build_aerith_conclusion(contract, comment)
                self.send_json(200, {
                    "ok": True,
                    "profile": "aerith",
                    "provider": provider_name,
                    "model": model,
                    "time": utc_now(),
                    "quality": "strict_contract_v2",
                    "model_comment_used": model_comment_used,
                    "validation_warnings": warnings,
                    "answer": answer,
                    "source_reports": 4,
                    "report_fingerprint": str(body.get("report_fingerprint") or ""),
                    "read_only": True,
                })
                return

            if self.path == "/summary":
                mode = str(body.get("mode") or "market").strip().lower()
                if mode not in {"market", "top5", "math", "contradictions"}:
                    raise ValueError(
                        "Mode autorisé : market, top5, math ou contradictions."
                    )
                question = MODE_LABELS[mode]
            else:
                mode = "chat"
                question = str(body.get("question") or "").strip()
                max_question = int(
                    self.config.get("generation", {})
                    .get("max_question_chars", 4000)
                )
                if not question or len(question) > max_question:
                    raise ValueError("Question vide ou trop longue.")

            model_result = call_model_comment(
                self.config,
                provider_name,
                model,
                profile,
                mode,
                question,
                contract,
            )

            if model_result["used"]:
                comment = model_result["comment"]
                model_comment_used = True
                warnings: list[str] = []
            else:
                comment = deterministic_comment(profile, mode)
                model_comment_used = False
                warnings = model_result["warnings"]

            report_mode = "market" if mode == "chat" else mode
            answer = build_report(
                contract,
                profile,
                report_mode,
                comment,
            )

            self.send_json(200, {
                "ok": True,
                "profile": profile,
                "provider": provider_name,
                "model": model,
                "time": utc_now(),
                "quality": "strict_contract_v2",
                "model_comment_used": model_comment_used,
                "validation_warnings": warnings,
                "answer": answer,
                "read_only": True,
            })

        except ValueError as exc:
            self.send_json(400, {"ok": False, "error": str(exc)})
        except Exception as exc:
            self.send_json(503, {"ok": False, "error": str(exc)})


class BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        handler: type[BaseHTTPRequestHandler],
        config: dict[str, Any],
    ) -> None:
        super().__init__(address, handler)
        self.config = config


def self_test() -> int:
    config = load_config()
    profiles = profile_health()

    assert config["host"] in {"127.0.0.1", "localhost"}
    assert all(item["loaded"] for item in profiles.values()), profiles
    assert (
        config.get("strict_contract", {}).get("required_schema")
        == "atlas_crypto_fact_contract_v2"
    )

    sample = {
        "strict_contract": {
            "schema": "atlas_crypto_fact_contract_v2",
            "rules": {
                "market_list_is_not_portfolio": True,
                "no_missing_value_to_zero": True,
                "no_visual_position_inference": True,
                "no_unlisted_math_measure": True,
                "no_news_from_generic_limit": True,
                "no_financial_instruction": True,
            },
            "canonical_top5": {
                "symbols": ["BTC", "ETH", "BNB", "XRP", "SOL"],
                "complete": False,
                "assets": [],
            },
        }
    }
    validate_contract(sample)
    sample_contract = sample["strict_contract"]
    sample_contract.update({
        "sources": {
            "binance": {"feed_status": "ready", "source": "Binance WebSocket", "direct_pairs": 5, "derived_pairs": 0},
            "coingecko": {"status": "ready", "mode": "direct", "timestamp": utc_now()},
        },
        "market": {"assets_loaded": 250, "target_assets": 250, "breadth_24h": {"positive": 40, "negative": 200, "stable": 10, "classification": "largeur négative", "basis": "Variations 24 h"}},
        "graph": {"truth_label": "Historique en cache retardé", "freshness": "delayed"},
        "math": {"risk_global": "Partiel", "limitation": "mesures historiques seulement"},
        "news": {"status": "ready"},
        "watchlist": {"configured_count": 34},
        "contradictions": [{"level": "à vérifier", "text": "Historique non direct"}],
        "stop_point": {"meaning": "Arrêter lorsque les données ne soutiennent plus une conclusion."},
    })
    sample_contract["canonical_top5"]["complete"] = True
    sample_contract["canonical_top5"]["assets"] = [
        {"available": True, "symbol": symbol, "change_24h_pct": change}
        for symbol, change in zip(["BTC", "ETH", "BNB", "XRP", "SOL"], [-1.0, -2.0, 0.5, -3.0, -2.5])
    ]
    concrete_comment = aerith_concrete_limits_comment(sample_contract)
    conclusion = build_aerith_conclusion(sample_contract, concrete_comment)
    assert "Situation générale" in conclusion and "Limites et stop point" in conclusion
    assert "pas son évolution future" in conclusion
    assert "signal d’exécution" in conclusion

    generic_comment = {
        "reading": "Analyser l’état du marché et des sources.",
        "caution": "Évaluer la qualité des données et la fiabilité des informations.",
        "limits": "Utiliser uniquement les informations fournies, sans ajout ou modification.",
    }
    generic_valid, generic_warnings = validate_aerith_concrete_comment(generic_comment, sample_contract)
    assert generic_valid is False and generic_warnings

    bad_comment = {
        "reading": "Votre portefeuille suit un ratio de Sharpe de 2.",
        "caution": "Acheter demain.",
        "limits": "Stop point dans 30 jours.",
    }
    valid, warnings = validate_model_comment(
        bad_comment,
        sample["strict_contract"],
    )
    assert valid is False and warnings

    print("Configuration : OK")
    print("Profils Atlas/Aerith : OK")
    print("Contrat factuel V2 : OK")
    print("Filtre anti-invention : OK")
    assert set(HISTORY_PERIODS) == {1, 7, 30, 60, 90, 365, 36500}
    assert config.get("history_proxy", {}).get("enabled", True) is True
    print("Proxy historique local : OK")

    sample_scanner = {
        "schema": SCANNER_SCHEMA,
        "snapshot_id": "self-test_2026-07-28-15-30",
        "collector_id": "self-test",
        "collected_at": utc_now(),
        "market": {"source": "CoinGecko", "mode": "direct", "status": "ready", "assets_loaded": 237, "target_assets": 250, "quote_currency": "EUR"},
        "exchange_feed": {"source": "Binance WebSocket", "status": "ready", "direct_pairs": 5, "derived_pairs": 0},
        "baskets": {
            key: {
                "id": key,
                "label": key,
                "ranking_source": "CoinGecko Market Snapshot",
                "ranking_metric": "change_24h_pct" if key != "volume" else "volume_24h_eur",
                "assets": [{
                    "coin_id": "bitcoin",
                    "symbol": "BTC",
                    "name": "Bitcoin",
                    "market_rank": 1,
                    "scanner_rank": 1,
                    "classification_value": 1.0,
                    "market_price_eur": 50000,
                    "observed_price_eur": 50000,
                    "observed_source": "Binance BTCEUR WebSocket",
                    "observed_status": "live",
                    "binance_symbol_candidate": "BTC",
                    "binance_candidate_allowed": True,
                }],
            }
            for key in SCANNER_BASKETS
        },
    }
    validated_scanner = scanner_validate_snapshot(sample_scanner)
    assert validated_scanner["schema"] == SCANNER_SCHEMA
    assert all(validated_scanner["baskets"][key]["assets"] for key in SCANNER_BASKETS)
    print("Scanner Live Collector : OK")
    sample_publish = {
        "schema": GITHUB_PUBLISH_REQUEST_SCHEMA,
        "synthesis": {
            "schema": GITHUB_PUBLISH_SYNTHESIS_SCHEMA,
            "fingerprint": "self-test-fingerprint",
            "snapshot_label": "self-test",
            "reports": {mode: {"answer": "rapport"} for mode in GITHUB_PUBLISH_REPORT_MODES},
            "conclusion": {"answer": "conclusion"},
        },
    }
    validated_publish = validate_publish_request(sample_publish, config)
    assert validated_publish["publication"]["repository_path"] == GITHUB_PUBLISH_PATH
    assert github_publication_config(config)["repository"] == GITHUB_PUBLISH_REPOSITORY
    print("Publication GitHub bornée à un fichier : OK")
    print("Conclusion Aerith-10 Crypto : OK")
    print("Mode observation locale · publication externe bornée : OK")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--configure-github", action="store_true")
    parser.add_argument("--remove-github", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return self_test()
    if args.configure_github:
        return configure_github_publication()
    if args.remove_github:
        return remove_github_publication()

    config = load_config()
    host = config.get("host", "127.0.0.1")
    port = int(config.get("port", 8787))
    PID_PATH.write_text(str(os.getpid()), encoding="ascii")

    server = BridgeServer((host, port), BridgeHandler, config)

    def shutdown_handler(signum: int, frame: Any) -> None:
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown_handler)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, shutdown_handler)

    print("=" * 70)
    print("ATLAS-10 CRYPTO BRIDGE RYZEN V1.7.5")
    print(f"Adresse : http://{host}:{port}")
    print("Modèle : Ollama llama3.2")
    print("Qualité : contrat factuel déterministe V2 · commentaire assaini")
    print("Mode : observation locale · publication GitHub bornée à un fichier")
    print("=" * 70)

    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        server.server_close()
        try:
            PID_PATH.unlink(missing_ok=True)
        except Exception:
            pass
        print("Bridge arrêté.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
