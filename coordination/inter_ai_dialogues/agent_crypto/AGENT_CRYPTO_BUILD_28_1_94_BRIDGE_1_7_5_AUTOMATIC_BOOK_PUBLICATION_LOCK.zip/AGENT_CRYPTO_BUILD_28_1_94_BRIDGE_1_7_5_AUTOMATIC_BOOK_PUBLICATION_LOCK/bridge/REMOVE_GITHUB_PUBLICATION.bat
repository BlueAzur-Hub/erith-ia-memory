@echo off
setlocal
cd /d "%~dp0"
title Suppression GitHub Publication Agent-Crypto
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 bridge.py --remove-github
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python bridge.py --remove-github
  goto :end
)
echo Python 3 est introuvable.
:end
pause
endlocal
