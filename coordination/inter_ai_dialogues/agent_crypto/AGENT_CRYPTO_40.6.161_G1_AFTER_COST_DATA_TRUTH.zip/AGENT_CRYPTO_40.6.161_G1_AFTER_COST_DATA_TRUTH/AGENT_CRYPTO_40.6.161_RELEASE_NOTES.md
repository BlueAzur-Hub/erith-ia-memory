# Agent-Crypto 40.6.161 — Strategy A G1 After-Cost Data Truth

## Objet
Exposer, en lecture strictement passive, les faits déjà calculés par l'Evidence Dossier sur le dataset after-cost de Strategy A.

## Ajout visible
Le bloc `G1 · AFTER-COST DATA TRUTH` affiche :
- lignes after-cost ;
- IDs uniques ;
- lignes COMPLETE + VERIFIED ;
- IDs manquants ;
- timestamps manquants ;
- doublons ;
- chronologie ;
- valeurs numériques UNKNOWN ;
- lignes non VERIFIED ;
- état d'intégrité du dataset ;
- raison descriptive.

## Garde-fous
- G1 reste `EVIDENCE_REQUIRED` ; aucun PASS n'est créé par cette vue.
- Aucun seuil Strategy A modifié.
- Aucun lifecycle ou Risk modifié.
- Aucun ordre réel, wallet, credential ou action exchange.
- Market Core 38.15.11, Web Classique, Aether, Atlas CURRENT, Oracle, Lecture Technique et TRADUS inchangés.
- Aucun nouveau timer, observer ou propriétaire de stockage.

## Preuves
- Syntaxe JavaScript : PASS.
- Tests statiques datasetReadiness : PASS.
- Publication GitHub : vérifiée.
- Firefox terrain : PENDING — doit être contrôlé par l'opérateur avant de verrouiller la preuve visuelle/runtime.

## Commits
- Runtime G1 truth : `b971e06b80468f0a395540ca6087a9878c9948d7`
- Release immuable 40.6.161 : `31c9d1458655c7f574fac9d0fc500a3b3694dccc`
- Promotion build.json : `937eea075d0738c026a40b7bf04aae95111460ef`
