# Prepared next stages — NOT PUSHED

## 40.6.500 — EXECUTION VENUE COMPARATOR

BTC-EUR V6 gate is now COMPLETE (2026-10-02):
- 50 valid attempts;
- 21 full fills / 29 no-fill;
- 42.0% fill-any;
- median fill latency 20.478 s;
- markouts complete through +900 s.

40.6.500 remains intentionally BLOCKED on the matched comparison inputs:
- V6-B BTC-USDC final JSON using the same ~10 quote-unit ticket, 60 s timeout and +1/+5/+15/+30/+60/+300/+900 s markouts;
- current OKX EEA instrument discovery (post-2026-09-30 API IDs use Crypto-USDC for migrated USD books);
- return-to-EUR conversion cost measured separately.

Prepared auxiliary evidence pack:
- `ERITH_OKX_DEMO_V6B_BTC_USDC_PREP.zip`;
- separate Demo bridge V3 on port 8792, strict BTC-EUR/BTC-USDC allowlist;
- does not disturb known-good Bridge V2 on 8791;
- not to be run or pushed until operator validation.

Comparator metrics, descriptive only:
spread, ±5/±25bp depth, fee, fill CDF, no-fill, partial fill, markout, fill-vs-no-fill adverse-selection delta, conversion-to-EUR cost.
No automatic venue winner is encoded.

## 40.6.501 — STRATEGY A2 EVIDENCE LAB

Still blocked intentionally until .500 matched evidence exists.
Strategy A V1 remains FAIL_BENCHMARK_FROZEN.
No legacy threshold reduction. No promotion of Demo fill probability to live truth.
