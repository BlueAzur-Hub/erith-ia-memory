# Cascade 40.6.497 → 40.6.499 — test contract

## 40.6.497
- default display = EUR;
- switching EUR/USD never mutates executionInstrument = BTC-EUR;
- settlementAsset remains EUR;
- no network, storage, timer, observer;
- no recognized `data-chart-view` control is added (protected Graph Context V7 remains owner).

## 40.6.498
- candle canvas is separate from `#mainChart`;
- existing Prix/Base100 control attributes are untouched;
- network is demand-only after explicit `Bougies` click;
- true OHLC is required; no OHLC is synthesized from close-only history;
- OKX EEA candles; USD display maps microscope API instrument to Crypto-USDC after the Sep 30 migration;
- no polling timer/storage/Strategy A/Market Core mutation.

## 40.6.499
- public production EEA WebSocket opens only after `Profondeur` click;
- closes when panel is hidden;
- bbo-tbt + books-rpi + public trades only;
- no authentication, order, wallet, transfer or withdrawal route;
- no persistent storage; no recurring timer;
- depth is explicitly not treated as exact queue position.
