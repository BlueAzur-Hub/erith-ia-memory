# OKX Demo V6 BTC-EUR — completed evidence gate

Source: operator V6.2 log, 2026-10-02.

## Orders
- valid attempts: 50
- full fills: 21
- partial fills: 0
- no-fill: 29
- fill-any rate: 42.0%
- median fill latency: 20.478 s
- fill CDF: <=5s 2%, <=10s 10%, <=20s 18%, <=30s 28%, <=60s 42%

## Markout / fill-vs-no-fill median
- +1s: delta +0.0000647%; fill->mid -0.0308163%
- +5s: delta +0.0093492%; fill->mid -0.0203307%
- +15s: delta +0.0102553%; fill->mid -0.0077114%
- +30s: delta +0.0309698%; fill->mid -0.0079894%
- +60s: delta +0.0175083%; fill->mid -0.0021444%
- +300s: delta +0.0803492%; fill->mid +0.0565792%
- +900s: delta +0.0471349%; fill->mid -0.0439743%

Interpretation guard:
- this is Demo BTC-EUR evidence, not live fill probability;
- it does not authorize Strategy A2 or threshold changes;
- it unlocks preparation of a matched BTC-USDC campaign only;
- 40.6.500 remains blocked until matched BTC-USDC evidence plus return-to-EUR conversion cost exist.
