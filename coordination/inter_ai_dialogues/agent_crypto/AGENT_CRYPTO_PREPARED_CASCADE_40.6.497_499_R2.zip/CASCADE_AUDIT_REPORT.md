# Cascade audit report — 40.6.497 → 40.6.499

Status: **PREPARED LOCALLY / NOT PUSHED**
Baseline: **40.6.496**
Market Core: **38.15.11 protected**

## Code-owner audit
- canonical `administrator/app.js`: intentionally untouched;
- canonical `#mainChart`: intentionally untouched by .497 and overlaid, not rewritten, by .498/.499;
- canonical graph view controls `Prix` + `Base 100`: remain exactly two in prepared indexes;
- Strategy A OKX evidence owner stays pinned to `40.6.496` in post-boot loader.

## 40.6.497
- new isolated owner: `quote-currency-architecture-406497.js`;
- EUR default; USD presentation available;
- `executionInstrument=BTC-EUR` and `settlementAsset=EUR` remain unchanged;
- uses existing EUR+USD spot values already present in current app state;
- no fetch/storage/timer/observer;
- static self-test PASS.

## 40.6.498
- cumulative .497 + `market-microscope-candles-406498.js`;
- separate canvas overlay; `#mainChart` sentinel remains unchanged in browser tests;
- true OHLC parsing + volume + MA5/10/20 + crosshair;
- bars 1m/5m/15m/1H/4H/1Dutc;
- OKX EEA REST only after operator opens `Bougies`; no polling timer;
- USD presentation maps microscope public data to `Crypto-USDC` API ID after current OKX migration;
- static self-test PASS.

## 40.6.499
- cumulative .497/.498 + `market-microstructure-406499.js`;
- no WebSocket at boot;
- when `Profondeur` is opened: public EEA `bbo-tbt + books + books-rpi + trades`;
- organic and consolidated/RPI depth are stored and displayed separately;
- RPI-at-bid derived from `totalQty - nonRpiQty` only;
- seq/gap diagnostics present;
- closing panel releases socket;
- no auth/private channel/order/wallet/storage/timer/observer;
- static self-test PASS.

## Browser testing already performed
1. Styled synthetic visual harness with mocked OKX public data:
   - .497 PASS;
   - .498 PASS;
   - .499 PASS;
   - no page errors;
   - no localStorage writes;
   - protected `#mainChart` sentinel unchanged.
2. Actual 40.6.496 DOM integration harness (canonical index HTML, scripts/network disabled, controlled app-state stub):
   - selectors mount correctly on current `.496` DOM;
   - `data-chart-view` count remains 2;
   - .498 separate canvas exists and `#mainChart` dimensions/style are not rewritten by module;
   - .499 proves boot socket false, both books + RPI data parsing, close-to-idle.

These are **pre-push tests**, not Firefox/GitHub-Pages terrain proof. Live CORS and production public WS origin acceptance remain terrain gates for .498/.499.

## Push discipline on return
Push exactly one version, wait CI/Pages, test in Firefox, then continue. Any terrain failure stops the cascade and rolls back to the last validated version.

## Re-audit after V6 completion
- Node syntax re-check PASS for .497/.498/.499 modules.
- Synthetic browser matrix re-run PASS.
- Actual 40.6.496 DOM integration re-run PASS.
- Current GitHub `main` Administrator baseline still resolves to build 40.6.496 and the same index/build/loader/app blob SHAs used for staging; the later repository commit did not alter these Administrator baseline files.
- BTC-EUR V6 is now complete; .500 is blocked only by matched BTC-USDC + return-to-EUR evidence, not by BTC-EUR.
