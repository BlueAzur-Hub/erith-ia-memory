# Push plan — owner validation required

Nothing in this staging pack has been pushed.

When Christophe returns, push and validate one cumulative version at a time:

1. 40.6.497 — add `js/quote-currency-architecture-406497.js`, load it after canonical `app.js`, bump build truth, static guard, Firefox terrain proof, ZIP.
2. 40.6.498 — keep .497; add `js/market-microscope-candles-406498.js`, bump build truth, guard separate canvas + no mainChart mutation, Firefox visual proof, ZIP.
3. 40.6.499 — keep .497/.498; add `js/market-microstructure-406499.js`, bump build truth, guard demand-only WebSocket + no auth/order route, Firefox visual proof, ZIP.
4. Stop. Do not implement .500/.501 until V6 evidence gate is satisfied.

Rollback rule: each version remains a complete stable predecessor. No destructive rewrite of canonical app.js is planned for .497-.499.
