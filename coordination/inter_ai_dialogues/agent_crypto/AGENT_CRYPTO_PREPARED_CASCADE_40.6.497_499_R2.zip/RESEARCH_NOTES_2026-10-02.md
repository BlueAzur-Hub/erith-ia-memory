# Research notes — 2026-10-02

## Existing Agent-Crypto owner audit
- canonical graph owner is current root `administrator/app.js` (Git blob `3507514b8a90366a7ca1b5d86e5cf3f700be31ab`);
- current graph uses Chart.js and `#mainChart` with a historical-canvas purity lock;
- comparison is canonical Base 100; single view supports Prix / Base100, Normal / Log, volume/legend/analysis/oracle;
- current `app.js` already stores direct CoinGecko EUR and USD spot quotes (`spotBook.quotes[id].eur/.usd`) and propagates `coin.priceEur` + `coin.priceUsd`;
- current runtime emits `agentcrypto:current-finalized`; the new quote module listens to this event plus direct operator click capture, without a timer or MutationObserver;
- therefore 40.6.497 does not need a new market-data network owner.

## Design decision
Do not edit canonical `app.js` in .497-.499. Add isolated late augmentation modules after app.js. This protects Graph Context V7, Chart.js historical geometry, Lecture Technique, Oracle and Market Core 38.15.11.

## OKX current facts used in design
Official sources checked 2026-10-02:
- EEA API overview: https://my.okx.com/docs-v5/
- API changelog: https://my.okx.com/docs-v5/log_en/
- USD/USDC consolidation: https://www.okx.com/en-eu/help/okx-is-consolidating-usd-and-usdc-spot-order-books-effective-september-30-2026
- USDⓢ migration: https://www.okx.com/en-eu/help/okx-to-migrate-usds-spot-trading-pairs
- unified USD orderbook explanation: https://www.okx.com/en-eu/help/how-do-i-trade-a-usd-pair-using-usdc-or-another-stablecoin

Facts:
- EEA REST domain: `https://eea.okx.com`.
- Candles: `GET /api/v5/market/candles`; response rows `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`; request `limit` max 300, current endpoint can retrieve recent history with pagination; staging requests 240 only.
- supported bars used by staging: 1m/5m/15m/1H/4H/1Dutc. UTC suffix becomes relevant on the documented 6H+ daily/weekly/monthly families; 1H/4H are canonical bar IDs.
- EEA production public WebSocket on port 443: `wss://wseea.okx.com/ws/v5/public`. OKX announced port 8443 retirement for 2026-10-31; port 443 already works.
- `bbo-tbt` publishes BBO snapshots up to 10 ms cadence when changed; `books` incremental depth every 100 ms.
- `books-rpi` public channel exposes consolidated depth `[price,totalQty,nonRpiQty,count]`, up to 400 levels, 100 ms updates, sequence via `seqId/prevSeqId`.
- .499 deliberately subscribes BOTH `books` and `books-rpi`; organic and consolidated/RPI depth stay separate. Depth is never labeled as exact queue position.
- after the 2026-09-30 USD orderbook migration, affected API clients must use corresponding `Crypto-USDC` instrument IDs even when web/app displays the unified market as Crypto-USD / Crypto-USDⓢ.

## Deliberate evidence gates
- .500 is blocked until matched BTC-EUR and BTC-USDC V6 datasets exist.
- .501 is blocked until .500 comparison evidence exists.
