# Return checklist

Do not jump directly to .499.

1. Inspect V6.2 status/report separately; it does not block .497-.499 UI staging.
2. Re-fetch GitHub `main` and compare to commit `2d387744fcec449a8bce46c8249431d891b1ffe2` / current head. If main drifted, reconcile before push.
3. Push **40.6.497 only** → CI/Pages → Firefox terrain proof → ZIP/commit proof.
4. If PASS, push **40.6.498** → Firefox test `Bougies` in EUR and USDⓢ → close/reopen graph → proof.
5. If PASS, push **40.6.499** → prove no socket at boot → open Profondeur → validate BBO/books/books-rpi/trades → close → prove release.
6. Stop. `.500` remains blocked until V6 BTC-EUR final + matched BTC-USDC V6-B exist.
7. `.501` remains blocked until `.500` comparison evidence exists.
