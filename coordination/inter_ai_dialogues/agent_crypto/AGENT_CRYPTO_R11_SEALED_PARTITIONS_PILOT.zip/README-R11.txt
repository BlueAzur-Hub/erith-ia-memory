SEVEN HEAVEN — R11 · PILOTE PARTITIONS HORODATÉES (LECTURE SEULE)
8 octobre 2026

Aucun remplacement du Coffre R10, des bougies ni du collecteur horaire.

Livraison :
- tools/build_historical_partitions_r11.py
- .github/workflows/agent-crypto-historical-partitions-r11.yml
- coordination/inter_ai_dialogues/agent_crypto/R11_SEALED_PARTITIONS_PILOT.md

Exécutions locales facultatives :
python public/agent_crypto_erith_ia/tools/build_historical_partitions_r11.py --self-test
python public/agent_crypto_erith_ia/tools/build_historical_partitions_r11.py --plan
python public/agent_crypto_erith_ia/tools/build_historical_partitions_r11.py --build --target /tmp/partitions_r11
python public/agent_crypto_erith_ia/tools/build_historical_partitions_r11.py --verify --target /tmp/partitions_r11

Attention : le dossier temporaire n'est pas le Coffre public et n'est PAS une publication automatique.
