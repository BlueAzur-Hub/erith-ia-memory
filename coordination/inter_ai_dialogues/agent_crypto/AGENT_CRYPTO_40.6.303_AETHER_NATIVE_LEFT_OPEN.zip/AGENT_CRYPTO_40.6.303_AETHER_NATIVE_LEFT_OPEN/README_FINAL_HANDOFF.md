# AGENT-CRYPTO 40.6.303 — AETHER NATIVE LEFT OPEN RESTORE

Cette livraison correspond à la correction bornée issue de la relecture du Fil Crypto,
des 50 dernières versions retenues et du code courant.

**Commit main :** `355eb51a3ae877b812c33004e0699256531af25d`

Le ZIP contient :
- la correction fonctionnelle sous forme de patch ;
- la preuve de livraison ;
- la synthèse de l'audit ;
- l'extrait source des 50 versions ;
- la capture terrain `.302` montrant l'échec centré.

La version `.303` reste **PENDING_FIREFOX**.
Aucune réussite terrain n'est déclarée avant la preuve de Christophe.
