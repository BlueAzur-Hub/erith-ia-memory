# Audit 50 versions → cause de `.302` → correction `.303`

## Périmètre réellement relu

Le Fil Crypto a été retraité sur les **50 versions uniques 40.6.252 → 40.6.302**
(`40.6.294` n'apparaît pas comme entrée de version distincte dans l'extrait retenu).
Le fichier `LAST_50_VERSION_THREAD_EXTRACT.txt` joint conserve les passages source
associés à chacune de ces versions.

## Constat structurel

Les 50 versions montrent plusieurs cycles différents qui ont été mélangés :
Decision Intelligence / stabilité Firefox, boot-performance, Storage, puis récupération Aether.
Pour Aether, la chaîne importante est :

- `.273` : checkpoint historique pré-régression `.284`.
- `.284` : bascule Consultation First / changement de cycle de vie.
- `.290–.293` : tentatives de restauration Aether.
- `.293` : contient un geste utile précis : lors d'une ouverture opérateur,
  si `aether-watch` n'est plus flottante, le code appelle le **Window Manager existant**
  pour la repasser flottante.
- `.296–.298` : couches de récupération entrée/F11/géométrie.
- `.299` : correction de latence interaction, conservée.
- `.300` : restauration « golden » depuis `.273`; elle retire aussi le geste utile
  de `.293` en restaurant `aether.js` au checkpoint.
- `.301` : restaure le cycle fonctionnel Aether pré-`.284`.
- `.302` : force `x=12` dans l'état persisté, mais ne remet pas Aether en état flottant.
  Terrain Firefox fourni par Christophe : **FAIL, fenêtre centrée**.

## Cause relue dans le code courant

Le Window Manager contient explicitement :

`if (win.floating) setFloating(win, false, false);`

dans le chemin `hide()`.

Donc fermer Aether peut laisser son état `floating=false`.

Or avant `.303`, l'ouverture Aether faisait seulement :

`hide(false) → minimize(false) → focus()`

Elle **ne repassait pas la fenêtre en flottant**.

Dans cet état docké, le vieux CSS portail contient toujours :

`left:50%!important`
`transform:translate(-50%,-50%)!important`

Le `x=12` écrit par `.302` existe alors dans la donnée, mais il n'est pas le propriétaire
de la géométrie effectivement rendue.

Le Window Manager, lui, sait déjà faire correctement la fenêtre gauche :
pour une fenêtre `directFixed` flottante il écrit `left/top/width/height` inline avec
`!important`, et la définition Aether conserve `preferredFloatGeometry.x = 12`.

## Pourquoi `.303` est bornée

`.303` ne crée aucun propriétaire.

Elle rétablit uniquement le geste déjà présent dans `.293` :

```js
const nativeWindow=manager.getWindow?.('aether-watch');
if(nativeWindow && nativeWindow.floating!==true)manager.float('aether-watch',true);
```

Le propriétaire reste `ErithAdministratorWindows`.

Aucun CSS n'est ajouté.
Aucune réécriture du Window Manager.
Aucune nouvelle logique F11/resize.
Aucun nouveau timer/observer.
Aucun changement Storage/Strategy/Market Core.

## Gate terrain obligatoire

Ne pas appeler `.303` « validée » avant Firefox :

1. attendre **Build 40.6.303** ;
2. F5 ;
3. ouvrir Aether ;
4. vérifier **GAUCHE x≈12** ;
5. drag ;
6. free resize ;
7. F11 ;
8. sortie F11 ;
9. maximize/restore ;
10. close/reopen ;
11. F5/reopen.

Un seul FAIL = STOP.
