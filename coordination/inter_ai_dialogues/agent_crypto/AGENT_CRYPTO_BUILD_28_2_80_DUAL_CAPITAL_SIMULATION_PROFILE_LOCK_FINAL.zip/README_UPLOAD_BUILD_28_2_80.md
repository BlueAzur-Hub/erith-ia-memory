# Upload Build 28.2.80 — DUAL CAPITAL SIMULATION PROFILE LOCK

## Base

Build 28.2.80 supersedes Build 28.2.79 and contains all of its additive pedagogy and transaction-proof functions.

## Replace these four files

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

## Important behavior

- Default simulation profile: **Solo Progression 1 000 €**.
- Preserved selectable profile: **Solo Débutant 100 €**.
- Profile 1 000 €: ticket 50 €, maximum 100 €, exposure 300 €, reserve 700 €.
- Profile 100 €: ticket 5 €, maximum 10 €, exposure 30 €, reserve 70 €.
- Each profile has a separate local portfolio and journal.
- Switching profiles does not erase the other profile.
- Legacy 100 € state is copied non-destructively into the preserved school profile.

## Publication check

1. Upload the four files.
2. Commit with the supplied commit text.
3. Wait for GitHub Pages publication.
4. Open the public interface in Firefox.
5. Perform `Ctrl + F5`.
6. Confirm Build 28.2.80.
7. Open Administration → Simulation.
8. Confirm that **Progression 1 000 €** is active by default.
9. Confirm 1 000 € / 50 € / 100 € / 300 € / 700 €.
10. Switch to **École 100 €** and confirm 100 € / 5 € / 10 € / 30 € / 70 €.
11. Switch back and confirm each profile preserves its own state.
12. Test one guided school scenario under each profile.
13. Confirm Crypto, Metals, Decision Board and Bridge remain unchanged.

## Automated verification

- 100/100 checks passed.
- JavaScript syntax valid.
- JSON valid.
- All 735 HTML IDs from Build 28.2.79 preserved.
- 16 new IDs added.
- All existing buttons, details and school routes preserved.
- Container Chromium navigation was blocked by administrator policy; public Firefox/Ryzen validation remains required.

No GitHub write or real crypto action was performed.
