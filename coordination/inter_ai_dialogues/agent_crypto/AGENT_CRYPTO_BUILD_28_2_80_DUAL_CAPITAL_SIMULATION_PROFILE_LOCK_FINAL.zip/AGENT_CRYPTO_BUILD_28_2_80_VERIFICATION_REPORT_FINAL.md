# AGENT-CRYPTO BUILD 28.2.80 — VERIFICATION REPORT FINAL

## Identity

- Release: Market Core V2.0-Alpha
- Build: 28.2.80
- Title: DUAL CAPITAL SIMULATION PROFILE LOCK
- Base: Build 28.2.79
- Result: **PASS**
- Checks: **100/100 passed**

## Delivered change

Build 28.2.80 adds a default virtual capital of **1 000 €** while preserving the original **100 €** school simulation as a separate profile.

### Solo Progression 1 000 €

- Initial capital: 1 000 €
- Recommended ticket: 50 €
- Maximum per operation: 100 €
- Maximum exposure: 300 €
- Minimum reserve: 700 €
- Assets: BTC, ETH, SOL

### Solo Débutant 100 €

- Initial capital: 100 €
- Recommended ticket: 5 €
- Maximum per operation: 10 €
- Maximum exposure: 30 €
- Minimum reserve: 70 €
- Assets: BTC, ETH, SOL

## Preservation and migration

- All Build 28.2.79 HTML IDs preserved.
- All existing buttons preserved.
- All 47 collapsible blocks preserved.
- All Mode École routes preserved.
- Each profile uses isolated local storage.
- Profile switching saves and reloads without deleting the other state.
- Legacy 100 € simulation data is copied into the preserved school profile and the legacy record is not deleted.

## Functional checks

- Active profile controls all amounts and limits.
- School exercises scale dynamically.
- Security Gate uses the active maximum, exposure and reserve.
- Manual simulation defaults to 50 € under the 1 000 € profile.
- Human-readable summaries and exports use the active profile.
- Cost, break-even, P/L, roadmap, proof ledger, withdrawal lab and Scam Sentinel remain present.

## Browser validation boundary

Node syntax, HTML structure, manifest coherence, preservation and profile invariants were checked automatically. Local Chromium navigation is blocked by administrator policy in the execution environment. Final visual and interaction validation must therefore be performed on the published GitHub Pages interface using Firefox/Ryzen.

## Safety

No GitHub write, exchange action, wallet action, key use, collector change or workflow change was performed.
