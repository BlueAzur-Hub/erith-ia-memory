# Agent-Crypto 40.6.321 — exact pre-.284 Aether subsystem restore

Functional commit: c0764c10eae024ae80f5857a15488b0632998f6b
Source tree for restored Aether subsystem: 093ded1888c21620f4077627baf84b33d77bc2b7

Restored byte-for-byte:
- administrator/js/app.js
- administrator/js/aether.js
- administrator/js/core/admin-window-manager.js
- administrator/admin-ribbons.css
- administrator/aether.css
- administrator/aether-v2.css
- administrator/js/aether-role-visibility.js

Only build/index truth was advanced to 40.6.321.

This build intentionally contains NO left-placement adaptation.
The expected terrain baseline is the historical/default Aether presentation first.
