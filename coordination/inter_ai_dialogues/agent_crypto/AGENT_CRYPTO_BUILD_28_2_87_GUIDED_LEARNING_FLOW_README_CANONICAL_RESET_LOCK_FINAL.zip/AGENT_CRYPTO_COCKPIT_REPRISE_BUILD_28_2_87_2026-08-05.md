# AGENT-CRYPTO — Reprise canonique du Cockpit

**Date :** 5 août 2026  
**Build :** 28.2.87  
**Base :** 28.2.86  
**Destination :** apprentissage guidé sans recherche ni geste ambigu

## 1. État réel avant le Build

Le système de récupération est considéré comme terminé.

État observé chez Christophe :

- profil fictif principal : Solo Progression 1 000 € ;
- Module 01 : Marché et données — Compris ;
- Module 02 : Spot et carnet d’ordres — session terminée ;
- étapes : 5/5 ;
- notes : 550 caractères ;
- conclusion : 195 caractères ;
- progression : 9 % ;
- stockage : IndexedDB vérifiée ;
- argent réel : aucun.

Le défaut restant n’était pas une perte de données. Il concernait la compréhension du geste suivant.

## 2. Contrat du Cockpit

Le Cockpit doit répondre à une question unique :

> Que dois-je faire maintenant ?

Il ne doit jamais demander à l’apprenant de comprendre la structure interne de la page, de rechercher une zone, de deviner si une case est une preuve ou une commande, ni de savoir quel bouton réinitialise ou poursuit une séance.

## 3. Machine à états canonique

```text
READ
→ OPEN
→ PRACTICE
→ VERIFY
→ NOTE
→ COMPLETE
→ NEXT_MODULE
```

Chaque état possède :

- une action principale ;
- une phrase expliquant sa mission ;
- une preuve d’accomplissement ;
- une destination précise ;
- un retour direct ;
- aucun effet financier réel.

## 4. Invariants

- une séance archivée ne redevient jamais un brouillon ;
- `completed_at` n’est pas effacé par une continuation normale ;
- `session_id` empêche les doublons ;
- le prochain module crée une nouvelle séance ;
- recommencer ne touche qu’au brouillon courant ;
- l’historique reste intact ;
- les notes archivées restent lisibles mais verrouillées ;
- IndexedDB reste le stockage du carnet ;
- les profils de simulation restent séparés ;
- aucun module n’est validé par un simple changement visuel sans preuve.

## 5. Module 03 préparé

La suite pédagogique naturelle est :

**03 · Frais et gestion du risque**

Mission de pratique :

1. charger l’exemple pédagogique de coûts ;
2. observer un scénario fictif de baisse de 3 % ;
3. observer un scénario fictif de hausse de 5 % ;
4. vérifier le résultat ;
5. expliquer avec ses propres mots la différence entre résultat brut, coûts et résultat net.

Les scénarios sont des calculs locaux et ne modifient aucune position.

## 6. Stop point

Après publication, le seul objectif est de vérifier le chemin complet dans Firefox avec les données réelles de Christophe.

Aucune nouvelle fonction de marché, aucun travail Kraken, aucune archive supplémentaire et aucune autre version ne doivent être engagés avant le retour de ce test.
