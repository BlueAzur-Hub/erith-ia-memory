# Upload — Agent-Crypto Build 28.2.87

## Mission

Corriger le parcours du Cockpit d’apprentissage sans modifier les marchés, les collecteurs, le Bridge, les profils fictifs ni la récupération IndexedDB du Build 28.2.86.

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/README.md
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Aucun autre fichier public n’est à remplacer pour cette version.

## Publication

1. Remplacer les cinq fichiers ci-dessus dans GitHub.
2. Attendre la publication GitHub Pages.
3. Ouvrir l’interface avec le même profil Firefox qui contient le carnet IndexedDB.
4. Effectuer un rechargement forcé.
5. Vérifier que la version affichée est `Build 28.2.87`.
6. Ouvrir le Cockpit d’apprentissage.

## Résultat attendu avec l’état actuel de Christophe

La séance `02 · Spot et carnet d’ordres`, déjà archivée dans le Build 28.2.86, doit être reconnue comme terminée même si l’ancien bouton `Continuer mon parcours` l’avait rouverte visuellement.

La carte de fin doit afficher notamment :

```text
02 · Spot et carnet d’ordres
5/5 étapes
550 caractères de notes
195 caractères de conclusion
9 % de progression
Passer au module 03 — Frais et gestion du risque
```

Les nombres de caractères sont ceux de l’état observé dans les captures. L’interface doit afficher les valeurs réellement présentes dans IndexedDB.

## Test principal

1. Ne recommencer aucun module.
2. Vérifier la carte de fin de la séance Spot.
3. Cliquer une fois sur `Passer au module 03 — Frais et gestion du risque`.
4. Vérifier qu’une nouvelle séance du Module 03 est créée.
5. Vérifier que le Module 02 reste archivé et que la progression n’est pas effacée.
6. Recharger Firefox et confirmer que le Module 03 reste au même point.

## Parcours du Module 03

Le bouton principal doit guider successivement :

```text
Lire la leçon
→ Ouvrir les frais et scénarios
→ Faire l’exercice fictif
→ Vérifier le résultat
→ Écrire ma conclusion
→ Terminer et archiver
→ Passer au module suivant
```

Pour le Module 03, l’exercice demande trois preuves locales :

- charger l’exemple de coûts pédagogiques ;
- observer le scénario `−3 %` ;
- observer le scénario `+5 %`.

Ces scénarios ne modifient pas le portefeuille fictif.

## Sécurité

- aucune clé API ;
- aucun wallet ;
- aucun argent réel ;
- aucun ordre réel ;
- aucun levier ;
- aucune écriture GitHub effectuée par l’assistante ;
- aucun collecteur ou workflow modifié.

## En cas d’anomalie

Ne supprimer aucune donnée Firefox et ne réinitialiser aucun profil. Envoyer une capture du Cockpit, de la carte de fin et du marqueur de Build.
