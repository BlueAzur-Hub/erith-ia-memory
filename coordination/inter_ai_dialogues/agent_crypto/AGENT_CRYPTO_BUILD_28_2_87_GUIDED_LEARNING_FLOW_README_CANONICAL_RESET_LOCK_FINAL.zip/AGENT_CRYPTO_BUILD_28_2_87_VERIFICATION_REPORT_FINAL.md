# AGENT-CRYPTO — Rapport de vérification final

## Build

**Market Core V2.0-Alpha · Build 28.2.87**  
**GUIDED LEARNING FLOW & CANONICAL README RESET LOCK**

## Base de départ

Le Build 28.2.86 est conservé comme base de récupération validée :

- carnet pédagogique dans IndexedDB ;
- anciennes sources 28.2.81 et 28.2.79 préservées ;
- progression et notes restaurées ;
- session Spot archivée ;
- aucune migration supplémentaire requise.

Le Build 28.2.87 ne réécrit pas ce système. Il corrige uniquement le parcours du Cockpit et le README public.

## Défaut corrigé

L’ancien parcours pouvait produire l’état suivant :

- une séance était correctement archivée ;
- le bouton `Continuer mon parcours` effaçait visuellement son état terminé en remettant `completed_at` à `null` ;
- l’utilisateur était renvoyé vers l’exercice déjà terminé ;
- le bouton qui créait réellement une nouvelle séance était associé à `Recommencer ce module` ;
- l’archivage ne produisait pas de transition visuelle assez claire.

Le résultat humain était une boucle : séance réussie, impression que rien ne s’était passé, retour dans la Simulation, recherche d’une flèche ou d’une prochaine étape dans une longue page.

## Correction fonctionnelle

### Action principale déterministe

Le Cockpit affiche désormais une seule action dominante selon l’état réel :

1. lire la leçon ;
2. ouvrir la bonne zone ;
3. faire l’exercice fictif ;
4. vérifier le résultat ;
5. écrire la conclusion ;
6. terminer et archiver ;
7. passer au module suivant.

### Preuves automatiques

Les cinq cases sont conservées mais désactivées. Elles représentent les preuves enregistrées par les actions réelles et ne demandent plus une manipulation manuelle ambiguë.

### Réparation de séance archivée rouverte

Le moteur compare l’identifiant de la séance courante avec l’historique IndexedDB. Lorsque les cinq étapes sont présentes et qu’une archive terminée possède le même identifiant, le Cockpit restaure l’état terminé et affiche la carte de fin sans créer de doublon.

### Archivage idempotent

L’archivage utilise `session_id` comme identité. Un second clic sur la fin de séance ne crée aucune nouvelle entrée historique.

### Transition explicite

La carte de fin affiche :

- le module terminé ;
- la date et l’identifiant de séance ;
- les cinq étapes ;
- la longueur des notes ;
- la longueur de la conclusion ;
- la progression globale ;
- le nombre de sessions archivées ;
- le prochain module ;
- un bouton explicite pour le créer.

### Guide dans l’exercice

La destination ouverte par le Cockpit contient un guide visible avec :

- le fil du parcours ;
- le module courant ;
- la mission exacte ;
- l’action de validation ;
- le retour direct à la session guidée.

### Recommencer protégé

`Recommencer ce module` est déplacé dans les options secondaires. Il ne peut réinitialiser qu’un brouillon en cours après confirmation. Une séance archivée ne peut pas être effacée par ce bouton.

### README canonique

Le README public accumulé et obsolète est remplacé par un document actuel centré sur le produit réellement publié : Market Core V2.0-Alpha, Cockpit guidé, profils fictifs, IndexedDB, vérité des données, architecture et procédure de publication.

## Résultat des contrôles

**61 contrôles réussis sur 61 — 0 échec.**

### Contrôles statiques

- syntaxe JavaScript validée avec Node.js ;
- `version.json` valide ;
- identité Build et token cohérente ;
- 839 identifiants HTML uniques ;
- tous les identifiants du Build 28.2.86 conservés ;
- boutons conservés et étendus : 263 vers 270 ;
- blocs dépliables conservés et étendus : 48 vers 50 ;
- toutes les fonctions JavaScript nommées de 28.2.86 conservées ;
- appels `fetch` inchangés : 16 vers 16 ;
- WebSocket inchangé : 1 vers 1 ;
- clés de stockage pédagogique et de simulation inchangées ;
- nouveau README cohérent avec 28.2.87.

### Test comportemental ciblé

Le scénario automatisé a vérifié :

- démarrage sans erreur d’exécution ;
- restauration d’une séance Spot archivée mais visuellement rouverte ;
- affichage de la carte de fin ;
- restitution des compteurs de 550 caractères de notes et 195 caractères de conclusion ;
- proposition du Module 03 ;
- absence de doublon après une nouvelle tentative d’archivage : 1 vers 1 ;
- création du Module 03 sans suppression de l’historique ;
- démarrage du Module 03 à la leçon ;
- exigence des trois preuves de frais et scénarios ;
- ouverture de la vérification sans validation prématurée ;
- enregistrement de l’étape 4 depuis le guide ;
- conservation d’une note de 12 010 caractères sans troncature ;
- validation de la conclusion ;
- archivage du Module 03 comme deuxième session ;
- absence de doublon après répétition : 2 vers 2 ;
- verrouillage des champs d’une séance archivée ;
- zéro erreur finale d’exécution.

## Méthode du test navigateur

L’interface complète a été injectée dans Chromium avec un contrat IndexedDB en mémoire reproduisant les opérations utilisées par le Cockpit. Le scénario a été piloté par les fonctions réelles de l’application et a contrôlé le DOM, la session courante, l’historique et les transitions.

Ce test valide le moteur ciblé. La validation publique définitive reste le test effectué par Christophe dans son profil Firefox/Ryzen, avec ses données IndexedDB réelles, après publication.

## Préservation

Le Build ne modifie pas :

- collecteurs Crypto et Métaux ;
- workflows GitHub Actions ;
- registres et contrats de données ;
- graphiques et Math Core ;
- Decision Board ;
- Bridge et Control Center ;
- profils fictifs 100 € et 1 000 € ;
- calculs de simulation ;
- Transaction Proof Ledger ;
- Security Gate ;
- retrait fictif ;
- Scam Sentinel ;
- preuve de récupération IndexedDB 28.2.86.

## Limites exactes

- aucune validation publique Firefox/Ryzen n’est revendiquée avant publication par Christophe ;
- aucun ordre réel, compte d’exchange ou wallet n’est testé ;
- le test ciblé ne prétend pas cliquer chaque bouton secondaire de l’ensemble du produit ;
- aucune écriture GitHub n’a été effectuée par l’assistante ;
- aucune image n’a été générée.

## Verdict

**PASS statique et comportemental ciblé.**  
**Build prêt pour publication manuelle et validation publique Firefox/Ryzen.**
