# Agent-Crypto 40.6.174 — Direct Shell Evidence Load

## Type de livraison
PATCH de release, pas une distribution autonome complète.
Base requise : dépôt Agent-Crypto contenant déjà les modules Strategy A de 40.6.166 à 40.6.172.

## Cause
40.6.173 publiait correctement le build mais les panneaux 40.6.169/171/172 n'étaient toujours pas observés
dans l'état terrain exporté. La présence des fichiers dans un registre ou dans Git ne suffisait donc pas.

## Correction 40.6.174
L'entrée immuable de release injecte directement sept balises <script> dans le HTML du runtime-shell AVANT
document.write(). Les modules participent ainsi au parsing normal de la shell, après les modules legacy.

Modules :
- strategy-a-evidence-lifecycle-truth.js
- strategy-a-foundation-applicability-truth.js
- strategy-a-time-semantics-truth.js
- strategy-a-g3-structured-data-truth.js
- strategy-a-g3-history-owner-discovery.js
- strategy-a-g3-historical-evidence-adapter.js
- strategy-a-gate-canonical-truth.js

## Invariants
- Market Core 38.15.11 inchangé
- aucun seuil Strategy A modifié
- aucun changement Risk / lifecycle métier
- aucun ordre réel
- aucun timer récurrent
- aucun MutationObserver
- aucun nouvel owner de stockage
- G3 reste PENDING
- G9 reste LOCKED

## Commits GitHub
- release 40.6.174 : c67b71c15b55b1f0e7f4f545e80ccbeb9c2d8d26
- promotion build.json : a484a0cd9a4d91d488bb74f7bf5b9cc1dfc39c20

## Terrain
Firefox : PENDING jusqu'au prochain rechargement.
