# Upload

Unzip and merge at the repository root of `BlueAzur-Hub/agent-crypto-operator`, preserving paths. Do not delete historical `.118` or rollback files.

Expected page after GitHub Pages deployment:
`https://blueazur-hub.github.io/agent-crypto-operator/public/agent_crypto_erith_ia/operator/index-40.6.121.html`

Suggested commit:
`release(agent-crypto-operator): sync Yohan Operator to 40.6.121`
