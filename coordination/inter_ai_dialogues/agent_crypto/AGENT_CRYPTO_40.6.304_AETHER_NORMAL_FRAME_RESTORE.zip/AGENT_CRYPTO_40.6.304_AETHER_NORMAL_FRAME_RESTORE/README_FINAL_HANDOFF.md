# AGENT-CRYPTO 40.6.304 — AETHER NORMAL FRAME RESTORE

Main commit:
fc9d5e48ffd6fd6ba0496776a0d14174f3de76c9

Release:
PARKER LEWIS CAN'T LOSE · AETHER NORMAL FRAME RESTORE

Root cause fixed:
40.6.303 correctly recovered LEFT x=12, but the active `preferredFloatGeometry`
still used the reduced formula:

    min(1450, vw - 32, (vh * 1.7777777778) - 352)

That formula reproduces the reduced Aether frame observed on Firefox.

40.6.304 restores the validated 40.6.75 normal-frame rule:
- x = 12
- complete 16:9 frame
- use the full safe field to the left of visible Lecture Technique
- max width = 1450
- one-time Aether-only migration from stale .300-.303 presentation state
- then the existing Administrator Window Manager owns drag, resize,
  close/reopen persistence and maximize/restore.

Files changed:
- public/agent_crypto_erith_ia/administrator/js/app.js
- public/agent_crypto_erith_ia/administrator/build.json
- public/agent_crypto_erith_ia/administrator/index.html

Protected and unchanged:
- Decision Intelligence current truth
- post-boot loader
- admin-window-manager.js
- aether.js
- aether.css
- aether-v2.css
- Market Core 38.15.11
- Oracle
- Lecture Technique
- Storage business logic
- Strategy

Firefox terrain remains the final proof.
