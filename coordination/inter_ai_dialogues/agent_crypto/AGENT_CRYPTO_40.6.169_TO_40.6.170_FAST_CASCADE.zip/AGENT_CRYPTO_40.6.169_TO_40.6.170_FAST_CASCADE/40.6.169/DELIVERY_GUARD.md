# Delivery Guard

- Build: 40.6.169
- Inline HTML scripts: PASS
- `strategy-a-g3-structured-data-truth.js`: PASS
- `runtime-modules.js`: PASS
