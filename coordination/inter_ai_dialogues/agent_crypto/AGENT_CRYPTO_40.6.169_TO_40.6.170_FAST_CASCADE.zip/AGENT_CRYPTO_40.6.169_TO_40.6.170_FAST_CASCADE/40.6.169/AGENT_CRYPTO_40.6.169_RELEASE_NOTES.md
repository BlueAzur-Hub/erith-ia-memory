# 40.6.169 — G3 Structured Data Truth

- G3 certification-facing data now comes from structured owners only.
- `document.body.innerText` is not parsed by this new truth layer.
- Missing structured values stay `null / INCONNU`; UNKNOWN never becomes zero.
- Market Memory count uses `atlasDecisionMemoryStats`; retrospective evaluability uses `atlasRetrospectiveValidation.derive`.
- No explicit structured owner is assumed for 24h series metadata; those values remain INCONNU until an owner exists.
- G3 remains PENDING; no replay/backtest is certified.
