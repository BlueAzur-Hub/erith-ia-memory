# Fast cascade 40.6.169 → 40.6.170

1. 40.6.169 replaces certification-facing G3 text scraping with structured owner truth and preserves UNKNOWN as UNKNOWN.
2. 40.6.170 preserves canonical gate numbers/states and removes unavailable=zero semantics from the authoritative presentation layer.

Market Core 38.15.11 preserved. PAPER only. G3 PENDING. G9 LOCKED.
