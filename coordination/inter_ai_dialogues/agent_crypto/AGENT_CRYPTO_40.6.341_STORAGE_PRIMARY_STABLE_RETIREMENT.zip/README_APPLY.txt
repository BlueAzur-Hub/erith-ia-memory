Agent-Crypto 40.6.341 — differential reconstruction archive
Parent commit: 3103f47f95594ee95f1f508f19870c4249fe4551
Functional commit: 63bb39d35dd431e9ae6b3de29ab449ec32aab918
Packaging base HEAD: 527dc9ee3a279283f8437f9808a72288266aa805

Contents:
- PATCH_40.6.341_STORAGE_PRIMARY_STABLE_RETIREMENT.diff
- build.json
- HANDOFF_40.6.341_STORAGE_PRIMARY_STABLE_RETIREMENT.md

The archive is intentionally differential because administrator/app.js is a multi-megabyte canonical owner.
Apply the patch to the exact parent commit. GitHub main already contains the full resulting runtime files.
