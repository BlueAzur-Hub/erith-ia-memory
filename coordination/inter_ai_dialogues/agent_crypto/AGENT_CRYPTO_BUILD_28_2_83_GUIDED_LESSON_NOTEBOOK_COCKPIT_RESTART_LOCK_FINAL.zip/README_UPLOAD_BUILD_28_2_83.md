# Upload Build 28.2.83

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

## Après l'upload

1. attendre la fin de publication GitHub Pages ;
2. effectuer un rechargement complet dans Firefox ;
3. vérifier l'affichage `Build 28.2.83` ;
4. ouvrir le Cockpit ;
5. confirmer le retour au module 01 ;
6. vérifier que l'ancienne simulation 1 000 € reste présente ;
7. lire la leçon intégrée ;
8. saisir un texte long dans `Mes notes libres` ;
9. saisir une conclusion dans `Ce que je retiens` ;
10. recharger la page et vérifier que les deux textes restent complets ;
11. terminer une session et exporter le carnet complet.

## Important

Le redémarrage concerne uniquement le nouveau suivi Cockpit/Parcours 28.2.83. Les anciennes clés d'apprentissage restent conservées localement et aucun portefeuille fictif n'est effacé.

## SHA-256

```text
app.js      d858e095451b5e9c1bde747071056f9b85582cf3fce00aa7af814464ec40a0db
index.html  bfb63dd479ae475409bd0ea54b9547e87fcfc7c43385166aaedf54ce027c096e
style.css   c5f3550c381c5e85f434ed840ca0d82a48c02345db73948bbe5f070451368beb
version.json 7119e2bc7ae82ac641113319ce149950b1e10290fcd45472aa3743cad6ab6f7b
```
