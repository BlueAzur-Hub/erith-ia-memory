# AGENT-CRYPTO — Parcours pédagogique complet et point de reprise

**Date :** 4 août 2026  
**Base publique testée avant ce Build :** Build 28.2.81 — fonctionnelle, avec anomalie visuelle des cases à cocher  
**Objet :** réunir les notions étudiées, les observations faites sur l’interface, les améliorations envisagées et le point exact de reprise.

## 1. Règles de continuité

- Le Build 28.2.81 est la base publique testée par Christophe avant la préparation de 28.2.82. Le Cockpit fonctionne, mais les cases à cocher sont visuellement étirées sous Firefox/Ryzen.
- Aucune suppression, aucune réduction et aucun remplacement destructif.
- Toute amélioration future doit être additive, compatible avec l’existant et réversible.
- Aucun argent réel, aucun ordre réel, aucun retrait réel et aucune connexion Kraken pendant la phase pédagogique.
- Les frais, taux, seuils fiscaux, statuts réglementaires et procédures de plateforme doivent être vérifiés sur les sources officielles au moment de l’usage.
- Les explications doivent distinguer les définitions stables, les données actuelles, les hypothèses pédagogiques, les observations réelles et les fonctions non encore implémentées.

## 2. Simulation réellement observée dans le Build 28.2.78

### Achat fictif

- Capital initial : 100,00 €
- Achat simulé : BTC pour 5,00 €
- Capital restant : 95,00 €
- Valeur de la position : environ 5,00 €
- Quantité observée : environ 0,00009057 BTC
- Exposition : 5,00 € sur un plafond de 30,00 €
- P/L immédiat : proche de 0,00 €
- Journal : `ACHAT SIMULÉ · BTC pour 5,00 €`

### Vente fictive

- Vente simulée BTC : 5,00 €
- Position ensuite fermée
- Portefeuille virtuel : aucune position simulée
- Journal : `VENTE SIMULÉE · Vente simulée BTC pour 5,00 €`

### Limites constatées

Le simulateur affiche le capital, les positions, le total, le P/L, la quantité, la valeur actuelle, l’exposition et le journal. Il n’affiche pas encore clairement le prix d’entrée et de sortie, les frais, le spread, le slippage, le prix d’équilibre, le P/L brut et net séparés, le résultat réalisé détaillé, la durée de détention et la fraîcheur du prix utilisé.

## 3. Notions pédagogiques étudiées

### Lire le marché

- Prix actuel : valeur observée à un instant donné.
- Variation 24 h / 7 j : évolution entre deux bornes temporelles.
- Volume : valeur totale des échanges sur une période.
- Capitalisation : prix multiplié par les unités en circulation.
- Deux sources peuvent diverger sans qu’une soit nécessairement fausse : marché, heure, méthode et fréquence peuvent différer.

### Risque historique

- Volatilité : amplitude des mouvements.
- Drawdown : baisse entre un sommet et le creux suivant.
- VaR : estimation historique d’une perte ordinaire à un niveau de confiance donné ; elle ne décrit pas le pire scénario.

### Volume, liquidité, spread et slippage

- Volume élevé = beaucoup d’échanges, pas une hausse certaine.
- Liquidité = facilité d’acheter ou vendre sans trop déplacer le prix.
- Bid = meilleur prix acheteur.
- Ask = meilleur prix vendeur.
- Spread = écart bid/ask.
- Slippage = différence entre prix attendu et prix moyen exécuté.

### Ordres

- Ordre marché : exécution prioritaire, prix exact non garanti.
- Ordre limite : prix contrôlé, exécution non garantie.
- Stop-loss : sortie au marché, slippage possible.
- Stop-limit : prix minimal contrôlé, sortie non garantie.
- Take-profit : objectif de sortie favorable.
- OCO : l’exécution d’une sortie annule l’autre.

### Frais et seuil de rentabilité

Le coût complet peut inclure frais d’achat, frais de vente, spread, slippage, dépôt, conversion et retrait.

Approximation pédagogique :

`seuil de rentabilité ≈ frais achat + frais vente + spread + slippage`

Une hausse visible ne constitue pas encore un bénéfice tant que tous les coûts ne sont pas couverts.

### Taille de position et exposition

- Taille de position : somme exposée.
- Risque en euros = taille de position × baisse envisagée.
- Allocation : répartition du capital.
- Réserve : argent non exposé.
- Concentration : poids important d’un seul actif.

### Résultat latent, résultat réalisé et prix moyen

- Perte latente : actif encore détenu sous le coût d’achat.
- Perte réalisée : actif vendu sous le coût d’achat.
- Prix moyen réel = coût total payé / quantité totale détenue.
- DCA : calendrier régulier décidé à l’avance.
- Moyenner à la baisse : ajouter du capital après une baisse, ce qui augmente aussi l’exposition.

### Rendement, risque et séries de pertes

- Rapport rendement/risque = gain potentiel / perte potentielle.
- Espérance = probabilité de gain × gain moyen − probabilité de perte × perte moyenne − coûts.
- Un taux de réussite élevé peut rester déficitaire.
- Une perte de 20 % exige une hausse de 25 % pour revenir à l’équilibre.
- Une perte de 50 % exige une hausse de 100 %.

## 4. Retraits, réseaux et portefeuilles

### Anatomie d’un retrait

Un retrait comporte au minimum :

1. actif ;
2. réseau ;
3. adresse de destination ;
4. montant ;
5. frais ;
6. montant net estimé ;
7. statut et TXID.

La vérification doit porter simultanément sur le bon actif, le bon réseau, la bonne adresse, la bonne destination, les frais et les minimums.

### Petit retrait test

1. Vérifier actif, réseau et adresse.
2. Envoyer une petite quantité supérieure au minimum et aux frais.
3. Attendre la réception complète.
4. Vérifier TXID, confirmations et montant net.
5. Revérifier avant tout transfert suivant.

### Problèmes réseau

- Mauvais réseau : risque majeur de perte ou récupération difficile.
- Réseau correct mais lent : confirmations en attente.
- Blocage interne de plateforme : transaction pas encore diffusée ou retenue.
- Pas de TXID : probablement encore côté plateforme.
- TXID présent : transaction diffusée.
- Confirmations suffisantes mais solde absent : vérifier la destination.

### Plateforme et portefeuille personnel

- Plateforme : négociation et conservation par le prestataire.
- Portefeuille personnel : contrôle des clés par l’utilisateur.
- Plus de contrôle signifie plus de responsabilité.

## 5. Sécurité du compte

### Couches minimales

- email sécurisé ;
- mot de passe unique ;
- gestionnaire de mots de passe ;
- passkey ou application d’authentification ;
- 2FA de connexion ;
- 2FA de financement/retrait ;
- protection du trading ;
- verrouillage global des paramètres lorsque la configuration est terminée.

### GSL Kraken

Le verrouillage global des paramètres peut empêcher les modifications sensibles, masquer des informations et imposer un délai de déverrouillage. Il complète la 2FA et aide à empêcher l’ajout ou la modification d’adresses de retrait après compromission.

La clé maîtresse Kraken et la phrase de récupération d’un portefeuille sont deux notions différentes.

### Phishing et faux support

- Ne jamais communiquer mot de passe, codes 2FA ou phrase de récupération.
- Utiliser uniquement les canaux officiels.
- Éviter les liens reçus par message.
- Conserver l’adresse officielle en favori.
- Un support officiel ne demande pas la phrase secrète du portefeuille.

### Blocages de sécurité

Un premier achat instantané ou certaines méthodes de dépôt peuvent entraîner un blocage temporaire de retrait. Cela ne signifie pas nécessairement une panne ou une perte.

### Réaction en cas de doute

- arrêter toute transaction ;
- sécuriser d’abord l’email ;
- modifier les identifiants compromis ;
- vérifier les sessions et paramètres ;
- utiliser uniquement le support officiel ;
- ne jamais envoyer de fonds à une personne prétendant « débloquer » le compte.

## 6. Sécurité du portefeuille personnel

### Adresse publique et secret

- Adresse publique : sert à recevoir.
- Phrase de récupération / clé privée : donne le contrôle du portefeuille.
- La phrase secrète ne doit jamais être transmise à un support, une connaissance ou un site non vérifié.

### Sauvegarde

- noter exactement les mots et leur ordre ;
- conserver la sauvegarde hors ligne ;
- éviter capture d’écran, email et SMS ;
- utiliser un support physique protégé ;
- ne pas laisser la sauvegarde avec l’appareil contenant le portefeuille.

### Perte ou compromission

- Phrase perdue et plus aucun accès : actifs potentiellement irrécupérables.
- Phrase connue d’un tiers : portefeuille considéré compromis.
- Importer la même phrase ailleurs ne corrige pas la compromission.
- Les actifs restants doivent être transférés vers un nouveau portefeuille avec une nouvelle phrase, selon une procédure vérifiée.

### Portefeuille logiciel et matériel

- Logiciel : pratique mais exposé aux risques de l’appareil.
- Matériel : clés protégées par un appareil dédié, mais aucune protection contre une mauvaise adresse, un mauvais réseau, une phrase volée ou une signature mal comprise.
- Aucun appareil ne remplace la vérification humaine.

## 7. Traçabilité et fiscalité française

> Section pédagogique. Les règles doivent être revérifiées au moment de la déclaration.

### Journal à conserver dès la première opération

- date et heure ;
- plateforme ;
- actif et paire ;
- type d’ordre ;
- quantité ;
- prix ;
- montant en euros ;
- frais ;
- identifiant de l’ordre ;
- dépôt ou retrait ;
- réseau ;
- adresse ;
- TXID ;
- justificatif bancaire ;
- export CSV ou relevé ;
- capture utile de confirmation.

### Opérations et déclaration

Pour un particulier fiscalement domicilié en France :

- simple détention : non imposée ;
- vente contre euros : cession imposable potentielle ;
- achat d’un bien ou service en crypto : cession imposable potentielle ;
- échange crypto contre crypto sans soulte : sursis d’imposition ;
- échange avec soulte : traitement spécifique à vérifier.

Le seuil de 305 € porte sur la somme annuelle brute des prix de cession, pas sur le bénéfice.

Formulaires et cases :

- annexe 2086 ;
- 3AN pour une plus-value ;
- 3BN pour une moins-value ;
- 3CN pour l’option au barème progressif lorsqu’elle s’applique ;
- 3916-3916 bis pour les comptes d’actifs numériques à l’étranger.

La page impots.gouv.fr modifiée le 17 juillet 2026 indique, pour la gestion privée, un PFU de 31,4 % : 12,8 % d’impôt et 18,6 % de prélèvements sociaux. Ce taux doit être revérifié, car d’anciens documents mentionnaient 30 %.

Une activité professionnelle ou assimilée, le minage, le staking, la DeFi ou des opérations nombreuses et sophistiquées peuvent relever d’un autre traitement.

## 8. Améliorations futures de l’interface

### Règle absolue

- Conserver 100 % des sections, fonctions, scénarios, données et boutons existants.
- Aucune réduction ni suppression.
- Améliorations uniquement additives et réversibles.

### Info-bulles pédagogiques dynamiques

Chaque bulle doit inclure :

1. définition stable ;
2. valeur actuelle ;
3. lecture contextuelle déterministe ;
4. source ;
5. date et heure ;
6. âge de la donnée ;
7. donnée réelle ou hypothèse ;
8. limite d’interprétation.

Notions prioritaires : prix, variation, volume, capitalisation, liquidité, volatilité, drawdown, VaR, spread, slippage, P/L, exposition, frais, seuil de rentabilité, résultat latent/réalisé, réseau, adresse, TXID et phrase de récupération.

### Simulation enrichie

Ajouter :

- prix d’entrée et prix actuel ;
- variation depuis l’achat ;
- quantité brute et nette ;
- frais achat/vente ;
- spread et slippage estimés ;
- prix d’équilibre ;
- P/L brut et net ;
- résultat réalisé ;
- durée de détention ;
- source et fraîcheur du prix.

### Scénarios instantanés

Boutons :

`−5 % · −3 % · −1 % · prix actuel · +1 % · +3 % · +5 %`

Ils doivent recalculer valeur de position, P/L brut, coûts, P/L net, portefeuille total et explication adaptée.

### Mode École guidé

Conserver tous les exercices et ajouter état de progression, prévisualisation, règles contrôlées, motif exact des refus, comparaison avant/après, protection contre double clic et liens directs vers portefeuille et journal.

### Simulateur de retrait fictif

Prévoir actif, réseau, adresse de démonstration, montant, frais, montant net, minimum, incompatibilités, TXID fictif, confirmations et checklist finale.

### Corrections visuelles

- `DONNÉES À JOUR` → `À JOUR` ;
- verrouiller la largeur du cartouche ;
- éviter le redimensionnement de la fenêtre et le déplacement du graphique ;
- supprimer `−0,00 €` ;
- expliquer les abréviations comme P/L.

## 9. Point exact de reprise

### Terminé

- lecture de l’Observatoire ;
- prix, volume, risque, liquidité ;
- frais et seuil de rentabilité ;
- taille de position ;
- résultat latent et réalisé ;
- ordres Spot ;
- retraits, réseaux et TXID ;
- sécurité du compte et du portefeuille ;
- première boucle complète de simulation fictive ;
- principales lacunes pédagogiques du Build 28.2.78.

### Étapes suivantes

1. relire et valider ce document ;
2. vérifier qu’aucune amélioration ne manque ;
3. établir une liste finale et priorisée ;
4. décider explicitement si un nouveau Build doit être lancé ;
5. seulement ensuite modifier l’interface de manière additive ;
6. produire ZIP, rapport de vérification, hashes, chemins de remplacement et texte de commit complet.

## 10. Sources officielles

### Kraken

- https://support.kraken.com/fr/articles/360000426923-secure-your-account-with-two-factor-authentication-2fa-
- https://support.kraken.com/fr/articles/360000911763-how-does-two-factor-authentication-2fa-for-funding-deposits-withdrawals-work-
- https://support.kraken.com/fr/articles/201396877-what-is-the-global-settings-lock-gsl-
- https://support.kraken.com/fr/articles/13644055237908-how-to-prevent-unwanted-withdrawals
- https://support.kraken.com/fr/articles/backing-up-your-kraken-wallet
- https://support.kraken.com/fr/articles/create-a-wallet-on-kraken-wallet
- https://support.kraken.com/fr/articles/my-kraken-wallet-has-been-compromised
- https://support.kraken.com/fr/articles/kraken-wallet-official-support-and-communication-channels
- https://support.kraken.com/fr/articles/360000389606-why-is-there-a-withdrawal-hold-on-my-account-

### France

- https://www.impots.gouv.fr/particulier/questions/comment-declarer-les-plus-ou-moins-values-sur-cessions-dactifs-numeriques
- https://www.impots.gouv.fr/particulier/les-cessions-mobilieres
- https://www.impots.gouv.fr/formulaire/3916/declaration-par-un-resident-dun-compte-letranger-ou-dun-contrat-de-capitalisation-o
- https://bofip.impots.gouv.fr/bofip/11969-PGP.html/identifiant%3DBOI-RPPM-PVBMC-30-30-20240423
- https://www.economie.gouv.fr/particuliers/gerer-mon-argent/investissement-dans-les-cryptomonnaies-ce-quil-faut-savoir
- https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/crypto-actifs-bitcoin-etc
- https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/crypto-actifs-bitcoin-etc/investir-en-crypto-monnaies-quel-professionnel-choisir

## 11. Verdict

Le socle théorique essentiel est couvert. La prochaine étape n’est pas une nouvelle leçon : c’est la consolidation et la transformation contrôlée de ces constats en cahier des charges d’interface, sans suppression de l’existant.

---

# Complément final — notions avancées de culture crypto

## 12. Stablecoins

Un stablecoin cherche à suivre une référence, souvent le dollar ou l’euro. « Stable » ne signifie ni garanti, ni identique à un dépôt bancaire.

Risques à connaître :

- désancrage ou depeg ;
- qualité des réserves et solidité de l’émetteur ;
- liquidité ;
- gel possible de certaines adresses selon l’émetteur ;
- risque de change pour un utilisateur raisonnant en euros ;
- même nom de jeton disponible sur plusieurs réseaux ;
- faux jetons portant un symbole connu.

Règle : vérifier l’actif, l’adresse de contrat et le réseau.

## 13. Staking et produits de rendement

Le staking consiste à immobiliser ou déléguer certains jetons afin de participer au fonctionnement d’un réseau et recevoir des récompenses possibles.

Le rendement annoncé doit être corrigé par :

- la variation du prix du jeton ;
- les frais ;
- l’inflation de l’offre ;
- le délai de déblocage ;
- le risque du validateur ou de la plateforme ;
- le slashing éventuel ;
- la fiscalité applicable.

Plus de jetons ne signifie pas automatiquement davantage de valeur en euros.

## 14. Tokenomics et dilution

Éléments principaux :

- offre en circulation ;
- offre totale ;
- offre maximale ;
- capitalisation ;
- valorisation pleinement diluée ou FDV ;
- calendrier de vesting ;
- token unlocks ;
- inflation ;
- burn ;
- répartition entre équipe, investisseurs, trésorerie et public ;
- utilité réelle du jeton.

Formules simples :

`capitalisation = prix × offre en circulation`

`FDV = prix × offre maximale ou totalement diluée`

Un faible prix unitaire ne signifie pas qu’un jeton est bon marché. Une forte différence entre capitalisation et FDV peut signaler une dilution potentielle importante.

## 15. Smart contracts et autorisations

Un smart contract est un programme exécuté sur une blockchain. Il applique son code ; ce n’est pas une intelligence capable de juger l’intention de l’utilisateur.

Distinguer :

- connexion d’un portefeuille ;
- signature d’un message ;
- transaction blockchain ;
- approbation ou allowance donnée à un contrat.

Une autorisation illimitée peut exposer davantage de jetons que l’opération actuelle. Déconnecter un site ne révoque pas nécessairement une autorisation déjà enregistrée sur la blockchain.

## 16. DeFi

La finance décentralisée peut proposer échange, prêt, emprunt, fourniture de liquidité et produits de rendement.

Risques :

- bug ou faille de smart contract ;
- clé administrative ;
- oracle de prix défaillant ;
- liquidité insuffisante ;
- gas ;
- slippage et price impact ;
- liquidation d’un emprunt garanti ;
- perte impermanente ;
- dépendance à plusieurs protocoles assemblés.

Un audit réduit certains risques, mais ne garantit jamais l’absence de faille.

## 17. Bridges

Un bridge relie deux réseaux. Selon son fonctionnement, il peut bloquer un actif sur le réseau de départ et produire une représentation sur le réseau d’arrivée.

Vérifier :

- réseau de départ ;
- réseau d’arrivée ;
- bridge officiel ;
- actif reçu ;
- frais sur les deux réseaux ;
- liquidité ;
- temps de transfert ;
- petit test préalable.

Un bridge ajoute une nouvelle couche de risque : contrats, validateurs, réseaux et liquidité.

## 18. Marge, levier, futures et liquidation

- Spot : exposition limitée au capital utilisé, sans liquidation de marché liée à un emprunt.
- Marge : capacité fournie pour ouvrir une position plus grande.
- Levier : exposition supérieure au capital engagé.
- Long : recherche d’une hausse.
- Short : recherche d’une baisse.
- Future : contrat dépendant du prix d’un actif.
- Perpétuel : future sans échéance fixe.
- Funding : paiement périodique entre positions longues et courtes.
- Liquidation : fermeture forcée lorsque la marge devient insuffisante.
- Marge isolée : risque compartimenté.
- Marge croisée : plusieurs positions partagent le même capital.
- Mark price : prix de référence pouvant être utilisé pour la liquidation.

Le levier réduit la marge d’erreur. Un mouvement ordinaire du marché peut provoquer une perte majeure ou une liquidation.

Règle du profil débutant : Spot uniquement, sans levier, marge, futures, perpetuals ni short.

## 19. Arnaques et manipulations

Principaux scénarios :

- fausse plateforme avec gains fictifs ;
- taxe ou dépôt supplémentaire demandé pour débloquer un retrait ;
- faux support ;
- phishing ;
- logiciel de prise de contrôle à distance ;
- malware remplaçant une adresse copiée ;
- address poisoning ;
- faux cadeau demandant d’envoyer d’abord des cryptos ;
- arnaque relationnelle ou sentimentale ;
- faux groupe de trading ;
- pump-and-dump ;
- rug pull ;
- honeypot empêchant la vente ;
- faux jeton ;
- wallet drainer ;
- fausse récupération de fonds ;
- faux emploi ou utilisation du compte comme intermédiaire.

Signaux critiques : rendement garanti, urgence, secret réservé aux initiés, support demandant un code ou un secret, adresse dictée par un tiers, autorisation illimitée incomprise, nouveau paiement exigé pour retirer.

## 20. Checklist finale

Avant un achat Spot fictif ou futur :

- prestataire et domaine vérifiés ;
- compte sécurisé ;
- actif et paire compris ;
- type d’ordre compris ;
- montant borné ;
- frais d’entrée et de sortie connus ;
- spread observé ;
- prix d’équilibre calculé ;
- perte maximale acceptable ;
- aucun levier ;
- absence de pression extérieure ;
- confirmation humaine finale.

Avant un retrait :

- bon actif ;
- bon réseau ;
- bonne adresse ;
- adresse contrôlée après collage ;
- frais et montant net connus ;
- minimum respecté ;
- petit retrait test ;
- TXID et confirmations vérifiés.

Avant une interaction DeFi :

- domaine officiel ;
- réseau correct ;
- contrat identifié ;
- fonction comprise ;
- montant d’autorisation limité ;
- gas, slippage, price impact et minimum reçu connus ;
- méthode de sortie comprise.

En cas d’incompréhension : **ne pas signer et ne pas confirmer.**

---

# Build 28.2.78 — point de reprise

Le Build 28.2.78 ajoute, sans retirer l’existant :

- info-bulles pédagogiques dynamiques dans la simulation ;
- libellés plus compréhensibles ;
- hypothèses manuelles de frais et d’écarts ;
- exemple école explicitement non contractuel ;
- P/L brut séparé du P/L net estimé ;
- prix d’équilibre estimé ;
- scénarios instantanés de −5 % à +5 % ;
- détails de position enrichis ;
- journal d’achat et de vente enrichi ;
- Security Gate vert, orange ou rouge ;
- suppression de l’affichage négatif `−0,00 €` ;
- statut compact `À JOUR` ;
- largeur du cartouche de vérité du graphique verrouillée.

Les sections, fonctions et scénarios existants sont conservés.

## Sources officielles utiles

- AMF — crypto-actifs : https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/crypto-actifs-bitcoin-etc
- AMF — listes blanches et noires : https://www.amf-france.org/fr/espace-epargnants/proteger-son-epargne/listes-blanches
- Kraken Support : https://support.kraken.com/fr
- Ethereum — smart contracts : https://ethereum.org/fr/developers/docs/smart-contracts/
- Ethereum — DeFi : https://ethereum.org/fr/defi/
- Ethereum — bridges : https://ethereum.org/fr/bridges/
- ESMA — crypto-assets : https://www.esma.europa.eu/investor-corner/crypto-assets
- Europol — prévention : https://www.europol.europa.eu/operations-services-and-innovation/public-awareness-and-prevention-guides
- Impôts — actifs numériques : https://www.impots.gouv.fr/particulier/questions/comment-declarer-les-plus-ou-moins-values-sur-cessions-dactifs-numeriques

Les procédures, frais, statuts réglementaires et règles fiscales doivent toujours être revérifiés au moment de l’usage.


---

# ADDENDUM BUILD 28.2.79 — REPRISE OPÉRATIONNELLE

## Validation de 28.2.78 reçue

Les captures Firefox/Ryzen ont confirmé la présence et le fonctionnement visible des nouveaux blocs pédagogiques, du Security Gate, du laboratoire de retrait et du Scam Sentinel. Retour principal : les explications centrées sous forme de fenêtre modale sont jugées trop intrusives.

## Correction 28.2.79

- remplacement de la fenêtre modale par une aide contextuelle non bloquante ;
- suppression du flou et de l’assombrissement global ;
- panneau réductible et fermable ;
- ajout du parcours expert sur 24 mois ;
- ajout du Transaction Proof Ledger ;
- conservation intégrale des fonctions 28.2.78.

## Point de reprise après publication

1. valider visuellement le nouveau panneau d’aide ;
2. vérifier la persistance du parcours expert ;
3. tester achat, vente et refus fictifs ;
4. contrôler les preuves locales ;
5. relever toute anomalie avant le Build suivant.


---

## Mise à jour Build 28.2.80 — Double capital de simulation

La simulation possède désormais deux profils locaux séparés.

### Profil par défaut — Solo Progression 1 000 €

- capital : 1 000 € ;
- ticket conseillé : 50 € ;
- maximum par opération : 100 € ;
- exposition maximale : 300 € ;
- réserve minimale : 700 € ;
- actifs autorisés : BTC, ETH, SOL.

### Profil préservé — Solo Débutant 100 €

- capital : 100 € ;
- ticket conseillé : 5 € ;
- maximum par opération : 10 € ;
- exposition maximale : 30 € ;
- réserve minimale : 70 € ;
- actifs autorisés : BTC, ETH, SOL.

Chaque profil conserve séparément son argent disponible, ses positions, son résultat réalisé et son journal de preuves. Le changement de profil n’efface pas l’autre portefeuille. L’ancienne simulation locale à 100 € est migrée par copie vers le profil École sans suppression de l’ancien enregistrement.

### Point de validation publique

Après publication :

1. vérifier que le profil 1 000 € est actif ;
2. effectuer un achat fictif de 50 € ;
3. basculer sur le profil 100 € ;
4. vérifier que son portefeuille est indépendant ;
5. revenir sur le profil 1 000 € et vérifier que la position de 50 € est conservée ;
6. tester le Mode École dans les deux profils ;
7. vérifier l’absence de régression dans Crypto, Métaux, Decision Board et Bridge.


---

## Mise à jour Build 28.2.81 — Cockpit d’apprentissage guidé

### Objectif

Transformer le parcours expert sur 24 mois en cursus pratique quotidien, sans argent réel, sans suppression de l’interface existante et sans imposer une fenêtre pédagogique longue.

### Cockpit ajouté

Le Cockpit d’apprentissage rassemble désormais :

- le profil fictif actif — 100 € ou 1 000 € ;
- la progression globale sur les onze modules ;
- l’état du portefeuille fictif ;
- la dernière preuve de simulation ;
- le module recommandé ;
- une session guidée de cinq étapes ;
- une note personnelle locale ;
- un export Markdown de la session ;
- des raccourcis vers l’exercice, le parcours et le journal.

### Session guidée

La séance suit un ordre stable :

1. relire la notion ;
2. ouvrir la zone adaptée ;
3. réaliser un exercice fictif ;
4. vérifier les frais, le seuil et le résultat ;
5. écrire ce qui a été compris.

Une session peut être marquée comme terminée. Lorsqu’un module est encore `À découvrir` ou `Découvert`, la fin d’une séance peut le faire passer à `Compris`. Aucun score financier, aucune compétition et aucune autorisation d’opération réelle ne sont créés.

### Aides pédagogiques réglables

Trois modes locaux sont ajoutés :

- `Désactivées` : les boutons ⓘ restent visibles mais n’ouvrent rien ;
- `Courtes` : définition et état actuel ;
- `Détaillées` : définition, état actuel et règle de prudence.

Le mode par défaut est `Courtes`, conformément au retour de Christophe sur les fenêtres trop présentes.

### Recommandation automatique

Le cockpit choisit en priorité :

1. un module marqué `À revoir` ;
2. sinon le premier module `À découvrir` ;
3. sinon un module non encore pratiqué.

Cette recommandation est pédagogique. Elle ne constitue jamais un conseil financier.

### Persistance locale

Sont conservés localement :

- identifiant de session ;
- heure de début et de fin ;
- étapes cochées ;
- note personnelle ;
- nombre de sessions terminées ;
- niveau d’aide choisi.

Les clés des profils 28.2.80 et du parcours expert 28.2.79 restent inchangées afin de préserver les données déjà enregistrées.

### Point de validation publique

Après publication de 28.2.81 :

1. vérifier que le Cockpit apparaît avant le parcours expert ;
2. confirmer le profil actif et le capital fictif ;
3. cliquer sur `Continuer mon parcours` ;
4. tester les trois niveaux d’aide ;
5. cocher les cinq étapes et saisir une note ;
6. marquer la session terminée ;
7. exporter la session Markdown ;
8. vérifier que les profils 100 € et 1 000 € conservent leurs portefeuilles séparés ;
9. contrôler l’absence de régression dans Crypto, Métaux, Decision Board, Security Gate, retrait fictif, Scam Sentinel et Bridge.

### Statut

- Construction locale : terminée.
- Vérification automatisée : 128/128 contrôles réussis.
- Validation publique Firefox/Ryzen : à effectuer après upload par Christophe.
- Écriture GitHub par l’assistante : aucune.

## Build 28.2.82 — Checkbox Layout & Guided Session UI Fix

### Retour visuel de Christophe

Les captures publiques du Build 28.2.81 montrent que les cases à cocher sont séparées de leurs textes par une très grande zone vide. Le problème est visible dans :

- les cinq étapes de la session guidée ;
- la confirmation des hypothèses de coûts ;
- les contrôles du retrait fictif ;
- les signaux du Scam Sentinel.

### Cause confirmée dans le CSS

Une règle historique destinée aux champs de texte applique `width: 100%` à tous les éléments `input`. Les cases à cocher natives sont donc elles aussi étendues sur toute la largeur disponible. Le carré visible reste petit, mais sa boîte de mise en page devient immense et pousse le texte au bord opposé.

### Correction

Le Build 28.2.82 :

- impose une géométrie carrée stable aux checkboxes ;
- utilise 16 px sur desktop et 17 px sur petit écran ;
- retire le padding et l’expansion flex hérités ;
- place la case immédiatement à gauche du texte ;
- reconstruit les lignes de session en deux colonnes explicites ;
- applique la même correction aux coûts, au retrait fictif et au Scam Sentinel.

### Périmètre strict

Aucune structure HTML n’est ajoutée ou supprimée. Aucun comportement JavaScript ne change. Les calculs, profils, règles pédagogiques, états de progression, exports, journaux et verrous de sécurité restent identiques au Build 28.2.81.

### Vérification locale

- Syntaxe JavaScript : valide.
- Manifeste JSON : valide.
- Identifiants HTML : intégralement conservés.
- Boutons, champs, checkboxes et blocs dépliables : nombres inchangés.
- 17 checkboxes conservées avec les mêmes identités.
- Smoke test Chromium en contenu injecté, sans réseau : géométrie correcte à 1640, 1000 et 640 px.
- Résultat automatisé : 67 contrôles réussis sur 67.

### Point de reprise

Après publication de 28.2.82 :

1. recharger complètement Firefox ;
2. vérifier le marqueur `28.2.82` ;
3. contrôler les cinq étapes du Cockpit ;
4. contrôler la confirmation des coûts ;
5. contrôler le retrait fictif ;
6. contrôler le Scam Sentinel ;
7. confirmer que les cases restent cliquables et que les états persistent ;
8. poursuivre ensuite la première session pédagogique réelle avec argent imaginaire.

### Statut 28.2.82

- Construction locale : terminée.
- Vérification automatisée : 67/67.
- Validation publique Firefox/Ryzen : à effectuer après upload par Christophe.
- Écriture GitHub par l’assistante : aucune.
- Argent réel ou transaction réelle : aucun.

---

# Mise à jour Build 28.2.83 — Guided Lesson Notebook & Cockpit Restart Lock

## Décision issue des premières leçons réelles

Le premier usage complet du Cockpit a montré que la compréhension de Christophe ne pouvait pas reposer sur un champ limité à 800 caractères ni sur des explications fournies uniquement dans la conversation.

Le Cockpit est donc redémarré sur un nouveau carnet local 28.2.83. Les anciennes données d'apprentissage restent conservées sous leurs anciennes clés. Les simulations 100 € et 1 000 €, positions et preuves ne sont pas réinitialisées.

## Nouvelle architecture de séance

Chaque module possède désormais une leçon intégrée avec :

- définition générale ;
- vocabulaire ;
- exemple ;
- faits actuels de l'interface ;
- règle de sécurité.

La séance utilise ensuite cinq étapes :

1. lire la leçon intégrée ;
2. ouvrir la zone ;
3. effectuer l'exercice fictif ;
4. vérifier le résultat ;
5. écrire une conclusion personnelle.

## Carnet complet

Deux zones séparées :

### Mes notes libres

Destinées aux définitions, observations, questions et explications longues.

### Ce que je retiens

Destinée à la conclusion personnelle de la séance.

Aucune coupe volontaire à 800 caractères n'est appliquée. La sauvegarde est automatique et les sessions terminées sont archivées dans un carnet exportable en Markdown.

## Point de reprise 28.2.83

- publier les quatre fichiers ;
- recharger Firefox ;
- vérifier Build 28.2.83 ;
- recommencer depuis le module 01 ;
- contrôler la persistance d'une note longue après rechargement ;
- terminer la première session et exporter le carnet complet.
