# AGENT-CRYPTO — Rapport de vérification Build 28.2.83

## Identité

- **Build :** 28.2.83
- **Nom :** GUIDED LESSON NOTEBOOK & COCKPIT RESTART LOCK
- **Base :** Build 28.2.82
- **Date :** 5 août 2026
- **Verdict automatisé :** PASS — 66/66 contrôles
- **Validation publique Firefox/Ryzen :** requise après upload par Christophe

## Incident corrigé

L'utilisation réelle du Cockpit a révélé deux défauts importants :

1. le champ unique `Note de la session` possédait `maxlength=800` ;
2. le JavaScript appliquait également `slice(0,800)` avant la sauvegarde.

Une partie des définitions, observations et conclusions pouvait donc être perdue. En outre, le Cockpit indiquait les notions à apprendre sans fournir une leçon autonome suffisamment complète dans l'interface.

## Correction

### Nouveau départ non destructif

Le Cockpit et le parcours 24 mois utilisent de nouvelles clés locales 28.2.83. Les anciennes clés 28.2.81/82 et 28.2.79 ne sont ni supprimées ni écrasées. Les portefeuilles fictifs, positions et preuves de simulation sont conservés.

### Onze leçons intégrées

Chaque module contient désormais directement dans le Cockpit :

- introduction ;
- notions essentielles ;
- exemple pédagogique ;
- données actuelles visibles dans l'interface ;
- règle de sécurité.

### Carnet sans coupe volontaire

Deux champs séparés remplacent l'ancien commentaire :

- `Mes notes libres` ;
- `Ce que je retiens`.

Les deux champs :

- n'ont plus de `maxlength` HTML ;
- ne subissent plus de `slice(0,800)` ;
- sont sauvegardés automatiquement ;
- possèdent un compteur de caractères ;
- sont exportés intégralement dans le Markdown.

Le test unitaire a conservé correctement :

- 12 000 caractères de notes libres ;
- 5 000 caractères de conclusion ;
- 15 000 caractères dans l'historique ;
- 6 000 caractères de conclusion archivée.

### Historique pédagogique

Chaque session terminée est archivée avec :

- leçon ;
- notes complètes ;
- conclusion ;
- faits affichés ;
- étapes ;
- état de simulation ;
- date et identifiant.

Un export `Carnet complet .md` est ajouté.

### Progression affinée

Une session fait évoluer un module progressivement :

`À découvrir → Découvert → Compris → Pratiqué`

Les cinq étapes doivent être validées avant l'archivage.

## Préservation vérifiée

- tous les identifiants HTML nommés du Build 28.2.82 sont conservés ;
- tous les boutons nommés sont conservés ;
- les 17 cases à cocher sont conservées ;
- toutes les fonctions JavaScript nommées de la base sont conservées ;
- aucun nouvel appel `fetch` ;
- aucun nouveau WebSocket ;
- correction carrée des checkboxes préservée ;
- simulations et règles de sécurité inchangées.

## Limite de vérification

La politique du navigateur du conteneur bloque la navigation HTTP locale et `file://`. Aucune validation visuelle Chromium complète n'est revendiquée. Le contrôle final doit être effectué sur GitHub Pages avec Firefox/Ryzen.

## Hashes des fichiers publics

- `app.js` — `d858e095451b5e9c1bde747071056f9b85582cf3fce00aa7af814464ec40a0db`
- `index.html` — `bfb63dd479ae475409bd0ea54b9547e87fcfc7c43385166aaedf54ce027c096e`
- `style.css` — `c5f3550c381c5e85f434ed840ca0d82a48c02345db73948bbe5f070451368beb`
- `version.json` — `7119e2bc7ae82ac641113319ce149950b1e10290fcd45472aa3743cad6ab6f7b`
