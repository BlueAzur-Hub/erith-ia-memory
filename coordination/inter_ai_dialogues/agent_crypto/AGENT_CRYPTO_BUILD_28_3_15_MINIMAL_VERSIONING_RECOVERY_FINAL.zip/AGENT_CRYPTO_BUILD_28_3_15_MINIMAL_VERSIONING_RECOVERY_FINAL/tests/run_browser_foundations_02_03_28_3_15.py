import asyncio, json, re
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent.parent
WEB=ROOT/'public/agent_crypto_erith_ia/web'
RESULTS=[]

def record(name, ok, details=''):
    ok=bool(ok); RESULTS.append({'name':name,'pass':ok,'details':str(details)}); print(f'[browser-02-03-312] {name}: {ok}', flush=True)
    if not ok: raise AssertionError(f'{name}: {details}')

async def logical_visible(locator):
    return await locator.evaluate("""e => { let n=e; while(n){const cs=getComputedStyle(n); if(n.hidden||cs.display==='none'||cs.visibility==='hidden') return false; if(n.tagName==='DETAILS'&&!n.open&&n!==e&&e!==n.querySelector(':scope > summary')) return false; n=n.parentElement;} return true; }""")

async def wait_ready(page):
    html=(WEB/'index.html').read_text(encoding='utf-8')
    html=re.sub(r'<link rel="stylesheet" href="\./style\.css[^>]*>', '', html)
    html=re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>', '', html)
    html=re.sub(r'<script src="\./app\.js[^>]*></script>', '', html)
    await page.set_content(html, wait_until='domcontentloaded', timeout=60000)
    await page.evaluate("""() => { class MemoryStorage { constructor(){this.map=new Map()} get length(){return this.map.size} key(i){return [...this.map.keys()][i]??null} getItem(k){k=String(k);return this.map.has(k)?this.map.get(k):null} setItem(k,v){this.map.set(String(k),String(v))} removeItem(k){this.map.delete(String(k))} clear(){this.map.clear()} } try{Object.defineProperty(window,'localStorage',{value:new MemoryStorage(),configurable:true})}catch{} try{Object.defineProperty(window,'sessionStorage',{value:new MemoryStorage(),configurable:true})}catch{} }""")
    await page.add_style_tag(content=(WEB/'style.css').read_text(encoding='utf-8'))
    await page.add_script_tag(content=(WEB/'app.js').read_text(encoding='utf-8'))
    await page.wait_for_timeout(1400)
    await page.evaluate("""() => {
      window.__fakeLearningDbRecord=null;
      atlasLearningDbWriteVerified=async record=>{const normalized=atlasLearningNormalizeNotebook(atlasLearningClone(record));window.__fakeLearningDbRecord=atlasLearningClone(normalized);return {ok:true,backend:'BrowserMemoryVerifiedReadBack',bytes:JSON.stringify(normalized).length,digest:'browser-memory',record:atlasLearningClone(normalized)}};
      atlasLearningDbReadRecord=async()=>window.__fakeLearningDbRecord?atlasLearningClone(window.__fakeLearningDbRecord):null;
      atlasLearningStorageReady=true; atlasLearningStorageReadBlocked=false; atlasLearningStorageResetting=false; atlasLearningStorageInitPromise=Promise.resolve(atlasLearningNotebookCache);
      if(typeof atlasV2ApplyMode==='function') atlasV2ApplyMode('intermediate');
    }""")

async def seed_live(page):
    await page.evaluate("""() => {
      state.liveOk=true; state.mainSource='CoinGecko USD · snapshot pédagogique'; state.timestamp=new Date().toISOString(); state.sourceLock={valid:true,mode:'direct',timestamp:state.timestamp};
      const btc={id:'bitcoin',name:'Bitcoin',symbol:'BTC',rank:1,price:55876.33,priceEur:55876.33,change24h:0.30,change7d:2.10,marketCap:1100000000000,volume24h:20000000000,image:'',sparkline:[55200,55400,55876.33],source:'coingecko'};
      const fillers=Array.from({length:249},(_,i)=>({id:`asset-${i+2}`,name:`Asset ${i+2}`,symbol:`A${i+2}`,rank:i+2,price:1+i/100,priceEur:1+i/100,change24h:0,change7d:0,marketCap:1000000,volume24h:10000,image:'',sparkline:[1,1.01],source:'coingecko'}));
      state.coins=[btc,...fillers];
      if(els.sourceName) els.sourceName.textContent=state.mainSource; if(els.sourceTime) els.sourceTime.textContent='06/08/2026 04:02:00'; if(els.liveStatus) els.liveStatus.textContent='Prix live test · 250/250';
      try{renderMarketTable()}catch{}; renderSimulation();
    }""")

async def fresh_spot(page):
    await page.evaluate("""async()=>{
      atlasLearningNotebookCache=atlasLearningSeedFromLocalStorage(); atlasLearningNotebookCache.history=[]; atlasLearningNotebookCache.roadmap=atlasLearningNormalizeRoadmap(null);
      atlasLearningNotebookCache.roadmap.modules.market.status='practiced'; atlasLearningNotebookCache.roadmap.modules.market.updated_at=new Date().toISOString();
      atlasLearningNotebookCache.history=[{session_id:'MARKET-ARCHIVE',module_key:'market',module_title:'01 · Marché et données',completed_at:new Date().toISOString(),steps:{read:true,open:true,practice:true,verify:true,note:true},takeaway:'Synthèse Module 01'}];
      const c=defaultLearningCockpitState(); c.module_key='spot'; c.foundation_path_build=ATLAS_FOUNDATION_LEARNING_BUILD; atlasLearningNotebookCache.cockpit=atlasLearningNormalizeCockpit(c,1);
      await atlasLearningPersistNow('browser_311_fresh_spot'); renderExpertRoadmap(); renderLearningJourneyCockpit(); learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    await page.wait_for_timeout(300)
    await seed_live(page)

async def click_primary(page): await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')

async def run_flow(page):
    errors=[]; page.on('pageerror', lambda exc: errors.append(str(exc)))
    await fresh_spot(page)
    record('module02_fresh_0_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('0/5'))
    record('module02_title','02 · Spot' in (await page.locator('#learningCockpitModule').text_content()))
    await click_primary(page); record('module02_open_lesson_no_validation',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('0/5'))
    record('module02_post_lesson_button_visible',await logical_visible(page.locator('#btnMarkLessonRead')))
    await page.locator('#btnMarkLessonRead').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.read===true")
    record('module02_step1_1_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('1/5'))
    record('module02_step2_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Commencer l’exercice Bid / Ask')
    await click_primary(page)
    await page.locator('[data-foundation-action="spot_ask_60020"]').evaluate('(e)=>e.click()'); await page.wait_for_timeout(100)
    record('module02_wrong_ask_does_not_advance',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('1/5'))
    await page.locator('[data-foundation-action="spot_ask_60010"]').evaluate('(e)=>e.click()')
    await page.locator('[data-foundation-action="spot_bid_59990"]').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.open===true")
    record('module02_bid_ask_to_2_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('2/5'))
    record('module02_spread_visible','20 €' in (await page.locator('[data-foundation-stage="2"]').text_content()))
    await click_primary(page)
    await page.locator('[data-foundation-action="spot_market_wrong"]').evaluate('(e)=>e.click()'); await page.wait_for_timeout(80)
    record('module02_wrong_market_no_advance',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('2/5'))
    await page.locator('[data-foundation-action="spot_market_correct"]').evaluate('(e)=>e.click()')
    await page.locator('[data-foundation-action="spot_limit_correct"]').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.practice===true")
    record('module02_market_limit_to_3_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('3/5'))
    await page.evaluate("saveLearningSessionNotes('Texte très long qui ne doit jamais valider le module deux malgré sa longueur et ses nombreuses phrases.', 'takeaway')")
    record('module02_free_text_cannot_validate',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('3/5'))
    record('module02_takeaway_hidden',await page.locator('#learningTakeawayField').evaluate("e=>e.hidden||getComputedStyle(e).display==='none'"))
    record('module02_step4_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Créer la position BTC fictive de 50 €')
    await click_primary(page); await page.wait_for_function("loadLearningCockpitState().steps.verify===true",timeout=20000)
    record('module02_position_to_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    c=await page.evaluate('loadLearningCockpitState()')
    record('module02_position_details_recorded',bool(c.get('practice_evidence',{}).get('spot_position_details')),json.dumps(c.get('practice_evidence',{}),ensure_ascii=False)[:700])
    text5=await page.locator('[data-foundation-stage="5"]').text_content()
    spot_summary_before=text5
    await page.evaluate("""() => {
      if(state.sim.positions.BTC){state.sim.positions.BTC.avgPrice=1234;state.sim.positions.BTC.qty=99;state.sim.positions.BTC.invested=999;}
      state.sim.cash=1; if(state.coins[0]) state.coins[0].price=999999;
      renderLearningJourneyCockpit(); learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    spot_summary_after=await page.locator('[data-foundation-stage="5"]').text_content()
    record('module02_summary_stable_after_live_position_mutation',spot_summary_before==spot_summary_after,spot_summary_after[:700])
    text5=spot_summary_after
    record('module02_summary_teaches_position','position de' in text5 and 'ordre limite' in text5.lower(),text5[:600])
    await click_primary(page)
    await page.locator('[data-foundation-action="spot_limit_guarantee_yes"]').evaluate('(e)=>e.click()'); record('module02_wrong_yes_stays_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    await page.locator('[data-foundation-action="spot_limit_guarantee_no"]').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.note===true")
    record('module02_guided_no_to_5_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('5/5'))
    c=await page.evaluate('loadLearningCockpitState()'); record('module02_guided_evidence',c.get('practice_evidence',{}).get('spot_guided_conclusion') is True)
    record('module02_archive_enabled',not await page.locator('#btnCompleteLearningSession').is_disabled())
    await page.locator('#btnCompleteLearningSession').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().completed_at!==null",timeout=20000)
    record('module02_archive_panel_visible',await logical_visible(page.locator('#learningCompletionPanel')))
    persisted=await page.evaluate('atlasLearningDbReadRecord()'); spot=(persisted or {}).get('roadmap',{}).get('modules',{}).get('spot',{})
    record('module02_roadmap_practiced',spot.get('status')=='practiced',json.dumps(spot,ensure_ascii=False))
    roadmap_text=await page.locator('#learningCockpitModules').text_content(); record('module02_progress_2_11','2/11' in roadmap_text and '2 pratiqué' in roadmap_text,roadmap_text)

    await page.locator('#btnLearningNextModule').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().module_key==='risk'")
    record('module03_only_after_explicit_button','03 · Frais' in (await page.locator('#learningCockpitModule').text_content()))
    await seed_live(page)
    record('module03_fresh_0_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('0/5'))
    await click_primary(page); await page.locator('#btnMarkLessonRead').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.read===true")
    record('module03_step1_1_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('1/5'))
    record('module03_step2_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Charger l’exemple école')
    await click_primary(page); await page.wait_for_function("loadLearningCockpitState().steps.open===true")
    record('module03_costs_to_2_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('2/5'))
    risk2=await page.locator('[data-foundation-stage="2"]').text_content(); record('module03_costs_060_visible','0.60 %' in risk2 or '0,60 %' in risk2,risk2)
    record('module03_step3_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Créer la position BTC fictive de 50 €')
    await click_primary(page); await page.wait_for_function("loadLearningCockpitState().steps.practice===true",timeout=20000)
    record('module03_position_to_3_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('3/5'))
    c=await page.evaluate('loadLearningCockpitState()'); record('module03_position_details_recorded',bool(c.get('practice_evidence',{}).get('risk_position_details')))
    record('module03_step4_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Ouvrir les scénarios −3 % et +5 %')
    await click_primary(page)
    await page.locator('[data-foundation-action="risk_scenario_minus3"]').evaluate('(e)=>e.click()'); await page.wait_for_timeout(120)
    record('module03_minus3_only_stays_3_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('3/5'))
    await page.locator('[data-foundation-action="risk_scenario_plus5"]').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.verify===true")
    record('module03_both_scenarios_to_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    c=await page.evaluate('loadLearningCockpitState()')
    risk_results=c.get('practice_evidence',{}).get('risk_scenario_results',{})
    minus=risk_results.get('-3',{}); plus=risk_results.get('5',{})
    record('module03_minus3_exact',abs(float(minus.get('gross_pnl_eur',999))+1.5)<1e-9 and abs(float(minus.get('net_pnl_eur',999))+1.8)<1e-9,json.dumps(minus,ensure_ascii=False))
    record('module03_plus5_exact',abs(float(plus.get('gross_pnl_eur',999))-2.5)<1e-9 and abs(float(plus.get('net_pnl_eur',999))-2.2)<1e-9,json.dumps(plus,ensure_ascii=False))
    record('module03_entry_anchored_model',minus.get('model')=='entry_anchored_simplified' and plus.get('model')=='entry_anchored_simplified',json.dumps(risk_results,ensure_ascii=False))
    risk4=await page.locator('[data-foundation-stage="4"]').text_content()
    risk5_before=await page.locator('[data-foundation-stage="5"]').text_content()
    await page.evaluate("""() => {
      if(state.sim.positions.BTC){state.sim.positions.BTC.avgPrice=777;state.sim.positions.BTC.qty=77;state.sim.positions.BTC.invested=777;}
      state.sim.cash=7; if(state.coins[0]) state.coins[0].price=888888;
      els.simBuyFeePct.value='4'; els.simSellFeePct.value='3'; els.simEntryImpactPct.value='2'; els.simExitImpactPct.value='1';
      renderLearningJourneyCockpit(); learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    risk4_after=await page.locator('[data-foundation-stage="4"]').text_content(); risk5_after=await page.locator('[data-foundation-stage="5"]').text_content()
    record('module03_scenarios_stable_after_market_cost_mutation',risk4==risk4_after and risk5_before==risk5_after,risk4_after[:700]+' | '+risk5_after[:900])
    record('module03_frozen_roundtrip_060','0.60 %' in risk5_after or '0,60 %' in risk5_after,risk5_after[:900])
    record('module03_brut_net_visible','brut' in risk4.lower() and 'net' in risk4.lower(),risk4[:500])
    await page.evaluate("saveLearningSessionNotes('Encore un texte long qui ne doit pas valider la conclusion guidée du module trois.', 'takeaway')")
    record('module03_free_text_cannot_validate',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    record('module03_step5_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Comprendre le résultat net')
    await click_primary(page)
    text5r=await page.locator('[data-foundation-stage="5"]').text_content(); record('module03_summary_teaches_brut_net','résultat net' in text5r.lower() and 'résultat brut' in text5r.lower(),text5r[:700])
    await page.locator('[data-foundation-action="risk_costs_reduce_no"]').evaluate('(e)=>e.click()'); record('module03_wrong_no_stays_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    await page.locator('[data-foundation-action="risk_costs_reduce_yes"]').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().steps.note===true")
    record('module03_guided_yes_to_5_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('5/5'))
    c=await page.evaluate('loadLearningCockpitState()'); record('module03_guided_evidence',c.get('practice_evidence',{}).get('risk_guided_conclusion') is True)
    risk_takeaway=c.get('takeaway','')
    record('module03_takeaway_keeps_frozen_results','-1,50' in risk_takeaway and '-1,80' in risk_takeaway and '+2,50' in risk_takeaway and '+2,20' in risk_takeaway and ('0.60 %' in risk_takeaway or '0,60 %' in risk_takeaway),risk_takeaway)
    risk_session_id=c.get('session_id')
    await page.locator('#btnCompleteLearningSession').evaluate('(e)=>e.click()'); await page.wait_for_function("loadLearningCockpitState().completed_at!==null",timeout=20000)
    persisted=await page.evaluate('atlasLearningDbReadRecord()'); risk=(persisted or {}).get('roadmap',{}).get('modules',{}).get('risk',{})
    risk_archive=next((x for x in (persisted or {}).get('history',[]) if x.get('session_id')==risk_session_id),{})
    archived_results=risk_archive.get('practice_evidence',{}).get('risk_scenario_results',{})
    record('module03_archive_keeps_frozen_results',risk_archive.get('takeaway')==risk_takeaway and archived_results.get('-3',{}).get('model')=='entry_anchored_simplified' and abs(float(archived_results.get('5',{}).get('net_pnl_eur',999))-2.2)<1e-9,json.dumps(risk_archive,ensure_ascii=False)[:1400])
    record('module03_roadmap_practiced',risk.get('status')=='practiced',json.dumps(risk,ensure_ascii=False))
    roadmap_text=await page.locator('#learningCockpitModules').text_content(); record('module03_progress_3_11','3/11' in roadmap_text and '3 pratiqué' in roadmap_text,roadmap_text)
    history=(persisted or {}).get('history',[]); record('three_archives_persisted',len([x for x in history if x.get('completed_at')])==3,json.dumps(history,ensure_ascii=False)[:800])
    notice=await page.locator('#learningMigrationNoticeText').text_content(); record('indexeddb_archive_count_message','3 séances archivées' in notice,notice)
    critical=[e for e in errors if 'ResizeObserver loop' not in e and 'Access is denied for this document' not in e]
    record('modules02_03_no_critical_pageerror',not critical,json.dumps(critical,ensure_ascii=False))

async def main():
    async with async_playwright() as p:
      browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
      context=await browser.new_context(); page=await context.new_page(); await wait_ready(page); await run_flow(page); await browser.close()
    out={'passed':sum(x['pass'] for x in RESULTS),'total':len(RESULTS),'results':RESULTS,'persistence_backend':'BrowserMemoryVerifiedReadBack','limitation':'Chromium DOM and verified read-back adapter; final Firefox public-origin confirmation remains external.'}
    (ROOT/'BROWSER_FOUNDATIONS_02_03_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"[browser-02-03-312] TOTAL {out['passed']}/{out['total']}")

if __name__=='__main__': asyncio.run(main())
