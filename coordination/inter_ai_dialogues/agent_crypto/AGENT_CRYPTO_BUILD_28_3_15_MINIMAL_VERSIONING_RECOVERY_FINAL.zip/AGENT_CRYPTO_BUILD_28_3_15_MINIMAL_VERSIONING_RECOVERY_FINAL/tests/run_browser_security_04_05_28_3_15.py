import asyncio,json,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent; WEB=ROOT/'public/agent_crypto_erith_ia/web'; RESULTS=[]
def record(name,ok,details=''):
    ok=bool(ok); RESULTS.append({'name':name,'pass':ok,'details':str(details)}); print(f'[browser-04-05-312] {name}: {ok}',flush=True)
    if not ok: raise AssertionError(f'{name}: {details}')
async def logical_visible(locator):
    return await locator.evaluate("""e=>{let n=e;while(n){const cs=getComputedStyle(n);if(n.hidden||cs.display==='none'||cs.visibility==='hidden')return false;if(n.tagName==='DETAILS'&&!n.open&&n!==e&&e!==n.querySelector(':scope > summary'))return false;n=n.parentElement;}return true;}""")
async def wait_ready(page):
    html=(WEB/'index.html').read_text(encoding='utf-8')
    html=re.sub(r'<link rel="stylesheet" href="\./style\.css[^>]*>','',html)
    html=re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>','',html)
    html=re.sub(r'<script src="\./app\.js[^>]*></script>','',html)
    await page.set_content(html,wait_until='domcontentloaded',timeout=60000)
    await page.evaluate("""()=>{class MemoryStorage{constructor(){this.map=new Map()}get length(){return this.map.size}key(i){return [...this.map.keys()][i]??null}getItem(k){k=String(k);return this.map.has(k)?this.map.get(k):null}setItem(k,v){this.map.set(String(k),String(v))}removeItem(k){this.map.delete(String(k))}clear(){this.map.clear()}}try{Object.defineProperty(window,'localStorage',{value:new MemoryStorage(),configurable:true})}catch{}try{Object.defineProperty(window,'sessionStorage',{value:new MemoryStorage(),configurable:true})}catch{}}""")
    await page.add_style_tag(content=(WEB/'style.css').read_text(encoding='utf-8'))
    await page.add_script_tag(content=(WEB/'app.js').read_text(encoding='utf-8'))
    await page.wait_for_timeout(1400)
    await page.evaluate("""()=>{
      window.__fakeLearningDbRecord=null;
      atlasLearningDbWriteVerified=async record=>{const normalized=atlasLearningNormalizeNotebook(atlasLearningClone(record));window.__fakeLearningDbRecord=atlasLearningClone(normalized);return {ok:true,backend:'BrowserMemoryVerifiedReadBack',bytes:JSON.stringify(normalized).length,digest:'browser-memory',record:atlasLearningClone(normalized)}};
      atlasLearningDbReadRecord=async()=>window.__fakeLearningDbRecord?atlasLearningClone(window.__fakeLearningDbRecord):null;
      atlasLearningStorageReady=true; atlasLearningStorageReadBlocked=false; atlasLearningStorageResetting=false;atlasLearningStorageInitPromise=Promise.resolve(atlasLearningNotebookCache);
      if(typeof atlasV2ApplyMode==='function')atlasV2ApplyMode('intermediate');
    }""")
async def seed_account(page):
    await page.evaluate("""async()=>{
      atlasLearningNotebookCache=atlasLearningSeedFromLocalStorage();
      atlasLearningNotebookCache.history=['market','spot','risk'].map((key,i)=>({session_id:`ARCH-${key}`,module_key:key,module_title:`0${i+1}`,completed_at:new Date().toISOString(),steps:{read:true,open:true,practice:true,verify:true,note:true},takeaway:`Archive ${key}`}));
      atlasLearningNotebookCache.roadmap=atlasLearningNormalizeRoadmap(null);
      ['market','spot','risk'].forEach(key=>{atlasLearningNotebookCache.roadmap.modules[key].status='practiced';atlasLearningNotebookCache.roadmap.modules[key].updated_at=new Date().toISOString()});
      const c=defaultLearningCockpitState();c.module_key='account';c.foundation_path_build=ATLAS_FOUNDATION_LEARNING_BUILD;atlasLearningNotebookCache.cockpit=atlasLearningNormalizeCockpit(c,3);
      await atlasLearningPersistNow('browser_311_fresh_account');renderExpertRoadmap();renderLearningJourneyCockpit();learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    await page.wait_for_timeout(250)
async def click_primary(page): await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
async def progress(page): return (await page.locator('#learningSessionProgress').text_content()).strip()
async def run_flow(page):
    errors=[]; page.on('pageerror',lambda exc:errors.append(str(exc)))
    await seed_account(page)
    record('module04_fresh_0_5',(await progress(page)).startswith('0/5'))
    record('module04_title','04 · Sécurité du compte' in (await page.locator('#learningCockpitModule').text_content()))
    record('module04_path_visible','SOCLE DU COMPTE' in (await page.locator('#learningFoundationRoute').text_content()))
    await click_primary(page);record('module04_lesson_open_no_advance',(await progress(page)).startswith('0/5'))
    record('module04_lesson_validation_visible',await logical_visible(page.locator('#btnMarkLessonRead')))
    await page.locator('#btnMarkLessonRead').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.read===true")
    record('module04_step1',(await progress(page)).startswith('1/5'))
    record('module04_primary_step2',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Choisir le socle du compte')
    await click_primary(page)
    await page.locator('[data-foundation-action="account_stack_weak"]').evaluate('(e)=>e.click()');record('module04_weak_stack_refused',(await progress(page)).startswith('1/5'))
    await page.locator('[data-foundation-action="account_stack_strong"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.open===true")
    record('module04_step2',(await progress(page)).startswith('2/5'))
    await click_primary(page)
    await page.locator('[data-foundation-action="account_support_comply"]').evaluate('(e)=>e.click()');record('module04_fake_support_compliance_refused',(await progress(page)).startswith('2/5'))
    await page.locator('[data-foundation-action="account_support_stop"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.practice===true")
    record('module04_step3',(await progress(page)).startswith('3/5'))
    await page.evaluate("saveLearningSessionNotes('Texte libre très long qui ne doit pas valider la sécurité du compte sans preuve guidée.', 'takeaway')")
    record('module04_free_text_no_advance',(await progress(page)).startswith('3/5'))
    await click_primary(page);await page.locator('[data-foundation-action="account_validate_plan"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.verify===true")
    record('module04_step4',(await progress(page)).startswith('4/5'))
    c=await page.evaluate('loadLearningCockpitState()')
    record('module04_plan_frozen',c['practice_evidence']['account_security_plan']['real_account_modified'] is False,json.dumps(c['practice_evidence'],ensure_ascii=False))
    await click_primary(page)
    await page.locator('[data-foundation-action="account_support_secret_yes"]').evaluate('(e)=>e.click()');record('module04_wrong_yes_stays_4_5',(await progress(page)).startswith('4/5'))
    await page.locator('[data-foundation-action="account_support_secret_no"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.note===true")
    record('module04_step5',(await progress(page)).startswith('5/5'))
    record('module04_takeaway_guided','Aucun secret réel' in (await page.evaluate('loadLearningCockpitState().takeaway')))
    await page.locator('#btnCompleteLearningSession').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().completed_at!==null")
    record('module04_archived',await logical_visible(page.locator('#learningCompletionPanel')))
    record('module04_roadmap_practiced',(await page.evaluate("loadExpertRoadmap().modules.account.status"))=='practiced')
    record('module04_next_wallet','module 05' in (await page.locator('#btnLearningNextModule').text_content()).lower())
    await page.locator('#btnLearningNextModule').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().module_key==='wallet'")
    record('module05_fresh_0_5',(await progress(page)).startswith('0/5'))
    record('module05_title','05 · Portefeuilles et retraits' in (await page.locator('#learningCockpitModule').text_content()))
    await click_primary(page);await page.locator('#btnMarkLessonRead').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.read===true")
    record('module05_step1',(await progress(page)).startswith('1/5'))
    await click_primary(page)
    await page.locator('[data-foundation-action="wallet_network_ethereum"]').evaluate('(e)=>e.click()');record('module05_wrong_network_refused',(await progress(page)).startswith('1/5'))
    await page.locator('[data-foundation-action="wallet_network_bitcoin"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.open===true")
    record('module05_step2',(await progress(page)).startswith('2/5'))
    await click_primary(page)
    await page.locator('[data-foundation-action="wallet_destination_third_party"]').evaluate('(e)=>e.click()');record('module05_third_party_refused',(await progress(page)).startswith('2/5'))
    await page.locator('[data-foundation-action="wallet_destination_independent"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.practice===true")
    record('module05_step3',(await progress(page)).startswith('3/5'))
    await click_primary(page);await page.locator('[data-foundation-action="wallet_validate_test_trace"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.verify===true")
    record('module05_step4',(await progress(page)).startswith('4/5'))
    c=await page.evaluate('loadLearningCockpitState()')
    record('module05_no_real_address',c['practice_evidence']['wallet_network_match']['real_address_used'] is False and c['practice_evidence']['wallet_destination_method']['real_address_used'] is False,json.dumps(c['practice_evidence'],ensure_ascii=False))
    record('module05_no_real_transaction',c['practice_evidence']['wallet_test_trace']['real_transaction'] is False)
    await click_primary(page)
    await page.locator('[data-foundation-action="wallet_network_mismatch_yes"]').evaluate('(e)=>e.click()');record('module05_wrong_yes_stays_4_5',(await progress(page)).startswith('4/5'))
    await page.locator('[data-foundation-action="wallet_network_mismatch_no"]').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().steps.note===true")
    record('module05_step5',(await progress(page)).startswith('5/5'))
    await page.locator('#btnCompleteLearningSession').evaluate('(e)=>e.click()');await page.wait_for_function("loadLearningCockpitState().completed_at!==null")
    record('module05_archived',await logical_visible(page.locator('#learningCompletionPanel')))
    record('module05_roadmap_practiced',(await page.evaluate("loadExpertRoadmap().modules.wallet.status"))=='practiced')
    history=await page.evaluate('loadLearningHistory()')
    record('history_01_05_preserved',len(history)==5,[x.get('module_key') for x in history])
    statuses=await page.evaluate("Object.fromEntries(['market','spot','risk','account','wallet'].map(k=>[k,loadExpertRoadmap().modules[k].status]))")
    record('previous_modules_preserved',all(v=='practiced' for v in statuses.values()),statuses)
    record('no_page_errors',not errors,errors)
async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu']);page=await browser.new_page(viewport={'width':1600,'height':1200});await wait_ready(page);await run_flow(page);await browser.close()
    out={'build':'28.3.15','passed':sum(x['pass'] for x in RESULTS),'total':len(RESULTS),'results':RESULTS}
    (ROOT/'BROWSER_SECURITY_04_05_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'[browser-04-05-312] TOTAL {out["passed"]}/{out["total"]}')
    if out['passed']!=out['total']: raise SystemExit(1)
if __name__=='__main__': asyncio.run(main())
