import asyncio, json, re
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / 'public/agent_crypto_erith_ia/web'
RESULTS = []

def record(name, ok, details=''):
    ok = bool(ok)
    RESULTS.append({'name': name, 'pass': ok, 'details': str(details)})
    print(f'[browser-persistence-contract-313] {name}: {ok}', flush=True)
    if not ok:
        raise AssertionError(f'{name}: {details}')

async def boot(page):
    html = (WEB / 'index.html').read_text(encoding='utf-8')
    html = re.sub(r'<link rel="stylesheet" href="\./style\.css[^>]*>', '', html)
    html = re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>', '', html)
    html = re.sub(r'<script src="\./app\.js[^>]*></script>', '', html)
    await page.set_content(html, wait_until='domcontentloaded', timeout=60000)
    await page.evaluate("""() => {
      class MemoryStorage {
        constructor(){ this.map = new Map(); }
        get length(){ return this.map.size; }
        key(i){ return [...this.map.keys()][i] ?? null; }
        getItem(k){ k=String(k); return this.map.has(k) ? this.map.get(k) : null; }
        setItem(k,v){ this.map.set(String(k), String(v)); }
        removeItem(k){ this.map.delete(String(k)); }
        clear(){ this.map.clear(); }
      }
      try { Object.defineProperty(window, 'localStorage', {value:new MemoryStorage(), configurable:true}); } catch {}
      try { Object.defineProperty(window, 'sessionStorage', {value:new MemoryStorage(), configurable:true}); } catch {}
      window.confirm = () => true;
    }""")
    await page.add_style_tag(content=(WEB / 'style.css').read_text(encoding='utf-8'))
    await page.add_script_tag(content=(WEB / 'app.js').read_text(encoding='utf-8'))
    await page.wait_for_timeout(1300)
    await page.evaluate("""() => {
      window.__contractDbRecord = null;
      window.__contractWriteEvents = [];
      window.__contractFailNext = null;
      atlasLearningDbReadRecord = async () => window.__contractDbRecord ? atlasLearningClone(window.__contractDbRecord) : null;
      atlasLearningDbWriteVerified = async (record, options={}) => {
        const reason = String(options.reason || 'save');
        window.__contractWriteEvents.push('start:' + reason);
        if (reason === 'queue_first') await new Promise(r => setTimeout(r, 80));
        else await new Promise(r => setTimeout(r, 12));
        if (window.__contractFailNext) {
          const failure = window.__contractFailNext;
          window.__contractFailNext = null;
          window.__contractWriteEvents.push('fail:' + reason);
          return {...failure, ok:false, backend:'BrowserPersistenceContract', reason};
        }
        const payload = atlasLearningNotebookPayload(record);
        const now = new Date().toISOString();
        payload.persistence = {
          ...(payload.persistence || {}),
          schema:ATLAS_LEARNING_PERSISTENCE_SCHEMA,
          last_attempt_at:now,
          last_verified_at:now,
          last_reason:reason,
          last_error:null
        };
        const digest = atlasLearningNotebookDigest(payload);
        payload.persistence.last_verified_digest = digest;
        window.__contractDbRecord = atlasLearningClone(payload);
        window.__contractWriteEvents.push('end:' + reason);
        return {ok:true, backend:'BrowserPersistenceContract', bytes:JSON.stringify(payload).length, digest, reason, verified_at:now, record:atlasLearningClone(payload)};
      };
      atlasLearningStorageReady = true;
      atlasLearningStorageReadBlocked = false;
      atlasLearningStorageResetting = false;
      atlasLearningStorageInitPromise = Promise.resolve(atlasLearningNotebookCache);
      atlasLearningStorageWriteChain = Promise.resolve();
      atlasLearningStorageRevision = 0;
      if (typeof atlasV2ApplyMode === 'function') atlasV2ApplyMode('intermediate');
    }""")

async def seed_account(page):
    return await page.evaluate("""async () => {
      const roadmap = atlasLearningNormalizeRoadmap(null);
      ['market','spot','risk'].forEach(key => { roadmap.modules[key].status='understood'; roadmap.modules[key].updated_at=new Date().toISOString(); });
      const cockpit = defaultLearningCockpitState();
      cockpit.module_key='account';
      cockpit.session_id='PERSIST-CONTRACT-ACCOUNT';
      cockpit.steps={read:true,open:true,practice:true,verify:false,note:false};
      cockpit.notes_free='état initial';
      cockpit.practice_evidence={account_security_stack:{verified:true},account_support_response:{verified:true}};
      cockpit.foundation_path_build=foundationPathBuildForModule('account');
      atlasLearningNotebookCache=atlasLearningNormalizeNotebook({cockpit,history:[],roadmap,recovery:{status:'contract'},migration:{},reset:{}});
      atlasLearningStorageRevision += 1;
      const result=await atlasLearningPersistNow('seed_account');
      renderLearningJourneyCockpit();
      return {result,record:await atlasLearningDbReadRecord()};
    }""")

async def run(page):
    seeded = await seed_account(page)
    record('seed_write_verified', seeded['result']['ok'] is True, seeded['result'])
    rec = seeded['record']
    record('notebook_schema_v2_runtime', rec['schema'] == 'agent_crypto_learning_notebook_indexeddb_v2', rec['schema'])
    versions = rec.get('versions', {})
    record('versions_are_separated', versions.get('notebook') == 2 and versions.get('cockpit') == 2 and versions.get('history') == 1 and versions.get('roadmap') == 1, versions)
    record('module_pedagogy_versions_present', len(versions.get('module_pedagogy', {})) == 11, versions.get('module_pedagogy'))
    record('simulation_store_declared_separate', versions.get('simulation') == 'separate_local_store', versions)
    record('verified_digest_persisted', bool(rec.get('persistence', {}).get('last_verified_digest')), rec.get('persistence'))
    record('verified_digest_matches_runtime', await page.evaluate("atlasLearningNotebookDigest(window.__contractDbRecord)===window.__contractDbRecord.persistence.last_verified_digest"))

    queue = await page.evaluate("""async () => {
      window.__contractWriteEvents=[];
      let c=loadLearningCockpitState(); c.notes_free='QUEUE-FIRST'; atlasLearningNotebookCache.cockpit=c; atlasLearningStorageRevision+=1;
      const p1=atlasLearningPersistNow('queue_first');
      c=atlasLearningClone(c); c.notes_free='QUEUE-SECOND-FINAL'; atlasLearningNotebookCache.cockpit=c; atlasLearningStorageRevision+=1;
      const p2=atlasLearningPersistNow('queue_second');
      await Promise.all([p1,p2]);
      return {events:[...window.__contractWriteEvents],stored:window.__contractDbRecord.cockpit.notes_free,cache:atlasLearningNotebookCache.cockpit.notes_free,last:window.__atlasLearningNotebookPersist};
    }""")
    record('writes_are_serialized', queue['events'] == ['start:queue_first','end:queue_first','start:queue_second','end:queue_second'], queue)
    record('latest_queued_snapshot_wins', queue['stored'] == 'QUEUE-SECOND-FINAL', queue)
    record('late_old_write_does_not_replace_cache', queue['cache'] == 'QUEUE-SECOND-FINAL', queue)
    record('latest_write_has_verified_result', queue['last']['ok'] is True and queue['last']['reason'] == 'queue_second', queue['last'])

    failure = await page.evaluate("""async () => {
      const before=atlasLearningClone(window.__contractDbRecord);
      let c=loadLearningCockpitState(); c.notes_free='UNSAVED-NEW-STATE'; atlasLearningNotebookCache.cockpit=c; atlasLearningStorageRevision+=1;
      window.__contractFailNext={error_code:'LEARNING-STORAGE-QUOTA',error_name:'QuotaExceededError',error_message:'quota exceeded',phase:'write',quota:true};
      const result=await atlasLearningPersistNow('forced_quota_failure');
      return {result,before:before.cockpit.notes_free,stored:window.__contractDbRecord.cockpit.notes_free,cache:atlasLearningNotebookCache.cockpit.notes_free,title:document.getElementById('learningMigrationNoticeTitle')?.textContent||'',text:document.getElementById('learningMigrationNoticeText')?.textContent||''};
    }""")
    record('failed_write_is_reported', failure['result']['ok'] is False and failure['result']['error_code'] == 'LEARNING-STORAGE-QUOTA', failure)
    record('failed_write_preserves_previous_record', failure['stored'] == failure['before'] == 'QUEUE-SECOND-FINAL', failure)
    record('failed_write_does_not_claim_success', failure['title'] == 'Carnet non sauvegardé', failure)
    record('failure_notice_says_no_automatic_deletion', 'aucune donnée n’a été effacée automatiquement' in failure['text'].lower(), failure['text'])

    # Restore coherent cache from persisted record before integrity diagnosis.
    diagnosis = await page.evaluate("""async () => {
      atlasLearningNotebookCache=atlasLearningNormalizeNotebook(window.__contractDbRecord);
      const before={id:atlasLearningNotebookCache.cockpit.session_id,history:atlasLearningNotebookCache.history.length,notes:atlasLearningNotebookCache.cockpit.notes_free,writes:window.__contractWriteEvents.length};
      const report=await verifyLearningIntegrity();
      const after={id:atlasLearningNotebookCache.cockpit.session_id,history:atlasLearningNotebookCache.history.length,notes:atlasLearningNotebookCache.cockpit.notes_free,writes:window.__contractWriteEvents.length};
      return {report,before,after,panelHidden:document.getElementById('learningIntegrityPanel').hidden,badge:document.getElementById('learningIntegrityBadge').textContent,exportDisabled:document.getElementById('btnExportLearningIntegrity').disabled};
    }""")
    report = diagnosis['report']
    record('integrity_report_schema', report['schema'] == 'agent_crypto_learning_integrity_report_v2', report['schema'])
    record('integrity_report_ok', report['status'] == 'ok' and not report['failures'], json.dumps(report, ensure_ascii=False)[:1400])
    record('integrity_digest_verified', report['persistence']['digest_verified'] is True, report['persistence'])
    record('integrity_checks_step_order', report['cockpit']['step_order_valid'] is True, report['cockpit'])
    record('integrity_checks_simulation_separation', report['separation']['simulation_inside_notebook'] is False, report['separation'])
    record('integrity_ui_is_visible', diagnosis['panelHidden'] is False and diagnosis['badge'] == 'INTÈGRE', diagnosis)
    record('integrity_export_is_enabled', diagnosis['exportDisabled'] is False, diagnosis)
    record('integrity_check_is_non_destructive', diagnosis['before']['id'] == diagnosis['after']['id'] and diagnosis['before']['history'] == diagnosis['after']['history'] and diagnosis['before']['notes'] == diagnosis['after']['notes'], diagnosis)
    record('integrity_check_is_read_only', diagnosis['before']['writes'] == diagnosis['after']['writes'], diagnosis)

    corrupt = await page.evaluate("""() => {
      const bad=atlasLearningClone(window.__contractDbRecord);
      bad.cockpit.steps={read:true,open:false,practice:true,verify:false,note:false};
      bad.history=[{session_id:'DUP',module_key:'market',completed_at:new Date().toISOString(),steps:{read:true,open:true,practice:true,verify:true,note:true}},{session_id:'DUP',module_key:'spot',completed_at:new Date().toISOString(),steps:{read:true,open:true,practice:true,verify:true,note:true}}];
      bad.simulation={positions:[1]};
      bad.persistence.last_verified_digest=atlasLearningNotebookDigest(bad);
      return atlasLearningIntegrityReportFromRecord(bad);
    }""")
    codes = [x['code'] for x in corrupt['failures']]
    record('diagnostic_detects_step_gap', 'LEARNING-STEP-ORDER' in codes, codes)
    record('diagnostic_detects_duplicate_archive', 'LEARNING-ARCHIVE-DUPLICATE' in codes, codes)
    record('diagnostic_detects_simulation_contamination', 'LEARNING-SIMULATION-SEPARATION' in codes, codes)

    errors = await page.evaluate("""() => ({
      quota:atlasLearningPersistenceErrorCode({name:'QuotaExceededError',message:'quota exceeded'},'write'),
      open:atlasLearningPersistenceErrorCode({name:'UnknownError',message:'open failed'},'open'),
      blockedEn:atlasLearningPersistenceErrorCode({name:'UnknownError',message:'blocked'},'open'),
      blockedFr:atlasLearningPersistenceErrorCode({name:'UnknownError',message:'IndexedDB bloquée par un autre onglet'},'open'),
      read:atlasLearningPersistenceErrorCode({name:'UnknownError',message:'read failed'},'read'),
      write:atlasLearningPersistenceErrorCode({name:'UnknownError',message:'write failed'},'write'),
      verify:atlasLearningPersistenceErrorCode({name:'StorageVerificationError',message:'different'},'verify')
    })""")
    expected = {
      'quota':'LEARNING-STORAGE-QUOTA','open':'LEARNING-IDB-OPEN','blockedEn':'LEARNING-IDB-BLOCKED','blockedFr':'LEARNING-IDB-BLOCKED',
      'read':'LEARNING-IDB-READ','write':'LEARNING-IDB-WRITE','verify':'LEARNING-IDB-VERIFY'
    }
    for key, value in expected.items():
        record(f'error_code_{key}', errors.get(key) == value, errors)

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-gpu'])
        page = await browser.new_page(viewport={'width':1600,'height':1200})
        page_errors=[]
        page.on('pageerror', lambda exc: page_errors.append(str(exc)))
        await boot(page)
        await run(page)
        critical=[e for e in page_errors if 'ResizeObserver loop' not in e]
        record('no_critical_page_errors', not critical, critical)
        await browser.close()
    out={
      'build':'28.3.15',
      'passed':sum(x['pass'] for x in RESULTS),
      'total':len(RESULTS),
      'all_passed':all(x['pass'] for x in RESULTS),
      'browser':'Chromium system',
      'persistence_backend':'BrowserPersistenceContract — asynchronous verified read-back double',
      'scope':'Serialized writes, revision ordering, failure preservation, digest, integrity diagnostic and explicit error codes.',
      'limitation':'This suite exercises production persistence orchestration in a browser, but not the native IndexedDB engine because managed URL policy blocks executable web origins in the build container.',
      'results':RESULTS
    }
    (ROOT/'BROWSER_PERSISTENCE_CONTRACT_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"[browser-persistence-contract-313] TOTAL {out['passed']}/{out['total']}")

if __name__=='__main__':
    asyncio.run(main())
