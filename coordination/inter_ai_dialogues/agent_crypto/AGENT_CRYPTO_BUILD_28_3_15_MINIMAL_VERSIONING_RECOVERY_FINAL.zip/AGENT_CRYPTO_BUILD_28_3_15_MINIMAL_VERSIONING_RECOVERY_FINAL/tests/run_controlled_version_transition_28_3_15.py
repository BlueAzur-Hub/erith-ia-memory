import asyncio
import json
import re
import shutil
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent.parent
WEB15 = ROOT / 'public/agent_crypto_erith_ia/web'
WEB14 = Path('/mnt/data/crypto_versions_audit/AGENT_CRYPTO_BUILD_28_3_14_FINAL/AGENT_CRYPTO_BUILD_28_3_14_FINAL/public/agent_crypto_erith_ia/web')
RESULTS=[]

def rec(name, ok, details=''):
    RESULTS.append({'name':name,'pass':bool(ok),'details':details})
    print(f'[controlled-version-315] {name}: {bool(ok)}',flush=True)
    if not ok: raise AssertionError(f'{name}: {details}')

def files_from(web):
    return {
      'manifest':json.loads((web/'version.json').read_text(encoding='utf-8')),
      'index':(web/'index.html').read_text(encoding='utf-8'),
      'app':(web/'app.js').read_text(encoding='utf-8'),
      'style':(web/'style.css').read_text(encoding='utf-8')
    }

def variant(source, build, token):
    f=files_from(source)
    old_build='28.3.15'; old_token='market-core-v2.0-alpha-build-28.3.15'
    for key in ('index','app','style'):
        f[key]=f[key].replace(old_token,token).replace(old_build,build)
    f['manifest']['release']=f'Market Core V2.0-Alpha · Build {build}'
    f['manifest']['build']=build
    f['manifest']['asset_token']=token
    return f

def strip_assets(html):
    html=re.sub(r'<link rel="stylesheet"[^>]*>', '', html)
    html=re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>', '', html)
    html=re.sub(r'<script src="\.\/app\.js[^>]*></script>', '', html)
    return html.replace('<head>','<head><base href="https://agent.test/">',1)

async def load_runtime(browser, files):
    page=await browser.new_page(viewport={'width':1440,'height':900})
    errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
    await page.set_content(strip_assets(files['index']),wait_until='domcontentloaded',timeout=60000)
    await page.evaluate("""() => { class DummyChart { constructor(){this.data={datasets:[]};this.options={};this.scales={};} destroy(){} update(){} } window.Chart=DummyChart; }""")
    await page.add_style_tag(content=files['style'])
    await page.add_script_tag(content=files['app'])
    await page.wait_for_timeout(800)
    return page,errors

async def install_fetch(page, files):
    payload={'manifest':files['manifest'],'index':files['index'],'app':files['app'],'style':files['style']}
    await page.evaluate("""payload => {
      window.__versionPayload=payload;
      window.fetch=async input=>{
        const u=String(input?.url||input||'');
        if(u.includes('version.json')) return new Response(JSON.stringify(window.__versionPayload.manifest),{status:200,headers:{'content-type':'application/json'}});
        if(u.includes('index.html')) return new Response(window.__versionPayload.index,{status:200,headers:{'content-type':'text/html'}});
        if(u.includes('app.js')) return new Response(window.__versionPayload.app,{status:200,headers:{'content-type':'application/javascript'}});
        if(u.includes('style.css')) return new Response(window.__versionPayload.style,{status:200,headers:{'content-type':'text/css'}});
        return new Response('',{status:404});
      };
    }""",payload)

async def main():
  f14=files_from(WEB14); f15=files_from(WEB15)
  f16=variant(WEB15,'28.3.16','market-core-v2.0-alpha-build-28.3.16')
  f15conflict=variant(WEB15,'28.3.15','market-core-v2.0-alpha-build-28.3.15-r2')
  async with async_playwright() as p:
    browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])

    page,errors=await load_runtime(browser,f14)
    rec('loaded_client_28_3_14',await page.evaluate('ATLAS_BUILD')=='28.3.14')
    rec('loaded_28_3_14_identity_coherent',await page.evaluate('atlasVersionRuntimeIdentity().ok') is True)
    await install_fetch(page,f15)
    available=await page.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('28_3_14_detects_28_3_15',available is True)
    rec('28_3_14_state_available',await page.locator('#atlasVersionControl').get_attribute('data-state')=='available')
    await page.evaluate("""() => { window.__versionTarget=''; atlasVersionNavigateToUpdate=t=>{window.__versionTarget=t;return true}; }""")
    applied=await page.evaluate('atlasApplyVersionUpdate()')
    target=await page.evaluate('window.__versionTarget')
    rec('28_3_14_apply_path_accepts_28_3_15',applied is True)
    rec('28_3_15_target_has_new_build_and_token','build=28.3.15' in target and 'asset_token=market-core-v2.0-alpha-build-28.3.15' in target,target)
    await page.close()

    page15,errors15=await load_runtime(browser,f15)
    rec('loaded_client_28_3_15',await page15.evaluate('ATLAS_BUILD')=='28.3.15')
    rec('28_3_15_identity_coherent',await page15.evaluate('atlasVersionRuntimeIdentity().ok') is True)
    rec('root_asset_paths_retained',await page15.evaluate("ATLAS_VERSION_ASSET_URLS.index === './index.html' && ATLAS_VERSION_ASSET_URLS.app === './app.js' && ATLAS_VERSION_ASSET_URLS.style === './style.css'") is True)

    await install_fetch(page15,f16)
    available16=await page15.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('28_3_15_detects_future_28_3_16',available16 is True)
    rec('future_state_available',await page15.locator('#atlasVersionControl').get_attribute('data-state')=='available')
    await page15.evaluate("""() => { window.__versionTarget=''; atlasVersionNavigateToUpdate=t=>{window.__versionTarget=t;return true}; }""")
    applied16=await page15.evaluate('atlasApplyVersionUpdate()')
    target16=await page15.evaluate('window.__versionTarget')
    rec('future_apply_path_accepts_28_3_16',applied16 is True)
    rec('future_target_has_28_3_16','build=28.3.16' in target16 and 'asset_token=market-core-v2.0-alpha-build-28.3.16' in target16,target16)

    await install_fetch(page15,f15conflict)
    conflict_check=await page15.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('same_build_new_token_check_rejected',conflict_check is False)
    rec('same_build_conflict_state_publishing',await page15.locator('#atlasVersionControl').get_attribute('data-state')=='publishing')
    await page15.evaluate("""() => { window.__versionTarget=''; atlasVersionNavigateToUpdate=t=>{window.__versionTarget=t;return true}; }""")
    conflict_apply=await page15.evaluate('atlasApplyVersionUpdate()')
    rec('same_build_new_token_apply_rejected',conflict_apply is False)
    rec('same_build_conflict_has_no_navigation_target',await page15.evaluate('window.__versionTarget')=='')

    await install_fetch(page15,{'manifest':f16['manifest'],'index':f15['index'],'app':f15['app'],'style':f15['style']})
    partial=await page15.evaluate('atlasVersionCheck({force:true,userInitiated:true})')
    rec('partial_future_publication_rejected',partial is False)
    rec('partial_future_state_publishing',await page15.locator('#atlasVersionControl').get_attribute('data-state')=='publishing')

    critical=[e for e in errors+errors15 if not any(x in e for x in ('Failed to fetch','Chart','sessionStorage'))]
    rec('no_critical_controlled_pageerror',not critical,critical)
    await page15.close(); await browser.close()

  out={'build':'28.3.15','test_type':'controlled_browser_actual_version_functions_and_actual_publication_verifier','passed':sum(x['pass'] for x in RESULTS),'total':len(RESULTS),'all_passed':all(x['pass'] for x in RESULTS),'native_http_navigation_tested':False,'native_firefox_tested':False,'limitation':'Managed browser blocks localhost. Fetch transport and final navigation are controlled; version comparison, publication verification, state transitions and rejection logic are the real application functions.','results':RESULTS}
  (ROOT/'CONTROLLED_VERSION_TRANSITION_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print(f"[controlled-version-315] TOTAL {out['passed']}/{out['total']}")
  raise SystemExit(0 if out['all_passed'] else 1)

asyncio.run(main())
