const fs=require('fs'), path=require('path'), vm=require('vm');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'public/agent_crypto_erith_ia/web/app.js'),'utf8');
const results=[];
function check(name, condition, details=''){
  const pass=Boolean(condition); results.push({name,pass,details:String(details)});
  console.log(`[contract-313] ${name}: ${pass}`); if(!pass) throw new Error(`${name}: ${details}`);
}
function clone(value){return JSON.parse(JSON.stringify(value));}
function extractFunction(name){
  const candidates=[`async function ${name}(`,`function ${name}(`]; let start=-1;
  for(const marker of candidates){const i=src.indexOf(marker);if(i>=0&&(start<0||i<start))start=i;}
  if(start<0)throw new Error(`missing function ${name}`);
  let i=src.indexOf('{',start),depth=0,quote=null,escape=false;
  for(;i<src.length;i++){
    const c=src[i];
    if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===quote)quote=null;continue;}
    if(c==='"'||c==="'"||c==='`'){quote=c;continue;}
    if(c==='{')depth++; else if(c==='}'&&--depth===0)return src.slice(start,i+1);
  }
  throw new Error(`unterminated function ${name}`);
}
function extractFrozenObject(name){
  const marker=`const ${name} = Object.freeze(`; const start=src.indexOf(marker); if(start<0)throw new Error(name);
  let i=start+marker.length, depth=0, quote=null, escape=false;
  const begin=i;
  for(;i<src.length;i++){
    const c=src[i];
    if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===quote)quote=null;continue;}
    if(c==='"'||c==="'"||c==='`'){quote=c;continue;}
    if(c==='{')depth++; else if(c==='}'&&--depth===0)return vm.runInNewContext(`(${src.slice(begin,i+1)})`);
  }
  throw new Error(`unterminated object ${name}`);
}
function loadFunctions(context,names){vm.createContext(context);for(const name of names)vm.runInContext(extractFunction(name),context);}

const moduleBuilds=extractFrozenObject('ATLAS_FOUNDATION_MODULE_BUILDS');
const expected={market:'28.3.07',spot:'28.3.07',risk:'28.3.07',account:'28.3.08',wallet:'28.3.08',tokenomics:'28.3.09',defi:'28.3.09',yield:'28.3.09',derivatives:'28.3.10',scams:'28.3.10',records:'28.3.10'};
check('module_versions_exact',JSON.stringify(moduleBuilds)===JSON.stringify(expected),JSON.stringify(moduleBuilds));

const order=extractFrozenObject('ATLAS_FOUNDATION_ACTION_ORDER');
for(const action of ['account_stack_strong','wallet_network_bitcoin','tokenomics_stablecoin_riskfree_no','defi_write_transaction','yield_source_rewards','derivatives_exposure_500','scams_red_flags','records_complete_schema']){
  check(`step2_requires_read_${action}`,order[action]==='read',order[action]);
}
for(const action of ['account_support_stop','wallet_destination_independent','tokenomics_valuation_correct','defi_approval_limited','yield_value_756','derivatives_loss_25','scams_stop_official','records_mark_incomplete']){
  check(`step3_requires_open_${action}`,order[action]==='open',order[action]);
}

{
  const modules=Object.keys(expected).map(key=>({key}));
  const context={
    ATLAS_EXPERT_ROADMAP_MODULES:modules,
    ATLAS_LEARNING_SESSION_STEPS:['read','open','practice','verify','note'],
    ATLAS_LEARNING_FLOW_BUILD:'28.3.15',
    atlasLearningClone:clone,
    foundationPathBuildForModule:key=>expected[key]||null,
    foundationGuidedEvidenceKey:key=>`${key}_guided_conclusion`
  };
  loadFunctions(context,['atlasLearningNormalizeCockpit']);
  for(const key of ['account','wallet','tokenomics','defi','yield','derivatives','scams','records']){
    const sourceBuild=key==='account'||key==='wallet'?'28.3.10':key==='tokenomics'||key==='defi'||key==='yield'?'28.3.10':'28.3.09';
    const draft={module_key:key,foundation_path_build:sourceBuild,steps:{read:true,open:true,practice:true,verify:true,note:true},practice_evidence:{[`${key}_draft_proof`]:{kept:true}},takeaway:'draft kept'};
    const normalized=context.atlasLearningNormalizeCockpit(draft,4);
    check(`draft_steps_preserved_${key}`,['read','open','practice','verify','note'].every(step=>normalized.steps[step]===true),JSON.stringify(normalized.steps));
    check(`draft_evidence_preserved_${key}`,normalized.practice_evidence[`${key}_draft_proof`]?.kept===true,JSON.stringify(normalized.practice_evidence));
    check(`draft_module_version_reconciled_${key}`,normalized.foundation_path_build===expected[key],normalized.foundation_path_build);
  }
}

{
  const modules=Object.keys(expected).map((key,index)=>({key,title:`${String(index+1).padStart(2,'0')} · ${key}`}));
  const completeStats={practiced:modules.length,data:{modules:Object.fromEntries(modules.map(m=>[m.key,{status:'practiced'}]))}};
  const context={
    ATLAS_EXPERT_ROADMAP_MODULES:modules,
    learningRoadmapStats:()=>completeStats
  };
  loadFunctions(context,['learningJourneyIsComplete','recommendedLearningModule']);
  context.learningModuleByKey=key=>modules.find(m=>m.key===key)||modules[0];
  loadFunctions(context,['learningModuleAfterCompleted']);
  check('journey_complete_true',context.learningJourneyIsComplete(completeStats)===true);
  check('recommended_null_at_11_11',context.recommendedLearningModule()===null);
  check('next_null_after_module_11',context.learningModuleAfterCompleted({module_key:'records'})===null);
}


{
  const context={};
  loadFunctions(context,['atlasLearningPersistenceErrorCode']);
  check('error_code_quota',context.atlasLearningPersistenceErrorCode({name:'QuotaExceededError',message:'quota exceeded'},'write')==='LEARNING-STORAGE-QUOTA');
  check('error_code_read',context.atlasLearningPersistenceErrorCode({name:'UnknownError',message:'failed'},'read')==='LEARNING-IDB-READ');
  check('error_code_verify',context.atlasLearningPersistenceErrorCode({name:'StorageVerificationError',message:'different'},'verify')==='LEARNING-IDB-VERIFY');
  check('step_order_function_present',src.includes('function atlasLearningStepsAreOrdered(steps = {})'));
  check('step_order_gap_guard_present',src.includes('else if (gap) return false;'));
}
check('notebook_schema_v2_present',src.includes('agent_crypto_learning_notebook_indexeddb_v2'));
check('serialized_write_chain_present',src.includes('atlasLearningStorageWriteChain = atlasLearningStorageWriteChain.catch(() => null).then(execute);'));
check('integrity_diagnostic_present',src.includes('async function verifyLearningIntegrity()'));

check('no_generic_draft_reset_branch',!src.includes('guided_path_refresh_required'));
check('order_gate_called',src.includes('if (!foundationOrderGate(cockpit, action)) return;'));
check('journey_complete_action_present',src.includes('key:"journey_complete"'));
const out={build:'28.3.15',passed:results.filter(x=>x.pass).length,total:results.length,results};
fs.writeFileSync(path.join(root,'CONTRACT_HARNESS_RESULTS_28_3_15.json'),JSON.stringify(out,null,2)+'\n');
console.log(`[contract-313] TOTAL ${out.passed}/${out.total}`);
if(out.passed!==out.total)process.exit(1);
