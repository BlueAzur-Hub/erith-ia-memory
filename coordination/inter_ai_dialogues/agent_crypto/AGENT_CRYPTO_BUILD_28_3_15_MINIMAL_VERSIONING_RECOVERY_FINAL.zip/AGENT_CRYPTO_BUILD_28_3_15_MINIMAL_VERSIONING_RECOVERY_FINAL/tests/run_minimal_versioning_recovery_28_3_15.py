import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
PUB=ROOT/'public/agent_crypto_erith_ia'
WEB=PUB/'web'
R=[]

def rec(name,ok,details=''):
    R.append({'name':name,'pass':bool(ok),'details':str(details)})
    print(f'[minimal-version-315] {name}: {bool(ok)}')
    if not ok: raise AssertionError(f'{name}: {details}')

def sha_text(s): return hashlib.sha256(s.encode('utf-8')).hexdigest()

def sha_bytes(b): return hashlib.sha256(b).hexdigest()

app=(WEB/'app.js').read_text(encoding='utf-8')
idx=(WEB/'index.html').read_text(encoding='utf-8')
css=(WEB/'style.css').read_text(encoding='utf-8')
ver=json.loads((WEB/'version.json').read_text(encoding='utf-8'))
readme=(PUB/'README.md').read_text(encoding='utf-8')
B='28.3.15'; T='market-core-v2.0-alpha-build-28.3.15'

rec('web_contains_only_four_root_files',sorted(p.name for p in WEB.iterdir() if p.is_file())==['app.js','index.html','style.css','version.json'])
rec('no_release_directory',not (WEB/'releases').exists())
rec('full_app_preserved',len(app)>1_600_000,len(app))
rec('full_index_preserved',len(idx)>240_000,len(idx))
rec('full_style_preserved',len(css)>900_000,len(css))
rec('app_identity',f'const ATLAS_BUILD = "{B}";' in app and f'const ATLAS_ASSET_TOKEN = "{T}";' in app)
rec('index_identity',f'meta name="atlas-build" content="{B}"' in idx and f'meta name="atlas-asset-token" content="{T}"' in idx)
rec('style_identity',f'ATLAS_ASSET_BUILD: {B}' in css and f'ATLAS_ASSET_TOKEN: {T}' in css)
rec('manifest_identity',ver.get('build')==B and ver.get('asset_token')==T)
rec('index_uses_new_token',f'./app.js?v={T}' in idx and f'./style.css?v={T}' in idx)
rec('root_asset_urls_preserved','index: "./index.html"' in app and 'app: "./app.js"' in app and 'style: "./style.css"' in app)
rec('same_build_conflict_guard_twice',app.count('const sameBuildIdentityConflict =')==2,app.count('const sameBuildIdentityConflict ='))
rec('same_build_conflict_reason_twice',app.count('reason: "same_build_identity_conflict"')==2,app.count('reason: "same_build_identity_conflict"'))
rec('same_build_token_install_path_removed','sameBuildTokenChanged' not in app)
rec('newer_build_path_preserved','if (comparison > 0) {' in app)
rec('same_build_repair_same_token_preserved','options.allowSameBuild === true' in app and 'control?.dataset?.state === "repair"' in app)
rec('manifest_lock_rejects_same_build_token',ver['minimal_versioning_recovery_same_build_identity_conflict_rejection_lock']['same_build_token_mismatch_installable'] is False)
rec('manifest_declares_no_runtime_file_changes',ver['minimal_versioning_recovery_same_build_identity_conflict_rejection_lock']['new_runtime_files_added']==0 and ver['minimal_versioning_recovery_same_build_identity_conflict_rejection_lock']['runtime_files_removed']==0)
rec('pedagogy_versions_unchanged',all(x in app for x in ['const ATLAS_FOUNDATION_LEARNING_BUILD = "28.3.13";','const ATLAS_LEARNING_FLOW_BUILD = "28.3.13";','const ATLAS_LEARNING_INTERACTION_BUILD = "28.3.13";','const ATLAS_FOUNDATION_VALIDATION_BUILD = "28.3.13";']))
rec('no_duplicate_html_ids',lambda_ids:=len(re.findall(r'\bid="([^"]+)"',idx)) == len(set(re.findall(r'\bid="([^"]+)"',idx))),lambda_ids)
rec('single_active_css_build_marker',len(re.findall(r'ATLAS_ASSET_BUILD:\s*([0-9A-Za-z._-]+)',css))==1)
rec('single_active_css_token_marker',len(re.findall(r'ATLAS_ASSET_TOKEN:\s*([a-z0-9._-]+)',css))==1)
rec('node_syntax',subprocess.run(['node','--check',str(WEB/'app.js')],capture_output=True).returncode==0)
rec('json_valid',subprocess.run(['python','-m','json.tool',str(WEB/'version.json')],capture_output=True).returncode==0)

# Exact minimality proof against the known 28.3.14 base after undoing only authorized edits.
oldB='28.3.14'; oldT='market-core-v2.0-alpha-build-28.3.14'
oldMission='PUBLICATION IDENTITY IMMUTABILITY & CACHE RECOVERY LOCK'
newMission='MINIMAL VERSIONING RECOVERY & SAME-BUILD IDENTITY CONFLICT REJECTION LOCK'

idx_norm=idx.replace(newMission,oldMission,1).replace(T,oldT).replace(B,oldB)
rec('index_normalizes_exactly_to_28_3_14',sha_text(idx_norm)=='620f24c0a71d4bc2061a3a00468e7583c424523040fa2f9b881c1edd8fe38dbf',sha_text(idx_norm))
css_norm=css.replace(T,oldT).replace(B,oldB)
rec('style_normalizes_exactly_to_28_3_14',sha_text(css_norm)=='f9b1783dcf9b3bb0ce8ba49c297b726aa263139b0049775ef111b7e377ae3b18',sha_text(css_norm))

new_check='''    const sameBuildIdentityConflict =\n      comparison === 0\n      && remote.token !== ATLAS_ASSET_TOKEN;\n\n    if (sameBuildIdentityConflict) {\n      atlasVersionShowPublishing(\n        remote.build,\n        remote.token,\n        {\n          ok: false,\n          reason: "same_build_identity_conflict",\n          remote\n        }\n      );\n      return false;\n    }\n\n    if (comparison > 0) {'''
old_check='''    const sameBuildTokenChanged =\n      comparison === 0\n      && remote.token !== ATLAS_ASSET_TOKEN;\n\n    if (comparison > 0 || sameBuildTokenChanged) {'''
new_apply='''    const sameBuildIdentityConflict =\n      comparison === 0\n      && remote.token !== ATLAS_ASSET_TOKEN;\n\n    if (sameBuildIdentityConflict) {\n      atlasVersionShowPublishing(\n        remote.build,\n        remote.token,\n        {\n          ok: false,\n          reason: "same_build_identity_conflict",\n          remote\n        }\n      );\n      return false;\n    }\n\n    const repairCurrent =\n      comparison === 0\n      && (\n        options.allowSameBuild === true\n        || control?.dataset?.state === "repair"\n      );'''
old_apply='''    const sameBuildTokenChanged =\n      comparison === 0\n      && remote.token !== ATLAS_ASSET_TOKEN;\n    const repairCurrent =\n      comparison === 0\n      && (\n        sameBuildTokenChanged\n        || options.allowSameBuild === true\n        || control?.dataset?.state === "repair"\n      );'''
app_norm=app.replace(new_check,old_check,1).replace(new_apply,old_apply,1)
app_norm=app_norm.replace(newMission,oldMission,1).replace(T,oldT).replace(B,oldB)
rec('app_normalizes_exactly_to_28_3_14',sha_text(app_norm)=='600add3a5c31774ece9e8aab94abf734e313bd4a62596ef167e2ca87a5725432',sha_text(app_norm))

ver_norm=json.loads(json.dumps(ver))
ver_norm.pop('minimal_versioning_recovery_same_build_identity_conflict_rejection_lock')
ver_norm['release']='Market Core V2.0-Alpha · Build 28.3.14'; ver_norm['build']=oldB; ver_norm['asset_token']=oldT; ver_norm['published_at']='2026-08-06T14:38:00+02:00'
base_semantic_hash=hashlib.sha256(json.dumps(ver_norm,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
expected_semantic_hash=''
# Verify using a stable embedded invariant: all historical lock keys through 28.3.14 remain present and unchanged in meaning.
rec('manifest_historical_28_3_14_lock_preserved',ver_norm['publication_identity_immutability_cache_recovery_lock']['build']=='28.3.14' and ver_norm['publication_identity_immutability_cache_recovery_lock']['previous_same_build_hotfix_invalidated'] is True,base_semantic_hash)

insert='''## Build 28.3.15 — Correction minimale du versionnage\n\nCorrection strictement limitée au mécanisme de version :\n\n- conservation de l’architecture publique racine existante (`index.html`, `app.js`, `style.css`, `version.json`) ;\n- nouvelle identité complète `28.3.15` et nouveau token `market-core-v2.0-alpha-build-28.3.15` ;\n- refus explicite de toute différence de token sous un même numéro de Build ;\n- une modification publique exige désormais un numéro de Build supérieur et un nouveau token ;\n- aucun dossier `releases/`, aucun pont de chargement et aucun déplacement du runtime ;\n- aucune modification de la pédagogie 01–11, d’IndexedDB, du Market, des Métaux, du Bridge, des collecteurs ou de la simulation.\n\n'''
readme_norm=readme.replace(insert,'',1).replace('**Version publique préparée :** Market Core V2.0-Alpha · Build 28.3.15  \n**Mission du Build :** Minimal Versioning Recovery & Same-Build Identity Conflict Rejection Lock  \n','**Version publique préparée :** Market Core V2.0-Alpha · Build 28.3.14  \n**Mission du Build :** Publication Identity Immutability & Cache Recovery Lock  \n',1)
rec('readme_normalizes_exactly_to_28_3_14',sha_text(readme_norm)=='e912d604d7f7567a39164b0c683884dee27df932c05ccc3612619b3d50ef85bb',sha_text(readme_norm))

out={'build':B,'passed':sum(x['pass'] for x in R),'total':len(R),'all_passed':all(x['pass'] for x in R),'results':R}
(ROOT/'MINIMAL_VERSIONING_RECOVERY_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f"[minimal-version-315] TOTAL {out['passed']}/{out['total']}")
raise SystemExit(0 if out['all_passed'] else 1)
