import asyncio, json, re
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent.parent
WEB=ROOT/'public/agent_crypto_erith_ia/web'
RESULTS=[]

def record(name, ok, details=''):
    ok=bool(ok)
    RESULTS.append({'name':name,'pass':ok,'details':str(details)})
    print(f'[browser-314] {name}: {ok}', flush=True)
    if not ok:
        raise AssertionError(f'{name}: {details}')


async def logical_visible(locator):
    return await locator.evaluate("""e => {
      let n=e;
      while(n){
        const cs=getComputedStyle(n);
        if(n.hidden || cs.display==='none' || cs.visibility==='hidden') return false;
        if(n.tagName==='DETAILS' && !n.open && n!==e && e!==n.querySelector(':scope > summary')) return false;
        n=n.parentElement;
      }
      return true;
    }""")

async def wait_ready(page):
    html=(WEB/'index.html').read_text(encoding='utf-8')
    html=re.sub(r'<link rel="stylesheet" href="\./style\.css[^>]*>', '', html)
    html=re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>', '', html)
    html=re.sub(r'<script src="\./app\.js[^>]*></script>', '', html)
    await page.set_content(html, wait_until='domcontentloaded', timeout=60000)
    await page.evaluate("""() => {
      class MemoryStorage {
        constructor(){ this.map = new Map(); }
        get length(){ return this.map.size; }
        key(i){ return [...this.map.keys()][i] ?? null; }
        getItem(k){ k=String(k); return this.map.has(k) ? this.map.get(k) : null; }
        setItem(k,v){ this.map.set(String(k), String(v)); }
        removeItem(k){ this.map.delete(String(k)); }
        clear(){ this.map.clear(); }
      }
      try { Object.defineProperty(window, 'localStorage', {value:new MemoryStorage(), configurable:true}); } catch {}
      try { Object.defineProperty(window, 'sessionStorage', {value:new MemoryStorage(), configurable:true}); } catch {}
    }""")
    await page.add_style_tag(content=(WEB/'style.css').read_text(encoding='utf-8'))
    await page.add_script_tag(content=(WEB/'app.js').read_text(encoding='utf-8'))
    await page.wait_for_timeout(1500)
    await page.evaluate("""() => {
      window.__fakeLearningDbRecord = null;
      atlasLearningDbWriteVerified = async (record) => {
        const normalized = atlasLearningNormalizeNotebook(atlasLearningClone(record));
        window.__fakeLearningDbRecord = atlasLearningClone(normalized);
        return {ok:true, backend:'BrowserMemoryVerifiedReadBack', bytes:JSON.stringify(normalized).length, digest:'browser-memory', record:atlasLearningClone(normalized)};
      };
      atlasLearningDbReadRecord = async () => window.__fakeLearningDbRecord ? atlasLearningClone(window.__fakeLearningDbRecord) : null;
      atlasLearningStorageReady = true;
      atlasLearningStorageReadBlocked = false;
      atlasLearningStorageResetting = false;
      atlasLearningStorageInitPromise = Promise.resolve(atlasLearningNotebookCache);
      const cockpit=document.querySelector('#learningJourneyCockpit');
      if (cockpit && typeof learningOpenParentDetails === 'function') learningOpenParentDetails(cockpit);
      renderLearningJourneyCockpit();
      if (typeof atlasV2ApplyMode === 'function') atlasV2ApplyMode('intermediate');
      learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    await page.wait_for_selector('#learningJourneyCockpit', state='attached', timeout=60000)
    await page.wait_for_timeout(500)

async def fresh_market_session(page):
    await page.evaluate("""async () => {
      atlasLearningNotebookCache = atlasLearningSeedFromLocalStorage();
      atlasLearningNotebookCache.history = [];
      atlasLearningNotebookCache.roadmap = atlasLearningNormalizeRoadmap(null);
      const c = defaultLearningCockpitState();
      c.module_key = 'market';
      c.foundation_path_build = ATLAS_FOUNDATION_LEARNING_BUILD;
      atlasLearningNotebookCache.cockpit = atlasLearningNormalizeCockpit(c, 0);
      await atlasLearningPersistNow('browser_311_fresh_session');
      renderExpertRoadmap();
      renderLearningJourneyCockpit();
      if (typeof atlasV2ApplyMode === 'function') atlasV2ApplyMode('intermediate');
      learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    await page.wait_for_timeout(400)

async def seed_market_data(page):
    await page.evaluate("""() => {
      runLivecheck = async () => {
        state.liveOk = true;
        state.mainSource = 'CoinGecko USD · snapshot pédagogique';
        state.timestamp = '2026-08-06T03:14:49+02:00';
        state.coins = [{
          id:'bitcoin', name:'Bitcoin', symbol:'BTC', rank:1,
          price:55817.95, change24h:0.60, change7d:2.10,
          marketCap:1100000000000, volume24h:20000000000,
          image:'', sparkline:[55200,55400,55817.95]
        }];
        if (els.sourceName) els.sourceName.textContent = state.mainSource;
        if (els.sourceTime) els.sourceTime.textContent = '06/08/2026 03:14:49';
        if (els.liveStatus) els.liveStatus.textContent = 'Prix live test · 1/1';
        try { renderMarketTable(); } catch {}
        return true;
      };
    }""")

async def test_full_flow(page):
    await fresh_market_session(page)
    errors=[]
    page.on('pageerror', lambda exc: errors.append(str(exc)))

    record('fresh_progress_0_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('0/5'))
    record('step1_primary_open_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Ouvrir la leçon du Module 01')
    await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
    record('step1_open_does_not_validate',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('0/5'))
    diag=await page.locator('#btnMarkLessonRead').evaluate("e=>({hidden:e.hidden,display:getComputedStyle(e).display,visibility:getComputedStyle(e).visibility,detailsOpen:e.closest('details')?.open,rect:e.getBoundingClientRect().toJSON(),parentDisplay:getComputedStyle(e.parentElement).display})")
    record('step1_bottom_button_visible',not diag['hidden'] and diag['display']!='none' and diag['visibility']!='hidden' and diag['detailsOpen'],diag)
    await page.locator('#btnMarkLessonRead').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().steps.read === true")
    record('step1_validates_to_1_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('1/5'))
    record('step1_lesson_remains_open',await page.locator('#learningLessonPanel').evaluate('(e)=>e.open'))

    await seed_market_data(page)
    record('step2_primary_livecheck',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Lancer Livecheck')
    await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().steps.open === true", timeout=20000)
    record('step2_validates_to_2_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('2/5'))
    persisted_step2=await page.evaluate("atlasLearningDbReadRecord()")
    record('step2_verified_persistence_readback',persisted_step2 and persisted_step2.get('cockpit',{}).get('steps',{}).get('open') is True)

    record('step3_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Relever Prix / 24 h / 7 j')
    await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
    await page.wait_for_timeout(200)
    chain=await page.locator('[data-foundation-stage="3"]').evaluate("e=>{const a=[];let n=e;while(n){const cs=getComputedStyle(n);a.push({tag:n.tagName,id:n.id,cls:n.className,hidden:n.hidden,display:cs.display,visibility:cs.visibility,open:n.open});n=n.parentElement;}return a}")
    record('step3_card_visible',await logical_visible(page.locator('[data-foundation-stage="3"]')),chain[:8])
    record('step3_values_visible','55' in (await page.locator('[data-foundation-stage="3"]').text_content()))
    before=(await page.locator('#learningSessionProgress').text_content()).strip()
    await page.locator('[data-foundation-action="market_show_btc_row"]').evaluate('(e)=>e.click()')
    await page.wait_for_timeout(200)
    after=(await page.locator('#learningSessionProgress').text_content()).strip()
    record('step3_view_row_does_not_validate',before==after and after.startswith('2/5'),f'{before}->{after}')
    await page.locator('[data-foundation-action="market_read_btc"]').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().steps.practice === true")
    record('step3_explicit_confirmation_to_3_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('3/5'))
    frozen_step3=await page.evaluate("loadLearningCockpitState().practice_evidence.market_btc_read")
    record('step3_evidence_frozen_mode',frozen_step3.get('evidence_mode')=='frozen_at_validation',json.dumps(frozen_step3,ensure_ascii=False))
    await page.evaluate("""() => {
      state.coins[0].price=99999.99; state.coins[0].change24h=-9.99; state.coins[0].change7d=-8.88;
      state.mainSource='SOURCE-B · après étape 3';
      if(els.sourceName) els.sourceName.textContent=state.mainSource;
      if(els.sourceTime) els.sourceTime.textContent='06/08/2026 04:44:44';
      renderLearningJourneyCockpit(); learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    stage3_after_drift=await page.locator('[data-foundation-stage="3"]').text_content()
    record('step3_values_survive_live_drift',frozen_step3['price'] in stage3_after_drift and frozen_step3['change_24h'] in stage3_after_drift and '99\u202f999' not in stage3_after_drift,stage3_after_drift)

    record('step4_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Vérifier source + heure')
    await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
    await page.wait_for_timeout(200)
    card4=page.locator('[data-foundation-stage="4"]')
    text4=await card4.text_content()
    record('step4_source_time_visible','SOURCE-B · après étape 3' in text4 and '06/08/2026 04:44:44' in text4,text4[:300])
    await page.locator('[data-foundation-action="market_verify_source_time"]').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().steps.verify === true")
    record('step4_explicit_confirmation_to_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    frozen_step4=await page.evaluate("loadLearningCockpitState().practice_evidence.market_source_time")
    record('step4_provenance_frozen_mode',frozen_step4.get('evidence_mode')=='frozen_at_validation' and frozen_step4.get('source')=='SOURCE-B · après étape 3' and frozen_step4.get('time')=='06/08/2026 04:44:44',json.dumps(frozen_step4,ensure_ascii=False))
    await page.evaluate("""() => {
      state.coins[0].price=11111.11; state.coins[0].change24h=7.77; state.coins[0].change7d=6.66;
      state.mainSource='SOURCE-C · après étape 4';
      if(els.sourceName) els.sourceName.textContent=state.mainSource;
      if(els.sourceTime) els.sourceTime.textContent='06/08/2026 05:55:55';
      renderLearningJourneyCockpit(); learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
    }""")
    frozen_stage5=await page.locator('[data-foundation-stage="5"]').text_content()
    record('step5_uses_frozen_values_and_provenance',frozen_step3['price'] in frozen_stage5 and frozen_step4['source'] in frozen_stage5 and frozen_step4['time'] in frozen_stage5 and 'SOURCE-C' not in frozen_stage5 and '11\u202f111' not in frozen_stage5,frozen_stage5[:900])

    await page.evaluate("saveLearningSessionNotes('JE NE SAIS PAS, J AI PASSE MON TEMPS A DEBUGGER CE FORMULAIRE ET CE TEXTE EST TRES LONG MAIS NE PROUVE AUCUNE COMPREHENSION.', 'takeaway')")
    await page.wait_for_timeout(250)
    record('long_free_text_does_not_validate',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    record('mandatory_takeaway_field_hidden',await page.locator('#learningTakeawayField').evaluate("e=>e.hidden || getComputedStyle(e).display==='none'"))
    record('optional_notes_still_visible',await logical_visible(page.locator('#learningSessionNotesFree')))
    record('archive_locked_before_guided_answer',await page.locator('#btnCompleteLearningSession').is_disabled())

    record('step5_primary_label',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Comprendre la conclusion guidée')
    await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
    await page.wait_for_timeout(200)
    card5=page.locator('[data-foundation-stage="5"]')
    text5=await card5.text_content()
    record('step5_teaches_before_question','décrivent l’écran observé' in text5 and 'ne permettent pas de prédire' in text5,text5[:700])
    await page.locator('[data-foundation-action="market_prediction_yes"]').evaluate('(e)=>e.click()')
    await page.wait_for_timeout(200)
    record('wrong_yes_stays_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    await page.locator('[data-foundation-action="market_prediction_no"]').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().steps.note === true")
    record('correct_no_validates_5_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('5/5'))
    c=await page.evaluate("loadLearningCockpitState()")
    record('guided_summary_replaces_bad_text',c.get('takeaway','').startswith('Au moment observé') and 'DEBUGGER' not in c.get('takeaway',''),c.get('takeaway','')[:300])
    frozen_takeaway=c.get('takeaway','')
    record('guided_summary_keeps_frozen_proofs',frozen_step3['price'] in frozen_takeaway and frozen_step4['source'] in frozen_takeaway and frozen_step4['time'] in frozen_takeaway and 'SOURCE-C' not in frozen_takeaway,frozen_takeaway)
    record('guided_evidence_recorded',c.get('practice_evidence',{}).get('market_guided_conclusion') is True)
    record('archive_enabled_after_guided_answer',not await page.locator('#btnCompleteLearningSession').is_disabled())

    session_id=c['session_id']
    await page.locator('#btnCompleteLearningSession').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().completed_at !== null", timeout=20000)
    record('archive_completion_panel_visible',await logical_visible(page.locator('#learningCompletionPanel')))
    record('module01_plan_stays_visible',await logical_visible(page.locator('#learningSessionPlan')))
    record('module01_lesson_stays_visible',await logical_visible(page.locator('#learningLessonPanel')))
    record('next_module_button_visible',await logical_visible(page.locator('#btnLearningNextModule')))
    persisted=await page.evaluate("atlasLearningDbReadRecord()")
    ph=persisted.get('history',[]) if persisted else []
    record('archive_verified_persistence_history',any(x.get('session_id')==session_id and x.get('completed_at') for x in ph),json.dumps(ph,ensure_ascii=False)[:600])
    archived_market=next((x for x in ph if x.get('session_id')==session_id),{})
    record('archive_keeps_frozen_market_summary',archived_market.get('takeaway')==frozen_takeaway and archived_market.get('practice_evidence',{}).get('market_btc_read',{}).get('price')==frozen_step3['price'] and archived_market.get('practice_evidence',{}).get('market_source_time',{}).get('source')==frozen_step4['source'],json.dumps(archived_market,ensure_ascii=False)[:1200])
    market=(persisted or {}).get('roadmap',{}).get('modules',{}).get('market',{})
    record('roadmap_module01_practiced',market.get('status')=='practiced',json.dumps(market,ensure_ascii=False))
    modules_text=await page.locator('#learningCockpitModules').text_content()
    record('roadmap_progress_counted','1/11' in modules_text and '1 pratiqué' in modules_text,modules_text)

    await page.locator('#btnLearningNextModule').evaluate('(e)=>e.click()')
    await page.wait_for_function("loadLearningCockpitState().module_key === 'spot'")
    record('module02_only_after_explicit_button','02 · Spot' in (await page.locator('#learningCockpitModule').text_content()),await page.locator('#learningCockpitModule').text_content())
    await page.evaluate("atlasLearningPersistNow('browser_311_module_02_start')")
    await page.evaluate("""async () => {
      const record = await atlasLearningDbReadRecord();
      atlasLearningNotebookCache = atlasLearningNormalizeNotebook(record);
      renderExpertRoadmap();
      renderLearningJourneyCockpit();
    }""")
    await page.wait_for_timeout(250)
    persisted2=await page.evaluate("atlasLearningDbReadRecord()")
    record('archive_survives_full_rehydrate',any(x.get('session_id')==session_id for x in (persisted2 or {}).get('history',[])))
    record('module02_survives_full_rehydrate',(await page.evaluate("loadLearningCockpitState().module_key"))=='spot')

    critical=[e for e in errors if 'ResizeObserver loop' not in e and 'Access is denied for this document' not in e]
    record('full_flow_no_critical_pageerror',not critical,json.dumps(critical,ensure_ascii=False))

async def test_304_active_draft_migration(page):
    await page.evaluate("""async () => {
      atlasLearningNotebookCache = atlasLearningSeedFromLocalStorage();
      atlasLearningNotebookCache.history = [];
      atlasLearningNotebookCache.roadmap = atlasLearningNormalizeRoadmap(null);
      const c = defaultLearningCockpitState();
      c.module_key='market';
      c.flow_build='28.3.04';
      c.foundation_path_build='28.3.04';
      c.steps={read:true,open:true,practice:true,verify:true,note:true};
      c.takeaway='Ancienne conclusion longue acceptée uniquement par longueur dans la version précédente.';
      c.practice_evidence={market_btc_read:true,market_prudent:true,foundation_conclusion_ready:true};
      atlasLearningNotebookCache.cockpit=atlasLearningNormalizeCockpit(c,0);
      renderLearningJourneyCockpit();
      if (typeof atlasV2ApplyMode === 'function') atlasV2ApplyMode('intermediate');
      learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));
      await atlasLearningPersistNow('browser_311_migrate_304_draft');
    }""")
    await page.wait_for_timeout(300)
    c=await page.evaluate("loadLearningCockpitState()")
    record('migration_304_old_text_loses_step5',c['steps']['note'] is False,json.dumps(c,ensure_ascii=False)[:700])
    record('migration_304_returns_to_4_5',(await page.locator('#learningSessionProgress').text_content()).strip().startswith('4/5'))
    record('migration_304_guided_action_shown',(await page.locator('#btnLearningPrimaryAction').text_content()).strip()=='Comprendre la conclusion guidée')
    record('migration_304_archive_disabled',await page.locator('#btnCompleteLearningSession').is_disabled())

async def main():
    async with async_playwright() as p:
      browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
      context=await browser.new_context()
      page=await context.new_page()
      await wait_ready(page)
      await test_full_flow(page)
      await context.close()

      context2=await browser.new_context()
      page2=await context2.new_page()
      await wait_ready(page2)
      await test_304_active_draft_migration(page2)
      await context2.close()
      await browser.close()
    out={
      'passed':sum(x['pass'] for x in RESULTS),
      'total':len(RESULTS),
      'results':RESULTS,
      'persistence_backend':'BrowserMemoryVerifiedReadBack',
      'limitation':'The container blocks localhost/file navigation, so this browser runtime validates the full DOM flow with a deterministic verified read-back adapter rather than the public Firefox origin.'
    }
    (ROOT/'BROWSER_RUNTIME_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'[browser-314] TOTAL {out["passed"]}/{out["total"]}')

if __name__=='__main__':
    asyncio.run(main())
