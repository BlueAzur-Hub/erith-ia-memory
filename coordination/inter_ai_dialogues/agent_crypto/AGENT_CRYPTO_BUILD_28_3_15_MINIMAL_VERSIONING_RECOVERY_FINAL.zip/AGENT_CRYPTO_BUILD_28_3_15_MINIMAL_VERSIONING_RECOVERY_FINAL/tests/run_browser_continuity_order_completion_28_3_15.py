import asyncio, json, re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parent.parent
WEB=ROOT/'public/agent_crypto_erith_ia/web'
RESULTS=[]
def record(name, ok, details=''):
    ok=bool(ok); RESULTS.append({'name':name,'pass':ok,'details':str(details)}); print(f'[browser-continuity-313] {name}: {ok}',flush=True)
    if not ok: raise AssertionError(f'{name}: {details}')
async def boot(page):
    html=(WEB/'index.html').read_text(encoding='utf-8')
    html=re.sub(r'<link rel="stylesheet" href="\./style\.css[^>]*>','',html)
    html=re.sub(r'<script src="https://cdn\.jsdelivr\.net[^>]*></script>','',html)
    html=re.sub(r'<script src="\./app\.js[^>]*></script>','',html)
    await page.set_content(html,wait_until='domcontentloaded',timeout=60000)
    await page.evaluate("""()=>{class M{constructor(){this.m=new Map()}get length(){return this.m.size}key(i){return [...this.m.keys()][i]??null}getItem(k){k=String(k);return this.m.has(k)?this.m.get(k):null}setItem(k,v){this.m.set(String(k),String(v))}removeItem(k){this.m.delete(String(k))}clear(){this.m.clear()}};try{Object.defineProperty(window,'localStorage',{value:new M(),configurable:true})}catch{};try{Object.defineProperty(window,'sessionStorage',{value:new M(),configurable:true})}catch{};window.confirm=()=>true;}""")
    await page.add_style_tag(content=(WEB/'style.css').read_text(encoding='utf-8'))
    await page.add_script_tag(content=(WEB/'app.js').read_text(encoding='utf-8'))
    await page.wait_for_timeout(1300)
    await page.evaluate("""()=>{window.__fakeLearningDbRecord=null;atlasLearningDbWriteVerified=async record=>{const normalized=atlasLearningNormalizeNotebook(atlasLearningClone(record));window.__fakeLearningDbRecord=atlasLearningClone(normalized);return {ok:true,backend:'BrowserMemoryVerifiedReadBack',bytes:JSON.stringify(normalized).length,digest:'browser-memory',record:atlasLearningClone(normalized)}};atlasLearningDbReadRecord=async()=>window.__fakeLearningDbRecord?atlasLearningClone(window.__fakeLearningDbRecord):null;atlasLearningStorageReady=true; atlasLearningStorageReadBlocked=false; atlasLearningStorageResetting=false;atlasLearningStorageInitPromise=Promise.resolve(atlasLearningNotebookCache);if(typeof atlasV2ApplyMode==='function')atlasV2ApplyMode('intermediate');}""")
async def seed_fresh(page,key):
    await page.evaluate("""async key=>{atlasLearningNotebookCache=atlasLearningSeedFromLocalStorage();atlasLearningNotebookCache.history=[];atlasLearningNotebookCache.roadmap=atlasLearningNormalizeRoadmap(null);const index=ATLAS_EXPERT_ROADMAP_MODULES.findIndex(m=>m.key===key);ATLAS_EXPERT_ROADMAP_MODULES.slice(0,index).forEach(m=>atlasLearningNotebookCache.roadmap.modules[m.key].status='practiced');const c=defaultLearningCockpitState();c.module_key=key;c.foundation_path_build=foundationPathBuildForModule(key);atlasLearningNotebookCache.cockpit=atlasLearningNormalizeCockpit(c,index);await atlasLearningPersistNow('browser_311_seed_'+key);renderExpertRoadmap();renderLearningJourneyCockpit();learningOpenParentDetails(document.querySelector('#learningJourneyCockpit'));}""",key)
    await page.wait_for_timeout(120)
async def test_order(page):
    actions={'account':'account_stack_strong','wallet':'wallet_network_bitcoin','tokenomics':'tokenomics_stablecoin_riskfree_no','defi':'defi_write_transaction','yield':'yield_source_rewards','derivatives':'derivatives_exposure_500','scams':'scams_red_flags','records':'records_complete_schema'}
    for key,action in actions.items():
        await seed_fresh(page,key)
        disabled=await page.locator('[data-foundation-stage="2"] button').evaluate_all('(els)=>els.length>0&&els.every(e=>e.disabled)')
        record(f'{key}_step2_ui_blocked_before_read',disabled)
        await page.evaluate('(action)=>handleFoundationAction(action)',action)
        state=await page.evaluate('loadLearningCockpitState()')
        record(f'{key}_handler_blocked_before_read',state['steps']['read'] is False and state['steps']['open'] is False,json.dumps(state['steps']))
        await page.locator('#btnLearningPrimaryAction').evaluate('(e)=>e.click()')
        await page.locator('#btnMarkLessonRead').evaluate('(e)=>e.click()')
        await page.wait_for_function('loadLearningCockpitState().steps.read===true')
        enabled=await page.locator(f'[data-foundation-action="{action}"]').evaluate('(e)=>!e.disabled')
        record(f'{key}_step2_unlocked_after_read',enabled)
async def test_draft_continuity(page):
    modules=['account','wallet','tokenomics','defi','yield','derivatives','scams','records']
    for key in modules:
        result=await page.evaluate("""key=>{const oldBuild=['account','wallet'].includes(key)?'28.3.10':['tokenomics','defi','yield'].includes(key)?'28.3.10':'28.3.09';const proof=key+'_draft_proof';const source={module_key:key,foundation_path_build:oldBuild,steps:{read:true,open:true,practice:true,verify:true,note:true},practice_evidence:{[proof]:{kept:true}},takeaway:'brouillon conservé'};const n=atlasLearningNormalizeCockpit(source,4);return {steps:n.steps,evidence:n.practice_evidence,build:n.foundation_path_build,expected:foundationPathBuildForModule(key),proof};}""",key)
        record(f'{key}_draft_steps_preserved',all(result['steps'][x] for x in ['read','open','practice','verify','note']),json.dumps(result['steps']))
        record(f'{key}_draft_evidence_preserved',result['evidence'].get(result['proof'],{}).get('kept') is True,json.dumps(result['evidence']))
        record(f'{key}_draft_version_reconciled',result['build']==result['expected'],f"{result['build']} != {result['expected']}")
async def test_completion(page):
    before=await page.evaluate("""async()=>{atlasLearningNotebookCache=atlasLearningSeedFromLocalStorage();const now=new Date().toISOString();atlasLearningNotebookCache.history=ATLAS_EXPERT_ROADMAP_MODULES.map((m,i)=>({session_id:'DONE-'+i,module_key:m.key,module_title:m.title,completed_at:now,steps:{read:true,open:true,practice:true,verify:true,note:true},takeaway:'archive'}));atlasLearningNotebookCache.roadmap=atlasLearningNormalizeRoadmap(null);ATLAS_EXPERT_ROADMAP_MODULES.forEach(m=>{atlasLearningNotebookCache.roadmap.modules[m.key].status='practiced';atlasLearningNotebookCache.roadmap.modules[m.key].updated_at=now});const c=defaultLearningCockpitState();c.module_key='records';c.session_id='DONE-10';c.completed_at=now;c.completed_sessions=11;c.steps={read:true,open:true,practice:true,verify:true,note:true};c.practice_evidence.records_guided_conclusion=true;c.takeaway='archive';c.foundation_path_build=foundationPathBuildForModule('records');atlasLearningNotebookCache.cockpit=atlasLearningNormalizeCockpit(c,11);await atlasLearningPersistNow('browser_311_complete');renderExpertRoadmap();renderLearningJourneyCockpit();return {id:loadLearningCockpitState().session_id,module:loadLearningCockpitState().module_key,completed:loadLearningCockpitState().completed_at};}""")
    await page.wait_for_timeout(200)
    record('journey_progress_100',(await page.locator('#learningCockpitProgress').text_content()).strip()=='100 %')
    record('journey_status_11_11','11/11' in (await page.locator('#learningCockpitStatus').text_content()))
    record('journey_title_complete','Parcours pédagogique terminé · 11/11' in (await page.locator('#learningCockpitModule').text_content()))
    record('journey_action_complete',(await page.evaluate('learningActionState(loadLearningCockpitState()).key'))=='journey_complete')
    record('journey_next_is_null',await page.evaluate('learningModuleAfterCompleted(loadLearningCockpitState())===null'))
    record('journey_button_not_module01',(await page.locator('#btnLearningNextModule').text_content()).strip()=='Voir mon carnet complet')
    await page.locator('#btnLearningNextModule').evaluate('(e)=>e.click()')
    await page.wait_for_timeout(150)
    after=await page.evaluate('({id:loadLearningCockpitState().session_id,module:loadLearningCockpitState().module_key,completed:loadLearningCockpitState().completed_at,history:loadLearningHistory().length})')
    record('journey_click_preserves_completed_session',after['id']==before['id'] and after['module']=='records' and after['completed']==before['completed'],json.dumps(after))
    record('journey_click_no_new_archive',after['history']==11,after['history'])
async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
        page=await browser.new_page(); await boot(page)
        errors=[]; page.on('pageerror',lambda exc: errors.append(str(exc)))
        await test_order(page); await test_draft_continuity(page); await test_completion(page)
        record('no_page_errors',not errors,errors)
        await browser.close()
    out={'build':'28.3.15','passed':sum(x['pass'] for x in RESULTS),'total':len(RESULTS),'results':RESULTS,'persistence_backend':'BrowserMemoryVerifiedReadBack','limitation':'DOM, order, migration and completion are browser-tested with deterministic read-back. Public Firefox IndexedDB persistence still requires one post-upload validation.'}
    (ROOT/'BROWSER_CONTINUITY_ORDER_COMPLETION_RESULTS_28_3_15.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f"[browser-continuity-313] TOTAL {out['passed']}/{out['total']}")
if __name__=='__main__': asyncio.run(main())
