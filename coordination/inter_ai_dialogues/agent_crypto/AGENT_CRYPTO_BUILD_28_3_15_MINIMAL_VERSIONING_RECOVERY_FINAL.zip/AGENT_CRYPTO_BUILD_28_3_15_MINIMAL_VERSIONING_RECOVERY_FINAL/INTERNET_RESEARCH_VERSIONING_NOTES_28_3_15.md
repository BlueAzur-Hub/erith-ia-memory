# Recherche technique — versionnage et cache

Sources officielles consultées :

- MDN — HTTP caching : utiliser une URL versionnée ou hachée pour un contenu statique qui change ; une nouvelle version doit obtenir une nouvelle URL.
- MDN — Cache-Control : les ressources versionnées peuvent être immuables ; le document HTML doit être revalidé.
- RFC 9111 — `no-store` empêche le stockage de la réponse concernée mais ne purge pas rétroactivement une réponse déjà stockée.
- MDN — CSS `url()` : une URL relative est résolue relativement à l’URL de la feuille de style, pas à celle de la page.
- GitHub Docs — GitHub Pages publie des fichiers HTML, CSS et JavaScript statiques issus du dépôt.

Conséquence pour Agent-Crypto :

- chaque Build modifiant les fichiers publics reçoit un nouveau numéro et un nouveau token d’URL ;
- le même Build ne peut jamais accepter un nouveau token comme mise à jour ;
- déplacer un CSS dans un sous-répertoire exige de corriger tous ses chemins relatifs, ce qui n’avait pas été fait dans la première archive 28.3.15 ;
- la correction retenue conserve donc l’architecture racine existante au lieu de déplacer le runtime.
