# Invalidation — première archive Build 28.3.15

Archive : `AGENT_CRYPTO_BUILD_28_3_15_FINAL.zip`

Statut : **INVALIDE — NE PAS UPLOADER**

## Motifs

- réécriture non demandée de l’architecture ;
- remplacement de l’application racine par un pont ;
- déplacement du runtime vers `web/releases/28.3.15/` ;
- `index.html` racine réduit de 3954 à 35 lignes ;
- `app.js` racine réduit de 34692 à 127 lignes ;
- chemins relatifs du CSS déplacé non réécrits, avec 404 observées ;
- test navigateur ayant retiré les vraies ressources et remplacé le vérificateur lors du scénario futur.

Cette archive ne correspond pas à une correction bornée du versionnage.
