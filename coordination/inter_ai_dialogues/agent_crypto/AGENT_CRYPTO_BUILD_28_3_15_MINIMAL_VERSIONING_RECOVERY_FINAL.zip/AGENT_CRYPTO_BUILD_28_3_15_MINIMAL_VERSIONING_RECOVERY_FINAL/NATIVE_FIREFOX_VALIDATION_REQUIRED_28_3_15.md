# Validation Firefox native requise

La vérification contrôlée ne remplace pas Firefox réel.

Après publication seulement :

1. garder une page 28.3.14 déjà ouverte sur une machine lorsque c’est encore possible ;
2. constater la détection de 28.3.15 ;
3. lancer l’installation depuis le cartouche ;
4. vérifier que 28.3.15 apparaît et que la page complète reste disponible ;
5. fermer puis rouvrir Firefox sans effacer le stockage ;
6. vérifier la conservation du parcours et des archives IndexedDB.

Aucun reset, aucun nettoyage de cache et aucune suppression de données avant le constat.
