# Agent-Crypto 40.6.164 — G3 Historical Dataset Discovery

## But
Découvrir sans fabriquer les candidats de données historiques déjà visibles dans Administrator.

## Preuve terrain de départ (40.6.163)
- BTC : fenêtre historique 24h, 300 points, pas médian 5 min, complétude 100 %.
- Mémoire : 483 observations marché distinctes, comparaison disponible.
- Historique rétrospectif : 2 / 2 CURRENT évaluables.
- G3 était encore PENDING : aucun dataset de replay Strategy A avec labels d'outcome certifiés.

## Ajout 40.6.164
Le bloc `G3 · HISTORICAL DATASET DISCOVERY` lit passivement les preuves déjà visibles :
- série marché ;
- fenêtre ;
- pas médian ;
- complétude ;
- observations mémoire ;
- CURRENT évaluables ;
- labels outcome certifiés ;
- dataset replay certifié ;
- état G3.

## Vérité
Ces données sont des candidats historiques réels, pas encore un backtest certifié.
`certified_outcome_labels=false`
`replay_contract_ready=false`
`backtest_ready=false`
`G3=PENDING`

## Garde-fous
Aucun backtest exécuté.
Aucune donnée fabriquée.
Aucun seuil Strategy A modifié.
Aucun ordre réel.
Aucun nouveau stockage, timer, observer ou appel réseau.
Market Core 38.15.11, Web Classique, Aether, Atlas CURRENT, Oracle, Lecture Technique et TRADUS protégés.

## Commits
- Runtime : caf3c8db17be7dbfd510de25be05f46eba46529f
- Release immuable : a5ca71521ac84c7958b5139a91e7a8fdb31f78b0
- Promotion : e6caa4a0e3b7b1611596881c6df38d9d07f65739

## Terrain attendu
Après recharge Firefox :
- Build 40.6.164 ;
- G2/G7 restent FOUNDATION_PASS ;
- Evidence Dossier reste monté ;
- nouveau bloc G3 visible ;
- attendu avec l'état courant : 300 pts / 24h / 5 min / 100 %, 483 observations, 2/2 CURRENT ;
- Labels outcome certifiés = NON ;
- Dataset replay certifié = NON ;
- G3 = PENDING.
