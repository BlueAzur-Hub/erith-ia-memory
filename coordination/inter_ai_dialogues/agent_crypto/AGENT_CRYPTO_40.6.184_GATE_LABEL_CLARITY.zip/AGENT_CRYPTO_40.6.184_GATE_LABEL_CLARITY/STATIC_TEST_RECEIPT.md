# STATIC TEST RECEIPT — 40.6.184

- Node syntax: PASS
- Scope: `#strategyADossier` text nodes only
- Visible contract: `G1..G9` → `GATE 1..GATE 9`
- Internal IDs/keys/states: UNCHANGED
- Market Core: 38.15.11 UNCHANGED
- Strategy A business logic: UNCHANGED
- Real order: OFF
- PAPER ONLY: YES
- MutationObserver: NONE
- Recurring timer: NONE
- Storage/network/exchange path: NONE
- Firefox terrain: PENDING
