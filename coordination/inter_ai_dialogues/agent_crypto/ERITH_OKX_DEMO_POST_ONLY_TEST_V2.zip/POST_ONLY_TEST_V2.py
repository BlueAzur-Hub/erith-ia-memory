#!/usr/bin/env python3
from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request
import urllib.error
from decimal import Decimal, ROUND_CEILING
from pathlib import Path
from datetime import datetime

BRIDGE = "http://127.0.0.1:8787"
OKX = "https://eea.okx.com"
INST = "BTC-EUR"
TARGET_EUR = Decimal("10")
ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
LOG = ROOT / "post_only_test_v2.log"

def log(msg=""):
    print(msg, flush=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")

def http_json(method, url, body=None, timeout=20):
    data = None
    headers = {"Content-Type": "application/json", "User-Agent": "ERITH-POSTONLY-TEST-V2"}
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", errors="replace")
            return r.status, json.loads(raw)
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        try:
            obj = json.loads(raw)
        except Exception:
            obj = {"raw": raw}
        return e.code, obj

def D(x):
    return Decimal(str(x))

def ceil_to_step(value: Decimal, step: Decimal) -> Decimal:
    units = (value / step).to_integral_value(rounding=ROUND_CEILING)
    return units * step

def main():
    LOG.write_text("", encoding="utf-8")
    log("============================================================")
    log("ERITH · OKX DEMO · POST-ONLY TEST V2")
    log("============================================================")
    log("")

    # 1) Bridge
    s, health = http_json("GET", BRIDGE + "/health")
    if s != 200 or not health.get("ok") or not health.get("demo"):
        raise RuntimeError(f"Bridge non prêt: HTTP {s} · {health}")
    if health.get("instrument") != INST:
        raise RuntimeError(f"Instrument Bridge inattendu: {health.get('instrument')}")
    log(f"[OK] Bridge DEMO : {health.get('bind')}")
    log(f"[OK] Instrument   : {health.get('instrument')}")

    # 2) Public market + rules
    qs = urllib.parse.urlencode({"instId": INST})
    s1, ticker = http_json("GET", OKX + "/api/v5/market/ticker?" + qs)
    if s1 != 200 or str(ticker.get("code")) != "0" or not ticker.get("data"):
        raise RuntimeError(f"Ticker indisponible: HTTP {s1} · {ticker}")

    qs2 = urllib.parse.urlencode({"instType": "SPOT", "instId": INST})
    s2, inst = http_json("GET", OKX + "/api/v5/public/instruments?" + qs2)
    if s2 != 200 or str(inst.get("code")) != "0" or not inst.get("data"):
        raise RuntimeError(f"Instrument indisponible: HTTP {s2} · {inst}")

    t = ticker["data"][0]
    i = inst["data"][0]

    bid = D(t["bidPx"])
    ask = D(t["askPx"])
    tick = D(i["tickSz"])
    lot = D(i["lotSz"])
    min_sz = D(i["minSz"])

    # Post-only BUY strictly below current best bid.
    px = bid - tick
    raw_sz = TARGET_EUR / px
    sz = ceil_to_step(raw_sz, lot)
    if sz < min_sz:
        sz = min_sz

    px_s = format(px, "f")
    sz_s = format(sz, "f")
    notion = px * sz

    log(f"[MARKET] bid={bid} ask={ask} tick={tick} lot={lot} minSz={min_sz}")
    log(f"[ORDER] DEMO BUY POST_ONLY {INST}")
    log(f"[ORDER] px={px_s} · sz={sz_s} BTC · notion≈{notion:.2f} EUR")
    log("")

    # 3) Place through authenticated Demo Bridge
    s3, placed = http_json(
        "POST",
        BRIDGE + "/demo/post-only",
        {"side": "buy", "px": px_s, "sz": sz_s},
    )
    if s3 != 200:
        raise RuntimeError(f"Bridge/OKX a refusé l'ordre: HTTP {s3} · {json.dumps(placed, ensure_ascii=False)}")
    if str(placed.get("code")) != "0" or not placed.get("data"):
        raise RuntimeError(f"OKX a refusé l'ordre: {json.dumps(placed, ensure_ascii=False)}")

    row = placed["data"][0]
    if str(row.get("sCode", "0")) != "0":
        raise RuntimeError(f"OKX sCode={row.get('sCode')} · {row.get('sMsg')}")

    ord_id = str(row.get("ordId", "")).strip()
    if not ord_id:
        raise RuntimeError(f"ordId absent: {placed}")

    log(f"[PLACED] ordId={ord_id}")

    snapshots = []
    elapsed = 0
    for wait_to in (2, 10, 20):
        time.sleep(wait_to - elapsed)
        elapsed = wait_to
        sq = urllib.parse.urlencode({"ordId": ord_id})
        so, order = http_json("GET", BRIDGE + "/demo/order?" + sq)
        if so != 200 or str(order.get("code")) != "0" or not order.get("data"):
            raise RuntimeError(f"Lecture ordre impossible T+{wait_to}: HTTP {so} · {order}")
        od = order["data"][0]
        snap = {
            "after_s": wait_to,
            "state": od.get("state"),
            "accFillSz": od.get("accFillSz"),
            "avgPx": od.get("avgPx"),
            "fee": od.get("fee"),
            "feeCcy": od.get("feeCcy"),
            "uTime": od.get("uTime"),
        }
        snapshots.append(snap)
        log(f"[T+{wait_to}] state={snap['state']} · fill={snap['accFillSz']} · avgPx={snap['avgPx']} · fee={snap['fee']} {snap['feeCcy']}")
        if snap["state"] in ("filled", "canceled"):
            break

    # 4) Cancel only if still resting/partial
    sq = urllib.parse.urlencode({"ordId": ord_id})
    so, current = http_json("GET", BRIDGE + "/demo/order?" + sq)
    if so != 200 or str(current.get("code")) != "0" or not current.get("data"):
        raise RuntimeError(f"Lecture finale impossible: HTTP {so} · {current}")

    state = current["data"][0].get("state")
    if state in ("live", "partially_filled"):
        log(f"[CANCEL] ordre encore {state} après {elapsed}s.")
        sc, cancel = http_json("POST", BRIDGE + "/demo/cancel", {"ordId": ord_id})
        if sc != 200 or str(cancel.get("code")) != "0":
            raise RuntimeError(f"Annulation impossible: HTTP {sc} · {cancel}")
        time.sleep(2)

    sf, final = http_json("GET", BRIDGE + "/demo/order?" + sq)
    if sf != 200 or str(final.get("code")) != "0" or not final.get("data"):
        raise RuntimeError(f"Lecture résultat impossible: HTTP {sf} · {final}")
    f = final["data"][0]

    REPORTS.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = REPORTS / f"okx_demo_post_only_v2_{stamp}.json"
    report = {
        "mode": "OKX_DEMO",
        "instrument": INST,
        "target_eur": str(TARGET_EUR),
        "market": {"bid": str(bid), "ask": str(ask), "tickSz": str(tick), "lotSz": str(lot), "minSz": str(min_sz)},
        "order": {"side": "buy", "ordType": "post_only", "px": px_s, "sz": sz_s, "ordId": ord_id},
        "snapshots": snapshots,
        "final": {
            "state": f.get("state"),
            "accFillSz": f.get("accFillSz"),
            "avgPx": f.get("avgPx"),
            "fee": f.get("fee"),
            "feeCcy": f.get("feeCcy"),
            "cTime": f.get("cTime"),
            "uTime": f.get("uTime"),
        },
    }
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    log("")
    log("================ RÉSULTAT ================")
    log(f"state={report['final']['state']}")
    log(f"accFillSz={report['final']['accFillSz']}")
    log(f"avgPx={report['final']['avgPx']}")
    log(f"fee={report['final']['fee']} {report['final']['feeCcy']}")
    log(f"rapport={report_path}")
    log("==========================================")
    return 0

if __name__ == "__main__":
    code = 1
    try:
        code = main()
    except Exception as e:
        try:
            log("")
            log("!!!!!!!!!!!!!!!! ERREUR !!!!!!!!!!!!!!!!")
            log(f"{type(e).__name__}: {e}")
            log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            log(f"log={LOG}")
        except Exception:
            print(f"ERREUR: {type(e).__name__}: {e}")
        code = 1
    finally:
        print()
        input("Entrée pour fermer cette fenêtre...")
    raise SystemExit(code)
