@echo off
setlocal
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY TEST V2

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0POST_ONLY_TEST_V2.py"
) else (
  python "%~dp0POST_ONLY_TEST_V2.py"
)

echo.
echo Le script est terminé.
pause
endlocal
