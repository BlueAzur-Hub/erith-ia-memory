# Agent-Crypto 40.6.332 — Security Badge Alignment

Scope: collapsed summaries for Security and Physical Security only.

Observed Firefox defect:
- VERROUS · HUMAIN · PAPER dropped under the Security title;
- LOCAL · COFFRE · RÉEL VERROUILLÉ dropped under the Physical Security title.

Correction:
- preserve the existing 40.6.329 security facade;
- explicitly assign icon, title, subtitle and status pseudo-badge to their intended grid cells;
- keep a dedicated responsive layout under 1050 px;
- no content or business logic changes.

Protected:
Market Core 38.15.11, Aether 40.6.322, Strategy A, Gates, Storage, command handlers, security policy and physical-security content.

Local Chromium geometry proof:
- desktop summary height 70 px;
- title/subtitle share row 1;
- badge grid-column 4 / grid-row 1 / centered;
- responsive badge column 3 spanning both text rows.

Firefox operator terrain validation remains required.
