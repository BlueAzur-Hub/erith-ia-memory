AGENT-CRYPTO · AETHER CONTROL · CONTROL CENTER R15
=================================================

VERSION
- Control Center : 2.3.2R15
- Bridge moteur : V1.9.11 INCHANGÉ
- Private Backend : V1.4.2 — OKX WAVE 1
- Administrator ouvert : 40.6.86 PROTÉGÉ
- Ports locaux : Bridge 8787 · Private Backend 8790

OBJECTIF UNIQUE
Ajouter OKX comme quatrième observation CEX de la future Source Truth, sans toucher au Market Core ni créer d'exécution.

BACKEND V1.4.2
- Kraken Public : READ ONLY
- Coinbase Exchange : READ ONLY
- OKX Public Market Data : READ ONLY
- DEX Screener / GeckoTerminal / DefiLlama : contexte uniquement
- /system : télémétrie locale en lecture seule
- aucune clé exchange, aucun compte, wallet, ordre, retrait ou signature
- aucune conversion USDT→EUR de secours : une paire OKX/EUR absente reste indisponible

R15
- conserve Bridge 8787 et Backend 8790 comme deux services séparés ;
- supervise Private Backend V1.4.2 ;
- reste compatible Windows natif / Wine pour le Control Center ;
- ouvre volontairement Administrator 40.6.86 : la 40.6.87 ne sera publiée qu'après preuve Firefox OKX.

TEST DEMANDÉ SUR LE RYZEN
1. Lancer l'EXE R15.
2. Vérifier BRIDGE actif/prêt V1.9.11.
3. Vérifier PRIVATE BACKEND actif/prêt V1.4.2.
4. Ouvrir http://127.0.0.1:8790/health : OKX doit apparaître dans sources.
5. Ouvrir http://127.0.0.1:8790/quotes?assets=BTC,ETH,BNB,XRP,SOL.
6. Vérifier les lignes provider=okx ; une paire indisponible doit rester unavailable, jamais fabriquée.
7. Administrator reste 40.6.86 à ce stade.
