#!/usr/bin/env python3
"""Agent-Crypto @erith.IA — Private Local Backend V1.4.2 (40.6.87 OKX Wave 1)
Read-only public market source bridge. No credentials, no trading, no wallet endpoints.
"""
from __future__ import annotations

import argparse
import ctypes
import json
import os
import platform
import shutil
import subprocess
import math
import statistics
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "1.4.2"
BUILD = "40.6.87 OKX Wave 1"
HOST = "127.0.0.1"
PORT = 8790
CACHE_TTL_SECONDS = 15
CONTEXT_CACHE_TTL_SECONDS = 90
SYSTEM_CACHE_TTL_SECONDS = 3
REQUEST_TIMEOUT_SECONDS = 4.0
COHERENT_PCT = 0.25
WATCH_PCT = 0.75
MAX_ASSETS = 10
DEFAULT_ASSETS = ("BTC", "ETH", "BNB", "XRP", "SOL")
ALLOWED_ORIGINS = {
    "https://blueazur-hub.github.io",
    "http://127.0.0.1",
    "http://localhost",
}

KRAKEN_PAIRS = {
    "BTC": "XBTEUR",
    "ETH": "ETHEUR",
    "BNB": "BNBEUR",
    "XRP": "XRPEUR",
    "SOL": "SOLEUR",
}
COINBASE_PRODUCTS = {asset: f"{asset}-EUR" for asset in DEFAULT_ASSETS}
OKX_INSTRUMENTS = {asset: f"{asset}-EUR" for asset in DEFAULT_ASSETS}
DEX_SEARCH = {
    "BTC": "WBTC/USDC",
    "ETH": "WETH/USDC",
    "BNB": "WBNB/USDC",
    "XRP": "XRP/USDC",
    "SOL": "SOL/USDC",
}
DEX_ALIASES = {
    "BTC": {"BTC", "WBTC", "CBBTC"},
    "ETH": {"ETH", "WETH"},
    "BNB": {"BNB", "WBNB"},
    "XRP": {"XRP"},
    "SOL": {"SOL", "WSOL"},
}
USD_QUOTES = {"USD", "USDC", "USDT", "DAI", "USDS", "FDUSD", "USD1"}
DEFILLAMA_CHAINS = ("Ethereum", "Solana", "BSC")

# 40.4.57 — bounded identity policy for symbol-discovered DEX pools.
# This is deliberately NOT address-level proof. It only prevents obviously
# wrong-chain symbol collisions (for example a token named WETH on Solana)
# from being treated as useful context for ETH.
DEX_NETWORK_ALIASES = {
    "eth": "ethereum",
    "ethereum": "ethereum",
    "arbitrum": "arbitrum",
    "arbitrum-one": "arbitrum",
    "base": "base",
    "optimism": "optimism",
    "op-mainnet": "optimism",
    "bsc": "bsc",
    "binance-smart-chain": "bsc",
    "solana": "solana",
    "xrpl": "xrpl",
    "xrp-ledger": "xrpl",
}
DEX_CHAIN_POLICY = {
    "BTC": {"ethereum", "arbitrum", "base"},
    "ETH": {"ethereum", "arbitrum", "base", "optimism"},
    "BNB": {"bsc"},
    "XRP": {"xrpl"},
    "SOL": {"solana"},
}
LIQUIDITY_RATIO_REVIEW = 20.0

SOURCE_REGISTRY = (
    {
        "id": "kraken",
        "label": "Kraken Public",
        "mode": "read_only_public",
        "role": "spot EUR · independent control",
        "auth_required": False,
        "base_url": "https://api.kraken.com/0/public",
    },
    {
        "id": "coinbase",
        "label": "Coinbase Exchange",
        "mode": "read_only_public",
        "role": "public market data · independent control",
        "auth_required": False,
        "base_url": "https://api.exchange.coinbase.com",
    },
    {
        "id": "okx",
        "label": "OKX Public",
        "mode": "read_only_public",
        "role": "spot EUR · independent control",
        "auth_required": False,
        "base_url": "https://www.okx.com/api/v5",
    },
    {
        "id": "dexscreener",
        "label": "DEX Screener",
        "mode": "read_only_public",
        "role": "DEX liquidity discovery · context only",
        "auth_required": False,
        "base_url": "https://api.dexscreener.com",
    },
    {
        "id": "geckoterminal",
        "label": "GeckoTerminal",
        "mode": "read_only_public",
        "role": "DEX pool cross-check · context only",
        "auth_required": False,
        "base_url": "https://api.geckoterminal.com/api/v2",
    },
    {
        "id": "defillama",
        "label": "DefiLlama",
        "mode": "read_only_public",
        "role": "DeFi aggregate context · DEX volume / chain TVL",
        "auth_required": False,
        "base_url": "https://api.llama.fi",
    },
)

_cache_lock = threading.Lock()
_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
_gt_semaphore = threading.Semaphore(2)
_system_lock = threading.Lock()
_system_cache: Tuple[float, Dict[str, Any]] = (0.0, {})
_cpu_sample: Optional[Tuple[int, int, int]] = None
QUIET = False


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _number(value: Any) -> Optional[float]:
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    return n if math.isfinite(n) else None


def _fetch_json(url: str, extra_headers: Optional[Dict[str, str]] = None) -> Any:
    headers = {
        "Accept": "application/json",
        "User-Agent": f"Agent-Crypto-Private-Backend/{VERSION}",
        "Cache-Control": "no-cache",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, method="GET", headers=headers)
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}")
        return json.loads(response.read().decode("utf-8"))


def _quote_error(provider: str, asset: str, pair: str, exc: Exception) -> Dict[str, Any]:
    return {
        "provider": provider,
        "asset": asset,
        "pair": pair,
        "status": "unavailable",
        "error": str(exc)[:180],
        "observed_at_utc": utc_now(),
    }


def fetch_kraken(asset: str) -> Dict[str, Any]:
    pair = KRAKEN_PAIRS.get(asset, f"{asset}EUR")
    url = "https://api.kraken.com/0/public/Ticker?" + urllib.parse.urlencode({"pair": pair})
    try:
        payload = _fetch_json(url)
        errors = payload.get("error") or []
        if errors:
            raise RuntimeError("; ".join(map(str, errors)))
        result = payload.get("result") or {}
        if not result:
            raise RuntimeError("empty ticker result")
        ticker = next(iter(result.values()))
        return {
            "provider": "kraken",
            "asset": asset,
            "pair": pair,
            "status": "ok",
            "price_eur": _number((ticker.get("c") or [None])[0]),
            "bid_eur": _number((ticker.get("b") or [None])[0]),
            "ask_eur": _number((ticker.get("a") or [None])[0]),
            "volume_24h": _number((ticker.get("v") or [None, None])[1]),
            "observed_at_utc": utc_now(),
            "source_url": url,
        }
    except Exception as exc:
        return _quote_error("kraken", asset, pair, exc)


def fetch_coinbase(asset: str) -> Dict[str, Any]:
    product = COINBASE_PRODUCTS.get(asset, f"{asset}-EUR")
    url = f"https://api.exchange.coinbase.com/products/{urllib.parse.quote(product)}/stats"
    try:
        payload = _fetch_json(url)
        price = _number(payload.get("last"))
        if price is None:
            raise RuntimeError("missing last price")
        return {
            "provider": "coinbase",
            "asset": asset,
            "pair": product,
            "status": "ok",
            "price_eur": price,
            "bid_eur": None,
            "ask_eur": None,
            "volume_24h": _number(payload.get("volume")),
            "observed_at_utc": utc_now(),
            "source_url": url,
        }
    except Exception as exc:
        return _quote_error("coinbase", asset, product, exc)


def _utc_from_unix_ms(value: Any) -> str:
    try:
        ms = int(str(value))
        if ms <= 0:
            raise ValueError("non-positive timestamp")
        return datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    except (TypeError, ValueError, OverflowError):
        return utc_now()


def fetch_okx(asset: str) -> Dict[str, Any]:
    instrument = OKX_INSTRUMENTS.get(asset, f"{asset}-EUR")
    url = "https://www.okx.com/api/v5/market/ticker?" + urllib.parse.urlencode({"instId": instrument})
    try:
        payload = _fetch_json(url)
        if str(payload.get("code", "")) != "0":
            raise RuntimeError(str(payload.get("msg") or f"OKX code {payload.get('code')}"))
        data = payload.get("data") or []
        if not data:
            raise RuntimeError("instrument unavailable or empty ticker result")
        ticker = data[0] or {}
        if str(ticker.get("instId") or instrument).upper() != instrument.upper():
            raise RuntimeError("unexpected instrument")
        price = _number(ticker.get("last"))
        if price is None or price <= 0:
            raise RuntimeError("missing last price")
        return {
            "provider": "okx",
            "asset": asset,
            "pair": instrument,
            "status": "ok",
            "price_eur": price,
            "bid_eur": _number(ticker.get("bidPx")),
            "ask_eur": _number(ticker.get("askPx")),
            "volume_24h": _number(ticker.get("vol24h")),
            "quote_volume_24h": _number(ticker.get("volCcy24h")),
            "observed_at_utc": _utc_from_unix_ms(ticker.get("ts")),
            "source_url": url,
        }
    except Exception as exc:
        return _quote_error("okx", asset, instrument, exc)


def _consensus(quotes: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    prices = [q.get("price_eur") for q in quotes if q.get("status") == "ok" and _number(q.get("price_eur")) is not None]
    prices = [float(p) for p in prices]
    if len(prices) < 2:
        return {"providers": len(prices), "median_eur": prices[0] if prices else None, "spread_pct": None, "verdict": "insufficient"}
    mean = statistics.fmean(prices)
    spread = ((max(prices) - min(prices)) / mean * 100.0) if mean else None
    verdict = "coherent" if spread is not None and spread <= COHERENT_PCT else "watch" if spread is not None and spread <= WATCH_PCT else "divergent"
    return {
        "providers": len(prices),
        "median_eur": statistics.median(prices),
        "min_eur": min(prices),
        "max_eur": max(prices),
        "spread_pct": spread,
        "verdict": verdict,
    }



def _dex_error(provider: str, asset: str, exc: Exception) -> Dict[str, Any]:
    return {
        "provider": provider,
        "asset": asset,
        "status": "unavailable",
        "error": str(exc)[:180],
        "observed_at_utc": utc_now(),
        "context_only": True,
        "identity_proof": False,
    }


def _normalize_network(value: Any) -> Optional[str]:
    raw = str(value or "").strip().lower()
    if not raw:
        return None
    return DEX_NETWORK_ALIASES.get(raw, raw)


def _network_allowed(asset: str, network: Any) -> bool:
    normalized = _normalize_network(network)
    allowed = DEX_CHAIN_POLICY.get(asset, set())
    return bool(normalized and normalized in allowed)


def _dexscreener_pair_orientation(asset: str, pair: Dict[str, Any]) -> Optional[str]:
    aliases = DEX_ALIASES.get(asset, {asset})
    base = str((pair.get("baseToken") or {}).get("symbol") or "").upper()
    quote = str((pair.get("quoteToken") or {}).get("symbol") or "").upper()
    if base in aliases and quote in USD_QUOTES:
        return "asset_base"
    if quote in aliases and base in USD_QUOTES:
        return "asset_quote"
    return None


def _best_dexscreener_pair(asset: str, pairs: Iterable[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    candidates = []
    for pair in pairs or []:
        orientation = _dexscreener_pair_orientation(asset, pair)
        if not orientation:
            continue
        network = _normalize_network(pair.get("chainId"))
        if not _network_allowed(asset, network):
            continue
        liquidity = _number((pair.get("liquidity") or {}).get("usd")) or 0.0
        candidates.append((liquidity, pair))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def fetch_dexscreener(asset: str) -> Dict[str, Any]:
    # Search intended asset/stable pair first, then bounded alias fallback.
    # A result is accepted only when alias orientation AND asset chain policy
    # agree. This rejects obvious symbol collisions while remaining context-only.
    pair_query = DEX_SEARCH.get(asset, f"{asset}/USDC").replace("/", " ")
    alias_query = DEX_SEARCH.get(asset, f"{asset}/USDC").split("/", 1)[0]
    queries = [pair_query] + ([alias_query] if alias_query != pair_query else [])
    try:
        pair = None
        used_url = None
        used_query = None
        for query in queries:
            url = "https://api.dexscreener.com/latest/dex/search?" + urllib.parse.urlencode({"q": query})
            payload = _fetch_json(url)
            pair = _best_dexscreener_pair(asset, payload.get("pairs") or [])
            if pair:
                used_url, used_query = url, query
                break
        if not pair:
            raise RuntimeError("no alias/stable pool on allowed asset network")
        orientation = _dexscreener_pair_orientation(asset, pair)
        network = _normalize_network(pair.get("chainId"))
        raw_pair_price = _number(pair.get("priceUsd"))
        # DEX Screener priceUsd is the base-token price. Do not silently use it
        # as asset price when the asset is on the quote side.
        asset_price = raw_pair_price if orientation == "asset_base" else None
        return {
            "provider": "dexscreener",
            "asset": asset,
            "status": "ok",
            "context_only": True,
            "discovery_method": "symbol_search_chain_bounded_alias_stable_bidirectional",
            "identity_proof": False,
            "identity_status": "bounded_chain_alias",
            "identity_level": "CHAIN_ALIAS_ONLY",
            "query": used_query,
            "queries_attempted": queries[: queries.index(used_query) + 1] if used_query in queries else queries,
            "asset_side": orientation,
            "chain": pair.get("chainId"),
            "network_normalized": network,
            "chain_allowed": True,
            "allowed_networks": sorted(DEX_CHAIN_POLICY.get(asset, set())),
            "dex": pair.get("dexId"),
            "pair_address": pair.get("pairAddress"),
            "base_symbol": (pair.get("baseToken") or {}).get("symbol"),
            "base_address": (pair.get("baseToken") or {}).get("address"),
            "quote_symbol": (pair.get("quoteToken") or {}).get("symbol"),
            "quote_address": (pair.get("quoteToken") or {}).get("address"),
            "asset_address": (pair.get("baseToken") or {}).get("address") if orientation == "asset_base" else (pair.get("quoteToken") or {}).get("address"),
            "stable_address": (pair.get("quoteToken") or {}).get("address") if orientation == "asset_base" else (pair.get("baseToken") or {}).get("address"),
            "asset_price_usd": asset_price,
            "pair_base_price_usd": raw_pair_price,
            "liquidity_usd": _number((pair.get("liquidity") or {}).get("usd")),
            "volume_24h_usd": _number((pair.get("volume") or {}).get("h24")),
            "price_change_24h_pct": _number((pair.get("priceChange") or {}).get("h24")),
            "observed_at_utc": utc_now(),
            "source_url": pair.get("url") or used_url,
        }
    except Exception as exc:
        return _dex_error("dexscreener", asset, exc)


def _gt_network(row: Dict[str, Any]) -> Optional[str]:
    rel = (((row.get("relationships") or {}).get("network") or {}).get("data") or {}).get("id")
    if rel:
        return _normalize_network(rel)
    row_id = str(row.get("id") or "")
    if "_" in row_id:
        return _normalize_network(row_id.split("_", 1)[0])
    return None


def _gt_name_orientation(asset: str, row: Dict[str, Any]) -> Optional[str]:
    aliases = DEX_ALIASES.get(asset, {asset})
    name = str((row.get("attributes") or {}).get("name") or "").upper().replace("-", "/")
    pieces = [piece.strip().split()[0] for piece in name.split("/")[:2] if piece.strip()]
    if len(pieces) < 2:
        return None
    base, quote = pieces[0], pieces[1]
    if base in aliases and quote in USD_QUOTES:
        return "asset_base"
    if quote in aliases and base in USD_QUOTES:
        return "asset_quote"
    return None

def _best_geckoterminal_pool(asset: str, rows: Iterable[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    candidates = []
    for row in rows or []:
        orientation = _gt_name_orientation(asset, row)
        if not orientation:
            continue
        network = _gt_network(row)
        if not _network_allowed(asset, network):
            continue
        attrs = row.get("attributes") or {}
        reserve = _number(attrs.get("reserve_in_usd")) or 0.0
        candidates.append((reserve, row))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def _gt_relationship_address(row: Dict[str, Any], side: str) -> Optional[str]:
    rel = (((row.get("relationships") or {}).get(side) or {}).get("data") or {}).get("id")
    raw = str(rel or "").strip()
    if not raw:
        return None
    return raw.split("_", 1)[1] if "_" in raw else raw

def _normalize_address(network: Any, address: Any) -> Optional[str]:
    raw = str(address or "").strip()
    if not raw:
        return None
    net = _normalize_network(network)
    if net in {"ethereum", "arbitrum", "base", "optimism", "bsc"}:
        return raw.lower()
    return raw

def _asset_address_from_pair(asset: str, item: Dict[str, Any]) -> Optional[str]:
    side = item.get("asset_side")
    if side == "asset_base":
        return item.get("base_address")
    if side == "asset_quote":
        return item.get("quote_address")
    return item.get("asset_address")

def fetch_geckoterminal(asset: str) -> Dict[str, Any]:
    query = DEX_SEARCH.get(asset, f"{asset}/USDC").replace("/", " ")
    url = "https://api.geckoterminal.com/api/v2/search/pools?" + urllib.parse.urlencode({"query": query, "include": "base_token,quote_token"})
    try:
        with _gt_semaphore:
            payload = _fetch_json(url, {"Accept": "application/json;version=20230203"})
        row = _best_geckoterminal_pool(asset, payload.get("data") or [])
        if not row:
            raise RuntimeError("no alias/stable pool on allowed asset network")
        attrs = row.get("attributes") or {}
        network = _gt_network(row)
        orientation = _gt_name_orientation(asset, row)
        volume = attrs.get("volume_usd") or {}
        change = attrs.get("price_change_percentage") or {}
        base_price = _number(attrs.get("base_token_price_usd"))
        quote_price = _number(attrs.get("quote_token_price_usd"))
        asset_price = base_price if orientation == "asset_base" else quote_price if orientation == "asset_quote" else None
        return {
            "provider": "geckoterminal",
            "asset": asset,
            "status": "ok",
            "context_only": True,
            "identity_proof": False,
            "identity_status": "bounded_chain_alias",
            "identity_level": "CHAIN_ALIAS_ONLY",
            "discovery_method": "pool_search_chain_bounded_highest_reserve_alias_stable",
            "query": query,
            "network": network,
            "network_normalized": network,
            "chain_allowed": True,
            "allowed_networks": sorted(DEX_CHAIN_POLICY.get(asset, set())),
            "asset_side": orientation,
            "pool_address": attrs.get("address") or str(row.get("id") or "").split("_", 1)[-1],
            "base_address": _gt_relationship_address(row, "base_token"),
            "quote_address": _gt_relationship_address(row, "quote_token"),
            "asset_address": _gt_relationship_address(row, "base_token") if orientation == "asset_base" else _gt_relationship_address(row, "quote_token"),
            "stable_address": _gt_relationship_address(row, "quote_token") if orientation == "asset_base" else _gt_relationship_address(row, "base_token"),
            "name": attrs.get("name"),
            "asset_price_usd": asset_price,
            "base_token_price_usd": base_price,
            "quote_token_price_usd": quote_price,
            "reserve_usd": _number(attrs.get("reserve_in_usd")),
            "volume_24h_usd": _number(volume.get("h24")),
            "price_change_24h_pct": _number(change.get("h24")),
            "observed_at_utc": utc_now(),
            "source_url": url,
        }
    except Exception as exc:
        return _dex_error("geckoterminal", asset, exc)


def _context_identity_crosscheck(asset: str, ds: Dict[str, Any], gt: Dict[str, Any]) -> Dict[str, Any]:
    providers = [item for item in (ds, gt) if item.get("status") == "ok"]
    networks = sorted({str(item.get("network_normalized") or "") for item in providers if item.get("network_normalized")})
    ds_liq = _number(ds.get("liquidity_usd")) if ds.get("status") == "ok" else None
    gt_liq = _number(gt.get("reserve_usd")) if gt.get("status") == "ok" else None
    ratio = None
    if ds_liq and gt_liq and ds_liq > 0 and gt_liq > 0:
        ratio = max(ds_liq, gt_liq) / min(ds_liq, gt_liq)
    liquidity_review = bool(ratio is not None and ratio >= LIQUIDITY_RATIO_REVIEW)
    same_network = len(networks) == 1 and len(providers) >= 2
    ds_addr = _normalize_address(ds.get("network_normalized"), _asset_address_from_pair(asset, ds)) if ds.get("status") == "ok" else None
    gt_addr = _normalize_address(gt.get("network_normalized"), _asset_address_from_pair(asset, gt)) if gt.get("status") == "ok" else None
    address_crosscheck_available = bool(same_network and ds_addr and gt_addr)
    address_match = bool(address_crosscheck_available and ds_addr == gt_addr)
    address_mismatch = bool(address_crosscheck_available and ds_addr != gt_addr)
    if address_mismatch:
        state, confidence = "review", "low"
        reason = "inter-provider token address mismatch"
    elif address_match and not liquidity_review:
        state, confidence = "proved", "high"
        reason = "same network + alias/stable + inter-provider token address match"
    elif len(providers) >= 2 and not liquidity_review:
        state, confidence = "bounded", "medium"
        reason = "chain + alias bounded; address cross-check unavailable or cross-network"
    elif providers:
        state, confidence = "review" if liquidity_review else "partial", "low"
        reason = "liquidity anomaly" if liquidity_review else "single-provider bounded discovery"
    else:
        state, confidence, reason = "unavailable", "none", "no bounded provider"
    atlas_eligible = state in {"proved", "bounded"} and not liquidity_review and not address_mismatch
    return {
        "asset": asset,
        "status": state,
        "confidence": confidence,
        "reason": reason,
        "providers_ok": len(providers),
        "networks": networks,
        "multi_chain": len(networks) > 1,
        "liquidity_ratio": ratio,
        "liquidity_review": liquidity_review,
        "address_crosscheck_available": address_crosscheck_available,
        "address_level_proof": address_match,
        "address_match": address_match,
        "address_mismatch": address_mismatch,
        "dexscreener_asset_address": ds_addr,
        "geckoterminal_asset_address": gt_addr,
        "atlas_eligible": atlas_eligible,
        "rule": "PROVED only when both providers expose the same asset token address on the same allowed network; otherwise bounded/partial/review",
    }

def fetch_defillama_context() -> Dict[str, Any]:
    def one(chain: str) -> Dict[str, Any]:
        url = f"https://api.llama.fi/overview/dexs/{urllib.parse.quote(chain)}"
        try:
            payload = _fetch_json(url)
            return {
                "chain": chain,
                "status": "ok",
                "dex_volume_24h_usd": _number(payload.get("total24h")),
                "dex_volume_7d_usd": _number(payload.get("total7d")),
                "change_1d_pct": _number(payload.get("change_1d")),
                "observed_at_utc": utc_now(),
                "source_url": url,
            }
        except Exception as exc:
            return {"chain": chain, "status": "unavailable", "error": str(exc)[:180], "observed_at_utc": utc_now()}

    with ThreadPoolExecutor(max_workers=len(DEFILLAMA_CHAINS)) as pool:
        rows = list(pool.map(one, DEFILLAMA_CHAINS))
    chains = [row for row in rows if row.get("status") == "ok"]
    errors = [row for row in rows if row.get("status") != "ok"]
    return {
        "provider": "defillama",
        "status": "ok" if chains else "unavailable",
        "context_only": True,
        "chains": chains,
        "errors": errors,
        "observed_at_utc": utc_now(),
    }


def context_payload(assets: List[str]) -> Dict[str, Any]:
    cache_key = "context:" + ",".join(assets)
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= CONTEXT_CACHE_TTL_SECONDS:
            payload = dict(cached[1])
            payload["cache"] = {"state": "hit", "ttl_seconds": CONTEXT_CACHE_TTL_SECONDS}
            return payload

    tasks = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for asset in assets:
            tasks.append(pool.submit(fetch_dexscreener, asset))
            tasks.append(pool.submit(fetch_geckoterminal, asset))
        tasks.append(pool.submit(fetch_defillama_context))
        results = [future.result() for future in as_completed(tasks)]

    llama = next((item for item in results if item.get("provider") == "defillama"), {"provider": "defillama", "status": "unavailable", "chains": []})
    rows = []
    for asset in assets:
        ds = next((item for item in results if item.get("provider") == "dexscreener" and item.get("asset") == asset), _dex_error("dexscreener", asset, RuntimeError("missing result")))
        gt = next((item for item in results if item.get("provider") == "geckoterminal" and item.get("asset") == asset), _dex_error("geckoterminal", asset, RuntimeError("missing result")))
        identity = _context_identity_crosscheck(asset, ds, gt)
        rows.append({"asset": asset, "dexscreener": ds, "geckoterminal": gt, "identity": identity})

    payload = {
        "schema": "agent_crypto_private_backend_dex_defi_context_v4",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "context_only": True,
        "observed_at_utc": utc_now(),
        "assets": rows,
        "defillama": llama,
        "cache": {"state": "fresh", "ttl_seconds": CONTEXT_CACHE_TTL_SECONDS},
        "quality": {
            "dexscreener_ok": sum(1 for row in rows if row["dexscreener"].get("status") == "ok"),
            "geckoterminal_ok": sum(1 for row in rows if row["geckoterminal"].get("status") == "ok"),
            "defillama_chains_ok": len(llama.get("chains") or []),
            "identity_proved": sum(1 for row in rows if (row.get("identity") or {}).get("status") == "proved"),
            "identity_bounded": sum(1 for row in rows if (row.get("identity") or {}).get("status") == "bounded"),
            "identity_review": sum(1 for row in rows if (row.get("identity") or {}).get("status") == "review"),
            "liquidity_review": sum(1 for row in rows if (row.get("identity") or {}).get("liquidity_review") is True),
        },
        "provenance": {
            "dexscreener": {"class": "DEX_LIQUIDITY_CONTEXT", "mode": "READ_ONLY_PUBLIC", "identity_proof": False},
            "geckoterminal": {"class": "DEX_POOL_CROSSCHECK", "mode": "READ_ONLY_PUBLIC", "identity_proof": False},
            "defillama": {"class": "DEFI_AGGREGATE_CONTEXT", "mode": "READ_ONLY_PUBLIC", "identity_proof": False},
        },
        "rules": {
            "cex_primary_unchanged": "binance",
            "dex_prices_not_promoted_to_cex_truth": True,
            "symbol_search_is_discovery_not_identity_proof": True,
            "wrong_chain_symbol_collision_rejected": True,
            "address_level_identity_proof": "INTER_PROVIDER_WHEN_AVAILABLE",
            "liquidity_ratio_review_threshold": LIQUIDITY_RATIO_REVIEW,
            "financial_signal": False,
        },
        "identity_policy": {
            "type": "chain_alias_plus_inter_provider_address",
            "asset_networks": {asset: sorted(DEX_CHAIN_POLICY.get(asset, set())) for asset in assets},
            "address_level_proof": "INTER_PROVIDER_WHEN_AVAILABLE",
            "wrapped_assets_explicit": True,
        },
        "disclaimer": "DEX/DeFi context only; bounded identity is not canonical asset proof, price truth, execution or financial recommendation",
    }
    with _cache_lock:
        _cache[cache_key] = (now, payload)
    return payload


def normalize_assets(raw: str) -> List[str]:
    items = [item.strip().upper() for item in (raw or "").split(",") if item.strip()]
    if not items:
        items = list(DEFAULT_ASSETS)
    allowed = []
    for asset in items:
        if not asset.replace("_", "").isalnum() or len(asset) > 16:
            continue
        if asset not in allowed:
            allowed.append(asset)
        if len(allowed) >= MAX_ASSETS:
            break
    return allowed


def quotes_payload(assets: List[str]) -> Dict[str, Any]:
    cache_key = "quotes:" + ",".join(assets)
    now = time.monotonic()
    with _cache_lock:
        cached = _cache.get(cache_key)
        if cached and now - cached[0] <= CACHE_TTL_SECONDS:
            payload = dict(cached[1])
            payload["cache"] = {"state": "hit", "ttl_seconds": CACHE_TTL_SECONDS}
            return payload

    tasks = []
    with ThreadPoolExecutor(max_workers=min(6, max(1, len(assets) * 3))) as pool:
        for asset in assets:
            tasks.append(pool.submit(fetch_kraken, asset))
            tasks.append(pool.submit(fetch_coinbase, asset))
            tasks.append(pool.submit(fetch_okx, asset))
        results = [future.result() for future in as_completed(tasks)]

    rows = []
    for asset in assets:
        quotes = sorted((q for q in results if q.get("asset") == asset), key=lambda q: q.get("provider", ""))
        rows.append({"asset": asset, "quotes": quotes, "consensus": _consensus(quotes)})

    providers_ok = len({q.get("provider") for q in results if q.get("status") == "ok"})
    quotes_ok = sum(1 for q in results if q.get("status") == "ok")
    payload = {
        "schema": "agent_crypto_private_backend_quotes_v1",
        "backend_version": VERSION,
        "build": BUILD,
        "read_only": True,
        "observed_at_utc": utc_now(),
        "assets": rows,
        "summary": {"assets": len(assets), "quotes_ok": quotes_ok, "quotes_total": len(results), "providers_ok": providers_ok},
        "thresholds": {"coherent_pct": COHERENT_PCT, "watch_pct": WATCH_PCT},
        "cache": {"state": "fresh", "ttl_seconds": CACHE_TTL_SECONDS},
        "disclaimer": "technical source concordance only; no execution or financial recommendation",
    }
    with _cache_lock:
        _cache[cache_key] = (now, payload)
    return payload



# 1.4.1 — local read-only Windows system telemetry for the Aether operator lane.
# No control/action endpoint is added. GPU is read only through nvidia-smi when present.
class _FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", ctypes.c_uint32), ("dwHighDateTime", ctypes.c_uint32)]


class _MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_uint32),
        ("dwMemoryLoad", ctypes.c_uint32),
        ("ullTotalPhys", ctypes.c_uint64),
        ("ullAvailPhys", ctypes.c_uint64),
        ("ullTotalPageFile", ctypes.c_uint64),
        ("ullAvailPageFile", ctypes.c_uint64),
        ("ullTotalVirtual", ctypes.c_uint64),
        ("ullAvailVirtual", ctypes.c_uint64),
        ("ullAvailExtendedVirtual", ctypes.c_uint64),
    ]


def _filetime_value(value: _FILETIME) -> int:
    return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)


def _windows_cpu_sample() -> Optional[Tuple[int, int, int]]:
    if os.name != "nt":
        return None
    try:
        idle, kernel, user = _FILETIME(), _FILETIME(), _FILETIME()
        ok = ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user))
        if not ok:
            return None
        return (_filetime_value(idle), _filetime_value(kernel), _filetime_value(user))
    except Exception:
        return None


def _cpu_percent() -> Optional[float]:
    global _cpu_sample
    current = _windows_cpu_sample()
    if current is None:
        return None
    previous = _cpu_sample
    if previous is None:
        _cpu_sample = current
        time.sleep(0.08)
        current = _windows_cpu_sample()
        previous = _cpu_sample
        if current is None or previous is None:
            return None
    _cpu_sample = current
    idle_delta = current[0] - previous[0]
    kernel_delta = current[1] - previous[1]
    user_delta = current[2] - previous[2]
    total = kernel_delta + user_delta
    if total <= 0:
        return None
    busy = max(0, total - idle_delta)
    return max(0.0, min(100.0, busy / total * 100.0))


def _memory_snapshot() -> Dict[str, Any]:
    if os.name != "nt":
        return {"usage_pct": None, "used_gb": None, "total_gb": None, "available_gb": None}
    try:
        status = _MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            raise OSError("GlobalMemoryStatusEx failed")
        total = int(status.ullTotalPhys)
        available = int(status.ullAvailPhys)
        used = max(0, total - available)
        gib = 1024 ** 3
        return {
            "usage_pct": round((used / total * 100.0), 1) if total else None,
            "used_gb": round(used / gib, 2),
            "total_gb": round(total / gib, 2),
            "available_gb": round(available / gib, 2),
        }
    except Exception:
        return {"usage_pct": None, "used_gb": None, "total_gb": None, "available_gb": None}


def _gpu_snapshot() -> Dict[str, Any]:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return {"status": "unavailable", "name": None, "usage_pct": None, "temperature_c": None, "memory_used_mb": None, "memory_total_mb": None}
    try:
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        result = subprocess.run(
            [exe, "--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=1.4,
            check=False,
            creationflags=creationflags,
        )
        if result.returncode != 0 or not result.stdout.strip():
            raise RuntimeError((result.stderr or "nvidia-smi unavailable").strip()[:160])
        row = [part.strip() for part in result.stdout.splitlines()[0].split(",")]
        if len(row) < 5:
            raise RuntimeError("unexpected nvidia-smi output")
        return {
            "status": "ok",
            "name": row[0] or None,
            "usage_pct": _number(row[1]),
            "temperature_c": _number(row[2]),
            "memory_used_mb": _number(row[3]),
            "memory_total_mb": _number(row[4]),
        }
    except Exception as exc:
        return {"status": "unavailable", "name": None, "usage_pct": None, "temperature_c": None, "memory_used_mb": None, "memory_total_mb": None, "error": str(exc)[:160]}


def system_payload(force: bool = False) -> Dict[str, Any]:
    global _system_cache
    now = time.time()
    with _system_lock:
        cached_at, cached = _system_cache
        if not force and cached and now - cached_at < SYSTEM_CACHE_TTL_SECONDS:
            return {**cached, "cache": {"state": "cached", "ttl_seconds": SYSTEM_CACHE_TTL_SECONDS}}
        cpu_pct = _cpu_percent()
        memory = _memory_snapshot()
        gpu = _gpu_snapshot()
        payload = {
            "schema": "agent_crypto_private_backend_system_v1",
            "backend_version": VERSION,
            "build": BUILD,
            "read_only": True,
            "observed_at_utc": utc_now(),
            "platform": {"system": platform.system(), "release": platform.release(), "machine": platform.machine()},
            "cpu": {"name": platform.processor() or None, "usage_pct": round(cpu_pct, 1) if cpu_pct is not None else None, "temperature_c": None},
            "gpu": gpu,
            "memory": memory,
            "cache": {"state": "fresh", "ttl_seconds": SYSTEM_CACHE_TTL_SECONDS},
            "capabilities": ["cpu_usage_read", "memory_usage_read", "nvidia_gpu_read_if_available"],
            "forbidden": ["process_kill", "clock_change", "power_control", "fan_control", "overclock", "gpu_control", "filesystem_write"],
        }
        _system_cache = (now, payload)
        return payload


class Handler(BaseHTTPRequestHandler):
    server_version = f"AgentCryptoPrivateBackend/{VERSION}"

    def log_message(self, fmt: str, *args: Any) -> None:
        if not QUIET:
            print(f"[{utc_now()}] {self.client_address[0]} {fmt % args}")

    def _origin(self) -> Optional[str]:
        origin = self.headers.get("Origin")
        return origin if origin in ALLOWED_ORIGINS else None

    def _headers(self, status: int = 200, content_type: str = "application/json; charset=utf-8") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Agent-Crypto-Read-Only", "true")
        origin = self._origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Accept, Content-Type")
        self.end_headers()

    def _json(self, payload: Any, status: int = 200, head: bool = False) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self._headers(status)
        if not head:
            self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        self._headers(HTTPStatus.NO_CONTENT)

    def do_HEAD(self) -> None:
        self._route(head=True)

    def do_GET(self) -> None:
        self._route(head=False)

    def _blocked(self) -> None:
        self._json({"error": "read_only_backend", "allowed_methods": ["GET", "HEAD", "OPTIONS"]}, HTTPStatus.METHOD_NOT_ALLOWED)

    do_POST = _blocked
    do_PUT = _blocked
    do_PATCH = _blocked
    do_DELETE = _blocked

    def _route(self, head: bool) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/health":
            self._json({
                "schema": "agent_crypto_private_backend_health_v1",
                "status": "ready",
                "version": VERSION,
                "build": BUILD,
                "read_only": True,
                "host": HOST,
                "port": PORT,
                "cache_ttl_seconds": CACHE_TTL_SECONDS,
                "context_cache_ttl_seconds": CONTEXT_CACHE_TTL_SECONDS,
                "sources": list(SOURCE_REGISTRY),
                "capabilities": ["public_market_read", "source_registry", "bounded_cache", "provenance", "concordance", "dex_liquidity_context", "defi_aggregate_context", "source_intelligence_contract", "dex_identity_chain_gate", "dex_inter_provider_address_crosscheck", "atlas_eligibility_gate", "liquidity_anomaly_review", "local_system_telemetry_read"],
                "forbidden": ["orders", "trading", "wallet", "withdrawal", "seed", "signature", "exchange_private_api"],
            }, head=head)
            return
        if parsed.path == "/sources":
            self._json({"read_only": True, "sources": list(SOURCE_REGISTRY)}, head=head)
            return
        if parsed.path == "/system":
            self._json(system_payload(), head=head)
            return
        if parsed.path == "/quotes":
            query = urllib.parse.parse_qs(parsed.query)
            assets = normalize_assets((query.get("assets") or [""])[0])
            self._json(quotes_payload(assets), head=head)
            return
        if parsed.path == "/context":
            query = urllib.parse.parse_qs(parsed.query)
            assets = normalize_assets((query.get("assets") or [""])[0])
            self._json(context_payload(assets), head=head)
            return
        self._json({"error": "not_found", "routes": ["/health", "/sources", "/system", "/quotes?assets=BTC,ETH,BNB,XRP,SOL", "/context?assets=BTC,ETH,BNB,XRP,SOL"]}, HTTPStatus.NOT_FOUND, head=head)


def self_test() -> int:
    kraken_fixture = {"error": [], "result": {"XXBTZEUR": {"a": ["100.2", "1", "1"], "b": ["99.8", "1", "1"], "c": ["100.0", "0.1"], "v": ["2", "3"]}}}
    coinbase_fixture = {"open": "95", "high": "105", "low": "90", "volume": "12", "last": "100.1"}
    okx_fixture = {"code":"0","msg":"","data":[{"instType":"SPOT","instId":"BTC-EUR","last":"100.05","askPx":"100.06","bidPx":"100.04","vol24h":"9.5","volCcy24h":"950.0","ts":"1708669508505"}]}
    assert _number(kraken_fixture["result"]["XXBTZEUR"]["c"][0]) == 100.0
    assert _number(coinbase_fixture["last"]) == 100.1
    assert _number(okx_fixture["data"][0]["last"]) == 100.05
    assert _utc_from_unix_ms(okx_fixture["data"][0]["ts"]).endswith("Z")
    c = _consensus([{"status": "ok", "price_eur": 100.0}, {"status": "ok", "price_eur": 100.1}, {"status": "ok", "price_eur": 100.05}])
    assert c["verdict"] == "coherent" and c["providers"] == 3
    ds_fixture = [{"chainId":"ethereum","baseToken":{"symbol":"WETH","address":"0xWETH"},"quoteToken":{"symbol":"USDC","address":"0xUSDC"},"liquidity":{"usd":123456},"priceUsd":"2100"}]
    assert _best_dexscreener_pair("ETH", ds_fixture)["priceUsd"] == "2100"
    ds_reverse = [{"chainId":"ethereum","baseToken":{"symbol":"USDC"},"quoteToken":{"symbol":"WETH"},"liquidity":{"usd":999999},"priceUsd":"1"}]
    assert _best_dexscreener_pair("ETH", ds_reverse) is not None
    assert _dexscreener_pair_orientation("ETH", ds_reverse[0]) == "asset_quote"
    ds_wrong_chain = [{"chainId":"solana","baseToken":{"symbol":"WETH"},"quoteToken":{"symbol":"USDC"},"liquidity":{"usd":9_000_000_000},"priceUsd":"2100"}]
    assert _best_dexscreener_pair("ETH", ds_wrong_chain) is None
    ds_mixed = ds_wrong_chain + [{"chainId":"ethereum","baseToken":{"symbol":"WETH"},"quoteToken":{"symbol":"USDC"},"liquidity":{"usd":2_000_000},"priceUsd":"2100"}]
    assert _best_dexscreener_pair("ETH", ds_mixed)["chainId"] == "ethereum"
    gt_fixture = [{"id":"eth_0xpool","attributes":{"name":"WETH / USDC","reserve_in_usd":"654321","base_token_price_usd":"2100","quote_token_price_usd":"1"},"relationships":{"base_token":{"data":{"id":"eth_0xWETH"}},"quote_token":{"data":{"id":"eth_0xUSDC"}}}}]
    assert _best_geckoterminal_pool("ETH", gt_fixture)["attributes"]["base_token_price_usd"] == "2100"
    gt_wrong_chain = [{"id":"solana_fake","attributes":{"name":"WETH / USDC","reserve_in_usd":"9999999999","base_token_price_usd":"2100"}}]
    assert _best_geckoterminal_pool("ETH", gt_wrong_chain) is None
    gt_mixed = gt_wrong_chain + gt_fixture
    assert _gt_network(_best_geckoterminal_pool("ETH", gt_mixed)) == "ethereum"
    identity = _context_identity_crosscheck("ETH",
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","liquidity_usd":1_000_000},
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","reserve_usd":1_200_000})
    assert identity["status"] == "proved" and identity["address_level_proof"] is True and identity["atlas_eligible"] is True
    anomaly = _context_identity_crosscheck("ETH",
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","liquidity_usd":100_000_000},
        {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xWETH","reserve_usd":1_000_000})
    assert anomaly["status"] == "review" and anomaly["liquidity_review"] is True
    mismatch = _context_identity_crosscheck("ETH", {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xAAA","liquidity_usd":1_000_000}, {"status":"ok","network_normalized":"ethereum","asset_side":"asset_base","base_address":"0xBBB","reserve_usd":1_100_000})
    assert mismatch["status"] == "review" and mismatch["address_mismatch"] is True and mismatch["atlas_eligible"] is False
    assert normalize_assets("btc,eth,btc") == ["BTC", "ETH"]
    system = system_payload(force=True)
    assert system["read_only"] is True and system["schema"] == "agent_crypto_private_backend_system_v1"
    assert set(["cpu", "gpu", "memory"]).issubset(system)
    assert "orders" in {item for item in ["orders", "trading", "wallet"]}
    print("SELF-TEST PASS")
    print(f"version={VERSION} build={BUILD} read_only=true sources={len(SOURCE_REGISTRY)}")
    print("routes=/health,/sources,/system,/quotes,/context ; Kraken + Coinbase + OKX read-only CEX controls ; address-crosschecked DEX identity + source-intelligence contract via public client ; write methods blocked")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Agent-Crypto private local backend — read-only public sources")
    parser.add_argument("--host", default=HOST)
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--quiet", action="store_true", help="suppress request/startup console logs")
    args = parser.parse_args()
    global QUIET
    QUIET = bool(args.quiet)
    if args.self_test:
        return self_test()
    if args.host not in {"127.0.0.1", "localhost"}:
        raise SystemExit("Refusing non-loopback bind: use 127.0.0.1 or localhost")
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    if not QUIET:
        print(f"Agent-Crypto Private Backend V{VERSION} · Build {BUILD}")
        print(f"READ ONLY · http://{args.host}:{args.port} · Kraken + Coinbase + OKX + DEX/DeFi public context + /system")
        print("No API key · no wallet · no order endpoint · Ctrl+C to stop")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
