# Agent-Crypto Private Backend V1.4.2

Backend local **read-only** sur `127.0.0.1:8790`.

## Ajout V1.4.2 — OKX Wave 1

- Ajout de **OKX Public Market Data** comme contrôle CEX indépendant en EUR.
- Endpoint public utilisé : `GET /api/v5/market/ticker?instId={ASSET}-EUR`.
- Actifs demandés : BTC, ETH, BNB, XRP, SOL. Une paire absente reste `unavailable` : aucune conversion USDT→EUR n'est fabriquée.
- `last`, `bidPx`, `askPx`, `vol24h`, `volCcy24h` et `ts` sont lus sans clé API.
- Binance reste le propriétaire LIVE primaire côté Administrator. Kraken, Coinbase et OKX restent des contrôles read-only.
- Aucun endpoint ordre, compte, wallet, retrait, signature ou API privée exchange.

## Continuité V1.4.1

- `GET /system` : CPU Windows, RAM Windows et GPU NVIDIA via `nvidia-smi` si disponible.
- Aucun contrôle système : lecture uniquement.
- `start_private_backend.cmd` démarre avec `pythonw` sans console persistante.
- `start_private_backend_console.cmd` conserve la console pour diagnostic manuel.
- Routes : `/health`, `/sources`, `/quotes`, `/context`, `/system`.

## Wine / Windows

Le backend reste en Python standard (`urllib`, aucun SDK OKX). Le Control Center Windows peut être lancé nativement ou sous Wine. La télémétrie Windows reste protégée par `os.name == "nt"`.

## Test

```powershell
python private_backend.py --self-test
```

Le serveur refuse les binds non-loopback et bloque POST/PUT/PATCH/DELETE.
