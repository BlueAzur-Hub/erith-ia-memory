# Aether Control — Atlas-10 Crypto Bridge 2.3.2R15

R15 integrates **Private Backend V1.4.2 / OKX Wave 1** while preserving the two-service architecture.

Runtime owners remain separate:

- `bridge/bridge.py` — Bridge V1.9.11 on `127.0.0.1:8787`;
- `backend/private_backend.py` — Private Backend V1.4.2 on `127.0.0.1:8790`.

The Windows GUI supervises both services: health, PID ownership, start, stop, restart and separate logs. It opens the protected Administrator **40.6.86** until the OKX frontend candidate receives Firefox proof and earns build 40.6.87.

OKX uses public market-data REST only. No exchange-private API, API key, account, wallet or order code is introduced.

Use the top-level Windows GUI executable for normal operation. `start_private_backend.cmd` remains available as a manual fallback. Sources are in `source/`.
