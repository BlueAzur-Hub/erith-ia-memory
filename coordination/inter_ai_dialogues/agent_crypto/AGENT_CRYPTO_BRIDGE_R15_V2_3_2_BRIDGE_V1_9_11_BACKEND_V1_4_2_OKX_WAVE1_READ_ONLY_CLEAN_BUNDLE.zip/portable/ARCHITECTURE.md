# R15 dual-service supervision architecture

```text
Administrator 40.6.86 (current protected runtime)
        |
        +--> Bridge V1.9.11 · 127.0.0.1:8787
        |       -> Ollama / Atlas / Aerith / Book Mirror / auth
        |
        +--> Private Backend V1.4.2 · 127.0.0.1:8790
                -> Kraken / Coinbase / OKX / DEX / DeFi / system telemetry

Aether Control 2.3.2R15
        -> supervises 8787
        -> supervises 8790
        -> does not merge either runtime
```

## Ownership lock

R15 changes only the Control Center version contract and embeds Private Backend V1.4.2.

Protected owners:
- `bridge/bridge.py` stays V1.9.11;
- `backend/private_backend.py` becomes V1.4.2 for OKX Wave 1;
- Administrator 40.6.86 / Market Core 38.15.11 are not modified by this local bundle.

## Backend adoption

When `8790` is already healthy, R15 can discover the listening PID through Windows, then validates that its command line is `private_backend.py --quiet` before treating it as pilotable. If that proof fails, the process remains external and STOP/RESTART are refused.
