# Agent-Crypto 40.6.293 — AETHER CONTRACT RESTORE

Build terrain à tester : **40.6.293**

Commit structure : `31af446af90ec9300920d3fd46046bf265fbade6`
Commit final : `da81ceacd46aa751c12cc7c55d1b024b094c490b`

## Objet
Restaurer les fonctions Aether existantes avant la régression 40.6.284, sans réécrire le Window Manager générique.

- panneau Aether complet créé avant l'initialisation du Window Manager ;
- runtime/data Aether lourd toujours différé après la consultation ;
- ouverture flottante restaurée seulement si le Window Manager a raccroché Aether ;
- `admin-window-manager.js` inchangé par rapport au baseline 40.6.273 / 40.6.290 ;
- `aether.css` et `aether-v2.css` inchangés ;
- préchargement du master V2 avancé à l'entrée canonique ;
- fond sombre injecté avant la réécriture de `runtime-shell` ;
- aucun nouveau fichier JS/CSS versionné ;
- Market Core 38.15.11 inchangé ;
- Storage gelé.

Ce ZIP est un **bundle de livraison / reprise**. La source canonique exacte est le commit final GitHub ci-dessus.
