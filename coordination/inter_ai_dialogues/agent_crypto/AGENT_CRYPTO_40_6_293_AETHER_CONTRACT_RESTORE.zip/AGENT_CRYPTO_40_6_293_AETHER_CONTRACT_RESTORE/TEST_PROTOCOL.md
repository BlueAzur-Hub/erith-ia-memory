# Firefox terrain — 40.6.293

1. Attendre que le badge affiche **Build 40.6.293**.
2. Recharger la page : fond sombre / Initialisation, pas de longue page blanche.
3. Ouvrir `Aether · ATTENTION` : fenêtre à gauche, barre native cinq contrôles visible.
4. Déplacer Aether.
5. Redimensionner plus petit, puis plus grand.
   - la scène 16:9 reste intacte ;
   - pas de grande plaque noire ;
   - la fenêtre ne part pas hors écran.
6. Fermer puis rouvrir : Aether redevient flottante et utilisable.
7. F5 puis rouvrir : géométrie cohérente.
8. Arrêt. Ne pas reprendre Storage tant que cette Gate n'est pas PASS.
