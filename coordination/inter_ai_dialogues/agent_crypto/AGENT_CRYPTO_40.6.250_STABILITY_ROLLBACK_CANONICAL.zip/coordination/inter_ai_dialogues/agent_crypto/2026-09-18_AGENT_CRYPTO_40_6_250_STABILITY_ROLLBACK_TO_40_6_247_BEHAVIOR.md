# AGENT-CRYPTO 40.6.250 — STABILITY ROLLBACK TO 40.6.247 BEHAVIOR

Date: 2026-09-18
Release: **40.6.250**
Parent: **40.6.249**
Known terrain baseline: **40.6.247**
Market Core: **38.15.11**
Mode: **PAPER ONLY**
G3: **PENDING**
G9: **LOCKED**

Firefox terrain still showed a slowdown banner and incomplete / blank rendering after 40.6.248 and 40.6.249.

Repository comparison isolated the post-40.6.247 Administrator runtime delta to:
- build.json
- js/decision-intelligence-acceptance.js
- js/decision-intelligence-current-truth-406243.js

40.6.250 restores the 40.6.247 behavior of both Decision Intelligence JavaScript owners while preserving the rest of the current repository and current market data.

Commits:
- runtime rollback: 4fef4b1cb49582df05b4f11227d55aba7f1a5bc8
- acceptance rollback: 9f3e2a919bfd3c582c1a610039e8dda36e55b97d
- release manifest: 5026f97fe1353dc53dea7bc64b35eba30ccdccce
- receipt: c32363af53ebb1baf97dad4d0cd849c40beb0b23

Important delivery finding:
the historical archives supplied as “versions” include many PATCH / receipt bundles rather than standalone builds. The previous 40.6.249 ZIP was not a canonical full repository snapshot and its reduced build.json must not replace the canonical GitHub manifest wholesale.
