# PACKAGE SCOPE

This archive is an exact bounded recovery package for Agent-Crypto 40.6.250.

It contains the three canonical Administrator files changed by the 40.6.250 rollback plus the canonical receipt and manifest.

It is intentionally NOT presented as a full standalone copy of the complete repository.

Canonical runtime source remains the GitHub repository at the commit chain recorded in PATCH_MANIFEST.json.

Do not replace unrelated Administrator files with older historical ZIP contents.
