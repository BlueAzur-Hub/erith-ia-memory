# Upload manuel — Build 28.1.93

## 1. Interface

Chemin GitHub :

`public/agent_crypto_erith_ia/web/`

Remplacer uniquement :

- `app.js`
- `index.html`
- `style.css`

Les trois fichiers se trouvent dans le dossier `web/` du pack.

## 2. Publication partagée

Chemin GitHub déjà existant :

`public/agent_crypto_erith_ia/data/`

Ajouter ou remplacer :

- `latest_atlas_aerith_synthesis.json`

Le fichier se trouve dans le dossier `data/` du pack.

## Commit

`publish atlas aerith synthesis through data build 28.1.93`

## Fonctionnement

Ryzen :

1. Atlas produit les quatre rapports.
2. Aerith produit la conclusion.
3. Le bouton `Préparer publication Book` crée toujours :
   `latest_atlas_aerith_synthesis.json`
4. Ce fichier remplace ensuite manuellement celui du dossier GitHub `data/`.

Book :

1. Ouvrir l’Interface habituelle.
2. L’Interface lit automatiquement le fichier du dossier `data/`.
3. Une publication plus récente est validée puis enregistrée dans IndexedDB.
4. Une publication identique ou plus ancienne ne remplace pas la mémoire locale.
5. Si GitHub est indisponible, les dernières données IndexedDB restent affichées.

L’import JSON manuel demeure disponible comme secours.

Aucune écriture GitHub automatique n’a été effectuée.
