# Validation — Build 28.1.93

## Architecture retenue

Le répertoire GitHub existant est utilisé :

`public/agent_crypto_erith_ia/data/`

Fichier canonique unique :

`latest_atlas_aerith_synthesis.json`

Depuis l’Interface située dans `web/`, la lecture utilise le chemin relatif
même domaine :

`../data/latest_atlas_aerith_synthesis.json`

Aucun accès au réseau local Ryzen n’est nécessaire sur le Book.

## Verrou 28.1.92 conservé

- IndexedDB inchangé ;
- restauration après F5 inchangée ;
- import manuel inchangé ;
- aucun stockage de synthèse dans localStorage ;
- aucun quatrième fichier JavaScript ;
- Bridge V1.7.4 inchangé.

## Tests exécutés

- JavaScript : syntaxe valide ;
- HTML : structure analysée ;
- CSS : accolades équilibrées ;
- démarrage Book sans mémoire :
  - publication GitHub chargée ;
  - rapports Atlas 4/4 ;
  - conclusion Aerith disponible ;
  - écriture et relecture IndexedDB valides ;
- redémarrage :
  - IndexedDB restaurée ;
  - publication identique classée « À jour » ;
- GitHub indisponible :
  - mémoire IndexedDB conservée ;
  - aucun effacement ;
- publication GitHub plus ancienne :
  - mémoire locale plus récente conservée ;
- export de publication :
  - nom canonique exact ;
  - chemin du dépôt inscrit dans les métadonnées ;
- mauvais JSON de mémoire de marché :
  - refusé ;
- localStorage forcé en erreur de quota :
  - sans effet sur la synthèse.

## Limite honnête

La preuve finale reste l’ouverture réelle de GitHub Pages sur le Ryzen et le
Transformer Book après téléversement des quatre fichiers.
