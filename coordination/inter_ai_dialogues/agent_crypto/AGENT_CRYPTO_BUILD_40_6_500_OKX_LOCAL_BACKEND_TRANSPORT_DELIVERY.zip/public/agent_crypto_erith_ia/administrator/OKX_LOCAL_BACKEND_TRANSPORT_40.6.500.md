# Agent-Crypto 40.6.500 — OKX Local Backend Transport

Terrain repair for 40.6.498 Candles and 40.6.499 Microstructure: Firefox/GitHub Pages direct OKX fetches returned NetworkError.

40.6.500 adds a bounded browser shim that routes only public OKX market GETs for candles, ticker, books, books-rpi and trades to the local Private Backend on 127.0.0.1:8790.

Required local companion: Aether Control 2.3.2R19; Bridge V1.9.13 unchanged; Private Backend V1.4.4.

Protected: Market Core 38.15.11, native Prix/Base100, Strategy thresholds, Cost Gate, Oracle Math, Atlas CURRENT, Aether, Lecture Technique, Web Classique.

Terrain: pending Firefox/Ryzen proof.
