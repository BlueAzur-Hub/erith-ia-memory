@echo off
setlocal
cd /d "%~dp0"
title ERITH - OKX DEMO POST-ONLY FILL QUALITY LAB V6

echo ============================================================
echo ERITH - OKX DEMO - POST-ONLY FILL QUALITY LAB V6
echo ============================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)

%PY% -c "import websocket" >nul 2>nul
if not %errorlevel%==0 (
  echo [SETUP] Installation de websocket-client...
  %PY% -m pip install --user websocket-client
  if not %errorlevel%==0 (
    echo [ERREUR] Installation websocket-client impossible.
    pause
    exit /b 1
  )
)

%PY% "%~dp0POST_ONLY_FILL_QUALITY_LAB_V6.py"
echo.
pause
