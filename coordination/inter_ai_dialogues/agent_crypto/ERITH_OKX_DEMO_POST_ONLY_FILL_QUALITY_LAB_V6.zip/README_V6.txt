ERITH · OKX DEMO · POST-ONLY FILL QUALITY + ADVERSE SELECTION LAB V6

DOSSIER
Copier ces fichiers dans :
C:\ERITH\okx-demo-bridge\

REQUIS EXISTANT
- okx-demo.env
- ERITH_OKX_DEMO_BRIDGE_V2 en cours d'exécution sur 127.0.0.1:8791
- clé OKX DEMO avec Read + Trade

LANCEMENT
RUN_POST_ONLY_FILL_QUALITY_LAB_V6.bat

CE QUE V6 MESURE
- 50 BUY Post-only DEMO BTC-EUR, ~10 EUR, au best bid
- timeout ordre : 60 s
- fill complet / partiel / no-fill
- fillTime, tradeId, avgPx, fee, feeRate lorsque fournis par OKX
- distribution P(fill <= 1/2/5/10/20/30/60 s)
- carnet public WebSocket :
  - bbo-tbt
  - books
  - books-rpi
- profondeur organique au bid, nombre d'ordres agrégé au niveau
- imbalance top 10 organique et RPI
- part RPI au niveau exact lorsque disponible
- markout après événement à +1/+5/+15/+30/+60/+300/+900 s
- comparaison marché après FILL vs marché après NO-FILL
- delta fill - no-fill :
  négatif = signal compatible avec adverse selection
  (ce n'est pas, à lui seul, une preuve causale)
- fee maker/taker applicable via GET /api/v5/account/trade-fee

FICHIERS DE SORTIE
reports\post_only_fill_quality_lab_v6_LIVE.json
  - réécrit en continu, utile en cas d'interruption
reports\post_only_fill_quality_lab_v6_FINAL_YYYYMMDD_HHMMSS.json
  - rapport final à envoyer à Seven

IMPORTANT
- DEMO uniquement.
- Tous les ordres passent par le Bridge 8791 qui doit annoncer demo=true.
- V6 ne contient aucune route live, aucun retrait, aucun transfert.
- V6 ne place PAS d'ordre de sortie.
- La profondeur observée n'est PAS une position exacte dans la file.
- Les résultats Demo ne sont PAS une probabilité de fill live.
- Strategy A V1 / Market Core / seuils ne sont pas modifiés.

DUREE
- 50 tentatives séquentielles.
- un no-fill peut durer jusqu'à 60 s.
- après le dernier ordre, le programme attend jusqu'à +15 min pour terminer les markouts.
- durée totale dépend donc du nombre de no-fill.
