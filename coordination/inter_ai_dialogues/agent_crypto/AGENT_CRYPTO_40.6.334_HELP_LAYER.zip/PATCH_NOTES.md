# Agent-Crypto 40.6.334 — HELP LAYER

Presentation-only contextual help. Cyan ? beside the three views. Topics: Menu, LiveCheck, Graphique, Lecture Technique, Target Top/Market Flow, Market Snapshot, Math Core. No timer, observer, storage, network or business logic. Aether untouched. Parent Shared Memory 40.6.333 operator test remains deferred.
