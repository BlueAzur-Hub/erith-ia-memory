# Atlas-10 Crypto Bridge — R17 / Bridge V1.9.13 — Verification Report

Date: 2026-09-30

## Trigger

R16 / Bridge V1.9.12 reached `READY`, authenticated GitHub successfully, but two operator attempts to ingest the first 500-Evidence bundle failed with `The write operation timed out`. No cold chunk or manifest entry was committed and local Evidence remained intact.

## Root-cause corrections

1. Oracle Evidence blob creation had a hard 25 s GitHub timeout. R17 uses 180 s for large blob writes plus one bounded retry.
2. GitHub Repository Contents does not embed normal file content for files above 1 MiB. R17 requests object metadata, obtains the blob SHA, then performs exact readback through the Git Blob endpoint.
3. Small Git operations use 45 s; cold readback uses 120 s.
4. Exhausted timeouts surface as `GITHUB_TIMEOUT` instead of raw urllib exceptions.

## Version truth

- Control Center: 2.3.2R17
- Bridge: V1.9.13
- Private Backend: V1.4.2 unchanged
- Agent-Crypto target: 40.6.485
- Bridge: 127.0.0.1:8787
- Backend: 127.0.0.1:8790
- Seven Vault: 127.0.0.1:8780 outside scope

## Static proof

PASS:
- Python compile of Bridge and Backend;
- real 500-Evidence bundle accepted; payload JSONL = 4,269,455 bytes;
- known SHA-256 preserved: 0492dd842d38040854d445d40f51e2030d43d474d6e934d65b8d3aed6871a66f;
- simulated first timeout then success: retry PASS;
- simulated repeated timeout: clear `GITHUB_TIMEOUT` PASS;
- simulated >1 MiB readback path: object metadata -> Git Blob PASS;
- Windows x86-64 GUI build PASS;
- deterministic second rebuild produced identical EXE SHA-256;
- Private Backend V1.4.2 hash unchanged.

## Hashes

- bridge.py: `abc821e68bc77d183894581c743a085a450edfa06b49348a7c0f374a834b7ec4`
- bridge_config.json: `9b814ebe1bfacffd05320217af0fa3b019eefc49a032bec529bcc7fbcd951d3a`
- private_backend.py: `77a69691932ebcfb82bc43c6e0da9289bad08054753280a8f80e6ab8d5a8bc7f`
- main.go: `be5977d870ab738ce8c7d7b13341d312b7d7d22747d1c089d08702f481fe3da0`
- payload.zip: `6c8960ea994071b6225ac3a2966c278c3ffdd25dd5a1eb7fcb3e7027b1bb7c68`
- R17 EXE: `137bd1ac81a3cb8895e18bc1ef15236031f12e15156c676a17e145274c6bd313`

## Safety lock

No local Evidence delete. No retention reduction. No generic GitHub browser write. No token in Firefox. Backend 8790 remains read-only. Market Core / Strategy / Oracle Math unchanged.

Wine execution was not available here and is not claimed. Final transport proof belongs to the Ryzen Windows terrain test.
