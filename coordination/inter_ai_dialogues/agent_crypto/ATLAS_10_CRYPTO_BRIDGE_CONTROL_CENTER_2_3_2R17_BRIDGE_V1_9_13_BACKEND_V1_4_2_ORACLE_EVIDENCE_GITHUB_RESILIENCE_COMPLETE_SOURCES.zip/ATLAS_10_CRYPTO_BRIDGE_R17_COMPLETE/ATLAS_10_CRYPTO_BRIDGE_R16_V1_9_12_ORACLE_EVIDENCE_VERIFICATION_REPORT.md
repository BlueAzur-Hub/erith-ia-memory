# Atlas-10 Crypto Bridge — R16 / Bridge V1.9.12 — Verification Report

Date: 2026-09-30

## Scope

This release starts from the user-supplied canonical R15 complete-source archive:

- Control Center 2.3.2R15
- Bridge V1.9.11
- Private Backend V1.4.2

It integrates Oracle Evidence cold archive into the **existing authenticated Bridge on 127.0.0.1:8787**.
The temporary standalone Oracle Evidence transport on 127.0.0.1:8791 is superseded and must not be launched.

## Version truth

- Control Center: 2.3.2R16
- Bridge: V1.9.12
- Private Backend: V1.4.2 (unchanged)
- Agent-Crypto target: 40.6.484
- Market Core: 38.15.11 (unchanged)
- Seven Vault: 127.0.0.1:8780 (outside scope)
- Atlas-10 Bridge: 127.0.0.1:8787
- Private Backend: 127.0.0.1:8790

## Oracle Evidence owner

New Bridge capabilities, owner-only and authenticated:

- `oracle_evidence.read`
- `oracle_evidence.publish`

New bounded routes:

- `GET /oracle-evidence/status`
- `POST /oracle-evidence/ingest`

The browser never receives a GitHub credential. The Bridge reuses its existing local GitHub credential resolution and its existing authenticated session/capability policy.

## Ingest contract

The Bridge validates before write:

1. transport-bundle schema;
2. accepted source build (40.6.482 / 40.6.483 / 40.6.484);
3. chunk schema and JSONL payload;
4. safe cold relative path;
5. row count 1..1000;
6. SHA-256;
7. first/last IDs and T0;
8. watermark;
9. every row parses as `atlas.oracle.evidence.v1`;
10. browser-write / token / local-delete flags remain locked false.

Write protocol:

1. atomic Git commit A = JSONL chunk + manifest `WRITTEN_PENDING_VERIFY`;
2. independent readback of the exact Git commit A;
3. recompute SHA-256, row count and JSON parse;
4. Git commit B = manifest entry `VERIFIED`;
5. final manifest reread must expose `VERIFIED`.

The Bridge checks that `main` has not moved before each commit and fails closed instead of force-pushing.

## Retention lock

This release does **not** delete Firefox / IndexedDB Evidence.

- `local_retention_allowed = false`
- no local delete API
- no automatic upload
- no generic GitHub write capability

A future HOT-window/retention release remains blocked until multiple cold chunks are genuinely VERIFIED.

## Static verification performed

PASS:

- `python -m py_compile bridge/bridge.py`
- `python -m py_compile backend/private_backend.py`
- synthetic valid Oracle Evidence bundle accepted
- tampered SHA-256 rejected
- path traversal rejected
- PENDING manifest contract validated
- VERIFIED manifest contract validated
- owner-only route/capability wiring present
- source `payload.zip` copies match the visible Bridge / config / Backend sources
- Windows x86-64 GUI compilation PASS
- second rebuild produced the identical EXE SHA-256
- PE subsystem = Windows GUI (`Subsystem 2`), no host console
- Private Backend V1.4.2 byte hash unchanged from supplied R15 archive
- Atlas/Aerith profile sample hashes unchanged from supplied R15 archive

## Wine / Windows proof boundary

Wine is not installed in the current build environment, so **Wine execution is not claimed as PASS**.
The final operator proof remains the Ryzen Windows launch, Bridge/auth check, one 500-row ingest, GitHub readback verification, and unchanged local Evidence count.
