# Aether Control / Atlas-10 Crypto Bridge — R17 architecture

```text
Seven Vault V7.0.14
        -> 127.0.0.1:8780 (independent)

Aether Control 2.3.2R17
        +--> Bridge V1.9.13 · 127.0.0.1:8787
        |      +--> Ollama / Atlas / Aerith
        |      +--> Aether Trust sessions + capabilities
        |      +--> Book Mirror bounded GitHub publication
        |      `--> Oracle Evidence bounded cold archive
        |
        `--> Private Backend V1.4.2 · 127.0.0.1:8790
               `--> public/read-only market sources incl. OKX
```

## R17 ownership change

R15 already supervised 8787 + 8790. R17 **does not add another local service**.

The temporary Agent-Crypto 40.6.483 transport owner on port 8791 is superseded before operator installation. Oracle Evidence now uses the established authenticated Bridge on 8787.

## Oracle Evidence flow

```text
Firefox / IndexedDB HOT
        -> proven 40.6.482 bundle (500 default, 1000 max)
        -> Bridge 8787 owner session
        -> schema + SHA-256 + row_count + watermark validation
        -> GitHub cold chunk + WRITTEN_PENDING_VERIFY manifest (one atomic commit)
        -> independent GitHub readback
        -> SHA/count/JSON verification
        -> VERIFIED manifest commit
```

40.6.485 / Bridge 1.9.13 still authorizes **zero local deletion**. Future retention remains a separate later scope after multiple VERIFIED chunks.
