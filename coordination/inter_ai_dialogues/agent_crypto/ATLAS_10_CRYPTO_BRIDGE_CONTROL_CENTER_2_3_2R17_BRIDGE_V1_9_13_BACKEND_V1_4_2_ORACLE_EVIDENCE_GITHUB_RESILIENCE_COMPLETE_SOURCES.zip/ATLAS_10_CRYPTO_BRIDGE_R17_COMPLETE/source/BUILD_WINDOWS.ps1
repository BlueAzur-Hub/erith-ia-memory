$ErrorActionPreference = "Stop"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

$Out = "ATLAS_10_CRYPTO_BRIDGE_CONTROL_CENTER_2_3_2R17_BRIDGE_V1_9_13_BACKEND_V1_4_2_OKX_WAVE1_GUI_NO_CONSOLE.exe"
go build -trimpath -ldflags "-H windowsgui -s -w" -o $Out main.go
Write-Host "Compilation terminee : Control Center V2.3.2R17 / Bridge V1.9.13 Oracle Evidence GitHub timeout + large-file readback resilience / Private Backend V1.4.2 OKX Wave 1 READ ONLY / double supervision locale 8787+8790 / Windows GUI / aucune console hote."
