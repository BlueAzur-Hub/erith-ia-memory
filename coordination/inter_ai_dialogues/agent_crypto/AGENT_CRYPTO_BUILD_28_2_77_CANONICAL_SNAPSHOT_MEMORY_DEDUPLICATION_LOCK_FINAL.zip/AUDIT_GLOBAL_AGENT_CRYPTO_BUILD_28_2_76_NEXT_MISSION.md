# Audit global Agent-Crypto — base stable 28.2.76

## Base auditée

- Archive : `AGENT_CRYPTO_BUILD_28_2_76_PUBLICATION_IDENTITY_SINGLE_SOURCE_LOCK_FINAL.zip`
- Build : `28.2.76`
- Base fonctionnelle héritée : `28.2.75 — Public Crypto Market Archive Lock`
- Fichiers inspectés : `app.js`, `index.html`, `style.css`, `version.json`, ainsi que le collecteur et le workflow livrés dans le paquet 28.2.75.

## État validé

- Le marché principal est chargé depuis le snapshot public produit par GitHub Actions.
- Les valeurs CoinGecko USD sont converties en EUR avec le taux BCE.
- Le Decision Board accepte le snapshot public récent.
- Le contrôle de publication 28.2.76 est réparé.
- Binance, les graphiques, les Métaux, News Sentinel, Math Core et le Bridge restent séparés et préservés.

## Défaut structurel restant identifié

La mémoire locale ajoute un nouveau relevé après chaque Livecheck réussi, même lorsque le snapshot public GitHub Actions n'a pas changé.

### Code concerné

- `app.js:12760` — `makeAutoSnapshot()` crée un identifiant local fondé sur l'heure du navigateur.
- `app.js:12762-12771` — `saveAutoSnapshot()` ajoute systématiquement le relevé dans `localStorage`.
- `app.js:12920` — `atlasAfterLivecheck()` sauvegarde après chaque Livecheck valide.
- `app.js:11063-11072` — `atlasDecisionMemoryStats()` compare les deux derniers relevés du même collecteur sans exiger deux snapshots publics canoniques distincts.
- `app.js:5320-5394` — l'identifiant canonique existe pourtant déjà dans `state.sourceLock.snapshotId`.

### Conséquence

Deux rechargements ou deux Livechecks peuvent produire deux enregistrements locaux différents représentant exactement le même snapshot public CoinGecko. Le Decision Board peut alors annoncer plusieurs snapshots et une mémoire comparable alors que le marché source n'a pas réellement avancé.

Ce comportement explique notamment les lectures du type :

- `2 snapshots locaux` ;
- `écart insuffisant entre deux relevés du même collecteur`.

Ce n'est pas une panne du marché, mais une faiblesse du contrat de vérité de la mémoire.

## Mission suivante retenue

### Build 28.2.77 — Canonical Snapshot Memory Deduplication Lock

Objectif : faire correspondre un relevé de mémoire à un snapshot public réellement distinct, et non à chaque rafraîchissement de page.

### Périmètre

1. Ajouter aux relevés locaux :
   - `market_snapshot_id` ;
   - `market_generated_at` ;
   - `market_source_mode` ;
   - provenance publique CoinGecko/BCE.
2. Ne sauvegarder qu'une fois le même `market_snapshot_id` pour un collecteur donné.
3. Comparer deux snapshots publics distincts dans le Decision Board.
4. Afficher explicitement :
   - `1 snapshot public distinct · comparaison en attente` ;
   - ou `2 snapshots publics distincts · comparaison disponible`.
5. Migrer prudemment les anciens relevés sans les supprimer.
6. Conserver l'import de mémoire GitHub, mais dédupliquer selon l'identité canonique du marché.

### Éléments protégés

- formule et seuils du Decision Board ;
- collecteur Crypto GitHub Actions ;
- fréquence toutes les deux heures ;
- conversion BCE ;
- Binance et graphiques ;
- News Sentinel ;
- Métaux ;
- Bridge V1.7.6 et Control Center V2.1.0R1 ;
- simulation locale ;
- géométrie de l'interface.

## Mission non retenue immédiatement

Le code historique des appels directs Top 250 EUR/USD du Build 28.2.74 est encore présent mais n'est plus appelé par `runLivecheck()`. Il constitue une dette technique réelle, mais sans effet visible actuel. Son retrait viendra après la correction de mémoire, qui affecte directement la vérité affichée par le Decision Board.
