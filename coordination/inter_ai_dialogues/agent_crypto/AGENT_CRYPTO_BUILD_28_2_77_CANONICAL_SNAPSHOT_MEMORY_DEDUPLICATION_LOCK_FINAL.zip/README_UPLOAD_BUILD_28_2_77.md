# Agent-Crypto — installation du Build 28.2.77

## Version

**Build 28.2.77 — Canonical Snapshot Memory Deduplication Lock**

Base exacte : **Build 28.2.76 — Publication Identity Single Source Lock**.

## Fichiers à remplacer ensemble

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Aucun workflow, collecteur ou fichier de données n'est remplacé par ce Build.

## Ordre de publication

1. Remplacer les quatre fichiers dans un seul commit GitHub.
2. Utiliser le texte fourni dans `GITHUB_COMMIT_BUILD_28_2_77.txt`.
3. Attendre la propagation normale de GitHub Pages.
4. Recharger l'interface avec le contrôle de mise à jour ou `Ctrl+F5`.

## Vérification visible

L'en-tête doit afficher **Build 28.2.77**.

Dans `Atlas Decision Board → Mémoire comparable`, la lecture doit désormais distinguer :

```text
N snapshots canoniques distincts
M relevés conservés · X doublon(s) neutralisé(s)
```

Un nouveau Livecheck exécuté avant la publication d'un nouveau snapshot GitHub Actions ne doit plus créer un faux point de comparaison. Le nombre de snapshots distincts reste identique.

Après l'arrivée naturelle d'un nouveau snapshot public, le nombre de snapshots distincts peut augmenter d'une unité et la comparaison devient disponible.

Cette attente éventuelle ne bloque ni le marché, ni les graphiques, ni le Decision Board courant : elle concerne uniquement la comparaison mémoire entre deux instants réellement différents.

## Éléments inchangés

- collecteur Crypto public et workflow GitHub Actions ;
- fréquence toutes les deux heures ;
- CoinGecko USD et conversion BCE EUR ;
- prix live Binance et graphiques ;
- formule et seuils du Decision Board ;
- News Sentinel, Watchlist et simulation ;
- Métaux et Math Cores ;
- Bridge V1.7.6 et Control Center V2.1.0R1 ;
- géométrie et identifiants HTML.

Aucune écriture GitHub n'est effectuée par l'assistant.
