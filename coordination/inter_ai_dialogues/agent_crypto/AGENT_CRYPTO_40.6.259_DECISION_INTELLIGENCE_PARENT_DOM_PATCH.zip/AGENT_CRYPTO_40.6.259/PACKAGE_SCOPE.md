# PACKAGE SCOPE — 40.6.259

Ce ZIP est un **patch local borné sur la 40.6.258 publiée**.

Il contient :
- le propriétaire JS complet corrigé ;
- la note de release ;
- le delta de métadonnées Build 40.6.259.

Il ne remplace pas le dépôt complet et ne doit pas être appliqué à une base
antérieure à 40.6.258 comme s'il s'agissait d'un snapshot intégral.

Aucune écriture GitHub n'a été effectuée pendant cette préparation.
