# Handoff — Agent-Crypto 40.6.259

## D
Faire de `Decision Intelligence · vérité courante` un vrai enfant DOM de
`01 · Analyse & décision`.

## Cause 40.6.258
`hostAnchor()` retournait le wrapper `.atlas-layout-family`, puis `mount()`
appelait `insertAdjacentHTML("afterend", markup())` : bon propriétaire trouvé,
mauvaise opération DOM.

## Correction
- `hostFamily()` retourne uniquement la famille 01 réelle ;
- pas de fallback orphelin ;
- `beforeend` dans la famille ;
- un ancien panneau hors parent est réattaché via `appendChild` ;
- largeur forcée sur les 3 colonnes de la grille famille ;
- calcul/cache/métier inchangés.

## Preuve finale requise
Firefox réel.

## Stop
PASS Firefox -> arrêter. Ne pas enchaîner sur NEWS, Shared Memory ou Strategy A
dans cette même validation.
