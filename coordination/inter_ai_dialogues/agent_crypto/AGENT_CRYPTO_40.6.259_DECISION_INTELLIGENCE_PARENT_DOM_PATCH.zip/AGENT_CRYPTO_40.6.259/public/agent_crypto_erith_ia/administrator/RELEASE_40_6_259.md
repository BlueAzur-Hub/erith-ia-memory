# Agent-Crypto 40.6.259 — DECISION INTELLIGENCE · FAMILY 01 TRUE DOM PARENT

Parent canonique : **40.6.258**  
Market Core : **38.15.11 — PROTÉGÉ**

## Objet unique

Corriger l'erreur structurelle encore présente en 40.6.258 :
`Decision Intelligence · vérité courante` était déclarée `analysis`, mais son
montage utilisait le wrapper complet de la famille 01 comme ancre puis
`insertAdjacentHTML("afterend", ...)`, ce qui créait le panneau **hors** de
la famille 01.

## Correction 40.6.259

Fichier propriétaire unique :
`js/decision-intelligence-current-truth.js`

La correction est limitée au parent DOM :

- le parent autorisé est exclusivement `.atlas-layout-family-analysis`
  contenant `#atlasLayoutFamily01` ;
- création avec `family.insertAdjacentHTML("beforeend", markup())` ;
- si un ancien panneau existe déjà hors de 01, il est réattaché avec
  `family.appendChild(details)` ;
- aucun fallback vers `#news-sentinel`, `#multi-horizon` ou une autre famille ;
- le panneau devient donc un **enfant DOM direct** de `01 · Analyse & décision` ;
- la famille 01 étant une grille 3 colonnes, le panneau occupe toute sa largeur
  avec `grid-column: 1 / -1` ;
- moteur de calcul/cache Decision Intelligence inchangé.

## Contrat de non-régression

Non modifiés :

- Market Core 38.15.11 ;
- Atlas CURRENT ;
- Oracle ;
- Lecture Technique ;
- Aether ;
- Strategy A et ses règles métier ;
- Bridge auth ;
- Web Classique ;
- Event Memory / Analogs / Regime / Calibration / Capital Survival /
  Acceptance / Explainability.

Aucun nouveau :

- timer récurrent ;
- MutationObserver ;
- fetch ;
- owner de stockage ;
- ordre réel ;
- chemin d'exécution trading.

## Preuve statique attendue

```text
family 01 (.atlas-layout-family-analysis)
└── Decision Intelligence · vérité courante
```

Le test Firefox reste nécessaire pour la preuve visuelle finale.

## STOP POINT

Après vérification Firefox :

1. `Decision Intelligence` apparaît réellement dans le bandeau/conteneur 01 ;
2. elle n'est plus un bloc autonome entre les familles ;
3. ouverture/fermeture fonctionne ;
4. aucun ralentissement ;
5. Oracle / Lecture Technique / Atlas / Strategy A restent intacts.

Si PASS : **STOP.**
