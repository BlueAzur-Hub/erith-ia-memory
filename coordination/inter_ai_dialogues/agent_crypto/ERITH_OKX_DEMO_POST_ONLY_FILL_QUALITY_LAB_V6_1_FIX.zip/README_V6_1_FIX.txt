ERITH · PATCH LAUNCHER V6.1

Correction unique :
- le premier BAT V6 lisait %errorlevel% à l'intérieur d'un bloc parenthésé ;
- Windows développait cette valeur avant la fin de l'installation pip ;
- il pouvait donc afficher « installation impossible » alors que pip venait d'indiquer
  « Successfully installed websocket-client ».

Le package Python V6 n'est pas modifié.

Copier les deux fichiers dans :
C:\ERITH\okx-demo-bridge\

Puis lancer :
RUN_POST_ONLY_FILL_QUALITY_LAB_V6_1.bat
