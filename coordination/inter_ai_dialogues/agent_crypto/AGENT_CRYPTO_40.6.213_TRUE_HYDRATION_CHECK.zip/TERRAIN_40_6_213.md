# Terrain 40.6.213

1. Reload until `Build 40.6.213 · Administrator`.
2. Do not record another PAPER decision yet.
3. Export the markdown report.
4. Inspect the Evidence host:
   - title contains `TRUE HYDRATION · 40.6.213`
   - HYDRATÉ(S) must match real rendered panels
   - no `MODULE EN ATTENTE` may count as hydrated
5. Send the report back for the next blocker-driven version.
