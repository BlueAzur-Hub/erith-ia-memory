# Agent-Crypto 40.6.213 — TRUE HYDRATION CHECK

Parent: 40.6.212
Engine: Market Core 38.15.11
Mode: PAPER ONLY
G3: PENDING
G9: LOCKED

Terrain 40.6.212:
- Durable-memory block visible and reports MÉMOIRE DURABLE OK.
- Host claimed 9/9 hydrated while seven historical panels still displayed MODULE EN ATTENTE.
- Root cause: hydration was counted from API/function presence rather than rendered content.

40.6.213:
- Placeholder text can no longer count as hydrated.
- The placeholder class is removed only after real owner content replaces MODULE EN ATTENTE.
- Lifecycle truth delegates hydration to the integrator's panel_hydrated() contract.
- Bootstrap settles only when all nine panels are genuinely hydrated.
- No Strategy A business logic, Gate state, Market Core, Atlas, Oracle, Risk Governor or real-order path changed.

Terrain:
Reload to Build 40.6.213 and export the markdown report without recording another PAPER decision.
