AGENT-CRYPTO 40.6.316 — AETHER TRANSIENT GEOMETRY AUTHORITY

Functional commit: 8a8969cef04b284ea3e39fe94dcffe126b1c0119
Purpose: separate durable normal Aether geometry from temporary browser-F11 display geometry.

Repair:
- Window Manager owns win.geometry as durable normal operator state.
- Window Manager owns transientGeometry as display-only state.
- F11 uses transientGeometry; persist=false is no longer enough by itself.
- pointer-up/native CSS resize cannot persist transient geometry.
- workspace snapshots capture durable geometry, not transient F11 geometry.
- dock/hide clears transient geometry.
- bounded RAF state reconciliation closes the Firefox fullScreen/resize race.
- boot integrity repair fixes the proven oversized/non-16:9 left-side leak that creates black bands.
- setGeometry406312 runtime scar removed; API name is stable setGeometry.

Protected / unchanged:
- CSS: unchanged
- Aether artwork/backplate: unchanged
- Market Core 38.15.11: unchanged
- Oracle / Storage schema / Strategy / Lecture Technique: unchanged

Firefox terrain gate:
1. Ctrl+F5.
2. Normal Aether must open compact 16:9 without black side bands.
3. Open/close F12: no Aether jump.
4. Resize Firefox: no false F11.
5. F11: historical large 16:9 field.
6. Click inside Aether while F11, then exit F11: exact normal rectangle must return.
7. Reload: normal rectangle must still be the normal rectangle, never the F11 rectangle.
