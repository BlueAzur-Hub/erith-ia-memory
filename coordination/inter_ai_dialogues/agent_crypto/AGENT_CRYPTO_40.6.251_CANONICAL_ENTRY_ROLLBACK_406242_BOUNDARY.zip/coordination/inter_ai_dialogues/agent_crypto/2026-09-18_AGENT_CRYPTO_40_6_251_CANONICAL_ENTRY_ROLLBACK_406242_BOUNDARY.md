# AGENT-CRYPTO 40.6.251 — CANONICAL ENTRY WIRING ROLLBACK TO 40.6.242 BOUNDARY

Date: 2026-09-18
Release: **40.6.251**
Parent: **40.6.250**
Firefox terrain baseline: **40.6.242**
Market Core: **38.15.11**
Mode: **PAPER ONLY**
G3: **PENDING**
G9: **LOCKED**

## Repair

40.6.251 restores `administrator/index.html` to the exact canonical-entry wiring of 40.6.242.

Removed from the active entry:
- `DECISION_INTELLIGENCE_CURRENT_TRUTH_MODULE`
- `injectDecisionIntelligenceCurrentTruth(...)`
- the `patchShell(...)` injection call.

The 40.6.243 module file is preserved in the repository but no longer loaded.

## Exact proof

- current index length: 14409 chars
- 40.6.242 index length: 14409 chars
- exact equality: TRUE
- canonical index Git blob SHA: `65ac8bc4bee31e88c8288a4260d07f04f391df30`

## Commits

- entry rollback: `b77f88240167e151ab55b27ab8713880dd1f73f2`
- release manifest: `ec3d29d6be5452144dae2c956ad142b8caceaa10`
- receipt: `d9023cda447751f3f9779bf08a3cdef384c98d9f`

## Protected

Unchanged:
Market Core 38.15.11, runtime-shell.html, app.js, News Sentinel, Strategy A business logic, Atlas CURRENT, Oracle, Lecture Technique, Aether, Window Manager, Web Classique and current market archives.

## Firefox acceptance

Wait for `Build 40.6.251 · Administrator`, hard reload once, then open one formerly empty/lazy subsection at a time.

PASS = no Firefox slowdown banner, responsive scrolling, normal fan settling, subsection hydration.
