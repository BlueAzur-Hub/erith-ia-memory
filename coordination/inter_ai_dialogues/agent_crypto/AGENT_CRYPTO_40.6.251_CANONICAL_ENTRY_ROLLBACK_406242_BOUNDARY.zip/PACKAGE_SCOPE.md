# PACKAGE SCOPE

Bounded recovery package for Agent-Crypto 40.6.251.

Contains the canonical entry, full build manifest, receipt and integrity manifest.
This is not a full repository snapshot; GitHub remains canonical.
Do not overwrite unrelated Administrator files with historical archives.
