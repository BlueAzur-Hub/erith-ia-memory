Seven Heaven / Agent Crypto — R10.1 — correction saut de page Coffre historique
8 octobre 2026

CONTENU
  public/agent_crypto_erith_ia/administrator/js/historical-vault-automatic.js
  public/agent_crypto_erith_ia/tools/historical-vault-automatic.test.mjs
  coordination/inter_ai_dialogues/agent_crypto/HISTORICAL_VAULT_SCROLL_R10_1.md

CORRECTION
  Avant un changement de crypto/période R9 (automatique ou bouton manuel),
  conserver la hauteur du tableau courant pendant la vérification SHA-256.
  Aucun changement des chandelles, des graphiques, du Trader ni du workflow.

VERIFICATION
  Dans la racine du dépôt :
  node --check public/agent_crypto_erith_ia/administrator/js/historical-vault-automatic.js
  node --test public/agent_crypto_erith_ia/tools/historical-vault-automatic.test.mjs

  Test Firefox réel en attente : Coffre → R9 BTC → 24h → 7j → 30j.
