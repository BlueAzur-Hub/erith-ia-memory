# Upload — Agent-Crypto Build 28.2.86

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

## Après publication

1. Ouvrir l’interface avec le même profil Firefox.
2. Faire un rechargement forcé.
3. Descendre au Cockpit d’apprentissage.
4. Ne cliquer sur aucune leçon et aucun bouton de récupération pendant le chargement.
5. Attendre le statut final.

## Résultat attendu

```text
RÉCUPÉRATION TERMINÉE
Module 01 : Compris
Module actif : 02 · Spot et carnet d’ordres
Étapes récupérées : 3/3
Notes récupérées : 550/550 caractères
Stockage : IndexedDB vérifiée
Sources 28.2.81/79 : intactes
```

Le nombre `3/3` signifie que les trois anciennes étapes effectivement cochées ont été restaurées. Il ne signifie pas que la séance est terminée sur cinq étapes.

## En cas d’échec

Ne supprimer aucune donnée Firefox et ne recommencer aucune leçon. Envoyer seulement une capture du bloc qui affiche `ÉCHEC INDEXEDDB` et son texte.

## Limite de périmètre

Le Build migre le carnet pédagogique et le parcours expert. Il ne modifie pas le stockage du portefeuille fictif ni les calculs de simulation.
