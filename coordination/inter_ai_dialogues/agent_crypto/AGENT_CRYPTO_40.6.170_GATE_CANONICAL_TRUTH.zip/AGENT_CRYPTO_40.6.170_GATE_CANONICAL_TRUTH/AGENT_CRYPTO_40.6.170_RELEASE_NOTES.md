# 40.6.170 — Gate Canonical Truth

- Canonical gate numbers and exact certification states are preserved.
- The simplified unresolved list is corrected from sequential numbering/uniform WAIT to canonical G-number/exact state.
- Evidence unavailable => count INCONNU, never zero.
- FOUNDATION_PASS remains foundation-scoped and is not full certification.
- Owner and proof date are shown when available; missing date remains DATE INCONNUE.
- 40.6.169 remains active. No certification mutation or order path.
