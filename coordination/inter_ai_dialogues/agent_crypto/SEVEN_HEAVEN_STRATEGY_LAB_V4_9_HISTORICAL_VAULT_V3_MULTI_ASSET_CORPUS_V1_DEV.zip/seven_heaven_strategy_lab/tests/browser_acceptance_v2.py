"""Genuine Chromium DOM acceptance: use only in the CI browser job.

Requires Playwright installed in CI, not in the user's Python 3.13 environment.
No CDN, login, keys or live trading services.
"""
from __future__ import annotations
import os
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

BASE="http://127.0.0.1:8777"
OUTPUT=Path(os.environ["RUNNER_TEMP"])/"seven-lab-evidence"
OUTPUT.mkdir(parents=True,exist_ok=True)


def main():
    with sync_playwright() as p:
        browser=p.chromium.launch(channel="chrome",headless=True,args=["--no-sandbox"])
        try:
            desktop=browser.new_page(viewport={"width":1536,"height":960},device_scale_factor=1)
            errors=[]
            desktop.on("pageerror",lambda err:errors.append(str(err)))
            desktop.goto(BASE,wait_until="domcontentloaded")
            expect(desktop.locator(".version-pill")).to_contain_text("BUILD 4.6.2", timeout=15000)
            expect(desktop.locator("#dataset-badge")).not_to_have_text("À authentifier", timeout=15000)
            assert desktop.locator("#comparison-empty").is_visible()
            assert desktop.locator("#okx-pair").is_visible()
            assert desktop.locator("#source-choice").is_visible()
            assert desktop.locator("#okx-pair option").count()==4
            assert desktop.locator("#run").is_enabled()
            assert desktop.locator(".identity-title").inner_text()=="Strategy Lab"
            assert "4.6.2" in desktop.locator(".masthead").inner_text()
            desktop.locator("#compare").click()
            desktop.locator("#comparison-result").wait_for(state="visible",timeout=35000)
            assert desktop.locator("#comparison-rows > tr").count()==6
            desktop.locator("#comparison-rows > tr").first.locator("button").click()
            desktop.locator("#result").wait_for(state="visible",timeout=30000)
            assert "USDT" in desktop.locator("#equity").inner_text()
            assert desktop.locator("#zero-cost").inner_text()!="—"
            assert desktop.locator("#readout-equity").inner_text().endswith("USDT")
            assert desktop.locator("#history > button").count()>=1
            desktop.screenshot(path=str(OUTPUT/"SEVEN_HEAVEN_STRATEGY_LAB_V462_DESKTOP_COCKPIT.png"),full_page=True)
            desktop.locator("#profile-name").fill("V4.6.2 EMA 10-30 Browser Acceptance")
            desktop.locator("#save-profile").click()
            desktop.locator("#saved-profiles option").filter(has_text="V4.6.2 EMA 10-30").wait_for(state="attached",timeout=15000)
            # Full-stack acceptance: real public OKX Spot endpoint, immutable
            # local 240x1H cache, six PAPER comparisons and USDC denomination.
            desktop.locator("#okx-pair").select_option("BTC-USDC")
            desktop.locator("#okx-import").click()
            expect(desktop.locator("#source-active-title")).to_have_text(
                "OKX Spot · BTC/USDC",timeout=75000)
            assert desktop.locator("#source-choice").input_value().startswith("OKX_BTC_USDC_1H_")
            assert desktop.locator('input[name="timeframe"][value="1m"]').is_disabled()
            assert desktop.locator('input[name="timeframe"][value="1h"]').is_checked()
            assert desktop.locator("#run").is_enabled()
            desktop.locator("#compare").click()
            expect(desktop.locator("#compare-context")).to_contain_text(
                "BTC/USDC · OKX Spot",timeout=25000)
            assert desktop.locator("#comparison-rows > tr").count()==6
            assert "USDC" in desktop.locator("#comparison-rows > tr").first.inner_text()
            desktop.locator("#comparison-rows > tr").first.locator("button").click()
            expect(desktop.locator("#equity")).to_contain_text("USDC",timeout=25000)
            assert desktop.locator("#inventory").inner_text().endswith("BTC")
            # V4.6.2 regression: an Aether Research result belongs to one source.
            # Changing the source must remove it before any new study is launched.
            desktop.locator("#filters-run").click()
            desktop.locator("#research-result").wait_for(state="visible",timeout=35000)
            desktop.locator("#source-choice").select_option("BINANCE_BTCUSDT_2026_01_1M")
            assert desktop.locator("#research-result").is_hidden()
            assert desktop.locator("#research-empty").is_visible()
            desktop.screenshot(path=str(OUTPUT/"SEVEN_HEAVEN_STRATEGY_LAB_V462_SOURCE_RESET.png"),full_page=True)
            assert not errors, f"Unexpected JavaScript page exceptions: {errors}"

            mobile=browser.new_page(viewport={"width":390,"height":844},device_scale_factor=1)
            mobile.goto(BASE,wait_until="domcontentloaded")
            expect(mobile.locator(".version-pill")).to_contain_text("BUILD 4.6.2", timeout=15000)
            expect(mobile.locator("#dataset-badge")).not_to_have_text("À authentifier", timeout=15000)
            mobile.locator("#laboratory").scroll_into_view_if_needed()
            mobile.screenshot(path=str(OUTPUT/"SEVEN_HEAVEN_STRATEGY_LAB_V462_MOBILE_COCKPIT.png"),full_page=True)
            width=mobile.evaluate("document.documentElement.scrollWidth")
            assert width<=390, f"Unexpected horizontal body overflow mobile: {width}px"
            print("PASS: Chromium V4.6.2, source-bound Research reset, historical comparison, profile save, desktop/mobile rendering and no script errors")
        finally:
            browser.close()


if __name__=="__main__":
    main()
