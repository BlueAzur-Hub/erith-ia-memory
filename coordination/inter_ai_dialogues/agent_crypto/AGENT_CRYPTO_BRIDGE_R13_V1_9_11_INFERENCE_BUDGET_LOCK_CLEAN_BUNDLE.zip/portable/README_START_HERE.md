# Aether Control — Atlas-10 Crypto Bridge 2.3.2R13 / V1.9.11

Performance release for the Ryzen producer.

- 1 Atlas model pass produces the four bounded Atlas comments for one CURRENT fingerprint.
- 1 separate Aerith model pass closes the CURRENT after NØX.
- Runtime context budgets: Atlas 8K, Aerith 16K.
- Ollama unloads immediately after the final Aerith conclusion (`keep_alive: 0`).
- Browser protocol, strict Fact Contract, auth, Market Core, IndexedDB and Book Mirror remain unchanged.

Use the top-level Windows GUI executable for normal operation. Sources are in `source/`; runtime payload is in `bridge/`.
