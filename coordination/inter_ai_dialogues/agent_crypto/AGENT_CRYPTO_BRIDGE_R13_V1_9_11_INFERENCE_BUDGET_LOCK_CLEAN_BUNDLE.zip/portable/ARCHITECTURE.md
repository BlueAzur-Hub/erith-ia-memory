# R13 inference architecture

Administrator 40.4.51 -> Bridge 1.9.11 -> Ollama gpt-oss:20b-32k

CURRENT:
1. Snapshot canonical qualified.
2. `/summary market` -> one Atlas suite inference -> comments for market/top5/math/contradictions cached by strict-contract fingerprint.
3. `/summary top5|math|contradictions` -> cache only; deterministic report builders remain distinct.
4. NØX remains deterministic/runtime-owned.
5. `/conclusion` -> one Aerith inference with the four validated reports.
6. `keep_alive=0` on conclusion -> model unload requested immediately.

Expected heavy model calls per CURRENT: 2 (was 5 in V1.9.10).
