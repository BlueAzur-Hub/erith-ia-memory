#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import signal
import threading
import secrets
import subprocess
import shutil
import base64
import hashlib
import hmac
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse
from typing import Any

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "bridge_config.json"
PID_PATH = ROOT / "bridge.pid"
LEGACY_AUTH_PATH = ROOT / "bridge_auth.json"

def _persistent_trust_root() -> Path:
    local = str(os.environ.get("LOCALAPPDATA") or "").strip()
    if local:
        return Path(local) / "ERITH.IA" / "AtlasCryptoBridge" / "trust"
    try:
        return Path.home() / ".erith-ia" / "AtlasCryptoBridge" / "trust"
    except Exception:
        return ROOT.parent / "trust"

TRUST_ROOT = _persistent_trust_root()
AUTH_PATH = TRUST_ROOT / "bridge_auth.json"
SECURITY_AUDIT_PATH = ROOT / "data" / "security" / "audit.jsonl"
BOOK_MIRROR_STATUS_PATH = ROOT / "data" / "book_mirror_publication_status.json"



CANONICAL_PROFILE_FILES = {
    "atlas": (
        ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_MULTI_AGENT_CORE.md",
        ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_PERSONA_OPERATING_LAYER.md",
    ),
    "aerith": (
        ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_MULTI_AGENT_CORE.md",
        ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_PERSONA_OPERATING_LAYER.md",
    ),
}

RUNTIME_PROFILE_FILES = {
    "atlas": ROOT / "profiles" / "atlas" / "ATLAS_10_CRYPTO_RUNTIME_PROMPT.md",
    "aerith": ROOT / "profiles" / "aerith" / "AERITH_10_CRYPTO_RUNTIME_PROMPT.md",
}

MODE_LABELS = {
    "market": "Synthèse du marché",
    "top5": "Analyse du Target Top 5",
    "math": "Explication du Math Core",
    "contradictions": "Contrôle des contradictions",
    "chat": "Réponse à la question libre",
    "conclusion": "Conclusion Aerith-10 Crypto",
}

FORBIDDEN_MODEL_PATTERNS = (
    r"\bportefeuille\b",
    r"\bratio de sharpe\b",
    r"\bvalue at risk\b",
    r"\bexpected shortfall\b",
    r"\bacheter\b",
    r"\bvendre\b",
    r"\bsignal d['’]?achat\b",
    r"\bstop point.{0,30}\bjours?\b",
    r"\bcourbe en bas\b",
)

SAFETY_CONTRACT = """
CONTRAT LOCAL OBLIGATOIRE
- Lecture seule.
- Aucun ordre financier, wallet, exchange, GitHub ou action d'interface.
- La liste du marché n'est jamais un portefeuille.
- Le Target Top 5 canonique est BTC, ETH, BNB, XRP et SOL.
- Agent-Crypto calcule les faits ; le modèle local ne les remplace pas.
- Une mesure absente reste absente.
- Une limite générale n'est pas une actualité.
- La position visuelle d'une courbe ne prouve aucune tendance.
- Le stop point n'est pas une durée : c'est la limite des données disponibles.
""".strip()


FRESHNESS_LABELS = {
    "fresh": "récente",
    "delayed": "retardée",
    "stale": "ancienne",
    "archive": "archivée",
    "expired": "expirée",
    "direct": "directe",
    "cache": "en cache",
    "recent-cache": "en cache récent",
    "local-cache": "en cache local",
}

MODEL_COMMENT_PROFILES = {
    "atlas": (
        "Tu es Atlas-10 Crypto. Ajoute un commentaire analytique très court, "
        "sobre, contradictoire et limité aux faits condensés transmis."
    ),
    "aerith": (
        "Tu es Aerith-10 Crypto. Produis une synthèse pédagogique transversale, concrète et suffisamment détaillée, "
        "strictement limitée au snapshot CURRENT et aux quatre rapports Atlas relus. "
        "Relie marché, Top 5, graphique, Math Core, News Sentinel, Watchlist, contradictions et NØX sans inventer de causalité. "
        "Explique ce que les mesures signifient ici, ce qu’elles ne permettent pas de conclure et les informations manquantes. "
        "Évite de répéter mécaniquement les chiffres déjà exposés et n’écris jamais une consigne générale à l’infinitif comme « analyser », « évaluer » ou « utiliser »."
    ),
}

HISTORY_BINANCE_BASES = (
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api-gcp.binance.com",
)

HISTORY_PERIODS = {
    1: {"interval": "5m", "limit": 300, "api_days": 1},
    7: {"interval": "30m", "limit": 350, "api_days": 7},
    30: {"interval": "2h", "limit": 370, "api_days": 30},
    60: {"interval": "4h", "limit": 370, "api_days": 60},
    90: {"interval": "4h", "limit": 550, "api_days": 90},
    365: {"interval": "12h", "limit": 740, "api_days": 365},
    36500: {"interval": "1d", "limit": 1000, "api_days": "max"},
}

HISTORY_CACHE: dict[str, dict[str, Any]] = {}
HISTORY_CACHE_LOCK = threading.Lock()

# V1.9.11 — Atlas 4/4 single inference cache.
# The browser still requests the four canonical /summary routes sequentially,
# but one gpt-oss pass produces the four bounded comments for a fingerprint.
# Subsequent summary routes reuse that in-memory result; deterministic report
# construction remains unchanged.
ATLAS_SUITE_COMMENT_CACHE_LOCK = threading.Lock()
ATLAS_SUITE_COMMENT_CACHE: dict[str, dict[str, Any]] = {}
ATLAS_SUITE_COMMENT_CACHE_MAX = 8
HISTORY_INFLIGHT: dict[str, dict[str, Any]] = {}
HISTORY_INFLIGHT_LOCK = threading.Lock()


SCANNER_DATA_DIR = ROOT / "data" / "scanner_live"
SCANNER_LATEST_PATH = SCANNER_DATA_DIR / "latest.json"
SCANNER_WRITE_LOCK = threading.Lock()
SCANNER_BINANCE_TICKER_CACHE: dict[str, Any] = {"saved_at": 0.0, "rows": {}}
SCANNER_BINANCE_TICKER_LOCK = threading.Lock()
SCANNER_SCHEMA = "atlas_scanner_live_snapshot_v1"
SCANNER_BASKETS = ("top5", "gainers", "losers", "volume")

MODEL_COMMENT_RULES = """
CONTRAT DU RAISONNEMENT LOCAL ATLAS/AERITH
- Travaille uniquement à partir du dossier factuel transmis par Agent-Crypto.
- Ne crée aucun prix, volume, rendement, source, actualité, position ou mesure absent.
- Distingue fait, hypothèse, interprétation, contradiction, risque, limite et information manquante.
- Aucune instruction d'achat, vente, levier, retrait ou exécution.
- Aucune causalité supposée à partir d'une simple corrélation.
- La liste du marché et la Watchlist ne sont jamais un portefeuille.
- Source Truth, Evidence, Math Quality Gates et Contradictions priment sur une formulation du modèle.
- Si le dossier ne permet pas une conclusion : INFORMATION MANQUANTE.
- Réponds uniquement avec ce JSON : {"lecture":"...","prudence":"...","limites":"..."}.
- Chaque champ peut contenir jusqu'à trois phrases courtes, ancrées dans le snapshot présent.
""".strip()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


AUTH_SESSION_TTL_SECONDS = 12 * 60 * 60
AUTH_MAX_FAILURES = 6
AUTH_FAILURE_WINDOW_SECONDS = 15 * 60
AUTH_SESSIONS: dict[str, dict[str, Any]] = {}
AUTH_SESSIONS_LOCK = threading.Lock()
AUTH_FAILURES: dict[str, list[float]] = {}
AUTH_FAILURES_LOCK = threading.Lock()
AUTH_PRIVILEGED_GET = {"/profiles", "/history", "/scanner-latest", "/scanner-status", "/scanner-history", "/capabilities", "/security/status", "/book-mirror/status"}
AUTH_PRIVILEGED_POST = {"/chat", "/summary", "/conclusion", "/scanner-snapshot", "/book-mirror/publish"}


def security_audit(event: str, *, ok: bool, detail: str = "", remote: str = "") -> None:
    try:
        SECURITY_AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
        row = {"at": utc_now(), "event": str(event), "ok": bool(ok), "detail": str(detail)[:240], "remote": str(remote)[:80]}
        with SECURITY_AUDIT_PATH.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _auth_state_valid(state: dict[str, Any] | None) -> bool:
    return bool(isinstance(state, dict) and state.get("schema") == "atlas_bridge_auth_v1" and str(state.get("salt") or "").strip() and str(state.get("verifier") or "").strip())

def auth_migrate_legacy_if_needed() -> bool:
    """Migrate one valid version-local verifier into stable per-user trust storage."""
    try:
        if AUTH_PATH.exists():
            return False
        TRUST_ROOT.mkdir(parents=True, exist_ok=True)
        candidates: list[Path] = []
        if LEGACY_AUTH_PATH.exists():
            candidates.append(LEGACY_AUTH_PATH)
        try:
            base = ROOT.parent.parent
            for candidate in base.glob("2.3.2R*/bridge/bridge_auth.json"):
                if candidate != AUTH_PATH and candidate not in candidates:
                    candidates.append(candidate)
        except Exception:
            pass
        candidates.sort(key=lambda path: path.stat().st_mtime if path.exists() else 0.0, reverse=True)
        for candidate in candidates:
            try:
                state = load_json(candidate)
            except Exception:
                continue
            if not _auth_state_valid(state):
                continue
            tmp = AUTH_PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            os.replace(tmp, AUTH_PATH)
            return True
        return False
    except Exception:
        return False

def auth_state_read() -> dict[str, Any] | None:
    try:
        auth_migrate_legacy_if_needed()
        state = load_json(AUTH_PATH)
        return state if _auth_state_valid(state) else None
    except Exception:
        return None


def auth_secret_hash(secret: str, salt_hex: str) -> str:
    salt = bytes.fromhex(salt_hex)
    return hashlib.scrypt(str(secret).encode("utf-8"), salt=salt, n=16384, r=8, p=1, dklen=32).hex()


def auth_register(secret: str) -> dict[str, Any]:
    if auth_state_read() is not None:
        raise ValueError("Bridge Administrator déjà configuré.")
    if len(secret) < 6 or len(secret) > 256:
        raise ValueError("Mot de passe Administrator invalide.")
    salt = secrets.token_hex(16)
    state = {
        "schema": "atlas_bridge_auth_v1",
        "role": "owner",
        "created_at": utc_now(),
        "kdf": "scrypt-n16384-r8-p1-dk32",
        "salt": salt,
        "verifier": auth_secret_hash(secret, salt),
    }
    TRUST_ROOT.mkdir(parents=True, exist_ok=True)
    tmp = AUTH_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, AUTH_PATH)
    return state


def auth_verify(secret: str) -> bool:
    state = auth_state_read()
    if not state:
        return False
    candidate = auth_secret_hash(secret, str(state.get("salt") or ""))
    return hmac.compare_digest(candidate, str(state.get("verifier") or ""))


def auth_failure_allowed(remote: str) -> bool:
    now = time.time()
    with AUTH_FAILURES_LOCK:
        rows = [t for t in AUTH_FAILURES.get(remote, []) if now - t <= AUTH_FAILURE_WINDOW_SECONDS]
        AUTH_FAILURES[remote] = rows
        return len(rows) < AUTH_MAX_FAILURES


def auth_failure_record(remote: str) -> None:
    now = time.time()
    with AUTH_FAILURES_LOCK:
        rows = [t for t in AUTH_FAILURES.get(remote, []) if now - t <= AUTH_FAILURE_WINDOW_SECONDS]
        rows.append(now)
        AUTH_FAILURES[remote] = rows[-AUTH_MAX_FAILURES:]



CAPABILITY_POLICY = {
    "owner": frozenset({"history.read", "scanner.read", "scanner.write", "atlas.run", "aerith.run", "chat.run", "security.read", "book_mirror.publish", "book_mirror.read"}),
    "operator": frozenset({"history.read", "scanner.read", "atlas.run", "aerith.run", "chat.run"}),
    "reader": frozenset({"history.read", "scanner.read"}),
}
ROUTE_CAPABILITY = {
    "/profiles": "security.read",
    "/history": "history.read",
    "/scanner-latest": "scanner.read",
    "/scanner-status": "scanner.read",
    "/scanner-history": "scanner.read",
    "/scanner-snapshot": "scanner.write",
    "/summary": "atlas.run",
    "/conclusion": "aerith.run",
    "/chat": "chat.run",
    "/capabilities": "security.read",
    "/security/status": "security.read",
    "/book-mirror/status": "book_mirror.read",
    "/book-mirror/publish": "book_mirror.publish",
}


def capabilities_for_role(role: str) -> list[str]:
    return sorted(CAPABILITY_POLICY.get(str(role), frozenset()))

def auth_session_create(role: str = "owner") -> dict[str, Any]:
    token = secrets.token_urlsafe(36)
    expires = time.time() + AUTH_SESSION_TTL_SECONDS
    row = {"role": role, "created_at": time.time(), "expires_at": expires}
    with AUTH_SESSIONS_LOCK:
        AUTH_SESSIONS[token] = row
    return {"token": token, "role": role, "expires_at": datetime.fromtimestamp(expires, timezone.utc).isoformat(), "capabilities": capabilities_for_role(role)}


def auth_session_get(token: str) -> dict[str, Any] | None:
    if not token:
        return None
    now = time.time()
    with AUTH_SESSIONS_LOCK:
        row = AUTH_SESSIONS.get(token)
        if not row:
            return None
        if float(row.get("expires_at") or 0) <= now:
            AUTH_SESSIONS.pop(token, None)
            return None
        return dict(row)


def auth_session_revoke(token: str) -> None:
    if not token:
        return
    with AUTH_SESSIONS_LOCK:
        AUTH_SESSIONS.pop(token, None)


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def load_config() -> dict[str, Any]:
    config = load_json(CONFIG_PATH)
    if config.get("host") not in {"127.0.0.1", "localhost"}:
        raise RuntimeError("Le Bridge doit rester lié à 127.0.0.1 ou localhost.")
    return config


def request_json(url: str, payload: dict[str, Any] | None, timeout: int) -> dict[str, Any]:
    data = None
    headers = {"Accept": "application/json"}
    method = "GET"
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
        method = "POST"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read()
    return json.loads(raw.decode("utf-8")) if raw else {}























def history_error_text(exc: Exception) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return re.sub(r"\s+", " ", text)[:220]


def history_request_json(url: str, timeout: float) -> Any:
    headers = {
        "Accept": "application/json",
        "User-Agent": "Atlas-10-Crypto-Bridge/1.9.11 (+local-read-only-history)",
    }
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=max(1.0, float(timeout))) as response:
            raw = response.read()
        return json.loads(raw.decode("utf-8")) if raw else None
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")[:180]
        except Exception:
            body = ""
        suffix = f" · {body}" if body else ""
        raise RuntimeError(f"HTTP {exc.code}{suffix}") from exc


def history_cache_get(key: str, max_age_seconds: int) -> dict[str, Any] | None:
    with HISTORY_CACHE_LOCK:
        item = HISTORY_CACHE.get(key)
        if not item:
            return None
        if time.time() - float(item.get("saved_at", 0)) > max_age_seconds:
            HISTORY_CACHE.pop(key, None)
            return None
        payload = item.get("payload")
        return dict(payload) if isinstance(payload, dict) else None


def history_cache_put(key: str, payload: dict[str, Any]) -> None:
    with HISTORY_CACHE_LOCK:
        HISTORY_CACHE[key] = {"saved_at": time.time(), "payload": dict(payload)}
        if len(HISTORY_CACHE) > 160:
            oldest = sorted(HISTORY_CACHE, key=lambda item: HISTORY_CACHE[item].get("saved_at", 0))[:40]
            for stale in oldest:
                HISTORY_CACHE.pop(stale, None)


def history_fetch_binance_rows(symbol: str, interval: str, limit: int, total_timeout: float) -> list[Any]:
    deadline = time.monotonic() + max(2.0, total_timeout)
    errors: list[str] = []
    for base in HISTORY_BINANCE_BASES:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        url = (
            f"{base}/api/v3/klines?symbol={quote(symbol, safe='')}"
            f"&interval={quote(interval, safe='')}&limit={int(limit)}"
        )
        try:
            payload = history_request_json(url, min(5.0, remaining))
            if not isinstance(payload, list) or not payload:
                raise RuntimeError("chandelles absentes")
            return payload
        except Exception as exc:
            errors.append(f"{base}: {history_error_text(exc)}")
    raise RuntimeError(" | ".join(errors) or f"Binance indisponible pour {symbol}")


def history_normalize_binance(rows: list[Any]) -> tuple[list[list[float]], list[list[float]]]:
    series: list[list[float]] = []
    volumes: list[list[float]] = []
    for row in rows:
        if not isinstance(row, list) or len(row) < 8:
            continue
        try:
            timestamp = float(row[0])
            close = float(row[4])
            quote_volume = float(row[7])
        except (TypeError, ValueError):
            continue
        if timestamp > 0 and close > 0:
            series.append([timestamp, close])
            if quote_volume >= 0:
                volumes.append([timestamp, quote_volume])
    return series, volumes


def history_normalize_derived(
    crypto_rows: list[Any],
    eur_rows: list[Any],
) -> tuple[list[list[float]], list[list[float]]]:
    eur_by_time: dict[float, float] = {}
    for row in eur_rows:
        if not isinstance(row, list) or len(row) < 5:
            continue
        try:
            timestamp = float(row[0])
            close = float(row[4])
        except (TypeError, ValueError):
            continue
        if timestamp > 0 and close > 0:
            eur_by_time[timestamp] = close

    series: list[list[float]] = []
    volumes: list[list[float]] = []
    for row in crypto_rows:
        if not isinstance(row, list) or len(row) < 8:
            continue
        try:
            timestamp = float(row[0])
            crypto_close = float(row[4])
            quote_volume_usdt = float(row[7])
        except (TypeError, ValueError):
            continue
        eur_usdt = eur_by_time.get(timestamp)
        if timestamp > 0 and crypto_close > 0 and eur_usdt and eur_usdt > 0:
            series.append([timestamp, crypto_close / eur_usdt])
            if quote_volume_usdt >= 0:
                volumes.append([timestamp, quote_volume_usdt / eur_usdt])
    return series, volumes


def history_payload(
    *,
    coin_id: str,
    symbol: str,
    days: int,
    provider: str,
    source_mode: str,
    source: str,
    interval: str | None,
    api_days: int | str,
    series: list[list[float]],
    volume_series: list[list[float]],
    attempts: list[str],
) -> dict[str, Any]:
    generated_at = utc_now()
    if series:
        try:
            generated_at = datetime.fromtimestamp(series[-1][0] / 1000, timezone.utc).isoformat()
        except Exception:
            pass
    return {
        "ok": True,
        "read_only": True,
        "bridge_version": "1.9.11",
        "coin_id": coin_id,
        "symbol": symbol,
        "days": days,
        "provider": provider,
        "source_mode": source_mode,
        "source": source,
        "interval": interval,
        "api_days": api_days,
        "generated_at": generated_at,
        "point_count": len(series),
        "series": series,
        "volume_series": volume_series,
        "attempts": attempts,
    }


def fetch_history(config: dict[str, Any], coin_id: str, symbol: str, days: int, allow_binance: bool = True) -> dict[str, Any]:
    history_config = config.get("history_proxy", {})
    if history_config.get("enabled", True) is not True:
        raise RuntimeError("Proxy historique désactivé.")

    period = HISTORY_PERIODS[days]
    cache_seconds = int(history_config.get("cache_seconds", 60))
    cache_key = f"{coin_id}:{symbol}:{days}:{int(allow_binance)}"
    cached = history_cache_get(cache_key, cache_seconds)
    if cached:
        cached["cache"] = "bridge-memory-recent"
        return cached

    attempts: list[str] = []
    binance_timeout = float(history_config.get("binance_timeout_seconds", 12))
    coingecko_timeout = float(history_config.get("coingecko_timeout_seconds", 10))
    direct_symbol = f"{symbol}EUR"
    usdt_symbol = f"{symbol}USDT"

    if allow_binance:
        try:
            rows = history_fetch_binance_rows(
                direct_symbol,
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            series, volumes = history_normalize_binance(rows)
            if len(series) < 3:
                raise RuntimeError("série Binance EUR trop courte")
            payload = history_payload(
                coin_id=coin_id,
                symbol=symbol,
                days=days,
                provider="binance",
                source_mode="binance-bridge-direct-klines",
                source=f"Binance Spot {symbol}/EUR · Bridge local",
                interval=str(period["interval"]),
                api_days=period["api_days"],
                series=series,
                volume_series=volumes,
                attempts=attempts,
            )
            history_cache_put(cache_key, payload)
            return payload
        except Exception as exc:
            attempts.append(f"Binance {direct_symbol}: {history_error_text(exc)}")

        try:
            # Deux appels ont chacun un budget borné ; le cache du Bridge évite les répétitions.
            crypto_rows = history_fetch_binance_rows(
                usdt_symbol,
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            eur_rows = history_fetch_binance_rows(
                "EURUSDT",
                period["interval"],
                int(period["limit"]),
                binance_timeout,
            )
            series, volumes = history_normalize_derived(crypto_rows, eur_rows)
            if len(series) < 3:
                raise RuntimeError("série Binance USDT/EUR trop courte")
            payload = history_payload(
                coin_id=coin_id,
                symbol=symbol,
                days=days,
                provider="binance",
                source_mode="binance-bridge-derived-klines",
                source=f"Binance Spot {symbol}/USDT ÷ EUR/USDT · Bridge local",
                interval=str(period["interval"]),
                api_days=period["api_days"],
                series=series,
                volume_series=volumes,
                attempts=attempts,
            )
            history_cache_put(cache_key, payload)
            return payload
        except Exception as exc:
            attempts.append(f"Binance {usdt_symbol}/EURUSDT: {history_error_text(exc)}")

    else:
        attempts.append("Binance ignoré : symbole CoinGecko ambigu dans le Market")

    try:
        api_days = period["api_days"]
        url = (
            "https://api.coingecko.com/api/v3/coins/"
            f"{quote(coin_id, safe='')}/market_chart?vs_currency=eur"
            f"&days={quote(str(api_days), safe='')}&precision=full"
        )
        data = history_request_json(url, coingecko_timeout)
        raw_prices = data.get("prices", []) if isinstance(data, dict) else []
        raw_volumes = data.get("total_volumes", []) if isinstance(data, dict) else []
        series = [
            [float(row[0]), float(row[1])]
            for row in raw_prices
            if isinstance(row, list) and len(row) >= 2
            and float(row[0]) > 0 and float(row[1]) > 0
        ]
        volumes = [
            [float(row[0]), float(row[1])]
            for row in raw_volumes
            if isinstance(row, list) and len(row) >= 2
            and float(row[0]) > 0 and float(row[1]) >= 0
        ]
        if len(series) < 3:
            raise RuntimeError("série CoinGecko trop courte")
        payload = history_payload(
            coin_id=coin_id,
            symbol=symbol,
            days=days,
            provider="coingecko",
            source_mode="coingecko-bridge-direct",
            source="CoinGecko market_chart EUR · Bridge local",
            interval=None,
            api_days=api_days,
            series=series,
            volume_series=volumes,
            attempts=attempts,
        )
        history_cache_put(cache_key, payload)
        return payload
    except Exception as exc:
        attempts.append(f"CoinGecko {coin_id}: {history_error_text(exc)}")

    error = RuntimeError("Aucun historique direct disponible via le Bridge.")
    setattr(error, "attempts", attempts)
    raise error


def fetch_history_singleflight(
    config: dict[str, Any],
    coin_id: str,
    symbol: str,
    days: int,
    allow_binance: bool = True,
) -> dict[str, Any]:
    """Une seule récupération externe active par actif/période.

    Les requêtes Firefox concurrentes attendent le même résultat au lieu de
    relancer Binance/CoinGecko. Le résultat reste ensuite couvert par le cache
    mémoire normal du Bridge.
    """
    key = f"{coin_id}:{symbol}:{days}:{int(allow_binance)}"
    with HISTORY_INFLIGHT_LOCK:
        entry = HISTORY_INFLIGHT.get(key)
        owner = entry is None
        if owner:
            entry = {
                "event": threading.Event(),
                "payload": None,
                "error": None,
                "started_at": time.monotonic(),
            }
            HISTORY_INFLIGHT[key] = entry

    assert entry is not None
    if owner:
        try:
            payload = fetch_history(config, coin_id, symbol, days, allow_binance)
            entry["payload"] = payload
            return dict(payload)
        except Exception as exc:
            entry["error"] = exc
            raise
        finally:
            entry["event"].set()
            with HISTORY_INFLIGHT_LOCK:
                HISTORY_INFLIGHT.pop(key, None)

    wait_seconds = max(
        8.0,
        float(config.get("history_proxy", {}).get("singleflight_wait_seconds", 35)),
    )
    if not entry["event"].wait(wait_seconds):
        raise RuntimeError("Historique déjà en cours : délai d’attente dépassé.")
    payload = entry.get("payload")
    if isinstance(payload, dict):
        replay = dict(payload)
        replay["cache"] = "bridge-single-flight"
        return replay
    error = entry.get("error")
    if isinstance(error, Exception):
        raise RuntimeError(str(error)) from error
    raise RuntimeError("Historique simultané terminé sans résultat.")


def scanner_finite(value: Any, *, positive: bool = False) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not (number == number and abs(number) != float("inf")):
        return None
    if positive and number <= 0:
        return None
    return number


def scanner_safe_text(value: Any, limit: int = 160) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    return re.sub(r"\s+", " ", text)[:limit]


def scanner_validate_asset(asset: Any, basket: str, index: int) -> dict[str, Any]:
    if not isinstance(asset, dict):
        raise ValueError(f"Actif invalide dans {basket} à la position {index + 1}.")
    coin_id = scanner_safe_text(asset.get("coin_id"), 80)
    symbol = scanner_safe_text(asset.get("symbol"), 20)
    if not coin_id or not re.fullmatch(r"[a-z0-9-]{1,80}", coin_id):
        raise ValueError(f"coin_id invalide dans {basket}.")
    if not symbol or not re.fullmatch(r"[A-Z0-9]{1,20}", symbol):
        raise ValueError(f"symbol invalide dans {basket}.")
    return {
        "coin_id": coin_id,
        "symbol": symbol,
        "name": scanner_safe_text(asset.get("name"), 120),
        "market_rank": scanner_finite(asset.get("market_rank")),
        "scanner_rank": scanner_finite(asset.get("scanner_rank")),
        "classification_source": scanner_safe_text(asset.get("classification_source"), 100),
        "classification_metric": scanner_safe_text(asset.get("classification_metric"), 60),
        "classification_value": scanner_finite(asset.get("classification_value")),
        "market_price_eur": scanner_finite(asset.get("market_price_eur"), positive=True),
        "market_change_24h_pct": scanner_finite(asset.get("market_change_24h_pct")),
        "market_volume_24h_eur": scanner_finite(asset.get("market_volume_24h_eur")),
        "observed_price_eur": scanner_finite(asset.get("observed_price_eur"), positive=True),
        "observed_change_24h_pct": scanner_finite(asset.get("observed_change_24h_pct")),
        "observed_source": scanner_safe_text(asset.get("observed_source"), 160),
        "observed_status": scanner_safe_text(asset.get("observed_status"), 40),
        "observed_at": scanner_safe_text(asset.get("observed_at"), 60),
        "binance_symbol_candidate": scanner_safe_text(asset.get("binance_symbol_candidate"), 20),
        "binance_candidate_allowed": asset.get("binance_candidate_allowed") is True,
    }


def scanner_validate_snapshot(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Snapshot scanner invalide.")
    if payload.get("schema") != SCANNER_SCHEMA:
        raise ValueError(f"Schéma scanner refusé : {payload.get('schema')!r}.")
    snapshot_id = scanner_safe_text(payload.get("snapshot_id"), 140)
    collector_id = scanner_safe_text(payload.get("collector_id"), 100)
    collected_at = scanner_safe_text(payload.get("collected_at"), 60)
    if not snapshot_id or not re.fullmatch(r"[A-Za-z0-9_.-]{1,140}", snapshot_id):
        raise ValueError("snapshot_id scanner invalide.")
    if not collector_id:
        raise ValueError("collector_id scanner absent.")
    baskets_raw = payload.get("baskets")
    if not isinstance(baskets_raw, dict):
        raise ValueError("Paniers scanner absents.")

    baskets: dict[str, Any] = {}
    for key in SCANNER_BASKETS:
        raw = baskets_raw.get(key)
        if not isinstance(raw, dict):
            raise ValueError(f"Panier {key} absent.")
        assets_raw = raw.get("assets")
        if not isinstance(assets_raw, list) or not 1 <= len(assets_raw) <= 5:
            raise ValueError(f"Panier {key} : 1 à 5 actifs requis.")
        assets = [scanner_validate_asset(asset, key, index) for index, asset in enumerate(assets_raw)]
        coin_ids = [asset["coin_id"] for asset in assets]
        if len(set(coin_ids)) != len(coin_ids):
            raise ValueError(f"Panier {key} : actif dupliqué.")
        baskets[key] = {
            "id": key,
            "label": scanner_safe_text(raw.get("label"), 80) or key,
            "ranking_source": scanner_safe_text(raw.get("ranking_source"), 120),
            "ranking_metric": scanner_safe_text(raw.get("ranking_metric"), 80),
            "assets": assets,
        }

    market_raw = payload.get("market") if isinstance(payload.get("market"), dict) else {}
    exchange_raw = payload.get("exchange_feed") if isinstance(payload.get("exchange_feed"), dict) else {}
    return {
        "schema": SCANNER_SCHEMA,
        "snapshot_id": snapshot_id,
        "collector_id": collector_id,
        "collector_type": scanner_safe_text(payload.get("collector_type"), 60) or "agent_crypto_browser",
        "release": scanner_safe_text(payload.get("release"), 100),
        "collected_at": collected_at or utc_now(),
        "received_at": utc_now(),
        "reason": scanner_safe_text(payload.get("reason"), 80),
        "market": {
            "source": scanner_safe_text(market_raw.get("source"), 100),
            "mode": scanner_safe_text(market_raw.get("mode"), 40),
            "status": scanner_safe_text(market_raw.get("status"), 40),
            "timestamp": scanner_safe_text(market_raw.get("timestamp"), 60),
            "snapshot_id": scanner_safe_text(market_raw.get("snapshot_id"), 140),
            "assets_loaded": scanner_finite(market_raw.get("assets_loaded")),
            "target_assets": scanner_finite(market_raw.get("target_assets")),
            "quote_currency": scanner_safe_text(market_raw.get("quote_currency"), 12) or "EUR",
        },
        "exchange_feed": {
            "source": scanner_safe_text(exchange_raw.get("source"), 100),
            "status": scanner_safe_text(exchange_raw.get("status"), 40),
            "last_message_at": scanner_safe_text(exchange_raw.get("last_message_at"), 60),
            "direct_pairs": scanner_finite(exchange_raw.get("direct_pairs")),
            "derived_pairs": scanner_finite(exchange_raw.get("derived_pairs")),
        },
        "baskets": baskets,
        "safety": {
            "observation_only": True,
            "no_exchange_action": True,
            "no_wallet_action": True,
            "no_github_write": True,
            "ranking_never_decided_by_binance": True,
        },
    }


def scanner_binance_tickers(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    scanner_cfg = config.get("scanner_collector", {})
    ttl = max(10, int(scanner_cfg.get("binance_ticker_cache_seconds", 30)))
    with SCANNER_BINANCE_TICKER_LOCK:
        if time.time() - float(SCANNER_BINANCE_TICKER_CACHE.get("saved_at", 0)) <= ttl:
            rows = SCANNER_BINANCE_TICKER_CACHE.get("rows")
            if isinstance(rows, dict) and rows:
                return rows

    errors: list[str] = []
    timeout = max(2.0, float(scanner_cfg.get("binance_timeout_seconds", 6)))
    for base in HISTORY_BINANCE_BASES:
        try:
            payload = history_request_json(f"{base}/api/v3/ticker/24hr?type=MINI", timeout)
            if not isinstance(payload, list):
                raise RuntimeError("tickers Binance absents")
            rows = {
                str(row.get("symbol") or "").upper(): row
                for row in payload
                if isinstance(row, dict) and row.get("symbol")
            }
            if not rows:
                raise RuntimeError("catalogue ticker Binance vide")
            with SCANNER_BINANCE_TICKER_LOCK:
                SCANNER_BINANCE_TICKER_CACHE["saved_at"] = time.time()
                SCANNER_BINANCE_TICKER_CACHE["rows"] = rows
            return rows
        except Exception as exc:
            errors.append(history_error_text(exc))
    raise RuntimeError(" | ".join(errors) or "Tickers Binance indisponibles")


def scanner_binance_row_price(row: dict[str, Any] | None) -> tuple[float | None, float | None, float | None]:
    if not isinstance(row, dict):
        return None, None, None
    price = scanner_finite(row.get("lastPrice"), positive=True)
    change = scanner_finite(row.get("priceChangePercent"))
    volume = scanner_finite(row.get("quoteVolume"))
    return price, change, volume


def scanner_enrich_asset_binance(asset: dict[str, Any], rows: dict[str, dict[str, Any]], config: dict[str, Any]) -> dict[str, Any]:
    result = dict(asset)
    symbol = str(asset.get("binance_symbol_candidate") or "").upper()
    if not asset.get("binance_candidate_allowed") or not re.fullmatch(r"[A-Z0-9]{2,15}", symbol):
        result["binance_enrichment"] = "not_allowed"
        return result

    reference = scanner_finite(asset.get("market_price_eur"), positive=True)
    if not reference:
        result["binance_enrichment"] = "missing_reference"
        return result

    eur_price, eur_change, eur_volume = scanner_binance_row_price(rows.get(f"{symbol}EUR"))
    usdt_price, usdt_change, usdt_volume = scanner_binance_row_price(rows.get(f"{symbol}USDT"))
    eurusdt_price, eurusdt_change, _ = scanner_binance_row_price(rows.get("EURUSDT"))

    candidate_price = None
    candidate_change = None
    candidate_volume = None
    source = None
    pair = None
    if eur_price:
        candidate_price = eur_price
        candidate_change = eur_change
        candidate_volume = eur_volume
        pair = f"{symbol}EUR"
        source = f"Binance {symbol}/EUR ticker 24 h"
    elif usdt_price and eurusdt_price:
        candidate_price = usdt_price / eurusdt_price
        if usdt_change is not None:
            denominator = 1 + (eurusdt_change or 0) / 100
            candidate_change = ((1 + usdt_change / 100) / denominator - 1) * 100 if denominator > 0 else usdt_change
        candidate_volume = usdt_volume / eurusdt_price if usdt_volume is not None else None
        pair = f"{symbol}USDT/EURUSDT"
        source = f"Binance {symbol}/USDT ÷ EUR/USDT ticker 24 h"

    if not candidate_price:
        result["binance_enrichment"] = "pair_unavailable"
        return result

    max_gap = max(0.01, min(0.50, float(config.get("scanner_collector", {}).get("max_price_alignment_gap_ratio", 0.12))))
    gap = abs(candidate_price - reference) / reference
    if gap > max_gap:
        result["binance_enrichment"] = "rejected_price_alignment"
        result["binance_alignment_gap_ratio"] = round(gap, 6)
        return result

    result.update({
        "observed_price_eur": candidate_price,
        "observed_change_24h_pct": candidate_change if candidate_change is not None else result.get("observed_change_24h_pct"),
        "observed_source": source,
        "observed_status": "live_binance_verified",
        "observed_at": utc_now(),
        "binance_enrichment": "accepted_price_alignment",
        "binance_pair": pair,
        "binance_alignment_gap_ratio": round(gap, 6),
        "binance_quote_volume_eur": candidate_volume,
    })
    return result


def scanner_enrich_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    scanner_cfg = config.get("scanner_collector", {})
    if not scanner_cfg.get("binance_enrichment", True):
        return snapshot
    try:
        rows = scanner_binance_tickers(config)
    except Exception as exc:
        snapshot["binance_enrichment"] = {"status": "unavailable", "error": history_error_text(exc)}
        return snapshot

    accepted = 0
    rejected = 0
    for basket in snapshot.get("baskets", {}).values():
        enriched_assets = []
        for asset in basket.get("assets", []):
            enriched = scanner_enrich_asset_binance(asset, rows, config)
            if enriched.get("binance_enrichment") == "accepted_price_alignment":
                accepted += 1
            elif enriched.get("binance_candidate_allowed"):
                rejected += 1
            enriched_assets.append(enriched)
        basket["assets"] = enriched_assets
    snapshot["binance_enrichment"] = {
        "status": "complete",
        "accepted_assets": accepted,
        "not_accepted_assets": rejected,
        "method": "unique_symbol_plus_price_alignment",
        "ranking_unchanged": True,
    }
    return snapshot


def scanner_data_config(config: dict[str, Any]) -> dict[str, Any]:
    cfg = config.get("scanner_collector", {})
    return {
        "enabled": cfg.get("enabled", True) is True,
        "retention_days": max(1, min(90, int(cfg.get("retention_days", 14)))),
        "max_history_rows": max(1, min(5000, int(cfg.get("max_history_rows", 720)))),
    }


def scanner_prune_files(config: dict[str, Any]) -> None:
    cfg = scanner_data_config(config)
    cutoff = time.time() - cfg["retention_days"] * 86400
    if not SCANNER_DATA_DIR.exists():
        return
    for file in SCANNER_DATA_DIR.glob("20??-??-??.jsonl"):
        try:
            if file.stat().st_mtime < cutoff:
                file.unlink(missing_ok=True)
        except OSError:
            pass


def scanner_read_latest() -> dict[str, Any] | None:
    try:
        payload = load_json(SCANNER_LATEST_PATH)
        return payload if isinstance(payload, dict) else None
    except Exception:
        return None


def scanner_persist_snapshot(snapshot: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    cfg = scanner_data_config(config)
    if not cfg["enabled"]:
        raise RuntimeError("Scanner Live Collector désactivé dans bridge_config.json.")
    SCANNER_DATA_DIR.mkdir(parents=True, exist_ok=True)
    with SCANNER_WRITE_LOCK:
        latest = scanner_read_latest()
        if latest and latest.get("snapshot_id") == snapshot.get("snapshot_id"):
            return {"duplicate": True, "path": str(SCANNER_LATEST_PATH.relative_to(ROOT))}
        day = str(snapshot.get("collected_at") or utc_now())[:10]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
            day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        daily = SCANNER_DATA_DIR / f"{day}.jsonl"
        line = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")) + "\n"
        with daily.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(line)
        temp = SCANNER_LATEST_PATH.with_suffix(".tmp")
        temp.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(SCANNER_LATEST_PATH)
        scanner_prune_files(config)
        return {"duplicate": False, "path": str(daily.relative_to(ROOT))}


def scanner_history(config: dict[str, Any], basket: str, limit: int) -> list[dict[str, Any]]:
    if basket not in SCANNER_BASKETS:
        raise ValueError("basket autorisé : top5, gainers, losers ou volume.")
    max_rows = scanner_data_config(config)["max_history_rows"]
    limit = max(1, min(max_rows, int(limit)))
    if not SCANNER_DATA_DIR.exists():
        return []
    rows: list[dict[str, Any]] = []
    files = sorted(SCANNER_DATA_DIR.glob("20??-??-??.jsonl"), reverse=True)
    for file in files:
        try:
            lines = file.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        for line in reversed(lines):
            try:
                payload = json.loads(line)
            except Exception:
                continue
            basket_payload = payload.get("baskets", {}).get(basket)
            if not isinstance(basket_payload, dict):
                continue
            rows.append({
                "snapshot_id": payload.get("snapshot_id"),
                "collected_at": payload.get("collected_at"),
                "market": payload.get("market"),
                "exchange_feed": payload.get("exchange_feed"),
                "binance_enrichment": payload.get("binance_enrichment"),
                "basket": basket_payload,
            })
            if len(rows) >= limit:
                return list(reversed(rows))
    return list(reversed(rows))


def scanner_status(config: dict[str, Any]) -> dict[str, Any]:
    latest = scanner_read_latest()
    files = sorted(SCANNER_DATA_DIR.glob("20??-??-??.jsonl")) if SCANNER_DATA_DIR.exists() else []
    return {
        "ok": True,
        "bridge_version": "1.9.11",
        "schema": SCANNER_SCHEMA,
        "enabled": scanner_data_config(config)["enabled"],
        "storage": "local_jsonl",
        "data_directory": str(SCANNER_DATA_DIR.relative_to(ROOT)),
        "daily_files": len(files),
        "latest_snapshot_id": latest.get("snapshot_id") if latest else None,
        "latest_collected_at": latest.get("collected_at") if latest else None,
        "latest_market_timestamp": latest.get("market", {}).get("timestamp") if latest else None,
        "basket_counts": {
            key: len(latest.get("baskets", {}).get(key, {}).get("assets", [])) if latest else 0
            for key in SCANNER_BASKETS
        },
        "read_only_external": True,
        "local_observation_storage": True,
    }


def provider_status(config: dict[str, Any], name: str) -> dict[str, Any]:
    provider = config["providers"][name]
    if not provider.get("enabled"):
        return {"enabled": False, "online": False, "models": [], "error": "désactivé"}

    base = provider["base_url"].rstrip("/")
    try:
        if name == "ollama":
            payload = request_json(f"{base}/api/tags", None, 2)
            models = [
                item.get("name", "")
                for item in payload.get("models", [])
                if item.get("name")
            ]
        else:
            payload = request_json(f"{base}/models", None, 2)
            models = [
                item.get("id", "")
                for item in payload.get("data", [])
                if item.get("id")
            ]
        return {"enabled": True, "online": True, "models": models, "error": ""}
    except Exception as exc:
        return {
            "enabled": True,
            "online": False,
            "models": [],
            "error": str(exc)[:180],
        }


def resolve_required_model(configured: str, models: list[str]) -> str:
    configured = str(configured or "").strip()
    if configured in models:
        return configured

    configured_base = configured.split(":", 1)[0]
    for model in models:
        if model.split(":", 1)[0] == configured_base:
            return model
    return ""


def choose_provider(
    config: dict[str, Any],
    statuses: dict[str, dict[str, Any]] | None = None,
) -> tuple[str, str]:
    """Resolve the active provider without re-probing when status is already known.

    V1.9.5 /health built a provider inventory and then called choose_provider(),
    which probed Ollama a second time in the same HTTP request. Under model load
    that could keep /api/tags busy almost continuously when the Control Center
    also refreshed frequently. V1.9.6 reuses the first inventory.
    """
    preferred = str(config.get("preferred_provider") or "ollama")
    order = [preferred]
    if config.get("allow_provider_fallback", False):
        order.extend(name for name in ("ollama", "lm_studio") if name != preferred)

    for name in order:
        if name not in config["providers"]:
            continue
        provider = config["providers"][name]
        if not provider.get("enabled"):
            continue
        status = (statuses or {}).get(name)
        if not isinstance(status, dict):
            status = provider_status(config, name)
        if not status.get("online"):
            continue
        configured = str(provider.get("model") or "").strip()
        models = list(status.get("models") or [])
        if configured:
            resolved = resolve_required_model(configured, models)
            if resolved:
                return name, resolved
            if provider.get("required"):
                raise RuntimeError(
                    f"Modèle requis absent : {configured}. "
                    f"Installe-le avec : ollama pull {configured}"
                )
        elif models:
            return name, models[0]

    raise RuntimeError(
        "Aucun moteur local prêt. Lance Ollama et vérifie gpt-oss:20b-32k."
    )


def profile_health() -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, canonical_files in CANONICAL_PROFILE_FILES.items():
        runtime_file = RUNTIME_PROFILE_FILES[name]
        missing = [
            str(path.relative_to(ROOT))
            for path in (*canonical_files, runtime_file)
            if not path.exists()
        ]
        result[name] = {
            "loaded": not missing,
            "runtime_mode": "atlas_aerith_fact_contract_v2_v3_truth_evidence_gpt_oss_32k",
            "canonical_files_present": all(path.exists() for path in canonical_files),
            "runtime_file_present": runtime_file.exists(),
            "missing": missing,
        }
    return result


def validate_contract(snapshot: dict[str, Any]) -> dict[str, Any]:
    contract = snapshot.get("strict_contract")
    if not isinstance(contract, dict):
        raise ValueError("Contrat factuel absent du snapshot.")

    schema = str(contract.get("schema") or "").strip()
    allowed = {
        "atlas_crypto_fact_contract_v2",
        "atlas_crypto_fact_contract_v3_truth_evidence",
    }
    if schema not in allowed:
        raise ValueError(
            f"Schéma factuel refusé : {schema!r}; attendus : V2 ou V3 Truth/Evidence."
        )

    top5 = contract.get("canonical_top5")
    if not isinstance(top5, dict):
        raise ValueError("Target Top 5 canonique absent.")

    symbols = top5.get("symbols")
    if symbols != ["BTC", "ETH", "BNB", "XRP", "SOL"]:
        raise ValueError("Target Top 5 non canonique.")

    rules = contract.get("rules")
    if not isinstance(rules, dict):
        raise ValueError("Règles du contrat absentes.")

    required_true = (
        "market_list_is_not_portfolio",
        "no_missing_value_to_zero",
        "no_visual_position_inference",
        "no_unlisted_math_measure",
        "no_news_from_generic_limit",
        "no_financial_instruction",
    )
    for key in required_true:
        if rules.get(key) is not True:
            raise ValueError(f"Règle factuelle non verrouillée : {key}.")

    if schema == "atlas_crypto_fact_contract_v3_truth_evidence":
        required_layers = (
            "source_truth_v2",
            "evidence_v2",
            "math_quality_gates_v2",
            "contradictions_v2",
        )
        for key in required_layers:
            if not isinstance(contract.get(key), dict):
                raise ValueError(f"Couche V3 absente ou invalide : {key}.")
        required_v3_rules = (
            "analytical_fingerprint_v2",
            "source_truth_v2",
            "evidence_independence_required",
            "metric_quality_gates",
            "transactional_conclusion",
        )
        for key in required_v3_rules:
            if rules.get(key) is not True:
                raise ValueError(f"Verrou V3 non actif : {key}.")
        analytical_state = snapshot.get("analytical_state")
        if not isinstance(analytical_state, dict):
            raise ValueError("État analytique V2 absent du snapshot V3.")
        fingerprint = analytical_state.get("fingerprint")
        if not isinstance(fingerprint, dict) or not str(fingerprint.get("value") or "").strip():
            raise ValueError("Empreinte analytique SHA-256 absente du snapshot V3.")

    return contract

def fmt_number(value: Any, digits: int = 2) -> str:
    number = float(value)
    text = f"{number:,.{digits}f}"
    return text.replace(",", "\u202f").replace(".", ",")


def fmt_price(value: Any) -> str:
    number = float(value)
    digits = 6 if abs(number) < 1 else 2
    return f"{fmt_number(number, digits)} €"


def fmt_pct(value: Any) -> str:
    number = float(value)
    sign = "+" if number > 0 else ""
    return f"{sign}{fmt_number(number, 2)} %"


def fmt_risk_pct(value: Any) -> str:
    number = float(value)
    return f"{fmt_number(abs(number), 2)} %"


def safe_value(value: Any, formatter=None) -> str:
    if value is None:
        return "indisponible"
    try:
        return formatter(value) if formatter else str(value)
    except Exception:
        return "indisponible"


STATUS_LABELS = {
    "ready": "prêt",
    "ok": "opérationnel",
    "loading": "chargement",
    "error": "erreur",
    "failed": "échec",
    "stale": "ancien",
    "live": "direct",
    "direct": "direct",
    "local-cache": "cache local",
    "recent-cache": "cache récent",
    "github-cache": "cache GitHub",
    "browser-cache": "cache navigateur",
    "cache": "cache",
    "fresh": "récent",
    "delayed": "retardé",
    "archive": "archive datée",
    "expired": "expiré",
    "linear": "linéaire",
    "log": "logarithmique",
    "price": "prix",
    "base100": "base 100",
    "normal": "normale",
}


def clean_sentence(value: Any) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r"\s+([,;:!?])", r"\1", text)
    text = re.sub(r"([.!?])\1+$", r"\1", text)
    text = re.sub(r"\.{2,}$", ".", text)
    return text


def label_status(value: Any, fallback: str = "inconnu") -> str:
    text = str(value or "").strip()
    if not text:
        return fallback
    return STATUS_LABELS.get(text.lower(), text)


def format_datetime_fr(value: Any) -> str:
    if value in (None, ""):
        return "indisponible"
    text = str(value).strip()
    try:
        normalized = text.replace("Z", "+00:00")
        date = datetime.fromisoformat(normalized)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        local = date.astimezone()
        return local.strftime("%d/%m/%Y à %H:%M:%S")
    except Exception:
        return clean_sentence(text)


def format_score_block(value: Any, fallback: str = "inconnu") -> str:
    if value is None:
        return fallback
    if isinstance(value, dict):
        level = (
            value.get("level")
            or value.get("label")
            or value.get("name")
            or value.get("status")
        )
        score = value.get("score")
        if level and score is not None:
            return f"{clean_sentence(level)} — score {safe_value(score)}/100"
        if level:
            return clean_sentence(level)
        if score is not None:
            return f"score {safe_value(score)}/100"
        compact = [
            f"{clean_sentence(key)} : {clean_sentence(item)}"
            for key, item in value.items()
            if item not in (None, "", [], {})
        ]
        return " · ".join(compact) if compact else fallback
    return clean_sentence(value) or fallback


def normalize_model_comment(value: Any) -> dict[str, str] | None:
    if not isinstance(value, dict):
        return None

    candidate = value
    for wrapper in ("comment", "commentaire", "response", "réponse", "analysis", "analyse"):
        nested = candidate.get(wrapper)
        if isinstance(nested, dict):
            candidate = nested
            break

    aliases = {
        "reading": ("reading", "lecture", "analyse", "interpretation", "interprétation"),
        "caution": ("caution", "prudence", "vigilance", "risque"),
        "limits": ("limits", "limites", "limit", "borne", "bornes"),
    }

    normalized: dict[str, str] = {}
    for target, keys in aliases.items():
        for key in keys:
            item = candidate.get(key)
            if isinstance(item, str) and item.strip():
                normalized[target] = clean_sentence(item)
                break

    return normalized if normalized else None


def parse_model_comment(raw: str) -> dict[str, str] | None:
    text = str(raw or "").strip()
    if not text:
        return None

    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)

    candidates = [text]
    first = text.find("{")
    last = text.rfind("}")
    if first >= 0 and last > first:
        candidates.append(text[first:last + 1])

    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            normalized = normalize_model_comment(parsed)
            if normalized:
                return normalized
        except Exception:
            pass

    labeled: dict[str, str] = {}
    label_map = {
        "reading": ("reading", "lecture", "analyse"),
        "caution": ("caution", "prudence", "vigilance"),
        "limits": ("limits", "limites", "bornes"),
    }
    for target, labels in label_map.items():
        for label in labels:
            match = re.search(
                rf"(?im)^\s*(?:[-*]\s*)?(?:\*\*)?{re.escape(label)}(?:\*\*)?\s*[:\-]\s*(.+)$",
                text,
            )
            if match:
                labeled[target] = clean_sentence(match.group(1))
                break

    return labeled if labeled else None


def freshness_label(value: Any, fallback: str = "inconnue") -> str:
    text = str(value or "").strip()
    if not text:
        return fallback
    return FRESHNESS_LABELS.get(text.lower(), text)


def model_comment_profile(profile: str) -> str:
    return MODEL_COMMENT_PROFILES.get(profile, MODEL_COMMENT_PROFILES["atlas"])


def sanitize_comment_question(value: Any) -> str:
    text = clean_sentence(value)
    if not text:
        return ""

    for pattern in FORBIDDEN_MODEL_PATTERNS:
        text = re.sub(
            pattern,
            "élément réservé au rapport factuel",
            text,
            flags=re.I | re.S,
        )

    text = re.sub(
        r"-?\d+(?:[.,]\d+)?",
        "valeur réservée au rapport factuel",
        text,
    )
    return clean_sentence(text)[:280]


def model_comment_facts(
    contract: dict[str, Any],
    mode: str,
    question: str,
) -> dict[str, Any]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    top5 = contract.get("canonical_top5", {})
    graph = contract.get("graph", {})
    math = contract.get("math", {})
    news = contract.get("news", {})
    contradictions = contract.get("contradictions") or []

    facts = {
        "mission": mode,
        "sources": {
            "binance": label_status(
                contract.get("sources", {}).get("binance", {}).get("feed_status")
            ),
            "coingecko": label_status(
                contract.get("sources", {}).get("coingecko", {}).get("status")
            ),
        },
        "market": {
            "breadth": clean_sentence(
                breadth.get("classification") or "indéterminée"
            ),
            "coverage": (
                "complète"
                if market.get("assets_loaded") == market.get("target_assets")
                else "partielle"
            ),
        },
        "target_group": {
            "coverage": "complète" if top5.get("complete") else "partielle",
        },
        "graph": {
            "history": clean_sentence(
                graph.get("truth_label") or "indisponible"
            ),
            "freshness": freshness_label(graph.get("freshness")),
            "series_available": bool(graph.get("series")),
        },
        "math": {
            "coverage": clean_sentence(math.get("coverage") or "indisponible"),
            "horizon_coherence": clean_sentence(
                math.get("horizon_coherence") or "indisponible"
            ),
            "amplitude": clean_sentence(
                math.get("amplitude_24h") or "indisponible"
            ),
            "global_risk": clean_sentence(
                math.get("risk_global") or "non évalué"
            ),
        },
        "news": {
            "status": label_status(news.get("status")),
            "qualified_event_available": bool(news.get("lead_event")),
            "lead_event": clean_sentence((news.get("lead_event") or {}).get("event_label") or "") or None,
            "lead_source": clean_sentence((news.get("lead_event") or {}).get("source_name") or "") or None,
            "lead_evidence": (news.get("lead_event") or {}).get("evidence"),
            "lead_impact": (news.get("lead_event") or {}).get("impact"),
            "lead_assets": (news.get("lead_event") or {}).get("assets") or [],
        },
        "nox_no_fomo": contract.get("nox_no_fomo_v1") or {},
        "limits_present": bool(contradictions),
    }

    if mode == "chat":
        intent = sanitize_comment_question(question)
        if intent:
            facts["question_intent"] = intent

    if mode == "conclusion":
        report_bundle = contract.get("atlas_reports_v1") or {}
        if isinstance(report_bundle, dict):
            facts["atlas_reports_re_read"] = True
            facts["atlas_reports"] = {
                key: {
                    "label": value.get("label"),
                    "answer": value.get("answer"),
                    "fingerprint": value.get("fingerprint"),
                    "model": value.get("model"),
                }
                for key, value in report_bundle.items()
                if key in CONCLUSION_REPORT_MODES and isinstance(value, dict)
            }

    source_truth = contract.get("source_truth_v2") or {}
    evidence = contract.get("evidence_v2") or {}
    quality = contract.get("math_quality_gates_v2") or {}
    contradictions_v2 = contract.get("contradictions_v2") or {}
    facts["truth_evidence"] = {
        "source_modes": source_truth.get("counts") or {},
        "public_source_failures": source_truth.get("public_source_failures"),
        "evidence_counts": evidence.get("counts") or {},
        "math_quality_counts": quality.get("counts") or {},
        "contradiction_counts": contradictions_v2.get("counts") or {},
    }

    return facts


CONCLUSION_REPORT_MODES = ("market", "top5", "math", "contradictions")
CONCLUSION_REPORT_MAX_CHARS_EACH = 10000
CONCLUSION_REPORT_MAX_CHARS_TOTAL = 36000

def normalize_conclusion_reports(value: Any, fingerprint: str) -> dict[str, dict[str, Any]]:
    if not fingerprint:
        raise ValueError("Fingerprint Atlas CURRENT manquant pour la conclusion.")
    if not isinstance(value, dict):
        raise ValueError("Les quatre rapports Atlas-10 CURRENT doivent être transmis à Aerith.")

    normalized: dict[str, dict[str, Any]] = {}
    total = 0
    for mode in CONCLUSION_REPORT_MODES:
        raw = value.get(mode)
        if not isinstance(raw, dict):
            raise ValueError(f"Rapport Atlas CURRENT manquant : {mode}.")
        answer = str(raw.get("answer") or "").replace("\r\n", "\n").strip()
        report_fp = str(raw.get("fingerprint") or "").strip()
        if report_fp != fingerprint:
            raise ValueError(f"Fingerprint du rapport {mode} différent du snapshot CURRENT.")
        if len(answer) < 120:
            raise ValueError(f"Rapport Atlas CURRENT vide ou trop court : {mode}.")
        answer = answer[:CONCLUSION_REPORT_MAX_CHARS_EACH]
        remaining = CONCLUSION_REPORT_MAX_CHARS_TOTAL - total
        if remaining <= 0:
            raise ValueError("Volume des rapports Atlas trop important pour le contexte de conclusion.")
        answer = answer[:remaining]
        total += len(answer)
        normalized[mode] = {
            "mode": mode,
            "label": clean_sentence(raw.get("label") or MODE_LABELS.get(mode) or mode),
            "answer": answer,
            "fingerprint": report_fp,
            "model": clean_sentence(raw.get("model") or ""),
            "time": clean_sentence(raw.get("time") or ""),
        }

    if set(normalized) != set(CONCLUSION_REPORT_MODES):
        raise ValueError("Les quatre rapports Atlas CURRENT ne sont pas complets.")
    return normalized

def aerith_atlas_reports_re_read_lines(contract: dict[str, Any]) -> list[str]:
    reports = contract.get("atlas_reports_v1") or {}
    if not isinstance(reports, dict) or any(mode not in reports for mode in CONCLUSION_REPORT_MODES):
        return ["- Relecture Atlas : INFORMATION MANQUANTE."]
    lines = ["- Les quatre rapports Atlas-10 CURRENT ont été transmis et relus avant cette synthèse."]
    for index, mode in enumerate(CONCLUSION_REPORT_MODES, start=1):
        report = reports.get(mode) or {}
        label = clean_sentence(report.get("label") or MODE_LABELS.get(mode) or mode)
        model = clean_sentence(report.get("model") or "modèle local")
        lines.append(f"- 0{index} · {label} · {model} · même fingerprint CURRENT.")
    return lines


def deterministic_sources(contract: dict[str, Any]) -> list[str]:
    binance = contract.get("sources", {}).get("binance", {})
    coingecko = contract.get("sources", {}).get("coingecko", {})
    return [
        f"- Binance : {label_status(binance.get('feed_status'))}"
        f" · {clean_sentence(binance.get('source') or 'source non précisée')}"
        f" · {safe_value(binance.get('direct_pairs'))} paires directes"
        f" · {safe_value(binance.get('derived_pairs'))} dérivées.",
        f"- CoinGecko : {label_status(coingecko.get('status'))}"
        f" · mode {label_status(coingecko.get('mode'))}"
        f" · horodatage {format_datetime_fr(coingecko.get('timestamp'))}.",
    ]


def deterministic_top5(contract: dict[str, Any]) -> list[str]:
    top5 = contract["canonical_top5"]
    lines = [
        f"Target canonique : {' / '.join(top5['symbols'])}.",
        f"Couverture : {'5/5' if top5.get('complete') else 'partielle'}.",
    ]
    for row in top5.get("assets", []):
        symbol = row.get("symbol") or "?"
        if not row.get("available"):
            lines.append(f"- {symbol} : prix indisponible.")
            continue
        lines.append(
            f"- {symbol} : {safe_value(row.get('price_eur'), fmt_price)}"
            f" · 24 h {safe_value(row.get('change_24h_pct'), fmt_pct)}"
            f" · {clean_sentence(row.get('source') or 'source inconnue')}"
            f" · état {label_status(row.get('quote_status'))}."
        )
    return lines


def deterministic_market(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    return [
        f"- Univers chargé : {safe_value(market.get('assets_loaded'))}/"
        f"{safe_value(market.get('target_assets'))} actifs, devise EUR.",
        f"- Largeur 24 h : {safe_value(breadth.get('positive'))} hausses"
        f" · {safe_value(breadth.get('negative'))} baisses"
        f" · {safe_value(breadth.get('stable'))} stables"
        f" · classification : {breadth.get('classification') or 'indéterminée'}.",
        f"- Base de calcul : {breadth.get('basis') or 'indisponible'}.",
    ]


def deterministic_graph(contract: dict[str, Any]) -> list[str]:
    graph = contract.get("graph", {})
    lines = [
        f"- Période : {clean_sentence(graph.get('period_label') or 'indisponible')}"
        f" · vue {label_status(graph.get('view'))}"
        f" · échelle {label_status(graph.get('scale'))}.",
        f"- Historique : {clean_sentence(graph.get('truth_label') or 'indisponible')}"
        f" · fournisseur {clean_sentence(graph.get('provider') or 'inconnu')}"
        f" · fraîcheur {freshness_label(graph.get('freshness'))}.",
        "- Règle : aucune tendance n’est déduite de la position verticale à l’écran.",
    ]

    series = graph.get("series") or []
    if series:
        for row in series:
            lines.append(
                f"- {clean_sentence(row.get('symbol') or '?')} : variation de série "
                f"{safe_value(row.get('series_change_pct'), fmt_pct)}"
                f" · {safe_value(row.get('points'))} points."
            )
    else:
        lines.append("- Aucune série exploitable dans le contrat.")

    return lines


def deterministic_math(contract: dict[str, Any]) -> list[str]:
    math = contract.get("math", {})
    window = math.get("active_window") or {}
    risk = math.get("historical_risk") or {}
    ci = risk.get("bootstrap_volatility_window_ci95_pct") or [None, None]

    lines = [
        f"- Actif : {math.get('asset') or 'indisponible'}.",
        f"- Score heuristique : {safe_value(math.get('heuristic_score'))}.",
        f"- Fenêtre active : {window.get('period_label') or 'indisponible'}"
        f" · granularité {window.get('granularity') or 'inconnue'}"
        f" · {safe_value(window.get('observations'))} points"
        f" · complétude {safe_value(window.get('completeness_pct'), fmt_pct)}.",
        f"- Volatilité réalisée sur la fenêtre : {safe_value(risk.get('realized_volatility_window_pct'), fmt_risk_pct)}.",
        f"- Volatilité réalisée annualisée : {safe_value(risk.get('realized_volatility_annualized_pct'), fmt_risk_pct)}.",
        f"- Volatilité EWMA annualisée : {safe_value(risk.get('ewma_volatility_annualized_pct'), fmt_risk_pct)}"
        f" · lambda {safe_value(risk.get('ewma_lambda'))}.",
        f"- Downside deviation annualisée : {safe_value(risk.get('downside_deviation_annualized_pct'), fmt_risk_pct)}.",
        f"- Drawdown maximal : {safe_value(risk.get('max_drawdown_pct'), fmt_risk_pct)}.",
        f"- VaR historique 95 % par pas : {safe_value(risk.get('var_historical_95_step_pct'), fmt_risk_pct)}.",
        f"- Expected Shortfall historique 95 % par pas : {safe_value(risk.get('expected_shortfall_historical_95_step_pct'), fmt_risk_pct)}.",
        f"- Corrélation au BTC : {safe_value(risk.get('correlation_btc'))}"
        f" · bêta {safe_value(risk.get('beta_btc'))}"
        f" · {safe_value(risk.get('benchmark_observations'))} observations alignées.",
        f"- Dispersion IQR par pas : {safe_value(risk.get('dispersion_iqr_step_pct'), fmt_risk_pct)}"
        f" · concentration des 10 % plus forts mouvements : {safe_value(risk.get('concentration_top10_absolute_moves_pct'), fmt_risk_pct)}.",
        f"- Intervalle bootstrap 95 % de volatilité de fenêtre : "
        f"{safe_value(ci[0] if len(ci) > 0 else None, fmt_risk_pct)} à "
        f"{safe_value(ci[1] if len(ci) > 1 else None, fmt_risk_pct)}"
        f" · {safe_value(risk.get('bootstrap_samples'))} rééchantillonnages.",
        f"- Ratio volume / capitalisation : {math.get('volume_market_cap_ratio') or 'indisponible'}.",
        f"- Risque global : {math.get('risk_global') or 'non évalué'}.",
        f"- Limite : {clean_sentence(math.get('limitation') or 'non précisée').rstrip('.')}.",
    ]

    not_calculated = math.get("explicitly_not_calculated") or []
    if not_calculated:
        lines.append("- Mesures non calculées : " + ", ".join(not_calculated) + ".")
    else:
        lines.append("- Toutes les mesures historiques prévues par Math Core V3 sont calculées pour cette fenêtre.")

    return lines


def deterministic_news(contract: dict[str, Any]) -> list[str]:
    news = contract.get("news", {})
    watchlist = contract.get("watchlist", {})
    lead = news.get("lead_event")

    lines = [
        f"- News Sentinel : {label_status(news.get('status'))}"
        f" · archive {format_datetime_fr(news.get('archive_time'))}.",
        f"- Watchlist : {safe_value(watchlist.get('configured_count'))} actifs observés"
        " · ce n’est pas un portefeuille.",
    ]

    if isinstance(lead, dict):
        lines.append(
            f"- Événement directeur : {clean_sentence(lead.get('headline') or lead.get('event_label') or 'sans titre')}"
            f" · preuve {format_score_block(lead.get('evidence'))}"
            f" · impact {format_score_block(lead.get('impact'))}."
        )
    else:
        lines.append("- Aucun événement directeur qualifié n’est fourni.")

    lines.append("- Une limite générale de données n’est jamais transformée en actualité.")
    return lines


def deterministic_contradictions(contract: dict[str, Any]) -> list[str]:
    issues = contract.get("contradictions") or []
    if not issues:
        return ["- Aucune contradiction déterministe enregistrée dans le contrat."]
    return [
        f"- [{clean_sentence(item.get('level') or 'à vérifier')}] "
        f"{clean_sentence(item.get('text') or item.get('code') or 'problème non décrit').rstrip('.')}."
        for item in issues
    ]


def deterministic_stop_point(contract: dict[str, Any]) -> list[str]:
    stop = contract.get("stop_point", {})
    return [
        f"- {stop.get('meaning') or 'Arrêter lorsque les données ne soutiennent plus la conclusion.'}",
        "- Aucune durée arbitraire n’est fixée.",
        "- La chaîne analytique Atlas → NØX → Aerith est automatique : aucune validation humaine n’est requise entre ses étapes.",
        "- Validation humaine uniquement avant une décision ou action financière réelle ; jamais pour autoriser la synthèse.",
    ]



def aerith_count_label(value: int, singular: str, plural: str) -> str:
    if value == 0:
        return f"aucun {singular}"
    if value == 1:
        return f"1 {singular}"
    return f"{value} {plural}"


def aerith_conclusion_situation(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    coverage = None
    try:
        loaded_n = int(loaded)
        target_n = int(target)
        if target_n > 0:
            coverage = (loaded_n / target_n) * 100
    except (TypeError, ValueError, ZeroDivisionError):
        coverage = None

    coverage_text = (
        f" ({fmt_number(coverage, 1)} % de couverture)" if coverage is not None else ""
    )
    return deterministic_sources(contract) + [
        f"- Univers chargé : {safe_value(loaded)}/{safe_value(target)} actifs{coverage_text}, devise EUR.",
        f"- État d’ensemble : {clean_sentence(breadth.get('classification') or 'indéterminée')}.",
        f"- Base de calcul : {breadth.get('basis') or 'indisponible'}.",
    ]


def aerith_conclusion_signal(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    top5 = contract.get("canonical_top5", {})

    try:
        positive_market = int(breadth.get("positive") or 0)
        negative_market = int(breadth.get("negative") or 0)
        stable_market = int(breadth.get("stable") or 0)
    except (TypeError, ValueError):
        positive_market = negative_market = stable_market = 0

    if positive_market > 0 and negative_market >= positive_market * 2:
        breadth_reading = (
            f"La pression baissière est large : {negative_market} baisses, "
            f"soit plus du double des {positive_market} hausses"
        )
    elif negative_market > 0 and positive_market >= negative_market * 2:
        breadth_reading = (
            f"La participation haussière est large : {positive_market} hausses, "
            f"soit plus du double des {negative_market} baisses"
        )
    elif positive_market == 0 and negative_market == 0:
        breadth_reading = "La largeur du marché n’est pas exploitable sur ce snapshot"
    else:
        breadth_reading = (
            f"La largeur reste partagée : {positive_market} hausses et {negative_market} baisses"
        )
    if stable_market:
        breadth_reading += f", avec {stable_market} actifs stables"
    breadth_reading += "."

    rows = [row for row in (top5.get("assets") or []) if row.get("available")]
    finite = [
        float(row.get("change_24h_pct"))
        for row in rows
        if isinstance(row.get("change_24h_pct"), (int, float))
    ]
    positives = sum(1 for value in finite if value > 0)
    negatives = sum(1 for value in finite if value < 0)
    stable = sum(1 for value in finite if value == 0)
    target_reading = " · ".join([
        aerith_count_label(positives, "actif positif", "actifs positifs"),
        aerith_count_label(negatives, "actif négatif", "actifs négatifs"),
        aerith_count_label(stable, "actif stable", "actifs stables"),
    ])
    return [
        f"- {breadth_reading}",
        f"- Target Top 5 : {target_reading} · couverture {'5/5' if top5.get('complete') else 'partielle'}.",
    ]


def aerith_conclusion_vigilance(contract: dict[str, Any]) -> list[str]:
    graph = contract.get("graph", {})
    math = contract.get("math", {})
    news = contract.get("news", {})
    watchlist = contract.get("watchlist", {})
    return [
        f"- Historique graphique : {clean_sentence(graph.get('truth_label') or 'indisponible')}"
        f" · fraîcheur {freshness_label(graph.get('freshness'))}.",
        f"- Math Core : {clean_sentence(math.get('risk_global') or 'risque global non évalué')}"
        f" · limite {clean_sentence(math.get('limitation') or 'non précisée').rstrip('.')}.",
        f"- News Sentinel : {label_status(news.get('status'))}.",
        f"- Watchlist : {safe_value(watchlist.get('configured_count'))} actifs observés"
        " · ce n’est pas un portefeuille.",
    ]


def aerith_conclusion_watch(contract: dict[str, Any]) -> list[str]:
    market = contract.get("market", {})
    graph = contract.get("graph", {})
    issues = contract.get("contradictions") or []
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    if loaded == target and loaded is not None:
        market_line = "- Vérifier que la prochaine lecture CoinGecko conserve la couverture complète du Market Snapshot."
    else:
        market_line = "- Vérifier si la prochaine lecture CoinGecko complète la couverture encore partielle du Market Snapshot."
    lines = [
        market_line,
        "- Contrôler la continuité des cinq cotations Binance directes du Target Top 5.",
        f"- Relever si la fraîcheur de l’historique graphique reste {freshness_label(graph.get('freshness'))} ou s’améliore.",
    ]
    if issues:
        lines.append("- Recontrôler les contradictions encore classées confirmées ou à vérifier.")
    else:
        lines.append("- Recontrôler l’apparition éventuelle d’une contradiction déterministe au prochain snapshot.")
    return lines



AERITH_GENERIC_COMMENT_PATTERNS = (
    r"^\s*(analyser|évaluer|utiliser|examiner|considérer|vérifier|contrôler|surveiller|prendre en compte|se baser)\b",
    r"\b(informations?|données?)\s+(fournies|disponibles)\b.{0,80}\b(sans ajout|sans modification)\b",
    r"\bqualité des données\b.{0,80}\bfiabilité des informations\b",
)


def aerith_market_coverage(contract: dict[str, Any]) -> tuple[int | None, int | None, float | None]:
    market = contract.get("market", {})
    loaded = market.get("assets_loaded")
    target = market.get("target_assets")
    try:
        loaded_n = int(loaded)
        target_n = int(target)
        coverage = (loaded_n / target_n) * 100 if target_n > 0 else None
        return loaded_n, target_n, coverage
    except (TypeError, ValueError, ZeroDivisionError):
        return None, None, None


def aerith_top5_distribution(contract: dict[str, Any]) -> tuple[int, int, int, int]:
    rows = [
        row for row in (contract.get("canonical_top5", {}).get("assets") or [])
        if row.get("available")
    ]
    values = [
        float(row.get("change_24h_pct"))
        for row in rows
        if isinstance(row.get("change_24h_pct"), (int, float))
    ]
    positives = sum(1 for value in values if value > 0)
    negatives = sum(1 for value in values if value < 0)
    stable = sum(1 for value in values if value == 0)
    return positives, negatives, stable, len(values)


def aerith_concrete_limits_comment(contract: dict[str, Any]) -> dict[str, str]:
    market = contract.get("market", {})
    breadth = market.get("breadth_24h", {})
    graph = contract.get("graph", {})

    try:
        positive_market = int(breadth.get("positive") or 0)
        negative_market = int(breadth.get("negative") or 0)
    except (TypeError, ValueError):
        positive_market = negative_market = 0

    if positive_market > 0 and negative_market >= positive_market * 2:
        opening = "La pression baissière est largement partagée"
    elif negative_market > 0 and positive_market >= negative_market * 2:
        opening = "La participation haussière est largement partagée"
    elif positive_market or negative_market:
        opening = "La largeur du marché reste partagée"
    else:
        opening = "La largeur du marché reste insuffisamment documentée"

    loaded_n, target_n, coverage = aerith_market_coverage(contract)
    market_partial = (
        loaded_n is not None and target_n is not None and target_n > 0 and loaded_n < target_n
    )
    graph_freshness = freshness_label(graph.get("freshness"))
    graph_delayed = graph_freshness in {"retardée", "ancienne", "archivée", "expirée"}

    qualifiers: list[str] = []
    if market_partial:
        qualifiers.append("un Market Snapshot encore incomplet")
    if graph_delayed:
        qualifiers.append(f"un historique graphique {graph_freshness}")

    if qualifiers:
        reading = f"{opening}, mais elle repose sur " + " et sur ".join(qualifiers) + "."
    else:
        reading = f"{opening} sur les sources actuellement disponibles."
    reading += " Elle décrit l’état observé, pas son évolution future."

    positives, negatives, stable, count = aerith_top5_distribution(contract)
    if count and negatives == count:
        caution = (
            "Le Target Top 5 est entièrement négatif, mais cette convergence ne constitue "
            "ni une prévision ni un signal d’exécution."
        )
    elif count and positives == count:
        caution = (
            "Le Target Top 5 est entièrement positif, mais cette convergence ne constitue "
            "ni une prévision ni un signal d’exécution."
        )
    elif count:
        caution = (
            "Le Target Top 5 reste partagé ; cette distribution ne constitue ni une prévision "
            "ni un signal d’exécution."
        )
    else:
        caution = (
            "Le Target Top 5 n’est pas suffisamment couvert pour soutenir une prévision "
            "ou un signal d’exécution."
        )

    limits_parts = [
        "Les risques de protocole, de contrepartie, de réglementation, de liquidité d’exécution "
        "et les données on-chain ne sont pas évalués."
    ]
    if market_partial:
        if coverage is not None:
            limits_parts.append(
                f"La couverture CoinGecko reste partielle à {fmt_number(coverage, 1)} %."
            )
        else:
            limits_parts.append("La couverture CoinGecko reste partielle.")
    if graph_delayed:
        limits_parts.append("L’historique graphique ne fournit pas encore une fraîcheur directe.")

    return {
        "reading": reading,
        "caution": caution,
        "limits": " ".join(limits_parts),
    }


def validate_aerith_concrete_comment(
    comment: dict[str, Any],
    contract: dict[str, Any],
) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(comment, dict):
        return False, ["commentaire Aerith non structuré"]

    required = ("reading", "caution", "limits")
    values: dict[str, str] = {}
    for key in required:
        value = str(comment.get(key) or "").strip()
        values[key] = value
        if len(value) < 35:
            warnings.append(f"commentaire Aerith trop générique : {key}")
        lowered = value.lower()
        for pattern in AERITH_GENERIC_COMMENT_PATTERNS:
            if re.search(pattern, lowered, flags=re.I | re.S):
                warnings.append(f"consigne générique refusée : {key}")
                break

    if not re.search(r"baissi|haussi|largeur|état observé|marché", values["reading"], flags=re.I):
        warnings.append("lecture Aerith non ancrée dans le marché observé")
    if not re.search(r"prévision|exécution|décision|certitude|signal", values["caution"], flags=re.I):
        warnings.append("prudence Aerith non concrète")
    if not re.search(
        r"protocole|contrepartie|réglementation|liquidité|on-chain|couverture|historique|non évalu",
        values["limits"],
        flags=re.I,
    ):
        warnings.append("limites Aerith non reliées aux risques absents")

    return not warnings, warnings

def aerith_conclusion_news(contract: dict[str, Any]) -> list[str]:
    news = contract.get("news", {}) or {}
    lead = news.get("lead_event") or {}
    if not lead:
        return [
            f"- News Sentinel : {label_status(news.get('status'))}.",
            "- Aucun événement directeur qualifié n’est disponible : ne pas fabriquer de causalité marché.",
        ]

    event = clean_sentence(lead.get("event_label") or "événement sans libellé")
    source = clean_sentence(lead.get("source_name") or "source non précisée")
    evidence = lead.get("evidence") or {}
    impact = lead.get("impact") or {}
    if isinstance(evidence, dict):
        evidence_text = clean_sentence(evidence.get("label") or evidence.get("quality") or "non qualifiée")
        if evidence.get("score") is not None:
            evidence_text += f" · score {safe_value(evidence.get('score'))}/100"
    else:
        evidence_text = clean_sentence(evidence or "non qualifiée")
    if isinstance(impact, dict):
        impact_text = clean_sentence(impact.get("label") or "non qualifié")
        if impact.get("score") is not None:
            impact_text += f" · score {safe_value(impact.get('score'))}/100"
    else:
        impact_text = clean_sentence(impact or "non qualifié")
    assets = [str(x).strip() for x in (lead.get("assets") or []) if str(x).strip()]
    sectors = [str(x).strip() for x in (lead.get("sectors") or []) if str(x).strip()]
    scope = " · ".join((assets + sectors)[:8]) or "portée à qualifier"
    decision = clean_sentence(lead.get("decision") or "observation")
    return [
        f"- Événement directeur : {event}.",
        f"- Source : {source} · preuve {evidence_text}.",
        f"- Impact potentiel : {impact_text} · actifs/secteurs : {scope}.",
        f"- Lecture News : {decision}.",
        "- La proximité temporelle entre une news et un mouvement de prix ne démontre pas la causalité.",
    ]


def aerith_conclusion_nox(contract: dict[str, Any]) -> list[str]:
    audit = contract.get("nox_no_fomo_v1") or {}
    status = str(audit.get("status") or "PRUDENCE").strip().upper()
    fomo = clean_sentence(audit.get("fomo") or "à vérifier")
    causal = clean_sentence(audit.get("causal_inference") or "NON ÉTABLIE")
    decision = clean_sentence(audit.get("decision") or "Continuer en observation")
    flags = [clean_sentence(x) for x in (audit.get("flags") or []) if clean_sentence(x)]
    lines = [
        f"- État NØX : {status} · FOMO {fomo}.",
        f"- Causalité : {causal}.",
        f"- Refroidissement : {decision}.",
    ]
    if flags:
        lines.append("- Motifs : " + " · ".join(flags[:5]) + ".")
    lines.append("- NØX ne produit ni prix, ni ordre, ni recommandation financière.")
    return lines


def build_aerith_conclusion(contract: dict[str, Any], comment: dict[str, str]) -> str:
    sections = [
        ("1. Situation générale", aerith_conclusion_situation(contract)),
        ("2. Relecture des quatre rapports Atlas-10 CURRENT", aerith_atlas_reports_re_read_lines(contract)),
        ("3. Synthèse transversale Aerith-10", render_comment(comment, "aerith")),
        ("4. Signal dominant", aerith_conclusion_signal(contract)),
        ("5. News Sentinel — événement et preuve", aerith_conclusion_news(contract)),
        ("6. Points de vigilance", aerith_conclusion_vigilance(contract)),
        ("7. NØX No-FOMO — refroidissement", aerith_conclusion_nox(contract)),
        ("8. Contradictions importantes", deterministic_contradictions(contract)),
        ("9. Ce qu’il faut surveiller ensuite", aerith_conclusion_watch(contract)),
        ("10. Comprendre cette page — vulgarisation", [
            "- Atlas décrit les faits et calculs présents dans le snapshot ; NØX cherche les exagérations, la pression FOMO et les causalités non démontrées ; Aerith croise l’ensemble sans remplacer les données.",
            "- Prix : valeur observée à l’instant du snapshot, pas une prévision.",
            "- Volume : quantité ou valeur échangée sur une période ; une baisse de volume n’explique pas à elle seule une hausse ou une baisse de prix.",
            "- Volatilité : amplitude des mouvements observés ; elle ne donne pas la direction future.",
            "- Corrélation : deux séries peuvent évoluer ensemble sans lien de cause à effet.",
            "- VaR / Expected Shortfall : mesures statistiques historiques du risque ; elles ne constituent ni garantie ni perte maximale certaine.",
            "- News : importance potentielle et niveau de preuve doivent être séparés ; une actualité importante n’est jamais automatiquement un signal d’exécution.",
            "- INFORMATION MANQUANTE reste INFORMATION MANQUANTE : aucune valeur absente ne doit être inventée.",
        ]),
        ("11. Limites et stop point", deterministic_stop_point(contract)),
    ]
    lines: list[str] = []
    for title, body in sections:
        lines.append(f"**{title}**")
        lines.append("")
        lines.extend(body)
        lines.append("")
    return "\n".join(lines).strip()

def allowed_number_tokens(contract: dict[str, Any]) -> set[str]:
    raw = json.dumps(contract, ensure_ascii=False)
    numbers = re.findall(r"-?\d+(?:[.,]\d+)?", raw)
    allowed: set[str] = set()

    for token in numbers:
        normalized = token.replace(",", ".")
        allowed.add(token)
        allowed.add(normalized)
        try:
            value = float(normalized)
        except ValueError:
            continue
        for digits in range(0, 7):
            rendered = f"{value:.{digits}f}"
            allowed.add(rendered)
            allowed.add(rendered.replace(".", ","))

    # Numéros de sections autorisés.
    allowed.update(str(i) for i in range(1, 10))
    return allowed


def validate_model_comment(comment: dict[str, Any], contract: dict[str, Any]) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if not isinstance(comment, dict):
        return False, ["sortie locale non structurée"]

    required = ("reading", "caution", "limits")
    for key in required:
        value = comment.get(key)
        if not isinstance(value, str) or not value.strip():
            warnings.append(f"champ du commentaire absent : {key}")

    text = "\n".join(str(comment.get(key) or "") for key in required).strip()
    if len(text) > 3600:
        warnings.append("analyse locale trop longue")

    lowered = text.lower()
    for pattern in FORBIDDEN_MODEL_PATTERNS:
        if re.search(pattern, lowered, flags=re.I | re.S):
            warnings.append(f"formulation interdite : {pattern}")

    allowed = allowed_number_tokens(contract)
    for token in re.findall(r"-?\d+(?:[.,]\d+)?", text):
        if token not in allowed and token.replace(",", ".") not in allowed:
            warnings.append(f"nombre non autorisé : {token}")

    return not warnings, warnings


def read_runtime_profile(profile: str) -> str:
    runtime_file = RUNTIME_PROFILE_FILES.get(profile)
    if not runtime_file or not runtime_file.exists():
        raise RuntimeError("Prompt runtime local manquant.")
    return runtime_file.read_text(encoding="utf-8")


def atlas_suite_cache_key(contract: dict[str, Any]) -> str:
    payload = json.dumps(contract, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def parse_atlas_suite_comments(raw: str) -> dict[str, dict[str, str]]:
    text = str(raw or "").strip()
    if not text:
        return {}
    text = re.sub(r"^```(?:json)?\\s*", "", text, flags=re.I)
    text = re.sub(r"\\s*```$", "", text)
    candidates = [text]
    first = text.find("{")
    last = text.rfind("}")
    if first >= 0 and last > first:
        candidates.append(text[first:last + 1])
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
        except Exception:
            continue
        if isinstance(parsed, dict) and isinstance(parsed.get("comments"), dict):
            parsed = parsed["comments"]
        if not isinstance(parsed, dict):
            continue
        result: dict[str, dict[str, str]] = {}
        for mode in CONCLUSION_REPORT_MODES:
            value = parsed.get(mode)
            if isinstance(value, dict):
                normalized = normalize_model_comment(value)
                if normalized:
                    result[mode] = normalized
        if result:
            return result
    return {}


def atlas_suite_cached_result(key: str) -> dict[str, Any] | None:
    with ATLAS_SUITE_COMMENT_CACHE_LOCK:
        value = ATLAS_SUITE_COMMENT_CACHE.get(key)
        return dict(value) if isinstance(value, dict) else None


def atlas_suite_store_result(key: str, value: dict[str, Any]) -> None:
    with ATLAS_SUITE_COMMENT_CACHE_LOCK:
        ATLAS_SUITE_COMMENT_CACHE[key] = dict(value)
        while len(ATLAS_SUITE_COMMENT_CACHE) > ATLAS_SUITE_COMMENT_CACHE_MAX:
            oldest = next(iter(ATLAS_SUITE_COMMENT_CACHE))
            if oldest == key and len(ATLAS_SUITE_COMMENT_CACHE) == 1:
                break
            ATLAS_SUITE_COMMENT_CACHE.pop(oldest, None)


def call_model_atlas_suite_comments(
    config: dict[str, Any],
    provider_name: str,
    model: str,
    contract: dict[str, Any],
) -> dict[str, Any]:
    """Generate all four Atlas bounded comments in one model pass.

    V1.9.10 invoked gpt-oss once per /summary route (4 expensive inferences),
    then once more for Aerith. V1.9.11 keeps the same four deterministic
    reports and same browser protocol, but shares one Atlas inference result
    across market/top5/math/contradictions for the same strict contract.
    """
    key = atlas_suite_cache_key(contract)
    cached = atlas_suite_cached_result(key)
    if cached is not None:
        cached["cache_hit"] = True
        return cached

    provider = config["providers"][provider_name]
    base = provider["base_url"].rstrip("/")
    timeout = int(provider.get("timeout_seconds", 120))
    generation = config.get("generation", {})
    performance = config.get("performance", {})
    temperature = float(generation.get("temperature", 0.08))
    num_ctx = max(4096, int(performance.get("atlas_suite_num_ctx", 8192)))
    num_predict = max(256, int(performance.get("atlas_suite_num_predict", 900)))
    keep_alive = performance.get("atlas_suite_keep_alive", "90s")

    facts = model_comment_facts(contract, "market", "")
    facts["mission"] = "atlas_suite_4"
    facts["planned_modes"] = list(CONCLUSION_REPORT_MODES)
    facts["output_contract"] = {
        "keys": list(CONCLUSION_REPORT_MODES),
        "fields_each": ["reading", "caution", "limits"],
        "numbers": "do_not_add_any_number_not_present_in_facts",
        "style": "three short factual French sentences per mode",
    }

    runtime_profile = read_runtime_profile("atlas")
    system = (
        runtime_profile
        + "\\n\\n"
        + model_comment_profile("atlas")
        + "\\n\\n"
        + MODEL_COMMENT_RULES
        + "\\n\\nTu produis en UNE SEULE PASSE les quatre commentaires bornés Atlas CURRENT. "
        + "Retourne uniquement un objet JSON avec les clés market, top5, math, contradictions. "
        + "Chaque clé contient reading, caution, limits. Aucun texte hors JSON."
    )
    user = (
        "Produis les quatre commentaires à partir de ce dossier contrôlé. "
        "N'invente aucun fait, nombre, causalité, portefeuille ou recommandation.\\n\\n"
        + json.dumps(facts, ensure_ascii=False, separators=(",", ":"))
    )

    try:
        if provider_name == "ollama":
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "stream": False,
                "format": "json",
                "keep_alive": keep_alive,
                "options": {
                    "temperature": temperature,
                    "num_ctx": num_ctx,
                    "num_predict": num_predict,
                },
            }
            result = request_json(f"{base}/api/chat", payload, timeout)
            raw = str(result.get("message", {}).get("content", "") or "").strip()
        else:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": temperature,
                "stream": False,
                "response_format": {"type": "json_object"},
            }
            result = request_json(f"{base}/chat/completions", payload, timeout)
            choices = result.get("choices") or []
            raw = str(choices[0].get("message", {}).get("content", "") if choices else "").strip()
    except Exception as exc:
        suite = {
            "used": False,
            "cache_hit": False,
            "provider_failure": True,
            "warnings": [f"suite Atlas locale indisponible après {timeout}s : {type(exc).__name__}"],
            "comments": {},
        }
        atlas_suite_store_result(key, suite)
        return suite

    parsed = parse_atlas_suite_comments(raw)
    comments: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []
    for mode in CONCLUSION_REPORT_MODES:
        comment = parsed.get(mode)
        valid, mode_warnings = validate_model_comment(comment or {}, contract)
        if valid and comment:
            comments[mode] = {"used": True, "comment": comment, "warnings": []}
        else:
            comments[mode] = {
                "used": False,
                "comment": deterministic_comment("atlas", mode),
                "warnings": mode_warnings or [f"commentaire suite Atlas manquant : {mode}"],
            }
            warnings.extend(comments[mode]["warnings"])

    suite = {
        "used": any(bool(value.get("used")) for value in comments.values()),
        "cache_hit": False,
        "provider_failure": False,
        "warnings": warnings,
        "comments": comments,
        "num_ctx": num_ctx,
        "model_calls_for_atlas_4_4": 1,
    }
    atlas_suite_store_result(key, suite)
    return suite


def call_model_comment(
    config: dict[str, Any],
    provider_name: str,
    model: str,
    profile: str,
    mode: str,
    question: str,
    contract: dict[str, Any],
) -> dict[str, Any]:
    provider = config["providers"][provider_name]
    base = provider["base_url"].rstrip("/")
    timeout = int(provider.get("timeout_seconds", 120))
    if mode == "conclusion":
        timeout = min(
            timeout,
            int(config.get("generation", {}).get("conclusion_comment_timeout_seconds", 300))
        )
    temperature = float(config.get("generation", {}).get("temperature", 0.08))

    facts = model_comment_facts(contract, mode, question)

    runtime_profile = read_runtime_profile(profile)
    system = (
        runtime_profile
        + "\n\n"
        + model_comment_profile(profile)
        + "\n\n"
        + MODEL_COMMENT_RULES
        + "\n\nLe dossier factuel est déjà construit par Agent-Crypto et validé par le Bridge."
        + "\nPour une conclusion Aerith, le dossier contient aussi le texte des quatre rapports Atlas CURRENT : relis-les réellement avant de synthétiser."
        + "\nLe modèle explique et met en perspective ; il ne remplace ni Data Truth, ni Math Core, ni les contradictions."
    )

    user = (
        "Commente seulement ce dossier contrôlé. Pour une conclusion, croise réellement les quatre rapports Atlas transmis avec le snapshot et NØX. "
        "Ne reconstruis aucun fait et n’ajoute aucune information.\n\n"
        + json.dumps(facts, ensure_ascii=False, separators=(",", ":"))
    )

    try:
        if provider_name == "ollama":
            performance = config.get("performance", {})
            if mode == "conclusion":
                num_ctx = max(8192, int(performance.get("conclusion_num_ctx", 16384)))
                num_predict = max(512, int(performance.get("conclusion_num_predict", 1400)))
                keep_alive = performance.get("conclusion_keep_alive", 0)
            else:
                num_ctx = max(4096, int(performance.get("comment_num_ctx", 8192)))
                num_predict = max(192, int(performance.get("comment_num_predict", 480)))
                keep_alive = performance.get("comment_keep_alive", "60s")
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "stream": False,
                "format": "json",
                "keep_alive": keep_alive,
                "options": {
                    "temperature": temperature,
                    "num_ctx": num_ctx,
                    "num_predict": num_predict,
                },
            }
            result = request_json(f"{base}/api/chat", payload, timeout)
            raw = str(result.get("message", {}).get("content", "") or "").strip()
        else:
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": temperature,
                "stream": False,
                "response_format": {"type": "json_object"},
            }
            result = request_json(f"{base}/chat/completions", payload, timeout)
            choices = result.get("choices") or []
            raw = str(
                choices[0].get("message", {}).get("content", "")
                if choices else ""
            ).strip()
    except Exception as exc:
        return {
            "used": False,
            "warnings": [f"commentaire local indisponible après {timeout}s : {type(exc).__name__}"],
            "comment": None,
            "provider_failure": True,
            "provider_error": str(exc)[:220],
        }

    parsed = parse_model_comment(raw)
    if not parsed:
        return {
            "used": False,
            "warnings": ["commentaire local non structuré"],
            "comment": None,
        }

    valid, warnings = validate_model_comment(parsed, contract)
    return {
        "used": valid,
        "warnings": warnings,
        "comment": parsed if valid else None,
    }


def deterministic_comment(profile: str, mode: str) -> dict[str, str]:
    if profile == "aerith":
        return {
            "reading": (
                "Les sources convergent vers une lecture de prudence, mais elles décrivent "
                "un état présent et non une certitude sur la suite."
            ),
            "caution": (
                "Une variation ou une actualité isolée ne suffit pas à justifier une décision ; "
                "la cohérence des sources et leur fraîcheur doivent d’abord être confirmées."
            ),
            "limits": (
                "Le risque mesuré reste historique et partiel ; les dimensions de protocole, "
                "contrepartie, réglementation, exécution et données on-chain ne sont pas couvertes."
            ),
        }

    return {
        "reading": (
            "Le contrat factuel permet de comparer les sources, les horizons et "
            "les séries sans reconstruire les données."
        ),
        "caution": (
            "Toute conclusion qui dépasse les mesures présentes doit être rejetée "
            "ou classée à vérifier."
        ),
        "limits": (
            "Le rapport reste descriptif, en lecture seule, et ne couvre pas "
            "les risques absents du Math Core."
        ),
    }


def render_comment(comment: dict[str, str], profile: str) -> list[str]:
    name = "Aerith-10" if profile == "aerith" else "Atlas-10"
    return [
        f"- Lecture {name} : {comment['reading']}",
        f"- Prudence : {comment['caution']}",
        f"- Limites : {comment['limits']}",
    ]


def build_report(
    contract: dict[str, Any],
    profile: str,
    mode: str,
    comment: dict[str, str],
) -> str:
    sections: list[tuple[str, list[str]]]

    if mode == "top5":
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Target Top 5 canonique", deterministic_top5(contract)),
            ("3. Graphique lié au Top 5", deterministic_graph(contract)),
            ("4. Commentaire local borné", render_comment(comment, profile)),
            ("5. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("6. Stop point", deterministic_stop_point(contract)),
        ]
    elif mode == "math":
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Math Core — mesures réellement calculées", deterministic_math(contract)),
            ("3. Commentaire local borné", render_comment(comment, profile)),
            ("4. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("5. Stop point", deterministic_stop_point(contract)),
        ]
    elif mode == "contradictions":
        sections = [
            ("1. Verrous du contrat", [
                "- Top 5 canonique : BTC / ETH / BNB / XRP / SOL.",
                "- Aucun null transformé en zéro.",
                "- Aucune mesure Math absente inventée.",
                "- Aucune position visuelle du graphique interprétée comme tendance.",
                "- Aucune limite générale transformée en actualité.",
            ]),
            ("2. Contradictions détectées", deterministic_contradictions(contract)),
            ("3. Sources à vérifier", deterministic_sources(contract)),
            ("4. Commentaire local borné", render_comment(comment, profile)),
            ("5. Stop point", deterministic_stop_point(contract)),
        ]
    else:
        sections = [
            ("1. État des sources", deterministic_sources(contract)),
            ("2. Lecture globale déterministe", deterministic_market(contract)),
            ("3. Target Top 5 canonique", deterministic_top5(contract)),
            ("4. Graphique", deterministic_graph(contract)),
            ("5. Math Core", deterministic_math(contract)),
            ("6. News Sentinel / Watchlist", deterministic_news(contract)),
            ("7. Contradictions et données manquantes", deterministic_contradictions(contract)),
            ("8. Commentaire local borné", render_comment(comment, profile)),
            ("9. Stop point", deterministic_stop_point(contract)),
        ]

    lines: list[str] = []
    for title, body in sections:
        lines.append(f"**{title}**")
        lines.append("")
        lines.extend(body)
        lines.append("")

    return "\n".join(lines).strip()



BOOK_MIRROR_SCHEMA = "agent_crypto_book_mirror_v36"
BOOK_MIRROR_REPOSITORY = "BlueAzur-Hub/erith-ia-memory"
BOOK_MIRROR_BRANCH = "main"
BOOK_MIRROR_PATH = "public/agent_crypto_erith_ia/administrator/book_mirror.json"
BOOK_MIRROR_MAX_BYTES = 2_500_000
BOOK_MIRROR_WRITE_LOCK = threading.Lock()


def github_credential() -> tuple[str, str]:
    for key in ("AGENT_CRYPTO_GITHUB_TOKEN", "GH_TOKEN", "GITHUB_TOKEN"):
        value = str(os.environ.get(key) or "").strip()
        if value:
            return value, f"env:{key}"
    gh = shutil.which("gh")
    if gh:
        try:
            cp = subprocess.run([gh, "auth", "token"], capture_output=True, text=True, timeout=6, check=True)
            value = cp.stdout.strip()
            if value:
                return value, "gh-cli"
        except Exception:
            pass
    git = shutil.which("git")
    if git:
        try:
            cp = subprocess.run([git, "credential", "fill"], input="protocol=https\nhost=github.com\n\n", capture_output=True, text=True, timeout=8, check=True)
            fields = dict(line.split("=", 1) for line in cp.stdout.splitlines() if "=" in line)
            value = str(fields.get("password") or "").strip()
            if value:
                return value, "git-credential"
        except Exception:
            pass
    return "", ""


def github_json(method: str, url: str, token: str, payload: dict[str, Any] | None = None, timeout: int = 18) -> tuple[int, Any]:
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {"Accept": "application/vnd.github+json", "Authorization": f"Bearer {token}", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "Atlas-10-Crypto-Bridge/1.9.11"}
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read()
            return response.status, json.loads(raw.decode("utf-8")) if raw else {}
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try: body = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception: body = {"message": raw.decode("utf-8", errors="replace")[:500]}
        return exc.code, body


def book_mirror_validate(payload: dict[str, Any]) -> tuple[str, str]:
    if str(payload.get("schema") or "") != BOOK_MIRROR_SCHEMA:
        raise ValueError("Schéma book_mirror refusé.")
    if payload.get("observation_only") is not True:
        raise ValueError("Le miroir doit rester observation_only.")
    execution = payload.get("execution") or {}
    if str(execution.get("producer") or "") != "ryzen" or str(execution.get("consumer") or "") != "transformer_book":
        raise ValueError("Provenance Ryzen → Transformer Book requise.")
    package = payload.get("package")
    if not isinstance(package, dict):
        raise ValueError("Paquet CURRENT absent.")
    reports = package.get("reports") or {}
    required = ("market", "top5", "math", "contradictions")
    if not all(str((reports.get(mode) or {}).get("answer") or "").strip() for mode in required):
        raise ValueError("Atlas 4/4 complet requis avant publication Book.")
    conclusion = package.get("conclusion") or {}
    if not str(conclusion.get("answer") or "").strip():
        raise ValueError("Conclusion Aerith complète requise.")
    fp = str(payload.get("fingerprint") or "").strip()
    if not fp or len(fp) > 180:
        raise ValueError("Fingerprint miroir absent ou invalide.")
    generated = str(payload.get("generated_at") or "").strip()
    return fp, generated


def book_mirror_status() -> dict[str, Any]:
    token, mode = github_credential()
    previous = None
    try: previous = load_json(BOOK_MIRROR_STATUS_PATH)
    except Exception: previous = None
    return {"ok": True, "bridge_version": "1.9.11", "enabled": True, "credential_ready": bool(token), "credential_mode": mode or None, "repository": BOOK_MIRROR_REPOSITORY, "branch": BOOK_MIRROR_BRANCH, "path": BOOK_MIRROR_PATH, "generic_github_write": False, "last_publication": previous}


def book_mirror_publish(payload: dict[str, Any]) -> dict[str, Any]:
    fp, generated = book_mirror_validate(payload)
    token, mode = github_credential()
    if not token:
        raise RuntimeError("Credential GitHub local absent : publication Book indisponible.")
    raw = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if len(raw) > BOOK_MIRROR_MAX_BYTES:
        raise ValueError("book_mirror.json trop volumineux.")
    api = f"https://api.github.com/repos/{BOOK_MIRROR_REPOSITORY}/contents/{BOOK_MIRROR_PATH}"
    with BOOK_MIRROR_WRITE_LOCK:
        status, existing = github_json("GET", api + f"?ref={BOOK_MIRROR_BRANCH}", token)
        existing_sha = str(existing.get("sha") or "") if status == 200 and isinstance(existing, dict) else ""
        if status not in {200, 404}:
            raise RuntimeError(f"GitHub lecture miroir refusée HTTP {status}.")
        current_fp = ""
        current_generated = ""
        if status == 200 and isinstance(existing, dict):
            try:
                decoded = base64.b64decode(str(existing.get("content") or "").replace("\n", ""))
                current = json.loads(decoded.decode("utf-8"))
                current_fp = str(current.get("fingerprint") or "")
                current_generated = str(current.get("generated_at") or "")
            except Exception:
                pass
        if current_fp == fp:
            result = {"ok": True, "changed": False, "fingerprint": fp, "generated_at": generated, "credential_mode": mode, "path": BOOK_MIRROR_PATH}
        else:
            # Refuse obvious rollback when both payloads expose comparable snapshot timestamps.
            new_snapshot = str((payload.get("package") or {}).get("snapshot_at") or "")
            old_snapshot = ""
            try:
                old_snapshot = str((current.get("package") or {}).get("snapshot_at") or "")
            except Exception:
                old_snapshot = ""
            if old_snapshot and new_snapshot:
                try:
                    old_dt = datetime.fromisoformat(old_snapshot.replace("Z", "+00:00"))
                    new_dt = datetime.fromisoformat(new_snapshot.replace("Z", "+00:00"))
                    if new_dt < old_dt:
                        raise ValueError("Rollback book_mirror refusé : snapshot plus ancien que le miroir publié.")
                except ValueError as exc:
                    if "Rollback book_mirror refusé" in str(exc):
                        raise
            body = {"message": f"agent-crypto: update Book mirror {fp[:18]}", "content": base64.b64encode(raw).decode("ascii"), "branch": BOOK_MIRROR_BRANCH}
            if existing_sha: body["sha"] = existing_sha
            put_status, put = github_json("PUT", api, token, body, timeout=25)
            if put_status not in {200, 201}:
                raise RuntimeError(f"GitHub publication miroir refusée HTTP {put_status}: {str((put or {}).get('message') or '')[:220]}")
            result = {"ok": True, "changed": True, "fingerprint": fp, "generated_at": generated, "credential_mode": mode, "path": BOOK_MIRROR_PATH, "content_sha": str((put.get("content") or {}).get("sha") or "")}
        BOOK_MIRROR_STATUS_PATH.parent.mkdir(parents=True, exist_ok=True)
        BOOK_MIRROR_STATUS_PATH.write_text(json.dumps({**result, "published_at": utc_now()}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        security_audit("book_mirror_publish", ok=True, detail=f"changed={result['changed']} fp={fp[:24]}")
        return result

class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "AtlasCryptoBridge/1.9.11"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {self.address_string()} {fmt % args}")

    @property
    def config(self) -> dict[str, Any]:
        return self.server.config  # type: ignore[attr-defined]

    def allowed_origin(self) -> str:
        origin = self.headers.get("Origin", "")
        allowed = self.config.get("allowed_origins", [])
        if not origin:
            return ""
        if origin in allowed:
            return origin
        return ""

    def send_json(self, status: int, payload: dict[str, Any]) -> bool:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            origin = self.allowed_origin()
            if origin:
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
            self.end_headers()
            self.wfile.write(data)
            return True
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError):
            # Firefox peut annuler une ancienne requête lorsque le graphique
            # change. La réponse n'est plus utile ; le Bridge reste sain.
            return False

    def bearer_token(self) -> str:
        value = str(self.headers.get("Authorization") or "").strip()
        if not value.lower().startswith("bearer "):
            return ""
        return value.split(" ", 1)[1].strip()

    def require_authenticated(self, route: str) -> dict[str, Any] | None:
        token = self.bearer_token()
        session = auth_session_get(token)
        if not session:
            security_audit("auth_required", ok=False, detail=route, remote=self.client_address[0])
            self.send_json(401, {"ok": False, "error": "Authentification Administrator Bridge requise.", "auth_required": True})
            return None
        capability = ROUTE_CAPABILITY.get(route)
        if capability and capability not in CAPABILITY_POLICY.get(str(session.get("role") or ""), frozenset()):
            security_audit("capability_refused", ok=False, detail=f"{route}:{capability}", remote=self.client_address[0])
            self.send_json(403, {"ok": False, "error": "Capacité Bridge refusée.", "required_capability": capability})
            return None
        return session

    def do_OPTIONS(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return
        self.send_json(204, {})

    def do_GET(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return

        parsed_url = urlparse(self.path)
        route = parsed_url.path

        if route == "/auth/status":
            token = self.bearer_token()
            session = auth_session_get(token)
            self.send_json(200, {
                "ok": True,
                "configured": auth_state_read() is not None,
                "authenticated": session is not None,
                "role": session.get("role") if session else None,
                "session_ttl_seconds": AUTH_SESSION_TTL_SECONDS,
                "bridge_version": "1.9.11",
            })
            return

        privileged_session = None
        if route in AUTH_PRIVILEGED_GET:
            privileged_session = self.require_authenticated(route)
            if privileged_session is None:
                return

        if route == "/capabilities":
            role = str(privileged_session.get("role") or "reader")
            self.send_json(200, {"ok": True, "bridge_version": "1.9.11", "role": role, "capabilities": capabilities_for_role(role), "refusal_default": True})
            return

        if route == "/security/status":
            self.send_json(200, {"ok": True, "bridge_version": "1.9.11", "auth_configured": auth_state_read() is not None, "sessions_memory_only": True, "audit_log": str(SECURITY_AUDIT_PATH.relative_to(ROOT)), "generic_github_write": False, "book_mirror_publication": True, "exchange_actions": False, "wallet_actions": False})
            return

        if route == "/book-mirror/status":
            self.send_json(200, book_mirror_status())
            return

        if route == "/health":
            providers = {
                name: provider_status(self.config, name)
                for name in ("ollama", "lm_studio")
            }
            active = None
            model = None
            readiness_error = ""
            try:
                # V1.9.6 — reuse the provider inventory above. /health must be a
                # cheap readiness read, not two consecutive Ollama /api/tags probes.
                active, model = choose_provider(self.config, providers)
            except Exception as exc:
                readiness_error = str(exc)

            required_model = str(
                self.config.get("providers", {})
                .get("ollama", {})
                .get("model") or "gpt-oss:20b-32k"
            )
            model_ready = bool(active and model)

            self.send_json(200, {
                "ok": True,
                "ready": model_ready,
                "model_ready": model_ready,
                "required_model": required_model,
                "readiness_error": readiness_error,
                "service": "Atlas-10 Crypto Bridge Ryzen",
                "version": "1.9.11",
                "quality": "strict_contract_v2_v3_truth_evidence",
                "comment_prompt_policy": "sanitized_comment_v1",
                "forbidden_control_terms_sent_to_model": False,
                "time": utc_now(),
                "read_only": True,
                "auth": {"required_for_privileged_routes": True, "configured": auth_state_read() is not None, "session_ttl_seconds": AUTH_SESSION_TTL_SECONDS},
                "book_mirror": {"enabled": True, "owner": "Bridge 1.9.11", "path": BOOK_MIRROR_PATH, "generic_github_write": False},
                "history_proxy_read_only": True,
                "history_route": "/history",
                "scanner_collector_route": "/scanner-snapshot",
                "scanner_status_route": "/scanner-status",
                "scanner_latest_route": "/scanner-latest",
                "scanner_history_route": "/scanner-history",
                "aerith_conclusion_route": "/conclusion",
                "local_observation_storage": True,
                "inference_policy": {
                    "atlas_4_4_model_calls": 1 if self.config.get("performance", {}).get("atlas_suite_single_model_pass", True) else 4,
                    "aerith_conclusion_model_calls": 1,
                    "atlas_num_ctx": int(self.config.get("performance", {}).get("atlas_suite_num_ctx", 8192)),
                    "conclusion_num_ctx": int(self.config.get("performance", {}).get("conclusion_num_ctx", 16384)),
                    "unload_after_conclusion": self.config.get("performance", {}).get("conclusion_keep_alive", 0) == 0,
                },
                "provider": active,
                "model": model,
                "providers": providers,
                "profiles": profile_health(),
                "actions": {
                    "exchange": False,
                    "wallet": False,
                    "github": False,
                    "github_publication": False,
                    "ui": False,
                },
            })
            return

        if route == "/profiles":
            self.send_json(200, {
                "ok": True,
                "quality": "strict_contract_v2_v3_truth_evidence",
                "profiles": profile_health(),
            })
            return

        if route == "/history":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                coin_id = str((query.get("coin_id") or [""])[0]).strip().lower()
                symbol = str((query.get("symbol") or [""])[0]).strip().upper()
                days_raw = str((query.get("days") or ["1"])[0]).strip()
                if not re.fullmatch(r"[a-z0-9-]{1,80}", coin_id):
                    raise ValueError("coin_id invalide.")
                if not re.fullmatch(r"[A-Z0-9]{2,15}", symbol):
                    raise ValueError("symbol invalide.")
                try:
                    days = int(days_raw)
                except ValueError as exc:
                    raise ValueError("days invalide.") from exc
                if days not in HISTORY_PERIODS:
                    raise ValueError("Période autorisée : 1, 7, 30, 60, 90, 365 ou 36500 jours.")
                allow_binance_raw = str((query.get("allow_binance") or ["1"])[0]).strip().lower()
                allow_binance = allow_binance_raw not in {"0", "false", "no"}
                payload = fetch_history_singleflight(
                    self.config, coin_id, symbol, days, allow_binance
                )
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc), "read_only": True})
            except Exception as exc:
                self.send_json(503, {
                    "ok": False,
                    "error": str(exc),
                    "attempts": list(getattr(exc, "attempts", [])),
                    "read_only": True,
                    "bridge_version": "1.9.11",
                })
            else:
                self.send_json(200, payload)
            return

        if route == "/scanner-latest":
            latest = scanner_read_latest()
            self.send_json(200, {
                "ok": True,
                "bridge_version": "1.9.11",
                "schema": SCANNER_SCHEMA,
                "available": latest is not None,
                "snapshot": latest,
                "read_only_external": True,
                "local_observation_storage": True,
            })
            return

        if route == "/scanner-status":
            self.send_json(200, scanner_status(self.config))
            return

        if route == "/scanner-history":
            try:
                query = parse_qs(parsed_url.query, keep_blank_values=False)
                basket = str((query.get("basket") or ["top5"])[0]).strip().lower()
                limit_raw = str((query.get("limit") or ["120"])[0]).strip()
                limit = int(limit_raw)
                rows = scanner_history(self.config, basket, limit)
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": "1.9.11",
                    "schema": SCANNER_SCHEMA,
                    "basket": basket,
                    "count": len(rows),
                    "rows": rows,
                    "read_only_external": True,
                })
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc)})
            except Exception as exc:
                self.send_json(503, {"ok": False, "error": str(exc)})
            return

        self.send_json(404, {"ok": False, "error": "Route inconnue."})

    def read_body(self, max_bytes: int | None = None) -> dict[str, Any]:
        raw_length = self.headers.get("Content-Length", "0")
        length = int(raw_length)
        max_snapshot = int(
            self.config.get("generation", {})
            .get("max_snapshot_chars", 250000)
        )
        limit = int(max_bytes) if max_bytes is not None else max_snapshot + 20000
        if length <= 0 or length > limit:
            raise ValueError("Corps vide ou trop volumineux.")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def do_POST(self) -> None:
        if self.headers.get("Origin") and not self.allowed_origin():
            self.send_json(403, {"ok": False, "error": "Origine refusée."})
            return

        route = urlparse(self.path).path
        if route in {"/auth/register", "/auth/login", "/auth/logout"}:
            if not self.headers.get("Origin") or not self.allowed_origin():
                self.send_json(403, {"ok": False, "error": "Origin Administrator exacte requise."})
                return
            try:
                body = self.read_body(max_bytes=16_384)
                if route == "/auth/logout":
                    token = self.bearer_token()
                    if not auth_session_get(token):
                        self.send_json(401, {"ok": False, "error": "Session Bridge absente."})
                        return
                    auth_session_revoke(token)
                    security_audit("logout", ok=True, remote=self.client_address[0])
                    self.send_json(200, {"ok": True, "logged_out": True, "bridge_version": "1.9.11"})
                    return
                remote = self.client_address[0]
                if not auth_failure_allowed(remote):
                    security_audit("login_rate_limit", ok=False, remote=remote)
                    self.send_json(429, {"ok": False, "error": "Trop de tentatives. Réessaie plus tard."})
                    return
                secret = str(body.get("secret") or "")
                if route == "/auth/register":
                    auth_register(secret)
                elif not auth_verify(secret):
                    auth_failure_record(remote)
                    security_audit("login", ok=False, detail="secret refused", remote=remote)
                    self.send_json(401, {"ok": False, "error": "Mot de passe Administrator Bridge incorrect."})
                    return
                session = auth_session_create("owner")
                security_audit("register" if route == "/auth/register" else "login", ok=True, remote=remote)
                self.send_json(200, {"ok": True, "bridge_version": "1.9.11", **session})
                return
            except ValueError as exc:
                self.send_json(400, {"ok": False, "error": str(exc)})
                return
            except Exception as exc:
                self.send_json(503, {"ok": False, "error": str(exc)})
                return

        if route not in AUTH_PRIVILEGED_POST:
            self.send_json(404, {"ok": False, "error": "Route inconnue."})
            return
        if self.require_authenticated(route) is None:
            return

        try:
            body = self.read_body(max_bytes=BOOK_MIRROR_MAX_BYTES + 16_384 if route == "/book-mirror/publish" else None)

            if route == "/book-mirror/publish":
                try:
                    self.send_json(200, book_mirror_publish(body))
                except ValueError as exc:
                    security_audit("book_mirror_publish", ok=False, detail=str(exc), remote=self.client_address[0])
                    self.send_json(400, {"ok": False, "error": str(exc)})
                except Exception as exc:
                    security_audit("book_mirror_publish", ok=False, detail=str(exc), remote=self.client_address[0])
                    self.send_json(503, {"ok": False, "error": str(exc)})
                return

            if route == "/scanner-snapshot":
                snapshot = scanner_validate_snapshot(body)
                snapshot = scanner_enrich_snapshot(snapshot, self.config)
                stored = scanner_persist_snapshot(snapshot, self.config)
                self.send_json(200, {
                    "ok": True,
                    "bridge_version": "1.9.11",
                    "schema": SCANNER_SCHEMA,
                    "snapshot_id": snapshot.get("snapshot_id"),
                    "collected_at": snapshot.get("collected_at"),
                    "duplicate": stored.get("duplicate", False),
                    "storage_path": stored.get("path"),
                    "binance_enrichment": snapshot.get("binance_enrichment"),
                    "snapshot": snapshot,
                    "read_only_external": True,
                    "local_observation_storage": True,
                })
                return

            profile = str(body.get("profile") or "atlas").strip().lower()
            if profile not in RUNTIME_PROFILE_FILES:
                raise ValueError("Profil autorisé : atlas ou aerith.")

            snapshot = body.get("snapshot")
            if not isinstance(snapshot, dict):
                raise ValueError("Le snapshot Agent-Crypto doit être un objet JSON.")

            contract = validate_contract(snapshot)
            provider_name, model = choose_provider(self.config)

            if route == "/conclusion":
                if profile != "aerith":
                    raise ValueError("La conclusion finale utilise uniquement le profil Aerith-10.")
                report_modes = body.get("report_modes") or []
                if report_modes != list(CONCLUSION_REPORT_MODES):
                    raise ValueError("Les quatre rapports Atlas-10 validés sont requis dans l’ordre canonique.")
                report_fingerprint = str(body.get("report_fingerprint") or "").strip()
                contract["atlas_reports_v1"] = normalize_conclusion_reports(body.get("reports"), report_fingerprint)
                pedagogy_body = body.get("pedagogy_contract")
                if isinstance(pedagogy_body, dict):
                    contract["pedagogy_v1"] = pedagogy_body
                nox_body = body.get("nox_audit")
                if nox_body is not None:
                    if not isinstance(nox_body, dict):
                        raise ValueError("L'audit NØX doit être un objet JSON.")
                    if str(nox_body.get("schema") or "") != "agent_crypto_nox_no_fomo_v1":
                        raise ValueError("Schéma NØX No-FOMO refusé.")
                    if str(nox_body.get("status") or "").upper() not in {"CALME", "PRUDENCE", "STOP"}:
                        raise ValueError("Statut NØX invalide.")
                    contract["nox_no_fomo_v1"] = nox_body
                model_result = call_model_comment(
                    self.config,
                    provider_name,
                    model,
                    "aerith",
                    "conclusion",
                    "Produire une conclusion prudente après les quatre rapports Atlas-10 validés. Relire tout le snapshot : marché, Top 5, graphique, Math Core, News Sentinel, contradictions, preuves et NØX. Expliquer en français simple les termes crypto, banque, trading et statistiques utilisés. Pour chaque indicateur important : dire ce qu’il mesure, ce que la valeur signifie ici et ce qu’elle ne permet pas de conclure. Ne jamais transformer une actualité en causalité ou signal d’exécution sans preuve. Une donnée absente reste INFORMATION MANQUANTE.",
                    contract,
                )
                if model_result["used"]:
                    candidate = model_result["comment"]
                    concrete_ok, concrete_warnings = validate_aerith_concrete_comment(candidate, contract)
                    if concrete_ok:
                        comment = candidate
                        model_comment_used = True
                        warnings: list[str] = []
                    else:
                        comment = aerith_concrete_limits_comment(contract)
                        model_comment_used = False
                        warnings = list(model_result.get("warnings") or []) + concrete_warnings
                else:
                    comment = aerith_concrete_limits_comment(contract)
                    model_comment_used = False
                    warnings = model_result["warnings"]
                answer = build_aerith_conclusion(contract, comment)
                self.send_json(200, {
                    "ok": True,
                    "profile": "aerith",
                    "provider": provider_name,
                    "model": model,
                    "time": utc_now(),
                    "quality": "strict_contract_v2_v3_truth_evidence",
                    "model_comment_used": model_comment_used,
                    "deterministic_fallback_used": not model_comment_used,
                    "validation_warnings": warnings,
                    "answer": answer,
                    "source_reports": 4,
                    "reports_re_read": True,
                    "report_modes_re_read": list(CONCLUSION_REPORT_MODES),
                    "news_context_used": True,
                    "nox_no_fomo_used": bool(contract.get("nox_no_fomo_v1")),
                    "report_fingerprint": report_fingerprint,
                    "read_only": True,
                })
                return

            if route == "/summary":
                mode = str(body.get("mode") or "market").strip().lower()
                if mode not in {"market", "top5", "math", "contradictions"}:
                    raise ValueError(
                        "Mode autorisé : market, top5, math ou contradictions."
                    )
                question = MODE_LABELS[mode]
            else:
                mode = "chat"
                question = str(body.get("question") or "").strip()
                max_question = int(
                    self.config.get("generation", {})
                    .get("max_question_chars", 4000)
                )
                if not question or len(question) > max_question:
                    raise ValueError("Question vide ou trop longue.")

            suite_meta: dict[str, Any] | None = None
            if (
                route == "/summary"
                and profile == "atlas"
                and bool(self.config.get("performance", {}).get("atlas_suite_single_model_pass", True))
            ):
                suite_meta = call_model_atlas_suite_comments(
                    self.config, provider_name, model, contract
                )
                suite_row = (suite_meta.get("comments") or {}).get(mode) or {}
                comment = suite_row.get("comment") or deterministic_comment(profile, mode)
                model_comment_used = bool(suite_row.get("used"))
                warnings = list(suite_row.get("warnings") or suite_meta.get("warnings") or [])
            else:
                model_result = call_model_comment(
                    self.config,
                    provider_name,
                    model,
                    profile,
                    mode,
                    question,
                    contract,
                )

                if model_result["used"]:
                    comment = model_result["comment"]
                    model_comment_used = True
                    warnings = []
                else:
                    comment = deterministic_comment(profile, mode)
                    model_comment_used = False
                    warnings = model_result["warnings"]

            report_mode = "market" if mode == "chat" else mode
            answer = build_report(
                contract,
                profile,
                report_mode,
                comment,
            )

            self.send_json(200, {
                "ok": True,
                "profile": profile,
                "provider": provider_name,
                "model": model,
                "time": utc_now(),
                "quality": "strict_contract_v2_v3_truth_evidence",
                "model_comment_used": model_comment_used,
                "atlas_suite_single_model_pass": bool(suite_meta is not None),
                "atlas_suite_cache_hit": bool(suite_meta.get("cache_hit")) if suite_meta else False,
                "atlas_model_calls_for_4_4": int(suite_meta.get("model_calls_for_atlas_4_4", 1)) if suite_meta else None,
                "validation_warnings": warnings,
                "answer": answer,
                "read_only": True,
            })

        except ValueError as exc:
            self.send_json(400, {"ok": False, "error": str(exc)})
        except Exception as exc:
            self.send_json(503, {"ok": False, "error": str(exc)})


class BridgeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        handler: type[BaseHTTPRequestHandler],
        config: dict[str, Any],
    ) -> None:
        super().__init__(address, handler)
        self.config = config


def self_test() -> int:
    config = load_config()
    profiles = profile_health()

    assert config["host"] in {"127.0.0.1", "localhost"}
    assert all(item["loaded"] for item in profiles.values()), profiles
    allowed_schemas = config.get("strict_contract", {}).get("accepted_schemas") or []
    assert "atlas_crypto_fact_contract_v2" in allowed_schemas
    assert "atlas_crypto_fact_contract_v3_truth_evidence" in allowed_schemas

    sample = {
        "strict_contract": {
            "schema": "atlas_crypto_fact_contract_v2",
            "rules": {
                "market_list_is_not_portfolio": True,
                "no_missing_value_to_zero": True,
                "no_visual_position_inference": True,
                "no_unlisted_math_measure": True,
                "no_news_from_generic_limit": True,
                "no_financial_instruction": True,
            },
            "canonical_top5": {
                "symbols": ["BTC", "ETH", "BNB", "XRP", "SOL"],
                "complete": False,
                "assets": [],
            },
        }
    }
    validate_contract(sample)
    sample_v3 = json.loads(json.dumps(sample))
    sample_v3["strict_contract"]["schema"] = "atlas_crypto_fact_contract_v3_truth_evidence"
    sample_v3["strict_contract"]["rules"].update({
        "analytical_fingerprint_v2": True,
        "source_truth_v2": True,
        "evidence_independence_required": True,
        "metric_quality_gates": True,
        "transactional_conclusion": True,
    })
    sample_v3["strict_contract"]["source_truth_v2"] = {"schema": "source_truth_v2", "counts": {"DIRECT": 1}}
    sample_v3["strict_contract"]["evidence_v2"] = {"schema": "evidence_v2", "events": [], "counts": {}}
    sample_v3["strict_contract"]["math_quality_gates_v2"] = {"schema": "math_quality_gates_v2", "gates": [], "counts": {}}
    sample_v3["strict_contract"]["contradictions_v2"] = {"schema": "contradictions_v2", "items": [], "counts": {"total": 0}}
    sample_v3["analytical_state"] = {"schema": "analytical_state_v2", "fingerprint": {"algorithm": "SHA-256", "value": "self-test"}}
    validate_contract(sample_v3)
    sample_contract = sample["strict_contract"]
    sample_contract.update({
        "sources": {
            "binance": {"feed_status": "ready", "source": "Binance WebSocket", "direct_pairs": 5, "derived_pairs": 0},
            "coingecko": {"status": "ready", "mode": "direct", "timestamp": utc_now()},
        },
        "market": {"assets_loaded": 250, "target_assets": 250, "breadth_24h": {"positive": 40, "negative": 200, "stable": 10, "classification": "largeur négative", "basis": "Variations 24 h"}},
        "graph": {"truth_label": "Historique en cache retardé", "freshness": "delayed"},
        "math": {"risk_global": "Partiel", "limitation": "mesures historiques seulement"},
        "news": {"status": "ready"},
        "watchlist": {"configured_count": 34},
        "contradictions": [{"level": "à vérifier", "text": "Historique non direct"}],
        "stop_point": {"meaning": "Arrêter lorsque les données ne soutiennent plus une conclusion."},
    })
    sample_contract["canonical_top5"]["complete"] = True
    sample_contract["canonical_top5"]["assets"] = [
        {"available": True, "symbol": symbol, "change_24h_pct": change}
        for symbol, change in zip(["BTC", "ETH", "BNB", "XRP", "SOL"], [-1.0, -2.0, 0.5, -3.0, -2.5])
    ]
    concrete_comment = aerith_concrete_limits_comment(sample_contract)
    conclusion = build_aerith_conclusion(sample_contract, concrete_comment)
    assert "Situation générale" in conclusion and "Limites et stop point" in conclusion
    assert "pas son évolution future" in conclusion
    assert "signal d’exécution" in conclusion

    generic_comment = {
        "reading": "Analyser l’état du marché et des sources.",
        "caution": "Évaluer la qualité des données et la fiabilité des informations.",
        "limits": "Utiliser uniquement les informations fournies, sans ajout ou modification.",
    }
    generic_valid, generic_warnings = validate_aerith_concrete_comment(generic_comment, sample_contract)
    assert generic_valid is False and generic_warnings

    bad_comment = {
        "reading": "Votre portefeuille suit un ratio de Sharpe de 2.",
        "caution": "Acheter demain.",
        "limits": "Stop point dans 30 jours.",
    }
    valid, warnings = validate_model_comment(
        bad_comment,
        sample["strict_contract"],
    )
    assert valid is False and warnings

    print("Configuration : OK")
    print("Profils Atlas/Aerith : OK")
    print("Contrats factuels V2 + V3 Truth/Evidence : OK")
    print("Filtre anti-invention : OK")
    assert set(HISTORY_PERIODS) == {1, 7, 30, 60, 90, 365, 36500}
    assert config.get("history_proxy", {}).get("enabled", True) is True
    print("Proxy historique local : OK")

    sample_scanner = {
        "schema": SCANNER_SCHEMA,
        "snapshot_id": "self-test_2026-07-28-15-30",
        "collector_id": "self-test",
        "collected_at": utc_now(),
        "market": {"source": "CoinGecko", "mode": "direct", "status": "ready", "assets_loaded": 237, "target_assets": 250, "quote_currency": "EUR"},
        "exchange_feed": {"source": "Binance WebSocket", "status": "ready", "direct_pairs": 5, "derived_pairs": 0},
        "baskets": {
            key: {
                "id": key,
                "label": key,
                "ranking_source": "CoinGecko Market Snapshot",
                "ranking_metric": "change_24h_pct" if key != "volume" else "volume_24h_eur",
                "assets": [{
                    "coin_id": "bitcoin",
                    "symbol": "BTC",
                    "name": "Bitcoin",
                    "market_rank": 1,
                    "scanner_rank": 1,
                    "classification_value": 1.0,
                    "market_price_eur": 50000,
                    "observed_price_eur": 50000,
                    "observed_source": "Binance BTCEUR WebSocket",
                    "observed_status": "live",
                    "binance_symbol_candidate": "BTC",
                    "binance_candidate_allowed": True,
                }],
            }
            for key in SCANNER_BASKETS
        },
    }
    sample_fp = "self-test-current-fingerprint"
    sample_reports = {
        mode: {
            "label": MODE_LABELS[mode],
            "answer": (f"Rapport {mode} CURRENT. " * 20).strip(),
            "fingerprint": sample_fp,
            "model": "gpt-oss:20b-32k",
            "time": utc_now(),
        }
        for mode in CONCLUSION_REPORT_MODES
    }
    normalized_reports = normalize_conclusion_reports(sample_reports, sample_fp)
    assert len(normalized_reports) == 4
    assert all(row["fingerprint"] == sample_fp for row in normalized_reports.values())

    validated_scanner = scanner_validate_snapshot(sample_scanner)
    assert validated_scanner["schema"] == SCANNER_SCHEMA
    assert all(validated_scanner["baskets"][key]["assets"] for key in SCANNER_BASKETS)
    print("Scanner Live Collector : OK")
    print("Conclusion Aerith-10 Crypto : OK")
    print("Relecture réelle des 4 rapports Atlas CURRENT : OK")
    print("Mode observation locale · écriture externe générique interdite · miroir Book borné : OK")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return self_test()

    config = load_config()
    host = config.get("host", "127.0.0.1")
    port = int(config.get("port", 8787))
    PID_PATH.write_text(str(os.getpid()), encoding="ascii")

    server = BridgeServer((host, port), BridgeHandler, config)

    def shutdown_handler(signum: int, frame: Any) -> None:
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, shutdown_handler)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, shutdown_handler)

    print("=" * 70)
    print("ATLAS-10 CRYPTO BRIDGE RYZEN V1.9.11")
    print(f"Adresse : http://{host}:{port}")
    print("Modèle : Ollama gpt-oss:20b-32k")
    print("Qualité : contrats V2/V3 Truth-Evidence · Atlas/Aerith · lecture seule")
    print("Mode : observation locale · GitHub générique interdit · miroir Book borné")
    print("=" * 70)

    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        server.server_close()
        try:
            PID_PATH.unlink(missing_ok=True)
        except Exception:
            pass
        print("Bridge arrêté.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
