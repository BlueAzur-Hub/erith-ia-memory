@echo off
setlocal
cd /d "%~dp0"
title Atlas-10 Crypto Bridge Ryzen V1.9.6
echo Verification du Bridge V1.9.6 / GPT-OSS 20B-32K...
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 bridge.py --self-test || goto :error
  py -3 bridge.py
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python bridge.py --self-test || goto :error
  python bridge.py
  goto :end
)
echo.
echo Python 3 est introuvable sur ce PC.
echo Utilisez le Control Center portable fourni dans ce pack.
goto :pause

:error
echo.
echo Le test du Bridge a echoue. Lis le message ci-dessus.

:pause
pause
:end
endlocal
