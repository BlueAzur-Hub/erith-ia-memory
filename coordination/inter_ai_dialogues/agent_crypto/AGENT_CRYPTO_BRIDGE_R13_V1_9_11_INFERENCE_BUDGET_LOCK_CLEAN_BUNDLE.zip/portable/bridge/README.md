# Atlas-10 Crypto Bridge V1.9.6

Pile cible : Agent-Crypto 30.1.0 · Control Center V2.3.2R13 · `gpt-oss:20b-32k` · modèle canonique, budgets runtime 8K/16K.

Le Bridge reste local (`127.0.0.1:8787`) et en lecture seule pour les actions financières et GitHub.

## Routes principales

- `/health` : état Bridge/Ollama.
- `/summary` : 4 lectures Atlas séquentielles.
- `/conclusion` : conclusion Aerith. Cette route exige le fingerprint CURRENT et le texte des 4 rapports Atlas du même fingerprint.
- `/chat` : question libre ; n’ouvre pas un nouveau cycle Atlas/Aerith.

## Contrat de conclusion V1.9.6

La conclusion est refusée si un rapport manque, est trop court ou porte un autre fingerprint. Les quatre textes sont bornés avant envoi au modèle (10 000 caractères chacun, 36 000 caractères au total) afin de rester compatibles avec le contexte 32K. La réponse confirme `reports_re_read: true`.

## Modèle

Le modèle canonique est `gpt-oss:20b-32k`. `CREATE_GPT_OSS_20B_32K.bat` crée exactement cette variante avec `num_ctx 32768`. Aucun helper Llama ou 16K n’est livré dans ce pack consolidé.

## Arrêt

Après CURRENT, l’interface ferme le cycle automatique. Les prix live continuent, mais aucun nouveau passage Atlas/Aerith ne doit démarrer sans relance opérateur.


## V1.9.11 — Inference Budget Lock

- Atlas 4/4 conserve quatre rapports distincts mais utilise **une seule inférence gpt-oss** pour leurs quatre commentaires bornés ; les trois routes suivantes relisent le cache mémoire du même fingerprint.
- Aerith reste une seconde inférence séparée après Atlas 4/4 + NØX.
- Budget runtime : Atlas 8K, Aerith conclusion 16K. Le modèle `gpt-oss:20b-32k` reste canonique ; le Bridge réduit seulement le contexte effectivement réservé par requête.
- `keep_alive`: Atlas 90 s pour éviter un rechargement avant Aerith ; conclusion `0` pour libérer le modèle immédiatement après le CURRENT.
- Aucune modification de Data Truth, Math Core, fingerprint, auth, Book Mirror, exchange/wallet ou contrats de sécurité.
