@echo off
ollama list
echo.
echo Agent-Crypto requiert gpt-oss:20b-32k avec contexte 32768.
pause
