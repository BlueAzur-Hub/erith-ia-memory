@echo off
setlocal
where ollama >nul 2>nul || (echo Ollama introuvable.& pause & exit /b 1)
ollama show gpt-oss:20b-32k >nul 2>nul && (echo gpt-oss:20b-32k est deja disponible.& ollama show gpt-oss:20b-32k& pause & exit /b 0)
ollama show gpt-oss:20b >nul 2>nul || (echo Le modele de base gpt-oss:20b est absent. Lancez: ollama pull gpt-oss:20b& pause & exit /b 1)
> "%TEMP%\Modelfile-gptoss-32k" echo FROM gpt-oss:20b
>>"%TEMP%\Modelfile-gptoss-32k" echo.
>>"%TEMP%\Modelfile-gptoss-32k" echo PARAMETER num_ctx 32768
ollama create gpt-oss:20b-32k -f "%TEMP%\Modelfile-gptoss-32k"
del "%TEMP%\Modelfile-gptoss-32k" >nul 2>nul
echo.
ollama show gpt-oss:20b-32k
pause
