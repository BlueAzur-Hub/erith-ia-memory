$ErrorActionPreference = "Stop"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

$Out = "ATLAS_10_CRYPTO_BRIDGE_CONTROL_CENTER_2_3_2R13_BRIDGE_V1_9_11_PERSISTENT_TRUST_GUI_NO_CONSOLE.exe"
go build -trimpath -ldflags "-H windowsgui -s -w" -o $Out main.go
Write-Host "Compilation terminee : Control Center V2.3.2R13 / Bridge V1.9.11 / Aether Trust Operator UI / Windows GUI subsystem / aucune console hote." 
