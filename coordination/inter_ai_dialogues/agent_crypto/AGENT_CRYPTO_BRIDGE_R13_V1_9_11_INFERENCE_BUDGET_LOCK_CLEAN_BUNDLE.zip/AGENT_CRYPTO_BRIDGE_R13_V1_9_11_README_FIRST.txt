AGENT-CRYPTO · AETHER CONTROL · BRIDGE R13 / V1.9.11
====================================================

OBJECTIF
Réduire la charge locale Atlas sans modifier Data Truth, Math Core, CURRENT, NØX, Aerith, auth ou Book Mirror.

CAUSE MESURÉE DANS LE CODE R12
- Atlas 4/4 déclenchait 4 appels séquentiels gpt-oss:20b-32k (/summary).
- Aerith ajoutait ensuite un 5e appel gpt-oss pour la conclusion.
- Le modèle canonique 20B était exécuté avec une variante num_ctx 32768, puis restait chargé selon le keep-alive Ollama par défaut.

R13 / V1.9.11
- Atlas 4/4 = 1 seule inférence modèle pour les 4 commentaires bornés.
- Les 4 rapports restent distincts et déterministes ; /summary conserve son contrat public.
- Les 3 appels /summary suivants relisent le cache mémoire du même fingerprint.
- Aerith = 1 seconde inférence séparée après Atlas 4/4 + NØX.
- Budget contexte Atlas = 8192.
- Budget contexte conclusion Aerith = 16384.
- keep_alive Atlas = 90 s pour éviter un rechargement entre Atlas et Aerith.
- keep_alive conclusion = 0 : Ollama libère le modèle après la fermeture du CURRENT.
- Total attendu = 2 inférences lourdes par CURRENT au lieu de 5.

INSTALLATION / TEST
1. Quitter l'ancien Control Center R12 (le Bridge peut être arrêté depuis R12 avant remplacement).
2. Lancer l'EXE R13. Le trust Administrator reste dans LOCALAPPDATA/ERITH.IA/AtlasCryptoBridge/trust et n'est pas recréé par version.
3. Vérifier : Bridge V1.9.11, Ollama prêt, auth configurée.
4. Ouvrir Administrator 40.4.51.
5. Attendre un nouveau snapshot canonique ; observer Atlas 0→4/4→NØX→Aerith.
6. Après la conclusion, vérifier que la charge retombe rapidement ; `ollama ps` doit finir par ne plus garder gpt-oss chargé (conclusion keep_alive=0).

ROLLBACK
Relancer simplement l'EXE R12. Aucun format IndexedDB, CURRENT ou trust n'est migré.
