# Last-200-commit audit — Aether geometry conclusion

The repository history was reread across the latest 200 commits, then narrowed to
the Aether/Window Manager chain that actually changes geometry.

Relevant contracts recovered:

- 40.6.41: free resize shell.
- 40.6.52: Aether preload.
- 40.6.74: 16:9 / enlarged field framing work.
- 40.6.75: large responsive field fit.
- 40.6.76: Window Manager owns normal geometry and persisted operator position.
- 40.6.85: left boot x=12.
- 40.6.273: later checkpoint retaining compact normal fallback.
- 40.6.284: lifecycle change that began the later recovery chain.
- 40.6.290–296: native recovery attempts.
- 40.6.297: capture normal geometry -> temporary expanded F11 -> restore intent.
- 40.6.298: geometry-only Window Manager transaction to avoid dock/reparent.
- 40.6.299: interaction-latency repair; kept separate from Aether geometry.
- 40.6.300–304: recovery attempts that progressively mixed normal and F11 geometry.

Key correction:

40.6.304 incorrectly promoted the large field-fit geometry into NORMAL browser mode.
The historical compact formula was not a defect; it is the normal-mode fallback.
The large field belongs only to temporary F11/expanded mode.

40.6.305 therefore restores:

NORMAL = 40.6.76 / 40.6.295 compact operator geometry.
F11    = temporary 40.6.75-style large 16:9 field.
EXIT   = exact pre-F11 NORMAL geometry through geometry-only Window Manager API.
