# AGENT-CRYPTO 40.6.305 — AETHER NORMAL / F11 CONTRACT RESTORE

Main commit:
9d73a9b6fd074b52144c993d93359f30367605f3

Release:
PARKER LEWIS CAN'T LOSE · AETHER NORMAL / F11 CONTRACT RESTORE

Terrain status:
PENDING_FIREFOX

## Correction

40.6.304 was rejected because it used the large historical 40.6.75 field geometry
as NORMAL browser geometry.

40.6.305 restores the two distinct states:

NORMAL
- historical 40.6.76 / 40.6.295 compact operator window
- x=12 fallback
- persisted operator x/y/width/height preserved across close/reopen and F5

F11
- capture exact NORMAL geometry
- temporary large 16:9 historical field
- persist=false
- exact restore on exit F11

## Fresh repair for profiles that ran 40.6.304

Only when:
agent-crypto-administrator:migration:aether-normal-frame-406304 = 1

the one-time 40.6.305 migration resets the oversized 40.6.304 geometry to the
historical NORMAL fallback. Profiles that did not consume 40.6.304 keep their
operator geometry.

## Files changed

- public/agent_crypto_erith_ia/administrator/js/app.js
- public/agent_crypto_erith_ia/administrator/js/core/admin-window-manager.js
- public/agent_crypto_erith_ia/administrator/build.json
- public/agent_crypto_erith_ia/administrator/index.html

## Protected / unchanged

- js/aether.js
- aether.css
- aether-v2.css
- Decision Intelligence Current Truth
- post-boot loader
- Market Core 38.15.11
- Oracle
- Lecture Technique
- Storage business logic
- Strategy
