@echo off
setlocal
title Installation Ollama llama3.2
where ollama >nul 2>nul
if not %errorlevel%==0 (echo Ollama est introuvable.& pause & exit /b 1)
echo Telechargement ou verification de llama3.2...
ollama pull llama3.2
if not %errorlevel%==0 (echo Installation echouee.& pause & exit /b 1)
echo llama3.2 est pret. Lance START_BRIDGE.bat.
pause
endlocal
