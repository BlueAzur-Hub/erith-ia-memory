@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Write-Host '--- HEALTH ---' -ForegroundColor Cyan; try { $h=Invoke-RestMethod -Uri 'http://127.0.0.1:8787/health' -TimeoutSec 5; $h | Select-Object version,quality,history_route,scanner_latest_route,aerith_conclusion_route,read_only,actions | ConvertTo-Json -Depth 5 } catch { Write-Host 'Bridge non joignable :' $_.Exception.Message -ForegroundColor Yellow }"
pause
