# Atlas-10 Crypto Bridge Ryzen V1.7.6 — Clean Production Lock

Cette version nettoie le Bridge V1.7.5 après validation de l’Interface 28.1.95.

## Rôle conservé

Le Bridge fonctionne uniquement sur le Ryzen et fournit :

- `GET /health`
- `GET /profiles`
- `GET /history`
- `GET /scanner-latest`
- `GET /scanner-status`
- `GET /scanner-history`
- `POST /scanner-snapshot`
- `POST /summary`
- `POST /conclusion`
- `POST /chat`

Il permet au Ryzen de produire les quatre rapports Atlas et la conclusion
Aerith, ensuite inscrits dans la sous-section permanente de l’Interface.

## Éléments supprimés

- route `/publish-synthesis`
- code d’appel à l’API GitHub
- gestion d’un jeton GitHub
- `CONFIGURE_GITHUB_PUBLICATION.bat`
- `REMOVE_GITHUB_PUBLICATION.bat`
- messages de publication externe
- section `github_publication` de la configuration

## Sécurité

- écoute uniquement sur `127.0.0.1:8787`
- aucune action exchange
- aucun wallet
- aucune écriture GitHub
- aucune action d’interface
- données de marché et historiques en lecture seule
- snapshots du Scanner conservés uniquement dans le stockage local du Bridge
- profils Atlas/Aerith canoniques conservés

## Utilisation

1. Fermer l’ancien Bridge.
2. Remplacer son dossier par celui de la V1.7.6.
3. Lancer `START_BRIDGE.bat`.
4. Ouvrir l’Interface Agent-Crypto Build 28.1.95.

Aucune configuration GitHub n’est nécessaire.

## Compatibilité

- Interface : Build 28.1.95
- Bridge : V1.7.6
- Ollama : `llama3.2`
- adresse : `http://127.0.0.1:8787`
