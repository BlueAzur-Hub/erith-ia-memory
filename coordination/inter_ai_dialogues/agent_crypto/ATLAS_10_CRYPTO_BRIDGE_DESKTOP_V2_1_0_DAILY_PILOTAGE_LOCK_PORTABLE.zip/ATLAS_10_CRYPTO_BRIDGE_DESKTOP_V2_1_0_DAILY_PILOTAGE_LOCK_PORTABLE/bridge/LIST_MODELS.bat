@echo off
ollama list
echo.
echo Agent-Crypto requiert llama3.2.
pause
