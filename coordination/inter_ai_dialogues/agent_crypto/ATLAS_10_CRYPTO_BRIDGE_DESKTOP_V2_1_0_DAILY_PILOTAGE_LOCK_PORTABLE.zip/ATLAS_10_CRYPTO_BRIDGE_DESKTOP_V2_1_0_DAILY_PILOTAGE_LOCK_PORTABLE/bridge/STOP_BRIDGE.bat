@echo off
setlocal
cd /d "%~dp0"
if not exist bridge.pid (
  echo Aucun Bridge actif detecte.
  pause
  exit /b 0
)
set /p BRIDGE_PID=<bridge.pid
echo Arret du Bridge PID %BRIDGE_PID%...
taskkill /PID %BRIDGE_PID% /T /F
del /q bridge.pid 2>nul
pause
endlocal
