# Atlas-10 Crypto Bridge Desktop V2.1.0 — Daily Pilotage Lock

## Base stable conservée

- Interface Agent-Crypto : Build 28.1.95
- Bridge moteur : V1.7.6
- Control Center : base stable V2.0.1
- Ollama : llama3.2
- thread graphique Win32 verrouillé avec `runtime.LockOSThread()`

## Fonctions quotidiennes

### Démarrage du Bridge

Au lancement :

- aucun Bridge détecté : le Control Center démarre son Bridge intégré ;
- Bridge déjà actif dans cette installation : il devient pilotable ;
- Bridge actif depuis un BAT ou une autre installation : mode externe,
  lecture seule, aucun arrêt forcé.

### Démarrage avec Windows

Le bouton :

`Démarrage Windows : OUI / NON`

utilise uniquement la clé utilisateur :

`HKCU\Software\Microsoft\Windows\CurrentVersion\Run`

Aucun droit administrateur n’est requis.

### Ouverture automatique de l’Interface

Le bouton :

`Interface auto : OUI / NON`

ouvre Agent-Crypto après la vérification ou le démarrage du Bridge.

### Zone de notification

Le bouton :

`Zone notification : OUI / NON`

détermine le comportement de la croix :

- NON : la croix ferme uniquement le Control Center ;
- OUI : la croix masque la fenêtre dans la zone de notification.

Cliquer sur l’icône près de l’horloge restaure la fenêtre.

Le bouton `Quitter Control Center` ferme réellement l’application.
Dans tous les cas, le Bridge reste actif.

## Test Ryzen conseillé

1. Fermer l’ancienne V2.0.1.
2. Lancer `AtlasCryptoBridgeControlCenter.exe`.
3. Vérifier Bridge et Ollama.
4. Activer puis désactiver chaque option.
5. Tester le retour depuis Firefox.
6. Tester la réduction dans la zone de notification.
7. Cliquer sur `Quitter Control Center`.
8. Relancer et vérifier que les options sont mémorisées.

## Sécurité

- écoute locale `127.0.0.1:8787`
- aucun wallet
- aucune action exchange
- aucune écriture GitHub
- aucun jeton
- aucun arrêt d’un Bridge externe
