# Architecture — Control Center V2.1.0

```text
AtlasCryptoBridgeControlCenter.exe
├── GUI Win32 sombre et redimensionnable
├── thread UI verrouillé
├── contrôles réseau asynchrones
├── paramètres JSON locaux
├── démarrage utilisateur Windows optionnel
├── icône de zone de notification optionnelle
├── lancement du Bridge intégré si absent
└── protection stricte des Bridges externes

bridge/
├── bridge.py V1.7.6
├── bridge_config.json
└── profiles Atlas/Aerith
```

## Fichier de paramètres

Installation autonome :

`%LOCALAPPDATA%\ERITH.IA\AtlasCryptoBridge\2.1.0\control_center_settings.json`

Dossier portable :

`control_center_settings.json` à côté de l’EXE.

## Propriété du Bridge

Le PID est reconnu comme pilotable uniquement lorsqu’il est inscrit dans :

`bridge\bridge.pid`

et que le processus existe encore.

Un Bridge sain sur le port 8787 sans PID pilotable est classé :

`Bridge externe · lecture seule`
