# Agent-Crypto 40.6.318 — Aether large CSS presentation

Functional commit: 2ca2d56e8e9f1516d680467e59c583bd91dd1540

Scope:
- CSS presentation enlargement only.
- Aether Observatory visual field up to 1450 px wide.
- Canonical 1672/941 aspect ratio.
- Anchored to the floating Aether top-left.
- Lecture Technique, Market Core 38.15.11, app.js and Window Manager are not modified by the functional patch.

Primary file:
- public/agent_crypto_erith_ia/administrator/aether.css
