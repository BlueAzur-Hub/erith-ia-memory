SEVEN HEAVEN — TRADER SHARED SELECTION FIX
8 octobre 2026

Fichiers modifiés : deux owners partagés Administrator :
- market-instrument-resolver.js
- okx-microstructure-406499.js

Fichier ajouté : test Node VM de sélection rapide BTC → OKB → BTC
+ workflow CI isolé
+ note de chirurgie

Aucune modification du Trader HTML / Graphique / Market Core / Bridge / archives.
Déploiement GitHub Pages après commit ; contrôle Firefox requis pour valider la réalité.
