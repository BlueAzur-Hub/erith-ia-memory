SEVEN HEAVEN - TRADER SHARED SELECTION FIX
Code canonique Administrator, Trader iframe conserve.
7 tests de selection et 9 tests Coffre valides GitHub.
Un resultat backend en cache peut se terminer immediatement.
Aucune modification Bridge/Backend/Graphiques historiques.
Verification Firefox BTC > OKB > BTC recommandee.
