# Agent-Crypto 40.6.173 — Evidence Supplement Bootstrap

## Défaut trouvé
Les modules `.166 → .172` existaient dans le dépôt et dans `runtime-modules.js`, mais
`runtime-shell.html` ne chargeait pas ce registre. Leur présence Git ne prouvait donc
pas leur exécution dans Firefox.

## Correction
Le fichier déjà chargé par le shell `strategy-a-replay-acceptance.js` devient un point
de bootstrap tardif, après `window.load`, pour SEPT modules Strategy A de preuve seulement.

Aucun registre général n'est lancé. Aucun module sans rapport avec Strategy A n'est activé.

## Modules ciblés
- Evidence Lifecycle Truth
- Foundation Applicability Truth
- Time Semantics Truth
- G3 Structured Data Truth
- G3 History Owner Discovery
- G3 Historical Evidence Adapter
- Gate Canonical Truth

## Garde-fous
- aucun timer récurrent
- aucun MutationObserver
- aucun nouvel owner de stockage
- aucune logique Strategy A / Risk / Market Core modifiée
- aucun ordre réel
- G3 reste PENDING
- G9 reste LOCKED

## Commits GitHub
- bootstrap initial retiré/supplanté : `c86d0d7347cb461de1af33cd10d47e3d713bd181`
- bootstrap ciblé final : `5ab75cb7248c109f50a7c9bcca386f1a36185bf9`
- release 40.6.173 : `e2a8451735c4a3f74c4aa16d2aeebe5136b75c17`
- promotion build.json : `260a157afc91279b4d77bc16bd1f30eca180aafd`

## Terrain
La visibilité Firefox des nouveaux panneaux reste PENDING jusqu'au prochain rechargement.
