Seven Heaven · Archive vérifiée dans Trader / relais R10 → R11
Livraison additive. Aucune installation locale du ZIP demandée.
Trader 40.6.624 / Market Core 38.15.11 protégés.
Historique R9 Binance Spot USDT, PAS le graphique OKX USDC.
Panneau repliable à ouvrir depuis le bas du Trader (après cas d'école OKB).
BTC a une archive R9 ; OKB doit afficher archive indisponible.
Tests GitHub Actions Trader R9 = 6/6 ; précédents lecteurs / sélection = 16/16.
Relais R10/R11 à confirmer aussi sur déclenchements schedule autonomes.
