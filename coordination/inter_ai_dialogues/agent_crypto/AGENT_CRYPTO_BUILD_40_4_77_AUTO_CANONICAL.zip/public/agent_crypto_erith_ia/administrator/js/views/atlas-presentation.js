/* Agent-Crypto @erith.IA — 40.4.77
   ATLAS MIGRATION CLOSURE — PRIMARY + SECONDARY DELEGATED HYDRATION OWNER

   40.4.72 preserves the 40.4.70 interaction-first source-lazy topology and fixes
   only second-level operator ownership:
   - every deferred <details> shell receives its canonical secondary key;
   - one stable document-level delegated click owner survives DOM replay/replacement;
   - section buttons and details summaries hydrate through the same owner;
   - per-node listeners are no longer required for secondary demand;
   - no timer, observer, network owner, storage owner or business engine is added.

   40.4.69 completed the two-level source-lazy topology but Firefox operator testing
   still exposed a first-interaction cliff: DOM insertion, binding, state replay and
   semantic visibility reconciliation could execute in the same rendering turn.
   40.4.70 keeps the architecture and finishes its lifecycle contract:

   - parser boot still owns only family header + five stable first-level disclosure shells;
   - canonical views/atlas.html is fetched once, on demand;
   - local-ai first hydration still materializes only the operational core;
   - the 12 secondary readers remain true second-level source-lazy roots;
   - critical action binding runs immediately after DOM insertion;
   - state/render replay is deferred to one bounded requestAnimationFrame handoff so
     Firefox can commit the newly-created DOM before non-critical presentation work;
   - per-scope critical/replay timings are exposed for operator diagnosis;
   - no duplicate legacy Atlas owner, recurring timer, observer, storage owner,
     market owner or CURRENT owner is added.
*/
(()=>{
  "use strict";
  const BUILD="40.4.77";
  const SOURCE="./views/atlas.html";
  const host=document.getElementById("atlas-view-host");
  if(!host)return;

  const shellHtml=`
    <section class="atlas-layout-family atlas-layout-family-intelligence" aria-labelledby="atlasLayoutFamily02" data-atlas-source-lazy-40469="header">
      <span class="atlas-layout-family-index" aria-hidden="true">02</span>
      <div class="atlas-layout-family-copy">
        <p>PARCOURS ADMINISTRATEUR</p>
        <h2 id="atlasLayoutFamily02" class="atlas-icon-heading-40290" data-semantic-tone-40290="intelligence"><span class="atlas-heading-icon-40290" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="12" r="2"></circle><circle cx="12" cy="6" r="2"></circle><circle cx="18" cy="12" r="2"></circle><circle cx="12" cy="18" r="2"></circle><path d="M7.5 10.5 10.5 7.5M13.5 7.5l3 3M16.5 13.5l-3 3M10.5 16.5l-3-3"></path></svg></span>Intelligence, mémoire & création</h2>
        <span>Interroger Atlas et Aerith, conserver les repères, puis ouvrir la Forge sans quitter le parcours.</span>
      </div>
      <span class="atlas-layout-family-signal" aria-hidden="true"></span>
    </section>

    <details class="atlas-collapse glass atlas-local-ai-collapse atlas-family-member atlas-tone-intelligence" id="atlas-local-ai-collapse" data-collapse-key="local-ai-hub" data-layout-family="intelligence" data-atlas-source-lazy-shell-40467="local-ai-hub" data-atlas-source-lazy-shell-40469="local-ai-hub">
      <summary class="atlas-collapse-summary">
        <span class="atlas-collapse-icon" aria-hidden="true">▶</span>
        <span class="atlas-collapse-title">Atlas-10 + Aerith-10 Crypto</span>
        <span class="atlas-collapse-subtitle">Profils locaux du Ryzen · contenu opérationnel chargé à l’ouverture</span>
        <div class="atlas-collapsed-current-preview-40295" id="atlasCollapsedCurrentPreview40295" data-phase="idle" aria-label="Résumé du pipeline CURRENT Atlas">
          <div class="atlas-collapsed-current-copy-40295"><span>PIPELINE LOCAL · CURRENT</span><b id="atlasCollapsedCurrentTitle40295">État runtime conservé</b></div>
          <div class="atlas-collapsed-current-readout-40295"><strong id="atlasCollapsedCurrentPercent40295">0 %</strong><span id="atlasCollapsedCurrentState40295">IDLE</span></div>
          <div class="atlas-collapsed-current-track-40295" aria-hidden="true"><span id="atlasCollapsedCurrentBar40295"></span></div>
          <div class="atlas-analysis-progress-nodes atlas-collapsed-current-nodes-40295" aria-label="Étapes compactes Atlas CURRENT"><span data-atlas-progress-node="1"><i>01</i><b>Marché</b></span><span data-atlas-progress-node="2"><i>02</i><b>Top 5</b></span><span data-atlas-progress-node="3"><i>03</i><b>Math Core</b></span><span data-atlas-progress-node="4"><i>04</i><b>Contradictions</b></span><span data-atlas-progress-node="nox"><i>NØX</i><b>No-FOMO</b></span><span data-atlas-progress-node="aerith"><i>A</i><b>Aerith</b></span></div>
        </div>
      </summary>
      <div class="atlas-collapse-body" data-atlas-source-lazy-body-40467="local-ai-hub" data-atlas-source-lazy-body-40469="local-ai-hub" data-atlas-hydration-40469="placeholder"><p class="atlas-local-response-empty">Atlas/Aerith · runtime conservé · présentation opérationnelle chargée uniquement à l’ouverture.</p></div>
    </details>

    <details class="atlas-collapse glass forge-aerith-collapse forge-aerith-embedded-collapse atlas-family-member atlas-tone-creation" id="forge-aerith" data-collapse-key="forge-aerith" data-layout-family="creation" data-atlas-source-lazy-shell-40467="forge-aerith" data-atlas-source-lazy-shell-40469="forge-aerith">
      <summary class="atlas-collapse-summary"><span class="atlas-collapse-icon" aria-hidden="true">▶</span><span class="atlas-collapse-title">✦ Forge d’Aerith Pro</span><span class="atlas-collapse-subtitle">Atelier Créatrice · chargé à l’ouverture</span></summary>
      <div class="atlas-collapse-body" data-atlas-source-lazy-body-40467="forge-aerith" data-atlas-source-lazy-body-40469="forge-aerith" data-atlas-hydration-40469="placeholder"></div>
    </details>

    <details class="atlas-collapse glass atlas-family-member atlas-tone-intelligence" data-collapse-key="auto-reader" data-layout-family="intelligence" data-atlas-source-lazy-shell-40467="auto-reader" data-atlas-source-lazy-shell-40469="auto-reader">
      <summary class="atlas-collapse-summary"><span class="atlas-collapse-icon" aria-hidden="true">▶</span><span class="atlas-collapse-title">Atlas Auto Reader</span><span class="atlas-collapse-subtitle">Collecte autonome du marché · présentation à la demande</span></summary>
      <div class="atlas-collapse-body" data-atlas-source-lazy-body-40467="auto-reader" data-atlas-source-lazy-body-40469="auto-reader" data-atlas-hydration-40469="placeholder"></div>
    </details>

    <details class="atlas-collapse glass atlas-family-member atlas-tone-intelligence" data-collapse-key="shared-memory" data-layout-family="intelligence" data-atlas-source-lazy-shell-40467="shared-memory" data-atlas-source-lazy-shell-40469="shared-memory">
      <summary class="atlas-collapse-summary"><span class="atlas-collapse-icon" aria-hidden="true">▶</span><span class="atlas-collapse-title">Shared Memory</span><span class="atlas-collapse-subtitle">Export / import par machine · présentation à la demande</span></summary>
      <div class="atlas-collapse-body" data-atlas-source-lazy-body-40467="shared-memory" data-atlas-source-lazy-body-40469="shared-memory" data-atlas-hydration-40469="placeholder"></div>
    </details>

    <details class="atlas-collapse glass atlas-family-member atlas-tone-intelligence" data-collapse-key="github-memory" data-layout-family="intelligence" data-atlas-source-lazy-shell-40467="github-memory" data-atlas-source-lazy-shell-40469="github-memory">
      <summary class="atlas-collapse-summary"><span class="atlas-collapse-icon" aria-hidden="true">▶</span><span class="atlas-collapse-title">GitHub Shared Memory</span><span class="atlas-collapse-subtitle">Mémoire commune GitHub · présentation à la demande</span></summary>
      <div class="atlas-collapse-body" data-atlas-source-lazy-body-40467="github-memory" data-atlas-source-lazy-body-40469="github-memory" data-atlas-hydration-40469="placeholder"></div>
    </details>`;

  const SPECS=Object.freeze({
    "local-ai-hub":Object.freeze({id:"atlas-local-ai-collapse",selector:'#atlas-local-ai-collapse',scope:"local-ai"}),
    "forge-aerith":Object.freeze({id:"forge-aerith",selector:'#forge-aerith',scope:"forge"}),
    "auto-reader":Object.freeze({selector:'details[data-collapse-key="auto-reader"]',scope:"auto-reader"}),
    "shared-memory":Object.freeze({selector:'details[data-collapse-key="shared-memory"]',scope:"shared-memory"}),
    "github-memory":Object.freeze({selector:'details[data-collapse-key="github-memory"]',scope:"github-memory"})
  });

  const SECONDARY=Object.freeze({
    "stable-stack":Object.freeze({tag:"section",id:"atlasStableStack",titleId:"atlasStableStackTitle",eyebrow:"PILE STABLE CONSOLIDÉE · PRODUCTION / LECTURE",title:"Interface, Control Center, Bridge et mémoire",scope:"current-audit"}),
    "analytical-truth":Object.freeze({tag:"section",id:"atlasAnalyticalTruth",titleId:"atlasAnalyticalTruthTitle",eyebrow:"VÉRITÉ ANALYTIQUE · EMPREINTE V2",title:"Contexte, sources, preuves et qualité statistique",scope:"current-audit"}),
    "frame-truth":Object.freeze({tag:"section",id:"atlasFrameTruth",titleId:"atlasFrameTruthTitle",eyebrow:"COHÉRENCE TEMPORELLE · SNAPSHOT / LIVE",title:"Snapshot analysé et marché live",scope:"current-audit"}),
    "current-truth":Object.freeze({tag:"section",id:"atlasCurrentTruth33",titleId:"atlasCurrentTruth33Title",eyebrow:"CURRENT TRUTH · ÉTAT TRANSACTIONNEL",title:"Pourquoi cette analyse est CURRENT",scope:"current-audit"}),
    "memory-market":Object.freeze({tag:"details",id:"atlasMemoryIntelligence",title:"Market Memory · continuité 3 / 5 / 10",scope:"memory-residency"}),
    "memory-analytical":Object.freeze({tag:"details",id:"atlasAnalyticalMemory394",title:"Analytical Memory · CURRENT fermés",scope:"memory-residency"}),
    "decision-board":Object.freeze({tag:"section",id:"decision-board",titleId:"decisionBoardDeferredTitle40469",eyebrow:"ATLAS DECISION BOARD V2",title:"Décision froide + continuité mémoire",scope:"decision-board"}),
    "scanner-truth":Object.freeze({tag:"section",id:"atlasScannerTruth37",titleId:"atlasScannerTruthTitle37",eyebrow:"SCANNER TRUTH · HAUSSES / BAISSES / VOLUMES",title:"Scanner marché et provenance des cotations",scope:"scanner"}),
    "current-journal":Object.freeze({tag:"details",id:"atlasCurrentJournal33",title:"Journal CURRENT · archives analytiques",scope:"current-journal"}),
    "multi-collector":Object.freeze({tag:"details",id:"atlasMultiCollectorDetails40357",title:"Multi-Collector & Operator Console",scope:"multi-collector"}),
    "book-readonly":Object.freeze({tag:"section",id:"atlasBookReadOnlyKnowledge",titleId:"atlasBookReadOnlyTitle",eyebrow:"SHARED READ-ONLY KNOWLEDGE · RYZEN → BOOK",title:"Miroir et lecture Book",scope:"book-knowledge",group:"book-knowledge"}),
    "knowledge-library":Object.freeze({tag:"section",id:"atlasKnowledgeLibrary",titleId:"atlasKnowledgeLibraryTitle",eyebrow:"BIBLIOTHÈQUE PÉDAGOGIQUE PERMANENTE · SANS BRIDGE",title:"Dictionnaire Crypto / Banque / Bourse",scope:"book-knowledge",group:"book-knowledge"})
  });

  let sourcePromise=null;
  let sourceTextCache="";
  let sourceFetchCount=0;
  let hydrationCount=0;
  let secondaryHydrationCount=0;
  let lastError="";
  let semanticFrame=0;
  let sourceFetchDurationMs=0;
  const hydrated=new Set();
  const secondaryHydrated=new Set();
  const pendingRebind=new Set();
  const replayFrames=new Map();
  const scopeTimings=new Map();
  const now=()=>globalThis.performance?.now?.()??Date.now();
  const rounded=value=>Math.round(Number(value||0)*100)/100;
  function timingPatch(scope,patch={}){
    const key=String(scope||"unknown");
    scopeTimings.set(key,Object.freeze({...scopeTimings.get(key),...patch}));
  }

  host.insertAdjacentHTML("beforebegin",shellHtml);
  host.remove();

  const escRe=value=>String(value).replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  function elementBounds(source,tag,matcher){
    const startRe=matcher instanceof RegExp?matcher:new RegExp(`<${tag}\\b[^>]*${matcher}[^>]*>`,`i`);
    const hit=startRe.exec(source); if(!hit)return null;
    const start=hit.index,openEnd=start+hit[0].length,token=new RegExp(`<\\/?${tag}\\b[^>]*>`,`ig`);
    token.lastIndex=start; let depth=0,m;
    while((m=token.exec(source))){
      if(new RegExp(`^<\\/${tag}`,"i").test(m[0]))depth-=1;else depth+=1;
      if(depth===0)return {start,openEnd,close:m.index,end:token.lastIndex,openTag:hit[0]};
    }
    return null;
  }
  function detailBounds(source,keyOrId){
    const byId=String(keyOrId||"").startsWith("#");
    const value=byId?String(keyOrId).slice(1):String(keyOrId||"");
    const re=byId
      ? new RegExp(`<details\\b[^>]*\\bid=["']${escRe(value)}["'][^>]*>`,`i`)
      : new RegExp(`<details\\b[^>]*data-collapse-key=["']${escRe(value)}["'][^>]*>`,`i`);
    return elementBounds(source,"details",re);
  }
  function sectionBounds(source,id){
    return elementBounds(source,"section",new RegExp(`<section\\b[^>]*\\bid=["']${escRe(id)}["'][^>]*>`,`i`));
  }
  function sourceText(){
    if(sourceTextCache)return Promise.resolve(sourceTextCache);
    if(sourcePromise)return sourcePromise;
    sourceFetchCount+=1;
    const fetchStarted=now();
    sourcePromise=fetch(SOURCE,{credentials:"same-origin",cache:"default"})
      .then(response=>{if(!response.ok)throw new Error(`Atlas source HTTP ${response.status}`);return response.text();})
      .then(text=>{sourceTextCache=String(text||"");lastError="";sourceFetchDurationMs=rounded(now()-fetchStarted);return sourceTextCache;})
      .catch(error=>{sourceFetchDurationMs=rounded(now()-fetchStarted);lastError=String(error?.message||error||"Atlas source unavailable");sourcePromise=null;throw error;});
    return sourcePromise;
  }

  function placeholderOpenTag40469(openTag){
    const raw=String(openTag||"");
    if(/\bdata-atlas-hydration-40469\s*=/.test(raw))return raw.replace(/data-atlas-hydration-40469\s*=\s*["'][^"']*["']/i,'data-atlas-hydration-40469="placeholder"');
    return raw.replace(/>\s*$/,' data-atlas-hydration-40469="placeholder">');
  }
  function secondaryDetailsOpenTag40472(openTag,key){
    let raw=placeholderOpenTag40469(openTag);
    if(/\bdata-atlas-secondary-shell-40469\s*=/.test(raw)){
      return raw.replace(/data-atlas-secondary-shell-40469\s*=\s*["'][^"']*["']/i,`data-atlas-secondary-shell-40469="${String(key||"")}"`);
    }
    return raw.replace(/>\s*$/,` data-atlas-secondary-shell-40469="${String(key||"")}">`);
  }
  function sectionShellHtml(key,spec,openTag){
    const marked=placeholderOpenTag40469(openTag);
    return `${marked}<div class="section-head compact atlas-source-secondary-shell-40469" data-atlas-secondary-shell-40469="${key}"><div><p class="eyebrow">${spec.eyebrow||"ATLAS · LECTURE À LA DEMANDE"}</p><h5 id="${spec.titleId||`${spec.id}DeferredTitle40469`}">${spec.title}</h5><p class="planning-intro">Runtime et mémoire conservés · détails matérialisés uniquement à la demande.</p></div><button class="btn" type="button" data-atlas-secondary-open-40469="${key}" aria-controls="${spec.id}">Ouvrir les détails</button></div></section>`;
  }
  function detailsShellHtml(source,key,spec,bounds){
    const summaryStart=source.indexOf("<summary",bounds.openEnd);
    const summaryClose=summaryStart>=0?source.indexOf("</summary>",summaryStart):-1;
    const summary=summaryStart>=0&&summaryClose>=0
      ? source.slice(summaryStart,summaryClose+"</summary>".length)
      : `<summary class="atlas-collapse-summary"><span class="atlas-collapse-icon" aria-hidden="true">▶</span><span class="atlas-collapse-title">${spec.title}</span><span class="atlas-collapse-subtitle">Contenu chargé à l’ouverture</span></summary>`;
    return `${secondaryDetailsOpenTag40472(bounds.openTag,key)}${summary}<div class="atlas-collapse-body atlas-source-secondary-body-40469" data-atlas-secondary-body-40469="${key}" data-atlas-hydration-40469="placeholder"><p class="atlas-local-response-empty">${spec.title} · contenu conservé dans la source canonique et chargé à l’ouverture.</p></div></details>`;
  }
  function stripSecondary(source){
    let next=String(source||"");
    // Replace deepest/high-cost subtrees one by one before the local-ai HTML is parsed.
    // The outer root and ID remain connected, so role routing and hash navigation stay stable.
    for(const [key,spec] of Object.entries(SECONDARY)){
      const b=spec.tag==="details"?detailBounds(next,`#${spec.id}`):sectionBounds(next,spec.id);
      if(!b)continue;
      const shell=spec.tag==="details"?detailsShellHtml(next,key,spec,b):sectionShellHtml(key,spec,b.openTag);
      next=next.slice(0,b.start)+shell+next.slice(b.end);
    }
    return next;
  }
  function sourceDetailHtml(source,key){
    const spec=SPECS[key]; if(!spec)return "";
    const b=spec.id?detailBounds(source,`#${spec.id}`):detailBounds(source,key);
    if(!b)return "";
    let html=source.slice(b.start,b.end);
    if(key==="local-ai-hub")html=stripSecondary(html);
    return html;
  }
  function sourceElementInner(source,spec){
    const b=spec.tag==="details"?detailBounds(source,`#${spec.id}`):sectionBounds(source,spec.id);
    return b?source.slice(b.openEnd,b.close):"";
  }
  function liveDetail(key){return document.querySelector(`[data-atlas-source-lazy-shell-40469="${CSS.escape(key)}"]`)||document.querySelector(`[data-atlas-source-lazy-shell-40467="${CSS.escape(key)}"]`);}
  function liveBody(key){return liveDetail(key)?.querySelector(':scope > .atlas-collapse-body')||null;}
  function parseDetailBody(html,key){
    const template=document.createElement("template"); template.innerHTML=html;
    const sourceDetail=template.content.querySelector(SPECS[key].selector);
    const sourceBody=sourceDetail?.querySelector(':scope > .atlas-collapse-body');
    if(!(sourceBody instanceof HTMLElement))throw new Error(`Atlas body missing: ${key}`);
    return sourceBody.content?sourceBody.content.cloneNode(true):[...sourceBody.childNodes].map(node=>node.cloneNode(true));
  }

  function invalidatePresentation(scope){
    try{(globalThis.AgentCryptoAtlasPresentationEpoch40470||globalThis.AgentCryptoAtlasPresentationEpoch40469)?.invalidate?.(scope);}catch(_){}
  }
  function ownerRebind(scope,phase="full"){
    const owner=globalThis.AgentCryptoAtlasLateHydration40470||globalThis.AgentCryptoAtlasLateHydration40469||globalThis.AgentCryptoAtlasLateHydration40468||globalThis.AgentCryptoAtlasLateHydration40467;
    if(!owner?.rebind){pendingRebind.add(scope);return false;}
    try{owner.rebind(scope,{phase});pendingRebind.delete(scope);return true;}catch(error){pendingRebind.add(scope);console.warn(`Agent-Crypto ${BUILD} · Atlas late rebind`,scope,phase,error);return false;}
  }
  function scheduleSemanticReconcile(){
    if(semanticFrame)return;
    semanticFrame=requestAnimationFrame(()=>{
      semanticFrame=0;
      try{globalThis.atlasV2ClassifySections?.();}catch(_){}
      try{const mode=globalThis.atlasV2Mode?.()||document.documentElement.dataset.atlasView||"essential";globalThis.atlasV2ApplySectionVisibility?.(mode);globalThis.atlasV2ApplySemanticRoleIsolation40312?.(mode);}catch(_){}
    });
  }
  function rebind(scope,{semantic=false}={}){
    const clean=String(scope||"all");
    invalidatePresentation(clean);
    const criticalStarted=now();
    ownerRebind(clean,"critical");
    timingPatch(clean,{critical_ms:rounded(now()-criticalStarted),last_phase:"critical",pending_replay:true});

    const previous=replayFrames.get(clean);
    if(previous)cancelAnimationFrame(previous);
    const frame=requestAnimationFrame(()=>{
      replayFrames.delete(clean);
      const replayStarted=now();
      ownerRebind(clean,"replay");
      if(semantic)scheduleSemanticReconcile();
      const replayMs=rounded(now()-replayStarted);
      timingPatch(clean,{replay_ms:replayMs,last_phase:"replay",pending_replay:false,last_completed_at:new Date().toISOString()});
      try{window.dispatchEvent(new CustomEvent("erith:atlas-hydrated",{detail:{build:BUILD,scope:clean,phase:"replay",critical_ms:scopeTimings.get(clean)?.critical_ms||0,replay_ms:replayMs}}));}catch(_){}
    });
    replayFrames.set(clean,frame);
    return true;
  }

  function attachSecondary(root=document){
    // 40.4.72 — secondary demand is owned by one stable delegated listener.
    // Nodes may be replaced by source hydration/replay; ownership must survive.
    root.querySelectorAll?.('[data-atlas-secondary-open-40469]')?.forEach(button=>{
      button.dataset.atlasSecondaryOwner40472="delegated";
    });
    root.querySelectorAll?.('details[data-atlas-secondary-shell-40469]')?.forEach(detail=>{
      detail.dataset.atlasSecondaryOwner40472="delegated";
    });
  }

  function installSecondaryDelegation40472(){
    const marker=document.documentElement;
    if(marker.dataset.atlasSecondaryDelegation40472==="1")return;
    marker.dataset.atlasSecondaryDelegation40472="1";
    document.addEventListener("click",event=>{
      const target=event.target instanceof Element?event.target:null;
      if(!target)return;
      const button=target.closest('[data-atlas-secondary-open-40469]');
      if(button){
        const key=String(button.dataset.atlasSecondaryOpen40469||"");
        if(SECONDARY[key]){
          event.preventDefault();
          void hydrateSecondary(key);
        }
        return;
      }
      const summary=target.closest("summary");
      const detail=summary?.parentElement;
      if(detail instanceof HTMLDetailsElement && detail.matches('details[data-atlas-secondary-shell-40469]')){
        const key=String(detail.dataset.atlasSecondaryShell40469||"");
        if(SECONDARY[key])queueMicrotask(()=>void hydrateSecondary(key));
      }
    },true);
  }
  installSecondaryDelegation40472();

  // 40.4.75 — close the remaining first-level ownership gap.
  // Secondary demand has had a stable document owner since .72, but the five
  // first-level Atlas disclosures still depended on listeners attached to the
  // initial DOM nodes. Window/lifecycle replay may replace those nodes.
  // Native <details> owns visibility; this delegated layer owns hydration only.
  function atlasPrimaryKey40475(detail){
    if(!(detail instanceof HTMLDetailsElement))return "";
    const key=String(
      detail.dataset.atlasSourceLazyShell40469
      || detail.dataset.atlasSourceLazyShell40467
      || detail.dataset.collapseKey
      || ""
    );
    return SPECS[key]?key:"";
  }

  function atlasPrimaryStatus40475(key,phase,message=""){
    const detail=liveDetail(key);
    if(!(detail instanceof HTMLDetailsElement))return false;
    detail.dataset.atlasPrimaryHydration40475=String(phase||"idle");
    const subtitle=detail.querySelector(":scope > summary .atlas-collapse-subtitle");
    if(subtitle && message)subtitle.textContent=message;
    return true;
  }

  function atlasPrimaryDemand40475(detail,reason="operator"){
    const key=atlasPrimaryKey40475(detail);
    if(!key)return false;
    const live=liveDetail(key);
    if(!(live instanceof HTMLDetailsElement)||!live.open)return false;
    const body=liveBody(key);
    if(body?.dataset?.atlasHydration40469==="ready"){
      atlasPrimaryStatus40475(key,"ready",
        key==="local-ai-hub"
          ?"Profils locaux du Ryzen · Atlas/Aerith opérationnels"
          :`${live.querySelector(":scope > summary .atlas-collapse-title")?.textContent?.trim()||"Section"} · opérationnel`);
      return true;
    }
    atlasPrimaryStatus40475(key,"loading","Chargement de la présentation opérationnelle…");
    queueMicrotask(()=>void hydrate(key).then(ok=>{
      atlasPrimaryStatus40475(
        key,
        ok?"ready":"error",
        ok
          ?(key==="local-ai-hub"
              ?"Profils locaux du Ryzen · Atlas/Aerith opérationnels"
              :`${liveDetail(key)?.querySelector(":scope > summary .atlas-collapse-title")?.textContent?.trim()||"Section"} · opérationnel`)
          :"Présentation indisponible · chargement Atlas à vérifier"
      );
    }));
    return true;
  }

  function installPrimaryDelegation40475(){
    const marker=document.documentElement;
    if(marker.dataset.atlasPrimaryDelegation40475==="1")return;
    marker.dataset.atlasPrimaryDelegation40475="1";

    // Mouse/touch activation. Resolve the live disclosure after the native
    // summary toggles it, so replacement/replay cannot strand a visible shell.
    document.addEventListener("click",event=>{
      const target=event.target instanceof Element?event.target:null;
      const summary=target?.closest?.("summary");
      const detail=summary?.parentElement;
      const key=atlasPrimaryKey40475(detail);
      if(!key)return;
      queueMicrotask(()=>{
        const live=liveDetail(key);
        if(live instanceof HTMLDetailsElement && live.open)atlasPrimaryDemand40475(live,"click");
      });
    },true);

    // Covers keyboard activation, restored "open" state and programmatic
    // disclosure changes. toggle does not need to bubble when captured.
    document.addEventListener("toggle",event=>{
      const detail=event.target;
      const key=atlasPrimaryKey40475(detail);
      if(!key||!detail.open)return;
      atlasPrimaryDemand40475(detail,"toggle");
    },true);

    // Presentation lifecycle owners may re-resident/replace a disclosure.
    document.addEventListener("erith:presentation-resident",event=>{
      const detail=event.target instanceof HTMLDetailsElement?event.target:null;
      const key=atlasPrimaryKey40475(detail);
      if(!key||!detail.open)return;
      atlasPrimaryDemand40475(detail,"resident");
    },true);
  }
  installPrimaryDelegation40475();

  async function hydrateSecondary(key){
    key=String(key||"");
    const spec=SECONDARY[key]; if(!spec)return false;
    if(spec.group==="book-knowledge"){
      const groupKeys=Object.entries(SECONDARY).filter(([,row])=>row.group===spec.group).map(([name])=>name);
      let ok=true;
      for(const name of groupKeys){if(!secondaryHydrated.has(name))ok=(await hydrateSecondaryOne(name,{deferRebind:true}))&&ok;}
      rebind(spec.scope); return ok;
    }
    return hydrateSecondaryOne(key);
  }
  async function hydrateSecondaryOne(key,{deferRebind=false}={}){
    const spec=SECONDARY[key]; if(!spec)return false;
    if(secondaryHydrated.has(key))return true;
    const root=document.getElementById(spec.id); if(!root)return false;
    root.dataset.atlasHydration40469="loading";
    try{
      const source=await sourceText();
      const inner=sourceElementInner(source,spec); if(!inner)throw new Error(`Atlas secondary source missing: ${spec.id}`);
      const template=document.createElement("template"); template.innerHTML=inner;
      root.replaceChildren(template.content.cloneNode(true));
      root.dataset.atlasHydration40469="ready";
      secondaryHydrated.add(key); secondaryHydrationCount+=1;
      attachSecondary(root);
      if(!deferRebind)rebind(spec.scope);
      return true;
    }catch(error){
      root.dataset.atlasHydration40469="error";
      lastError=String(error?.message||error||"unknown");
      const note=root.querySelector(".planning-intro,.atlas-local-response-empty");
      if(note)note.textContent=`Chargement différé indisponible · ${lastError}`;
      console.warn(`Agent-Crypto ${BUILD} · Atlas secondary hydration failed`,key,error);
      return false;
    }
  }

  async function hydrate(key){
    key=String(key||""); const spec=SPECS[key]; if(!spec)return false;
    const detail=liveDetail(key); let body=liveBody(key);
    if(!(detail instanceof HTMLDetailsElement))return false;
    if(!(body instanceof HTMLElement)){
      try{globalThis.ErithPresentationLifecycle?.restoreForHash?.(`#${detail.id||detail.dataset.collapseKey||""}`);}catch(_){}
      body=liveBody(key);
    }
    if(!(body instanceof HTMLElement))return false;
    if(body.dataset.atlasHydration40469==="ready")return true;
    if(body.dataset.atlasHydration40469==="loading"){try{await sourcePromise;}catch(_){}return body.dataset.atlasHydration40469==="ready";}
    body.dataset.atlasHydration40469="loading";
    try{
      const source=await sourceText();
      const html=sourceDetailHtml(source,key); if(!html)throw new Error(`Atlas detail missing: ${key}`);
      const nodes=parseDetailBody(html,key);
      if(Array.isArray(nodes))body.replaceChildren(...nodes);else body.replaceChildren(nodes);
      body.dataset.atlasHydration40469="ready";
      body.dataset.atlasHydration40467="ready";
      hydrated.add(key); hydrationCount+=1;
      attachSecondary(body);
      rebind(spec.scope,{semantic:key==="local-ai-hub"||key==="forge-aerith"});
      return true;
    }catch(error){
      body.dataset.atlasHydration40469="error";
      body.innerHTML=`<p class="atlas-local-response-empty">Présentation Atlas indisponible · ${String(error?.message||error||"erreur inconnue")}</p>`;
      lastError=String(error?.message||error||"unknown");
      console.warn(`Agent-Crypto ${BUILD} · Atlas source hydration failed`,key,error);
      return false;
    }
  }

  // Initial-node fast path. The durable 40.4.75 owner is document delegation.
  Object.keys(SPECS).forEach(key=>{
    const detail=liveDetail(key); if(!(detail instanceof HTMLDetailsElement))return;
    detail.dataset.atlasPrimaryOwner40475="delegated";
    const ensure=()=>{if(detail.open)queueMicrotask(()=>void hydrate(key));};
    detail.addEventListener("toggle",ensure);
    detail.addEventListener("erith:presentation-resident",ensure);
    if(detail.open)ensure();
  });

  const targetToSecondary=Object.freeze(Object.fromEntries(Object.entries(SECONDARY).map(([key,spec])=>[spec.id,key])));
  const ownedNavigationTargets=new Set(["local-ai-hub","decision-board","auto-reader","shared-memory","github-memory","forge-aerith",...Object.keys(targetToSecondary)]);
  function ownsTarget(id){return ownedNavigationTargets.has(String(id||"").replace(/^#/,""));}
  async function ensureTarget(id){
    id=String(id||"").replace(/^#/,"");
    // Resolve the owning first-level disclosure before trusting a DOM match.
    // Forge itself and every secondary shell already have a connected root at boot/
    // first disclosure; that root is only a placeholder until its canonical body is
    // materialized. Returning it early would make navigation appear successful while
    // leaving the operator in an inert shell.
    let key="local-ai-hub";
    if(id==="forge-aerith")key="forge-aerith";
    else if(id==="auto-reader")key="auto-reader";
    else if(id==="shared-memory")key="shared-memory";
    else if(id==="github-memory")key="github-memory";
    const detail=liveDetail(key);
    if(detail)detail.open=true;
    const body=liveBody(key);
    if(body?.dataset?.atlasHydration40469!=="ready")await hydrate(key);
    const secondaryKey=targetToSecondary[id];
    if(secondaryKey)await hydrateSecondary(secondaryKey);
    const direct=document.getElementById(id);
    return direct||detail||null;
  }
  function hashHydrate(){
    const id=decodeURIComponent(String(location.hash||"").replace(/^#/,"")); if(!id)return;
    if(!ownsTarget(id)){
      if(document.getElementById(id))return;
      if(!/^atlas/i.test(id))return;
    }
    void ensureTarget(id).then(node=>{if(node)requestAnimationFrame(()=>node.scrollIntoView?.({block:"start"}));});
  }
  window.addEventListener("hashchange",hashHydrate,{passive:true});
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",hashHydrate,{once:true});else hashHydrate();

  function replayRebind(){
    const scopes=new Set(pendingRebind);
    for(const key of hydrated)scopes.add(SPECS[key]?.scope);
    for(const key of secondaryHydrated)scopes.add(SECONDARY[key]?.scope);
    [...scopes].filter(Boolean).forEach(scope=>rebind(scope,{semantic:scope==="local-ai"||scope==="forge"}));
    return [...scopes].filter(Boolean);
  }
  function snapshot(){return Object.freeze({
    build:BUILD,source:SOURCE,strategy:"delegated first-level + delegated second-level Atlas source-lazy residency + interaction-first paint handoff + scope timing",
    boot_full_atlas_html:false,local_ai_full_subtree_on_first_open:false,legacy_peripheral_lazy_owner_loaded:false,
    source_fetch_count:sourceFetchCount,source_fetch_ms:sourceFetchDurationMs,source_text_cached:!!sourceTextCache,hydration_count:hydrationCount,secondary_hydration_count:secondaryHydrationCount,
    hydrated:[...hydrated],secondary_hydrated:[...secondaryHydrated],pending_rebind:[...pendingRebind],pending_replay:[...replayFrames.keys()],scope_timings:Object.fromEntries(scopeTimings),last_error:lastError||null,
    current_runtime_owner:"app.js + IndexedDB",book_mirror_runtime_preserved:true,auto_reader_runtime_preserved:true,github_memory_runtime_preserved:true,
    current_engine_changed:false,bridge_engine_changed:false,market_core_changed:false,oracle_changed:false,new_recurring_timer:false,new_observer:false,storage_owner_added:false,bounded_paint_handoff:true,primary_delegated_owner:true,secondary_delegated_owner:true
  });}

  const api=Object.freeze({
    build:BUILD,source:SOURCE,ensureBody:hydrate,ensureTarget,ownsTarget,hydrateSecondary,replayRebind,snapshot,
    keys:Object.keys(SPECS),secondaryKeys:Object.keys(SECONDARY),new_recurring_timer:false,new_observer:false,storage_owner_added:false
  });
  globalThis.ErithAtlasPresentation=api;
  globalThis.ErithAtlasPresentation40467=api;
  globalThis.ErithAtlasPresentation40468=api;
  globalThis.ErithAtlasPresentation40469=api;
  globalThis.ErithAtlasPresentation40470=api;
  globalThis.ErithAtlasPresentation40472=api;
  globalThis.ErithAtlasPresentation40475=api;
  globalThis.AgentCryptoAtlasPeripheralLazy=Object.freeze({build:BUILD,retired_legacy_owner:true,replaced_by:"ErithAtlasPresentation40472",runtime_owner:"app.js"});
  globalThis.__AGENT_CRYPTO_ATLAS_PRESENTATION_40469__=snapshot();
  globalThis.__AGENT_CRYPTO_ATLAS_PRESENTATION_40470__=snapshot();
  globalThis.__AGENT_CRYPTO_ATLAS_PRESENTATION_40472__=snapshot();
  globalThis.__AGENT_CRYPTO_ATLAS_PRESENTATION_40475__=snapshot();
})();
