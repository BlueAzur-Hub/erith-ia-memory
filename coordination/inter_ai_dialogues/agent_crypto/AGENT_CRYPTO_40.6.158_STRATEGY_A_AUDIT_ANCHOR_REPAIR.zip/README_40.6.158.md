# Agent-Crypto 40.6.158 — STRATEGY A AUDIT ANCHOR REPAIR

Firefox terrain proof for 40.6.157:
- Build 40.6.157 loaded.
- Existing 9 Evidence Dossier rows visible.
- AUDIT DES 9 GATES and EXÉCUTER TESTS FONDATION · G2/G7 absent.

40.6.158 repair:
- Adds a late-mount repair companion.
- Re-runs the existing audit render only on ordinary lifecycle/operator events.
- Relocates the audit immediately after the existing nine-row gate list.
- No timer, MutationObserver, storage owner, order path, threshold, Market Core or business logic change.

Commits:
- repair module: 8d94f70723468569c4fa84e506d8f8b35dcef1cd
- runtime registry: c155408a88a8379e81a63d8203b40c022be301e0
- immutable release entry: 0c964bf03e2c90765823bf4e270d724f172ffa9c
- promotion: fe122864a1972c72eed6381878c0fa36fde12326
- visible audit stamp follow-up: b29c49bc645aa291fdc3d232d04f0219e8da143a

Expected Firefox location:
PAPER TRADING SANDBOX
→ PREUVES CROISÉES
→ open EVIDENCE DOSSIER · 9 GATE(S) NON SOLDÉE(S)
→ after the ninth row: AUDIT DES 9 GATES
→ button: EXÉCUTER TESTS FONDATION · G2/G7
