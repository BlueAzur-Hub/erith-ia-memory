# Agent-Crypto — Upload Build 28.2.82

## Version

**Market Core V2.0-Alpha · Build 28.2.82 — CHECKBOX LAYOUT & GUIDED SESSION UI FIX**

## Base

Build 28.2.81 publié et testé sous Firefox/Ryzen. Le contenu fonctionne, mais les cases à cocher héritent de la règle générale `input { width: 100% }`, ce qui éloigne visuellement la case de son texte.

## Fichiers à remplacer

```text
public/agent_crypto_erith_ia/web/app.js
public/agent_crypto_erith_ia/web/index.html
public/agent_crypto_erith_ia/web/style.css
public/agent_crypto_erith_ia/web/version.json
```

Ne remplacer aucun autre fichier.

## Contrôle après upload

1. Attendre la publication GitHub Pages.
2. Ouvrir l’interface sous Firefox/Ryzen.
3. Effectuer un rechargement complet avec `Ctrl + F5`.
4. Vérifier que le cartouche de version indique `Build 28.2.82`.
5. Ouvrir le Cockpit d’apprentissage.
6. Vérifier les cinq lignes de la session guidée : petite case carrée à gauche, texte immédiatement à côté, aucune grande zone vide.
7. Vérifier `J’ai vérifié ces hypothèses pour l’exercice` dans les coûts pédagogiques.
8. Vérifier les trois cases du retrait fictif.
9. Vérifier les huit cases du Scam Sentinel.
10. Cocher et décocher plusieurs cases pour confirmer que leur comportement n’a pas changé.

## Résultat attendu

- Desktop : cases carrées de 16 px.
- Petit écran : cases carrées de 17 px.
- Aucun contrôle étiré sur la largeur de la carte.
- Aucun texte rejeté au bord droit.
- Les lignes de session restent compactes et lisibles.
- Tous les calculs et toutes les fonctions du Build 28.2.81 restent identiques.

## Rollback

En cas de problème inattendu, restaurer les quatre fichiers du ZIP final Build 28.2.81.

## Sécurité

Aucune écriture GitHub, aucune transaction, aucune clé API, aucun wallet et aucun argent réel n’ont été utilisés pendant la préparation du Build.
