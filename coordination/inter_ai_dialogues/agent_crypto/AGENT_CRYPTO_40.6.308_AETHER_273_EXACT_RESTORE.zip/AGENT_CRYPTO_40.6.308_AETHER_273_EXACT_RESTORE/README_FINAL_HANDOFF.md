# 40.6.308 — RESTORE, NOT PATCH

This build abandons the Aether repair stack introduced after the proven 40.6.273
baseline. The five modified Aether subsystem files are restored exactly from
40.6.273. The two canonical V2 integration files already matched 40.6.273 and
remain untouched.

The only non-restoration changes are build/index identity for 40.6.308.

## Gate
1. Build header must show 40.6.308.
2. Ctrl+F5.
3. Open Aether outside F11.
4. Compare directly with the known-good NORMAL reference.
5. Enter F11 and compare with the known-good F11 reference.
6. Exit F11: geometry must return exactly.

Any mismatch = FAIL / STOP. No follow-up patch is authorized by this handoff.
