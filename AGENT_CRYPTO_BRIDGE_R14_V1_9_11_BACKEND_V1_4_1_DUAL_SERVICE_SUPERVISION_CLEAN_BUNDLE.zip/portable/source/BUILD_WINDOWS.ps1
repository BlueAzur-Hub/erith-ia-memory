$ErrorActionPreference = "Stop"
$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

$Out = "ATLAS_10_CRYPTO_BRIDGE_CONTROL_CENTER_2_3_2R14_BRIDGE_V1_9_11_BACKEND_V1_4_1_DUAL_SERVICE_SUPERVISION_GUI_NO_CONSOLE.exe"
go build -trimpath -ldflags "-H windowsgui -s -w" -o $Out main.go
Write-Host "Compilation terminee : Control Center V2.3.2R14 / Bridge V1.9.11 intact / Private Backend V1.4.1 intact / double supervision locale 8787+8790 / Windows GUI / aucune console hote."
