@echo off
setlocal
cd /d "%~dp0"
python private_backend.py
if errorlevel 1 (
  echo.
  echo Private Backend stopped with an error.
  pause
)
endlocal
