@echo off
setlocal
cd /d "%~dp0"
where pythonw >nul 2>nul
if errorlevel 1 (
  echo Pythonw introuvable. Lance start_private_backend_console.cmd pour le diagnostic.
  pause
  exit /b 1
)
start "Agent-Crypto Private Backend 8790" /b pythonw private_backend.py --quiet
exit /b 0
