# Agent-Crypto Private Backend V1.4.1

Backend local **read-only** sur `127.0.0.1:8790`.

## Ajout V1.4.1

- `GET /system` : CPU Windows, RAM Windows et GPU NVIDIA via `nvidia-smi` si disponible.
- Aucun contrôle système : lecture uniquement.
- `start_private_backend.cmd` démarre avec `pythonw` sans console persistante.
- `start_private_backend_console.cmd` conserve la console pour diagnostic manuel.
- Routes marché V1.4.0 inchangées : `/health`, `/sources`, `/quotes`, `/context`.

## Aether

La ligne Aether Administrator lit `http://127.0.0.1:8790/system`. Si le backend ou une mesure n'est pas disponible, l'interface affiche `N/D` : aucune valeur n'est inventée.

## Test

```powershell
python private_backend.py --self-test
```

Le serveur refuse les binds non-loopback et bloque POST/PUT/PATCH/DELETE.
