# R14 dual-service supervision architecture

```text
Administrator 40.4.139
        |
        +--> Bridge V1.9.11 · 127.0.0.1:8787
        |       -> Ollama / Atlas / Aerith / Book Mirror / auth
        |
        +--> Private Backend V1.4.1 · 127.0.0.1:8790
                -> Kraken / Coinbase / DEX / DeFi / system telemetry

Aether Control 2.3.2R14
        -> supervises 8787
        -> supervises 8790
        -> does not merge either runtime
```

## Ownership lock

R14 modifies the **Go Control Center only**.

Protected owners:
- `bridge/bridge.py` stays V1.9.11;
- `backend/private_backend.py` stays V1.4.1;
- Administrator/Atlas/Market Core are outside this bundle.

## Backend adoption

When `8790` is already healthy, R14 can discover the listening PID through Windows, then validates that its command line is `private_backend.py --quiet` before treating it as pilotable. If that proof fails, the process remains external and STOP/RESTART are refused.
