# Aether Control — Atlas-10 Crypto Bridge 2.3.2R14

R14 is a **Control Center integration release**.

Runtime owners remain separate:

- `bridge/bridge.py` — Bridge V1.9.11 on `127.0.0.1:8787`;
- `backend/private_backend.py` — Private Backend V1.4.1 on `127.0.0.1:8790`.

The Windows GUI now supervises both services: health, PID ownership, start, stop, restart and separate logs. It also reports Administrator build **40.4.139**.

No Atlas, Market Core, exchange-private API or wallet code is introduced by R14.

Use the top-level Windows GUI executable for normal operation. `start_private_backend.cmd` remains available only as a manual fallback. Sources are in `source/`.
