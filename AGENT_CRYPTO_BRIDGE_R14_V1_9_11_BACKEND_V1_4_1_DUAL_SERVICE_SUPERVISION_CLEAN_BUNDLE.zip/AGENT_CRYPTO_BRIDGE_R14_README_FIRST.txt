AGENT-CRYPTO · AETHER CONTROL · CONTROL CENTER R14
=================================================

VERSION
- Control Center : 2.3.2R14
- Bridge moteur : V1.9.11 INCHANGÉ
- Private Backend : V1.4.1 INCHANGÉ
- Administrator affiché : 40.4.139
- Ports locaux : Bridge 8787 · Private Backend 8790

OBJECTIF UNIQUE
Finir l'intégration quotidienne du Private Backend V1.4.1 sans fusionner les propriétaires.
Le Control Center supervise désormais deux services locaux séparés :
- Bridge 8787 -> Ollama / Atlas / Aerith
- Private Backend 8790 -> Kraken / Coinbase / DEX / DeFi / /system

R14
- démarre automatiquement le Bridge s'il n'est pas prêt ;
- démarre automatiquement le Private Backend s'il n'est pas prêt ;
- lance les deux processus sans console hôte ;
- health check séparé pour 8787 et 8790 ;
- PID, START, STOP et RESTART séparés ;
- journal Bridge séparé de journal Backend ;
- peut adopter le Private Backend V1.4.1 déjà lancé par start_private_backend.cmd si le listener 8790 et la ligne de commande sont cohérents ;
- refuse l'arrêt d'un processus Backend qui ne peut pas être identifié comme private_backend.py --quiet ;
- corrige la vérité d'affichage Administrator : 40.4.139 au lieu de 40.4.51.

NON-MODIFIÉ
- bridge/bridge.py V1.9.11 : hash identique R13 ;
- profils Atlas/Aerith : inchangés ;
- bridge_config.json : inchangé ;
- backend/private_backend.py V1.4.1 : hash identique au dossier validé Windows ;
- Atlas 40.4.139 : aucun fichier web modifié ;
- Market Core 38.15.11 : aucun fichier modifié ;
- aucune clé exchange ; aucun endpoint trading ajouté.

USAGE NORMAL
1. Lancer l'EXE R14.
2. Attendre les cartes : BRIDGE actif/prêt et PRIVATE BACKEND actif/prêt.
3. Le bouton Ouvrir Administrator ouvre la 40.4.139.
4. Les boutons Bridge et Backend pilotent chaque service séparément.
5. Quitter le Control Center laisse les services actifs, comme le comportement R13 du Bridge.

CAS DE TA SESSION ACTUELLE
Si Private Backend V1.4.1 a déjà été lancé par start_private_backend.cmd, R14 tente de l'identifier sur 127.0.0.1:8790 et de l'adopter proprement. S'il ne peut pas prouver le PID, il reste en observation et refuse de tuer un processus inconnu.

ROLLBACK
Relancer simplement l'EXE R13. Bridge V1.9.11 et Backend V1.4.1 n'ont subi aucune migration de données.
